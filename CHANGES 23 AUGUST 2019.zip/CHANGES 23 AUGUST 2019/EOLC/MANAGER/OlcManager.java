package panacea.OLC.Update;

import java.util.Vector;
import java.sql.*;
import panacea.common.JNDINames;
import java.util.LinkedHashMap;
import panacea.Manager.Manager;

/******************SQL2JAVA_IMPORT_BEGIN******************/

/******************SQL2JAVA_IMPORT_END********************/


public class OlcManager extends Manager
/******************SQL2JAVA_EXTENDS_BEGIN******************/

/******************SQL2JAVA_EXTENDS_END********************/

{

/******************SQL2JAVA_CLASS_BEGIN******************/

/******************SQL2JAVA_CLASS_END********************/


    public static final int OLC_BRN_CODE = 0;
    public static final int OLC_LC_TYPE = 1;
    public static final int OLC_LC_YEAR = 2;
    public static final int OLC_LC_SL = 3;
    public static final int OLC_CORR_REF_NUM = 4;
    public static final int OLC_LC_PRESANC_DATE = 5;
    public static final int OLC_LC_PRESANC_DAY_SL = 6;
    public static final int OLC_LC_DATE = 7;
    public static final int OLC_CUST_NUM = 8;
    public static final int OLC_BENEF_CODE = 9;
    public static final int OLC_BENEF_NAME = 10;
    public static final int OLC_BENEF_ADDR1 = 11;
    public static final int OLC_BENEF_ADDR2 = 12;
    public static final int OLC_BENEF_ADDR3 = 13;
    public static final int OLC_BENEF_ADDR4 = 14;
    public static final int OLC_BENEF_ADDR5 = 15;
    public static final int OLC_BENEF_CNTRY_CODE = 16;
    public static final int OLC_LC_ISS_BK_CODE = 17;
    public static final int OLC_LC_ISS_BRN_CODE = 18;
    public static final int OLC_LC_ISS_BRN_NAME = 19;
    public static final int OLC_LC_ISS_BRN_ADD1 = 20;
    public static final int OLC_LC_ISS_BRN_ADD2 = 21;
    public static final int OLC_LC_ISS_BRN_ADD3 = 22;
    public static final int OLC_LC_ISS_BRN_ADD4 = 23;
    public static final int OLC_LC_ISS_BRN_ADD5 = 24;
    public static final int OLC_LC_ISS_PLACE = 25;
    public static final int OLC_LC_ISS_CNTRY = 26;
    public static final int OLC_LC_ADV_THRU = 27;
    public static final int OLC_LC_CURR_CODE = 28;
    public static final int OLC_LC_AMOUNT = 29;
    public static final int OLC_LC_BALANCE = 30;
    public static final int OLC_DEV_ALLWD = 31;
    public static final int OLC_POS_DEV_ALLWD = 32;
    public static final int OLC_NEG_DEV_ALLWD = 33;
    public static final int OLC_DEV_AMOUNT = 34;
    public static final int OLC_DEV_BAL = 35;
    public static final int OLC_AMT_QUALFR = 36;
    public static final int OLC_PRICE_TERMS = 37;
    public static final int OLC_LAST_DATE_OF_NEG = 38;
    public static final int OLC_PLACE_OF_EXPIRY = 39;
    public static final int OLC_LATEST_DATE_OF_SHPMNT = 40;
    public static final int OLC_WITHIN_VALIDATE_LC = 41;
    public static final int OLC_LC_UI_BORNE_BY_APPLCNT = 42;
    public static final int OLC_NOF_TENORS = 43;
    public static final int OLC_LC_UNDER_CONTRACT = 44;
    public static final int OLC_TOT_LIAB_LC_CURR = 45;
    public static final int OLC_CONV_RATE_BASE_CURR = 46;
    public static final int OLC_TOT_LIAB_BASE_CURR = 47;
    public static final int OLC_CONV_RATE_LIM_CURR = 48;
    public static final int OLC_TOT_LIAB_LIM_CURR = 49;
    public static final int OLC_PAYMNT_CURR = 50;
    public static final int OLC_TOT_CHRGS_IN_PAYMNT_CURR = 51;
    public static final int OLC_CASH_MARGIN_BAL = 52;
    public static final int OLC_REIMB_CHRGS_BY = 53;
    public static final int OLC_PERC_RC_PAID_BY_APPLCNT = 54;
    public static final int OLC_NOSTRO_ALPHA_CODE = 55;
    public static final int OLC_ADV_THRU_BK = 56;
    public static final int OLC_ADV_THRU_BRN = 57;
    public static final int OLC_LC_TO_BE_CNFRMD = 58;
    public static final int OLC_LC_TO_BE_CNFRMD_BY_BK = 59;
    public static final int OLC_LC_TO_BE_CNFRMD_BY_BRN = 60;
    public static final int OLC_RESTRICTED = 61;
    public static final int OLC_RESTRICTED_TO_US = 62;
    public static final int OLC_RESTRICTED_BK_CODE = 63;
    public static final int OLC_RESTRICTED_BRN_CODE = 64;
    public static final int OLC_CR_AVLBL_BY = 65;
    public static final int OLC_IRREVOCABLE = 66;
    public static final int OLC_PART_SHPMNT = 67;
    public static final int OLC_TRAN_SHPMNT = 68;
    public static final int OLC_LC_TRANSFRBL = 69;
    public static final int OLC_DFT_REQD = 70;
    public static final int OLC_PERC_DFT_VALUE = 71;
    public static final int OLC_DFT_TO_BE_DRAWN_ON = 72;
    public static final int OLC_DFT_ON_BK = 73;
    public static final int OLC_DFT_ON_BRN = 74;
    public static final int OLC_SPEC_TEXT1 = 75;
    public static final int OLC_SPEC_TEXT2 = 76;
    public static final int OLC_SPEC_TEXT3 = 77;
    public static final int OLC_SPEC_TEXT4 = 78;
    public static final int OLC_PRIME_RATE_CLAUSE_REQ = 79;
    public static final int OLC_SHPMNT_MODE = 80;
    public static final int OLC_LLOYDS_CLAUSE_REQ = 81;
    public static final int OLC_MAX_SHIP_AGE = 82;
    public static final int OLC_SHORT_FORM_OF_BL = 83;
    public static final int OLC_LASH_TRANS_DOCS_ALLWD = 84;
    public static final int OLC_PERC_OF_INS_VALUE_CVRD = 85;
    public static final int OLC_INS_POLICY_NUM = 86;
    public static final int OLC_INS_DATE = 87;
    public static final int OLC_INS_CURR = 88;
    public static final int OLC_INS_AMT = 89;
    public static final int OLC_PREMIUM_CURR = 90;
    public static final int OLC_PREMIUM_AMT = 91;
    public static final int OLC_INS_COMPANY = 92;
    public static final int OLC_INS_COMPANY_NAME = 93;
    public static final int OLC_COO_ISS_BY = 94;
    public static final int OLC_OTHER_COMP_AUTH = 95;
    public static final int OLC_INTERMEDIARY_TRADE = 96;
    public static final int OLC_INSP_TEST_CERT_REQ = 97;
    public static final int OLC_CERT_BY = 98;
    public static final int OLC_IMP_UNDER = 99;
    public static final int OLC_IMP_POLICY_DET = 100;
    public static final int OLC_IMP_REF = 101;
    public static final int OLC_CUST_LIAB_ACC = 102;
    public static final int OLC_CANCELLED_ON = 103;
    public static final int OLC_USANCE_CHARGES = 104;
    public static final int OLC_USN_CHG_TAKEN_DAYS = 105;
    public static final int OLC_COMMITMENT_CHARGES = 106;
    public static final int OLC_COMMIT_CHG_TAKEN_DAYS = 107;
    public static final int TRANCHGS_CHGS_SL = 108;
    public static final int TRANCRATES_RATE_SL = 109;
    public static final int TRANSTLMNT_INV_NUM = 110;
    public static final int POST_TRAN_BRN = 111;
    public static final int POST_TRAN_DATE = 112;
    public static final int POST_TRAN_BATCH_NUM = 113;
    public static final int OLC_ENTD_BY = 114;
    public static final int OLC_ENTD_ON = 115;
    public static final int OLC_LASTMOD_BY = 116;
    public static final int OLC_LASTMOD_ON = 117;
    public static final int OLC_AUTH_BY = 118;
    public static final int OLC_AUTH_ON = 119;
    public static final int OLC_REJ_BY = 120;
    public static final int OLC_REJ_ON = 121;
    public static final int OLC_MARGIN_CURR = 122;
    public static final int OLC_MARGIN_AMT = 123;
    public static final int OLC_MARGIN_BAL = 124;
    public static final int OLC_CASH_MAR_AMT = 125;
    public static final int OLC_CASH_MAR_BAL = 126;
    public static final int OLC_CASH_MAR_REC = 127;
    public static final int OLC_DEP_MAR_REC = 128;
    public static final int OLC_OTH_SEC_MAR_REC = 129;
    public static final int OLC_USANCE_SERV_TAX = 130;
    public static final int OLC_COMMIT_SERV_TAX = 131;

    private String OldData_Key;
    private String NewData_Key;
    private String DataBlock_Old;
    private String DataBlock_New;
    private LinkedHashMap _COLLECTIONobj;
    private int _Logreq ;
    private int _Logaddreq ;
    public OlcManager(LinkedHashMap _COLLECTIONobj, int _Log_Req , int _Log_Add_Req ){
        this._COLLECTIONobj 	= _COLLECTIONobj;
        this._Logreq 			= _Log_Req;
        this._Logaddreq 		= _Log_Add_Req;
    }
    private static final String[] S2J_FIELD_NAMES = {
        "OLC.OLC_BRN_CODE"
        ,"OLC.OLC_LC_TYPE"
        ,"OLC.OLC_LC_YEAR"
        ,"OLC.OLC_LC_SL"
        ,"OLC.OLC_CORR_REF_NUM"
        ,"OLC.OLC_LC_PRESANC_DATE"
        ,"OLC.OLC_LC_PRESANC_DAY_SL"
        ,"OLC.OLC_LC_DATE"
        ,"OLC.OLC_CUST_NUM"
        ,"OLC.OLC_BENEF_CODE"
        ,"OLC.OLC_BENEF_NAME"
        ,"OLC.OLC_BENEF_ADDR1"
        ,"OLC.OLC_BENEF_ADDR2"
        ,"OLC.OLC_BENEF_ADDR3"
        ,"OLC.OLC_BENEF_ADDR4"
        ,"OLC.OLC_BENEF_ADDR5"
        ,"OLC.OLC_BENEF_CNTRY_CODE"
        ,"OLC.OLC_LC_ISS_BK_CODE"
        ,"OLC.OLC_LC_ISS_BRN_CODE"
        ,"OLC.OLC_LC_ISS_BRN_NAME"
        ,"OLC.OLC_LC_ISS_BRN_ADD1"
        ,"OLC.OLC_LC_ISS_BRN_ADD2"
        ,"OLC.OLC_LC_ISS_BRN_ADD3"
        ,"OLC.OLC_LC_ISS_BRN_ADD4"
        ,"OLC.OLC_LC_ISS_BRN_ADD5"
        ,"OLC.OLC_LC_ISS_PLACE"
        ,"OLC.OLC_LC_ISS_CNTRY"
        ,"OLC.OLC_LC_ADV_THRU"
        ,"OLC.OLC_LC_CURR_CODE"
        ,"OLC.OLC_LC_AMOUNT"
        ,"OLC.OLC_LC_BALANCE"
        ,"OLC.OLC_DEV_ALLWD"
        ,"OLC.OLC_POS_DEV_ALLWD"
        ,"OLC.OLC_NEG_DEV_ALLWD"
        ,"OLC.OLC_DEV_AMOUNT"
        ,"OLC.OLC_DEV_BAL"
        ,"OLC.OLC_AMT_QUALFR"
        ,"OLC.OLC_PRICE_TERMS"
        ,"OLC.OLC_LAST_DATE_OF_NEG"
        ,"OLC.OLC_PLACE_OF_EXPIRY"
        ,"OLC.OLC_LATEST_DATE_OF_SHPMNT"
        ,"OLC.OLC_WITHIN_VALIDATE_LC"
        ,"OLC.OLC_LC_UI_BORNE_BY_APPLCNT"
        ,"OLC.OLC_NOF_TENORS"
        ,"OLC.OLC_LC_UNDER_CONTRACT"
        ,"OLC.OLC_TOT_LIAB_LC_CURR"
        ,"OLC.OLC_CONV_RATE_BASE_CURR"
        ,"OLC.OLC_TOT_LIAB_BASE_CURR"
        ,"OLC.OLC_CONV_RATE_LIM_CURR"
        ,"OLC.OLC_TOT_LIAB_LIM_CURR"
        ,"OLC.OLC_PAYMNT_CURR"
        ,"OLC.OLC_TOT_CHRGS_IN_PAYMNT_CURR"
        ,"OLC.OLC_CASH_MARGIN_BAL"
        ,"OLC.OLC_REIMB_CHRGS_BY"
        ,"OLC.OLC_PERC_RC_PAID_BY_APPLCNT"
        ,"OLC.OLC_NOSTRO_ALPHA_CODE"
        ,"OLC.OLC_ADV_THRU_BK"
        ,"OLC.OLC_ADV_THRU_BRN"
        ,"OLC.OLC_LC_TO_BE_CNFRMD"
        ,"OLC.OLC_LC_TO_BE_CNFRMD_BY_BK"
        ,"OLC.OLC_LC_TO_BE_CNFRMD_BY_BRN"
        ,"OLC.OLC_RESTRICTED"
        ,"OLC.OLC_RESTRICTED_TO_US"
        ,"OLC.OLC_RESTRICTED_BK_CODE"
        ,"OLC.OLC_RESTRICTED_BRN_CODE"
        ,"OLC.OLC_CR_AVLBL_BY"
        ,"OLC.OLC_IRREVOCABLE"
        ,"OLC.OLC_PART_SHPMNT"
        ,"OLC.OLC_TRAN_SHPMNT"
        ,"OLC.OLC_LC_TRANSFRBL"
        ,"OLC.OLC_DFT_REQD"
        ,"OLC.OLC_PERC_DFT_VALUE"
        ,"OLC.OLC_DFT_TO_BE_DRAWN_ON"
        ,"OLC.OLC_DFT_ON_BK"
        ,"OLC.OLC_DFT_ON_BRN"
        ,"OLC.OLC_SPEC_TEXT1"
        ,"OLC.OLC_SPEC_TEXT2"
        ,"OLC.OLC_SPEC_TEXT3"
        ,"OLC.OLC_SPEC_TEXT4"
        ,"OLC.OLC_PRIME_RATE_CLAUSE_REQ"
        ,"OLC.OLC_SHPMNT_MODE"
        ,"OLC.OLC_LLOYDS_CLAUSE_REQ"
        ,"OLC.OLC_MAX_SHIP_AGE"
        ,"OLC.OLC_SHORT_FORM_OF_BL"
        ,"OLC.OLC_LASH_TRANS_DOCS_ALLWD"
        ,"OLC.OLC_PERC_OF_INS_VALUE_CVRD"
        ,"OLC.OLC_INS_POLICY_NUM"
        ,"OLC.OLC_INS_DATE"
        ,"OLC.OLC_INS_CURR"
        ,"OLC.OLC_INS_AMT"
        ,"OLC.OLC_PREMIUM_CURR"
        ,"OLC.OLC_PREMIUM_AMT"
        ,"OLC.OLC_INS_COMPANY"
        ,"OLC.OLC_INS_COMPANY_NAME"
        ,"OLC.OLC_COO_ISS_BY"
        ,"OLC.OLC_OTHER_COMP_AUTH"
        ,"OLC.OLC_INTERMEDIARY_TRADE"
        ,"OLC.OLC_INSP_TEST_CERT_REQ"
        ,"OLC.OLC_CERT_BY"
        ,"OLC.OLC_IMP_UNDER"
        ,"OLC.OLC_IMP_POLICY_DET"
        ,"OLC.OLC_IMP_REF"
        ,"OLC.OLC_CUST_LIAB_ACC"
        ,"OLC.OLC_CANCELLED_ON"
        ,"OLC.OLC_USANCE_CHARGES"
        ,"OLC.OLC_USN_CHG_TAKEN_DAYS"
        ,"OLC.OLC_COMMITMENT_CHARGES"
        ,"OLC.OLC_COMMIT_CHG_TAKEN_DAYS"
        ,"OLC.TRANCHGS_CHGS_SL"
        ,"OLC.TRANCRATES_RATE_SL"
        ,"OLC.TRANSTLMNT_INV_NUM"
        ,"OLC.POST_TRAN_BRN"
        ,"OLC.POST_TRAN_DATE"
        ,"OLC.POST_TRAN_BATCH_NUM"
        ,"OLC.OLC_ENTD_BY"
        ,"OLC.OLC_ENTD_ON"
        ,"OLC.OLC_LASTMOD_BY"
        ,"OLC.OLC_LASTMOD_ON"
        ,"OLC.OLC_AUTH_BY"
        ,"OLC.OLC_AUTH_ON"
        ,"OLC.OLC_REJ_BY"
        ,"OLC.OLC_REJ_ON"
        ,"OLC.OLC_MARGIN_CURR"
        ,"OLC.OLC_MARGIN_AMT"
        ,"OLC.OLC_MARGIN_BAL"
        ,"OLC.OLC_CASH_MAR_AMT"
        ,"OLC.OLC_CASH_MAR_BAL"
        ,"OLC.OLC_CASH_MAR_REC"
        ,"OLC.OLC_DEP_MAR_REC"
        ,"OLC.OLC_OTH_SEC_MAR_REC"
        ,"OLC.OLC_USANCE_SERV_TAX"
        ,"OLC.OLC_COMMIT_SERV_TAX"
    };

    private static final String ALL_FIELDS = "OLC.OLC_BRN_CODE"
                            + ",OLC.OLC_LC_TYPE"
                            + ",OLC.OLC_LC_YEAR"
                            + ",OLC.OLC_LC_SL"
                            + ",OLC.OLC_CORR_REF_NUM"
                            + ",OLC.OLC_LC_PRESANC_DATE"
                            + ",OLC.OLC_LC_PRESANC_DAY_SL"
                            + ",OLC.OLC_LC_DATE"
                            + ",OLC.OLC_CUST_NUM"
                            + ",OLC.OLC_BENEF_CODE"
                            + ",OLC.OLC_BENEF_NAME"
                            + ",OLC.OLC_BENEF_ADDR1"
                            + ",OLC.OLC_BENEF_ADDR2"
                            + ",OLC.OLC_BENEF_ADDR3"
                            + ",OLC.OLC_BENEF_ADDR4"
                            + ",OLC.OLC_BENEF_ADDR5"
                            + ",OLC.OLC_BENEF_CNTRY_CODE"
                            + ",OLC.OLC_LC_ISS_BK_CODE"
                            + ",OLC.OLC_LC_ISS_BRN_CODE"
                            + ",OLC.OLC_LC_ISS_BRN_NAME"
                            + ",OLC.OLC_LC_ISS_BRN_ADD1"
                            + ",OLC.OLC_LC_ISS_BRN_ADD2"
                            + ",OLC.OLC_LC_ISS_BRN_ADD3"
                            + ",OLC.OLC_LC_ISS_BRN_ADD4"
                            + ",OLC.OLC_LC_ISS_BRN_ADD5"
                            + ",OLC.OLC_LC_ISS_PLACE"
                            + ",OLC.OLC_LC_ISS_CNTRY"
                            + ",OLC.OLC_LC_ADV_THRU"
                            + ",OLC.OLC_LC_CURR_CODE"
                            + ",OLC.OLC_LC_AMOUNT"
                            + ",OLC.OLC_LC_BALANCE"
                            + ",OLC.OLC_DEV_ALLWD"
                            + ",OLC.OLC_POS_DEV_ALLWD"
                            + ",OLC.OLC_NEG_DEV_ALLWD"
                            + ",OLC.OLC_DEV_AMOUNT"
                            + ",OLC.OLC_DEV_BAL"
                            + ",OLC.OLC_AMT_QUALFR"
                            + ",OLC.OLC_PRICE_TERMS"
                            + ",OLC.OLC_LAST_DATE_OF_NEG"
                            + ",OLC.OLC_PLACE_OF_EXPIRY"
                            + ",OLC.OLC_LATEST_DATE_OF_SHPMNT"
                            + ",OLC.OLC_WITHIN_VALIDATE_LC"
                            + ",OLC.OLC_LC_UI_BORNE_BY_APPLCNT"
                            + ",OLC.OLC_NOF_TENORS"
                            + ",OLC.OLC_LC_UNDER_CONTRACT"
                            + ",OLC.OLC_TOT_LIAB_LC_CURR"
                            + ",OLC.OLC_CONV_RATE_BASE_CURR"
                            + ",OLC.OLC_TOT_LIAB_BASE_CURR"
                            + ",OLC.OLC_CONV_RATE_LIM_CURR"
                            + ",OLC.OLC_TOT_LIAB_LIM_CURR"
                            + ",OLC.OLC_PAYMNT_CURR"
                            + ",OLC.OLC_TOT_CHRGS_IN_PAYMNT_CURR"
                            + ",OLC.OLC_CASH_MARGIN_BAL"
                            + ",OLC.OLC_REIMB_CHRGS_BY"
                            + ",OLC.OLC_PERC_RC_PAID_BY_APPLCNT"
                            + ",OLC.OLC_NOSTRO_ALPHA_CODE"
                            + ",OLC.OLC_ADV_THRU_BK"
                            + ",OLC.OLC_ADV_THRU_BRN"
                            + ",OLC.OLC_LC_TO_BE_CNFRMD"
                            + ",OLC.OLC_LC_TO_BE_CNFRMD_BY_BK"
                            + ",OLC.OLC_LC_TO_BE_CNFRMD_BY_BRN"
                            + ",OLC.OLC_RESTRICTED"
                            + ",OLC.OLC_RESTRICTED_TO_US"
                            + ",OLC.OLC_RESTRICTED_BK_CODE"
                            + ",OLC.OLC_RESTRICTED_BRN_CODE"
                            + ",OLC.OLC_CR_AVLBL_BY"
                            + ",OLC.OLC_IRREVOCABLE"
                            + ",OLC.OLC_PART_SHPMNT"
                            + ",OLC.OLC_TRAN_SHPMNT"
                            + ",OLC.OLC_LC_TRANSFRBL"
                            + ",OLC.OLC_DFT_REQD"
                            + ",OLC.OLC_PERC_DFT_VALUE"
                            + ",OLC.OLC_DFT_TO_BE_DRAWN_ON"
                            + ",OLC.OLC_DFT_ON_BK"
                            + ",OLC.OLC_DFT_ON_BRN"
                            + ",OLC.OLC_SPEC_TEXT1"
                            + ",OLC.OLC_SPEC_TEXT2"
                            + ",OLC.OLC_SPEC_TEXT3"
                            + ",OLC.OLC_SPEC_TEXT4"
                            + ",OLC.OLC_PRIME_RATE_CLAUSE_REQ"
                            + ",OLC.OLC_SHPMNT_MODE"
                            + ",OLC.OLC_LLOYDS_CLAUSE_REQ"
                            + ",OLC.OLC_MAX_SHIP_AGE"
                            + ",OLC.OLC_SHORT_FORM_OF_BL"
                            + ",OLC.OLC_LASH_TRANS_DOCS_ALLWD"
                            + ",OLC.OLC_PERC_OF_INS_VALUE_CVRD"
                            + ",OLC.OLC_INS_POLICY_NUM"
                            + ",OLC.OLC_INS_DATE"
                            + ",OLC.OLC_INS_CURR"
                            + ",OLC.OLC_INS_AMT"
                            + ",OLC.OLC_PREMIUM_CURR"
                            + ",OLC.OLC_PREMIUM_AMT"
                            + ",OLC.OLC_INS_COMPANY"
                            + ",OLC.OLC_INS_COMPANY_NAME"
                            + ",OLC.OLC_COO_ISS_BY"
                            + ",OLC.OLC_OTHER_COMP_AUTH"
                            + ",OLC.OLC_INTERMEDIARY_TRADE"
                            + ",OLC.OLC_INSP_TEST_CERT_REQ"
                            + ",OLC.OLC_CERT_BY"
                            + ",OLC.OLC_IMP_UNDER"
                            + ",OLC.OLC_IMP_POLICY_DET"
                            + ",OLC.OLC_IMP_REF"
                            + ",OLC.OLC_CUST_LIAB_ACC"
                            + ",OLC.OLC_CANCELLED_ON"
                            + ",OLC.OLC_USANCE_CHARGES"
                            + ",OLC.OLC_USN_CHG_TAKEN_DAYS"
                            + ",OLC.OLC_COMMITMENT_CHARGES"
                            + ",OLC.OLC_COMMIT_CHG_TAKEN_DAYS"
                            + ",OLC.TRANCHGS_CHGS_SL"
                            + ",OLC.TRANCRATES_RATE_SL"
                            + ",OLC.TRANSTLMNT_INV_NUM"
                            + ",OLC.POST_TRAN_BRN"
                            + ",OLC.POST_TRAN_DATE"
                            + ",OLC.POST_TRAN_BATCH_NUM"
                            + ",OLC.OLC_ENTD_BY"
                            + ",OLC.OLC_ENTD_ON"
                            + ",OLC.OLC_LASTMOD_BY"
                            + ",OLC.OLC_LASTMOD_ON"
                            + ",OLC.OLC_AUTH_BY"
                            + ",OLC.OLC_AUTH_ON"
                            + ",OLC.OLC_REJ_BY"
                            + ",OLC.OLC_REJ_ON"
                            + ",OLC.OLC_MARGIN_CURR"
                            + ",OLC.OLC_MARGIN_AMT"
                            + ",OLC.OLC_MARGIN_BAL"
                            + ",OLC.OLC_CASH_MAR_AMT"
                            + ",OLC.OLC_CASH_MAR_BAL"
                            + ",OLC.OLC_CASH_MAR_REC"
                            + ",OLC.OLC_DEP_MAR_REC"
                            + ",OLC.OLC_OTH_SEC_MAR_REC"
                            + ",OLC.OLC_USANCE_SERV_TAX"
                            + ",OLC.OLC_COMMIT_SERV_TAX";

    public Olc loadByKey(int _olcBrnCode, int _olcLcSl, String _olcLcType, int _olcLcYear) throws SQLException {
        Connection _conn = null;
        try {
            _conn = openConnection();
            Olc _obj = loadByKey(_olcBrnCode, _olcLcSl, _olcLcType, _olcLcYear, _conn);
            if ( _obj != null)
            {
            OldData_Key = "OLC" + TableValueSep + OldDataChar + _obj.getOlcBrnCode() + _obj.getOlcLcType() + _obj.getOlcLcYear() + _obj.getOlcLcSl();
        DataBlock_Old = _obj.getOlcBrnCode() + JNDINames.splitchar + _obj.getOlcLcType() + JNDINames.splitchar + _obj.getOlcLcYear() + JNDINames.splitchar + _obj.getOlcLcSl() + JNDINames.splitchar + _obj.getOlcCorrRefNum() + JNDINames.splitchar + _obj.getOlcLcPresancDate() + JNDINames.splitchar + _obj.getOlcLcPresancDaySl() + JNDINames.splitchar + _obj.getOlcLcDate() + JNDINames.splitchar + _obj.getOlcCustNum() + JNDINames.splitchar + _obj.getOlcBenefCode() + JNDINames.splitchar + _obj.getOlcBenefName() + JNDINames.splitchar + _obj.getOlcBenefAddr1() + JNDINames.splitchar + _obj.getOlcBenefAddr2() + JNDINames.splitchar + _obj.getOlcBenefAddr3() + JNDINames.splitchar + _obj.getOlcBenefAddr4() + JNDINames.splitchar + _obj.getOlcBenefAddr5() + JNDINames.splitchar + _obj.getOlcBenefCntryCode() + JNDINames.splitchar + _obj.getOlcLcIssBkCode() + JNDINames.splitchar + _obj.getOlcLcIssBrnCode() + JNDINames.splitchar + _obj.getOlcLcIssBrnName() + JNDINames.splitchar + _obj.getOlcLcIssBrnAdd1() + JNDINames.splitchar + _obj.getOlcLcIssBrnAdd2() + JNDINames.splitchar + _obj.getOlcLcIssBrnAdd3() + JNDINames.splitchar + _obj.getOlcLcIssBrnAdd4() + JNDINames.splitchar + _obj.getOlcLcIssBrnAdd5() + JNDINames.splitchar + _obj.getOlcLcIssPlace() + JNDINames.splitchar + _obj.getOlcLcIssCntry() + JNDINames.splitchar + _obj.getOlcLcAdvThru() + JNDINames.splitchar + _obj.getOlcLcCurrCode() + JNDINames.splitchar + _obj.getOlcLcAmount() + JNDINames.splitchar + _obj.getOlcLcBalance() + JNDINames.splitchar + _obj.getOlcDevAllwd() + JNDINames.splitchar + _obj.getOlcPosDevAllwd() + JNDINames.splitchar + _obj.getOlcNegDevAllwd() + JNDINames.splitchar + _obj.getOlcDevAmount() + JNDINames.splitchar + _obj.getOlcDevBal() + JNDINames.splitchar + _obj.getOlcAmtQualfr() + JNDINames.splitchar + _obj.getOlcPriceTerms() + JNDINames.splitchar + _obj.getOlcLastDateOfNeg() + JNDINames.splitchar + _obj.getOlcPlaceOfExpiry() + JNDINames.splitchar + _obj.getOlcLatestDateOfShpmnt() + JNDINames.splitchar + _obj.getOlcWithinValidateLc() + JNDINames.splitchar + _obj.getOlcLcUiBorneByApplcnt() + JNDINames.splitchar + _obj.getOlcNofTenors() + JNDINames.splitchar + _obj.getOlcLcUnderContract() + JNDINames.splitchar + _obj.getOlcTotLiabLcCurr() + JNDINames.splitchar + _obj.getOlcConvRateBaseCurr() + JNDINames.splitchar + _obj.getOlcTotLiabBaseCurr() + JNDINames.splitchar + _obj.getOlcConvRateLimCurr() + JNDINames.splitchar + _obj.getOlcTotLiabLimCurr() + JNDINames.splitchar + _obj.getOlcPaymntCurr() + JNDINames.splitchar + _obj.getOlcTotChrgsInPaymntCurr() + JNDINames.splitchar + _obj.getOlcCashMarginBal() + JNDINames.splitchar + _obj.getOlcReimbChrgsBy() + JNDINames.splitchar + _obj.getOlcPercRcPaidByApplcnt() + JNDINames.splitchar + _obj.getOlcNostroAlphaCode() + JNDINames.splitchar + _obj.getOlcAdvThruBk() + JNDINames.splitchar + _obj.getOlcAdvThruBrn() + JNDINames.splitchar + _obj.getOlcLcToBeCnfrmd() + JNDINames.splitchar + _obj.getOlcLcToBeCnfrmdByBk() + JNDINames.splitchar + _obj.getOlcLcToBeCnfrmdByBrn() + JNDINames.splitchar + _obj.getOlcRestricted() + JNDINames.splitchar + _obj.getOlcRestrictedToUs() + JNDINames.splitchar + _obj.getOlcRestrictedBkCode() + JNDINames.splitchar + _obj.getOlcRestrictedBrnCode() + JNDINames.splitchar + _obj.getOlcCrAvlblBy() + JNDINames.splitchar + _obj.getOlcIrrevocable() + JNDINames.splitchar + _obj.getOlcPartShpmnt() + JNDINames.splitchar + _obj.getOlcTranShpmnt() + JNDINames.splitchar + _obj.getOlcLcTransfrbl() + JNDINames.splitchar + _obj.getOlcDftReqd() + JNDINames.splitchar + _obj.getOlcPercDftValue() + JNDINames.splitchar + _obj.getOlcDftToBeDrawnOn() + JNDINames.splitchar + _obj.getOlcDftOnBk() + JNDINames.splitchar + _obj.getOlcDftOnBrn() + JNDINames.splitchar + _obj.getOlcSpecText1() + JNDINames.splitchar + _obj.getOlcSpecText2() + JNDINames.splitchar + _obj.getOlcSpecText3() + JNDINames.splitchar + _obj.getOlcSpecText4() + JNDINames.splitchar + _obj.getOlcPrimeRateClauseReq() + JNDINames.splitchar + _obj.getOlcShpmntMode() + JNDINames.splitchar + _obj.getOlcLloydsClauseReq() + JNDINames.splitchar + _obj.getOlcMaxShipAge() + JNDINames.splitchar + _obj.getOlcShortFormOfBl() + JNDINames.splitchar + _obj.getOlcLashTransDocsAllwd() + JNDINames.splitchar + _obj.getOlcPercOfInsValueCvrd() + JNDINames.splitchar + _obj.getOlcInsPolicyNum() + JNDINames.splitchar + _obj.getOlcInsDate() + JNDINames.splitchar + _obj.getOlcInsCurr() + JNDINames.splitchar + _obj.getOlcInsAmt() + JNDINames.splitchar + _obj.getOlcPremiumCurr() + JNDINames.splitchar + _obj.getOlcPremiumAmt() + JNDINames.splitchar + _obj.getOlcInsCompany() + JNDINames.splitchar + _obj.getOlcInsCompanyName() + JNDINames.splitchar + _obj.getOlcCooIssBy() + JNDINames.splitchar + _obj.getOlcOtherCompAuth() + JNDINames.splitchar + _obj.getOlcIntermediaryTrade() + JNDINames.splitchar + _obj.getOlcInspTestCertReq() + JNDINames.splitchar + _obj.getOlcCertBy() + JNDINames.splitchar + _obj.getOlcImpUnder() + JNDINames.splitchar + _obj.getOlcImpPolicyDet() + JNDINames.splitchar + _obj.getOlcImpRef() + JNDINames.splitchar + _obj.getOlcCustLiabAcc() + JNDINames.splitchar + _obj.getOlcCancelledOn() + JNDINames.splitchar + _obj.getOlcUsanceCharges() + JNDINames.splitchar + _obj.getOlcUsnChgTakenDays() + JNDINames.splitchar + _obj.getOlcCommitmentCharges() + JNDINames.splitchar + _obj.getOlcCommitChgTakenDays() + JNDINames.splitchar + _obj.getTranchgsChgsSl() + JNDINames.splitchar + _obj.getTrancratesRateSl() + JNDINames.splitchar + _obj.getTranstlmntInvNum() + JNDINames.splitchar + _obj.getPostTranBrn() + JNDINames.splitchar + _obj.getPostTranDate() + JNDINames.splitchar + _obj.getPostTranBatchNum() + JNDINames.splitchar + _obj.getOlcEntdBy() + JNDINames.splitchar + _obj.getOlcEntdOn() + JNDINames.splitchar + _obj.getOlcLastmodBy() + JNDINames.splitchar + _obj.getOlcLastmodOn() + JNDINames.splitchar + _obj.getOlcAuthBy() + JNDINames.splitchar + _obj.getOlcAuthOn() + JNDINames.splitchar + _obj.getOlcRejBy() + JNDINames.splitchar + _obj.getOlcRejOn() + JNDINames.splitchar + _obj.getOlcMarginCurr() + JNDINames.splitchar + _obj.getOlcMarginAmt() + JNDINames.splitchar + _obj.getOlcMarginBal() + JNDINames.splitchar + _obj.getOlcCashMarAmt() + JNDINames.splitchar + _obj.getOlcCashMarBal() + JNDINames.splitchar + _obj.getOlcCashMarRec() + JNDINames.splitchar + _obj.getOlcDepMarRec() + JNDINames.splitchar + _obj.getOlcOthSecMarRec() + JNDINames.splitchar + _obj.getOlcUsanceServTax() + JNDINames.splitchar + _obj.getOlcCommitServTax();
        }
            closeConnection(_conn);
            return _obj;
        }
        catch(SQLException e) {
            if(_conn != null)  try { closeConnection(_conn); } catch(SQLException e2) { }
            throw e;
        }
    }

    public Olc loadByKey(int _olcBrnCode, int _olcLcSl, String _olcLcType, int _olcLcYear, Connection _conn) throws SQLException {
        PreparedStatement _pstmt = null;
        try {
            _pstmt = _conn.prepareStatement("SELECT " + ALL_FIELDS + " FROM OLC WHERE OLC.OLC_BRN_CODE=? and OLC.OLC_LC_SL=? and OLC.OLC_LC_TYPE=? and OLC.OLC_LC_YEAR=?");
            _pstmt.setInt(1, _olcBrnCode);
            _pstmt.setInt(2, _olcLcSl);
            _pstmt.setString(3, _olcLcType);
            _pstmt.setInt(4, _olcLcYear);
            Olc _list[] = loadByPreparedStatement(_pstmt);
            _pstmt.close();
            if(_list.length < 1) return null;
            else                 return _list[0];
        }
        catch(SQLException e) {
            if(_pstmt != null) try { _pstmt.close(); } catch(SQLException e2) { }
            throw e;
        }
    }

    public Olc[] loadAll() throws SQLException {
        Connection _conn = null;
        try {
            _conn = openConnection();
            Olc _list[] = loadAll(_conn);
            closeConnection(_conn);
            return _list;
        }
        catch(SQLException e) {
            if(_conn != null)  try { closeConnection(_conn); } catch(SQLException e2) { }
            throw e;
        }
    }

    public Olc[] loadAll(Connection _conn) throws SQLException {
        PreparedStatement _pstmt = null;
        try {
            _pstmt = _conn.prepareStatement("SELECT " + ALL_FIELDS + " FROM OLC");
            Olc _list[] = loadByPreparedStatement(_pstmt);
            _pstmt.close();
            return _list;
        }
        catch(SQLException e) {
            if(_pstmt != null) try { _pstmt.close(); } catch(SQLException e2) { }
            throw e;
        }
    }

    public Olc[] loadByPreparedStatement(PreparedStatement pstmt) throws SQLException {
        return loadByPreparedStatement(pstmt, null, 0);
    }

    public Olc[] loadByPreparedStatement(PreparedStatement pstmt, int maxRows) throws SQLException {
        return loadByPreparedStatement(pstmt, null, maxRows);
    }

    public Olc[] loadByPreparedStatement(PreparedStatement pstmt, int[] fieldList) throws SQLException {
        return loadByPreparedStatement(pstmt, fieldList, 0);
    }

    public Olc[] loadByPreparedStatement(PreparedStatement pstmt, int[] fieldList, int maxRows) throws SQLException {
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            java.util.Vector v = new java.util.Vector();
            while(rs.next() && (maxRows == 0 || v.size() < maxRows)) {
                if(fieldList == null) v.addElement(decodeRow(rs));
                else v.addElement(decodeRow(rs, fieldList));
            }
            rs.close();
            Olc list[] = new Olc[v.size()];
            v.copyInto(list);
            return list;
        }
        catch(SQLException e) {
            if(rs!=null) try { rs.close();} catch(Exception e2) {}
            throw e;
        }
    }

    public Olc[] loadByWhere(String where) throws SQLException {
        return loadByWhere(where, (int[])null, 0);
    }
    public Olc[] loadByWhere(String where, int maxRows) throws SQLException {
        return loadByWhere(where, (int[])null, maxRows);
    }
    public Olc[] loadByWhere(String where, int[] fieldList) throws SQLException {
        return loadByWhere(where, fieldList, 0);
    }
    public Olc[] loadByWhere(String where, int[] fieldList, int maxRows) throws SQLException {
        Connection conn = null;
        try {
            conn = openConnection();
            Olc _list[] = loadByWhere(where, conn, fieldList, maxRows);
            closeConnection(conn);
            return _list;
        }
        catch(SQLException e) {
            if(conn!=null) try { closeConnection(conn);} catch(Exception e2) {}
            throw e;
        }
    }

    public Olc[] loadByWhere(String where, Connection conn) throws SQLException {
        return loadByWhere(where, conn, null, 0);
    }

    public Olc[] loadByWhere(String where, Connection conn, int[] fieldList) throws SQLException {
        return loadByWhere(where, conn, fieldList, 0);
    }

    public Olc[] loadByWhere(String where, Connection conn, int[] fieldList, int maxRows) throws SQLException {
        String sql = null;
        if(fieldList == null) sql = "select " + ALL_FIELDS + " from OLC " + where;
        else {
            StringBuffer buff = new StringBuffer(128);
            buff.append("select ");
            for(int i = 0; i < fieldList.length; i++) {
                if(i != 0) buff.append(",");
                buff.append(S2J_FIELD_NAMES[fieldList[i]]);
            }
            buff.append(" from OLC ");
            buff.append(where);
            sql = buff.toString();
        }
        Statement stmt = null;
        ResultSet rs = null;
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            java.util.Vector v = new java.util.Vector();
            while(rs.next() && (maxRows == 0 || v.size() < maxRows)) {
                if(fieldList == null) v.addElement(decodeRow(rs));
                else v.addElement(decodeRow(rs, fieldList));
            }
            rs.close();
            stmt.close();

            Olc _list[] = new Olc[v.size()];
            v.copyInto(_list);
            return _list;
        }
        catch(SQLException e) {
            if(rs!=null) try { rs.close();} catch(Exception e2) {}
            if(stmt!=null) try { stmt.close();} catch(Exception e2) {}
            throw e;
        }
    }

    public long GetMaxSl(int _olcBrnCode, String _olcLcType, int _olcLcYear) throws SQLException {
        ResultSet rs = null;
        long maxsl = 0;
        Connection _conn = null;
        PreparedStatement _pstmt = null;
            try {
                _conn = openConnection();
                StringBuffer _sql = new StringBuffer("SELECT NVL(MAX(OLC_LC_SL),0) + 1 AS MAXSL FROM OLC WHERE OLC.OLC_BRN_CODE=? and OLC.OLC_LC_TYPE=? and OLC.OLC_LC_YEAR=?");
                _pstmt = _conn.prepareStatement(_sql.toString());
            _pstmt.setInt(1, _olcBrnCode);
            _pstmt.setString(2, _olcLcType);
            _pstmt.setInt(3, _olcLcYear);
                 rs = _pstmt.executeQuery();
                 if (rs.next())
                {
                maxsl = rs.getLong(1);
                }
                rs.close();
                }
                catch(SQLException e) {
                if(rs!=null) try { rs.close();} catch(Exception e2) {}
                throw e;
            }
            return maxsl;
        }
    public int UpdateByQuery(String w_sql) throws SQLException {
        Connection _conn = null;
        PreparedStatement _pstmt = null;
            try {
                _conn = openConnection();
                _pstmt = _conn.prepareStatement(w_sql);
                int _rows = _pstmt.executeUpdate();
                closeConnection(_conn);
                return 1;
            }
            catch(SQLException e) {
                if(_pstmt!=null) try { _pstmt.close();} catch(Exception e2) {}
                if(_conn!=null) try { closeConnection(_conn);} catch(Exception e2) {}
                throw e;
            }
    }
    public int deleteByKey(int _olcBrnCode, int _olcLcSl, String _olcLcType, int _olcLcYear) throws SQLException {
        Connection _conn = null;
        try {
            _conn = openConnection();
            int _rows = deleteByKey(_olcBrnCode, _olcLcSl, _olcLcType, _olcLcYear, _conn);
            closeConnection(_conn);
            return _rows;
        }
        catch(SQLException e) {
            if(_conn!=null) try { closeConnection(_conn);} catch(Exception e2) {}
            throw e;
        }
    }

    public int deleteByKey(int _olcBrnCode, int _olcLcSl, String _olcLcType, int _olcLcYear, Connection _conn) throws SQLException {
        PreparedStatement _pstmt = null;
        try {
        Olc _obj  = loadByKey(_olcBrnCode, _olcLcSl, _olcLcType, _olcLcYear);
        _obj  = null;
            _pstmt = _conn.prepareStatement("DELETE from OLC WHERE OLC.OLC_BRN_CODE=? and OLC.OLC_LC_SL=? and OLC.OLC_LC_TYPE=? and OLC.OLC_LC_YEAR=?");
            _pstmt.setInt(1, _olcBrnCode);
            _pstmt.setInt(2, _olcLcSl);
            _pstmt.setString(3, _olcLcType);
            _pstmt.setInt(4, _olcLcYear);
            int _rows = _pstmt.executeUpdate();
            _pstmt.close();
            return _rows;
        }
        catch(SQLException e) {
            if(_pstmt!=null) try { _pstmt.close();} catch(Exception e2) {}
            throw e;
        }
    }

    public void save(Olc obj) throws SQLException {
        if(!obj.isModifiedS2J()) return;
        Connection _conn = null;
        try {
            _conn = openConnection();
            save(obj, _conn);
            closeConnection(_conn);
        }
        catch(SQLException e) {
            if(_conn!=null) try { closeConnection(_conn);} catch(Exception e2) {}
            throw e;
        }
    }

    public void save(Olc obj, Connection _conn) throws SQLException {
        PreparedStatement _pstmt = null;
        try {
            if(obj.isNew()) {
                int _dirtyCount = 0;
                StringBuffer _sql = new StringBuffer("INSERT into OLC (");
                if(obj.olcBrnCodeIsModifiedS2j()) {  _sql.append("OLC_BRN_CODE").append(","); _dirtyCount++; }
                if(obj.olcLcTypeIsModifiedS2j()) {  _sql.append("OLC_LC_TYPE").append(","); _dirtyCount++; }
                if(obj.olcLcYearIsModifiedS2j()) {  _sql.append("OLC_LC_YEAR").append(","); _dirtyCount++; }
                if(obj.olcLcSlIsModifiedS2j()) {  _sql.append("OLC_LC_SL").append(","); _dirtyCount++; }
                if(obj.olcCorrRefNumIsModifiedS2j()) {  _sql.append("OLC_CORR_REF_NUM").append(","); _dirtyCount++; }
                if(obj.olcLcPresancDateIsModifiedS2j()) {  _sql.append("OLC_LC_PRESANC_DATE").append(","); _dirtyCount++; }
                if(obj.olcLcPresancDaySlIsModifiedS2j()) {  _sql.append("OLC_LC_PRESANC_DAY_SL").append(","); _dirtyCount++; }
                if(obj.olcLcDateIsModifiedS2j()) {  _sql.append("OLC_LC_DATE").append(","); _dirtyCount++; }
                if(obj.olcCustNumIsModifiedS2j()) {  _sql.append("OLC_CUST_NUM").append(","); _dirtyCount++; }
                if(obj.olcBenefCodeIsModifiedS2j()) {  _sql.append("OLC_BENEF_CODE").append(","); _dirtyCount++; }
                if(obj.olcBenefNameIsModifiedS2j()) {  _sql.append("OLC_BENEF_NAME").append(","); _dirtyCount++; }
                if(obj.olcBenefAddr1IsModifiedS2j()) {  _sql.append("OLC_BENEF_ADDR1").append(","); _dirtyCount++; }
                if(obj.olcBenefAddr2IsModifiedS2j()) {  _sql.append("OLC_BENEF_ADDR2").append(","); _dirtyCount++; }
                if(obj.olcBenefAddr3IsModifiedS2j()) {  _sql.append("OLC_BENEF_ADDR3").append(","); _dirtyCount++; }
                if(obj.olcBenefAddr4IsModifiedS2j()) {  _sql.append("OLC_BENEF_ADDR4").append(","); _dirtyCount++; }
                if(obj.olcBenefAddr5IsModifiedS2j()) {  _sql.append("OLC_BENEF_ADDR5").append(","); _dirtyCount++; }
                if(obj.olcBenefCntryCodeIsModifiedS2j()) {  _sql.append("OLC_BENEF_CNTRY_CODE").append(","); _dirtyCount++; }
                if(obj.olcLcIssBkCodeIsModifiedS2j()) {  _sql.append("OLC_LC_ISS_BK_CODE").append(","); _dirtyCount++; }
                if(obj.olcLcIssBrnCodeIsModifiedS2j()) {  _sql.append("OLC_LC_ISS_BRN_CODE").append(","); _dirtyCount++; }
                if(obj.olcLcIssBrnNameIsModifiedS2j()) {  _sql.append("OLC_LC_ISS_BRN_NAME").append(","); _dirtyCount++; }
                if(obj.olcLcIssBrnAdd1IsModifiedS2j()) {  _sql.append("OLC_LC_ISS_BRN_ADD1").append(","); _dirtyCount++; }
                if(obj.olcLcIssBrnAdd2IsModifiedS2j()) {  _sql.append("OLC_LC_ISS_BRN_ADD2").append(","); _dirtyCount++; }
                if(obj.olcLcIssBrnAdd3IsModifiedS2j()) {  _sql.append("OLC_LC_ISS_BRN_ADD3").append(","); _dirtyCount++; }
                if(obj.olcLcIssBrnAdd4IsModifiedS2j()) {  _sql.append("OLC_LC_ISS_BRN_ADD4").append(","); _dirtyCount++; }
                if(obj.olcLcIssBrnAdd5IsModifiedS2j()) {  _sql.append("OLC_LC_ISS_BRN_ADD5").append(","); _dirtyCount++; }
                if(obj.olcLcIssPlaceIsModifiedS2j()) {  _sql.append("OLC_LC_ISS_PLACE").append(","); _dirtyCount++; }
                if(obj.olcLcIssCntryIsModifiedS2j()) {  _sql.append("OLC_LC_ISS_CNTRY").append(","); _dirtyCount++; }
                if(obj.olcLcAdvThruIsModifiedS2j()) {  _sql.append("OLC_LC_ADV_THRU").append(","); _dirtyCount++; }
                if(obj.olcLcCurrCodeIsModifiedS2j()) {  _sql.append("OLC_LC_CURR_CODE").append(","); _dirtyCount++; }
                if(obj.olcLcAmountIsModifiedS2j()) {  _sql.append("OLC_LC_AMOUNT").append(","); _dirtyCount++; }
                if(obj.olcLcBalanceIsModifiedS2j()) {  _sql.append("OLC_LC_BALANCE").append(","); _dirtyCount++; }
                if(obj.olcDevAllwdIsModifiedS2j()) {  _sql.append("OLC_DEV_ALLWD").append(","); _dirtyCount++; }
                if(obj.olcPosDevAllwdIsModifiedS2j()) {  _sql.append("OLC_POS_DEV_ALLWD").append(","); _dirtyCount++; }
                if(obj.olcNegDevAllwdIsModifiedS2j()) {  _sql.append("OLC_NEG_DEV_ALLWD").append(","); _dirtyCount++; }
                if(obj.olcDevAmountIsModifiedS2j()) {  _sql.append("OLC_DEV_AMOUNT").append(","); _dirtyCount++; }
                if(obj.olcDevBalIsModifiedS2j()) {  _sql.append("OLC_DEV_BAL").append(","); _dirtyCount++; }
                if(obj.olcAmtQualfrIsModifiedS2j()) {  _sql.append("OLC_AMT_QUALFR").append(","); _dirtyCount++; }
                if(obj.olcPriceTermsIsModifiedS2j()) {  _sql.append("OLC_PRICE_TERMS").append(","); _dirtyCount++; }
                if(obj.olcLastDateOfNegIsModifiedS2j()) {  _sql.append("OLC_LAST_DATE_OF_NEG").append(","); _dirtyCount++; }
                if(obj.olcPlaceOfExpiryIsModifiedS2j()) {  _sql.append("OLC_PLACE_OF_EXPIRY").append(","); _dirtyCount++; }
                if(obj.olcLatestDateOfShpmntIsModifiedS2j()) {  _sql.append("OLC_LATEST_DATE_OF_SHPMNT").append(","); _dirtyCount++; }
                if(obj.olcWithinValidateLcIsModifiedS2j()) {  _sql.append("OLC_WITHIN_VALIDATE_LC").append(","); _dirtyCount++; }
                if(obj.olcLcUiBorneByApplcntIsModifiedS2j()) {  _sql.append("OLC_LC_UI_BORNE_BY_APPLCNT").append(","); _dirtyCount++; }
                if(obj.olcNofTenorsIsModifiedS2j()) {  _sql.append("OLC_NOF_TENORS").append(","); _dirtyCount++; }
                if(obj.olcLcUnderContractIsModifiedS2j()) {  _sql.append("OLC_LC_UNDER_CONTRACT").append(","); _dirtyCount++; }
                if(obj.olcTotLiabLcCurrIsModifiedS2j()) {  _sql.append("OLC_TOT_LIAB_LC_CURR").append(","); _dirtyCount++; }
                if(obj.olcConvRateBaseCurrIsModifiedS2j()) {  _sql.append("OLC_CONV_RATE_BASE_CURR").append(","); _dirtyCount++; }
                if(obj.olcTotLiabBaseCurrIsModifiedS2j()) {  _sql.append("OLC_TOT_LIAB_BASE_CURR").append(","); _dirtyCount++; }
                if(obj.olcConvRateLimCurrIsModifiedS2j()) {  _sql.append("OLC_CONV_RATE_LIM_CURR").append(","); _dirtyCount++; }
                if(obj.olcTotLiabLimCurrIsModifiedS2j()) {  _sql.append("OLC_TOT_LIAB_LIM_CURR").append(","); _dirtyCount++; }
                if(obj.olcPaymntCurrIsModifiedS2j()) {  _sql.append("OLC_PAYMNT_CURR").append(","); _dirtyCount++; }
                if(obj.olcTotChrgsInPaymntCurrIsModifiedS2j()) {  _sql.append("OLC_TOT_CHRGS_IN_PAYMNT_CURR").append(","); _dirtyCount++; }
                if(obj.olcCashMarginBalIsModifiedS2j()) {  _sql.append("OLC_CASH_MARGIN_BAL").append(","); _dirtyCount++; }
                if(obj.olcReimbChrgsByIsModifiedS2j()) {  _sql.append("OLC_REIMB_CHRGS_BY").append(","); _dirtyCount++; }
                if(obj.olcPercRcPaidByApplcntIsModifiedS2j()) {  _sql.append("OLC_PERC_RC_PAID_BY_APPLCNT").append(","); _dirtyCount++; }
                if(obj.olcNostroAlphaCodeIsModifiedS2j()) {  _sql.append("OLC_NOSTRO_ALPHA_CODE").append(","); _dirtyCount++; }
                if(obj.olcAdvThruBkIsModifiedS2j()) {  _sql.append("OLC_ADV_THRU_BK").append(","); _dirtyCount++; }
                if(obj.olcAdvThruBrnIsModifiedS2j()) {  _sql.append("OLC_ADV_THRU_BRN").append(","); _dirtyCount++; }
                if(obj.olcLcToBeCnfrmdIsModifiedS2j()) {  _sql.append("OLC_LC_TO_BE_CNFRMD").append(","); _dirtyCount++; }
                if(obj.olcLcToBeCnfrmdByBkIsModifiedS2j()) {  _sql.append("OLC_LC_TO_BE_CNFRMD_BY_BK").append(","); _dirtyCount++; }
                if(obj.olcLcToBeCnfrmdByBrnIsModifiedS2j()) {  _sql.append("OLC_LC_TO_BE_CNFRMD_BY_BRN").append(","); _dirtyCount++; }
                if(obj.olcRestrictedIsModifiedS2j()) {  _sql.append("OLC_RESTRICTED").append(","); _dirtyCount++; }
                if(obj.olcRestrictedToUsIsModifiedS2j()) {  _sql.append("OLC_RESTRICTED_TO_US").append(","); _dirtyCount++; }
                if(obj.olcRestrictedBkCodeIsModifiedS2j()) {  _sql.append("OLC_RESTRICTED_BK_CODE").append(","); _dirtyCount++; }
                if(obj.olcRestrictedBrnCodeIsModifiedS2j()) {  _sql.append("OLC_RESTRICTED_BRN_CODE").append(","); _dirtyCount++; }
                if(obj.olcCrAvlblByIsModifiedS2j()) {  _sql.append("OLC_CR_AVLBL_BY").append(","); _dirtyCount++; }
                if(obj.olcIrrevocableIsModifiedS2j()) {  _sql.append("OLC_IRREVOCABLE").append(","); _dirtyCount++; }
                if(obj.olcPartShpmntIsModifiedS2j()) {  _sql.append("OLC_PART_SHPMNT").append(","); _dirtyCount++; }
                if(obj.olcTranShpmntIsModifiedS2j()) {  _sql.append("OLC_TRAN_SHPMNT").append(","); _dirtyCount++; }
                if(obj.olcLcTransfrblIsModifiedS2j()) {  _sql.append("OLC_LC_TRANSFRBL").append(","); _dirtyCount++; }
                if(obj.olcDftReqdIsModifiedS2j()) {  _sql.append("OLC_DFT_REQD").append(","); _dirtyCount++; }
                if(obj.olcPercDftValueIsModifiedS2j()) {  _sql.append("OLC_PERC_DFT_VALUE").append(","); _dirtyCount++; }
                if(obj.olcDftToBeDrawnOnIsModifiedS2j()) {  _sql.append("OLC_DFT_TO_BE_DRAWN_ON").append(","); _dirtyCount++; }
                if(obj.olcDftOnBkIsModifiedS2j()) {  _sql.append("OLC_DFT_ON_BK").append(","); _dirtyCount++; }
                if(obj.olcDftOnBrnIsModifiedS2j()) {  _sql.append("OLC_DFT_ON_BRN").append(","); _dirtyCount++; }
                if(obj.olcSpecText1IsModifiedS2j()) {  _sql.append("OLC_SPEC_TEXT1").append(","); _dirtyCount++; }
                if(obj.olcSpecText2IsModifiedS2j()) {  _sql.append("OLC_SPEC_TEXT2").append(","); _dirtyCount++; }
                if(obj.olcSpecText3IsModifiedS2j()) {  _sql.append("OLC_SPEC_TEXT3").append(","); _dirtyCount++; }
                if(obj.olcSpecText4IsModifiedS2j()) {  _sql.append("OLC_SPEC_TEXT4").append(","); _dirtyCount++; }
                if(obj.olcPrimeRateClauseReqIsModifiedS2j()) {  _sql.append("OLC_PRIME_RATE_CLAUSE_REQ").append(","); _dirtyCount++; }
                if(obj.olcShpmntModeIsModifiedS2j()) {  _sql.append("OLC_SHPMNT_MODE").append(","); _dirtyCount++; }
                if(obj.olcLloydsClauseReqIsModifiedS2j()) {  _sql.append("OLC_LLOYDS_CLAUSE_REQ").append(","); _dirtyCount++; }
                if(obj.olcMaxShipAgeIsModifiedS2j()) {  _sql.append("OLC_MAX_SHIP_AGE").append(","); _dirtyCount++; }
                if(obj.olcShortFormOfBlIsModifiedS2j()) {  _sql.append("OLC_SHORT_FORM_OF_BL").append(","); _dirtyCount++; }
                if(obj.olcLashTransDocsAllwdIsModifiedS2j()) {  _sql.append("OLC_LASH_TRANS_DOCS_ALLWD").append(","); _dirtyCount++; }
                if(obj.olcPercOfInsValueCvrdIsModifiedS2j()) {  _sql.append("OLC_PERC_OF_INS_VALUE_CVRD").append(","); _dirtyCount++; }
                if(obj.olcInsPolicyNumIsModifiedS2j()) {  _sql.append("OLC_INS_POLICY_NUM").append(","); _dirtyCount++; }
                if(obj.olcInsDateIsModifiedS2j()) {  _sql.append("OLC_INS_DATE").append(","); _dirtyCount++; }
                if(obj.olcInsCurrIsModifiedS2j()) {  _sql.append("OLC_INS_CURR").append(","); _dirtyCount++; }
                if(obj.olcInsAmtIsModifiedS2j()) {  _sql.append("OLC_INS_AMT").append(","); _dirtyCount++; }
                if(obj.olcPremiumCurrIsModifiedS2j()) {  _sql.append("OLC_PREMIUM_CURR").append(","); _dirtyCount++; }
                if(obj.olcPremiumAmtIsModifiedS2j()) {  _sql.append("OLC_PREMIUM_AMT").append(","); _dirtyCount++; }
                if(obj.olcInsCompanyIsModifiedS2j()) {  _sql.append("OLC_INS_COMPANY").append(","); _dirtyCount++; }
                if(obj.olcInsCompanyNameIsModifiedS2j()) {  _sql.append("OLC_INS_COMPANY_NAME").append(","); _dirtyCount++; }
                if(obj.olcCooIssByIsModifiedS2j()) {  _sql.append("OLC_COO_ISS_BY").append(","); _dirtyCount++; }
                if(obj.olcOtherCompAuthIsModifiedS2j()) {  _sql.append("OLC_OTHER_COMP_AUTH").append(","); _dirtyCount++; }
                if(obj.olcIntermediaryTradeIsModifiedS2j()) {  _sql.append("OLC_INTERMEDIARY_TRADE").append(","); _dirtyCount++; }
                if(obj.olcInspTestCertReqIsModifiedS2j()) {  _sql.append("OLC_INSP_TEST_CERT_REQ").append(","); _dirtyCount++; }
                if(obj.olcCertByIsModifiedS2j()) {  _sql.append("OLC_CERT_BY").append(","); _dirtyCount++; }
                if(obj.olcImpUnderIsModifiedS2j()) {  _sql.append("OLC_IMP_UNDER").append(","); _dirtyCount++; }
                if(obj.olcImpPolicyDetIsModifiedS2j()) {  _sql.append("OLC_IMP_POLICY_DET").append(","); _dirtyCount++; }
                if(obj.olcImpRefIsModifiedS2j()) {  _sql.append("OLC_IMP_REF").append(","); _dirtyCount++; }
                if(obj.olcCustLiabAccIsModifiedS2j()) {  _sql.append("OLC_CUST_LIAB_ACC").append(","); _dirtyCount++; }
                if(obj.olcCancelledOnIsModifiedS2j()) {  _sql.append("OLC_CANCELLED_ON").append(","); _dirtyCount++; }
                if(obj.olcUsanceChargesIsModifiedS2j()) {  _sql.append("OLC_USANCE_CHARGES").append(","); _dirtyCount++; }
                if(obj.olcUsnChgTakenDaysIsModifiedS2j()) {  _sql.append("OLC_USN_CHG_TAKEN_DAYS").append(","); _dirtyCount++; }
                if(obj.olcCommitmentChargesIsModifiedS2j()) {  _sql.append("OLC_COMMITMENT_CHARGES").append(","); _dirtyCount++; }
                if(obj.olcCommitChgTakenDaysIsModifiedS2j()) {  _sql.append("OLC_COMMIT_CHG_TAKEN_DAYS").append(","); _dirtyCount++; }
                if(obj.tranchgsChgsSlIsModifiedS2j()) {  _sql.append("TRANCHGS_CHGS_SL").append(","); _dirtyCount++; }
                if(obj.trancratesRateSlIsModifiedS2j()) {  _sql.append("TRANCRATES_RATE_SL").append(","); _dirtyCount++; }
                if(obj.transtlmntInvNumIsModifiedS2j()) {  _sql.append("TRANSTLMNT_INV_NUM").append(","); _dirtyCount++; }
                if(obj.postTranBrnIsModifiedS2j()) {  _sql.append("POST_TRAN_BRN").append(","); _dirtyCount++; }
                if(obj.postTranDateIsModifiedS2j()) {  _sql.append("POST_TRAN_DATE").append(","); _dirtyCount++; }
                if(obj.postTranBatchNumIsModifiedS2j()) {  _sql.append("POST_TRAN_BATCH_NUM").append(","); _dirtyCount++; }
                if(obj.olcEntdByIsModifiedS2j()) {  _sql.append("OLC_ENTD_BY").append(","); _dirtyCount++; }
                if(obj.olcEntdOnIsModifiedS2j()) {  _sql.append("OLC_ENTD_ON").append(","); _dirtyCount++; }
                if(obj.olcLastmodByIsModifiedS2j()) {  _sql.append("OLC_LASTMOD_BY").append(","); _dirtyCount++; }
                if(obj.olcLastmodOnIsModifiedS2j()) {  _sql.append("OLC_LASTMOD_ON").append(","); _dirtyCount++; }
                if(obj.olcAuthByIsModifiedS2j()) {  _sql.append("OLC_AUTH_BY").append(","); _dirtyCount++; }
                if(obj.olcAuthOnIsModifiedS2j()) {  _sql.append("OLC_AUTH_ON").append(","); _dirtyCount++; }
                if(obj.olcRejByIsModifiedS2j()) {  _sql.append("OLC_REJ_BY").append(","); _dirtyCount++; }
                if(obj.olcRejOnIsModifiedS2j()) {  _sql.append("OLC_REJ_ON").append(","); _dirtyCount++; }
                if(obj.olcMarginCurrIsModifiedS2j()) {  _sql.append("OLC_MARGIN_CURR").append(","); _dirtyCount++; }
                if(obj.olcMarginAmtIsModifiedS2j()) {  _sql.append("OLC_MARGIN_AMT").append(","); _dirtyCount++; }
                if(obj.olcMarginBalIsModifiedS2j()) {  _sql.append("OLC_MARGIN_BAL").append(","); _dirtyCount++; }
                if(obj.olcCashMarAmtIsModifiedS2j()) {  _sql.append("OLC_CASH_MAR_AMT").append(","); _dirtyCount++; }
                if(obj.olcCashMarBalIsModifiedS2j()) {  _sql.append("OLC_CASH_MAR_BAL").append(","); _dirtyCount++; }
                if(obj.olcCashMarRecIsModifiedS2j()) {  _sql.append("OLC_CASH_MAR_REC").append(","); _dirtyCount++; }
                if(obj.olcDepMarRecIsModifiedS2j()) {  _sql.append("OLC_DEP_MAR_REC").append(","); _dirtyCount++; }
                if(obj.olcOthSecMarRecIsModifiedS2j()) {  _sql.append("OLC_OTH_SEC_MAR_REC").append(","); _dirtyCount++; }
                if(obj.olcUsanceServTaxIsModifiedS2j()) {  _sql.append("OLC_USANCE_SERV_TAX").append(","); _dirtyCount++; }
                if(obj.olcCommitServTaxIsModifiedS2j()) {  _sql.append("OLC_COMMIT_SERV_TAX").append(","); _dirtyCount++; }
                _sql.setLength(_sql.length() - 1);
                _sql.append(") values (");
                for(int i = 0; i < _dirtyCount; i++) _sql.append("?,");
                _sql.setLength(_sql.length() - 1);
                _sql.append(")");

                _pstmt = _conn.prepareStatement(_sql.toString());
                _dirtyCount = 0;
                if(obj.olcBrnCodeIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcBrnCode()); } 
                if(obj.olcLcTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcLcType()); } 
                if(obj.olcLcYearIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcLcYear()); } 
                if(obj.olcLcSlIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcLcSl()); } 
                if(obj.olcCorrRefNumIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcCorrRefNum()); } 
                if(obj.olcLcPresancDateIsModifiedS2j()) { if (obj.getOlcLcPresancDate() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcLcPresancDate().getTime()));} } 
                if(obj.olcLcPresancDaySlIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcLcPresancDaySl()); } 
                if(obj.olcLcDateIsModifiedS2j()) { if (obj.getOlcLcDate() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcLcDate().getTime()));} } 
                if(obj.olcCustNumIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcCustNum()); } 
                if(obj.olcBenefCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcBenefCode()); } 
                if(obj.olcBenefNameIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcBenefName()); } 
                if(obj.olcBenefAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcBenefAddr1()); } 
                if(obj.olcBenefAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcBenefAddr2()); } 
                if(obj.olcBenefAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcBenefAddr3()); } 
                if(obj.olcBenefAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcBenefAddr4()); } 
                if(obj.olcBenefAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcBenefAddr5()); } 
                if(obj.olcBenefCntryCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcBenefCntryCode()); } 
                if(obj.olcLcIssBkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcLcIssBkCode()); } 
                if(obj.olcLcIssBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcLcIssBrnCode()); } 
                if(obj.olcLcIssBrnNameIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcLcIssBrnName()); } 
                if(obj.olcLcIssBrnAdd1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcLcIssBrnAdd1()); } 
                if(obj.olcLcIssBrnAdd2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcLcIssBrnAdd2()); } 
                if(obj.olcLcIssBrnAdd3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcLcIssBrnAdd3()); } 
                if(obj.olcLcIssBrnAdd4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcLcIssBrnAdd4()); } 
                if(obj.olcLcIssBrnAdd5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcLcIssBrnAdd5()); } 
                if(obj.olcLcIssPlaceIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcLcIssPlace()); } 
                if(obj.olcLcIssCntryIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcLcIssCntry()); } 
                if(obj.olcLcAdvThruIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcLcAdvThru())); } 
                if(obj.olcLcCurrCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcLcCurrCode()); } 
                if(obj.olcLcAmountIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcLcAmount()); } 
                if(obj.olcLcBalanceIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcLcBalance()); } 
                if(obj.olcDevAllwdIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcDevAllwd())); } 
                if(obj.olcPosDevAllwdIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcPosDevAllwd()); } 
                if(obj.olcNegDevAllwdIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcNegDevAllwd()); } 
                if(obj.olcDevAmountIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcDevAmount()); } 
                if(obj.olcDevBalIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcDevBal()); } 
                if(obj.olcAmtQualfrIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcAmtQualfr())); } 
                if(obj.olcPriceTermsIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcPriceTerms()); } 
                if(obj.olcLastDateOfNegIsModifiedS2j()) { if (obj.getOlcLastDateOfNeg() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcLastDateOfNeg().getTime()));} } 
                if(obj.olcPlaceOfExpiryIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcPlaceOfExpiry()); } 
                if(obj.olcLatestDateOfShpmntIsModifiedS2j()) { if (obj.getOlcLatestDateOfShpmnt() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcLatestDateOfShpmnt().getTime()));} } 
                if(obj.olcWithinValidateLcIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcWithinValidateLc())); } 
                if(obj.olcLcUiBorneByApplcntIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcLcUiBorneByApplcnt())); } 
                if(obj.olcNofTenorsIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcNofTenors()); } 
                if(obj.olcLcUnderContractIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcLcUnderContract())); } 
                if(obj.olcTotLiabLcCurrIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcTotLiabLcCurr()); } 
                if(obj.olcConvRateBaseCurrIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcConvRateBaseCurr()); } 
                if(obj.olcTotLiabBaseCurrIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcTotLiabBaseCurr()); } 
                if(obj.olcConvRateLimCurrIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcConvRateLimCurr()); } 
                if(obj.olcTotLiabLimCurrIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcTotLiabLimCurr()); } 
                if(obj.olcPaymntCurrIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcPaymntCurr()); } 
                if(obj.olcTotChrgsInPaymntCurrIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcTotChrgsInPaymntCurr()); } 
                if(obj.olcCashMarginBalIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcCashMarginBal()); } 
                if(obj.olcReimbChrgsByIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcReimbChrgsBy())); } 
                if(obj.olcPercRcPaidByApplcntIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcPercRcPaidByApplcnt()); } 
                if(obj.olcNostroAlphaCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcNostroAlphaCode()); } 
                if(obj.olcAdvThruBkIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcAdvThruBk()); } 
                if(obj.olcAdvThruBrnIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcAdvThruBrn()); } 
                if(obj.olcLcToBeCnfrmdIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcLcToBeCnfrmd())); } 
                if(obj.olcLcToBeCnfrmdByBkIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcLcToBeCnfrmdByBk()); } 
                if(obj.olcLcToBeCnfrmdByBrnIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcLcToBeCnfrmdByBrn()); } 
                if(obj.olcRestrictedIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcRestricted())); } 
                if(obj.olcRestrictedToUsIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcRestrictedToUs())); } 
                if(obj.olcRestrictedBkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcRestrictedBkCode()); } 
                if(obj.olcRestrictedBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcRestrictedBrnCode()); } 
                if(obj.olcCrAvlblByIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcCrAvlblBy())); } 
                if(obj.olcIrrevocableIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcIrrevocable())); } 
                if(obj.olcPartShpmntIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcPartShpmnt())); } 
                if(obj.olcTranShpmntIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcTranShpmnt())); } 
                if(obj.olcLcTransfrblIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcLcTransfrbl())); } 
                if(obj.olcDftReqdIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcDftReqd())); } 
                if(obj.olcPercDftValueIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcPercDftValue()); } 
                if(obj.olcDftToBeDrawnOnIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcDftToBeDrawnOn())); } 
                if(obj.olcDftOnBkIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcDftOnBk()); } 
                if(obj.olcDftOnBrnIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcDftOnBrn()); } 
                if(obj.olcSpecText1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcSpecText1()); } 
                if(obj.olcSpecText2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcSpecText2()); } 
                if(obj.olcSpecText3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcSpecText3()); } 
                if(obj.olcSpecText4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcSpecText4()); } 
                if(obj.olcPrimeRateClauseReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcPrimeRateClauseReq())); } 
                if(obj.olcShpmntModeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcShpmntMode())); } 
                if(obj.olcLloydsClauseReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcLloydsClauseReq())); } 
                if(obj.olcMaxShipAgeIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcMaxShipAge()); } 
                if(obj.olcShortFormOfBlIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcShortFormOfBl())); } 
                if(obj.olcLashTransDocsAllwdIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcLashTransDocsAllwd())); } 
                if(obj.olcPercOfInsValueCvrdIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcPercOfInsValueCvrd()); } 
                if(obj.olcInsPolicyNumIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcInsPolicyNum()); } 
                if(obj.olcInsDateIsModifiedS2j()) { if (obj.getOlcInsDate() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcInsDate().getTime()));} } 
                if(obj.olcInsCurrIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcInsCurr()); } 
                if(obj.olcInsAmtIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcInsAmt()); } 
                if(obj.olcPremiumCurrIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcPremiumCurr()); } 
                if(obj.olcPremiumAmtIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcPremiumAmt()); } 
                if(obj.olcInsCompanyIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcInsCompany()); } 
                if(obj.olcInsCompanyNameIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcInsCompanyName()); } 
                if(obj.olcCooIssByIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcCooIssBy()); } 
                if(obj.olcOtherCompAuthIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcOtherCompAuth()); } 
                if(obj.olcIntermediaryTradeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcIntermediaryTrade())); } 
                if(obj.olcInspTestCertReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcInspTestCertReq())); } 
                if(obj.olcCertByIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcCertBy()); } 
                if(obj.olcImpUnderIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcImpUnder())); } 
                if(obj.olcImpPolicyDetIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcImpPolicyDet()); } 
                if(obj.olcImpRefIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcImpRef()); } 
                if(obj.olcCustLiabAccIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcCustLiabAcc()); } 
                if(obj.olcCancelledOnIsModifiedS2j()) { if (obj.getOlcCancelledOn() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcCancelledOn().getTime()));} } 
                if(obj.olcUsanceChargesIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcUsanceCharges()); } 
                if(obj.olcUsnChgTakenDaysIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcUsnChgTakenDays()); } 
                if(obj.olcCommitmentChargesIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcCommitmentCharges()); } 
                if(obj.olcCommitChgTakenDaysIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcCommitChgTakenDays()); } 
                if(obj.tranchgsChgsSlIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getTranchgsChgsSl()); } 
                if(obj.trancratesRateSlIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getTrancratesRateSl()); } 
                if(obj.transtlmntInvNumIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getTranstlmntInvNum()); } 
                if(obj.postTranBrnIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getPostTranBrn()); } 
                if(obj.postTranDateIsModifiedS2j()) { if (obj.getPostTranDate() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getPostTranDate().getTime()));} } 
                if(obj.postTranBatchNumIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getPostTranBatchNum()); } 
                if(obj.olcEntdByIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcEntdBy()); } 
                if(obj.olcEntdOnIsModifiedS2j()) { if (obj.getOlcEntdOn() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcEntdOn().getTime()));} } 
                if(obj.olcLastmodByIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcLastmodBy()); } 
                if(obj.olcLastmodOnIsModifiedS2j()) { if (obj.getOlcLastmodOn() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcLastmodOn().getTime()));} } 
                if(obj.olcAuthByIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcAuthBy()); } 
                if(obj.olcAuthOnIsModifiedS2j()) { if (obj.getOlcAuthOn() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcAuthOn().getTime()));} } 
                if(obj.olcRejByIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcRejBy()); } 
                if(obj.olcRejOnIsModifiedS2j()) { if (obj.getOlcRejOn() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcRejOn().getTime()));} } 
                if(obj.olcMarginCurrIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcMarginCurr()); } 
                if(obj.olcMarginAmtIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcMarginAmt()); } 
                if(obj.olcMarginBalIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcMarginBal()); } 
                if(obj.olcCashMarAmtIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcCashMarAmt()); } 
                if(obj.olcCashMarBalIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcCashMarBal()); } 
                if(obj.olcCashMarRecIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcCashMarRec()); } 
                if(obj.olcDepMarRecIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcDepMarRec()); } 
                if(obj.olcOthSecMarRecIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcOthSecMarRec()); } 
                if(obj.olcUsanceServTaxIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcUsanceServTax()); } 
                if(obj.olcCommitServTaxIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcCommitServTax()); } 
                _pstmt.executeUpdate();
                obj.setIsNew(false);
                obj.resetIsModifiedS2J();
            }
            else {
                StringBuffer _sql = new StringBuffer("UPDATE OLC SET ");
                if(obj.olcBrnCodeIsModifiedS2j()) {  _sql.append("OLC_BRN_CODE").append("=?,"); }
                if(obj.olcLcTypeIsModifiedS2j()) {  _sql.append("OLC_LC_TYPE").append("=?,"); }
                if(obj.olcLcYearIsModifiedS2j()) {  _sql.append("OLC_LC_YEAR").append("=?,"); }
                if(obj.olcLcSlIsModifiedS2j()) {  _sql.append("OLC_LC_SL").append("=?,"); }
                if(obj.olcCorrRefNumIsModifiedS2j()) {  _sql.append("OLC_CORR_REF_NUM").append("=?,"); }
                if(obj.olcLcPresancDateIsModifiedS2j()) {  _sql.append("OLC_LC_PRESANC_DATE").append("=?,"); }
                if(obj.olcLcPresancDaySlIsModifiedS2j()) {  _sql.append("OLC_LC_PRESANC_DAY_SL").append("=?,"); }
                if(obj.olcLcDateIsModifiedS2j()) {  _sql.append("OLC_LC_DATE").append("=?,"); }
                if(obj.olcCustNumIsModifiedS2j()) {  _sql.append("OLC_CUST_NUM").append("=?,"); }
                if(obj.olcBenefCodeIsModifiedS2j()) {  _sql.append("OLC_BENEF_CODE").append("=?,"); }
                if(obj.olcBenefNameIsModifiedS2j()) {  _sql.append("OLC_BENEF_NAME").append("=?,"); }
                if(obj.olcBenefAddr1IsModifiedS2j()) {  _sql.append("OLC_BENEF_ADDR1").append("=?,"); }
                if(obj.olcBenefAddr2IsModifiedS2j()) {  _sql.append("OLC_BENEF_ADDR2").append("=?,"); }
                if(obj.olcBenefAddr3IsModifiedS2j()) {  _sql.append("OLC_BENEF_ADDR3").append("=?,"); }
                if(obj.olcBenefAddr4IsModifiedS2j()) {  _sql.append("OLC_BENEF_ADDR4").append("=?,"); }
                if(obj.olcBenefAddr5IsModifiedS2j()) {  _sql.append("OLC_BENEF_ADDR5").append("=?,"); }
                if(obj.olcBenefCntryCodeIsModifiedS2j()) {  _sql.append("OLC_BENEF_CNTRY_CODE").append("=?,"); }
                if(obj.olcLcIssBkCodeIsModifiedS2j()) {  _sql.append("OLC_LC_ISS_BK_CODE").append("=?,"); }
                if(obj.olcLcIssBrnCodeIsModifiedS2j()) {  _sql.append("OLC_LC_ISS_BRN_CODE").append("=?,"); }
                if(obj.olcLcIssBrnNameIsModifiedS2j()) {  _sql.append("OLC_LC_ISS_BRN_NAME").append("=?,"); }
                if(obj.olcLcIssBrnAdd1IsModifiedS2j()) {  _sql.append("OLC_LC_ISS_BRN_ADD1").append("=?,"); }
                if(obj.olcLcIssBrnAdd2IsModifiedS2j()) {  _sql.append("OLC_LC_ISS_BRN_ADD2").append("=?,"); }
                if(obj.olcLcIssBrnAdd3IsModifiedS2j()) {  _sql.append("OLC_LC_ISS_BRN_ADD3").append("=?,"); }
                if(obj.olcLcIssBrnAdd4IsModifiedS2j()) {  _sql.append("OLC_LC_ISS_BRN_ADD4").append("=?,"); }
                if(obj.olcLcIssBrnAdd5IsModifiedS2j()) {  _sql.append("OLC_LC_ISS_BRN_ADD5").append("=?,"); }
                if(obj.olcLcIssPlaceIsModifiedS2j()) {  _sql.append("OLC_LC_ISS_PLACE").append("=?,"); }
                if(obj.olcLcIssCntryIsModifiedS2j()) {  _sql.append("OLC_LC_ISS_CNTRY").append("=?,"); }
                if(obj.olcLcAdvThruIsModifiedS2j()) {  _sql.append("OLC_LC_ADV_THRU").append("=?,"); }
                if(obj.olcLcCurrCodeIsModifiedS2j()) {  _sql.append("OLC_LC_CURR_CODE").append("=?,"); }
                if(obj.olcLcAmountIsModifiedS2j()) {  _sql.append("OLC_LC_AMOUNT").append("=?,"); }
                if(obj.olcLcBalanceIsModifiedS2j()) {  _sql.append("OLC_LC_BALANCE").append("=?,"); }
                if(obj.olcDevAllwdIsModifiedS2j()) {  _sql.append("OLC_DEV_ALLWD").append("=?,"); }
                if(obj.olcPosDevAllwdIsModifiedS2j()) {  _sql.append("OLC_POS_DEV_ALLWD").append("=?,"); }
                if(obj.olcNegDevAllwdIsModifiedS2j()) {  _sql.append("OLC_NEG_DEV_ALLWD").append("=?,"); }
                if(obj.olcDevAmountIsModifiedS2j()) {  _sql.append("OLC_DEV_AMOUNT").append("=?,"); }
                if(obj.olcDevBalIsModifiedS2j()) {  _sql.append("OLC_DEV_BAL").append("=?,"); }
                if(obj.olcAmtQualfrIsModifiedS2j()) {  _sql.append("OLC_AMT_QUALFR").append("=?,"); }
                if(obj.olcPriceTermsIsModifiedS2j()) {  _sql.append("OLC_PRICE_TERMS").append("=?,"); }
                if(obj.olcLastDateOfNegIsModifiedS2j()) {  _sql.append("OLC_LAST_DATE_OF_NEG").append("=?,"); }
                if(obj.olcPlaceOfExpiryIsModifiedS2j()) {  _sql.append("OLC_PLACE_OF_EXPIRY").append("=?,"); }
                if(obj.olcLatestDateOfShpmntIsModifiedS2j()) {  _sql.append("OLC_LATEST_DATE_OF_SHPMNT").append("=?,"); }
                if(obj.olcWithinValidateLcIsModifiedS2j()) {  _sql.append("OLC_WITHIN_VALIDATE_LC").append("=?,"); }
                if(obj.olcLcUiBorneByApplcntIsModifiedS2j()) {  _sql.append("OLC_LC_UI_BORNE_BY_APPLCNT").append("=?,"); }
                if(obj.olcNofTenorsIsModifiedS2j()) {  _sql.append("OLC_NOF_TENORS").append("=?,"); }
                if(obj.olcLcUnderContractIsModifiedS2j()) {  _sql.append("OLC_LC_UNDER_CONTRACT").append("=?,"); }
                if(obj.olcTotLiabLcCurrIsModifiedS2j()) {  _sql.append("OLC_TOT_LIAB_LC_CURR").append("=?,"); }
                if(obj.olcConvRateBaseCurrIsModifiedS2j()) {  _sql.append("OLC_CONV_RATE_BASE_CURR").append("=?,"); }
                if(obj.olcTotLiabBaseCurrIsModifiedS2j()) {  _sql.append("OLC_TOT_LIAB_BASE_CURR").append("=?,"); }
                if(obj.olcConvRateLimCurrIsModifiedS2j()) {  _sql.append("OLC_CONV_RATE_LIM_CURR").append("=?,"); }
                if(obj.olcTotLiabLimCurrIsModifiedS2j()) {  _sql.append("OLC_TOT_LIAB_LIM_CURR").append("=?,"); }
                if(obj.olcPaymntCurrIsModifiedS2j()) {  _sql.append("OLC_PAYMNT_CURR").append("=?,"); }
                if(obj.olcTotChrgsInPaymntCurrIsModifiedS2j()) {  _sql.append("OLC_TOT_CHRGS_IN_PAYMNT_CURR").append("=?,"); }
                if(obj.olcCashMarginBalIsModifiedS2j()) {  _sql.append("OLC_CASH_MARGIN_BAL").append("=?,"); }
                if(obj.olcReimbChrgsByIsModifiedS2j()) {  _sql.append("OLC_REIMB_CHRGS_BY").append("=?,"); }
                if(obj.olcPercRcPaidByApplcntIsModifiedS2j()) {  _sql.append("OLC_PERC_RC_PAID_BY_APPLCNT").append("=?,"); }
                if(obj.olcNostroAlphaCodeIsModifiedS2j()) {  _sql.append("OLC_NOSTRO_ALPHA_CODE").append("=?,"); }
                if(obj.olcAdvThruBkIsModifiedS2j()) {  _sql.append("OLC_ADV_THRU_BK").append("=?,"); }
                if(obj.olcAdvThruBrnIsModifiedS2j()) {  _sql.append("OLC_ADV_THRU_BRN").append("=?,"); }
                if(obj.olcLcToBeCnfrmdIsModifiedS2j()) {  _sql.append("OLC_LC_TO_BE_CNFRMD").append("=?,"); }
                if(obj.olcLcToBeCnfrmdByBkIsModifiedS2j()) {  _sql.append("OLC_LC_TO_BE_CNFRMD_BY_BK").append("=?,"); }
                if(obj.olcLcToBeCnfrmdByBrnIsModifiedS2j()) {  _sql.append("OLC_LC_TO_BE_CNFRMD_BY_BRN").append("=?,"); }
                if(obj.olcRestrictedIsModifiedS2j()) {  _sql.append("OLC_RESTRICTED").append("=?,"); }
                if(obj.olcRestrictedToUsIsModifiedS2j()) {  _sql.append("OLC_RESTRICTED_TO_US").append("=?,"); }
                if(obj.olcRestrictedBkCodeIsModifiedS2j()) {  _sql.append("OLC_RESTRICTED_BK_CODE").append("=?,"); }
                if(obj.olcRestrictedBrnCodeIsModifiedS2j()) {  _sql.append("OLC_RESTRICTED_BRN_CODE").append("=?,"); }
                if(obj.olcCrAvlblByIsModifiedS2j()) {  _sql.append("OLC_CR_AVLBL_BY").append("=?,"); }
                if(obj.olcIrrevocableIsModifiedS2j()) {  _sql.append("OLC_IRREVOCABLE").append("=?,"); }
                if(obj.olcPartShpmntIsModifiedS2j()) {  _sql.append("OLC_PART_SHPMNT").append("=?,"); }
                if(obj.olcTranShpmntIsModifiedS2j()) {  _sql.append("OLC_TRAN_SHPMNT").append("=?,"); }
                if(obj.olcLcTransfrblIsModifiedS2j()) {  _sql.append("OLC_LC_TRANSFRBL").append("=?,"); }
                if(obj.olcDftReqdIsModifiedS2j()) {  _sql.append("OLC_DFT_REQD").append("=?,"); }
                if(obj.olcPercDftValueIsModifiedS2j()) {  _sql.append("OLC_PERC_DFT_VALUE").append("=?,"); }
                if(obj.olcDftToBeDrawnOnIsModifiedS2j()) {  _sql.append("OLC_DFT_TO_BE_DRAWN_ON").append("=?,"); }
                if(obj.olcDftOnBkIsModifiedS2j()) {  _sql.append("OLC_DFT_ON_BK").append("=?,"); }
                if(obj.olcDftOnBrnIsModifiedS2j()) {  _sql.append("OLC_DFT_ON_BRN").append("=?,"); }
                if(obj.olcSpecText1IsModifiedS2j()) {  _sql.append("OLC_SPEC_TEXT1").append("=?,"); }
                if(obj.olcSpecText2IsModifiedS2j()) {  _sql.append("OLC_SPEC_TEXT2").append("=?,"); }
                if(obj.olcSpecText3IsModifiedS2j()) {  _sql.append("OLC_SPEC_TEXT3").append("=?,"); }
                if(obj.olcSpecText4IsModifiedS2j()) {  _sql.append("OLC_SPEC_TEXT4").append("=?,"); }
                if(obj.olcPrimeRateClauseReqIsModifiedS2j()) {  _sql.append("OLC_PRIME_RATE_CLAUSE_REQ").append("=?,"); }
                if(obj.olcShpmntModeIsModifiedS2j()) {  _sql.append("OLC_SHPMNT_MODE").append("=?,"); }
                if(obj.olcLloydsClauseReqIsModifiedS2j()) {  _sql.append("OLC_LLOYDS_CLAUSE_REQ").append("=?,"); }
                if(obj.olcMaxShipAgeIsModifiedS2j()) {  _sql.append("OLC_MAX_SHIP_AGE").append("=?,"); }
                if(obj.olcShortFormOfBlIsModifiedS2j()) {  _sql.append("OLC_SHORT_FORM_OF_BL").append("=?,"); }
                if(obj.olcLashTransDocsAllwdIsModifiedS2j()) {  _sql.append("OLC_LASH_TRANS_DOCS_ALLWD").append("=?,"); }
                if(obj.olcPercOfInsValueCvrdIsModifiedS2j()) {  _sql.append("OLC_PERC_OF_INS_VALUE_CVRD").append("=?,"); }
                if(obj.olcInsPolicyNumIsModifiedS2j()) {  _sql.append("OLC_INS_POLICY_NUM").append("=?,"); }
                if(obj.olcInsDateIsModifiedS2j()) {  _sql.append("OLC_INS_DATE").append("=?,"); }
                if(obj.olcInsCurrIsModifiedS2j()) {  _sql.append("OLC_INS_CURR").append("=?,"); }
                if(obj.olcInsAmtIsModifiedS2j()) {  _sql.append("OLC_INS_AMT").append("=?,"); }
                if(obj.olcPremiumCurrIsModifiedS2j()) {  _sql.append("OLC_PREMIUM_CURR").append("=?,"); }
                if(obj.olcPremiumAmtIsModifiedS2j()) {  _sql.append("OLC_PREMIUM_AMT").append("=?,"); }
                if(obj.olcInsCompanyIsModifiedS2j()) {  _sql.append("OLC_INS_COMPANY").append("=?,"); }
                if(obj.olcInsCompanyNameIsModifiedS2j()) {  _sql.append("OLC_INS_COMPANY_NAME").append("=?,"); }
                if(obj.olcCooIssByIsModifiedS2j()) {  _sql.append("OLC_COO_ISS_BY").append("=?,"); }
                if(obj.olcOtherCompAuthIsModifiedS2j()) {  _sql.append("OLC_OTHER_COMP_AUTH").append("=?,"); }
                if(obj.olcIntermediaryTradeIsModifiedS2j()) {  _sql.append("OLC_INTERMEDIARY_TRADE").append("=?,"); }
                if(obj.olcInspTestCertReqIsModifiedS2j()) {  _sql.append("OLC_INSP_TEST_CERT_REQ").append("=?,"); }
                if(obj.olcCertByIsModifiedS2j()) {  _sql.append("OLC_CERT_BY").append("=?,"); }
                if(obj.olcImpUnderIsModifiedS2j()) {  _sql.append("OLC_IMP_UNDER").append("=?,"); }
                if(obj.olcImpPolicyDetIsModifiedS2j()) {  _sql.append("OLC_IMP_POLICY_DET").append("=?,"); }
                if(obj.olcImpRefIsModifiedS2j()) {  _sql.append("OLC_IMP_REF").append("=?,"); }
                if(obj.olcCustLiabAccIsModifiedS2j()) {  _sql.append("OLC_CUST_LIAB_ACC").append("=?,"); }
                if(obj.olcCancelledOnIsModifiedS2j()) {  _sql.append("OLC_CANCELLED_ON").append("=?,"); }
                if(obj.olcUsanceChargesIsModifiedS2j()) {  _sql.append("OLC_USANCE_CHARGES").append("=?,"); }
                if(obj.olcUsnChgTakenDaysIsModifiedS2j()) {  _sql.append("OLC_USN_CHG_TAKEN_DAYS").append("=?,"); }
                if(obj.olcCommitmentChargesIsModifiedS2j()) {  _sql.append("OLC_COMMITMENT_CHARGES").append("=?,"); }
                if(obj.olcCommitChgTakenDaysIsModifiedS2j()) {  _sql.append("OLC_COMMIT_CHG_TAKEN_DAYS").append("=?,"); }
                if(obj.tranchgsChgsSlIsModifiedS2j()) {  _sql.append("TRANCHGS_CHGS_SL").append("=?,"); }
                if(obj.trancratesRateSlIsModifiedS2j()) {  _sql.append("TRANCRATES_RATE_SL").append("=?,"); }
                if(obj.transtlmntInvNumIsModifiedS2j()) {  _sql.append("TRANSTLMNT_INV_NUM").append("=?,"); }
                if(obj.postTranBrnIsModifiedS2j()) {  _sql.append("POST_TRAN_BRN").append("=?,"); }
                if(obj.postTranDateIsModifiedS2j()) {  _sql.append("POST_TRAN_DATE").append("=?,"); }
                if(obj.postTranBatchNumIsModifiedS2j()) {  _sql.append("POST_TRAN_BATCH_NUM").append("=?,"); }
                if(obj.olcEntdByIsModifiedS2j()) {  _sql.append("OLC_ENTD_BY").append("=?,"); }
                if(obj.olcEntdOnIsModifiedS2j()) {  _sql.append("OLC_ENTD_ON").append("=?,"); }
                if(obj.olcLastmodByIsModifiedS2j()) {  _sql.append("OLC_LASTMOD_BY").append("=?,"); }
                if(obj.olcLastmodOnIsModifiedS2j()) {  _sql.append("OLC_LASTMOD_ON").append("=?,"); }
                if(obj.olcAuthByIsModifiedS2j()) {  _sql.append("OLC_AUTH_BY").append("=?,"); }
                if(obj.olcAuthOnIsModifiedS2j()) {  _sql.append("OLC_AUTH_ON").append("=?,"); }
                if(obj.olcRejByIsModifiedS2j()) {  _sql.append("OLC_REJ_BY").append("=?,"); }
                if(obj.olcRejOnIsModifiedS2j()) {  _sql.append("OLC_REJ_ON").append("=?,"); }
                if(obj.olcMarginCurrIsModifiedS2j()) {  _sql.append("OLC_MARGIN_CURR").append("=?,"); }
                if(obj.olcMarginAmtIsModifiedS2j()) {  _sql.append("OLC_MARGIN_AMT").append("=?,"); }
                if(obj.olcMarginBalIsModifiedS2j()) {  _sql.append("OLC_MARGIN_BAL").append("=?,"); }
                if(obj.olcCashMarAmtIsModifiedS2j()) {  _sql.append("OLC_CASH_MAR_AMT").append("=?,"); }
                if(obj.olcCashMarBalIsModifiedS2j()) {  _sql.append("OLC_CASH_MAR_BAL").append("=?,"); }
                if(obj.olcCashMarRecIsModifiedS2j()) {  _sql.append("OLC_CASH_MAR_REC").append("=?,"); }
                if(obj.olcDepMarRecIsModifiedS2j()) {  _sql.append("OLC_DEP_MAR_REC").append("=?,"); }
                if(obj.olcOthSecMarRecIsModifiedS2j()) {  _sql.append("OLC_OTH_SEC_MAR_REC").append("=?,"); }
                if(obj.olcUsanceServTaxIsModifiedS2j()) {  _sql.append("OLC_USANCE_SERV_TAX").append("=?,"); }
                if(obj.olcCommitServTaxIsModifiedS2j()) {  _sql.append("OLC_COMMIT_SERV_TAX").append("=?,"); }
                _sql.setLength(_sql.length() - 1);
                _sql.append(" WHERE ");
                _sql.append("OLC.OLC_BRN_CODE=? and OLC.OLC_LC_SL=? and OLC.OLC_LC_TYPE=? and OLC.OLC_LC_YEAR=?");
                _pstmt = _conn.prepareStatement(_sql.toString());
                int _dirtyCount = 0;
                if(obj.olcBrnCodeIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcBrnCode()); } 
                if(obj.olcLcTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcLcType()); } 
                if(obj.olcLcYearIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcLcYear()); } 
                if(obj.olcLcSlIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcLcSl()); } 
                if(obj.olcCorrRefNumIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcCorrRefNum()); } 
                if(obj.olcLcPresancDateIsModifiedS2j()) { if (obj.getOlcLcPresancDate() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcLcPresancDate().getTime()));} } 
                if(obj.olcLcPresancDaySlIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcLcPresancDaySl()); } 
                if(obj.olcLcDateIsModifiedS2j()) { if (obj.getOlcLcDate() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcLcDate().getTime()));} } 
                if(obj.olcCustNumIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcCustNum()); } 
                if(obj.olcBenefCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcBenefCode()); } 
                if(obj.olcBenefNameIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcBenefName()); } 
                if(obj.olcBenefAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcBenefAddr1()); } 
                if(obj.olcBenefAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcBenefAddr2()); } 
                if(obj.olcBenefAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcBenefAddr3()); } 
                if(obj.olcBenefAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcBenefAddr4()); } 
                if(obj.olcBenefAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcBenefAddr5()); } 
                if(obj.olcBenefCntryCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcBenefCntryCode()); } 
                if(obj.olcLcIssBkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcLcIssBkCode()); } 
                if(obj.olcLcIssBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcLcIssBrnCode()); } 
                if(obj.olcLcIssBrnNameIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcLcIssBrnName()); } 
                if(obj.olcLcIssBrnAdd1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcLcIssBrnAdd1()); } 
                if(obj.olcLcIssBrnAdd2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcLcIssBrnAdd2()); } 
                if(obj.olcLcIssBrnAdd3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcLcIssBrnAdd3()); } 
                if(obj.olcLcIssBrnAdd4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcLcIssBrnAdd4()); } 
                if(obj.olcLcIssBrnAdd5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcLcIssBrnAdd5()); } 
                if(obj.olcLcIssPlaceIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcLcIssPlace()); } 
                if(obj.olcLcIssCntryIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcLcIssCntry()); } 
                if(obj.olcLcAdvThruIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcLcAdvThru())); } 
                if(obj.olcLcCurrCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcLcCurrCode()); } 
                if(obj.olcLcAmountIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcLcAmount()); } 
                if(obj.olcLcBalanceIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcLcBalance()); } 
                if(obj.olcDevAllwdIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcDevAllwd())); } 
                if(obj.olcPosDevAllwdIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcPosDevAllwd()); } 
                if(obj.olcNegDevAllwdIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcNegDevAllwd()); } 
                if(obj.olcDevAmountIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcDevAmount()); } 
                if(obj.olcDevBalIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcDevBal()); } 
                if(obj.olcAmtQualfrIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcAmtQualfr())); } 
                if(obj.olcPriceTermsIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcPriceTerms()); } 
                if(obj.olcLastDateOfNegIsModifiedS2j()) { if (obj.getOlcLastDateOfNeg() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcLastDateOfNeg().getTime()));} } 
                if(obj.olcPlaceOfExpiryIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcPlaceOfExpiry()); } 
                if(obj.olcLatestDateOfShpmntIsModifiedS2j()) { if (obj.getOlcLatestDateOfShpmnt() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcLatestDateOfShpmnt().getTime()));} } 
                if(obj.olcWithinValidateLcIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcWithinValidateLc())); } 
                if(obj.olcLcUiBorneByApplcntIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcLcUiBorneByApplcnt())); } 
                if(obj.olcNofTenorsIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcNofTenors()); } 
                if(obj.olcLcUnderContractIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcLcUnderContract())); } 
                if(obj.olcTotLiabLcCurrIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcTotLiabLcCurr()); } 
                if(obj.olcConvRateBaseCurrIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcConvRateBaseCurr()); } 
                if(obj.olcTotLiabBaseCurrIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcTotLiabBaseCurr()); } 
                if(obj.olcConvRateLimCurrIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcConvRateLimCurr()); } 
                if(obj.olcTotLiabLimCurrIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcTotLiabLimCurr()); } 
                if(obj.olcPaymntCurrIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcPaymntCurr()); } 
                if(obj.olcTotChrgsInPaymntCurrIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcTotChrgsInPaymntCurr()); } 
                if(obj.olcCashMarginBalIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcCashMarginBal()); } 
                if(obj.olcReimbChrgsByIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcReimbChrgsBy())); } 
                if(obj.olcPercRcPaidByApplcntIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcPercRcPaidByApplcnt()); } 
                if(obj.olcNostroAlphaCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcNostroAlphaCode()); } 
                if(obj.olcAdvThruBkIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcAdvThruBk()); } 
                if(obj.olcAdvThruBrnIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcAdvThruBrn()); } 
                if(obj.olcLcToBeCnfrmdIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcLcToBeCnfrmd())); } 
                if(obj.olcLcToBeCnfrmdByBkIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcLcToBeCnfrmdByBk()); } 
                if(obj.olcLcToBeCnfrmdByBrnIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcLcToBeCnfrmdByBrn()); } 
                if(obj.olcRestrictedIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcRestricted())); } 
                if(obj.olcRestrictedToUsIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcRestrictedToUs())); } 
                if(obj.olcRestrictedBkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcRestrictedBkCode()); } 
                if(obj.olcRestrictedBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcRestrictedBrnCode()); } 
                if(obj.olcCrAvlblByIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcCrAvlblBy())); } 
                if(obj.olcIrrevocableIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcIrrevocable())); } 
                if(obj.olcPartShpmntIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcPartShpmnt())); } 
                if(obj.olcTranShpmntIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcTranShpmnt())); } 
                if(obj.olcLcTransfrblIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcLcTransfrbl())); } 
                if(obj.olcDftReqdIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcDftReqd())); } 
                if(obj.olcPercDftValueIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcPercDftValue()); } 
                if(obj.olcDftToBeDrawnOnIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcDftToBeDrawnOn())); } 
                if(obj.olcDftOnBkIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcDftOnBk()); } 
                if(obj.olcDftOnBrnIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcDftOnBrn()); } 
                if(obj.olcSpecText1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcSpecText1()); } 
                if(obj.olcSpecText2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcSpecText2()); } 
                if(obj.olcSpecText3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcSpecText3()); } 
                if(obj.olcSpecText4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcSpecText4()); } 
                if(obj.olcPrimeRateClauseReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcPrimeRateClauseReq())); } 
                if(obj.olcShpmntModeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcShpmntMode())); } 
                if(obj.olcLloydsClauseReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcLloydsClauseReq())); } 
                if(obj.olcMaxShipAgeIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcMaxShipAge()); } 
                if(obj.olcShortFormOfBlIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcShortFormOfBl())); } 
                if(obj.olcLashTransDocsAllwdIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcLashTransDocsAllwd())); } 
                if(obj.olcPercOfInsValueCvrdIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcPercOfInsValueCvrd()); } 
                if(obj.olcInsPolicyNumIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcInsPolicyNum()); } 
                if(obj.olcInsDateIsModifiedS2j()) { if (obj.getOlcInsDate() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcInsDate().getTime()));} } 
                if(obj.olcInsCurrIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcInsCurr()); } 
                if(obj.olcInsAmtIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcInsAmt()); } 
                if(obj.olcPremiumCurrIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcPremiumCurr()); } 
                if(obj.olcPremiumAmtIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcPremiumAmt()); } 
                if(obj.olcInsCompanyIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcInsCompany()); } 
                if(obj.olcInsCompanyNameIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcInsCompanyName()); } 
                if(obj.olcCooIssByIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcCooIssBy()); } 
                if(obj.olcOtherCompAuthIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcOtherCompAuth()); } 
                if(obj.olcIntermediaryTradeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcIntermediaryTrade())); } 
                if(obj.olcInspTestCertReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcInspTestCertReq())); } 
                if(obj.olcCertByIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcCertBy()); } 
                if(obj.olcImpUnderIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcImpUnder())); } 
                if(obj.olcImpPolicyDetIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcImpPolicyDet()); } 
                if(obj.olcImpRefIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcImpRef()); } 
                if(obj.olcCustLiabAccIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcCustLiabAcc()); } 
                if(obj.olcCancelledOnIsModifiedS2j()) { if (obj.getOlcCancelledOn() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcCancelledOn().getTime()));} } 
                if(obj.olcUsanceChargesIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcUsanceCharges()); } 
                if(obj.olcUsnChgTakenDaysIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcUsnChgTakenDays()); } 
                if(obj.olcCommitmentChargesIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcCommitmentCharges()); } 
                if(obj.olcCommitChgTakenDaysIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcCommitChgTakenDays()); } 
                if(obj.tranchgsChgsSlIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getTranchgsChgsSl()); } 
                if(obj.trancratesRateSlIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getTrancratesRateSl()); } 
                if(obj.transtlmntInvNumIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getTranstlmntInvNum()); } 
                if(obj.postTranBrnIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getPostTranBrn()); } 
                if(obj.postTranDateIsModifiedS2j()) { if (obj.getPostTranDate() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getPostTranDate().getTime()));} } 
                if(obj.postTranBatchNumIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getPostTranBatchNum()); } 
                if(obj.olcEntdByIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcEntdBy()); } 
                if(obj.olcEntdOnIsModifiedS2j()) { if (obj.getOlcEntdOn() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcEntdOn().getTime()));} } 
                if(obj.olcLastmodByIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcLastmodBy()); } 
                if(obj.olcLastmodOnIsModifiedS2j()) { if (obj.getOlcLastmodOn() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcLastmodOn().getTime()));} } 
                if(obj.olcAuthByIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcAuthBy()); } 
                if(obj.olcAuthOnIsModifiedS2j()) { if (obj.getOlcAuthOn() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcAuthOn().getTime()));} } 
                if(obj.olcRejByIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcRejBy()); } 
                if(obj.olcRejOnIsModifiedS2j()) { if (obj.getOlcRejOn() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcRejOn().getTime()));} } 
                if(obj.olcMarginCurrIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcMarginCurr()); } 
                if(obj.olcMarginAmtIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcMarginAmt()); } 
                if(obj.olcMarginBalIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcMarginBal()); } 
                if(obj.olcCashMarAmtIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcCashMarAmt()); } 
                if(obj.olcCashMarBalIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcCashMarBal()); } 
                if(obj.olcCashMarRecIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcCashMarRec()); } 
                if(obj.olcDepMarRecIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcDepMarRec()); } 
                if(obj.olcOthSecMarRecIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcOthSecMarRec()); } 
                if(obj.olcUsanceServTaxIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcUsanceServTax()); } 
                if(obj.olcCommitServTaxIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcCommitServTax()); } 
                _pstmt.setDouble(++_dirtyCount, obj.getOlcBrnCode());
                _pstmt.setDouble(++_dirtyCount, obj.getOlcLcSl());
                _pstmt.setString(++_dirtyCount, obj.getOlcLcType());
                _pstmt.setDouble(++_dirtyCount, obj.getOlcLcYear());
                _pstmt.executeUpdate();
                obj.resetIsModifiedS2J();
            }
            _pstmt.close();
        }
        catch(SQLException e) {
            if(_pstmt!=null) try { _pstmt.close();} catch(Exception e2) {}
            throw e;
        }
    }

    private Olc decodeRow(ResultSet rs) throws SQLException {
        Olc obj = new Olc();
        obj.setOlcBrnCode(rs.getInt(1));
        obj.setOlcLcType(rs.getString(2));
        obj.setOlcLcYear(rs.getInt(3));
        obj.setOlcLcSl(rs.getInt(4));
        obj.setOlcCorrRefNum(rs.getString(5));
        obj.setOlcLcPresancDate(rs.getDate(6));
        obj.setOlcLcPresancDaySl(rs.getInt(7));
        obj.setOlcLcDate(rs.getDate(8));
        obj.setOlcCustNum(rs.getLong(9));
        obj.setOlcBenefCode(rs.getString(10));
        obj.setOlcBenefName(rs.getString(11));
        obj.setOlcBenefAddr1(rs.getString(12));
        obj.setOlcBenefAddr2(rs.getString(13));
        obj.setOlcBenefAddr3(rs.getString(14));
        obj.setOlcBenefAddr4(rs.getString(15));
        obj.setOlcBenefAddr5(rs.getString(16));
        obj.setOlcBenefCntryCode(rs.getString(17));
        obj.setOlcLcIssBkCode(rs.getString(18));
        obj.setOlcLcIssBrnCode(rs.getString(19));
        obj.setOlcLcIssBrnName(rs.getString(20));
        obj.setOlcLcIssBrnAdd1(rs.getString(21));
        obj.setOlcLcIssBrnAdd2(rs.getString(22));
        obj.setOlcLcIssBrnAdd3(rs.getString(23));
        obj.setOlcLcIssBrnAdd4(rs.getString(24));
        obj.setOlcLcIssBrnAdd5(rs.getString(25));
        obj.setOlcLcIssPlace(rs.getString(26));
        obj.setOlcLcIssCntry(rs.getString(27));
        obj.setOlcLcAdvThru(stringToChar(rs.getString(28)));
        obj.setOlcLcCurrCode(rs.getString(29));
        obj.setOlcLcAmount(rs.getDouble(30));
        obj.setOlcLcBalance(rs.getDouble(31));
        obj.setOlcDevAllwd(stringToChar(rs.getString(32)));
        obj.setOlcPosDevAllwd(rs.getDouble(33));
        obj.setOlcNegDevAllwd(rs.getDouble(34));
        obj.setOlcDevAmount(rs.getDouble(35));
        obj.setOlcDevBal(rs.getDouble(36));
        obj.setOlcAmtQualfr(stringToChar(rs.getString(37)));
        obj.setOlcPriceTerms(rs.getString(38));
        obj.setOlcLastDateOfNeg(rs.getDate(39));
        obj.setOlcPlaceOfExpiry(rs.getString(40));
        obj.setOlcLatestDateOfShpmnt(rs.getDate(41));
        obj.setOlcWithinValidateLc(stringToChar(rs.getString(42)));
        obj.setOlcLcUiBorneByApplcnt(stringToChar(rs.getString(43)));
        obj.setOlcNofTenors(rs.getInt(44));
        obj.setOlcLcUnderContract(stringToChar(rs.getString(45)));
        obj.setOlcTotLiabLcCurr(rs.getDouble(46));
        obj.setOlcConvRateBaseCurr(rs.getDouble(47));
        obj.setOlcTotLiabBaseCurr(rs.getDouble(48));
        obj.setOlcConvRateLimCurr(rs.getDouble(49));
        obj.setOlcTotLiabLimCurr(rs.getDouble(50));
        obj.setOlcPaymntCurr(rs.getString(51));
        obj.setOlcTotChrgsInPaymntCurr(rs.getDouble(52));
        obj.setOlcCashMarginBal(rs.getDouble(53));
        obj.setOlcReimbChrgsBy(stringToChar(rs.getString(54)));
        obj.setOlcPercRcPaidByApplcnt(rs.getDouble(55));
        obj.setOlcNostroAlphaCode(rs.getString(56));
        obj.setOlcAdvThruBk(rs.getString(57));
        obj.setOlcAdvThruBrn(rs.getString(58));
        obj.setOlcLcToBeCnfrmd(stringToChar(rs.getString(59)));
        obj.setOlcLcToBeCnfrmdByBk(rs.getString(60));
        obj.setOlcLcToBeCnfrmdByBrn(rs.getString(61));
        obj.setOlcRestricted(stringToChar(rs.getString(62)));
        obj.setOlcRestrictedToUs(stringToChar(rs.getString(63)));
        obj.setOlcRestrictedBkCode(rs.getString(64));
        obj.setOlcRestrictedBrnCode(rs.getString(65));
        obj.setOlcCrAvlblBy(stringToChar(rs.getString(66)));
        obj.setOlcIrrevocable(stringToChar(rs.getString(67)));
        obj.setOlcPartShpmnt(stringToChar(rs.getString(68)));
        obj.setOlcTranShpmnt(stringToChar(rs.getString(69)));
        obj.setOlcLcTransfrbl(stringToChar(rs.getString(70)));
        obj.setOlcDftReqd(stringToChar(rs.getString(71)));
        obj.setOlcPercDftValue(rs.getDouble(72));
        obj.setOlcDftToBeDrawnOn(stringToChar(rs.getString(73)));
        obj.setOlcDftOnBk(rs.getString(74));
        obj.setOlcDftOnBrn(rs.getString(75));
        obj.setOlcSpecText1(rs.getString(76));
        obj.setOlcSpecText2(rs.getString(77));
        obj.setOlcSpecText3(rs.getString(78));
        obj.setOlcSpecText4(rs.getString(79));
        obj.setOlcPrimeRateClauseReq(stringToChar(rs.getString(80)));
        obj.setOlcShpmntMode(stringToChar(rs.getString(81)));
        obj.setOlcLloydsClauseReq(stringToChar(rs.getString(82)));
        obj.setOlcMaxShipAge(rs.getInt(83));
        obj.setOlcShortFormOfBl(stringToChar(rs.getString(84)));
        obj.setOlcLashTransDocsAllwd(stringToChar(rs.getString(85)));
        obj.setOlcPercOfInsValueCvrd(rs.getDouble(86));
        obj.setOlcInsPolicyNum(rs.getString(87));
        obj.setOlcInsDate(rs.getDate(88));
        obj.setOlcInsCurr(rs.getString(89));
        obj.setOlcInsAmt(rs.getDouble(90));
        obj.setOlcPremiumCurr(rs.getString(91));
        obj.setOlcPremiumAmt(rs.getDouble(92));
        obj.setOlcInsCompany(rs.getString(93));
        obj.setOlcInsCompanyName(rs.getString(94));
        obj.setOlcCooIssBy(rs.getString(95));
        obj.setOlcOtherCompAuth(rs.getString(96));
        obj.setOlcIntermediaryTrade(stringToChar(rs.getString(97)));
        obj.setOlcInspTestCertReq(stringToChar(rs.getString(98)));
        obj.setOlcCertBy(rs.getString(99));
        obj.setOlcImpUnder(stringToChar(rs.getString(100)));
        obj.setOlcImpPolicyDet(rs.getString(101));
        obj.setOlcImpRef(rs.getString(102));
        obj.setOlcCustLiabAcc(rs.getLong(103));
        obj.setOlcCancelledOn(rs.getDate(104));
        obj.setOlcUsanceCharges(rs.getDouble(105));
        obj.setOlcUsnChgTakenDays(rs.getInt(106));
        obj.setOlcCommitmentCharges(rs.getDouble(107));
        obj.setOlcCommitChgTakenDays(rs.getInt(108));
        obj.setTranchgsChgsSl(rs.getLong(109));
        obj.setTrancratesRateSl(rs.getLong(110));
        obj.setTranstlmntInvNum(rs.getLong(111));
        obj.setPostTranBrn(rs.getInt(112));
        obj.setPostTranDate(rs.getDate(113));
        obj.setPostTranBatchNum(rs.getInt(114));
        obj.setOlcEntdBy(rs.getString(115));
        obj.setOlcEntdOn(rs.getTimestamp(116));
        obj.setOlcLastmodBy(rs.getString(117));
        obj.setOlcLastmodOn(rs.getDate(118));
        obj.setOlcAuthBy(rs.getString(119));
        obj.setOlcAuthOn(rs.getDate(120));
        obj.setOlcRejBy(rs.getString(121));
        obj.setOlcRejOn(rs.getDate(122));
        obj.setOlcMarginCurr(rs.getString(123));
        obj.setOlcMarginAmt(rs.getDouble(124));
        obj.setOlcMarginBal(rs.getDouble(125));
        obj.setOlcCashMarAmt(rs.getDouble(126));
        obj.setOlcCashMarBal(rs.getDouble(127));
        obj.setOlcCashMarRec(rs.getDouble(128));
        obj.setOlcDepMarRec(rs.getDouble(129));
        obj.setOlcOthSecMarRec(rs.getDouble(130));
        obj.setOlcUsanceServTax(rs.getDouble(131));
        obj.setOlcCommitServTax(rs.getDouble(132));
        obj.setIsNew(false);
        obj.resetIsModifiedS2J();

        return obj;
    }

    private Olc decodeRow(ResultSet rs, int[] fieldList) throws SQLException {
        Olc obj = new Olc();
        int pos = 0;
        for(int i = 0; i < fieldList.length; i++) {
            switch(fieldList[i]) {
                case OLC_BRN_CODE: obj.setOlcBrnCode(rs.getInt(++pos));
                    break;
                case OLC_LC_TYPE: obj.setOlcLcType(rs.getString(++pos));
                    break;
                case OLC_LC_YEAR: obj.setOlcLcYear(rs.getInt(++pos));
                    break;
                case OLC_LC_SL: obj.setOlcLcSl(rs.getInt(++pos));
                    break;
                case OLC_CORR_REF_NUM: obj.setOlcCorrRefNum(rs.getString(++pos));
                    break;
                case OLC_LC_PRESANC_DATE: obj.setOlcLcPresancDate(rs.getDate(++pos));
                    break;
                case OLC_LC_PRESANC_DAY_SL: obj.setOlcLcPresancDaySl(rs.getInt(++pos));
                    break;
                case OLC_LC_DATE: obj.setOlcLcDate(rs.getDate(++pos));
                    break;
                case OLC_CUST_NUM: obj.setOlcCustNum(rs.getLong(++pos));
                    break;
                case OLC_BENEF_CODE: obj.setOlcBenefCode(rs.getString(++pos));
                    break;
                case OLC_BENEF_NAME: obj.setOlcBenefName(rs.getString(++pos));
                    break;
                case OLC_BENEF_ADDR1: obj.setOlcBenefAddr1(rs.getString(++pos));
                    break;
                case OLC_BENEF_ADDR2: obj.setOlcBenefAddr2(rs.getString(++pos));
                    break;
                case OLC_BENEF_ADDR3: obj.setOlcBenefAddr3(rs.getString(++pos));
                    break;
                case OLC_BENEF_ADDR4: obj.setOlcBenefAddr4(rs.getString(++pos));
                    break;
                case OLC_BENEF_ADDR5: obj.setOlcBenefAddr5(rs.getString(++pos));
                    break;
                case OLC_BENEF_CNTRY_CODE: obj.setOlcBenefCntryCode(rs.getString(++pos));
                    break;
                case OLC_LC_ISS_BK_CODE: obj.setOlcLcIssBkCode(rs.getString(++pos));
                    break;
                case OLC_LC_ISS_BRN_CODE: obj.setOlcLcIssBrnCode(rs.getString(++pos));
                    break;
                case OLC_LC_ISS_BRN_NAME: obj.setOlcLcIssBrnName(rs.getString(++pos));
                    break;
                case OLC_LC_ISS_BRN_ADD1: obj.setOlcLcIssBrnAdd1(rs.getString(++pos));
                    break;
                case OLC_LC_ISS_BRN_ADD2: obj.setOlcLcIssBrnAdd2(rs.getString(++pos));
                    break;
                case OLC_LC_ISS_BRN_ADD3: obj.setOlcLcIssBrnAdd3(rs.getString(++pos));
                    break;
                case OLC_LC_ISS_BRN_ADD4: obj.setOlcLcIssBrnAdd4(rs.getString(++pos));
                    break;
                case OLC_LC_ISS_BRN_ADD5: obj.setOlcLcIssBrnAdd5(rs.getString(++pos));
                    break;
                case OLC_LC_ISS_PLACE: obj.setOlcLcIssPlace(rs.getString(++pos));
                    break;
                case OLC_LC_ISS_CNTRY: obj.setOlcLcIssCntry(rs.getString(++pos));
                    break;
                case OLC_LC_ADV_THRU: obj.setOlcLcAdvThru(stringToChar(rs.getString(++pos)));
                    break;
                case OLC_LC_CURR_CODE: obj.setOlcLcCurrCode(rs.getString(++pos));
                    break;
                case OLC_LC_AMOUNT: obj.setOlcLcAmount(rs.getDouble(++pos));
                    break;
                case OLC_LC_BALANCE: obj.setOlcLcBalance(rs.getDouble(++pos));
                    break;
                case OLC_DEV_ALLWD: obj.setOlcDevAllwd(stringToChar(rs.getString(++pos)));
                    break;
                case OLC_POS_DEV_ALLWD: obj.setOlcPosDevAllwd(rs.getDouble(++pos));
                    break;
                case OLC_NEG_DEV_ALLWD: obj.setOlcNegDevAllwd(rs.getDouble(++pos));
                    break;
                case OLC_DEV_AMOUNT: obj.setOlcDevAmount(rs.getDouble(++pos));
                    break;
                case OLC_DEV_BAL: obj.setOlcDevBal(rs.getDouble(++pos));
                    break;
                case OLC_AMT_QUALFR: obj.setOlcAmtQualfr(stringToChar(rs.getString(++pos)));
                    break;
                case OLC_PRICE_TERMS: obj.setOlcPriceTerms(rs.getString(++pos));
                    break;
                case OLC_LAST_DATE_OF_NEG: obj.setOlcLastDateOfNeg(rs.getDate(++pos));
                    break;
                case OLC_PLACE_OF_EXPIRY: obj.setOlcPlaceOfExpiry(rs.getString(++pos));
                    break;
                case OLC_LATEST_DATE_OF_SHPMNT: obj.setOlcLatestDateOfShpmnt(rs.getDate(++pos));
                    break;
                case OLC_WITHIN_VALIDATE_LC: obj.setOlcWithinValidateLc(stringToChar(rs.getString(++pos)));
                    break;
                case OLC_LC_UI_BORNE_BY_APPLCNT: obj.setOlcLcUiBorneByApplcnt(stringToChar(rs.getString(++pos)));
                    break;
                case OLC_NOF_TENORS: obj.setOlcNofTenors(rs.getInt(++pos));
                    break;
                case OLC_LC_UNDER_CONTRACT: obj.setOlcLcUnderContract(stringToChar(rs.getString(++pos)));
                    break;
                case OLC_TOT_LIAB_LC_CURR: obj.setOlcTotLiabLcCurr(rs.getDouble(++pos));
                    break;
                case OLC_CONV_RATE_BASE_CURR: obj.setOlcConvRateBaseCurr(rs.getDouble(++pos));
                    break;
                case OLC_TOT_LIAB_BASE_CURR: obj.setOlcTotLiabBaseCurr(rs.getDouble(++pos));
                    break;
                case OLC_CONV_RATE_LIM_CURR: obj.setOlcConvRateLimCurr(rs.getDouble(++pos));
                    break;
                case OLC_TOT_LIAB_LIM_CURR: obj.setOlcTotLiabLimCurr(rs.getDouble(++pos));
                    break;
                case OLC_PAYMNT_CURR: obj.setOlcPaymntCurr(rs.getString(++pos));
                    break;
                case OLC_TOT_CHRGS_IN_PAYMNT_CURR: obj.setOlcTotChrgsInPaymntCurr(rs.getDouble(++pos));
                    break;
                case OLC_CASH_MARGIN_BAL: obj.setOlcCashMarginBal(rs.getDouble(++pos));
                    break;
                case OLC_REIMB_CHRGS_BY: obj.setOlcReimbChrgsBy(stringToChar(rs.getString(++pos)));
                    break;
                case OLC_PERC_RC_PAID_BY_APPLCNT: obj.setOlcPercRcPaidByApplcnt(rs.getDouble(++pos));
                    break;
                case OLC_NOSTRO_ALPHA_CODE: obj.setOlcNostroAlphaCode(rs.getString(++pos));
                    break;
                case OLC_ADV_THRU_BK: obj.setOlcAdvThruBk(rs.getString(++pos));
                    break;
                case OLC_ADV_THRU_BRN: obj.setOlcAdvThruBrn(rs.getString(++pos));
                    break;
                case OLC_LC_TO_BE_CNFRMD: obj.setOlcLcToBeCnfrmd(stringToChar(rs.getString(++pos)));
                    break;
                case OLC_LC_TO_BE_CNFRMD_BY_BK: obj.setOlcLcToBeCnfrmdByBk(rs.getString(++pos));
                    break;
                case OLC_LC_TO_BE_CNFRMD_BY_BRN: obj.setOlcLcToBeCnfrmdByBrn(rs.getString(++pos));
                    break;
                case OLC_RESTRICTED: obj.setOlcRestricted(stringToChar(rs.getString(++pos)));
                    break;
                case OLC_RESTRICTED_TO_US: obj.setOlcRestrictedToUs(stringToChar(rs.getString(++pos)));
                    break;
                case OLC_RESTRICTED_BK_CODE: obj.setOlcRestrictedBkCode(rs.getString(++pos));
                    break;
                case OLC_RESTRICTED_BRN_CODE: obj.setOlcRestrictedBrnCode(rs.getString(++pos));
                    break;
                case OLC_CR_AVLBL_BY: obj.setOlcCrAvlblBy(stringToChar(rs.getString(++pos)));
                    break;
                case OLC_IRREVOCABLE: obj.setOlcIrrevocable(stringToChar(rs.getString(++pos)));
                    break;
                case OLC_PART_SHPMNT: obj.setOlcPartShpmnt(stringToChar(rs.getString(++pos)));
                    break;
                case OLC_TRAN_SHPMNT: obj.setOlcTranShpmnt(stringToChar(rs.getString(++pos)));
                    break;
                case OLC_LC_TRANSFRBL: obj.setOlcLcTransfrbl(stringToChar(rs.getString(++pos)));
                    break;
                case OLC_DFT_REQD: obj.setOlcDftReqd(stringToChar(rs.getString(++pos)));
                    break;
                case OLC_PERC_DFT_VALUE: obj.setOlcPercDftValue(rs.getDouble(++pos));
                    break;
                case OLC_DFT_TO_BE_DRAWN_ON: obj.setOlcDftToBeDrawnOn(stringToChar(rs.getString(++pos)));
                    break;
                case OLC_DFT_ON_BK: obj.setOlcDftOnBk(rs.getString(++pos));
                    break;
                case OLC_DFT_ON_BRN: obj.setOlcDftOnBrn(rs.getString(++pos));
                    break;
                case OLC_SPEC_TEXT1: obj.setOlcSpecText1(rs.getString(++pos));
                    break;
                case OLC_SPEC_TEXT2: obj.setOlcSpecText2(rs.getString(++pos));
                    break;
                case OLC_SPEC_TEXT3: obj.setOlcSpecText3(rs.getString(++pos));
                    break;
                case OLC_SPEC_TEXT4: obj.setOlcSpecText4(rs.getString(++pos));
                    break;
                case OLC_PRIME_RATE_CLAUSE_REQ: obj.setOlcPrimeRateClauseReq(stringToChar(rs.getString(++pos)));
                    break;
                case OLC_SHPMNT_MODE: obj.setOlcShpmntMode(stringToChar(rs.getString(++pos)));
                    break;
                case OLC_LLOYDS_CLAUSE_REQ: obj.setOlcLloydsClauseReq(stringToChar(rs.getString(++pos)));
                    break;
                case OLC_MAX_SHIP_AGE: obj.setOlcMaxShipAge(rs.getInt(++pos));
                    break;
                case OLC_SHORT_FORM_OF_BL: obj.setOlcShortFormOfBl(stringToChar(rs.getString(++pos)));
                    break;
                case OLC_LASH_TRANS_DOCS_ALLWD: obj.setOlcLashTransDocsAllwd(stringToChar(rs.getString(++pos)));
                    break;
                case OLC_PERC_OF_INS_VALUE_CVRD: obj.setOlcPercOfInsValueCvrd(rs.getDouble(++pos));
                    break;
                case OLC_INS_POLICY_NUM: obj.setOlcInsPolicyNum(rs.getString(++pos));
                    break;
                case OLC_INS_DATE: obj.setOlcInsDate(rs.getDate(++pos));
                    break;
                case OLC_INS_CURR: obj.setOlcInsCurr(rs.getString(++pos));
                    break;
                case OLC_INS_AMT: obj.setOlcInsAmt(rs.getDouble(++pos));
                    break;
                case OLC_PREMIUM_CURR: obj.setOlcPremiumCurr(rs.getString(++pos));
                    break;
                case OLC_PREMIUM_AMT: obj.setOlcPremiumAmt(rs.getDouble(++pos));
                    break;
                case OLC_INS_COMPANY: obj.setOlcInsCompany(rs.getString(++pos));
                    break;
                case OLC_INS_COMPANY_NAME: obj.setOlcInsCompanyName(rs.getString(++pos));
                    break;
                case OLC_COO_ISS_BY: obj.setOlcCooIssBy(rs.getString(++pos));
                    break;
                case OLC_OTHER_COMP_AUTH: obj.setOlcOtherCompAuth(rs.getString(++pos));
                    break;
                case OLC_INTERMEDIARY_TRADE: obj.setOlcIntermediaryTrade(stringToChar(rs.getString(++pos)));
                    break;
                case OLC_INSP_TEST_CERT_REQ: obj.setOlcInspTestCertReq(stringToChar(rs.getString(++pos)));
                    break;
                case OLC_CERT_BY: obj.setOlcCertBy(rs.getString(++pos));
                    break;
                case OLC_IMP_UNDER: obj.setOlcImpUnder(stringToChar(rs.getString(++pos)));
                    break;
                case OLC_IMP_POLICY_DET: obj.setOlcImpPolicyDet(rs.getString(++pos));
                    break;
                case OLC_IMP_REF: obj.setOlcImpRef(rs.getString(++pos));
                    break;
                case OLC_CUST_LIAB_ACC: obj.setOlcCustLiabAcc(rs.getLong(++pos));
                    break;
                case OLC_CANCELLED_ON: obj.setOlcCancelledOn(rs.getDate(++pos));
                    break;
                case OLC_USANCE_CHARGES: obj.setOlcUsanceCharges(rs.getDouble(++pos));
                    break;
                case OLC_USN_CHG_TAKEN_DAYS: obj.setOlcUsnChgTakenDays(rs.getInt(++pos));
                    break;
                case OLC_COMMITMENT_CHARGES: obj.setOlcCommitmentCharges(rs.getDouble(++pos));
                    break;
                case OLC_COMMIT_CHG_TAKEN_DAYS: obj.setOlcCommitChgTakenDays(rs.getInt(++pos));
                    break;
                case TRANCHGS_CHGS_SL: obj.setTranchgsChgsSl(rs.getLong(++pos));
                    break;
                case TRANCRATES_RATE_SL: obj.setTrancratesRateSl(rs.getLong(++pos));
                    break;
                case TRANSTLMNT_INV_NUM: obj.setTranstlmntInvNum(rs.getLong(++pos));
                    break;
                case POST_TRAN_BRN: obj.setPostTranBrn(rs.getInt(++pos));
                    break;
                case POST_TRAN_DATE: obj.setPostTranDate(rs.getDate(++pos));
                    break;
                case POST_TRAN_BATCH_NUM: obj.setPostTranBatchNum(rs.getInt(++pos));
                    break;
                case OLC_ENTD_BY: obj.setOlcEntdBy(rs.getString(++pos));
                    break;
                case OLC_ENTD_ON: obj.setOlcEntdOn(rs.getTimestamp(++pos));
                    break;
                case OLC_LASTMOD_BY: obj.setOlcLastmodBy(rs.getString(++pos));
                    break;
                case OLC_LASTMOD_ON: obj.setOlcLastmodOn(rs.getDate(++pos));
                    break;
                case OLC_AUTH_BY: obj.setOlcAuthBy(rs.getString(++pos));
                    break;
                case OLC_AUTH_ON: obj.setOlcAuthOn(rs.getDate(++pos));
                    break;
                case OLC_REJ_BY: obj.setOlcRejBy(rs.getString(++pos));
                    break;
                case OLC_REJ_ON: obj.setOlcRejOn(rs.getDate(++pos));
                    break;
                case OLC_MARGIN_CURR: obj.setOlcMarginCurr(rs.getString(++pos));
                    break;
                case OLC_MARGIN_AMT: obj.setOlcMarginAmt(rs.getDouble(++pos));
                    break;
                case OLC_MARGIN_BAL: obj.setOlcMarginBal(rs.getDouble(++pos));
                    break;
                case OLC_CASH_MAR_AMT: obj.setOlcCashMarAmt(rs.getDouble(++pos));
                    break;
                case OLC_CASH_MAR_BAL: obj.setOlcCashMarBal(rs.getDouble(++pos));
                    break;
                case OLC_CASH_MAR_REC: obj.setOlcCashMarRec(rs.getDouble(++pos));
                    break;
                case OLC_DEP_MAR_REC: obj.setOlcDepMarRec(rs.getDouble(++pos));
                    break;
                case OLC_OTH_SEC_MAR_REC: obj.setOlcOthSecMarRec(rs.getDouble(++pos));
                    break;
                case OLC_USANCE_SERV_TAX: obj.setOlcUsanceServTax(rs.getDouble(++pos));
                    break;
                case OLC_COMMIT_SERV_TAX: obj.setOlcCommitServTax(rs.getDouble(++pos));
                    break;
            }
        }
        obj.setIsNew(false);
        obj.resetIsModifiedS2J();

        return obj;
    }
    public void save(Olc obj, String tba_main_key, Timestamp tba_entry_date, long tab_dtl_sl ) throws SQLException {
            NewData_Key = "OLC" + TableValueSep + NewDataChar + obj.getOlcBrnCode() + obj.getOlcLcType() + obj.getOlcLcYear() + obj.getOlcLcSl();
            DataBlock_New = obj.getOlcBrnCode() + JNDINames.splitchar + obj.getOlcLcType() + JNDINames.splitchar + obj.getOlcLcYear() + JNDINames.splitchar + obj.getOlcLcSl() + JNDINames.splitchar + obj.getOlcCorrRefNum() + JNDINames.splitchar + obj.getOlcLcPresancDate() + JNDINames.splitchar + obj.getOlcLcPresancDaySl() + JNDINames.splitchar + obj.getOlcLcDate() + JNDINames.splitchar + obj.getOlcCustNum() + JNDINames.splitchar + obj.getOlcBenefCode() + JNDINames.splitchar + obj.getOlcBenefName() + JNDINames.splitchar + obj.getOlcBenefAddr1() + JNDINames.splitchar + obj.getOlcBenefAddr2() + JNDINames.splitchar + obj.getOlcBenefAddr3() + JNDINames.splitchar + obj.getOlcBenefAddr4() + JNDINames.splitchar + obj.getOlcBenefAddr5() + JNDINames.splitchar + obj.getOlcBenefCntryCode() + JNDINames.splitchar + obj.getOlcLcIssBkCode() + JNDINames.splitchar + obj.getOlcLcIssBrnCode() + JNDINames.splitchar + obj.getOlcLcIssBrnName() + JNDINames.splitchar + obj.getOlcLcIssBrnAdd1() + JNDINames.splitchar + obj.getOlcLcIssBrnAdd2() + JNDINames.splitchar + obj.getOlcLcIssBrnAdd3() + JNDINames.splitchar + obj.getOlcLcIssBrnAdd4() + JNDINames.splitchar + obj.getOlcLcIssBrnAdd5() + JNDINames.splitchar + obj.getOlcLcIssPlace() + JNDINames.splitchar + obj.getOlcLcIssCntry() + JNDINames.splitchar + obj.getOlcLcAdvThru() + JNDINames.splitchar + obj.getOlcLcCurrCode() + JNDINames.splitchar + obj.getOlcLcAmount() + JNDINames.splitchar + obj.getOlcLcBalance() + JNDINames.splitchar + obj.getOlcDevAllwd() + JNDINames.splitchar + obj.getOlcPosDevAllwd() + JNDINames.splitchar + obj.getOlcNegDevAllwd() + JNDINames.splitchar + obj.getOlcDevAmount() + JNDINames.splitchar + obj.getOlcDevBal() + JNDINames.splitchar + obj.getOlcAmtQualfr() + JNDINames.splitchar + obj.getOlcPriceTerms() + JNDINames.splitchar + obj.getOlcLastDateOfNeg() + JNDINames.splitchar + obj.getOlcPlaceOfExpiry() + JNDINames.splitchar + obj.getOlcLatestDateOfShpmnt() + JNDINames.splitchar + obj.getOlcWithinValidateLc() + JNDINames.splitchar + obj.getOlcLcUiBorneByApplcnt() + JNDINames.splitchar + obj.getOlcNofTenors() + JNDINames.splitchar + obj.getOlcLcUnderContract() + JNDINames.splitchar + obj.getOlcTotLiabLcCurr() + JNDINames.splitchar + obj.getOlcConvRateBaseCurr() + JNDINames.splitchar + obj.getOlcTotLiabBaseCurr() + JNDINames.splitchar + obj.getOlcConvRateLimCurr() + JNDINames.splitchar + obj.getOlcTotLiabLimCurr() + JNDINames.splitchar + obj.getOlcPaymntCurr() + JNDINames.splitchar + obj.getOlcTotChrgsInPaymntCurr() + JNDINames.splitchar + obj.getOlcCashMarginBal() + JNDINames.splitchar + obj.getOlcReimbChrgsBy() + JNDINames.splitchar + obj.getOlcPercRcPaidByApplcnt() + JNDINames.splitchar + obj.getOlcNostroAlphaCode() + JNDINames.splitchar + obj.getOlcAdvThruBk() + JNDINames.splitchar + obj.getOlcAdvThruBrn() + JNDINames.splitchar + obj.getOlcLcToBeCnfrmd() + JNDINames.splitchar + obj.getOlcLcToBeCnfrmdByBk() + JNDINames.splitchar + obj.getOlcLcToBeCnfrmdByBrn() + JNDINames.splitchar + obj.getOlcRestricted() + JNDINames.splitchar + obj.getOlcRestrictedToUs() + JNDINames.splitchar + obj.getOlcRestrictedBkCode() + JNDINames.splitchar + obj.getOlcRestrictedBrnCode() + JNDINames.splitchar + obj.getOlcCrAvlblBy() + JNDINames.splitchar + obj.getOlcIrrevocable() + JNDINames.splitchar + obj.getOlcPartShpmnt() + JNDINames.splitchar + obj.getOlcTranShpmnt() + JNDINames.splitchar + obj.getOlcLcTransfrbl() + JNDINames.splitchar + obj.getOlcDftReqd() + JNDINames.splitchar + obj.getOlcPercDftValue() + JNDINames.splitchar + obj.getOlcDftToBeDrawnOn() + JNDINames.splitchar + obj.getOlcDftOnBk() + JNDINames.splitchar + obj.getOlcDftOnBrn() + JNDINames.splitchar + obj.getOlcSpecText1() + JNDINames.splitchar + obj.getOlcSpecText2() + JNDINames.splitchar + obj.getOlcSpecText3() + JNDINames.splitchar + obj.getOlcSpecText4() + JNDINames.splitchar + obj.getOlcPrimeRateClauseReq() + JNDINames.splitchar + obj.getOlcShpmntMode() + JNDINames.splitchar + obj.getOlcLloydsClauseReq() + JNDINames.splitchar + obj.getOlcMaxShipAge() + JNDINames.splitchar + obj.getOlcShortFormOfBl() + JNDINames.splitchar + obj.getOlcLashTransDocsAllwd() + JNDINames.splitchar + obj.getOlcPercOfInsValueCvrd() + JNDINames.splitchar + obj.getOlcInsPolicyNum() + JNDINames.splitchar + obj.getOlcInsDate() + JNDINames.splitchar + obj.getOlcInsCurr() + JNDINames.splitchar + obj.getOlcInsAmt() + JNDINames.splitchar + obj.getOlcPremiumCurr() + JNDINames.splitchar + obj.getOlcPremiumAmt() + JNDINames.splitchar + obj.getOlcInsCompany() + JNDINames.splitchar + obj.getOlcInsCompanyName() + JNDINames.splitchar + obj.getOlcCooIssBy() + JNDINames.splitchar + obj.getOlcOtherCompAuth() + JNDINames.splitchar + obj.getOlcIntermediaryTrade() + JNDINames.splitchar + obj.getOlcInspTestCertReq() + JNDINames.splitchar + obj.getOlcCertBy() + JNDINames.splitchar + obj.getOlcImpUnder() + JNDINames.splitchar + obj.getOlcImpPolicyDet() + JNDINames.splitchar + obj.getOlcImpRef() + JNDINames.splitchar + obj.getOlcCustLiabAcc() + JNDINames.splitchar + obj.getOlcCancelledOn() + JNDINames.splitchar + obj.getOlcUsanceCharges() + JNDINames.splitchar + obj.getOlcUsnChgTakenDays() + JNDINames.splitchar + obj.getOlcCommitmentCharges() + JNDINames.splitchar + obj.getOlcCommitChgTakenDays() + JNDINames.splitchar + obj.getTranchgsChgsSl() + JNDINames.splitchar + obj.getTrancratesRateSl() + JNDINames.splitchar + obj.getTranstlmntInvNum() + JNDINames.splitchar + obj.getPostTranBrn() + JNDINames.splitchar + obj.getPostTranDate() + JNDINames.splitchar + obj.getPostTranBatchNum() + JNDINames.splitchar + obj.getOlcEntdBy() + JNDINames.splitchar + obj.getOlcEntdOn() + JNDINames.splitchar + obj.getOlcLastmodBy() + JNDINames.splitchar + obj.getOlcLastmodOn() + JNDINames.splitchar + obj.getOlcAuthBy() + JNDINames.splitchar + obj.getOlcAuthOn() + JNDINames.splitchar + obj.getOlcRejBy() + JNDINames.splitchar + obj.getOlcRejOn() + JNDINames.splitchar + obj.getOlcMarginCurr() + JNDINames.splitchar + obj.getOlcMarginAmt() + JNDINames.splitchar + obj.getOlcMarginBal() + JNDINames.splitchar + obj.getOlcCashMarAmt() + JNDINames.splitchar + obj.getOlcCashMarBal() + JNDINames.splitchar + obj.getOlcCashMarRec() + JNDINames.splitchar + obj.getOlcDepMarRec() + JNDINames.splitchar + obj.getOlcOthSecMarRec() + JNDINames.splitchar + obj.getOlcUsanceServTax() + JNDINames.splitchar + obj.getOlcCommitServTax();
                if (_Logreq == 1)
                {
                    if (obj.isNew() == false)
                    {
                        if (OldData_Key != null) this._COLLECTIONobj.put(OldData_Key , DataBlock_Old );
                        if (NewData_Key != null) this._COLLECTIONobj.put(NewData_Key , DataBlock_New );
                    }else if ((_Logaddreq == 1) && obj.isNew() == true)
                    {
                        if (NewData_Key != null) this._COLLECTIONobj.put(NewData_Key , DataBlock_New );
                    }
                }
            OldData_Key ="";
            DataBlock_Old = "";
            DataBlock_New = "";
            NewData_Key = "";
        {
    // This is for main table Updation
            save(obj);
        }
    }

}
