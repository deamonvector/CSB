package panacea.OLC.Update;


/******************SQL2JAVA_IMPORT_BEGIN******************/

/******************SQL2JAVA_IMPORT_END********************/


public class Olc
/******************SQL2JAVA_EXTENDS_BEGIN******************/

/******************SQL2JAVA_EXTENDS_END********************/

{

/******************SQL2JAVA_CLASS_BEGIN******************/

/******************SQL2JAVA_CLASS_END********************/


    private int _olcBrnCode;
    private boolean __olcBrnCode_is_modified;
    private String _olcLcType;
    private boolean __olcLcType_is_modified;
    private int _olcLcYear;
    private boolean __olcLcYear_is_modified;
    private int _olcLcSl;
    private boolean __olcLcSl_is_modified;
    private String _olcCorrRefNum;
    private boolean __olcCorrRefNum_is_modified;
    private java.util.Date _olcLcPresancDate;
    private boolean __olcLcPresancDate_is_modified;
    private int _olcLcPresancDaySl;
    private boolean __olcLcPresancDaySl_is_modified;
    private java.util.Date _olcLcDate;
    private boolean __olcLcDate_is_modified;
    private long _olcCustNum;
    private boolean __olcCustNum_is_modified;
    private String _olcBenefCode;
    private boolean __olcBenefCode_is_modified;
    private String _olcBenefName;
    private boolean __olcBenefName_is_modified;
    private String _olcBenefAddr1;
    private boolean __olcBenefAddr1_is_modified;
    private String _olcBenefAddr2;
    private boolean __olcBenefAddr2_is_modified;
    private String _olcBenefAddr3;
    private boolean __olcBenefAddr3_is_modified;
    private String _olcBenefAddr4;
    private boolean __olcBenefAddr4_is_modified;
    private String _olcBenefAddr5;
    private boolean __olcBenefAddr5_is_modified;
    private String _olcBenefCntryCode;
    private boolean __olcBenefCntryCode_is_modified;
    private String _olcLcIssBkCode;
    private boolean __olcLcIssBkCode_is_modified;
    private String _olcLcIssBrnCode;
    private boolean __olcLcIssBrnCode_is_modified;
    private String _olcLcIssBrnName;
    private boolean __olcLcIssBrnName_is_modified;
    private String _olcLcIssBrnAdd1;
    private boolean __olcLcIssBrnAdd1_is_modified;
    private String _olcLcIssBrnAdd2;
    private boolean __olcLcIssBrnAdd2_is_modified;
    private String _olcLcIssBrnAdd3;
    private boolean __olcLcIssBrnAdd3_is_modified;
    private String _olcLcIssBrnAdd4;
    private boolean __olcLcIssBrnAdd4_is_modified;
    private String _olcLcIssBrnAdd5;
    private boolean __olcLcIssBrnAdd5_is_modified;
    private String _olcLcIssPlace;
    private boolean __olcLcIssPlace_is_modified;
    private String _olcLcIssCntry;
    private boolean __olcLcIssCntry_is_modified;
    private char _olcLcAdvThru;
    private boolean __olcLcAdvThru_is_modified;
    private String _olcLcCurrCode;
    private boolean __olcLcCurrCode_is_modified;
    private double _olcLcAmount;
    private boolean __olcLcAmount_is_modified;
    private double _olcLcBalance;
    private boolean __olcLcBalance_is_modified;
    private char _olcDevAllwd;
    private boolean __olcDevAllwd_is_modified;
    private double _olcPosDevAllwd;
    private boolean __olcPosDevAllwd_is_modified;
    private double _olcNegDevAllwd;
    private boolean __olcNegDevAllwd_is_modified;
    private double _olcDevAmount;
    private boolean __olcDevAmount_is_modified;
    private double _olcDevBal;
    private boolean __olcDevBal_is_modified;
    private char _olcAmtQualfr;
    private boolean __olcAmtQualfr_is_modified;
    private String _olcPriceTerms;
    private boolean __olcPriceTerms_is_modified;
    private java.util.Date _olcLastDateOfNeg;
    private boolean __olcLastDateOfNeg_is_modified;
    private String _olcPlaceOfExpiry;
    private boolean __olcPlaceOfExpiry_is_modified;
    private java.util.Date _olcLatestDateOfShpmnt;
    private boolean __olcLatestDateOfShpmnt_is_modified;
    private char _olcWithinValidateLc;
    private boolean __olcWithinValidateLc_is_modified;
    private char _olcLcUiBorneByApplcnt;
    private boolean __olcLcUiBorneByApplcnt_is_modified;
    private int _olcNofTenors;
    private boolean __olcNofTenors_is_modified;
    private char _olcLcUnderContract;
    private boolean __olcLcUnderContract_is_modified;
    private double _olcTotLiabLcCurr;
    private boolean __olcTotLiabLcCurr_is_modified;
    private double _olcConvRateBaseCurr;
    private boolean __olcConvRateBaseCurr_is_modified;
    private double _olcTotLiabBaseCurr;
    private boolean __olcTotLiabBaseCurr_is_modified;
    private double _olcConvRateLimCurr;
    private boolean __olcConvRateLimCurr_is_modified;
    private double _olcTotLiabLimCurr;
    private boolean __olcTotLiabLimCurr_is_modified;
    private String _olcPaymntCurr;
    private boolean __olcPaymntCurr_is_modified;
    private double _olcTotChrgsInPaymntCurr;
    private boolean __olcTotChrgsInPaymntCurr_is_modified;
    private double _olcCashMarginBal;
    private boolean __olcCashMarginBal_is_modified;
    private char _olcReimbChrgsBy;
    private boolean __olcReimbChrgsBy_is_modified;
    private double _olcPercRcPaidByApplcnt;
    private boolean __olcPercRcPaidByApplcnt_is_modified;
    private String _olcNostroAlphaCode;
    private boolean __olcNostroAlphaCode_is_modified;
    private String _olcAdvThruBk;
    private boolean __olcAdvThruBk_is_modified;
    private String _olcAdvThruBrn;
    private boolean __olcAdvThruBrn_is_modified;
    private char _olcLcToBeCnfrmd;
    private boolean __olcLcToBeCnfrmd_is_modified;
    private String _olcLcToBeCnfrmdByBk;
    private boolean __olcLcToBeCnfrmdByBk_is_modified;
    private String _olcLcToBeCnfrmdByBrn;
    private boolean __olcLcToBeCnfrmdByBrn_is_modified;
    private char _olcRestricted;
    private boolean __olcRestricted_is_modified;
    private char _olcRestrictedToUs;
    private boolean __olcRestrictedToUs_is_modified;
    private String _olcRestrictedBkCode;
    private boolean __olcRestrictedBkCode_is_modified;
    private String _olcRestrictedBrnCode;
    private boolean __olcRestrictedBrnCode_is_modified;
    private char _olcCrAvlblBy;
    private boolean __olcCrAvlblBy_is_modified;
    private char _olcIrrevocable;
    private boolean __olcIrrevocable_is_modified;
    private char _olcPartShpmnt;
    private boolean __olcPartShpmnt_is_modified;
    private char _olcTranShpmnt;
    private boolean __olcTranShpmnt_is_modified;
    private char _olcLcTransfrbl;
    private boolean __olcLcTransfrbl_is_modified;
    private char _olcDftReqd;
    private boolean __olcDftReqd_is_modified;
    private double _olcPercDftValue;
    private boolean __olcPercDftValue_is_modified;
    private char _olcDftToBeDrawnOn;
    private boolean __olcDftToBeDrawnOn_is_modified;
    private String _olcDftOnBk;
    private boolean __olcDftOnBk_is_modified;
    private String _olcDftOnBrn;
    private boolean __olcDftOnBrn_is_modified;
    private String _olcSpecText1;
    private boolean __olcSpecText1_is_modified;
    private String _olcSpecText2;
    private boolean __olcSpecText2_is_modified;
    private String _olcSpecText3;
    private boolean __olcSpecText3_is_modified;
    private String _olcSpecText4;
    private boolean __olcSpecText4_is_modified;
    private char _olcPrimeRateClauseReq;
    private boolean __olcPrimeRateClauseReq_is_modified;
    private char _olcShpmntMode;
    private boolean __olcShpmntMode_is_modified;
    private char _olcLloydsClauseReq;
    private boolean __olcLloydsClauseReq_is_modified;
    private int _olcMaxShipAge;
    private boolean __olcMaxShipAge_is_modified;
    private char _olcShortFormOfBl;
    private boolean __olcShortFormOfBl_is_modified;
    private char _olcLashTransDocsAllwd;
    private boolean __olcLashTransDocsAllwd_is_modified;
    private double _olcPercOfInsValueCvrd;
    private boolean __olcPercOfInsValueCvrd_is_modified;
    private String _olcInsPolicyNum;
    private boolean __olcInsPolicyNum_is_modified;
    private java.util.Date _olcInsDate;
    private boolean __olcInsDate_is_modified;
    private String _olcInsCurr;
    private boolean __olcInsCurr_is_modified;
    private double _olcInsAmt;
    private boolean __olcInsAmt_is_modified;
    private String _olcPremiumCurr;
    private boolean __olcPremiumCurr_is_modified;
    private double _olcPremiumAmt;
    private boolean __olcPremiumAmt_is_modified;
    private String _olcInsCompany;
    private boolean __olcInsCompany_is_modified;
    private String _olcInsCompanyName;
    private boolean __olcInsCompanyName_is_modified;
    private String _olcCooIssBy;
    private boolean __olcCooIssBy_is_modified;
    private String _olcOtherCompAuth;
    private boolean __olcOtherCompAuth_is_modified;
    private char _olcIntermediaryTrade;
    private boolean __olcIntermediaryTrade_is_modified;
    private char _olcInspTestCertReq;
    private boolean __olcInspTestCertReq_is_modified;
    private String _olcCertBy;
    private boolean __olcCertBy_is_modified;
    private char _olcImpUnder;
    private boolean __olcImpUnder_is_modified;
    private String _olcImpPolicyDet;
    private boolean __olcImpPolicyDet_is_modified;
    private String _olcImpRef;
    private boolean __olcImpRef_is_modified;
    private long _olcCustLiabAcc;
    private boolean __olcCustLiabAcc_is_modified;
    private java.util.Date _olcCancelledOn;
    private boolean __olcCancelledOn_is_modified;
    private double _olcUsanceCharges;
    private boolean __olcUsanceCharges_is_modified;
    private int _olcUsnChgTakenDays;
    private boolean __olcUsnChgTakenDays_is_modified;
    private double _olcCommitmentCharges;
    private boolean __olcCommitmentCharges_is_modified;
    private int _olcCommitChgTakenDays;
    private boolean __olcCommitChgTakenDays_is_modified;
    private long _tranchgsChgsSl;
    private boolean __tranchgsChgsSl_is_modified;
    private long _trancratesRateSl;
    private boolean __trancratesRateSl_is_modified;
    private long _transtlmntInvNum;
    private boolean __transtlmntInvNum_is_modified;
    private int _postTranBrn;
    private boolean __postTranBrn_is_modified;
    private java.util.Date _postTranDate;
    private boolean __postTranDate_is_modified;
    private int _postTranBatchNum;
    private boolean __postTranBatchNum_is_modified;
    private String _olcEntdBy;
    private boolean __olcEntdBy_is_modified;
    private java.util.Date _olcEntdOn;
    private boolean __olcEntdOn_is_modified;
    private String _olcLastmodBy;
    private boolean __olcLastmodBy_is_modified;
    private java.util.Date _olcLastmodOn;
    private boolean __olcLastmodOn_is_modified;
    private String _olcAuthBy;
    private boolean __olcAuthBy_is_modified;
    private java.util.Date _olcAuthOn;
    private boolean __olcAuthOn_is_modified;
    private String _olcRejBy;
    private boolean __olcRejBy_is_modified;
    private java.util.Date _olcRejOn;
    private boolean __olcRejOn_is_modified;
    private String _olcMarginCurr;
    private boolean __olcMarginCurr_is_modified;
    private double _olcMarginAmt;
    private boolean __olcMarginAmt_is_modified;
    private double _olcMarginBal;
    private boolean __olcMarginBal_is_modified;
    private double _olcCashMarAmt;
    private boolean __olcCashMarAmt_is_modified;
    private double _olcCashMarBal;
    private boolean __olcCashMarBal_is_modified;
    private double _olcCashMarRec;
    private boolean __olcCashMarRec_is_modified;
    private double _olcDepMarRec;
    private boolean __olcDepMarRec_is_modified;
    private double _olcOthSecMarRec;
    private boolean __olcOthSecMarRec_is_modified;
    private double _olcUsanceServTax;
    private boolean __olcUsanceServTax_is_modified;
    private double _olcCommitServTax;
    private boolean __olcCommitServTax_is_modified;
    private boolean _isNew = true;

    public int getOlcBrnCode() { return _olcBrnCode; }
    public void setOlcBrnCode(int newVal) { this._olcBrnCode = newVal; __olcBrnCode_is_modified = true; }
    public boolean olcBrnCodeIsModifiedS2j() { return __olcBrnCode_is_modified; }
    public String getOlcLcType() { return _olcLcType; }
    public void setOlcLcType(String newVal) { this._olcLcType = newVal; __olcLcType_is_modified = true; }
    public boolean olcLcTypeIsModifiedS2j() { return __olcLcType_is_modified; }
    public int getOlcLcYear() { return _olcLcYear; }
    public void setOlcLcYear(int newVal) { this._olcLcYear = newVal; __olcLcYear_is_modified = true; }
    public boolean olcLcYearIsModifiedS2j() { return __olcLcYear_is_modified; }
    public int getOlcLcSl() { return _olcLcSl; }
    public void setOlcLcSl(int newVal) { this._olcLcSl = newVal; __olcLcSl_is_modified = true; }
    public boolean olcLcSlIsModifiedS2j() { return __olcLcSl_is_modified; }
    public String getOlcCorrRefNum() { return _olcCorrRefNum == null ? "" : _olcCorrRefNum.trim(); }
    public void setOlcCorrRefNum(String newVal) { this._olcCorrRefNum = newVal; __olcCorrRefNum_is_modified = true; }
    public boolean olcCorrRefNumIsModifiedS2j() { return __olcCorrRefNum_is_modified; }
    public java.util.Date getOlcLcPresancDate() { return _olcLcPresancDate; }
    public void setOlcLcPresancDate(java.util.Date newVal) { this._olcLcPresancDate = newVal; __olcLcPresancDate_is_modified = true; }
    public boolean olcLcPresancDateIsModifiedS2j() { return __olcLcPresancDate_is_modified; }
    public int getOlcLcPresancDaySl() { return _olcLcPresancDaySl; }
    public void setOlcLcPresancDaySl(int newVal) { this._olcLcPresancDaySl = newVal; __olcLcPresancDaySl_is_modified = true; }
    public boolean olcLcPresancDaySlIsModifiedS2j() { return __olcLcPresancDaySl_is_modified; }
    public java.util.Date getOlcLcDate() { return _olcLcDate; }
    public void setOlcLcDate(java.util.Date newVal) { this._olcLcDate = newVal; __olcLcDate_is_modified = true; }
    public boolean olcLcDateIsModifiedS2j() { return __olcLcDate_is_modified; }
    public long getOlcCustNum() { return _olcCustNum; }
    public void setOlcCustNum(long newVal) { this._olcCustNum = newVal; __olcCustNum_is_modified = true; }
    public boolean olcCustNumIsModifiedS2j() { return __olcCustNum_is_modified; }
    public String getOlcBenefCode() { return _olcBenefCode == null ? "" : _olcBenefCode.trim(); }
    public void setOlcBenefCode(String newVal) { this._olcBenefCode = newVal; __olcBenefCode_is_modified = true; }
    public boolean olcBenefCodeIsModifiedS2j() { return __olcBenefCode_is_modified; }
    public String getOlcBenefName() { return _olcBenefName == null ? "" : _olcBenefName.trim(); }
    public void setOlcBenefName(String newVal) { this._olcBenefName = newVal; __olcBenefName_is_modified = true; }
    public boolean olcBenefNameIsModifiedS2j() { return __olcBenefName_is_modified; }
    public String getOlcBenefAddr1() { return _olcBenefAddr1 == null ? "" : _olcBenefAddr1.trim(); }
    public void setOlcBenefAddr1(String newVal) { this._olcBenefAddr1 = newVal; __olcBenefAddr1_is_modified = true; }
    public boolean olcBenefAddr1IsModifiedS2j() { return __olcBenefAddr1_is_modified; }
    public String getOlcBenefAddr2() { return _olcBenefAddr2 == null ? "" : _olcBenefAddr2.trim(); }
    public void setOlcBenefAddr2(String newVal) { this._olcBenefAddr2 = newVal; __olcBenefAddr2_is_modified = true; }
    public boolean olcBenefAddr2IsModifiedS2j() { return __olcBenefAddr2_is_modified; }
    public String getOlcBenefAddr3() { return _olcBenefAddr3 == null ? "" : _olcBenefAddr3.trim(); }
    public void setOlcBenefAddr3(String newVal) { this._olcBenefAddr3 = newVal; __olcBenefAddr3_is_modified = true; }
    public boolean olcBenefAddr3IsModifiedS2j() { return __olcBenefAddr3_is_modified; }
    public String getOlcBenefAddr4() { return _olcBenefAddr4 == null ? "" : _olcBenefAddr4.trim(); }
    public void setOlcBenefAddr4(String newVal) { this._olcBenefAddr4 = newVal; __olcBenefAddr4_is_modified = true; }
    public boolean olcBenefAddr4IsModifiedS2j() { return __olcBenefAddr4_is_modified; }
    public String getOlcBenefAddr5() { return _olcBenefAddr5 == null ? "" : _olcBenefAddr5.trim(); }
    public void setOlcBenefAddr5(String newVal) { this._olcBenefAddr5 = newVal; __olcBenefAddr5_is_modified = true; }
    public boolean olcBenefAddr5IsModifiedS2j() { return __olcBenefAddr5_is_modified; }
    public String getOlcBenefCntryCode() { return _olcBenefCntryCode == null ? "" : _olcBenefCntryCode.trim(); }
    public void setOlcBenefCntryCode(String newVal) { this._olcBenefCntryCode = newVal; __olcBenefCntryCode_is_modified = true; }
    public boolean olcBenefCntryCodeIsModifiedS2j() { return __olcBenefCntryCode_is_modified; }
    public String getOlcLcIssBkCode() { return _olcLcIssBkCode == null ? "" : _olcLcIssBkCode.trim(); }
    public void setOlcLcIssBkCode(String newVal) { this._olcLcIssBkCode = newVal; __olcLcIssBkCode_is_modified = true; }
    public boolean olcLcIssBkCodeIsModifiedS2j() { return __olcLcIssBkCode_is_modified; }
    public String getOlcLcIssBrnCode() { return _olcLcIssBrnCode == null ? "" : _olcLcIssBrnCode.trim(); }
    public void setOlcLcIssBrnCode(String newVal) { this._olcLcIssBrnCode = newVal; __olcLcIssBrnCode_is_modified = true; }
    public boolean olcLcIssBrnCodeIsModifiedS2j() { return __olcLcIssBrnCode_is_modified; }
    public String getOlcLcIssBrnName() { return _olcLcIssBrnName == null ? "" : _olcLcIssBrnName.trim(); }
    public void setOlcLcIssBrnName(String newVal) { this._olcLcIssBrnName = newVal; __olcLcIssBrnName_is_modified = true; }
    public boolean olcLcIssBrnNameIsModifiedS2j() { return __olcLcIssBrnName_is_modified; }
    public String getOlcLcIssBrnAdd1() { return _olcLcIssBrnAdd1 == null ? "" : _olcLcIssBrnAdd1.trim(); }
    public void setOlcLcIssBrnAdd1(String newVal) { this._olcLcIssBrnAdd1 = newVal; __olcLcIssBrnAdd1_is_modified = true; }
    public boolean olcLcIssBrnAdd1IsModifiedS2j() { return __olcLcIssBrnAdd1_is_modified; }
    public String getOlcLcIssBrnAdd2() { return _olcLcIssBrnAdd2 == null ? "" : _olcLcIssBrnAdd2.trim(); }
    public void setOlcLcIssBrnAdd2(String newVal) { this._olcLcIssBrnAdd2 = newVal; __olcLcIssBrnAdd2_is_modified = true; }
    public boolean olcLcIssBrnAdd2IsModifiedS2j() { return __olcLcIssBrnAdd2_is_modified; }
    public String getOlcLcIssBrnAdd3() { return _olcLcIssBrnAdd3 == null ? "" : _olcLcIssBrnAdd3.trim(); }
    public void setOlcLcIssBrnAdd3(String newVal) { this._olcLcIssBrnAdd3 = newVal; __olcLcIssBrnAdd3_is_modified = true; }
    public boolean olcLcIssBrnAdd3IsModifiedS2j() { return __olcLcIssBrnAdd3_is_modified; }
    public String getOlcLcIssBrnAdd4() { return _olcLcIssBrnAdd4 == null ? "" : _olcLcIssBrnAdd4.trim(); }
    public void setOlcLcIssBrnAdd4(String newVal) { this._olcLcIssBrnAdd4 = newVal; __olcLcIssBrnAdd4_is_modified = true; }
    public boolean olcLcIssBrnAdd4IsModifiedS2j() { return __olcLcIssBrnAdd4_is_modified; }
    public String getOlcLcIssBrnAdd5() { return _olcLcIssBrnAdd5 == null ? "" : _olcLcIssBrnAdd5.trim(); }
    public void setOlcLcIssBrnAdd5(String newVal) { this._olcLcIssBrnAdd5 = newVal; __olcLcIssBrnAdd5_is_modified = true; }
    public boolean olcLcIssBrnAdd5IsModifiedS2j() { return __olcLcIssBrnAdd5_is_modified; }
    public String getOlcLcIssPlace() { return _olcLcIssPlace == null ? "" : _olcLcIssPlace.trim(); }
    public void setOlcLcIssPlace(String newVal) { this._olcLcIssPlace = newVal; __olcLcIssPlace_is_modified = true; }
    public boolean olcLcIssPlaceIsModifiedS2j() { return __olcLcIssPlace_is_modified; }
    public String getOlcLcIssCntry() { return _olcLcIssCntry == null ? "" : _olcLcIssCntry.trim(); }
    public void setOlcLcIssCntry(String newVal) { this._olcLcIssCntry = newVal; __olcLcIssCntry_is_modified = true; }
    public boolean olcLcIssCntryIsModifiedS2j() { return __olcLcIssCntry_is_modified; }
    public char getOlcLcAdvThru() { return _olcLcAdvThru; }
    public void setOlcLcAdvThru(char newVal) { this._olcLcAdvThru = newVal; __olcLcAdvThru_is_modified = true; }
    public boolean olcLcAdvThruIsModifiedS2j() { return __olcLcAdvThru_is_modified; }
    public String getOlcLcCurrCode() { return _olcLcCurrCode == null ? "" : _olcLcCurrCode.trim(); }
    public void setOlcLcCurrCode(String newVal) { this._olcLcCurrCode = newVal; __olcLcCurrCode_is_modified = true; }
    public boolean olcLcCurrCodeIsModifiedS2j() { return __olcLcCurrCode_is_modified; }
    public double getOlcLcAmount() { return _olcLcAmount; }
    public void setOlcLcAmount(double newVal) { this._olcLcAmount = newVal; __olcLcAmount_is_modified = true; }
    public boolean olcLcAmountIsModifiedS2j() { return __olcLcAmount_is_modified; }
    public double getOlcLcBalance() { return _olcLcBalance; }
    public void setOlcLcBalance(double newVal) { this._olcLcBalance = newVal; __olcLcBalance_is_modified = true; }
    public boolean olcLcBalanceIsModifiedS2j() { return __olcLcBalance_is_modified; }
    public char getOlcDevAllwd() { return _olcDevAllwd; }
    public void setOlcDevAllwd(char newVal) { this._olcDevAllwd = newVal; __olcDevAllwd_is_modified = true; }
    public boolean olcDevAllwdIsModifiedS2j() { return __olcDevAllwd_is_modified; }
    public double getOlcPosDevAllwd() { return _olcPosDevAllwd; }
    public void setOlcPosDevAllwd(double newVal) { this._olcPosDevAllwd = newVal; __olcPosDevAllwd_is_modified = true; }
    public boolean olcPosDevAllwdIsModifiedS2j() { return __olcPosDevAllwd_is_modified; }
    public double getOlcNegDevAllwd() { return _olcNegDevAllwd; }
    public void setOlcNegDevAllwd(double newVal) { this._olcNegDevAllwd = newVal; __olcNegDevAllwd_is_modified = true; }
    public boolean olcNegDevAllwdIsModifiedS2j() { return __olcNegDevAllwd_is_modified; }
    public double getOlcDevAmount() { return _olcDevAmount; }
    public void setOlcDevAmount(double newVal) { this._olcDevAmount = newVal; __olcDevAmount_is_modified = true; }
    public boolean olcDevAmountIsModifiedS2j() { return __olcDevAmount_is_modified; }
    public double getOlcDevBal() { return _olcDevBal; }
    public void setOlcDevBal(double newVal) { this._olcDevBal = newVal; __olcDevBal_is_modified = true; }
    public boolean olcDevBalIsModifiedS2j() { return __olcDevBal_is_modified; }
    public char getOlcAmtQualfr() { return _olcAmtQualfr; }
    public void setOlcAmtQualfr(char newVal) { this._olcAmtQualfr = newVal; __olcAmtQualfr_is_modified = true; }
    public boolean olcAmtQualfrIsModifiedS2j() { return __olcAmtQualfr_is_modified; }
    public String getOlcPriceTerms() { return _olcPriceTerms == null ? "" : _olcPriceTerms.trim(); }
    public void setOlcPriceTerms(String newVal) { this._olcPriceTerms = newVal; __olcPriceTerms_is_modified = true; }
    public boolean olcPriceTermsIsModifiedS2j() { return __olcPriceTerms_is_modified; }
    public java.util.Date getOlcLastDateOfNeg() { return _olcLastDateOfNeg; }
    public void setOlcLastDateOfNeg(java.util.Date newVal) { this._olcLastDateOfNeg = newVal; __olcLastDateOfNeg_is_modified = true; }
    public boolean olcLastDateOfNegIsModifiedS2j() { return __olcLastDateOfNeg_is_modified; }
    public String getOlcPlaceOfExpiry() { return _olcPlaceOfExpiry == null ? "" : _olcPlaceOfExpiry.trim(); }
    public void setOlcPlaceOfExpiry(String newVal) { this._olcPlaceOfExpiry = newVal; __olcPlaceOfExpiry_is_modified = true; }
    public boolean olcPlaceOfExpiryIsModifiedS2j() { return __olcPlaceOfExpiry_is_modified; }
    public java.util.Date getOlcLatestDateOfShpmnt() { return _olcLatestDateOfShpmnt; }
    public void setOlcLatestDateOfShpmnt(java.util.Date newVal) { this._olcLatestDateOfShpmnt = newVal; __olcLatestDateOfShpmnt_is_modified = true; }
    public boolean olcLatestDateOfShpmntIsModifiedS2j() { return __olcLatestDateOfShpmnt_is_modified; }
    public char getOlcWithinValidateLc() { return _olcWithinValidateLc; }
    public void setOlcWithinValidateLc(char newVal) { this._olcWithinValidateLc = newVal; __olcWithinValidateLc_is_modified = true; }
    public boolean olcWithinValidateLcIsModifiedS2j() { return __olcWithinValidateLc_is_modified; }
    public char getOlcLcUiBorneByApplcnt() { return _olcLcUiBorneByApplcnt; }
    public void setOlcLcUiBorneByApplcnt(char newVal) { this._olcLcUiBorneByApplcnt = newVal; __olcLcUiBorneByApplcnt_is_modified = true; }
    public boolean olcLcUiBorneByApplcntIsModifiedS2j() { return __olcLcUiBorneByApplcnt_is_modified; }
    public int getOlcNofTenors() { return _olcNofTenors; }
    public void setOlcNofTenors(int newVal) { this._olcNofTenors = newVal; __olcNofTenors_is_modified = true; }
    public boolean olcNofTenorsIsModifiedS2j() { return __olcNofTenors_is_modified; }
    public char getOlcLcUnderContract() { return _olcLcUnderContract; }
    public void setOlcLcUnderContract(char newVal) { this._olcLcUnderContract = newVal; __olcLcUnderContract_is_modified = true; }
    public boolean olcLcUnderContractIsModifiedS2j() { return __olcLcUnderContract_is_modified; }
    public double getOlcTotLiabLcCurr() { return _olcTotLiabLcCurr; }
    public void setOlcTotLiabLcCurr(double newVal) { this._olcTotLiabLcCurr = newVal; __olcTotLiabLcCurr_is_modified = true; }
    public boolean olcTotLiabLcCurrIsModifiedS2j() { return __olcTotLiabLcCurr_is_modified; }
    public double getOlcConvRateBaseCurr() { return _olcConvRateBaseCurr; }
    public void setOlcConvRateBaseCurr(double newVal) { this._olcConvRateBaseCurr = newVal; __olcConvRateBaseCurr_is_modified = true; }
    public boolean olcConvRateBaseCurrIsModifiedS2j() { return __olcConvRateBaseCurr_is_modified; }
    public double getOlcTotLiabBaseCurr() { return _olcTotLiabBaseCurr; }
    public void setOlcTotLiabBaseCurr(double newVal) { this._olcTotLiabBaseCurr = newVal; __olcTotLiabBaseCurr_is_modified = true; }
    public boolean olcTotLiabBaseCurrIsModifiedS2j() { return __olcTotLiabBaseCurr_is_modified; }
    public double getOlcConvRateLimCurr() { return _olcConvRateLimCurr; }
    public void setOlcConvRateLimCurr(double newVal) { this._olcConvRateLimCurr = newVal; __olcConvRateLimCurr_is_modified = true; }
    public boolean olcConvRateLimCurrIsModifiedS2j() { return __olcConvRateLimCurr_is_modified; }
    public double getOlcTotLiabLimCurr() { return _olcTotLiabLimCurr; }
    public void setOlcTotLiabLimCurr(double newVal) { this._olcTotLiabLimCurr = newVal; __olcTotLiabLimCurr_is_modified = true; }
    public boolean olcTotLiabLimCurrIsModifiedS2j() { return __olcTotLiabLimCurr_is_modified; }
    public String getOlcPaymntCurr() { return _olcPaymntCurr == null ? "" : _olcPaymntCurr.trim(); }
    public void setOlcPaymntCurr(String newVal) { this._olcPaymntCurr = newVal; __olcPaymntCurr_is_modified = true; }
    public boolean olcPaymntCurrIsModifiedS2j() { return __olcPaymntCurr_is_modified; }
    public double getOlcTotChrgsInPaymntCurr() { return _olcTotChrgsInPaymntCurr; }
    public void setOlcTotChrgsInPaymntCurr(double newVal) { this._olcTotChrgsInPaymntCurr = newVal; __olcTotChrgsInPaymntCurr_is_modified = true; }
    public boolean olcTotChrgsInPaymntCurrIsModifiedS2j() { return __olcTotChrgsInPaymntCurr_is_modified; }
    public double getOlcCashMarginBal() { return _olcCashMarginBal; }
    public void setOlcCashMarginBal(double newVal) { this._olcCashMarginBal = newVal; __olcCashMarginBal_is_modified = true; }
    public boolean olcCashMarginBalIsModifiedS2j() { return __olcCashMarginBal_is_modified; }
    public char getOlcReimbChrgsBy() { return _olcReimbChrgsBy; }
    public void setOlcReimbChrgsBy(char newVal) { this._olcReimbChrgsBy = newVal; __olcReimbChrgsBy_is_modified = true; }
    public boolean olcReimbChrgsByIsModifiedS2j() { return __olcReimbChrgsBy_is_modified; }
    public double getOlcPercRcPaidByApplcnt() { return _olcPercRcPaidByApplcnt; }
    public void setOlcPercRcPaidByApplcnt(double newVal) { this._olcPercRcPaidByApplcnt = newVal; __olcPercRcPaidByApplcnt_is_modified = true; }
    public boolean olcPercRcPaidByApplcntIsModifiedS2j() { return __olcPercRcPaidByApplcnt_is_modified; }
    public String getOlcNostroAlphaCode() { return _olcNostroAlphaCode == null ? "" : _olcNostroAlphaCode.trim(); }
    public void setOlcNostroAlphaCode(String newVal) { this._olcNostroAlphaCode = newVal; __olcNostroAlphaCode_is_modified = true; }
    public boolean olcNostroAlphaCodeIsModifiedS2j() { return __olcNostroAlphaCode_is_modified; }
    public String getOlcAdvThruBk() { return _olcAdvThruBk == null ? "" : _olcAdvThruBk.trim(); }
    public void setOlcAdvThruBk(String newVal) { this._olcAdvThruBk = newVal; __olcAdvThruBk_is_modified = true; }
    public boolean olcAdvThruBkIsModifiedS2j() { return __olcAdvThruBk_is_modified; }
    public String getOlcAdvThruBrn() { return _olcAdvThruBrn == null ? "" : _olcAdvThruBrn.trim(); }
    public void setOlcAdvThruBrn(String newVal) { this._olcAdvThruBrn = newVal; __olcAdvThruBrn_is_modified = true; }
    public boolean olcAdvThruBrnIsModifiedS2j() { return __olcAdvThruBrn_is_modified; }
    public char getOlcLcToBeCnfrmd() { return _olcLcToBeCnfrmd; }
    public void setOlcLcToBeCnfrmd(char newVal) { this._olcLcToBeCnfrmd = newVal; __olcLcToBeCnfrmd_is_modified = true; }
    public boolean olcLcToBeCnfrmdIsModifiedS2j() { return __olcLcToBeCnfrmd_is_modified; }
    public String getOlcLcToBeCnfrmdByBk() { return _olcLcToBeCnfrmdByBk == null ? "" : _olcLcToBeCnfrmdByBk.trim(); }
    public void setOlcLcToBeCnfrmdByBk(String newVal) { this._olcLcToBeCnfrmdByBk = newVal; __olcLcToBeCnfrmdByBk_is_modified = true; }
    public boolean olcLcToBeCnfrmdByBkIsModifiedS2j() { return __olcLcToBeCnfrmdByBk_is_modified; }
    public String getOlcLcToBeCnfrmdByBrn() { return _olcLcToBeCnfrmdByBrn == null ? "" : _olcLcToBeCnfrmdByBrn.trim(); }
    public void setOlcLcToBeCnfrmdByBrn(String newVal) { this._olcLcToBeCnfrmdByBrn = newVal; __olcLcToBeCnfrmdByBrn_is_modified = true; }
    public boolean olcLcToBeCnfrmdByBrnIsModifiedS2j() { return __olcLcToBeCnfrmdByBrn_is_modified; }
    public char getOlcRestricted() { return _olcRestricted; }
    public void setOlcRestricted(char newVal) { this._olcRestricted = newVal; __olcRestricted_is_modified = true; }
    public boolean olcRestrictedIsModifiedS2j() { return __olcRestricted_is_modified; }
    public char getOlcRestrictedToUs() { return _olcRestrictedToUs; }
    public void setOlcRestrictedToUs(char newVal) { this._olcRestrictedToUs = newVal; __olcRestrictedToUs_is_modified = true; }
    public boolean olcRestrictedToUsIsModifiedS2j() { return __olcRestrictedToUs_is_modified; }
    public String getOlcRestrictedBkCode() { return _olcRestrictedBkCode == null ? "" : _olcRestrictedBkCode.trim(); }
    public void setOlcRestrictedBkCode(String newVal) { this._olcRestrictedBkCode = newVal; __olcRestrictedBkCode_is_modified = true; }
    public boolean olcRestrictedBkCodeIsModifiedS2j() { return __olcRestrictedBkCode_is_modified; }
    public String getOlcRestrictedBrnCode() { return _olcRestrictedBrnCode == null ? "" : _olcRestrictedBrnCode.trim(); }
    public void setOlcRestrictedBrnCode(String newVal) { this._olcRestrictedBrnCode = newVal; __olcRestrictedBrnCode_is_modified = true; }
    public boolean olcRestrictedBrnCodeIsModifiedS2j() { return __olcRestrictedBrnCode_is_modified; }
    public char getOlcCrAvlblBy() { return _olcCrAvlblBy; }
    public void setOlcCrAvlblBy(char newVal) { this._olcCrAvlblBy = newVal; __olcCrAvlblBy_is_modified = true; }
    public boolean olcCrAvlblByIsModifiedS2j() { return __olcCrAvlblBy_is_modified; }
    public char getOlcIrrevocable() { return _olcIrrevocable; }
    public void setOlcIrrevocable(char newVal) { this._olcIrrevocable = newVal; __olcIrrevocable_is_modified = true; }
    public boolean olcIrrevocableIsModifiedS2j() { return __olcIrrevocable_is_modified; }
    public char getOlcPartShpmnt() { return _olcPartShpmnt; }
    public void setOlcPartShpmnt(char newVal) { this._olcPartShpmnt = newVal; __olcPartShpmnt_is_modified = true; }
    public boolean olcPartShpmntIsModifiedS2j() { return __olcPartShpmnt_is_modified; }
    public char getOlcTranShpmnt() { return _olcTranShpmnt; }
    public void setOlcTranShpmnt(char newVal) { this._olcTranShpmnt = newVal; __olcTranShpmnt_is_modified = true; }
    public boolean olcTranShpmntIsModifiedS2j() { return __olcTranShpmnt_is_modified; }
    public char getOlcLcTransfrbl() { return _olcLcTransfrbl; }
    public void setOlcLcTransfrbl(char newVal) { this._olcLcTransfrbl = newVal; __olcLcTransfrbl_is_modified = true; }
    public boolean olcLcTransfrblIsModifiedS2j() { return __olcLcTransfrbl_is_modified; }
    public char getOlcDftReqd() { return _olcDftReqd; }
    public void setOlcDftReqd(char newVal) { this._olcDftReqd = newVal; __olcDftReqd_is_modified = true; }
    public boolean olcDftReqdIsModifiedS2j() { return __olcDftReqd_is_modified; }
    public double getOlcPercDftValue() { return _olcPercDftValue; }
    public void setOlcPercDftValue(double newVal) { this._olcPercDftValue = newVal; __olcPercDftValue_is_modified = true; }
    public boolean olcPercDftValueIsModifiedS2j() { return __olcPercDftValue_is_modified; }
    public char getOlcDftToBeDrawnOn() { return _olcDftToBeDrawnOn; }
    public void setOlcDftToBeDrawnOn(char newVal) { this._olcDftToBeDrawnOn = newVal; __olcDftToBeDrawnOn_is_modified = true; }
    public boolean olcDftToBeDrawnOnIsModifiedS2j() { return __olcDftToBeDrawnOn_is_modified; }
    public String getOlcDftOnBk() { return _olcDftOnBk == null ? "" : _olcDftOnBk.trim(); }
    public void setOlcDftOnBk(String newVal) { this._olcDftOnBk = newVal; __olcDftOnBk_is_modified = true; }
    public boolean olcDftOnBkIsModifiedS2j() { return __olcDftOnBk_is_modified; }
    public String getOlcDftOnBrn() { return _olcDftOnBrn == null ? "" : _olcDftOnBrn.trim(); }
    public void setOlcDftOnBrn(String newVal) { this._olcDftOnBrn = newVal; __olcDftOnBrn_is_modified = true; }
    public boolean olcDftOnBrnIsModifiedS2j() { return __olcDftOnBrn_is_modified; }
    public String getOlcSpecText1() { return _olcSpecText1 == null ? "" : _olcSpecText1.trim(); }
    public void setOlcSpecText1(String newVal) { this._olcSpecText1 = newVal; __olcSpecText1_is_modified = true; }
    public boolean olcSpecText1IsModifiedS2j() { return __olcSpecText1_is_modified; }
    public String getOlcSpecText2() { return _olcSpecText2 == null ? "" : _olcSpecText2.trim(); }
    public void setOlcSpecText2(String newVal) { this._olcSpecText2 = newVal; __olcSpecText2_is_modified = true; }
    public boolean olcSpecText2IsModifiedS2j() { return __olcSpecText2_is_modified; }
    public String getOlcSpecText3() { return _olcSpecText3 == null ? "" : _olcSpecText3.trim(); }
    public void setOlcSpecText3(String newVal) { this._olcSpecText3 = newVal; __olcSpecText3_is_modified = true; }
    public boolean olcSpecText3IsModifiedS2j() { return __olcSpecText3_is_modified; }
    public String getOlcSpecText4() { return _olcSpecText4 == null ? "" : _olcSpecText4.trim(); }
    public void setOlcSpecText4(String newVal) { this._olcSpecText4 = newVal; __olcSpecText4_is_modified = true; }
    public boolean olcSpecText4IsModifiedS2j() { return __olcSpecText4_is_modified; }
    public char getOlcPrimeRateClauseReq() { return _olcPrimeRateClauseReq; }
    public void setOlcPrimeRateClauseReq(char newVal) { this._olcPrimeRateClauseReq = newVal; __olcPrimeRateClauseReq_is_modified = true; }
    public boolean olcPrimeRateClauseReqIsModifiedS2j() { return __olcPrimeRateClauseReq_is_modified; }
    public char getOlcShpmntMode() { return _olcShpmntMode; }
    public void setOlcShpmntMode(char newVal) { this._olcShpmntMode = newVal; __olcShpmntMode_is_modified = true; }
    public boolean olcShpmntModeIsModifiedS2j() { return __olcShpmntMode_is_modified; }
    public char getOlcLloydsClauseReq() { return _olcLloydsClauseReq; }
    public void setOlcLloydsClauseReq(char newVal) { this._olcLloydsClauseReq = newVal; __olcLloydsClauseReq_is_modified = true; }
    public boolean olcLloydsClauseReqIsModifiedS2j() { return __olcLloydsClauseReq_is_modified; }
    public int getOlcMaxShipAge() { return _olcMaxShipAge; }
    public void setOlcMaxShipAge(int newVal) { this._olcMaxShipAge = newVal; __olcMaxShipAge_is_modified = true; }
    public boolean olcMaxShipAgeIsModifiedS2j() { return __olcMaxShipAge_is_modified; }
    public char getOlcShortFormOfBl() { return _olcShortFormOfBl; }
    public void setOlcShortFormOfBl(char newVal) { this._olcShortFormOfBl = newVal; __olcShortFormOfBl_is_modified = true; }
    public boolean olcShortFormOfBlIsModifiedS2j() { return __olcShortFormOfBl_is_modified; }
    public char getOlcLashTransDocsAllwd() { return _olcLashTransDocsAllwd; }
    public void setOlcLashTransDocsAllwd(char newVal) { this._olcLashTransDocsAllwd = newVal; __olcLashTransDocsAllwd_is_modified = true; }
    public boolean olcLashTransDocsAllwdIsModifiedS2j() { return __olcLashTransDocsAllwd_is_modified; }
    public double getOlcPercOfInsValueCvrd() { return _olcPercOfInsValueCvrd; }
    public void setOlcPercOfInsValueCvrd(double newVal) { this._olcPercOfInsValueCvrd = newVal; __olcPercOfInsValueCvrd_is_modified = true; }
    public boolean olcPercOfInsValueCvrdIsModifiedS2j() { return __olcPercOfInsValueCvrd_is_modified; }
    public String getOlcInsPolicyNum() { return _olcInsPolicyNum == null ? "" : _olcInsPolicyNum.trim(); }
    public void setOlcInsPolicyNum(String newVal) { this._olcInsPolicyNum = newVal; __olcInsPolicyNum_is_modified = true; }
    public boolean olcInsPolicyNumIsModifiedS2j() { return __olcInsPolicyNum_is_modified; }
    public java.util.Date getOlcInsDate() { return _olcInsDate; }
    public void setOlcInsDate(java.util.Date newVal) { this._olcInsDate = newVal; __olcInsDate_is_modified = true; }
    public boolean olcInsDateIsModifiedS2j() { return __olcInsDate_is_modified; }
    public String getOlcInsCurr() { return _olcInsCurr == null ? "" : _olcInsCurr.trim(); }
    public void setOlcInsCurr(String newVal) { this._olcInsCurr = newVal; __olcInsCurr_is_modified = true; }
    public boolean olcInsCurrIsModifiedS2j() { return __olcInsCurr_is_modified; }
    public double getOlcInsAmt() { return _olcInsAmt; }
    public void setOlcInsAmt(double newVal) { this._olcInsAmt = newVal; __olcInsAmt_is_modified = true; }
    public boolean olcInsAmtIsModifiedS2j() { return __olcInsAmt_is_modified; }
    public String getOlcPremiumCurr() { return _olcPremiumCurr == null ? "" : _olcPremiumCurr.trim(); }
    public void setOlcPremiumCurr(String newVal) { this._olcPremiumCurr = newVal; __olcPremiumCurr_is_modified = true; }
    public boolean olcPremiumCurrIsModifiedS2j() { return __olcPremiumCurr_is_modified; }
    public double getOlcPremiumAmt() { return _olcPremiumAmt; }
    public void setOlcPremiumAmt(double newVal) { this._olcPremiumAmt = newVal; __olcPremiumAmt_is_modified = true; }
    public boolean olcPremiumAmtIsModifiedS2j() { return __olcPremiumAmt_is_modified; }
    public String getOlcInsCompany() { return _olcInsCompany == null ? "" : _olcInsCompany.trim(); }
    public void setOlcInsCompany(String newVal) { this._olcInsCompany = newVal; __olcInsCompany_is_modified = true; }
    public boolean olcInsCompanyIsModifiedS2j() { return __olcInsCompany_is_modified; }
    public String getOlcInsCompanyName() { return _olcInsCompanyName == null ? "" : _olcInsCompanyName.trim(); }
    public void setOlcInsCompanyName(String newVal) { this._olcInsCompanyName = newVal; __olcInsCompanyName_is_modified = true; }
    public boolean olcInsCompanyNameIsModifiedS2j() { return __olcInsCompanyName_is_modified; }
    public String getOlcCooIssBy() { return _olcCooIssBy == null ? "" : _olcCooIssBy.trim(); }
    public void setOlcCooIssBy(String newVal) { this._olcCooIssBy = newVal; __olcCooIssBy_is_modified = true; }
    public boolean olcCooIssByIsModifiedS2j() { return __olcCooIssBy_is_modified; }
    public String getOlcOtherCompAuth() { return _olcOtherCompAuth == null ? "" : _olcOtherCompAuth.trim(); }
    public void setOlcOtherCompAuth(String newVal) { this._olcOtherCompAuth = newVal; __olcOtherCompAuth_is_modified = true; }
    public boolean olcOtherCompAuthIsModifiedS2j() { return __olcOtherCompAuth_is_modified; }
    public char getOlcIntermediaryTrade() { return _olcIntermediaryTrade; }
    public void setOlcIntermediaryTrade(char newVal) { this._olcIntermediaryTrade = newVal; __olcIntermediaryTrade_is_modified = true; }
    public boolean olcIntermediaryTradeIsModifiedS2j() { return __olcIntermediaryTrade_is_modified; }
    public char getOlcInspTestCertReq() { return _olcInspTestCertReq; }
    public void setOlcInspTestCertReq(char newVal) { this._olcInspTestCertReq = newVal; __olcInspTestCertReq_is_modified = true; }
    public boolean olcInspTestCertReqIsModifiedS2j() { return __olcInspTestCertReq_is_modified; }
    public String getOlcCertBy() { return _olcCertBy == null ? "" : _olcCertBy.trim(); }
    public void setOlcCertBy(String newVal) { this._olcCertBy = newVal; __olcCertBy_is_modified = true; }
    public boolean olcCertByIsModifiedS2j() { return __olcCertBy_is_modified; }
    public char getOlcImpUnder() { return _olcImpUnder; }
    public void setOlcImpUnder(char newVal) { this._olcImpUnder = newVal; __olcImpUnder_is_modified = true; }
    public boolean olcImpUnderIsModifiedS2j() { return __olcImpUnder_is_modified; }
    public String getOlcImpPolicyDet() { return _olcImpPolicyDet == null ? "" : _olcImpPolicyDet.trim(); }
    public void setOlcImpPolicyDet(String newVal) { this._olcImpPolicyDet = newVal; __olcImpPolicyDet_is_modified = true; }
    public boolean olcImpPolicyDetIsModifiedS2j() { return __olcImpPolicyDet_is_modified; }
    public String getOlcImpRef() { return _olcImpRef == null ? "" : _olcImpRef.trim(); }
    public void setOlcImpRef(String newVal) { this._olcImpRef = newVal; __olcImpRef_is_modified = true; }
    public boolean olcImpRefIsModifiedS2j() { return __olcImpRef_is_modified; }
    public long getOlcCustLiabAcc() { return _olcCustLiabAcc; }
    public void setOlcCustLiabAcc(long newVal) { this._olcCustLiabAcc = newVal; __olcCustLiabAcc_is_modified = true; }
    public boolean olcCustLiabAccIsModifiedS2j() { return __olcCustLiabAcc_is_modified; }
    public java.util.Date getOlcCancelledOn() { return _olcCancelledOn; }
    public void setOlcCancelledOn(java.util.Date newVal) { this._olcCancelledOn = newVal; __olcCancelledOn_is_modified = true; }
    public boolean olcCancelledOnIsModifiedS2j() { return __olcCancelledOn_is_modified; }
    public double getOlcUsanceCharges() { return _olcUsanceCharges; }
    public void setOlcUsanceCharges(double newVal) { this._olcUsanceCharges = newVal; __olcUsanceCharges_is_modified = true; }
    public boolean olcUsanceChargesIsModifiedS2j() { return __olcUsanceCharges_is_modified; }
    public int getOlcUsnChgTakenDays() { return _olcUsnChgTakenDays; }
    public void setOlcUsnChgTakenDays(int newVal) { this._olcUsnChgTakenDays = newVal; __olcUsnChgTakenDays_is_modified = true; }
    public boolean olcUsnChgTakenDaysIsModifiedS2j() { return __olcUsnChgTakenDays_is_modified; }
    public double getOlcCommitmentCharges() { return _olcCommitmentCharges; }
    public void setOlcCommitmentCharges(double newVal) { this._olcCommitmentCharges = newVal; __olcCommitmentCharges_is_modified = true; }
    public boolean olcCommitmentChargesIsModifiedS2j() { return __olcCommitmentCharges_is_modified; }
    public int getOlcCommitChgTakenDays() { return _olcCommitChgTakenDays; }
    public void setOlcCommitChgTakenDays(int newVal) { this._olcCommitChgTakenDays = newVal; __olcCommitChgTakenDays_is_modified = true; }
    public boolean olcCommitChgTakenDaysIsModifiedS2j() { return __olcCommitChgTakenDays_is_modified; }
    public long getTranchgsChgsSl() { return _tranchgsChgsSl; }
    public void setTranchgsChgsSl(long newVal) { this._tranchgsChgsSl = newVal; __tranchgsChgsSl_is_modified = true; }
    public boolean tranchgsChgsSlIsModifiedS2j() { return __tranchgsChgsSl_is_modified; }
    public long getTrancratesRateSl() { return _trancratesRateSl; }
    public void setTrancratesRateSl(long newVal) { this._trancratesRateSl = newVal; __trancratesRateSl_is_modified = true; }
    public boolean trancratesRateSlIsModifiedS2j() { return __trancratesRateSl_is_modified; }
    public long getTranstlmntInvNum() { return _transtlmntInvNum; }
    public void setTranstlmntInvNum(long newVal) { this._transtlmntInvNum = newVal; __transtlmntInvNum_is_modified = true; }
    public boolean transtlmntInvNumIsModifiedS2j() { return __transtlmntInvNum_is_modified; }
    public int getPostTranBrn() { return _postTranBrn; }
    public void setPostTranBrn(int newVal) { this._postTranBrn = newVal; __postTranBrn_is_modified = true; }
    public boolean postTranBrnIsModifiedS2j() { return __postTranBrn_is_modified; }
    public java.util.Date getPostTranDate() { return _postTranDate; }
    public void setPostTranDate(java.util.Date newVal) { this._postTranDate = newVal; __postTranDate_is_modified = true; }
    public boolean postTranDateIsModifiedS2j() { return __postTranDate_is_modified; }
    public int getPostTranBatchNum() { return _postTranBatchNum; }
    public void setPostTranBatchNum(int newVal) { this._postTranBatchNum = newVal; __postTranBatchNum_is_modified = true; }
    public boolean postTranBatchNumIsModifiedS2j() { return __postTranBatchNum_is_modified; }
    public String getOlcEntdBy() { return _olcEntdBy == null ? "" : _olcEntdBy.trim(); }
    public void setOlcEntdBy(String newVal) { this._olcEntdBy = newVal; __olcEntdBy_is_modified = true; }
    public boolean olcEntdByIsModifiedS2j() { return __olcEntdBy_is_modified; }
    public java.util.Date getOlcEntdOn() { return _olcEntdOn; }
    public void setOlcEntdOn(java.util.Date newVal) { this._olcEntdOn = newVal; __olcEntdOn_is_modified = true; }
    public boolean olcEntdOnIsModifiedS2j() { return __olcEntdOn_is_modified; }
    public String getOlcLastmodBy() { return _olcLastmodBy == null ? "" : _olcLastmodBy.trim(); }
    public void setOlcLastmodBy(String newVal) { this._olcLastmodBy = newVal; __olcLastmodBy_is_modified = true; }
    public boolean olcLastmodByIsModifiedS2j() { return __olcLastmodBy_is_modified; }
    public java.util.Date getOlcLastmodOn() { return _olcLastmodOn; }
    public void setOlcLastmodOn(java.util.Date newVal) { this._olcLastmodOn = newVal; __olcLastmodOn_is_modified = true; }
    public boolean olcLastmodOnIsModifiedS2j() { return __olcLastmodOn_is_modified; }
    public String getOlcAuthBy() { return _olcAuthBy == null ? "" : _olcAuthBy.trim(); }
    public void setOlcAuthBy(String newVal) { this._olcAuthBy = newVal; __olcAuthBy_is_modified = true; }
    public boolean olcAuthByIsModifiedS2j() { return __olcAuthBy_is_modified; }
    public java.util.Date getOlcAuthOn() { return _olcAuthOn; }
    public void setOlcAuthOn(java.util.Date newVal) { this._olcAuthOn = newVal; __olcAuthOn_is_modified = true; }
    public boolean olcAuthOnIsModifiedS2j() { return __olcAuthOn_is_modified; }
    public String getOlcRejBy() { return _olcRejBy == null ? "" : _olcRejBy.trim(); }
    public void setOlcRejBy(String newVal) { this._olcRejBy = newVal; __olcRejBy_is_modified = true; }
    public boolean olcRejByIsModifiedS2j() { return __olcRejBy_is_modified; }
    public java.util.Date getOlcRejOn() { return _olcRejOn; }
    public void setOlcRejOn(java.util.Date newVal) { this._olcRejOn = newVal; __olcRejOn_is_modified = true; }
    public boolean olcRejOnIsModifiedS2j() { return __olcRejOn_is_modified; }
    public String getOlcMarginCurr() { return _olcMarginCurr == null ? "" : _olcMarginCurr.trim(); }
    public void setOlcMarginCurr(String newVal) { this._olcMarginCurr = newVal; __olcMarginCurr_is_modified = true; }
    public boolean olcMarginCurrIsModifiedS2j() { return __olcMarginCurr_is_modified; }
    public double getOlcMarginAmt() { return _olcMarginAmt; }
    public void setOlcMarginAmt(double newVal) { this._olcMarginAmt = newVal; __olcMarginAmt_is_modified = true; }
    public boolean olcMarginAmtIsModifiedS2j() { return __olcMarginAmt_is_modified; }
    public double getOlcMarginBal() { return _olcMarginBal; }
    public void setOlcMarginBal(double newVal) { this._olcMarginBal = newVal; __olcMarginBal_is_modified = true; }
    public boolean olcMarginBalIsModifiedS2j() { return __olcMarginBal_is_modified; }
    public double getOlcCashMarAmt() { return _olcCashMarAmt; }
    public void setOlcCashMarAmt(double newVal) { this._olcCashMarAmt = newVal; __olcCashMarAmt_is_modified = true; }
    public boolean olcCashMarAmtIsModifiedS2j() { return __olcCashMarAmt_is_modified; }
    public double getOlcCashMarBal() { return _olcCashMarBal; }
    public void setOlcCashMarBal(double newVal) { this._olcCashMarBal = newVal; __olcCashMarBal_is_modified = true; }
    public boolean olcCashMarBalIsModifiedS2j() { return __olcCashMarBal_is_modified; }
    public double getOlcCashMarRec() { return _olcCashMarRec; }
    public void setOlcCashMarRec(double newVal) { this._olcCashMarRec = newVal; __olcCashMarRec_is_modified = true; }
    public boolean olcCashMarRecIsModifiedS2j() { return __olcCashMarRec_is_modified; }
    public double getOlcDepMarRec() { return _olcDepMarRec; }
    public void setOlcDepMarRec(double newVal) { this._olcDepMarRec = newVal; __olcDepMarRec_is_modified = true; }
    public boolean olcDepMarRecIsModifiedS2j() { return __olcDepMarRec_is_modified; }
    public double getOlcOthSecMarRec() { return _olcOthSecMarRec; }
    public void setOlcOthSecMarRec(double newVal) { this._olcOthSecMarRec = newVal; __olcOthSecMarRec_is_modified = true; }
    public boolean olcOthSecMarRecIsModifiedS2j() { return __olcOthSecMarRec_is_modified; }
    public double getOlcUsanceServTax() { return _olcUsanceServTax; }
    public void setOlcUsanceServTax(double newVal) { this._olcUsanceServTax = newVal; __olcUsanceServTax_is_modified = true; }
    public boolean olcUsanceServTaxIsModifiedS2j() { return __olcUsanceServTax_is_modified; }
    public double getOlcCommitServTax() { return _olcCommitServTax; }
    public void setOlcCommitServTax(double newVal) { this._olcCommitServTax = newVal; __olcCommitServTax_is_modified = true; }
    public boolean olcCommitServTaxIsModifiedS2j() { return __olcCommitServTax_is_modified; }
    public boolean isNew() { return _isNew; }
    public void setIsNew(boolean isNew) { this._isNew = isNew; }

    public boolean isModifiedS2J() {
        return __olcBrnCode_is_modified || 
        __olcLcType_is_modified || 
        __olcLcYear_is_modified || 
        __olcLcSl_is_modified || 
        __olcCorrRefNum_is_modified || 
        __olcLcPresancDate_is_modified || 
        __olcLcPresancDaySl_is_modified || 
        __olcLcDate_is_modified || 
        __olcCustNum_is_modified || 
        __olcBenefCode_is_modified || 
        __olcBenefName_is_modified || 
        __olcBenefAddr1_is_modified || 
        __olcBenefAddr2_is_modified || 
        __olcBenefAddr3_is_modified || 
        __olcBenefAddr4_is_modified || 
        __olcBenefAddr5_is_modified || 
        __olcBenefCntryCode_is_modified || 
        __olcLcIssBkCode_is_modified || 
        __olcLcIssBrnCode_is_modified || 
        __olcLcIssBrnName_is_modified || 
        __olcLcIssBrnAdd1_is_modified || 
        __olcLcIssBrnAdd2_is_modified || 
        __olcLcIssBrnAdd3_is_modified || 
        __olcLcIssBrnAdd4_is_modified || 
        __olcLcIssBrnAdd5_is_modified || 
        __olcLcIssPlace_is_modified || 
        __olcLcIssCntry_is_modified || 
        __olcLcAdvThru_is_modified || 
        __olcLcCurrCode_is_modified || 
        __olcLcAmount_is_modified || 
        __olcLcBalance_is_modified || 
        __olcDevAllwd_is_modified || 
        __olcPosDevAllwd_is_modified || 
        __olcNegDevAllwd_is_modified || 
        __olcDevAmount_is_modified || 
        __olcDevBal_is_modified || 
        __olcAmtQualfr_is_modified || 
        __olcPriceTerms_is_modified || 
        __olcLastDateOfNeg_is_modified || 
        __olcPlaceOfExpiry_is_modified || 
        __olcLatestDateOfShpmnt_is_modified || 
        __olcWithinValidateLc_is_modified || 
        __olcLcUiBorneByApplcnt_is_modified || 
        __olcNofTenors_is_modified || 
        __olcLcUnderContract_is_modified || 
        __olcTotLiabLcCurr_is_modified || 
        __olcConvRateBaseCurr_is_modified || 
        __olcTotLiabBaseCurr_is_modified || 
        __olcConvRateLimCurr_is_modified || 
        __olcTotLiabLimCurr_is_modified || 
        __olcPaymntCurr_is_modified || 
        __olcTotChrgsInPaymntCurr_is_modified || 
        __olcCashMarginBal_is_modified || 
        __olcReimbChrgsBy_is_modified || 
        __olcPercRcPaidByApplcnt_is_modified || 
        __olcNostroAlphaCode_is_modified || 
        __olcAdvThruBk_is_modified || 
        __olcAdvThruBrn_is_modified || 
        __olcLcToBeCnfrmd_is_modified || 
        __olcLcToBeCnfrmdByBk_is_modified || 
        __olcLcToBeCnfrmdByBrn_is_modified || 
        __olcRestricted_is_modified || 
        __olcRestrictedToUs_is_modified || 
        __olcRestrictedBkCode_is_modified || 
        __olcRestrictedBrnCode_is_modified || 
        __olcCrAvlblBy_is_modified || 
        __olcIrrevocable_is_modified || 
        __olcPartShpmnt_is_modified || 
        __olcTranShpmnt_is_modified || 
        __olcLcTransfrbl_is_modified || 
        __olcDftReqd_is_modified || 
        __olcPercDftValue_is_modified || 
        __olcDftToBeDrawnOn_is_modified || 
        __olcDftOnBk_is_modified || 
        __olcDftOnBrn_is_modified || 
        __olcSpecText1_is_modified || 
        __olcSpecText2_is_modified || 
        __olcSpecText3_is_modified || 
        __olcSpecText4_is_modified || 
        __olcPrimeRateClauseReq_is_modified || 
        __olcShpmntMode_is_modified || 
        __olcLloydsClauseReq_is_modified || 
        __olcMaxShipAge_is_modified || 
        __olcShortFormOfBl_is_modified || 
        __olcLashTransDocsAllwd_is_modified || 
        __olcPercOfInsValueCvrd_is_modified || 
        __olcInsPolicyNum_is_modified || 
        __olcInsDate_is_modified || 
        __olcInsCurr_is_modified || 
        __olcInsAmt_is_modified || 
        __olcPremiumCurr_is_modified || 
        __olcPremiumAmt_is_modified || 
        __olcInsCompany_is_modified || 
        __olcInsCompanyName_is_modified || 
        __olcCooIssBy_is_modified || 
        __olcOtherCompAuth_is_modified || 
        __olcIntermediaryTrade_is_modified || 
        __olcInspTestCertReq_is_modified || 
        __olcCertBy_is_modified || 
        __olcImpUnder_is_modified || 
        __olcImpPolicyDet_is_modified || 
        __olcImpRef_is_modified || 
        __olcCustLiabAcc_is_modified || 
        __olcCancelledOn_is_modified || 
        __olcUsanceCharges_is_modified || 
        __olcUsnChgTakenDays_is_modified || 
        __olcCommitmentCharges_is_modified || 
        __olcCommitChgTakenDays_is_modified || 
        __tranchgsChgsSl_is_modified || 
        __trancratesRateSl_is_modified || 
        __transtlmntInvNum_is_modified || 
        __postTranBrn_is_modified || 
        __postTranDate_is_modified || 
        __postTranBatchNum_is_modified || 
        __olcEntdBy_is_modified || 
        __olcEntdOn_is_modified || 
        __olcLastmodBy_is_modified || 
        __olcLastmodOn_is_modified || 
        __olcAuthBy_is_modified || 
        __olcAuthOn_is_modified || 
        __olcRejBy_is_modified || 
        __olcRejOn_is_modified || 
        __olcMarginCurr_is_modified || 
        __olcMarginAmt_is_modified || 
        __olcMarginBal_is_modified || 
        __olcCashMarAmt_is_modified || 
        __olcCashMarBal_is_modified || 
        __olcCashMarRec_is_modified || 
        __olcDepMarRec_is_modified || 
        __olcOthSecMarRec_is_modified || 
        __olcUsanceServTax_is_modified || 
        __olcCommitServTax_is_modified;
    }

    public void resetIsModifiedS2J() {
        __olcBrnCode_is_modified = false;
        __olcLcType_is_modified = false;
        __olcLcYear_is_modified = false;
        __olcLcSl_is_modified = false;
        __olcCorrRefNum_is_modified = false;
        __olcLcPresancDate_is_modified = false;
        __olcLcPresancDaySl_is_modified = false;
        __olcLcDate_is_modified = false;
        __olcCustNum_is_modified = false;
        __olcBenefCode_is_modified = false;
        __olcBenefName_is_modified = false;
        __olcBenefAddr1_is_modified = false;
        __olcBenefAddr2_is_modified = false;
        __olcBenefAddr3_is_modified = false;
        __olcBenefAddr4_is_modified = false;
        __olcBenefAddr5_is_modified = false;
        __olcBenefCntryCode_is_modified = false;
        __olcLcIssBkCode_is_modified = false;
        __olcLcIssBrnCode_is_modified = false;
        __olcLcIssBrnName_is_modified = false;
        __olcLcIssBrnAdd1_is_modified = false;
        __olcLcIssBrnAdd2_is_modified = false;
        __olcLcIssBrnAdd3_is_modified = false;
        __olcLcIssBrnAdd4_is_modified = false;
        __olcLcIssBrnAdd5_is_modified = false;
        __olcLcIssPlace_is_modified = false;
        __olcLcIssCntry_is_modified = false;
        __olcLcAdvThru_is_modified = false;
        __olcLcCurrCode_is_modified = false;
        __olcLcAmount_is_modified = false;
        __olcLcBalance_is_modified = false;
        __olcDevAllwd_is_modified = false;
        __olcPosDevAllwd_is_modified = false;
        __olcNegDevAllwd_is_modified = false;
        __olcDevAmount_is_modified = false;
        __olcDevBal_is_modified = false;
        __olcAmtQualfr_is_modified = false;
        __olcPriceTerms_is_modified = false;
        __olcLastDateOfNeg_is_modified = false;
        __olcPlaceOfExpiry_is_modified = false;
        __olcLatestDateOfShpmnt_is_modified = false;
        __olcWithinValidateLc_is_modified = false;
        __olcLcUiBorneByApplcnt_is_modified = false;
        __olcNofTenors_is_modified = false;
        __olcLcUnderContract_is_modified = false;
        __olcTotLiabLcCurr_is_modified = false;
        __olcConvRateBaseCurr_is_modified = false;
        __olcTotLiabBaseCurr_is_modified = false;
        __olcConvRateLimCurr_is_modified = false;
        __olcTotLiabLimCurr_is_modified = false;
        __olcPaymntCurr_is_modified = false;
        __olcTotChrgsInPaymntCurr_is_modified = false;
        __olcCashMarginBal_is_modified = false;
        __olcReimbChrgsBy_is_modified = false;
        __olcPercRcPaidByApplcnt_is_modified = false;
        __olcNostroAlphaCode_is_modified = false;
        __olcAdvThruBk_is_modified = false;
        __olcAdvThruBrn_is_modified = false;
        __olcLcToBeCnfrmd_is_modified = false;
        __olcLcToBeCnfrmdByBk_is_modified = false;
        __olcLcToBeCnfrmdByBrn_is_modified = false;
        __olcRestricted_is_modified = false;
        __olcRestrictedToUs_is_modified = false;
        __olcRestrictedBkCode_is_modified = false;
        __olcRestrictedBrnCode_is_modified = false;
        __olcCrAvlblBy_is_modified = false;
        __olcIrrevocable_is_modified = false;
        __olcPartShpmnt_is_modified = false;
        __olcTranShpmnt_is_modified = false;
        __olcLcTransfrbl_is_modified = false;
        __olcDftReqd_is_modified = false;
        __olcPercDftValue_is_modified = false;
        __olcDftToBeDrawnOn_is_modified = false;
        __olcDftOnBk_is_modified = false;
        __olcDftOnBrn_is_modified = false;
        __olcSpecText1_is_modified = false;
        __olcSpecText2_is_modified = false;
        __olcSpecText3_is_modified = false;
        __olcSpecText4_is_modified = false;
        __olcPrimeRateClauseReq_is_modified = false;
        __olcShpmntMode_is_modified = false;
        __olcLloydsClauseReq_is_modified = false;
        __olcMaxShipAge_is_modified = false;
        __olcShortFormOfBl_is_modified = false;
        __olcLashTransDocsAllwd_is_modified = false;
        __olcPercOfInsValueCvrd_is_modified = false;
        __olcInsPolicyNum_is_modified = false;
        __olcInsDate_is_modified = false;
        __olcInsCurr_is_modified = false;
        __olcInsAmt_is_modified = false;
        __olcPremiumCurr_is_modified = false;
        __olcPremiumAmt_is_modified = false;
        __olcInsCompany_is_modified = false;
        __olcInsCompanyName_is_modified = false;
        __olcCooIssBy_is_modified = false;
        __olcOtherCompAuth_is_modified = false;
        __olcIntermediaryTrade_is_modified = false;
        __olcInspTestCertReq_is_modified = false;
        __olcCertBy_is_modified = false;
        __olcImpUnder_is_modified = false;
        __olcImpPolicyDet_is_modified = false;
        __olcImpRef_is_modified = false;
        __olcCustLiabAcc_is_modified = false;
        __olcCancelledOn_is_modified = false;
        __olcUsanceCharges_is_modified = false;
        __olcUsnChgTakenDays_is_modified = false;
        __olcCommitmentCharges_is_modified = false;
        __olcCommitChgTakenDays_is_modified = false;
        __tranchgsChgsSl_is_modified = false;
        __trancratesRateSl_is_modified = false;
        __transtlmntInvNum_is_modified = false;
        __postTranBrn_is_modified = false;
        __postTranDate_is_modified = false;
        __postTranBatchNum_is_modified = false;
        __olcEntdBy_is_modified = false;
        __olcEntdOn_is_modified = false;
        __olcLastmodBy_is_modified = false;
        __olcLastmodOn_is_modified = false;
        __olcAuthBy_is_modified = false;
        __olcAuthOn_is_modified = false;
        __olcRejBy_is_modified = false;
        __olcRejOn_is_modified = false;
        __olcMarginCurr_is_modified = false;
        __olcMarginAmt_is_modified = false;
        __olcMarginBal_is_modified = false;
        __olcCashMarAmt_is_modified = false;
        __olcCashMarBal_is_modified = false;
        __olcCashMarRec_is_modified = false;
        __olcDepMarRec_is_modified = false;
        __olcOthSecMarRec_is_modified = false;
        __olcUsanceServTax_is_modified = false;
        __olcCommitServTax_is_modified = false;
    }
    public Olc() {
        _initialize();
    }

    public void _initialize() {
        _olcBrnCode = 0 ;
        _olcLcType = "" ;
        _olcLcYear = 0 ;
        _olcLcSl = 0 ;
        _olcCorrRefNum = "" ;
        _olcLcPresancDate = null ;
        _olcLcPresancDaySl = 0 ;
        _olcLcDate = null ;
        _olcCustNum = 0 ;
        _olcBenefCode = "" ;
        _olcBenefName = "" ;
        _olcBenefAddr1 = "" ;
        _olcBenefAddr2 = "" ;
        _olcBenefAddr3 = "" ;
        _olcBenefAddr4 = "" ;
        _olcBenefAddr5 = "" ;
        _olcBenefCntryCode = "" ;
        _olcLcIssBkCode = "" ;
        _olcLcIssBrnCode = "" ;
        _olcLcIssBrnName = "" ;
        _olcLcIssBrnAdd1 = "" ;
        _olcLcIssBrnAdd2 = "" ;
        _olcLcIssBrnAdd3 = "" ;
        _olcLcIssBrnAdd4 = "" ;
        _olcLcIssBrnAdd5 = "" ;
        _olcLcIssPlace = "" ;
        _olcLcIssCntry = "" ;
        _olcLcAdvThru = ' ';
        _olcLcCurrCode = "" ;
        _olcLcAmount = 0 ;
        _olcLcBalance = 0 ;
        _olcDevAllwd = ' ';
        _olcPosDevAllwd = 0 ;
        _olcNegDevAllwd = 0 ;
        _olcDevAmount = 0 ;
        _olcDevBal = 0 ;
        _olcAmtQualfr = ' ';
        _olcPriceTerms = "" ;
        _olcLastDateOfNeg = null ;
        _olcPlaceOfExpiry = "" ;
        _olcLatestDateOfShpmnt = null ;
        _olcWithinValidateLc = ' ';
        _olcLcUiBorneByApplcnt = ' ';
        _olcNofTenors = 0 ;
        _olcLcUnderContract = ' ';
        _olcTotLiabLcCurr = 0 ;
        _olcConvRateBaseCurr = 0 ;
        _olcTotLiabBaseCurr = 0 ;
        _olcConvRateLimCurr = 0 ;
        _olcTotLiabLimCurr = 0 ;
        _olcPaymntCurr = "" ;
        _olcTotChrgsInPaymntCurr = 0 ;
        _olcCashMarginBal = 0 ;
        _olcReimbChrgsBy = ' ';
        _olcPercRcPaidByApplcnt = 0 ;
        _olcNostroAlphaCode = "" ;
        _olcAdvThruBk = "" ;
        _olcAdvThruBrn = "" ;
        _olcLcToBeCnfrmd = ' ';
        _olcLcToBeCnfrmdByBk = "" ;
        _olcLcToBeCnfrmdByBrn = "" ;
        _olcRestricted = ' ';
        _olcRestrictedToUs = ' ';
        _olcRestrictedBkCode = "" ;
        _olcRestrictedBrnCode = "" ;
        _olcCrAvlblBy = ' ';
        _olcIrrevocable = ' ';
        _olcPartShpmnt = ' ';
        _olcTranShpmnt = ' ';
        _olcLcTransfrbl = ' ';
        _olcDftReqd = ' ';
        _olcPercDftValue = 0 ;
        _olcDftToBeDrawnOn = ' ';
        _olcDftOnBk = "" ;
        _olcDftOnBrn = "" ;
        _olcSpecText1 = "" ;
        _olcSpecText2 = "" ;
        _olcSpecText3 = "" ;
        _olcSpecText4 = "" ;
        _olcPrimeRateClauseReq = ' ';
        _olcShpmntMode = ' ';
        _olcLloydsClauseReq = ' ';
        _olcMaxShipAge = 0 ;
        _olcShortFormOfBl = ' ';
        _olcLashTransDocsAllwd = ' ';
        _olcPercOfInsValueCvrd = 0 ;
        _olcInsPolicyNum = "" ;
        _olcInsDate = null ;
        _olcInsCurr = "" ;
        _olcInsAmt = 0 ;
        _olcPremiumCurr = "" ;
        _olcPremiumAmt = 0 ;
        _olcInsCompany = "" ;
        _olcInsCompanyName = "" ;
        _olcCooIssBy = "" ;
        _olcOtherCompAuth = "" ;
        _olcIntermediaryTrade = ' ';
        _olcInspTestCertReq = ' ';
        _olcCertBy = "" ;
        _olcImpUnder = ' ';
        _olcImpPolicyDet = "" ;
        _olcImpRef = "" ;
        _olcCustLiabAcc = 0 ;
        _olcCancelledOn = null ;
        _olcUsanceCharges = 0 ;
        _olcUsnChgTakenDays = 0 ;
        _olcCommitmentCharges = 0 ;
        _olcCommitChgTakenDays = 0 ;
        _tranchgsChgsSl = 0 ;
        _trancratesRateSl = 0 ;
        _transtlmntInvNum = 0 ;
        _postTranBrn = 0 ;
        _postTranDate = null ;
        _postTranBatchNum = 0 ;
        _olcEntdBy = "" ;
        _olcEntdOn = null ;
        _olcLastmodBy = "" ;
        _olcLastmodOn = null ;
        _olcAuthBy = "" ;
        _olcAuthOn = null ;
        _olcRejBy = "" ;
        _olcRejOn = null ;
        _olcMarginCurr = "" ;
        _olcMarginAmt = 0 ;
        _olcMarginBal = 0 ;
        _olcCashMarAmt = 0 ;
        _olcCashMarBal = 0 ;
        _olcCashMarRec = 0 ;
        _olcDepMarRec = 0 ;
        _olcOthSecMarRec = 0 ;
        _olcUsanceServTax = 0 ;
        _olcCommitServTax = 0 ;
    }

}
