package panacea.OLC.ejb;


import java.rmi.RemoteException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import panacea.common.DTObject;
import panacea.common.PanErrorMsg;
import panacea.common.PanaceaException;
import panacea.common.FormatUtils;
import panacea.TranControl.TransControl;
import panacea.IBIL.Update.Ibill;
import panacea.IBIL.Update.IbillManager;
import panacea.OLC.Update.Olc;
import panacea.OLC.Update.OlcManager;
import panacea.OLC.Update.Olcled;
import panacea.OLC.Update.OlcledManager;
import panacea.OLC.Update.Olcmar;
import panacea.OLC.Update.OlcmarManager;
import panacea.OLC.Update.Olcotext;
import panacea.OLC.Update.OlcotextManager;
import panacea.OLC.Update.Olcshiptext;
import panacea.OLC.Update.OlcshiptextManager;
import panacea.OLC.Update.Olctenors;
import panacea.OLC.Update.OlctenorsManager;
import panacea.TFM.Update.Fxratereqsl;
import panacea.TFM.Update.FxratereqslManager;
import panacea.TFM.Update.Tbillserial;
import panacea.TFM.Update.TbillserialManager;
//import panacea.ACC.Update.UsrrmnuManager;
import panacea.AML.Update.blacklistVerificationQueueUpdate;
import panacea.COMP.Update.ctrancratesBO;
import panacea.COMP.Update.ctranchgsBO;
import panacea.COMP.Update.TranstlmntBO;
import panacea.OLC.Update.Lcps;
import panacea.OLC.Update.LcpsManager;
import panacea.OLC.Update.LcDetails;
import panacea.OLC.Update.LcDetailsManager;
import panacea.OLC.Update.LcDetailsHist;
import panacea.OLC.Update.LcDetailsHistManager;
import panacea.autopost.comp.*;

        /**
        * XDoclet-based session bean.  The class must be declared
        * public according to the EJB specification.
        *
        * To generate the EJB related files to this EJB:
        *		- Add Standard EJB module to XDoclet project properties
        *		- Customize XDoclet configuration for your appserver
        *		- Run XDoclet
        * @ejb.bean name= "eolcBO"
        *           display-name="Name for Bean Information"
        *           description="Description"
        *           jndi-name="ejb/eolcBO"
        *           type="Stateless"
        *           view-type="both"
        *           transaction-type = "Bean"
        * @ejb.interface
        *     remote-class ="panacea.OLC.interfaces.eolc"
        *     local-class  ="panacea.OLC.interfaces.eolcLocal"
        * @ejb.home
        *     remote-class ="panacea.OLC.interfaces.eolcHome"
        *     local-class  ="panacea.OLC.interfaces.eolcLocalHome"
        *
        */
public class eolcBO extends postingComponent implements SessionBean
{


	 	private ctranchgsBO ctranchgsInstance;
	 	private ctrancratesBO ctrancratesInstance;
        private String Option;
        private String branchCode;
        private String CurrDate;
        private String _sourceKey;
        private String olcType;
        private String olcYear;
        private int olcSl;
        private String useroption;
        private String lcdate;
        private String prevlcdate;
        
        private double equamt;
        private double amtcon;
        private double avg;
        
        //local variable for OLCLED table updation
        String txntype="L";
        String txsl="1";
        String redenh="E";
        String olcledsourcekey=" ";
        
        //local variable for OLCOTEXT table updation
        String olcotextsl="1";
        String olcotexttype="L";
        
        
        //local variable for OLCSHIPTEXT table updation 
        String shiptexttype="SH";
        String presenttype="PD";
        String refno;
        String slflag;
        
        //voucher variables 
        private String batno;
        private String trandate;
        private String tranbranch;
        private String contraGL;
        //Changes P.Subramani-19-06-2008 Beg
        private String contraGL1;
        private String contraGL2;
        private String usancechgcode;
        private String commchgcode;
        private double usancechgs;
        private double commchgs;
        //Changes P.Subramani 19-06-2008 End
		
	  //S.Suresh Babu Add 30-06-2009
        private double olc_commit_serv_tax;
        private double olc_usance_serv_tax;

        private String intaccNo;
        private String basecurr;
        private String totchargeamt;
      //Changes-M.S.Jayanthi-Chn-11/11/2009-beg
        private String inover;
      //Changes-M.S.Jayanthi-Chn-11/11/2009-end
        private long max_sl1 =0;
     // changes in EOLC on 12-Jun-2018 start
        private String _brnAuth = "";
        private String userBrnCode = "";
     // changes in EOLC on 12-Jun-2018 end
        
        
        
        private SessionContext context;
        
        public eolcBO(){
        super();
        
    }
    /**
     * Set the associated session context. The container calls this method
    * after the instance creation.
    * 
    * The enterprise bean instance should store the reference to the context
    * object in an instance variable.
    * 
    * This method is called with no transaction context.
    * 
    * @throws EJBException Thrown if method fails due to system-level error.
    */
        public void setSessionContext(SessionContext newContext)
        throws EJBException {
            context = newContext;
        }
        public void ejbRemove() throws EJBException, RemoteException {
        // TODO Auto-generated method stub
        
        }
        public void ejbActivate() throws EJBException, RemoteException {
        // TODO Auto-generated method stub
        
        }
        public void ejbPassivate() throws EJBException, RemoteException {
        // TODO Auto-generated method stub
        
        }
        /**
        * An ejbCreate method as required by the EJB specification.
        * 
        * The container calls the instance?s <code>ejbCreate</code> method whose
        * signature matches the signature of the <code>create</code> method invoked
        * by the client. The input parameters sent from the client are passed to
        * the <code>ejbCreate</code> method. Each session bean class must have at
        * least one <code>ejbCreate</code> method. The number and signatures
        * of a session bean?s <code>create</code> methods are specific to each 
        * session bean class.
        * 
        * @throws CreateException Thrown if method fails due to system-level error.
        * 
        
            * @ejb.create-method
        * 
        */
        public void ejbCreate() throws CreateException {
        // TODO Add ejbCreate method implementation
        
        }
        
        
        
        private void Init_Para() throws PanaceaException {
            Tba_key_In_Main_Table		= "";
            Programid 					= "eolc";
            TBAAUTH_MAIN_TABLE_NAME 	= "OLC";
            TBAAUTH_MAIN_PK 			= dtoobj.getValue("OLC_BRN_CODE") +"|" + dtoobj.getValue("OLC_LC_TYPE")+"|"+ dtoobj.getValue("OLC_LC_YEAR")+"|"+dtoobj.getValue("OLC_LC_SL");
            TBAAUTH_ENTRY_DATE 			= null; 
            TBAAUTH_DTL_SL 				= 0; 
            TBA_DISPLAY_DTLS 				= "";
            Option 						= dtoobj.getValue("UserOption");
            TBAAUTH_OPERN_FLG 			= Option;
            User_Id						= dtoobj.getValue("USERID");
            ReturnResult 				= new DTObject();
            ReturnResult.clearMap();
            tba_auth_queue_req			= false;
            Table_Class_Name			= "OLC";
            ctranchgsInstance = new ctranchgsBO();
            ctrancratesInstance = new ctrancratesBO();
            /* Olc  OlcInstance;
            OlcManager  OlcManagerInstance = new OlcManager(_COLLECTIONObj,V_LOG_REQ, V_ADD_LOG_REQ);
            try
                {
                OlcInstance = OlcManagerInstance.loadByKey(Integer.parseInt(dtoobj.getValue("OLC_BRN_CODE")),Integer.parseInt(dtoobj.getValue("IRTT_TRAN_SLNO")),dtoobj.getValue("IRTT_TYPE"),Integer.parseInt(dtoobj.getValue("IRTT_YEAR")));
                if (OlcInstance != null)
                {
                //Tba_key_In_Main_Table	= OlcInstance.getTbaMainKey();
                }
                else
                {
                Tba_key_In_Main_Table	 = "";
                }
                } catch (SQLException e) {
                throw new PanaceaException(e.getLocalizedMessage());
                }*/
            }
        
        
        
        /**
         * @ejb.interface-method view-type = "both"
        */
        public DTObject updateValues(DTObject InputmapObj)throws EJBException,RemoteException,SQLException
            {
                dtoobj = InputmapObj;
                DTObject tranchgsDTO = new DTObject();
                DTObject trancratesDTO=new DTObject();
                Connection 			connDB = null;
                PreparedStatement _pstmt = null;
                try
                {
                	
                	tranbranch=dtoobj.getValue("POST_TRAN_BRN");
                    trandate=dtoobj.getValue("POST_TRAN_DATE");
                    batno=dtoobj.getValue("POST_TRAN_BATCH_NUM");
                    intaccNo=dtoobj.getValue("INT_ACC_NO");
                    basecurr=dtoobj.getValue("BASE_CURR");
                    totchargeamt=dtoobj.getValue("OLC_TOT_CHRGS_IN_PAYMNT_CURR");
                    
                	useroption=InputmapObj.getValue("UserOption");
                	CurrDate	=	InputmapObj.getValue("CURRDATE");
                	branchCode = InputmapObj.getValue("OLC_BRN_CODE");
                	olcType = InputmapObj.getValue("OLC_LC_TYPE");
                	olcYear = InputmapObj.getValue("OLC_LC_YEAR");
                	olcSl =Integer.parseInt(InputmapObj.getValue("OLC_LC_SL"));
                	lcdate=InputmapObj.getValue("OLC_LC_DATE");
                	prevlcdate=InputmapObj.getValue("PREV_LC_DATE");
                	refno=InputmapObj.getValue("OLC_CORR_REF_NUM");
                	//Changes-M.S.Jayanthi-Chn-11/11/2009-beg
                	inover=InputmapObj.getValue("TNOMEN_INLAND_OVERSEAS");
                	//Changes-M.S.Jayanthi-Chn-11/11/2009-end
                	//Changes P.Subramani-Chn-19-06-2008 Beg
                	//usancechgcode = InputmapObj.getValue("TRCHG_USANCE_CHGCD");
                	//commchgcode = InputmapObj.getValue("TRCHG_COMMITMNT_CHGCD");
                	
                	usancechgs = Double.parseDouble(InputmapObj.getValue("USANCE_CHARGES"));
                	commchgs = Double.parseDouble(InputmapObj.getValue("COMMITMENT_CHARGES"));
                	//Changes P.Subramani-Chn-19-06-2008 End
                	
                	//S.Suresh Babu Add 30-06-2009
                	olc_commit_serv_tax = Double.parseDouble(InputmapObj.getValue("OLC_COMMIT_SERV_TAX"));
                	olc_usance_serv_tax = Double.parseDouble(InputmapObj.getValue("OLC_USANCE_SERV_TAX"));
                	
                	
                	
                	slflag=InputmapObj.getValue("SL_FLAG");
                	// changes in EOLC on 12-Jun-2018 start
                	_brnAuth = InputmapObj.getValue("USER_BRNAUTH");
                	userBrnCode = InputmapObj.getValue("USRBRNCODE");
                	// changes in EOLC on 12-Jun-2018 end
                	
                	//Changes P.Subramani-Chn-18/02/2008 Beg
                	if(dtoobj.getValue("OLC_LC_CURR_CODE").equalsIgnoreCase(basecurr))
                	{
                		equamt=Double.parseDouble(dtoobj.getValue("OLC_TOT_LIAB_LC_CURR"));
                		avg = 1;
                    }
                	else
                	{
                		equamt=Double.parseDouble(InputmapObj.getValue("TOT_EQUIVAMT"));
                		amtcon=Double.parseDouble(InputmapObj.getValue("TOTAMT_CONVERTED"));
                		//S.Suresh Babu Changes 24-09-2009
                		avg=Double.parseDouble(InputmapObj.getValue("OLC_CONV_RATE_BASE_CURR"));
                    }
                	//Changes P.Subramani-Chn-18/02/2008 End
                	
                	
                	if((useroption.equalsIgnoreCase("A")) && (slflag.equalsIgnoreCase("YES")))
                	{
                		olcSl=olcSl+1;
                	}
                	
                	_sourceKey = branchCode+"|"+olcType+"|"+olcYear+"|"+olcSl;
                	Init_Para();
                    BeginTransaction(context);
                    check_for_tba_updation();
                    ctranchgsInstance.set_COLLECTIONObj(_COLLECTIONObj);
                    ctranchgsInstance.setV_ADD_LOG_REQ(V_ADD_LOG_REQ);
                    ctranchgsInstance.setV_LOG_REQ(V_LOG_REQ);
                    
                    tranchgsDTO = ctranchgsInstance.updateValues(InputmapObj);
                    InputmapObj.setValue("TRANCHGS_RET_SL",tranchgsDTO.getValue("TRANCHGS_SL"));
                    //Changes P.Subramani-Chn-22/02/2008 Beg
                    if(!(dtoobj.getValue("OLC_LC_CURR_CODE").equalsIgnoreCase(basecurr)))
                	{
                    ctrancratesInstance.set_COLLECTIONObj(_COLLECTIONObj);
                    ctrancratesInstance.setV_ADD_LOG_REQ(V_ADD_LOG_REQ);
                    ctrancratesInstance.setV_LOG_REQ(V_LOG_REQ);
                    
                    InputmapObj.setValue("BRANCH_CODE",branchCode);
                    InputmapObj.setValue("RATEACC_DATE",CurrDate);
                    InputmapObj.setValue("TRANSACTION_DATE",InputmapObj.getValue("OLC_LC_DATE"));  
                    
                    trancratesDTO = ctrancratesInstance.updateValues(InputmapObj);
                    InputmapObj.setValue("TRANCRATES_RET_SL",trancratesDTO.getValue("TRANCRATES_SL"));
                	}//Changes P.Subramani-Chn-22/02/2008 End
                    if (Option.equalsIgnoreCase("A")) {
                        addRecord(InputmapObj);
                        if(slflag.equalsIgnoreCase("YES"))
                        {
                        addtbillsl(InputmapObj);
                        }
                        OlcLedAddRecord(InputmapObj);
                        AddOlcoText(InputmapObj);
                        AddOlcShipText(InputmapObj);
                        AddOlcMar(InputmapObj);
                        //changes in eolc on 01-jun-2018 start
                        if(olcType.trim().equals("OLC"))
                        {
                        	AddSwiftLcDetails(InputmapObj);
                        	setSerialNumber(InputmapObj);
                        	addLCHistRecord(InputmapObj);	
                        }
                      //changes in eolc on 01-jun-2018 end
                        //addlcps(InputmapObj); //Prabu K Changes-Removed on 18-Nov-2011
                        ReturnResult.setValue("SERIAL",String.valueOf(olcSl));
                       
                    }else{
                        modRecord(InputmapObj);
                        if(!(lcdate.equalsIgnoreCase(prevlcdate)))
                        {
                        OlcLedModRecord(InputmapObj);
                        }
                        ModOlcoText(InputmapObj);
                        ModOlcShipText(InputmapObj);
                        ModOlcMar(InputmapObj);
                        //changes in eolc on 01-jun-2018 start
                        if(olcType.trim().equals("OLC"))
                        	ModifySwifLcDetails(InputmapObj);
                        //changes in eolc on 01-jun-2018 end                        
                    }
                    addolctenor(InputmapObj);
                    //ADDED ON 01/10/2018 START
                    if(olcType.trim().equals("OLC"))
                    {
                    	System.out.println("olc");
                    	Updateclobolc();
                    }
                    //ADDED ON 01/10/2018 END
                    
               	    //ADDED BY PRASHANTH FOR BLACKLIST VERIRFICATION ON 06 JANUARY 2019
               	    setBlackListVerification(InputmapObj);
               	    //ADDED BY PRASHANTH FOR BLACKLIST VERIRFICATION ON 06 JANUARY 2019

                    posting_Transaction(InputmapObj);
                    

                    	CommitTran();
                    
            }
            catch (PanaceaException  Excep)
            {
            RollBackTran(Excep.getLocalizedMessage());
            }
            /*finally{
            	
                if(_pstmt!=null) try {   _pstmt.close();} catch(Exception e2) {}
            }
            try {
            	System.out.println("start");
            	connDB = openConnection();
            	String _QueryStr = "SELECT PKG_CSB_SWIFT.INSERT_CLOBDATAOLC(?,?,?,?,?,?,?) isEligible FROM DUAL";
            	_pstmt = connDB.prepareStatement(_QueryStr);
		        _pstmt.setInt(1,Integer.parseInt(dtoobj.getValue("OLC_BRN_CODE")) ); 
		        _pstmt.setString(2,dtoobj.getValue("OLC_LC_TYPE").trim()); 
		        _pstmt.setInt(3,Integer.parseInt(dtoobj.getValue("OLC_LC_YEAR").trim()) ); 
		        _pstmt.setString(4,FormatUtils.formatToDDMonYear(dtoobj.getValue("OLC_LC_PRESANC_DATE")));
		        _pstmt.setLong(5,Integer.parseInt(dtoobj.getValue("OLC_LC_PRESANC_DAY_SL"))); 
		        _pstmt.setLong(6,Long.parseLong(dtoobj.getValue("OLC_CUST_NUM")));
		        _pstmt.setInt(7,olcSl );
				_pstmt.executeUpdate();
				_pstmt.close();
				}
		    catch(SQLException e) {
		    	System.out.println(e.getMessage());	
		    	_pstmt = null;
		    	RollBackTran(e.getLocalizedMessage());
		    }
		    finally{
	            if(_pstmt!=null) try { _pstmt.close();} catch(Exception e2) {}
	            if(connDB!=null) try { connDB.close();} catch(Exception e2) {}            
	        }*/
           
		    /*
		     * dtoobject.getValue("OLC_LC_PRESANC_DATE")));
                    OlcInstance.setOlcLcPresancDaySl(Integer.parseInt(dtoobject.getValue("OLC_LC_PRESANC_DAY_SL")));
		     * OlcInstance.setOlcBrnCode(Integer.parseInt(dtoobject.getValue("OLC_BRN_CODE")));
                    OlcInstance.setOlcLcType(dtoobject.getValue("OLC_LC_TYPE"));
                    OlcInstance.setOlcLcYear(Integer.parseInt(dtoobject.getValue("OLC_LC_YEAR")));
                    OlcInstance.setOlcLcSl(olcSl);
		     * pkg_csb_swift.insert_clobdataolc(p_brn => :p_brn,
                                              p_type => :p_type,
                                              p_year => :p_year,
                                              p_entry_date => :p_entry_date,
                                              p_pres_sl => :p_pres_sl,
                                              p_clientid => :p_clientid)*/
		     
        return ReturnResult;
        }
        private void Set_Entd_Dtls( Olc inputObj) throws PanaceaException
        {
            if (Option.equalsIgnoreCase("A"))
                {
                    inputObj.setOlcEntdBy(User_Id);
                    inputObj.setOlcEntdOn(Get_System_Time());
                }
            else
                {
                    inputObj.setOlcAuthBy("");
                    inputObj.setOlcAuthOn(null);
                }
            inputObj.setOlcAuthBy("");
            inputObj.setOlcAuthOn(null);
            }
        
        
        //ADDED BY PRASHANTH FOR BLACKLIST VERIRFICATION ON 04 JANUARY 2019
        private void setBlackListVerification(DTObject InputmapObj) throws PanaceaException {
    		blacklistVerificationQueueUpdate blkUpdate = new blacklistVerificationQueueUpdate();
    		InputmapObj.setValue("PROGRAM_ID", "EOLC");
    		InputmapObj.setValue("MODULE_CODE", "OLC");
    		InputmapObj.setValue("SRC_TABLE", "OLC");
    		InputmapObj.setValue("BRANCH_CODE", branchCode);
    		InputmapObj.setValue("BLKLSTVQ_DATE", dtoobj.getValue("OLC_LC_DATE"));  
    		InputmapObj.setValue("CUST_CODE", InputmapObj.getValue("OLC_CUST_NUM"));
    		InputmapObj.setValue("CPARTY_CODE", InputmapObj.getValue("OLC_BENEF_CODE"));
    		InputmapObj.setValue("SOURCE_KEY", _sourceKey);
    		blkUpdate.updateBlackValue(InputmapObj);
    	}
   	    //ADDED BY PRASHANTH FOR BLACKLIST VERIRFICATION ON 04 JANUARY 2019
        
        
        private void addRecord(DTObject dtoobject) throws PanaceaException
        {
            try
            {
                Olc  OlcInstance=new Olc();
                OlcManager  OlcManagerInstance = new OlcManager(_COLLECTIONObj,V_LOG_REQ, V_ADD_LOG_REQ);
                            
                			
                            OlcInstance.setOlcBrnCode(Integer.parseInt(dtoobject.getValue("OLC_BRN_CODE")));
                            OlcInstance.setOlcLcType(dtoobject.getValue("OLC_LC_TYPE"));
                            OlcInstance.setOlcLcYear(Integer.parseInt(dtoobject.getValue("OLC_LC_YEAR")));
                            OlcInstance.setOlcLcSl(olcSl);
                            OlcInstance.setOlcCorrRefNum(dtoobject.getValue("OLC_CORR_REF_NUM"));
                            OlcInstance.setOlcLcPresancDate(DateToYYYYMMDD(dtoobject.getValue("OLC_LC_PRESANC_DATE")));
                            OlcInstance.setOlcLcPresancDaySl(Integer.parseInt(dtoobject.getValue("OLC_LC_PRESANC_DAY_SL")));
                            OlcInstance.setOlcLcDate(DateToYYYYMMDD(dtoobject.getValue("OLC_LC_DATE")));
                            OlcInstance.setOlcCustNum(Long.parseLong(dtoobject.getValue("OLC_CUST_NUM")));
                            OlcInstance.setOlcBenefCode(dtoobject.getValue("OLC_BENEF_CODE"));
                            OlcInstance.setOlcBenefName(dtoobject.getValue("OLC_BENEF_NAME"));
                            OlcInstance.setOlcBenefAddr1(dtoobject.getValue("OLC_BENEF_ADDR1"));
                            OlcInstance.setOlcBenefAddr2(dtoobject.getValue("OLC_BENEF_ADDR2"));
                            OlcInstance.setOlcBenefAddr3(dtoobject.getValue("OLC_BENEF_ADDR3"));
                            OlcInstance.setOlcBenefAddr4(dtoobject.getValue("OLC_BENEF_ADDR4"));
                            OlcInstance.setOlcBenefAddr5(dtoobject.getValue("OLC_BENEF_ADDR5"));
                            OlcInstance.setOlcBenefCntryCode(dtoobject.getValue("OLC_BENEF_CNTRY_CODE"));
                            OlcInstance.setOlcLcIssBkCode(dtoobject.getValue("OLC_LC_ISS_BK_CODE"));
                            OlcInstance.setOlcLcIssBrnCode(dtoobject.getValue("OLC_LC_ISS_BRN_CODE"));
                            OlcInstance.setOlcLcIssBrnName(dtoobject.getValue("OLC_LC_ISS_BRN_NAME"));
                            OlcInstance.setOlcLcIssBrnAdd1(dtoobject.getValue("OLC_LC_ISS_BRN_ADD1"));
                            OlcInstance.setOlcLcIssBrnAdd2(dtoobject.getValue("OLC_LC_ISS_BRN_ADD2"));
                            OlcInstance.setOlcLcIssBrnAdd3(dtoobject.getValue("OLC_LC_ISS_BRN_ADD3"));
                            OlcInstance.setOlcLcIssBrnAdd4(dtoobject.getValue("OLC_LC_ISS_BRN_ADD4"));
                            OlcInstance.setOlcLcIssBrnAdd5(dtoobject.getValue("OLC_LC_ISS_BRN_ADD5"));
                            OlcInstance.setOlcLcIssPlace(dtoobject.getValue("OLC_LC_ISS_PLACE"));
                            OlcInstance.setOlcLcIssCntry(dtoobject.getValue("OLC_LC_ISS_CNTRY"));
                            OlcInstance.setOlcLcAdvThru(stringToChar(dtoobject.getValue("OLC_LC_ADV_THRU")));
                            OlcInstance.setOlcLcCurrCode(dtoobject.getValue("OLC_LC_CURR_CODE"));
                            OlcInstance.setOlcLcAmount(Double.parseDouble(dtoobject.getValue("OLC_LC_AMOUNT")));
                            OlcInstance.setOlcLcBalance(Double.parseDouble(dtoobject.getValue("OLC_LC_BALANCE")));
                            OlcInstance.setOlcDevAllwd(stringToChar(dtoobject.getValue("OLC_DEV_ALLWD")));
                            OlcInstance.setOlcPosDevAllwd(Double.parseDouble(dtoobject.getValue("OLC_POS_DEV_ALLWD")));
                            OlcInstance.setOlcNegDevAllwd(Double.parseDouble(dtoobject.getValue("OLC_NEG_DEV_ALLWD")));
                            OlcInstance.setOlcDevAmount(Double.parseDouble(dtoobject.getValue("OLC_DEV_AMOUNT")));
                            OlcInstance.setOlcDevBal(Double.parseDouble(dtoobject.getValue("OLC_DEV_BAL")));
                            OlcInstance.setOlcAmtQualfr(stringToChar(dtoobject.getValue("OLC_AMT_QUALFR")));
                            OlcInstance.setOlcPriceTerms(dtoobject.getValue("OLC_PRICE_TERMS"));
                            OlcInstance.setOlcLastDateOfNeg(DateToYYYYMMDD(dtoobject.getValue("OLC_LAST_DATE_OF_NEG")));
                            OlcInstance.setOlcPlaceOfExpiry(dtoobject.getValue("OLC_PLACE_OF_EXPIRY"));
                            OlcInstance.setOlcLatestDateOfShpmnt(DateToYYYYMMDD(dtoobject.getValue("OLC_LATEST_DATE_OF_SHPMNT")));
                            OlcInstance.setOlcWithinValidateLc(stringToChar(dtoobject.getValue("OLC_WITHIN_VALIDATE_LC")));
                            OlcInstance.setOlcLcUiBorneByApplcnt(stringToChar(dtoobject.getValue("OLC_LC_UI_BORNE_BY_APPLCNT")));
                            OlcInstance.setOlcNofTenors(Integer.parseInt(dtoobject.getValue("OLC_NOF_TENORS")));
                            OlcInstance.setOlcLcUnderContract(stringToChar(dtoobject.getValue("OLC_LC_UNDER_CONTRACT")));
                            OlcInstance.setOlcTotLiabLcCurr(Double.parseDouble(dtoobject.getValue("OLC_TOT_LIAB_LC_CURR")));
                            OlcInstance.setOlcConvRateBaseCurr(avg);
                            OlcInstance.setOlcTotLiabBaseCurr(Double.parseDouble(dtoobject.getValue("OLC_TOT_LIAB_BASE_CURR")));
                            OlcInstance.setOlcConvRateLimCurr(Double.parseDouble(dtoobject.getValue("OLC_CONV_RATE_LIM_CURR")));
                            OlcInstance.setOlcTotLiabLimCurr(Double.parseDouble(dtoobject.getValue("OLC_TOT_LIAB_LIM_CURR")));
                            OlcInstance.setOlcPaymntCurr(dtoobject.getValue("OLC_PAYMNT_CURR"));
                            OlcInstance.setOlcTotChrgsInPaymntCurr(Double.parseDouble(dtoobject.getValue("OLC_TOT_CHRGS_IN_PAYMNT_CURR")));
                            OlcInstance.setOlcCashMarginBal(Double.parseDouble(dtoobject.getValue("OLC_CASH_MARGIN_BAL")));
                            OlcInstance.setOlcReimbChrgsBy(stringToChar(dtoobject.getValue("OLC_REIMB_CHRGS_BY")));
                            OlcInstance.setOlcPercRcPaidByApplcnt(Double.parseDouble(dtoobject.getValue("OLC_PERC_RC_PAID_BY_APPLCNT")));
                            OlcInstance.setOlcNostroAlphaCode(dtoobject.getValue("OLC_NOSTRO_ALPHA_CODE"));
                            OlcInstance.setOlcAdvThruBk(dtoobject.getValue("OLC_ADV_THRU_BK"));
                            OlcInstance.setOlcAdvThruBrn(dtoobject.getValue("OLC_ADV_THRU_BRN"));
                            OlcInstance.setOlcLcToBeCnfrmd(stringToChar(dtoobject.getValue("OLC_LC_TO_BE_CNFRMD")));
                            //Changes Sanjay1 22-07-2019 Begin
                            //OlcInstance.setOlcLcToBeCnfrmdByBk(dtoobject.getValue("OLC_LC_TO_BE_CNFRMD_BY_BK"));
                            //OlcInstance.setOlcLcToBeCnfrmdByBrn(dtoobject.getValue("OLC_LC_TO_BE_CNFRMD_BY_BRN"));
                            //Changes Sanjay1 22-07-2019 END
                            OlcInstance.setOlcRestricted(stringToChar(dtoobject.getValue("OLC_RESTRICTED")));
                            OlcInstance.setOlcRestrictedToUs(stringToChar(dtoobject.getValue("OLC_RESTRICTED_TO_US")));
                            OlcInstance.setOlcRestrictedBkCode(dtoobject.getValue("OLC_RESTRICTED_BK_CODE"));
                            OlcInstance.setOlcRestrictedBrnCode(dtoobject.getValue("OLC_RESTRICTED_BRN_CODE"));
                            OlcInstance.setOlcCrAvlblBy(stringToChar(dtoobject.getValue("OLC_CR_AVLBL_BY")));
                            OlcInstance.setOlcIrrevocable(stringToChar(dtoobject.getValue("OLC_IRREVOCABLE")));
                            OlcInstance.setOlcPartShpmnt(stringToChar(dtoobject.getValue("OLC_PART_SHPMNT")));
                            OlcInstance.setOlcTranShpmnt(stringToChar(dtoobject.getValue("OLC_TRAN_SHPMNT")));
                            OlcInstance.setOlcLcTransfrbl(stringToChar(dtoobject.getValue("OLC_LC_TRANSFRBL")));
                            OlcInstance.setOlcDftReqd(stringToChar(dtoobject.getValue("OLC_DFT_REQD")));
                            OlcInstance.setOlcPercDftValue(Double.parseDouble(dtoobject.getValue("OLC_PERC_DFT_VALUE")));
                            OlcInstance.setOlcDftToBeDrawnOn(stringToChar(dtoobject.getValue("OLC_DFT_TO_BE_DRAWN_ON")));
                            OlcInstance.setOlcDftOnBk(dtoobject.getValue("OLC_DFT_ON_BK"));
                            OlcInstance.setOlcDftOnBrn(dtoobject.getValue("OLC_DFT_ON_BRN"));
                            OlcInstance.setOlcSpecText1(dtoobject.getValue("OLC_SPEC_TEXT1"));
                            OlcInstance.setOlcSpecText2(dtoobject.getValue("OLC_SPEC_TEXT2"));
                            OlcInstance.setOlcSpecText3(dtoobject.getValue("OLC_SPEC_TEXT3"));
                            OlcInstance.setOlcSpecText4(dtoobject.getValue("OLC_SPEC_TEXT4"));
                            OlcInstance.setOlcPrimeRateClauseReq(stringToChar(dtoobject.getValue("OLC_PRIME_RATE_CLAUSE_REQ")));
                            OlcInstance.setOlcShpmntMode(stringToChar(dtoobject.getValue("OLC_SHPMNT_MODE")));
                            OlcInstance.setOlcLloydsClauseReq(stringToChar(dtoobject.getValue("OLC_LLOYDS_CLAUSE_REQ")));
                            OlcInstance.setOlcMaxShipAge(Integer.parseInt(dtoobject.getValue("OLC_MAX_SHIP_AGE")));
                            OlcInstance.setOlcShortFormOfBl(stringToChar(dtoobject.getValue("OLC_SHORT_FORM_OF_BL")));
                            OlcInstance.setOlcLashTransDocsAllwd(stringToChar(dtoobject.getValue("OLC_LASH_TRANS_DOCS_ALLWD")));
                            OlcInstance.setOlcPercOfInsValueCvrd(Double.parseDouble(dtoobject.getValue("OLC_PERC_OF_INS_VALUE_CVRD")));
                            OlcInstance.setOlcInsPolicyNum(dtoobject.getValue("OLC_INS_POLICY_NUM"));
                            OlcInstance.setOlcInsDate(DateToYYYYMMDD(dtoobject.getValue("OLC_INS_DATE")));
                            OlcInstance.setOlcInsCurr(dtoobject.getValue("OLC_INS_CURR"));
                            OlcInstance.setOlcInsAmt(Double.parseDouble(dtoobject.getValue("OLC_INS_AMT")));
                            OlcInstance.setOlcPremiumCurr(dtoobject.getValue("OLC_PREMIUM_CURR"));
                            OlcInstance.setOlcPremiumAmt(Double.parseDouble(dtoobject.getValue("OLC_PREMIUM_AMT")));
                            OlcInstance.setOlcInsCompany(dtoobject.getValue("OLC_INS_COMPANY"));
                            OlcInstance.setOlcInsCompanyName(dtoobject.getValue("OLC_INS_COMPANY_NAME"));
                            OlcInstance.setOlcCooIssBy(dtoobject.getValue("OLC_COO_ISS_BY"));
                            OlcInstance.setOlcOtherCompAuth(dtoobject.getValue("OLC_OTHER_COMP_AUTH"));
                            OlcInstance.setOlcIntermediaryTrade(stringToChar(dtoobject.getValue("OLC_INTERMEDIARY_TRADE")));
                            OlcInstance.setOlcInspTestCertReq(stringToChar(dtoobject.getValue("OLC_INSP_TEST_CERT_REQ")));
                            OlcInstance.setOlcCertBy(dtoobject.getValue("OLC_CERT_BY"));
                            OlcInstance.setOlcImpUnder(stringToChar(dtoobject.getValue("OLC_IMP_UNDER")));
                            OlcInstance.setOlcImpPolicyDet(dtoobject.getValue("OLC_IMP_POLICY_DET"));
                            OlcInstance.setOlcImpRef(dtoobject.getValue("OLC_IMP_REF"));
                            OlcInstance.setOlcCancelledOn(DateToYYYYMMDD(dtoobject.getValue("OLC_CANCELLED_ON")));
                            //Changes P.Subramani-Chn-11/04/2008  Beg
                            OlcInstance.setOlcUsanceCharges(Double.parseDouble(dtoobject.getValue("USANCE_CHARGES")));
                            OlcInstance.setOlcUsnChgTakenDays(Integer.parseInt(dtoobject.getValue("OLC_USN_CHG_TAKEN_DAYS")));
                            OlcInstance.setOlcCommitmentCharges(Double.parseDouble(dtoobject.getValue("COMMITMENT_CHARGES")));
                            OlcInstance.setOlcCommitChgTakenDays(Integer.parseInt(dtoobject.getValue("OLC_COMMIT_CHG_TAKEN_DAYS")));
                            //Changes P.Subramani-Chn-11/04/2008  End
                            OlcInstance.setTranchgsChgsSl(Long.parseLong(dtoobject.getValue("TRANCHGS_RET_SL")));
                            //Changes P.Subramani-Chn-22/02/2008
                            if(!(dtoobj.getValue("OLC_LC_CURR_CODE").equalsIgnoreCase(basecurr)))
                        	{
                            OlcInstance.setTrancratesRateSl(Long.parseLong(dtoobject.getValue("TRANCRATES_RET_SL")));
                        	}
                            OlcInstance.setOlcCustLiabAcc(Long.parseLong(intaccNo));
                            //OlcInstance.setTranstlmntInvNum(Long.parseLong(dtoobject.getValue("TRANSTLMNT_INV_NUM")));
                            //OlcInstance.setPostTranBrn(Integer.parseInt(dtoobject.getValue("POST_TRAN_BRN")));
                            //OlcInstance.setPostTranDate(DateToYYYYMMDD(dtoobject.getValue("POST_TRAN_DATE")));
                            //OlcInstance.setPostTranBatchNum(Integer.parseInt(dtoobject.getValue("POST_TRAN_BATCH_NUM")));
                            //OlcInstance.setOlcLastmodBy(dtoobject.getValue("OLC_LASTMOD_BY"));
                            //OlcInstance.setOlcLastmodOn(DateToYYYYMMDD(dtoobject.getValue("OLC_LASTMOD_ON")));
                            //OlcInstance.setOlcRejBy(dtoobject.getValue("OLC_REJ_BY"));
                            //OlcInstance.setOlcRejOn(DateToYYYYMMDD(dtoobject.getValue("OLC_REJ_ON")));
                            
                            //Changes P.Subramani-Chn-17/10/2008 Beg
                            OlcInstance.setOlcMarginCurr(dtoobject.getValue("OLC_MARGIN_CURR"));
                            OlcInstance.setOlcMarginAmt(Double.parseDouble(dtoobject.getValue("OLC_MARGIN_AMT")));
                            OlcInstance.setOlcCashMarAmt(Double.parseDouble(dtoobject.getValue("OLC_CASH_MAR_AMT")));
                            OlcInstance.setOlcMarginBal(Double.parseDouble(dtoobject.getValue("OLC_MARGIN_BAL")));
                            OlcInstance.setOlcCashMarBal(Double.parseDouble(dtoobject.getValue("OLC_CASH_MAR_BAL")));
                            OlcInstance.setOlcCashMarRec(Double.parseDouble(dtoobject.getValue("OLC_CASH_MAR_REC")));
                            OlcInstance.setOlcDepMarRec(Double.parseDouble(dtoobject.getValue("OLC_DEP_MAR_REC")));
                            OlcInstance.setOlcOthSecMarRec(Double.parseDouble(dtoobject.getValue("OLC_OTH_SEC_REC")));
                            //Changes P.Subramani-Chn-17/10/2008 End
                            //S.Suresh Babu Add 30-06-2009
                            OlcInstance.setOlcCommitServTax(Double.parseDouble(dtoobject.getValue("OLC_COMMIT_SERV_TAX")));
                            OlcInstance.setOlcUsanceServTax(Double.parseDouble(dtoobject.getValue("OLC_USANCE_SERV_TAX")));
                            Set_Entd_Dtls(OlcInstance);
                            OlcInstance.setIsNew(true);
                            OlcManagerInstance.save(OlcInstance ,TBAAUTH_MAIN_PK,TBAAUTH_ENTRY_DATE,TBAAUTH_DTL_SL);
              
                    
                }catch(Exception e)
            {
                throw new PanaceaException(e.getLocalizedMessage());
            }
        }
        
        private void addtbillsl(DTObject dtoobject) throws PanaceaException
        {
        	 try
             {
        		 Tbillserial TbillserialInstance;
        		 TbillserialManager  TbillserialManagerInstance = new TbillserialManager(_COLLECTIONObj,V_LOG_REQ, V_ADD_LOG_REQ);
        		 TbillserialInstance = TbillserialManagerInstance.loadByKey(Integer.parseInt(dtoobject.getValue("OLC_BRN_CODE")),dtoobject.getValue("OLC_LC_TYPE"),Integer.parseInt(dtoobject.getValue("OLC_LC_YEAR")));
                 if (TbillserialInstance!= null)
                 {
                	 TbillserialInstance.setTbillslLastNumUsed(olcSl);
                	 
                	 TbillserialInstance.setIsNew(false);
                	 TbillserialManagerInstance.save(TbillserialInstance ,TBAAUTH_MAIN_PK,TBAAUTH_ENTRY_DATE,TBAAUTH_DTL_SL);
                 }
             }
            catch(Exception e)
             {
            	throw new PanaceaException(e.getLocalizedMessage());
             }
        }
        
       // Prabu K Changes-Added on 18-Nov-2011 Beg
        /*
        private void addlcps(DTObject dtoobject) throws PanaceaException
        {
        	 try
             {
        		 Lcps  LcpsInstance;
                 LcpsManager  LcpsManagerInstance = new LcpsManager(_COLLECTIONObj,V_LOG_REQ, V_ADD_LOG_REQ);
                 LcpsInstance = LcpsManagerInstance.loadByKey(Integer.parseInt(dtoobj.getValue("OLC_BRN_CODE")),Integer.parseInt(dtoobj.getValue("OLC_LC_PRESANC_DAY_SL")),DateToYYYYMMDD(dtoobj.getValue("OLC_LC_PRESANC_DATE")));
                 if (LcpsInstance!= null)
                 {                 	 
                	 LcpsInstance.setLcpsLcYr(Integer.parseInt(dtoobject.getValue("OLC_LC_YEAR")));
                	 LcpsInstance.setLcpsLcSl(olcSl);
                	 LcpsInstance.setIsNew(false);
                	 LcpsManagerInstance.save(LcpsInstance ,TBAAUTH_MAIN_PK,TBAAUTH_ENTRY_DATE,TBAAUTH_DTL_SL);
                 }
             }
            catch(Exception e)
             {
            	throw new PanaceaException(e.getLocalizedMessage());
             }
        }
        */
        //Prabu K Changes-Added on 18-Nov-2011 End
        
        private void OlcLedAddRecord(DTObject dtoobject) throws PanaceaException
        {
            try
            {
                Olcled  OlcledInstance=new Olcled();
                OlcledManager  OlcledManagerInstance = new OlcledManager(_COLLECTIONObj,V_LOG_REQ, V_ADD_LOG_REQ);
                OlcledInstance.setOlcldBrnCode(Integer.parseInt(dtoobject.getValue("OLC_BRN_CODE")));
                OlcledInstance.setOlcldLcType(dtoobject.getValue("OLC_LC_TYPE"));
                OlcledInstance.setOlcldLcYear(Integer.parseInt(dtoobject.getValue("OLC_LC_YEAR")));
                OlcledInstance.setOlcldLcSl(olcSl);
                OlcledInstance.setOlcldTxnDate(DateToYYYYMMDD(dtoobject.getValue("OLC_LC_DATE")));
                OlcledInstance.setOlcldTxnType(stringToChar(txntype));
                OlcledInstance.setOlcldTxnSl(Integer.parseInt(txsl));
                OlcledInstance.setOlcldRedEnh(stringToChar(redenh));
                OlcledInstance.setOlcldTxnAmt(Double.parseDouble(dtoobject.getValue("OLC_LC_AMOUNT")));
                OlcledInstance.setOlcldSourceKey(olcledsourcekey);
                OlcledInstance.setIsNew(true);
                OlcledManagerInstance.save(OlcledInstance ,TBAAUTH_MAIN_PK,TBAAUTH_ENTRY_DATE,TBAAUTH_DTL_SL);
  
        
            }
		catch(Exception e)
			{
				throw new PanaceaException(e.getLocalizedMessage());
			}
        }
        private void OlcLedModRecord(DTObject dtoobject) throws PanaceaException
        {
            try
                {
            		Olcled  OlcledInstance;
            		OlcledManager  OlcledManagerInstance = new OlcledManager(_COLLECTIONObj,V_LOG_REQ, V_ADD_LOG_REQ);
            		OlcledInstance = OlcledManagerInstance.loadByKey(Integer.parseInt(dtoobj.getValue("OLC_BRN_CODE")),olcSl,dtoobj.getValue("OLC_LC_TYPE"),Integer.parseInt(dtoobj.getValue("OLC_LC_YEAR")),DateToYYYYMMDD(dtoobj.getValue("OLC_LC_DATE")),Integer.parseInt(txsl),stringToChar(txntype));
                    if (OlcledInstance!= null)
                    {
                    	OlcledInstance.setOlcldBrnCode(Integer.parseInt(dtoobject.getValue("OLC_BRN_CODE")));
                    	OlcledInstance.setOlcldLcType(dtoobject.getValue("OLC_LC_TYPE"));
                    	OlcledInstance.setOlcldLcYear(Integer.parseInt(dtoobject.getValue("OLC_LC_YEAR")));
                    	OlcledInstance.setOlcldLcSl(olcSl);
                    	OlcledInstance.setOlcldTxnDate(DateToYYYYMMDD(dtoobject.getValue("PREV_LC_DATE")));
                        OlcledInstance.setOlcldTxnType(stringToChar(txntype));
                        OlcledInstance.setOlcldTxnSl(Integer.parseInt(txsl));
                        OlcledInstance.setOlcldRedEnh(stringToChar(redenh));
                        OlcledInstance.setOlcldTxnAmt(Double.parseDouble(dtoobject.getValue("OLC_LC_AMOUNT")));
                        OlcledInstance.setOlcldSourceKey(olcledsourcekey);
                    	OlcledInstance.setIsNew(false);
                    	OlcledManagerInstance.save(OlcledInstance,TBAAUTH_MAIN_PK,TBAAUTH_ENTRY_DATE,TBAAUTH_DTL_SL);
                    }
                }     
            catch(Exception e)
            {
                throw new PanaceaException(e.getLocalizedMessage());
            }
        }
        private void AddOlcoText(DTObject dtoobject) throws PanaceaException
        {	
        	try
            {	
        		Olcotext  OlcotextInstance=new Olcotext();
        		OlcotextManager  OlcotextManagerInstance = new OlcotextManager(_COLLECTIONObj,V_LOG_REQ, V_ADD_LOG_REQ);
                OlcotextInstance.setOlcotxBrnCode(Integer.parseInt(dtoobject.getValue("OLC_BRN_CODE")));
    			OlcotextInstance.setOlcotxLcType(dtoobject.getValue("OLC_LC_TYPE"));
    			OlcotextInstance.setOlcotxLcYear(Integer.parseInt(dtoobject.getValue("OLC_LC_YEAR")));
                OlcotextInstance.setOlcotxLcSl(olcSl);
                OlcotextInstance.setOlcotxTxnSl(Integer.parseInt(olcotextsl));
                OlcotextInstance.setOlcotxTxnType(stringToChar(olcotexttype));
                OlcotextInstance.setOlcotxAddtnlAmtCvrd1(dtoobject.getValue("OLC_ADD_AMT_COV1"));
                OlcotextInstance.setOlcotxAddtnlAmtCvrd2(dtoobject.getValue("OLC_ADD_AMT_COV2"));
                OlcotextInstance.setOlcotxAddtnlAmtCvrd3(dtoobject.getValue("OLC_ADD_AMT_COV3"));
                OlcotextInstance.setOlcotxAddtnlAmtCvrd4(dtoobject.getValue("OLC_ADD_AMT_COV4"));
                OlcotextInstance.setIsNew(true);
                OlcotextManagerInstance.save(OlcotextInstance ,TBAAUTH_MAIN_PK,TBAAUTH_ENTRY_DATE,TBAAUTH_DTL_SL);
	     		
            
            }
        catch(Exception e)
         {
        	throw new PanaceaException(e.getLocalizedMessage());
         }
    }    	
                
        
        private void ModOlcoText(DTObject dtoobject) throws PanaceaException
        {
            try
                {
            		Olcotext  OlcotextInstance;
            		OlcotextManager  OlcotextManagerInstance = new OlcotextManager(_COLLECTIONObj,V_LOG_REQ, V_ADD_LOG_REQ);
            		OlcotextInstance = OlcotextManagerInstance.loadByKey(Integer.parseInt(dtoobj.getValue("OLC_BRN_CODE")),olcSl,dtoobj.getValue("OLC_LC_TYPE"),Integer.parseInt(dtoobj.getValue("OLC_LC_YEAR")),Integer.parseInt(olcotextsl),stringToChar(olcotexttype));
                    if (OlcotextInstance!= null)
                    {
                    	OlcotextInstance.setOlcotxBrnCode(Integer.parseInt(dtoobject.getValue("OLC_BRN_CODE")));
            			OlcotextInstance.setOlcotxLcType(dtoobject.getValue("OLC_LC_TYPE"));
            			OlcotextInstance.setOlcotxLcYear(Integer.parseInt(dtoobject.getValue("OLC_LC_YEAR")));
                        OlcotextInstance.setOlcotxLcSl(olcSl);
                        OlcotextInstance.setOlcotxTxnSl(Integer.parseInt(olcotextsl));
                        OlcotextInstance.setOlcotxTxnType(stringToChar(olcotexttype));
                        OlcotextInstance.setOlcotxAddtnlAmtCvrd1(dtoobject.getValue("OLC_ADD_AMT_COV1"));
                        OlcotextInstance.setOlcotxAddtnlAmtCvrd2(dtoobject.getValue("OLC_ADD_AMT_COV2"));
                        OlcotextInstance.setOlcotxAddtnlAmtCvrd3(dtoobject.getValue("OLC_ADD_AMT_COV3"));
                        OlcotextInstance.setOlcotxAddtnlAmtCvrd4(dtoobject.getValue("OLC_ADD_AMT_COV4"));
                    	OlcotextInstance.setIsNew(false);
                    	OlcotextManagerInstance.save(OlcotextInstance ,TBAAUTH_MAIN_PK,TBAAUTH_ENTRY_DATE,TBAAUTH_DTL_SL);
                        }
                    }     
                catch(Exception e)
                {
                    throw new PanaceaException(e.getLocalizedMessage());
                }
           }
        
        private void AddOlcShipText(DTObject dtoobject) throws PanaceaException
        {	
        	try
            {	
        		Olcshiptext  OlcshiptextInstance=new Olcshiptext();
        		OlcshiptextManager  OlcshiptextManagerInstance = new OlcshiptextManager(_COLLECTIONObj,V_LOG_REQ, V_ADD_LOG_REQ);
        		OlcshiptextInstance.setOlcstBrnCode(Integer.parseInt(dtoobject.getValue("OLC_BRN_CODE")));
                OlcshiptextInstance.setOlcstLcType(dtoobject.getValue("OLC_LC_TYPE"));
                OlcshiptextInstance.setOlcstLcYear(Integer.parseInt(dtoobject.getValue("OLC_LC_YEAR")));
    			OlcshiptextInstance.setOlcstLcSl(olcSl);
    			OlcshiptextInstance.setOlcstTxnType(stringToChar(olcotexttype));
    			OlcshiptextInstance.setOlcstTxnSl(Integer.parseInt(txsl));
    			OlcshiptextInstance.setOlcstTextType(shiptexttype);
                OlcshiptextInstance.setOlcstText1(dtoobject.getValue("OLC_SHIP_TEXT1"));
                OlcshiptextInstance.setOlcstText2(dtoobject.getValue("OLC_SHIP_TEXT2"));
                OlcshiptextInstance.setOlcstText3(dtoobject.getValue("OLC_SHIP_TEXT3"));
                OlcshiptextInstance.setOlcstText4(dtoobject.getValue("OLC_SHIP_TEXT4"));
                OlcshiptextInstance.setIsNew(true);
                OlcshiptextManagerInstance.save(OlcshiptextInstance ,TBAAUTH_MAIN_PK,TBAAUTH_ENTRY_DATE,TBAAUTH_DTL_SL);
	     		
                Olcshiptext  OlcshiptextInstance1=new Olcshiptext();
        		OlcshiptextManager  OlcshiptextManagerInstance1 = new OlcshiptextManager(_COLLECTIONObj,V_LOG_REQ, V_ADD_LOG_REQ);
        		OlcshiptextInstance1.setOlcstBrnCode(Integer.parseInt(dtoobject.getValue("OLC_BRN_CODE")));
        		OlcshiptextInstance1.setOlcstLcType(dtoobject.getValue("OLC_LC_TYPE"));
        		OlcshiptextInstance1.setOlcstLcYear(Integer.parseInt(dtoobject.getValue("OLC_LC_YEAR")));
        		OlcshiptextInstance1.setOlcstLcSl(olcSl);
        		OlcshiptextInstance1.setOlcstTxnType(stringToChar(olcotexttype));
        		OlcshiptextInstance1.setOlcstTxnSl(Integer.parseInt(txsl));
        		OlcshiptextInstance1.setOlcstTextType(presenttype);
        		OlcshiptextInstance1.setOlcstText1(dtoobject.getValue("OLC_PRE_DTL1"));
        		OlcshiptextInstance1.setOlcstText2(dtoobject.getValue("OLC_PRE_DTL2"));
                OlcshiptextInstance1.setOlcstText3(dtoobject.getValue("OLC_PRE_DTL3"));
                OlcshiptextInstance1.setOlcstText4(dtoobject.getValue("OLC_PRE_DTL4"));
                OlcshiptextInstance1.setIsNew(true);
                OlcshiptextManagerInstance1.save(OlcshiptextInstance1 ,TBAAUTH_MAIN_PK,TBAAUTH_ENTRY_DATE,TBAAUTH_DTL_SL);

            
            }
        catch(Exception e)
         {
        	throw new PanaceaException(e.getLocalizedMessage());
         }
    }    	
                
        
        private void ModOlcShipText(DTObject dtoobject) throws PanaceaException
        {
            try
                {
            		Olcshiptext  OlcshiptextInstance;
            		OlcshiptextManager  OlcshiptextManagerInstance = new OlcshiptextManager(_COLLECTIONObj,V_LOG_REQ, V_ADD_LOG_REQ);
            		OlcshiptextInstance = OlcshiptextManagerInstance.loadByKey(Integer.parseInt(dtoobj.getValue("OLC_BRN_CODE")),olcSl,dtoobj.getValue("OLC_LC_TYPE"),Integer.parseInt(dtoobj.getValue("OLC_LC_YEAR")),shiptexttype,Integer.parseInt(olcotextsl),stringToChar(olcotexttype));
                    if (OlcshiptextInstance!= null)
                    {
                    	OlcshiptextInstance.setOlcstBrnCode(Integer.parseInt(dtoobject.getValue("OLC_BRN_CODE")));
                        OlcshiptextInstance.setOlcstLcType(dtoobject.getValue("OLC_LC_TYPE"));
                        OlcshiptextInstance.setOlcstLcYear(Integer.parseInt(dtoobject.getValue("OLC_LC_YEAR")));
            			OlcshiptextInstance.setOlcstLcSl(olcSl);
            			OlcshiptextInstance.setOlcstTxnType(stringToChar(olcotexttype));
            			OlcshiptextInstance.setOlcstTxnSl(Integer.parseInt(txsl));
            			OlcshiptextInstance.setOlcstTextType(shiptexttype);
                        OlcshiptextInstance.setOlcstText1(dtoobject.getValue("OLC_SHIP_TEXT1"));
                        OlcshiptextInstance.setOlcstText2(dtoobject.getValue("OLC_SHIP_TEXT2"));
                        OlcshiptextInstance.setOlcstText3(dtoobject.getValue("OLC_SHIP_TEXT3"));
                        OlcshiptextInstance.setOlcstText4(dtoobject.getValue("OLC_SHIP_TEXT4"));
                    	OlcshiptextInstance.setIsNew(false);
                    	OlcshiptextManagerInstance.save(OlcshiptextInstance ,TBAAUTH_MAIN_PK,TBAAUTH_ENTRY_DATE,TBAAUTH_DTL_SL);
                    }
                    Olcshiptext  OlcshiptextInstance1;
                    OlcshiptextInstance1 = OlcshiptextManagerInstance.loadByKey(Integer.parseInt(dtoobj.getValue("OLC_BRN_CODE")),olcSl,dtoobj.getValue("OLC_LC_TYPE"),Integer.parseInt(dtoobj.getValue("OLC_LC_YEAR")),presenttype,Integer.parseInt(olcotextsl),stringToChar(olcotexttype));
                    if (OlcshiptextInstance!= null)
                    {
                    	OlcshiptextInstance1.setOlcstBrnCode(Integer.parseInt(dtoobject.getValue("OLC_BRN_CODE")));
                		OlcshiptextInstance1.setOlcstLcType(dtoobject.getValue("OLC_LC_TYPE"));
                		OlcshiptextInstance1.setOlcstLcYear(Integer.parseInt(dtoobject.getValue("OLC_LC_YEAR")));
                		OlcshiptextInstance1.setOlcstLcSl(olcSl);
                		OlcshiptextInstance1.setOlcstTxnType(stringToChar(olcotexttype));
                		OlcshiptextInstance1.setOlcstTxnSl(Integer.parseInt(txsl));
                		OlcshiptextInstance1.setOlcstTextType(presenttype);
                		OlcshiptextInstance1.setOlcstText1(dtoobject.getValue("OLC_PRE_DTL1"));
                		OlcshiptextInstance1.setOlcstText2(dtoobject.getValue("OLC_PRE_DTL2"));
                        OlcshiptextInstance1.setOlcstText3(dtoobject.getValue("OLC_PRE_DTL3"));
                        OlcshiptextInstance1.setOlcstText4(dtoobject.getValue("OLC_PRE_DTL4"));
                    	OlcshiptextInstance.setIsNew(false);
                    	OlcshiptextManagerInstance.save(OlcshiptextInstance1 ,TBAAUTH_MAIN_PK,TBAAUTH_ENTRY_DATE,TBAAUTH_DTL_SL);
                    }
                }     
                catch(Exception e)
                {
                    throw new PanaceaException(e.getLocalizedMessage());
                }
           }
        
        
        private void AddOlcMar(DTObject dtoobject) throws PanaceaException
        {	
        	try
            {	
        		Olcmar  OlcmarInstance=new Olcmar();
        		OlcmarManager  OlcmarManagerInstance = new OlcmarManager(_COLLECTIONObj,V_LOG_REQ, V_ADD_LOG_REQ);
        		OlcmarInstance.setOlcmBrnCode(Integer.parseInt(dtoobject.getValue("OLC_BRN_CODE")));
                OlcmarInstance.setOlcmLcType(dtoobject.getValue("OLC_LC_TYPE"));
                OlcmarInstance.setOlcmLcYear(Integer.parseInt(dtoobject.getValue("OLC_LC_YEAR")));
                OlcmarInstance.setOlcmLcSl(olcSl);
                OlcmarInstance.setOlcmTxnType(stringToChar(olcotexttype));
                OlcmarInstance.setOlcmTxnSl(Integer.parseInt(txsl));
                OlcmarInstance.setOlcmMarginCurr(dtoobject.getValue("MAGGIN_CURR"));
                OlcmarInstance.setOlcmMarginPerc(Double.parseDouble(dtoobject.getValue("MAGGIN_PER")));
                OlcmarInstance.setOlcmExOverLimitMarginPerc(Double.parseDouble(dtoobject.getValue("EOL_MAGGIN_PER")));
                OlcmarInstance.setOlcmMarginAmt(Double.parseDouble(dtoobject.getValue("MAGGIN_AMT")));
                OlcmarInstance.setOlcmExOverLimitMarginAmt(Double.parseDouble(dtoobject.getValue("EOL_MAGGIN_AMT")));
                OlcmarInstance.setOlcmCashMarginAmt(Double.parseDouble(dtoobject.getValue("CASH_MAGGIN")));
                OlcmarInstance.setOlcmEolCashMarginAmt(Double.parseDouble(dtoobject.getValue("EOL_CASH_MAGGIN")));
                OlcmarInstance.setOlcmMarginType(stringToChar(dtoobject.getValue("MAGGIN_TYPE")));
                OlcmarInstance.setOlcmExOverLimit(Double.parseDouble(dtoobject.getValue("EXCESS_LIMI")));
                OlcmarInstance.setIsNew(true);
                OlcmarManagerInstance.save(OlcmarInstance ,TBAAUTH_MAIN_PK,TBAAUTH_ENTRY_DATE,TBAAUTH_DTL_SL);
	     		
            
            }
        catch(Exception e)
         {
        	throw new PanaceaException(e.getLocalizedMessage());
         }
    }    	
                
        
        private void ModOlcMar(DTObject dtoobject) throws PanaceaException
        {
            try
                {
            		Olcmar  OlcmarInstance;
            		OlcmarManager  OlcmarManagerInstance = new OlcmarManager(_COLLECTIONObj,V_LOG_REQ, V_ADD_LOG_REQ);
            		OlcmarInstance = OlcmarManagerInstance.loadByKey(Integer.parseInt(dtoobj.getValue("OLC_BRN_CODE")),olcSl,dtoobj.getValue("OLC_LC_TYPE"),Integer.parseInt(dtoobj.getValue("OLC_LC_YEAR")),Integer.parseInt(olcotextsl),stringToChar(olcotexttype));
                    if (OlcmarInstance!= null)
                    {
                    	OlcmarInstance.setOlcmBrnCode(Integer.parseInt(dtoobject.getValue("OLC_BRN_CODE")));
                        OlcmarInstance.setOlcmLcType(dtoobject.getValue("OLC_LC_TYPE"));
                        OlcmarInstance.setOlcmLcYear(Integer.parseInt(dtoobject.getValue("OLC_LC_YEAR")));
                        OlcmarInstance.setOlcmLcSl(olcSl);
                        OlcmarInstance.setOlcmTxnType(stringToChar(olcotexttype));
                        OlcmarInstance.setOlcmTxnSl(Integer.parseInt(txsl));
                        OlcmarInstance.setOlcmMarginCurr(dtoobject.getValue("MAGGIN_CURR"));
                        OlcmarInstance.setOlcmMarginPerc(Double.parseDouble(dtoobject.getValue("MAGGIN_PER")));
                        OlcmarInstance.setOlcmExOverLimitMarginPerc(Double.parseDouble(dtoobject.getValue("EOL_MAGGIN_PER")));
                        OlcmarInstance.setOlcmMarginAmt(Double.parseDouble(dtoobject.getValue("MAGGIN_AMT")));
                        OlcmarInstance.setOlcmExOverLimitMarginAmt(Double.parseDouble(dtoobject.getValue("EOL_MAGGIN_AMT")));
                        OlcmarInstance.setOlcmCashMarginAmt(Double.parseDouble(dtoobject.getValue("CASH_MAGGIN")));
                        OlcmarInstance.setOlcmEolCashMarginAmt(Double.parseDouble(dtoobject.getValue("EOL_CASH_MAGGIN")));
                        OlcmarInstance.setOlcmMarginType(stringToChar(dtoobject.getValue("MAGGIN_TYPE")));
                        OlcmarInstance.setOlcmExOverLimit(Double.parseDouble(dtoobject.getValue("EXCESS_LIMI")));
                        OlcmarInstance.setIsNew(false);
                        OlcmarManagerInstance.save(OlcmarInstance ,TBAAUTH_MAIN_PK,TBAAUTH_ENTRY_DATE,TBAAUTH_DTL_SL);
                        }
                    }     
                catch(Exception e)
                {
                    throw new PanaceaException(e.getLocalizedMessage());
                }
           }
        
        
        
        private void modRecord(DTObject dtoobject) throws PanaceaException
        {
            try
                {
                    Olc  OlcInstance;
                    OlcManager  OlcManagerInstance = new OlcManager(_COLLECTIONObj,V_LOG_REQ, V_ADD_LOG_REQ);
                    OlcInstance = OlcManagerInstance.loadByKey(Integer.parseInt(dtoobj.getValue("OLC_BRN_CODE")),olcSl,dtoobj.getValue("OLC_LC_TYPE"),Integer.parseInt(dtoobj.getValue("OLC_LC_YEAR")));
                    if (OlcInstance!= null)
                    {
                    OlcInstance.setOlcBrnCode(Integer.parseInt(dtoobject.getValue("OLC_BRN_CODE")));
                    OlcInstance.setOlcLcType(dtoobject.getValue("OLC_LC_TYPE"));
                    OlcInstance.setOlcLcYear(Integer.parseInt(dtoobject.getValue("OLC_LC_YEAR")));
                    OlcInstance.setOlcLcSl(olcSl);
                    OlcInstance.setOlcCorrRefNum(dtoobject.getValue("OLC_CORR_REF_NUM"));
                    OlcInstance.setOlcLcPresancDate(DateToYYYYMMDD(dtoobject.getValue("OLC_LC_PRESANC_DATE")));
                    OlcInstance.setOlcLcPresancDaySl(Integer.parseInt(dtoobject.getValue("OLC_LC_PRESANC_DAY_SL")));
                    OlcInstance.setOlcLcDate(DateToYYYYMMDD(dtoobject.getValue("OLC_LC_DATE")));
                    OlcInstance.setOlcCustNum(Long.parseLong(dtoobject.getValue("OLC_CUST_NUM")));
                    OlcInstance.setOlcBenefCode(dtoobject.getValue("OLC_BENEF_CODE"));
                    OlcInstance.setOlcBenefName(dtoobject.getValue("OLC_BENEF_NAME"));
                    OlcInstance.setOlcBenefAddr1(dtoobject.getValue("OLC_BENEF_ADDR1"));
                    OlcInstance.setOlcBenefAddr2(dtoobject.getValue("OLC_BENEF_ADDR2"));
                    OlcInstance.setOlcBenefAddr3(dtoobject.getValue("OLC_BENEF_ADDR3"));
                    OlcInstance.setOlcBenefAddr4(dtoobject.getValue("OLC_BENEF_ADDR4"));
                    OlcInstance.setOlcBenefAddr5(dtoobject.getValue("OLC_BENEF_ADDR5"));
                    OlcInstance.setOlcBenefCntryCode(dtoobject.getValue("OLC_BENEF_CNTRY_CODE"));
                    OlcInstance.setOlcLcIssBkCode(dtoobject.getValue("OLC_LC_ISS_BK_CODE"));
                    OlcInstance.setOlcLcIssBrnCode(dtoobject.getValue("OLC_LC_ISS_BRN_CODE"));
                    OlcInstance.setOlcLcIssBrnName(dtoobject.getValue("OLC_LC_ISS_BRN_NAME"));
                    OlcInstance.setOlcLcIssBrnAdd1(dtoobject.getValue("OLC_LC_ISS_BRN_ADD1"));
                    OlcInstance.setOlcLcIssBrnAdd2(dtoobject.getValue("OLC_LC_ISS_BRN_ADD2"));
                    OlcInstance.setOlcLcIssBrnAdd3(dtoobject.getValue("OLC_LC_ISS_BRN_ADD3"));
                    OlcInstance.setOlcLcIssBrnAdd4(dtoobject.getValue("OLC_LC_ISS_BRN_ADD4"));
                    OlcInstance.setOlcLcIssBrnAdd5(dtoobject.getValue("OLC_LC_ISS_BRN_ADD5"));
                    OlcInstance.setOlcLcIssPlace(dtoobject.getValue("OLC_LC_ISS_PLACE"));
                    OlcInstance.setOlcLcIssCntry(dtoobject.getValue("OLC_LC_ISS_CNTRY"));
                    OlcInstance.setOlcLcAdvThru(stringToChar(dtoobject.getValue("OLC_LC_ADV_THRU")));
                    OlcInstance.setOlcLcCurrCode(dtoobject.getValue("OLC_LC_CURR_CODE"));
                    OlcInstance.setOlcLcAmount(Double.parseDouble(dtoobject.getValue("OLC_LC_AMOUNT")));
                    OlcInstance.setOlcLcBalance(Double.parseDouble(dtoobject.getValue("OLC_LC_BALANCE")));
                    OlcInstance.setOlcDevAllwd(stringToChar(dtoobject.getValue("OLC_DEV_ALLWD")));
                    OlcInstance.setOlcPosDevAllwd(Double.parseDouble(dtoobject.getValue("OLC_POS_DEV_ALLWD")));
                    OlcInstance.setOlcNegDevAllwd(Double.parseDouble(dtoobject.getValue("OLC_NEG_DEV_ALLWD")));
                    OlcInstance.setOlcDevAmount(Double.parseDouble(dtoobject.getValue("OLC_DEV_AMOUNT")));
                    OlcInstance.setOlcDevBal(Double.parseDouble(dtoobject.getValue("OLC_DEV_BAL")));
                    OlcInstance.setOlcAmtQualfr(stringToChar(dtoobject.getValue("OLC_AMT_QUALFR")));
                    OlcInstance.setOlcPriceTerms(dtoobject.getValue("OLC_PRICE_TERMS"));
                    OlcInstance.setOlcLastDateOfNeg(DateToYYYYMMDD(dtoobject.getValue("OLC_LAST_DATE_OF_NEG")));
                    OlcInstance.setOlcPlaceOfExpiry(dtoobject.getValue("OLC_PLACE_OF_EXPIRY"));
                    OlcInstance.setOlcLatestDateOfShpmnt(DateToYYYYMMDD(dtoobject.getValue("OLC_LATEST_DATE_OF_SHPMNT")));
                    OlcInstance.setOlcWithinValidateLc(stringToChar(dtoobject.getValue("OLC_WITHIN_VALIDATE_LC")));
                    OlcInstance.setOlcLcUiBorneByApplcnt(stringToChar(dtoobject.getValue("OLC_LC_UI_BORNE_BY_APPLCNT")));
                    OlcInstance.setOlcNofTenors(Integer.parseInt(dtoobject.getValue("OLC_NOF_TENORS")));
                    OlcInstance.setOlcLcUnderContract(stringToChar(dtoobject.getValue("OLC_LC_UNDER_CONTRACT")));
                    OlcInstance.setOlcTotLiabLcCurr(Double.parseDouble(dtoobject.getValue("OLC_TOT_LIAB_LC_CURR")));
                    OlcInstance.setOlcConvRateBaseCurr(avg);
                    OlcInstance.setOlcTotLiabBaseCurr(Double.parseDouble(dtoobject.getValue("OLC_TOT_LIAB_BASE_CURR")));
                    OlcInstance.setOlcConvRateLimCurr(Double.parseDouble(dtoobject.getValue("OLC_CONV_RATE_LIM_CURR")));
                    OlcInstance.setOlcTotLiabLimCurr(Double.parseDouble(dtoobject.getValue("OLC_TOT_LIAB_LIM_CURR")));
                    OlcInstance.setOlcPaymntCurr(dtoobject.getValue("OLC_PAYMNT_CURR"));
                    OlcInstance.setOlcTotChrgsInPaymntCurr(Double.parseDouble(dtoobject.getValue("OLC_TOT_CHRGS_IN_PAYMNT_CURR")));
                    OlcInstance.setOlcCashMarginBal(Double.parseDouble(dtoobject.getValue("OLC_CASH_MARGIN_BAL")));
                    OlcInstance.setOlcReimbChrgsBy(stringToChar(dtoobject.getValue("OLC_REIMB_CHRGS_BY")));
                    OlcInstance.setOlcPercRcPaidByApplcnt(Double.parseDouble(dtoobject.getValue("OLC_PERC_RC_PAID_BY_APPLCNT")));
                    OlcInstance.setOlcNostroAlphaCode(dtoobject.getValue("OLC_NOSTRO_ALPHA_CODE"));
                    OlcInstance.setOlcAdvThruBk(dtoobject.getValue("OLC_ADV_THRU_BK"));
                    OlcInstance.setOlcAdvThruBrn(dtoobject.getValue("OLC_ADV_THRU_BRN"));
                    OlcInstance.setOlcLcToBeCnfrmd(stringToChar(dtoobject.getValue("OLC_LC_TO_BE_CNFRMD")));
                    //Changes Sanjay1 22-07-2019 Begin
                    //OlcInstance.setOlcLcToBeCnfrmdByBk(dtoobject.getValue("OLC_LC_TO_BE_CNFRMD_BY_BK"));
                    //OlcInstance.setOlcLcToBeCnfrmdByBrn(dtoobject.getValue("OLC_LC_TO_BE_CNFRMD_BY_BRN"));
                    //Changes Sanjay1 22-07-2019 Begin
                    OlcInstance.setOlcRestricted(stringToChar(dtoobject.getValue("OLC_RESTRICTED")));
                    OlcInstance.setOlcRestrictedToUs(stringToChar(dtoobject.getValue("OLC_RESTRICTED_TO_US")));
                    OlcInstance.setOlcRestrictedBkCode(dtoobject.getValue("OLC_RESTRICTED_BK_CODE"));
                    OlcInstance.setOlcRestrictedBrnCode(dtoobject.getValue("OLC_RESTRICTED_BRN_CODE"));
                    OlcInstance.setOlcCrAvlblBy(stringToChar(dtoobject.getValue("OLC_CR_AVLBL_BY")));
                    OlcInstance.setOlcIrrevocable(stringToChar(dtoobject.getValue("OLC_IRREVOCABLE")));
                    OlcInstance.setOlcPartShpmnt(stringToChar(dtoobject.getValue("OLC_PART_SHPMNT")));
                    OlcInstance.setOlcTranShpmnt(stringToChar(dtoobject.getValue("OLC_TRAN_SHPMNT")));
                    OlcInstance.setOlcLcTransfrbl(stringToChar(dtoobject.getValue("OLC_LC_TRANSFRBL")));
                    OlcInstance.setOlcDftReqd(stringToChar(dtoobject.getValue("OLC_DFT_REQD")));
                    OlcInstance.setOlcPercDftValue(Double.parseDouble(dtoobject.getValue("OLC_PERC_DFT_VALUE")));
                    OlcInstance.setOlcDftToBeDrawnOn(stringToChar(dtoobject.getValue("OLC_DFT_TO_BE_DRAWN_ON")));
                    OlcInstance.setOlcDftOnBk(dtoobject.getValue("OLC_DFT_ON_BK"));
                    OlcInstance.setOlcDftOnBrn(dtoobject.getValue("OLC_DFT_ON_BRN"));
                    OlcInstance.setOlcSpecText1(dtoobject.getValue("OLC_SPEC_TEXT1"));
                    OlcInstance.setOlcSpecText2(dtoobject.getValue("OLC_SPEC_TEXT2"));
                    OlcInstance.setOlcSpecText3(dtoobject.getValue("OLC_SPEC_TEXT3"));
                    OlcInstance.setOlcSpecText4(dtoobject.getValue("OLC_SPEC_TEXT4"));
                    OlcInstance.setOlcPrimeRateClauseReq(stringToChar(dtoobject.getValue("OLC_PRIME_RATE_CLAUSE_REQ")));
                    OlcInstance.setOlcShpmntMode(stringToChar(dtoobject.getValue("OLC_SHPMNT_MODE")));
                    OlcInstance.setOlcLloydsClauseReq(stringToChar(dtoobject.getValue("OLC_LLOYDS_CLAUSE_REQ")));
                    OlcInstance.setOlcMaxShipAge(Integer.parseInt(dtoobject.getValue("OLC_MAX_SHIP_AGE")));
                    OlcInstance.setOlcShortFormOfBl(stringToChar(dtoobject.getValue("OLC_SHORT_FORM_OF_BL")));
                    OlcInstance.setOlcLashTransDocsAllwd(stringToChar(dtoobject.getValue("OLC_LASH_TRANS_DOCS_ALLWD")));
                    OlcInstance.setOlcPercOfInsValueCvrd(Double.parseDouble(dtoobject.getValue("OLC_PERC_OF_INS_VALUE_CVRD")));
                    OlcInstance.setOlcInsPolicyNum(dtoobject.getValue("OLC_INS_POLICY_NUM"));
                    OlcInstance.setOlcInsDate(DateToYYYYMMDD(dtoobject.getValue("OLC_INS_DATE")));
                    OlcInstance.setOlcInsCurr(dtoobject.getValue("OLC_INS_CURR"));
                    OlcInstance.setOlcInsAmt(Double.parseDouble(dtoobject.getValue("OLC_INS_AMT")));
                    OlcInstance.setOlcPremiumCurr(dtoobject.getValue("OLC_PREMIUM_CURR"));
                    OlcInstance.setOlcPremiumAmt(Double.parseDouble(dtoobject.getValue("OLC_PREMIUM_AMT")));
                    OlcInstance.setOlcInsCompany(dtoobject.getValue("OLC_INS_COMPANY"));
                    OlcInstance.setOlcInsCompanyName(dtoobject.getValue("OLC_INS_COMPANY_NAME"));
                    OlcInstance.setOlcCooIssBy(dtoobject.getValue("OLC_COO_ISS_BY"));
                    OlcInstance.setOlcOtherCompAuth(dtoobject.getValue("OLC_OTHER_COMP_AUTH"));
                    OlcInstance.setOlcIntermediaryTrade(stringToChar(dtoobject.getValue("OLC_INTERMEDIARY_TRADE")));
                    OlcInstance.setOlcInspTestCertReq(stringToChar(dtoobject.getValue("OLC_INSP_TEST_CERT_REQ")));
                    OlcInstance.setOlcCertBy(dtoobject.getValue("OLC_CERT_BY"));
                    OlcInstance.setOlcImpUnder(stringToChar(dtoobject.getValue("OLC_IMP_UNDER")));
                    OlcInstance.setOlcImpPolicyDet(dtoobject.getValue("OLC_IMP_POLICY_DET"));
                    OlcInstance.setOlcImpRef(dtoobject.getValue("OLC_IMP_REF"));
                    OlcInstance.setOlcCancelledOn(DateToYYYYMMDD(dtoobject.getValue("OLC_CANCELLED_ON")));
                    OlcInstance.setOlcCustLiabAcc(Long.parseLong(intaccNo));
                    //Changes P.Subramani-Chn-11/04/2008 Beg
                    OlcInstance.setOlcUsanceCharges(Double.parseDouble(dtoobject.getValue("USANCE_CHARGES")));
                    OlcInstance.setOlcUsnChgTakenDays(Integer.parseInt(dtoobject.getValue("OLC_USN_CHG_TAKEN_DAYS")));
                    OlcInstance.setOlcCommitmentCharges(Double.parseDouble(dtoobject.getValue("COMMITMENT_CHARGES")));
                    OlcInstance.setOlcCommitChgTakenDays(Integer.parseInt(dtoobject.getValue("OLC_COMMIT_CHG_TAKEN_DAYS")));
                    //Changes P.Subramani-Chn-11/04/2008  End
                    OlcInstance.setTranchgsChgsSl(Long.parseLong(dtoobject.getValue("TRANCHGS_CHGS_SL1")));
                    OlcInstance.setTrancratesRateSl(Long.parseLong(dtoobject.getValue("TRANCRATES_RATE_SL1")));
                    OlcInstance.setTranstlmntInvNum(Long.parseLong(dtoobject.getValue("TRANSTLMNT_INV_NUM1")));
                    OlcInstance.setPostTranBrn(Integer.parseInt(dtoobject.getValue("POST_TRAN_BRN")));
                    OlcInstance.setPostTranDate(DateToYYYYMMDD(dtoobject.getValue("POST_TRAN_DATE")));
                    OlcInstance.setPostTranBatchNum(Integer.parseInt(dtoobject.getValue("POST_TRAN_BATCH_NUM")));
                    //OlcInstance.setOlcLastmodBy(dtoobject.getValue("OLC_LASTMOD_BY"));
                    //OlcInstance.setOlcLastmodOn(DateToYYYYMMDD(dtoobject.getValue("OLC_LASTMOD_ON")));
                    //OlcInstance.setOlcRejBy(dtoobject.getValue("OLC_REJ_BY"));
                    //OlcInstance.setOlcRejOn(DateToYYYYMMDD(dtoobject.getValue("OLC_REJ_ON")));
                    
                    //Changes P.Subramani-Chn-17/10/2008 Beg
                    OlcInstance.setOlcMarginCurr(dtoobject.getValue("OLC_MARGIN_CURR"));
                    OlcInstance.setOlcMarginAmt(Double.parseDouble(dtoobject.getValue("OLC_MARGIN_AMT")));
                    OlcInstance.setOlcCashMarAmt(Double.parseDouble(dtoobject.getValue("OLC_CASH_MAR_AMT")));
                    OlcInstance.setOlcMarginBal(Double.parseDouble(dtoobject.getValue("OLC_MARGIN_BAL")));
                    OlcInstance.setOlcCashMarBal(Double.parseDouble(dtoobject.getValue("OLC_CASH_MAR_BAL")));
                    OlcInstance.setOlcCashMarRec(Double.parseDouble(dtoobject.getValue("OLC_CASH_MAR_REC")));
                    OlcInstance.setOlcDepMarRec(Double.parseDouble(dtoobject.getValue("OLC_DEP_MAR_REC")));
                    OlcInstance.setOlcOthSecMarRec(Double.parseDouble(dtoobject.getValue("OLC_OTH_SEC_REC")));
                    //Changes P.Subramani-Chn-17/10/2008 End
                    //S.Suresh Babu Add 30-06-2009
                    OlcInstance.setOlcCommitServTax(Double.parseDouble(dtoobject.getValue("OLC_COMMIT_SERV_TAX")));
                    OlcInstance.setOlcUsanceServTax(Double.parseDouble(dtoobject.getValue("OLC_USANCE_SERV_TAX")));
                    
                    Set_Entd_Dtls(OlcInstance);
                    OlcInstance.setIsNew(false);
                    OlcManagerInstance.save(OlcInstance ,TBAAUTH_MAIN_PK,TBAAUTH_ENTRY_DATE,TBAAUTH_DTL_SL);
                    }
                }     
            catch(Exception e)
            {
                throw new PanaceaException(e.getLocalizedMessage());
            }
        }
        
        
        private void addolctenor(DTObject dtoobject) throws PanaceaException
        {        	
        	try
        	{
        		
        		Olctenors OlctenorsInstance = new Olctenors();
        		OlctenorsManager OlctenorsManagerInstance = new OlctenorsManager(_COLLECTIONObj,V_LOG_REQ,V_ADD_LOG_REQ);
        		Integer xmltempRowCount = new Integer(dtoobject.getDTDObject("OLCTENORS").getRowCount());
//        		if(tba_auth_queue_req == false)
//        		{ 
//        			deleteolctenor(dtoobject);
//        		}
        		// MODIFIED BY PRASHANTH 
        		deleteolctenor(dtoobject);
        		for(int i=0; i< xmltempRowCount.intValue(); i++)
				{
        			String space=" ";
        			OlctenorsInstance.setOlctBrnCode(Integer.parseInt(dtoobject.getValue("OLC_BRN_CODE")));
        			OlctenorsInstance.setOlctLcType(dtoobject.getValue("OLC_LC_TYPE"));
        			OlctenorsInstance.setOlctLcYear(Integer.parseInt(dtoobject.getValue("OLC_LC_YEAR")));
        			OlctenorsInstance.setOlctLcSl(olcSl);
        			OlctenorsInstance.setOlctTenorSl(i+1);
        			
        			if(dtoobject.getDTDObject("OLCTENORS",i,0).equalsIgnoreCase(""))
        			{
        				OlctenorsInstance.setOlctTenorType(stringToChar(space));
        			}
        			else
        			{
        			OlctenorsInstance.setOlctTenorType(stringToChar(dtoobject.getDTDObject("OLCTENORS",i,0)));
        			}
        			if(dtoobject.getDTDObject("OLCTENORS",i,1).equalsIgnoreCase(""))
        			{
        				OlctenorsInstance.setOlctTenorAmt(0);
        			}else
        			{	
        			OlctenorsInstance.setOlctTenorAmt(Double.parseDouble(dtoobject.getDTDObject("OLCTENORS",i,1)));
        			}
        			if(dtoobject.getDTDObject("OLCTENORS",i,2).equalsIgnoreCase(""))
        			{
        				OlctenorsInstance.setOlctUsancePerd(0);
        			}
        			else
        			{
        			OlctenorsInstance.setOlctUsancePerd(Integer.parseInt(dtoobject.getDTDObject("OLCTENORS",i,2)));
        			}
        			if(dtoobject.getDTDObject("OLCTENORS",i,3).equalsIgnoreCase(""))
        			{
        				OlctenorsInstance.setOlctUsanceFrom(stringToChar(space));
        			}
        			else
        			{
        			OlctenorsInstance.setOlctUsanceFrom(stringToChar(dtoobject.getDTDObject("OLCTENORS",i,3)));
        			}
        			if(dtoobject.getDTDObject("OLCTENORS",i,4).equalsIgnoreCase(""))
        			{
        				OlctenorsInstance.setOlctOtherDateDesc(space);
        			}
        			else
        			{
        			OlctenorsInstance.setOlctOtherDateDesc(dtoobject.getDTDObject("OLCTENORS",i,4));
        			}
        			if(dtoobject.getDTDObject("OLCTENORS",i,5).equalsIgnoreCase(""))
        			{
        				OlctenorsInstance.setOlctOtherDateStartFrom(null);
        			}
        			else
        			{
        			OlctenorsInstance.setOlctOtherDateStartFrom(DateToYYYYMMDD(dtoobject.getDTDObject("OLCTENORS",i,5)));
        			}
        			OlctenorsInstance.setOlctUsanceIntRate(Double.parseDouble(dtoobject.getDTDObject("OLCTENORS",i,6)));
        			OlctenorsInstance.setOlctUsanceIntAmt(Double.parseDouble(dtoobject.getDTDObject("OLCTENORS",i,7)));
        			OlctenorsInstance.setOlctDocDelivery(stringToChar(dtoobject.getDTDObject("OLCTENORS",i,8)));
        			OlctenorsInstance.setOlctBalTenorAmt(Double.parseDouble(dtoobject.getDTDObject("OLCTENORS",i,1)));
        			OlctenorsInstance.setOlctBalUsanceIntAmt(Double.parseDouble(dtoobject.getDTDObject("OLCTENORS",i,7)));
        			OlctenorsInstance.setOlctBalDiffAmtUtil(0);
        			double tamt=Double.parseDouble(dtoobject.getDTDObject("OLCTENORS",i,1));
        			double intamt=Double.parseDouble(dtoobject.getDTDObject("OLCTENORS",i,7));
        			double lcamt=Double.parseDouble(dtoobject.getValue("OLC_LC_AMOUNT"));
        			double devamt=Double.parseDouble(dtoobject.getValue("OLC_DEV_AMOUNT"));
        			double res=tamt+((devamt/lcamt)*tamt)+intamt;
        			OlctenorsInstance.setOlctTotTenorLiab(res);
        			//Changes P.Subramani-Chn-23/08/2008 Beg
        			if(dtoobject.getDTDObject("OLCTENORS",i,9).equalsIgnoreCase(""))
        			{
        				OlctenorsInstance.setOlctUsnChrgTakenDays(0);
        			}
        			else
        			{
        				OlctenorsInstance.setOlctUsnChrgTakenDays(Integer.parseInt(dtoobject.getDTDObject("OLCTENORS",i,9)));
        			}
        			//Changes P.Subramani-Chn-23/08/2008 End        			
        			OlctenorsInstance.setIsNew(true);
        			OlctenorsManagerInstance.save(OlctenorsInstance,TBAAUTH_MAIN_PK,TBAAUTH_ENTRY_DATE,TBAAUTH_DTL_SL);
				}
        	}
        	catch(Exception e)
        	{
        		throw new PanaceaException(e.getLocalizedMessage());
        	}
        }
        	
        private void deleteolctenor(DTObject dtoobject) throws PanaceaException
        {
        	try{               	
        		String w_Sql;
        		OlctenorsManager OlctenorsManagerInstance = new OlctenorsManager(_COLLECTIONObj,V_LOG_REQ,V_ADD_LOG_REQ);
        		w_Sql = "DELETE FROM  OLCTENORS  WHERE  OLCT_BRN_CODE='" + Integer.parseInt(dtoobject.getValue("OLC_BRN_CODE"))+"' AND OLCT_LC_TYPE ='" +dtoobject.getValue("OLC_LC_TYPE")+"' AND OLCT_LC_YEAR='" + Integer.parseInt(dtoobject.getValue("OLC_LC_YEAR"))+"' AND OLCT_LC_SL='"+ olcSl+"'";
        		OlctenorsManagerInstance.deleteByQuery(w_Sql);
        		
        	}
        	catch(Exception e)
        	{
        		throw new PanaceaException(e.getLocalizedMessage());
        	}
        } 

        
        private void posting_Transaction(DTObject InputmapObj)throws PanaceaException, SQLException {
     		System.out.println(" Posting Started...");
     		Begin_Posting();
     	    Set_Tran_Key_Values(InputmapObj);
     	    Set_Tranbat_Values();
     	    Set_Tran_Values(InputmapObj);
     	    //Changes P.Subramani-Chn-19-06-2008 Beg
	    //S.Suresh Babu Changes 30-06-2009	
     	    //Set_Tran_Values1(InputmapObj);
     	    //Set_Tran_Values2(InputmapObj);
     	    //Changes P.Subramani-Chn-19-06-2008 End 
     	    Set_Tran_DebitContra_Values(InputmapObj);
     	    Set_Tran_CreditContra_Values(InputmapObj);
     	    //Changes P.Subramani-Chn-19-06-2008 Beg
     	    if(usancechgs>0.0)
     	    {
     		  Set_Tran_CreditContra_Values1(InputmapObj);
     	    }
     	    if(commchgs>0.0)
    	    {
     		 Set_Tran_CreditContra_Values2(InputmapObj);
    	    }
     	    //Changes P.Subramani-Chn-19-06-2008 End
     	    if(Double.parseDouble(totchargeamt)>0)
      	    {
     		Set_Tran_Debit_Values(InputmapObj);
     	    chargeStax(InputmapObj);
     	    }
     	    Post_Transaction();
     	    System.out.println(" SuccessFully Completed Posting ");
     	}
  
  public void Set_Tran_Key_Values(DTObject InputmapObj)throws PanaceaException
  {	
		 	if(Option.equalsIgnoreCase("A"))
		 	{
			
		 	// changes in EOLC on 12-Jun-2018 start
		 		
		 		if (Integer.parseInt(_brnAuth) > 0) {
					trankey.set_TRAN_BRN_CODE(Integer.parseInt(userBrnCode));
				} else {
					trankey.set_TRAN_BRN_CODE(Integer.parseInt(branchCode));
				}
		 		
		 	// changes in EOLC on 12-Jun-2018 end
		 		
			trankey.set_TRAN_DATE_OF_TRAN(CurrDate);
			trankey.set_TRAN_BATCH_NUMBER(0);
			trankey.set_TRAN_BATCH_SL_NUM(0);
			trankey.set_User_Option("A");
			System.out.println("SuccessFully: Set_Tran_Key_Values for Add Mode");
		}
		else
		{
			// changes in EOLC on 12-Jun-2018 start
			
			if (Integer.parseInt(_brnAuth) > 0) {
				trankey.set_TRAN_BRN_CODE(Integer.parseInt(userBrnCode));
			} else {
				trankey.set_TRAN_BRN_CODE(Integer.parseInt(tranbranch));
			}
			// changes in EOLC on 12-Jun-2018 end
			
			trankey.set_TRAN_DATE_OF_TRAN(trandate);
			trankey.set_TRAN_BATCH_NUMBER(Integer.parseInt(batno));
			trankey.set_TRAN_BATCH_SL_NUM(0);
			trankey.set_User_Option("M");
			System.out.println("SuccessFully: Set_Tran_Key_Values2 for Modification Mode");
		}
 	}
	
  public void Set_Tranbat_Values()
  {
  	  	tranbatrec.setTranbatSourceTable("OLC");
        tranbatrec.setTranbatSourceKey(_sourceKey); 
      //Changes-M.S.Jayanthi-Chn-11/11/2009-beg
        if(inover.equalsIgnoreCase("I"))
        	 tranbatrec.setTranbatNarrDtl1("Inland LC");
        else
        tranbatrec.setTranbatNarrDtl1("Import LC Issue");
      //Changes-M.S.Jayanthi-Chn-11/11/2009-end
        tranbatrec.setTranbatNarrDtl2(refno);
        tranbatrec.set_auto_authorise(false); 
        System.out.println("SuccessFully: Set_Tranbat_Values");
  }
  
  public void Set_Tran_Values(DTObject InputmapObj) throws PanaceaException
  {
  	Connection _conn=null;
  	ResultSet rs = null;
  	ResultSet rs1=null;
  	String qstr="select TRAC_COLL_CONTRA_GLACC_CODE from TRACPARAM where TRAC_NOMEN_CODE=?";
  	try{
  		
  		_conn=openConnection();
  		 PreparedStatement _pstmt = _conn.prepareStatement(qstr);
  		_pstmt.setString(1,olcType);
  		 rs =_pstmt.executeQuery();
 			 
 			 if(rs.next())
 			 {
 				contraGL=rs.getString(1);
 				rs.close();
 			 }
 			 else
 			 {
 				 rs.close();
 			 }			 
  	}catch (Exception e) {
  		throw new PanaceaException(e.getLocalizedMessage());
 		}
  	finally{
  		
  		try {
 			_conn.close();
 		} catch (Exception e) {
 			 throw new PanaceaException(e.getLocalizedMessage());
 		}
  	 }
   }
//Changes P.Subramani-Chn-19-06-2008 Beg
  public void Set_Tran_Values1(DTObject InputmapObj) throws PanaceaException
  {
  	Connection _conn=null;
  	ResultSet rs = null;
  	ResultSet rs1=null;
  	String qstr="select CHGCD_CR_INCOME_HEAD from chgcd where CHGCD_CHARGE_CODE=?";
  	try{
  		
  		_conn=openConnection();
  		 PreparedStatement _pstmt = _conn.prepareStatement(qstr);
  		_pstmt.setString(1,usancechgcode);
  		 rs =_pstmt.executeQuery();
 			 
 			 if(rs.next())
 			 {
 				contraGL1=rs.getString(1);
 				rs.close();
 			 }
 			 else
 			 {
 				 rs.close();
 			 }			 
  	}catch (Exception e) {
  		throw new PanaceaException(e.getLocalizedMessage());
 		}
  	finally{
  		
  		try {
 			_conn.close();
 		} catch (Exception e) {
 			 throw new PanaceaException(e.getLocalizedMessage());
 		}
  	 }
   }
  
  public void Set_Tran_Values2(DTObject InputmapObj) throws PanaceaException
  {
  	Connection _conn=null;
  	ResultSet rs = null;
  	ResultSet rs1=null;
  	String qstr="select CHGCD_CR_INCOME_HEAD from chgcd where CHGCD_CHARGE_CODE=?";
  	try{
  		
  		_conn=openConnection();
  		 PreparedStatement _pstmt = _conn.prepareStatement(qstr);
  		_pstmt.setString(1,commchgcode);
  		 rs =_pstmt.executeQuery();
 			 
 			 if(rs.next())
 			 {
 				contraGL2=rs.getString(1);
 				rs.close();
 			 }
 			 else
 			 {
 				 rs.close();
 			 }			 
  	}catch (Exception e) {
  		throw new PanaceaException(e.getLocalizedMessage());
 		}
  	finally{
  		
  		try {
 			_conn.close();
 		} catch (Exception e) {
 			 throw new PanaceaException(e.getLocalizedMessage());
 		}
  	 }
   }
//Changes P.Subramani-Chn-19-06-2008 End
  
   public void  Set_Tran_DebitContra_Values(DTObject InputmapObj)throws PanaceaException
   {
 	  
 	  tranRec.setTranAcingBrnCode(Integer.parseInt(branchCode));	
 	  tranRec.setTranInternalAcnum(Long.parseLong(intaccNo));
 	  //Changes-M.S.Jayanthi-Chn-11/11/2009-beg
 	  if(inover.equalsIgnoreCase("I"))
 		tranRec.setTranNarrDtl1("Inland LC");
 	  else
 	  tranRec.setTranNarrDtl1("Import LC Issue");
 	//Changes-M.S.Jayanthi-Chn-11/11/2009-end
 	  tranRec.setTranNarrDtl2(refno);
 	  tranRec.setTranContractNum(0);
 	  tranRec.setTranDbCrFlg("D");
 	  tranRec.setTranAmount(equamt);
 	  tranRec.setTranBaseCurrEqAmt(equamt);
 	  Move_Tran_Values(tranRec);     
   }	  
  
   public void  Set_Tran_CreditContra_Values(DTObject InputmapObj)throws PanaceaException
   {	  
	      tranRec.setTranAcingBrnCode(Integer.parseInt(branchCode));	
	 	  tranRec.setTranInternalAcnum(0);
	 	//Changes-M.S.Jayanthi-Chn-11/11/2009-beg
	 	 if(inover.equalsIgnoreCase("I"))
	 		tranRec.setTranNarrDtl1("Inland LC");
	  	  else
	 	  tranRec.setTranNarrDtl1("Import LC Issue");
	 	//Changes-M.S.Jayanthi-Chn-11/11/2009-end
	 	  tranRec.setTranNarrDtl2(refno);
	 	  tranRec.setTranContractNum(0);
	 	  tranRec.setTranGlaccCode(contraGL);
	 	  tranRec.setTranCurrCode(basecurr);
	 	  tranRec.setTranDbCrFlg("C");
	 	  tranRec.setTranAmount(equamt);
	 	  tranRec.setTranBaseCurrEqAmt(equamt);
	 	  Move_Tran_Values(tranRec);     
	}
   
   //Changes P.Subramani-19-06-2008 Beg
   public void  Set_Tran_CreditContra_Values1(DTObject InputmapObj)throws PanaceaException
   {	  
		//S.Suresh Babu Changes 30-06-2009

	   	chargeStax chargestax = new chargeStax();
	  	chargestax.set_chargeStaxBrnCode(Integer.parseInt(branchCode));
	  	chargestax.set_chargeStaxChrgCode(dtoobj.getValue("TRCHG_USANCE_CHGCD"));
		chargestax.set_chargeStaxChrgCurr(basecurr);
		chargestax.set_chargeStaxTotChrgAmt(usancechgs);		
		chargestax.set_chargeStaxTotSvrChrgAmt(olc_usance_serv_tax);
		chargestax.set_chargeStaxTotChrgAmtBCurr(usancechgs);
		chargestax.set_chargeStaxTotSvrChrgAmtBCurr(olc_usance_serv_tax);
		Move_Charge_Values(chargestax.post_CmnChrg_SrvChrg());   
	   /*tranRec.setTranAcingBrnCode(Integer.parseInt(branchCode));	
	 	  tranRec.setTranInternalAcnum(0);
	 	  tranRec.setTranContractNum(0);
	 	  tranRec.setTranGlaccCode(contraGL1);
	 	  tranRec.setTranCurrCode(basecurr);
	 	  tranRec.setTranDbCrFlg("C");
	 	  tranRec.setTranNarrDtl1("Import LC Issue");
	 	  tranRec.setTranNarrDtl2(refno);
	 	  tranRec.setTranAmount(usancechgs);
	 	  tranRec.setTranBaseCurrEqAmt(usancechgs);
	 	  Move_Tran_Values(tranRec);*/     
	}
   
   public void  Set_Tran_CreditContra_Values2(DTObject InputmapObj)throws PanaceaException
   {	  
		//S.Suresh Babu Changes 30-06-2009

	   	chargeStax chargestax = new chargeStax();
 	  	chargestax.set_chargeStaxBrnCode(Integer.parseInt(branchCode));
 	  	chargestax.set_chargeStaxChrgCode(dtoobj.getValue("TRCHG_COMMITMNT_CHGCD"));
		chargestax.set_chargeStaxChrgCurr(basecurr);
		chargestax.set_chargeStaxTotChrgAmt(commchgs);		
		chargestax.set_chargeStaxTotSvrChrgAmt(olc_commit_serv_tax);
		chargestax.set_chargeStaxTotChrgAmtBCurr(commchgs);
		chargestax.set_chargeStaxTotSvrChrgAmtBCurr(olc_commit_serv_tax);
		Move_Charge_Values(chargestax.post_CmnChrg_SrvChrg());
	      /*tranRec.setTranAcingBrnCode(Integer.parseInt(branchCode));	
	 	  tranRec.setTranInternalAcnum(0);
	 	  tranRec.setTranContractNum(0);
	 	  tranRec.setTranGlaccCode(contraGL2);
	 	  tranRec.setTranCurrCode(basecurr);
	 	  tranRec.setTranDbCrFlg("C");
	 	  tranRec.setTranNarrDtl1("Import LC Issue");
	 	  tranRec.setTranNarrDtl2(refno);
	 	  tranRec.setTranAmount(commchgs);
	 	  tranRec.setTranBaseCurrEqAmt(commchgs);
	 	  Move_Tran_Values(tranRec);*/     
	}
   //Changes P.Subramani-Chn-19-06-2008 End
   
   public void chargeStax(DTObject InputmapObj) throws PanaceaException
	  {
		chargeStax chargestax = new chargeStax();
	     for(int i=0;i<InputmapObj.getDTDObject("TRANCHGS").getRowCount();i++)
		  {
	    	 //Vinoth.S Changes on 27-Jan-2011 Beg 
			 //if((Double.parseDouble(InputmapObj.getDTDObject("TRANCHGS",i,"TRANCHGS_ACT_CHGS")) > 0)|| Removed 
	    	 if((Double.parseDouble(InputmapObj.getDTDObject("TRANCHGS",i,"TRANCHGS_CHGAMT_REC_CURR")) > 0)||
	    	 //Vinoth.S Changes on 27-Jan-2011 End
		     (Double.parseDouble(InputmapObj.getDTDObject("TRANCHGS",i,"TRANCHGS_STAX_REC_CURR"))) > 0)
		     {
				chargestax.set_chargeStaxBrnCode(Integer.parseInt(branchCode));
				chargestax.set_chargeStaxChrgCode(InputmapObj.getDTDObject("TRANCHGS",i,"TRANCHGS_CHG_CODE"));
				chargestax.set_chargeStaxChrgCurr(InputmapObj.getDTDObject("TRANCHGS",i,"TRANCHGS_CHG_CURR"));
				//chargestax.set_chargeStaxTotChrgAmt(Double.parseDouble(InputmapObj.getDTDObject("TRANCHGS",i,"TRANCHGS_ACT_CHGS")));
				//Vinoth.S Changes on 27-Jan-2011 Beg
				chargestax.set_chargeStaxTotSvrChrgAmt(Double.parseDouble(InputmapObj.getDTDObject("TRANCHGS",i,"TRANCHGS_STAX_REC_CURR")));
				//S.Suresh Babu Add 30-06-2009
				//chargestax.set_chargeStaxTotChrgAmtBCurr(Double.parseDouble(InputmapObj.getDTDObject("TRANCHGS",i,"TRANCHGS_ACT_CHGS")));
				 chargestax.set_chargeStaxTotChrgAmt(Double.parseDouble(InputmapObj.getDTDObject("TRANCHGS",i,"TRANCHGS_CHGAMT_REC_CURR")));
 			    //Vinoth.S Changes on 27-Jan-2011 End
				chargestax.set_chargeStaxTotSvrChrgAmtBCurr(Double.parseDouble(InputmapObj.getDTDObject("TRANCHGS",i,"TRANCHGS_STAX_REC_CURR")));
				Move_Charge_Values(chargestax.post_CmnChrg_SrvChrg());      
			 }  	   	
		 }       	
	 }
   
   public void Set_Tran_Debit_Values(DTObject InputmapObj) throws PanaceaException, SQLException
   {
	  	    TranstlmntBO Transtlmntobj=new TranstlmntBO();
			Transtlmntobj.setSourceTable(dtoobj.getValue("TranStl_SOURCE_TABLE"));
			Transtlmntobj.setSourceKey(_sourceKey);
			Transtlmntobj.setTba_main_key(TBAAUTH_MAIN_PK);
			Transtlmntobj.setTba_entry_date(TBAAUTH_ENTRY_DATE);
			Transtlmntobj.setTab_dtl_sl(TBAAUTH_DTL_SL);
			dtoobj.setValue("TranStl_SOURCE_KEY",_sourceKey);
			Transtlmntobj.updateValues(dtoobj);
			Move_Transtlmnt_Values(Transtlmntobj.getTransactionRecords(),Transtlmntobj.getTransactionBatchRecord());
			if(dtoobj.getValue("UserOption").equalsIgnoreCase("A"))
 			{
			updateInvNum(Transtlmntobj.getInventoryNumber());
 			}
   }
   
   private void updateInvNum(long _invNum) throws PanaceaException
   {
   	try
   	{
   		String update_q="UPDATE OLC SET TRANSTLMNT_INV_NUM="+_invNum+" WHERE  OLC_BRN_CODE='" + Integer.parseInt(dtoobj.getValue("OLC_BRN_CODE"))+"' AND  OLC_LC_TYPE='" +dtoobj.getValue("OLC_LC_TYPE")+"' AND OLC_LC_YEAR='" + Integer.parseInt(dtoobj.getValue("OLC_LC_YEAR"))+"' AND OLC_LC_SL ='"+ olcSl+"'";
		new OlcManager(_COLLECTIONObj,V_LOG_REQ, V_ADD_LOG_REQ).UpdateByQuery(update_q);
   	}
   	catch (Exception e) {
			throw new PanaceaException(e.getLocalizedMessage());
		}
   }
   
   //Changes in eolc on 28-May-2018 start
   private void AddSwiftLcDetails(DTObject dtoobject) throws PanaceaException
   {
       try
       {
           LcDetails  LcDetailsInstance=new LcDetails();
           LcDetailsManager  LcDetailsManagerInstance = new LcDetailsManager(_COLLECTIONObj,V_LOG_REQ, V_ADD_LOG_REQ);
			           LcDetailsInstance.setLcBrnCode(Integer.parseInt(dtoobject.getValue("OLC_BRN_CODE")));
			           LcDetailsInstance.setLcLcType(dtoobject.getValue("OLC_LC_TYPE"));
			           LcDetailsInstance.setLcLcYear(Integer.parseInt(dtoobject.getValue("OLC_LC_YEAR")));
			           LcDetailsInstance.setLcLcSl(olcSl);
                       LcDetailsInstance.setLcFormOfDocCredit(Integer.parseInt(dtoobject.getValue("LC_FORM_OF_DOC_CREDIT")));
                       LcDetailsInstance.setLcReferenceToPreadvice(dtoobject.getValue("LC_REFERENCE_TO_PREADVICE"));
                       LcDetailsInstance.setLcApplicableRules(Integer.parseInt(dtoobject.getValue("LC_APPLICABLE_RULES")));
                       LcDetailsInstance.setLcApplicantReq(stringToChar(dtoobject.getValue("LC_APPLICANT_REQ")));
                       LcDetailsInstance.setLcApplicantType(stringToChar(dtoobject.getValue("LC_APPLICANT_TYPE")));
                       LcDetailsInstance.setLcApplicantBrnCode(dtoobject.getValue("LC_APPLICANT_BRN_CODE"));
                       LcDetailsInstance.setLcApplicantBicCode(dtoobject.getValue("LC_APPLICANT_BIC_CODE"));
                       LcDetailsInstance.setLcApplicantRoutid(dtoobject.getValue("LC_APPLICANT_ROUTID"));
                       LcDetailsInstance.setLcApplicantBnkCode(dtoobject.getValue("LC_APPLICANT_BNK_CODE"));
                       LcDetailsInstance.setLcApplicantAddr1(dtoobject.getValue("LC_APPLICANT_ADDR1"));
                       LcDetailsInstance.setLcApplicantAddr2(dtoobject.getValue("LC_APPLICANT_ADDR2"));
                       LcDetailsInstance.setLcApplicantAddr3(dtoobject.getValue("LC_APPLICANT_ADDR3"));
                       LcDetailsInstance.setLcApplicantAddr4(dtoobject.getValue("LC_APPLICANT_ADDR4"));
                       LcDetailsInstance.setLcApplicantAddr5(dtoobject.getValue("LC_APPLICANT_ADDR5"));
                       LcDetailsInstance.setLcAvailableWithType(stringToChar(dtoobject.getValue("LC_AVAILABLE_WITH_TYPE")));
                       LcDetailsInstance.setLcAvailableWithBrnCode(dtoobject.getValue("LC_AVAILABLE_WITH_BRN_CODE"));
                       LcDetailsInstance.setLcAvailableWithCode(dtoobject.getValue("LC_AVAILABLE_WITH_CODE"));
                       LcDetailsInstance.setLcAvailableWithRoutid(dtoobject.getValue("LC_AVAILABLE_WITH_ROUTID"));
                       LcDetailsInstance.setLcAvailableWithBnkCode(dtoobject.getValue("LC_AVAILABLE_WITH_BNK_CODE"));
                       LcDetailsInstance.setLcAvailableWithAddr1(dtoobject.getValue("LC_AVAILABLE_WITH_ADDR1"));
                       LcDetailsInstance.setLcAvailableWithAddr2(dtoobject.getValue("LC_AVAILABLE_WITH_ADDR2"));
                       LcDetailsInstance.setLcAvailableWithAddr3(dtoobject.getValue("LC_AVAILABLE_WITH_ADDR3"));
                       LcDetailsInstance.setLcAvailableWithAddr4(dtoobject.getValue("LC_AVAILABLE_WITH_ADDR4"));
                       LcDetailsInstance.setLcAvailableWithAddr5(dtoobject.getValue("LC_AVAILABLE_WITH_ADDR5"));
                       LcDetailsInstance.setLcDraftsAt1(dtoobject.getValue("LC_DRAFTS_AT1"));
                       LcDetailsInstance.setLcDraftsAt2(dtoobject.getValue("LC_DRAFTS_AT2"));
                       LcDetailsInstance.setLcDraftsAt3(dtoobject.getValue("LC_DRAFTS_AT3"));
                       LcDetailsInstance.setLcDraweeReq(stringToChar(dtoobject.getValue("LC_DRAWEE_REQ")));
                       LcDetailsInstance.setLcDraweeType(stringToChar(dtoobject.getValue("LC_DRAWEE_TYPE")));
                       LcDetailsInstance.setLcDraweeBrnCode(dtoobject.getValue("LC_DRAWEE_BRN_CODE"));
                       LcDetailsInstance.setLcDraweeBicCode(dtoobject.getValue("LC_DRAWEE_BIC_CODE"));
                       LcDetailsInstance.setLcDraweeRoutid(dtoobject.getValue("LC_DRAWEE_ROUTID"));
                       LcDetailsInstance.setLcDraweeBnkCode(dtoobject.getValue("LC_DRAWEE_BNK_CODE"));
                       LcDetailsInstance.setLcDraweeAddr1(dtoobject.getValue("LC_DRAWEE_ADDR1"));
                       LcDetailsInstance.setLcDraweeAddr2(dtoobject.getValue("LC_DRAWEE_ADDR2"));
                       LcDetailsInstance.setLcDraweeAddr3(dtoobject.getValue("LC_DRAWEE_ADDR3"));
                       LcDetailsInstance.setLcDraweeAddr4(dtoobject.getValue("LC_DRAWEE_ADDR4"));
                       LcDetailsInstance.setLcDraweeAddr5(dtoobject.getValue("LC_DRAWEE_ADDR5"));
                       LcDetailsInstance.setLcMixedPayDetails1(dtoobject.getValue("LC_MIXED_PAY_DETAILS1"));
                       LcDetailsInstance.setLcMixedPayDetails2(dtoobject.getValue("LC_MIXED_PAY_DETAILS2"));
                       LcDetailsInstance.setLcMixedPayDetails3(dtoobject.getValue("LC_MIXED_PAY_DETAILS3"));
                       LcDetailsInstance.setLcMixedPayDetails4(dtoobject.getValue("LC_MIXED_PAY_DETAILS4"));
                       LcDetailsInstance.setLcDeferredPayDetails1(dtoobject.getValue("LC_DEFERRED_PAY_DETAILS1"));
                       LcDetailsInstance.setLcDeferredPayDetails2(dtoobject.getValue("LC_DEFERRED_PAY_DETAILS2"));
                       LcDetailsInstance.setLcDeferredPayDetails3(dtoobject.getValue("LC_DEFERRED_PAY_DETAILS3"));
                       LcDetailsInstance.setLcDeferredPayDetails4(dtoobject.getValue("LC_DEFERRED_PAY_DETAILS4"));
                       LcDetailsInstance.setLcPartialShipments(Integer.parseInt(dtoobject.getValue("LC_PARTIAL_SHIPMENTS")));
                       LcDetailsInstance.setLcTranshipment(Integer.parseInt(dtoobject.getValue("LC_TRANSHIPMENT")));
                       LcDetailsInstance.setLcPlaceOfTakingInCharge(dtoobject.getValue("LC_PLACE_OF_TAKING_IN_CHARGE"));
                       LcDetailsInstance.setLcPortOfLoading(dtoobject.getValue("LC_PORT_OF_LOADING"));
                       LcDetailsInstance.setLcPortOfDischarge(dtoobject.getValue("LC_PORT_OF_DISCHARGE"));
                       LcDetailsInstance.setLcPlaceOfFinalDest(dtoobject.getValue("LC_PLACE_OF_FINAL_DEST"));
                       LcDetailsInstance.setLcDescGoodsSer1("");
                       LcDetailsInstance.setLcDescGoodsSer2("");
                       LcDetailsInstance.setLcDescGoodsSer3("");
                       LcDetailsInstance.setLcDocReq1("");
                       LcDetailsInstance.setLcDocReq2("");
                       LcDetailsInstance.setLcDocReq3("");
                       LcDetailsInstance.setLcAddCondition1("");
                       LcDetailsInstance.setLcAddCondition2("");
                       LcDetailsInstance.setLcAddCondition3("");
                       LcDetailsInstance.setLcCharges1(dtoobject.getValue("LC_CHARGES1"));
                       LcDetailsInstance.setLcCharges2(dtoobject.getValue("LC_CHARGES2"));
                       LcDetailsInstance.setLcCharges3(dtoobject.getValue("LC_CHARGES3"));
                       LcDetailsInstance.setLcCharges4(dtoobject.getValue("LC_CHARGES4"));
                       LcDetailsInstance.setLcCharges5(dtoobject.getValue("LC_CHARGES5"));
                       LcDetailsInstance.setLcCharges6(dtoobject.getValue("LC_CHARGES6"));
                       LcDetailsInstance.setLcPerPresentationDay(Integer.parseInt(dtoobject.getValue("LC_PER_PRESENTATION_DAY")));
                       LcDetailsInstance.setLcConfirmationInst(Integer.parseInt(dtoobject.getValue("LC_CONFIRMATION_INST")));
                       LcDetailsInstance.setLcReimbReq(stringToChar(dtoobject.getValue("LC_REIMB_REQ")));
                       LcDetailsInstance.setLcReimbType(stringToChar(dtoobject.getValue("LC_REIMB_TYPE")));
                       LcDetailsInstance.setLcReimbBrnCode(dtoobject.getValue("LC_REIMB_BRN_CODE"));
                       LcDetailsInstance.setLcReimbBicCode(dtoobject.getValue("LC_REIMB_BIC_CODE"));
                       LcDetailsInstance.setLcReimbRoutid(dtoobject.getValue("LC_REIMB_ROUTID"));
                       LcDetailsInstance.setLcReimbBnkCode(dtoobject.getValue("LC_REIMB_BNK_CODE"));
                       LcDetailsInstance.setLcReimbAddr1(dtoobject.getValue("LC_REIMB_ADDR1"));
                       LcDetailsInstance.setLcReimbAddr2(dtoobject.getValue("LC_REIMB_ADDR2"));
                       LcDetailsInstance.setLcReimbAddr3(dtoobject.getValue("LC_REIMB_ADDR3"));
                       LcDetailsInstance.setLcReimbAddr4(dtoobject.getValue("LC_REIMB_ADDR4"));
                       LcDetailsInstance.setLcReimbAddr5(dtoobject.getValue("LC_REIMB_ADDR5"));
                       LcDetailsInstance.setLcInstPaying1(dtoobject.getValue("LC_INST_PAYING1"));
                       LcDetailsInstance.setLcInstPaying2(dtoobject.getValue("LC_INST_PAYING2"));
                       LcDetailsInstance.setLcInstPaying3(dtoobject.getValue("LC_INST_PAYING3"));
                       LcDetailsInstance.setLcInstPaying4(dtoobject.getValue("LC_INST_PAYING4"));
                       LcDetailsInstance.setLcInstPaying5(dtoobject.getValue("LC_INST_PAYING5"));
                       LcDetailsInstance.setLcInstPaying6(dtoobject.getValue("LC_INST_PAYING6"));
                       LcDetailsInstance.setLcInstPaying7(dtoobject.getValue("LC_INST_PAYING7"));
                       LcDetailsInstance.setLcInstPaying8(dtoobject.getValue("LC_INST_PAYING8"));
                       LcDetailsInstance.setLcInstPaying9(dtoobject.getValue("LC_INST_PAYING9"));
                       LcDetailsInstance.setLcInstPaying10(dtoobject.getValue("LC_INST_PAYING10"));
                       LcDetailsInstance.setLcInstPaying11(dtoobject.getValue("LC_INST_PAYING11"));
                       LcDetailsInstance.setLcInstPaying12(dtoobject.getValue("LC_INST_PAYING12"));
                       LcDetailsInstance.setLcSecondAdvReq(stringToChar(dtoobject.getValue("LC_SECOND_ADV_REQ")));
                       LcDetailsInstance.setLcSecondAdvType(stringToChar(dtoobject.getValue("LC_SECOND_ADV_TYPE")));
                       LcDetailsInstance.setLcSecondAdvBrnCode(dtoobject.getValue("LC_SECOND_ADV_BRN_CODE"));
                       LcDetailsInstance.setLcSecondAdvBicCode(dtoobject.getValue("LC_SECOND_ADV_BIC_CODE"));
                       LcDetailsInstance.setLcSecondAdvRoutid(dtoobject.getValue("LC_SECOND_ADV_ROUTID"));
                       LcDetailsInstance.setLcSecondAdvBnkCode(dtoobject.getValue("LC_SECOND_ADV_BNK_CODE"));
                       LcDetailsInstance.setLcSecondAdvAddr1(dtoobject.getValue("LC_SECOND_ADV_ADDR1"));
                       LcDetailsInstance.setLcSecondAdvAddr2(dtoobject.getValue("LC_SECOND_ADV_ADDR2"));
                       LcDetailsInstance.setLcSecondAdvAddr3(dtoobject.getValue("LC_SECOND_ADV_ADDR3"));
                       LcDetailsInstance.setLcSecondAdvAddr4(dtoobject.getValue("LC_SECOND_ADV_ADDR4"));
                       LcDetailsInstance.setLcSecondAdvAddr5(dtoobject.getValue("LC_SECOND_ADV_ADDR5"));
                       LcDetailsInstance.setLcSndrRecInfo1(dtoobject.getValue("LC_SNDR_REC_INFO1"));
                       LcDetailsInstance.setLcSndrRecInfo2(dtoobject.getValue("LC_SNDR_REC_INFO2"));
                       LcDetailsInstance.setLcSndrRecInfo3(dtoobject.getValue("LC_SNDR_REC_INFO3"));
                       LcDetailsInstance.setLcSndrRecInfo4(dtoobject.getValue("LC_SNDR_REC_INFO4"));
                       LcDetailsInstance.setLcSndrRecInfo5(dtoobject.getValue("LC_SNDR_REC_INFO5"));
                       LcDetailsInstance.setLcSndrRecInfo6(dtoobject.getValue("LC_SNDR_REC_INFO6"));
                       LcDetailsInstance.setLcApplicantCntryCode(dtoobject.getValue("LC_APPLICANT_CNTRY_CODE"));
                       LcDetailsInstance.setLcAvailableWithCntry(dtoobject.getValue("LC_AVAILABLE_WITH_CNTRY"));
                       LcDetailsInstance.setLcAvailableWithCodetyp(Integer.parseInt(dtoobject.getValue("LC_AVAILABLE_WITH_CODETYP")));
                       LcDetailsInstance.setLcDraweeCntryCode(dtoobject.getValue("LC_DRAWEE_CNTRY_CODE"));
                       LcDetailsInstance.setLcConfirmInstType(stringToChar(dtoobject.getValue("LC_CONFIRM_INST_TYPE")));
                       LcDetailsInstance.setLcReimbCntryCode(dtoobject.getValue("LC_REIMB_CNTRY_CODE"));
                       LcDetailsInstance.setLcSecondAdvCntrycode(dtoobject.getValue("LC_SECOND_ADV_CNTRYCODE"));
                       LcDetailsInstance.setLcShipmentPeriod1(dtoobject.getValue("LC_SHIPMENT_PERIOD1"));
                       LcDetailsInstance.setLcShipmentPeriod2(dtoobject.getValue("LC_SHIPMENT_PERIOD2"));
                       LcDetailsInstance.setLcShipmentPeriod3(dtoobject.getValue("LC_SHIPMENT_PERIOD3"));
                       LcDetailsInstance.setLcShipmentPeriod4(dtoobject.getValue("LC_SHIPMENT_PERIOD4"));
                       LcDetailsInstance.setLcShipmentPeriod5(dtoobject.getValue("LC_SHIPMENT_PERIOD5"));
                       LcDetailsInstance.setLcShipmentPeriod6(dtoobject.getValue("LC_SHIPMENT_PERIOD6"));
                       LcDetailsInstance.setLcPerPresentationRemarks(dtoobject.getValue("LC_PER_PRESENTATION_REMARKS"));
                       LcDetailsInstance.setLcRecBicCode(dtoobject.getValue("LC_REC_BIC_CODE"));
                       //Changes Sanjay1 22-07-2019 Begin
                       LcDetailsInstance.setLcCfmReimbType(stringToChar(dtoobject.getValue("LC_CFM_REIMB_TYPE")));
                       LcDetailsInstance.setLcCfmReimbBrnCode(dtoobject.getValue("LC_CFM_REIMB_BRN_CODE"));
                       LcDetailsInstance.setLcCfmReimbBicCode(dtoobject.getValue("LC_CFM_REIMB_BIC_CODE"));
                       LcDetailsInstance.setLcCfmReimbRoutid(dtoobject.getValue("LC_CFM_REIMB_ROUTID"));
                       LcDetailsInstance.setLcCfmReimbBnkCode(dtoobject.getValue("LC_CFM_REIMB_BNK_CODE"));
                       LcDetailsInstance.setLcCfmReimbAddr1(dtoobject.getValue("LC_CFM_REIMB_ADDR1"));
                       LcDetailsInstance.setLcCfmReimbAddr2(dtoobject.getValue("LC_CFM_REIMB_ADDR2"));
                       LcDetailsInstance.setLcCfmReimbAddr3(dtoobject.getValue("LC_CFM_REIMB_ADDR3"));
                       LcDetailsInstance.setLcCfmReimbAddr4(dtoobject.getValue("LC_CFM_REIMB_ADDR4"));
                       LcDetailsInstance.setLcCfmReimbAddr5(dtoobject.getValue("LC_CFM_REIMB_ADDR5"));
                       LcDetailsInstance.setLcCfmReimbCntryCode(dtoobject.getValue("LC_CFM_REIMB_CNTRY_CODE"));
                       //Changes Sanjay1 22-07-2019 End
                       //Set_Entd_Dtls(LcDetailsInstance);
                       LcDetailsInstance.setIsNew(true);
                       LcDetailsManagerInstance.save(LcDetailsInstance ,TBAAUTH_MAIN_PK,TBAAUTH_ENTRY_DATE,TBAAUTH_DTL_SL);
           }
       catch(Exception e)
       {
           throw new PanaceaException(e.getLocalizedMessage());
       }
   }
   
   private void addLCHistRecord(DTObject dtoobject) throws PanaceaException
   {
       try
       {
    	   LcDetailsHist  LcDetailsHistInstance=new LcDetailsHist();
    	   LcDetailsHistManager  LcHistDetailsManagerInstance = new LcDetailsHistManager(_COLLECTIONObj,V_LOG_REQ, V_ADD_LOG_REQ);
           LcDetailsHistInstance.setLchistBrnCode(Integer.parseInt(dtoobject.getValue("OLC_BRN_CODE")));
           LcDetailsHistInstance.setLchistLcType(dtoobject.getValue("OLC_LC_TYPE"));
           LcDetailsHistInstance.setLchistLcYear(Integer.parseInt(dtoobject.getValue("OLC_LC_YEAR")));
           LcDetailsHistInstance.setLchistLcSl(olcSl);
           LcDetailsHistInstance.setLchistLcHistdate(DateToYYYYMMDD(dtoobject.getValue("CBD")));
           LcDetailsHistInstance.setLchistLcHistsl(max_sl1);
           LcDetailsHistInstance.setLchistFormOfDocCredit(Integer.parseInt(dtoobject.getValue("LC_FORM_OF_DOC_CREDIT")));
           LcDetailsHistInstance.setLchistReferenceToPreadvice(dtoobject.getValue("LC_REFERENCE_TO_PREADVICE"));
           LcDetailsHistInstance.setLchistApplicableRules(Integer.parseInt(dtoobject.getValue("LC_APPLICABLE_RULES")));
           LcDetailsHistInstance.setLchistApplicantReq(stringToChar(dtoobject.getValue("LC_APPLICANT_REQ")));
           LcDetailsHistInstance.setLchistApplicantType(stringToChar(dtoobject.getValue("LC_APPLICANT_TYPE")));
           LcDetailsHistInstance.setLchistApplicantBrnCode(dtoobject.getValue("LC_APPLICANT_BRN_CODE"));
           LcDetailsHistInstance.setLchistApplicantBicCode(dtoobject.getValue("LC_APPLICANT_BIC_CODE"));
           LcDetailsHistInstance.setLchistApplicantRoutid(dtoobject.getValue("LC_APPLICANT_ROUTID"));
           LcDetailsHistInstance.setLchistApplicantBnkCode(dtoobject.getValue("LC_APPLICANT_BNK_CODE"));
           LcDetailsHistInstance.setLchistApplicantAddr1(dtoobject.getValue("LC_APPLICANT_ADDR1"));
           LcDetailsHistInstance.setLchistApplicantAddr2(dtoobject.getValue("LC_APPLICANT_ADDR2"));
           LcDetailsHistInstance.setLchistApplicantAddr3(dtoobject.getValue("LC_APPLICANT_ADDR3"));
           LcDetailsHistInstance.setLchistApplicantAddr4(dtoobject.getValue("LC_APPLICANT_ADDR4"));
           LcDetailsHistInstance.setLchistApplicantAddr5(dtoobject.getValue("LC_APPLICANT_ADDR5"));
           LcDetailsHistInstance.setLchistAvailableWithType(stringToChar(dtoobject.getValue("LC_AVAILABLE_WITH_TYPE")));
                       LcDetailsHistInstance.setLchistAvailableWithBrnCode(dtoobject.getValue("LC_AVAILABLE_WITH_BRN_CODE"));
                       LcDetailsHistInstance.setLchistAvailableWithCode(dtoobject.getValue("LC_AVAILABLE_WITH_CODE"));
                       LcDetailsHistInstance.setLchistAvailableWithRoutid(dtoobject.getValue("LC_AVAILABLE_WITH_ROUTID"));
                       LcDetailsHistInstance.setLchistAvailableWithBnkCode(dtoobject.getValue("LC_AVAILABLE_WITH_BNK_CODE"));
                       LcDetailsHistInstance.setLchistAvailableWithAddr1(dtoobject.getValue("LC_AVAILABLE_WITH_ADDR1"));
                       LcDetailsHistInstance.setLchistAvailableWithAddr2(dtoobject.getValue("LC_AVAILABLE_WITH_ADDR2"));
                       LcDetailsHistInstance.setLchistAvailableWithAddr3(dtoobject.getValue("LC_AVAILABLE_WITH_ADDR3"));
                       LcDetailsHistInstance.setLchistAvailableWithAddr4(dtoobject.getValue("LC_AVAILABLE_WITH_ADDR4"));
                       LcDetailsHistInstance.setLchistAvailableWithAddr5(dtoobject.getValue("LC_AVAILABLE_WITH_ADDR5"));
                       LcDetailsHistInstance.setLchistDraftsAt1(dtoobject.getValue("LC_DRAFTS_AT1"));
                       LcDetailsHistInstance.setLchistDraftsAt2(dtoobject.getValue("LC_DRAFTS_AT2"));
                       LcDetailsHistInstance.setLchistDraftsAt3(dtoobject.getValue("LC_DRAFTS_AT3"));
                       LcDetailsHistInstance.setLchistDraweeReq(stringToChar(dtoobject.getValue("LC_DRAWEE_REQ")));
                       LcDetailsHistInstance.setLchistDraweeType(stringToChar(dtoobject.getValue("LC_DRAWEE_TYPE")));
                       LcDetailsHistInstance.setLchistDraweeBrnCode(dtoobject.getValue("LC_DRAWEE_BRN_CODE"));
                       LcDetailsHistInstance.setLchistDraweeBicCode(dtoobject.getValue("LC_DRAWEE_BIC_CODE"));
                       LcDetailsHistInstance.setLchistDraweeRoutid(dtoobject.getValue("LC_DRAWEE_ROUTID"));
                       LcDetailsHistInstance.setLchistDraweeBnkCode(dtoobject.getValue("LC_DRAWEE_BNK_CODE"));
                       LcDetailsHistInstance.setLchistDraweeAddr1(dtoobject.getValue("LC_DRAWEE_ADDR1"));
                       LcDetailsHistInstance.setLchistDraweeAddr2(dtoobject.getValue("LC_DRAWEE_ADDR2"));
                       LcDetailsHistInstance.setLchistDraweeAddr3(dtoobject.getValue("LC_DRAWEE_ADDR3"));
                       LcDetailsHistInstance.setLchistDraweeAddr4(dtoobject.getValue("LC_DRAWEE_ADDR4"));
                       LcDetailsHistInstance.setLchistDraweeAddr5(dtoobject.getValue("LC_DRAWEE_ADDR5"));
                       LcDetailsHistInstance.setLchistMixedPayDetails1(dtoobject.getValue("LC_MIXED_PAY_DETAILS1"));
                       LcDetailsHistInstance.setLchistMixedPayDetails2(dtoobject.getValue("LC_MIXED_PAY_DETAILS2"));
                       LcDetailsHistInstance.setLchistMixedPayDetails3(dtoobject.getValue("LC_MIXED_PAY_DETAILS3"));
                       LcDetailsHistInstance.setLchistMixedPayDetails4(dtoobject.getValue("LC_MIXED_PAY_DETAILS4"));
                       LcDetailsHistInstance.setLchistDeferredPayDetails1(dtoobject.getValue("LC_DEFERRED_PAY_DETAILS1"));
                       LcDetailsHistInstance.setLchistDeferredPayDetails2(dtoobject.getValue("LC_DEFERRED_PAY_DETAILS2"));
                       LcDetailsHistInstance.setLchistDeferredPayDetails3(dtoobject.getValue("LC_DEFERRED_PAY_DETAILS3"));
                       LcDetailsHistInstance.setLchistDeferredPayDetails4(dtoobject.getValue("LC_DEFERRED_PAY_DETAILS4"));
                       LcDetailsHistInstance.setLchistPartialShipments(Integer.parseInt(dtoobject.getValue("LC_PARTIAL_SHIPMENTS")));
                       LcDetailsHistInstance.setLchistTranshipment(Integer.parseInt(dtoobject.getValue("LC_TRANSHIPMENT")));
                       LcDetailsHistInstance.setLchistPlaceInCharge(dtoobject.getValue("LC_PLACE_OF_TAKING_IN_CHARGE"));
                       LcDetailsHistInstance.setLchistPortOfLoading(dtoobject.getValue("LC_PORT_OF_LOADING"));
                       LcDetailsHistInstance.setLchistPortOfDischarge(dtoobject.getValue("LC_PORT_OF_DISCHARGE"));
                       LcDetailsHistInstance.setLchistPlaceOfFinalDest(dtoobject.getValue("LC_PLACE_OF_FINAL_DEST"));
                       LcDetailsHistInstance.setLchistDescGoodsSer1("");
                       LcDetailsHistInstance.setLchistDescGoodsSer2("");
                       LcDetailsHistInstance.setLchistDescGoodsSer3("");
                       LcDetailsHistInstance.setLchistDocReq1("");
                       LcDetailsHistInstance.setLchistDocReq2("");
                       LcDetailsHistInstance.setLchistDocReq3("");
                       LcDetailsHistInstance.setLchistAddCondition1("");
                       LcDetailsHistInstance.setLchistAddCondition2("");
                       LcDetailsHistInstance.setLchistAddCondition3("");
                       LcDetailsHistInstance.setLchistCharges1(dtoobject.getValue("LC_CHARGES1"));
                       LcDetailsHistInstance.setLchistCharges2(dtoobject.getValue("LC_CHARGES2"));
                       LcDetailsHistInstance.setLchistCharges3(dtoobject.getValue("LC_CHARGES3"));
                       LcDetailsHistInstance.setLchistCharges4(dtoobject.getValue("LC_CHARGES4"));
                       LcDetailsHistInstance.setLchistCharges5(dtoobject.getValue("LC_CHARGES5"));
                       LcDetailsHistInstance.setLchistCharges6(dtoobject.getValue("LC_CHARGES6"));
                       LcDetailsHistInstance.setLchistPerPresentationDay(Integer.parseInt(dtoobject.getValue("LC_PER_PRESENTATION_DAY")));
                       LcDetailsHistInstance.setLchistConfirmationInst(Integer.parseInt(dtoobject.getValue("LC_CONFIRMATION_INST")));
                       LcDetailsHistInstance.setLchistReimbReq(stringToChar(dtoobject.getValue("LC_REIMB_REQ")));
                       LcDetailsHistInstance.setLchistReimbType(stringToChar(dtoobject.getValue("LC_REIMB_TYPE")));
                       LcDetailsHistInstance.setLchistReimbBrnCode(dtoobject.getValue("LC_REIMB_BRN_CODE"));
                       LcDetailsHistInstance.setLchistReimbBicCode(dtoobject.getValue("LC_REIMB_BIC_CODE"));
                       LcDetailsHistInstance.setLchistReimbRoutid(dtoobject.getValue("LC_REIMB_ROUTID"));
                       LcDetailsHistInstance.setLchistReimbBnkCode(dtoobject.getValue("LC_REIMB_BNK_CODE"));
                       LcDetailsHistInstance.setLchistReimbAddr1(dtoobject.getValue("LC_REIMB_ADDR1"));
                       LcDetailsHistInstance.setLchistReimbAddr2(dtoobject.getValue("LC_REIMB_ADDR2"));
                       LcDetailsHistInstance.setLchistReimbAddr3(dtoobject.getValue("LC_REIMB_ADDR3"));
                       LcDetailsHistInstance.setLchistReimbAddr4(dtoobject.getValue("LC_REIMB_ADDR4"));
                       LcDetailsHistInstance.setLchistReimbAddr5(dtoobject.getValue("LC_REIMB_ADDR5"));
                       LcDetailsHistInstance.setLchistInstPaying1(dtoobject.getValue("LC_INST_PAYING1"));
                       LcDetailsHistInstance.setLchistInstPaying2(dtoobject.getValue("LC_INST_PAYING2"));
                       LcDetailsHistInstance.setLchistInstPaying3(dtoobject.getValue("LC_INST_PAYING3"));
                       LcDetailsHistInstance.setLchistInstPaying4(dtoobject.getValue("LC_INST_PAYING4"));
                       LcDetailsHistInstance.setLchistInstPaying5(dtoobject.getValue("LC_INST_PAYING5"));
                       LcDetailsHistInstance.setLchistInstPaying6(dtoobject.getValue("LC_INST_PAYING6"));
                       LcDetailsHistInstance.setLchistInstPaying7(dtoobject.getValue("LC_INST_PAYING7"));
                       LcDetailsHistInstance.setLchistInstPaying8(dtoobject.getValue("LC_INST_PAYING8"));
                       LcDetailsHistInstance.setLchistInstPaying9(dtoobject.getValue("LC_INST_PAYING9"));
                       LcDetailsHistInstance.setLchistInstPaying10(dtoobject.getValue("LC_INST_PAYING10"));
                       LcDetailsHistInstance.setLchistInstPaying11(dtoobject.getValue("LC_INST_PAYING11"));
                       LcDetailsHistInstance.setLchistInstPaying12(dtoobject.getValue("LC_INST_PAYING12"));
                       LcDetailsHistInstance.setLchistSecondAdvReq(stringToChar(dtoobject.getValue("LC_SECOND_ADV_REQ")));
                       LcDetailsHistInstance.setLchistSecondAdvType(stringToChar(dtoobject.getValue("LC_SECOND_ADV_TYPE")));
                       LcDetailsHistInstance.setLchistSecondAdvBrnCode(dtoobject.getValue("LC_SECOND_ADV_BRN_CODE"));
                       LcDetailsHistInstance.setLchistSecondAdvBicCode(dtoobject.getValue("LC_SECOND_ADV_BIC_CODE"));
                       LcDetailsHistInstance.setLchistSecondAdvRoutid(dtoobject.getValue("LC_SECOND_ADV_ROUTID"));
                       LcDetailsHistInstance.setLchistSecondAdvBnkCode(dtoobject.getValue("LC_SECOND_ADV_BNK_CODE"));
                       LcDetailsHistInstance.setLchistSecondAdvAddr1(dtoobject.getValue("LC_SECOND_ADV_ADDR1"));
                       LcDetailsHistInstance.setLchistSecondAdvAddr2(dtoobject.getValue("LC_SECOND_ADV_ADDR2"));
                       LcDetailsHistInstance.setLchistSecondAdvAddr3(dtoobject.getValue("LC_SECOND_ADV_ADDR3"));
                       LcDetailsHistInstance.setLchistSecondAdvAddr4(dtoobject.getValue("LC_SECOND_ADV_ADDR4"));
                       LcDetailsHistInstance.setLchistSecondAdvAddr5(dtoobject.getValue("LC_SECOND_ADV_ADDR5"));
                       LcDetailsHistInstance.setLchistSndrRecInfo1(dtoobject.getValue("LC_SNDR_REC_INFO1"));
                       LcDetailsHistInstance.setLchistSndrRecInfo2(dtoobject.getValue("LC_SNDR_REC_INFO2"));
                       LcDetailsHistInstance.setLchistSndrRecInfo3(dtoobject.getValue("LC_SNDR_REC_INFO3"));
                       LcDetailsHistInstance.setLchistSndrRecInfo4(dtoobject.getValue("LC_SNDR_REC_INFO4"));
                       LcDetailsHistInstance.setLchistSndrRecInfo5(dtoobject.getValue("LC_SNDR_REC_INFO5"));
                       LcDetailsHistInstance.setLchistSndrRecInfo6(dtoobject.getValue("LC_SNDR_REC_INFO6"));
                       LcDetailsHistInstance.setLchistApplicantCntryCode(dtoobject.getValue("LC_APPLICANT_CNTRY_CODE"));
                       LcDetailsHistInstance.setLchistAvailableWithCntry(dtoobject.getValue("LC_AVAILABLE_WITH_CNTRY"));
                       LcDetailsHistInstance.setLchistAvailableWithCodetyp(Integer.parseInt(dtoobject.getValue("LC_AVAILABLE_WITH_CODETYP")));
                       LcDetailsHistInstance.setLchistDraweeCntryCode(dtoobject.getValue("LC_DRAWEE_CNTRY_CODE"));
                       LcDetailsHistInstance.setLchistConfirmInstType(stringToChar(dtoobject.getValue("LC_CONFIRM_INST_TYPE")));
                       LcDetailsHistInstance.setLchistReimbCntryCode(dtoobject.getValue("LC_REIMB_CNTRY_CODE"));
                       LcDetailsHistInstance.setLchistSecondAdvCntrycode(dtoobject.getValue("LC_SECOND_ADV_CNTRYCODE"));
                       LcDetailsHistInstance.setLchistShipmentPeriod1(dtoobject.getValue("LC_SHIPMENT_PERIOD1"));
                       LcDetailsHistInstance.setLchistShipmentPeriod2(dtoobject.getValue("LC_SHIPMENT_PERIOD2"));
                       LcDetailsHistInstance.setLchistShipmentPeriod3(dtoobject.getValue("LC_SHIPMENT_PERIOD3"));
                       LcDetailsHistInstance.setLchistShipmentPeriod4(dtoobject.getValue("LC_SHIPMENT_PERIOD4"));
                       LcDetailsHistInstance.setLchistShipmentPeriod5(dtoobject.getValue("LC_SHIPMENT_PERIOD5"));
                       LcDetailsHistInstance.setLchistShipmentPeriod6(dtoobject.getValue("LC_SHIPMENT_PERIOD6"));
                       LcDetailsHistInstance.setLchistPerPresntRemarks(dtoobject.getValue("LC_PER_PRESENTATION_REMARKS"));
                       LcDetailsHistInstance.setLchistRecBicCode(dtoobject.getValue("LC_REC_BIC_CODE"));
                       //Changes Sanjay1 22-07-2019 Begin                       
                       LcDetailsHistInstance.setLchistCfmReimbType(stringToChar(dtoobject.getValue("LC_CFM_REIMB_TYPE")));
                       LcDetailsHistInstance.setLchistCfmReimbBrnCode(dtoobject.getValue("LC_CFM_REIMB_BRN_CODE"));
                       LcDetailsHistInstance.setLchistCfmReimbBicCode(dtoobject.getValue("LC_CFM_REIMB_BIC_CODE"));
                       LcDetailsHistInstance.setLchistCfmReimbRoutid(dtoobject.getValue("LC_CFM_REIMB_ROUTID"));
                       LcDetailsHistInstance.setLchistCfmReimbBnkCode(dtoobject.getValue("LC_CFM_REIMB_BNK_CODE"));
                       LcDetailsHistInstance.setLchistCfmReimbAddr1(dtoobject.getValue("LC_CFM_REIMB_ADDR1"));
                       LcDetailsHistInstance.setLchistCfmReimbAddr2(dtoobject.getValue("LC_CFM_REIMB_ADDR2"));
                       LcDetailsHistInstance.setLchistCfmReimbAddr3(dtoobject.getValue("LC_CFM_REIMB_ADDR3"));
                       LcDetailsHistInstance.setLchistCfmReimbAddr4(dtoobject.getValue("LC_CFM_REIMB_ADDR4"));
                       LcDetailsHistInstance.setLchistCfmReimbAddr5(dtoobject.getValue("LC_CFM_REIMB_ADDR5"));
                       LcDetailsHistInstance.setLchistCfmReimbCntryCode(dtoobject.getValue("LC_CFM_REIMB_CNTRY_CODE"));
                       //Changes Sanjay1 22-07-2019 End
                       //Set_Entd_Dtls(LcDetailsHistInstance);
                       LcDetailsHistInstance.setIsNew(true);
                       LcHistDetailsManagerInstance.save(LcDetailsHistInstance ,TBAAUTH_MAIN_PK,TBAAUTH_ENTRY_DATE,TBAAUTH_DTL_SL);
           }
       catch(Exception e)
       {
           throw new PanaceaException(e.getLocalizedMessage());
       }
   }
   private void DeleteFromLCDetails(DTObject dtoobject) throws PanaceaException
   {
	   try
	   {
		   LcDetailsManager LcDetails = new LcDetailsManager(_COLLECTIONObj,V_LOG_REQ, V_ADD_LOG_REQ);
		   LcDetails.deleteByKey((Integer.parseInt(dtoobject.getValue("OLC_BRN_CODE"))),olcSl,dtoobject.getValue("OLC_LC_TYPE"),(Integer.parseInt(dtoobject.getValue("OLC_LC_YEAR"))));
	   }
	   catch(Exception e)
	    {
	        throw new PanaceaException(e.getLocalizedMessage());
	    }	
   }
 
       
   private void ModifySwifLcDetails(DTObject dtoobject) throws PanaceaException
   {
	   try
	   {
		   setSerialNumber(dtoobject);
		   addLCHistRecord(dtoobject);		   
		   DeleteFromLCDetails(dtoobject);//delete from lc_details table
		   AddSwiftLcDetails(dtoobject);
		   
		   
	   }
	   catch(Exception e)
       {
           throw new PanaceaException(e.getLocalizedMessage());
       }
   }
   
 private void setSerialNumber(DTObject dtoobject) throws PanaceaException
   {
   
   	try {
   		LcDetailsHist lchist=null;
   		LcDetailsHistManager  lchistmanager = new LcDetailsHistManager(_COLLECTIONObj,V_LOG_REQ, V_ADD_LOG_REQ);
   			lchist = lchistmanager.loadByKey((Integer.parseInt(dtoobject.getValue("OLC_BRN_CODE"))),DateToYYYYMMDD(dtoobj.getValue("CBD")),olcSl,dtoobject.getValue("OLC_LC_TYPE"),(Integer.parseInt(dtoobject.getValue("OLC_LC_YEAR"))));
	            if (lchist != null)
	            {
	            	max_sl1=lchistmanager.GetMaxSl(Integer.parseInt(dtoobject.getValue("OLC_BRN_CODE")), DateToYYYYMMDD(dtoobj.getValue("CBD")),olcSl, dtoobject.getValue("OLC_LC_TYPE"),Integer.parseInt(dtoobject.getValue("OLC_LC_YEAR")));
	            	//max_sl1 = max_sl1 + 1;
	            }
	            else
	            {
	            	max_sl1 =1;
	            	
	            }
	             ReturnResult.setValue("REQ_DAY_SL",String.valueOf(max_sl1));
	             dtoobj.setValue("REQ_DAY_SL",max_sl1+"");
	              
   	}
   	catch (Exception e) {
			throw new PanaceaException(e.getLocalizedMessage());
		}
   }
   
//Changes in eolc on 28-May-2018 end
 
 public void Updateclobolc() throws PanaceaException {
	 String _errmsg ="";
		try {
			Connection _conn = null;
			CallableStatement _cstmt = null;
			_conn = openConnection();
			_cstmt = _conn.prepareCall("CALL PKG_CSB_SWIFT.INSERT_CLOBDATAOLC(?,?,?,?,?,?,?,?,?,?)");
			_cstmt.setInt(1, Integer.parseInt(dtoobj.getValue("OLC_BRN_CODE")) );
			_cstmt.setString(2, dtoobj.getValue("OLC_LC_TYPE").trim());
			_cstmt.setInt(3, Integer.parseInt(dtoobj.getValue("OLC_LC_YEAR").trim()));
			if(dtoobj.getValue("OLC_LC_PRESANC_DATE").trim().equals(""))
				_cstmt.setDate(4,null);
			else
				_cstmt.setString(4, FormatUtils.formatToDDMonYear(dtoobj.getValue("OLC_LC_PRESANC_DATE")));
			_cstmt.setInt(5, Integer.parseInt(dtoobj.getValue("OLC_LC_PRESANC_DAY_SL")));
			_cstmt.setLong(6, Long.parseLong(dtoobj.getValue("OLC_CUST_NUM")));
			_cstmt.setInt(7, olcSl);	
			//Changes in EOLC on 05-Oct-2018 start
			_cstmt.setString(8, Option);
			_cstmt.setLong(9, max_sl1);
			//Changes in EOLC on 05-Oct-2018 end
			_cstmt.registerOutParameter(10, Types.VARCHAR);
			
			_cstmt.execute();
			_errmsg =_cstmt.getString(10);
			if(_errmsg != null &&!_errmsg.trim().equals(""))
  			{
  				throw new PanaceaException(_errmsg);
  			}
          	
			_cstmt.close();
          } catch (Exception e) {
			throw new PanaceaException(_errmsg);
		}
	}

}
