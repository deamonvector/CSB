package panaceaOLCweb.OLCCtlbean;

import panacea.OLCaction.eolcval;
import panacea.Validator.CommonValidator;
import panacea.com.component.TFMCRatesDetails;
import panacea.com.component.TFMChargesDetails;
import panacea.com.component.TranStlmntPostDetails;
import panacea.common.DTObject;
import panacea.common.GetGridDisplay;
import panacea.common.JNDINames;
import panacea.delegate.CommonDelegate;
import panaceaweb.utility.Common;
import panaceaweb.utility.QueryManager;
import panaceaweb.utility.gridXML;
import java.sql.Clob;
import org.apache.commons.lang.StringUtils;

public class eolcctl extends Common {
	// ADDED BY PRASHANTH ON 29 JANUARY 2018
	//private String olcLcToBeCnfrmdByBrnName = "";
	// ADDED BY PRASHANTH ON 29 JANUARY 2018
	private String olcBrnCode = "";
	private String olcLcType = "";
	private String olcLcYear = "";
	private String olcLcSl = "";
	private String olcLcCorrrefNo = "";
	private String olcLcPresancDate = "";
	private String olcLcPresancDaySl = "";
	private String olcLcSanctionDate = "";
	private String olcLcDate = "";
	private String olcCustNo = "";
	private String olcBenefCode = "";
	private String olcBenefName = "";
	private String olcBenefAddr1 = "";
	private String olcBenefCntryCode = "";
	private String olcLcIssBkCode = "";
	private String olcLcIssBrnCode = "";
	private String olcLcIssBrnname = "";
	private String olcLcIssBrnAdd = "";
	private String olcLcIssPlace = "";
	private String olcLcIssCntry = "";
	private String olcLcAdvThru = "";
	private String olcLcCurrCode = "";
	private String olcLcAmount = "";
	private boolean olcDevAllwd;
	private String olcDevAllwd_bol;
	private String olcPosDevAllwd = "";
	private String olcNegDevAllwd = "";
	private String olcDevAmount = "";
	private String olcDevBal = "";
	private String olcAmtQualfr = "";
	private String olcAddAmtCovered = "";
	private String olcPriceTerms = "";
	private String olcLastDateOfNeg = "";
	private String olcPlaceOfExpiry = "";
	private String olcLatestDateOfShpmnt = "";
	private String olcShipmentPeriod = "";
	private String olcPresentDetail = "";
	private boolean olcWithinValidateLc;
	private String olcWithinValidateLcval = "";
	private boolean olcUsanceInterest;
	private String olcUsanceInterestval = "";
	private String olcNofTenors = "";
	private boolean olcLcUnderContract;
	private String olcLcUnderContractval = "";
	// Changes P.Subramani-Chn-16/02/2008
	private String olctotalcurr = "";
	private String olctotalAmt = "";
	private String olcMarginCurr = "";
	private String olcMarginper = "";
	private String olcEolMarginper = "";
	private String olcMarginAmt = "";
	private String olcEolMarginAmt = "";
	private String olcCashMargin = "";
	private String olcEolCashMargin = "";
	private String olcMarginType = "";
	private String olcExcessOverLimit = "";
	private String olcLcTotalTenoramt = "";
	private String xmlerrmsg = "";
	private String olcTotLiabLcCurr = "";
	private String olcConvRateBaseCurr = "";
	private String olcTotLiabBaseCurr = "";
	private String olcConvRateLimCurr = "";
	private String olcTotLiabLimCurr = "";
	private String olcPaymntCurr = "";
	private String olcTotChrgsInPaymntCurr = "";
	private String olcCashMarginBal = "";
	private String olcReimbChrgsBy = "";
	private String olcPercRcPaidByApplcnt = "";
	private String olcNostroAlphaCode = "";
	private String olcAdvThruBk = "";
	private String olcAdvThruBrn = "";
	private String olcLcToBeCnfrmd = "";
	//Changes Sanjay1 22-07-2019 Begin
	//private String olcLcToBeCnfrmdByBk = "";
	//private String olcLcToBeCnfrmdByBrn = "";
	String[] reimb_cfm_add = null;
	private String LC_REIMB_CFM_TYPE = "";
	private String LC_REIMB_CFM_BIC_CODE = "";
	private String LC_REIMB_CFM_BRN_CODE = "";
	private String LC_CFM_REIMB_ROUTID = "";
	private String LC_CFM_REIMB_BNK_CODE = "";
	private String LC_CFM_REIMB_ADDRESS = "";
	private String LC_CFM_REIMB_CNTRY_CODE = "";
	//Changes Sanjay1 22-07-2019 End
	private String olcRestricted = "";
	private String olcRestrictedToUs = "";
	private String olcRestrictedBkCode = "";
	private String olcRestrictedBrnCode = "";
	private String olcCrAvlblBy = "";
	private String olcIrrevocable = "";
	private String olcPartShpmnt = "";
	private String olcTranShpmnt = "";
	private String olcLcTransfrbl = "";
	private String olcDftReqd = "";
	private String olcPercDftValue = "";
	private boolean olcDftToBeDrawnOn;
	private String olcDftToBeDrawnOnval = "";
	private String olcDftOnBk = "";
	private String olcDftOnBrn = "";
	private String olcSpecText1 = "";
	private String olcSpecText2 = "";
	private String olcSpecText3 = "";
	private String olcSpecText4 = "";
	private boolean olcPrimeRateClauseReq;
	private String olcPrimeRateClauseReqval = "";
	private String olcShpmntMode = "";
	private String olcLloydsClauseReq = "";
	private String olcMaxShipAge = "";
	private String olcShortFormOfBl = "";
	private String olcLashTransDocsAllwd = "";
	private String olcPercOfInsValueCvrd = "";
	private String olcInsPolicyNum = "";
	private String olcInsDate = "";
	private String olcInsCurr = "";
	private String olcInsAmt = "";
	private String olcPremiumCurr = "";
	private String olcPremiumAmt = "";
	private String olcInsCompany = "";
	private String olcInsCompanyName = "";
	private String olcCooIssBy = "";
	private String olcOtherCompAuth = "";
	private String olcIntermediaryTrade = "";
	private String olcInspTestCertReq = "";
	private String olcCertBy = "";
	private String olcImpUnder = "";
	private String olcImpPolicyDet = "";
	private String olcImpRef = "";
	private String olcCancelledOn = "";
	private String tranchgsChgsSl = "";
	private String trancratesRateSl = "";
	private String transtlmntInvNum = "";
	private String muserOption = "";
	private String mtxnStatus = "";
	private DTObject DTOResult;
	private String merrmsg = "";
	private String mxmlstr1 = "";
	private String prevLcdate = "";
	private String serial = "";
	private String refno = "";
	private String batchnum = "";

	private String chargesSl1 = "";
	private String conrateSl1 = "";
	private String invenNo1 = "";
	private String correfno = "";
	private String batnum = "";

	// S.Suresh Babu Add 30-06-2009
	private String usanceservtax = "";
	private String commitservtax = "";

	private TFMChargesDetails tfmchargesdetail;
	private TFMCRatesDetails tfmcratesdetail;
	private TranStlmntPostDetails translmnt;

	// local variables

	private String num_choice = "";
	private String auto_num = "";
	private String inover = "";
	private String intaccno = "";
	private String limitcurr = "";
	private String limitlineno = "";
	private String totalliabamt = "";// Muthukumaran chen 27-aprl-2010 added
	String benefadd[] = null;
	String addarr[] = null;
	String shiparray[] = null;
	String presentarray[] = null;
	String brnadd[] = null;
	int brnlen;
	int len;
	int len1;
	int len2;
	int len3;
	String brnadd1 = "";
	String brnadd2 = "";
	String brnadd3 = "";
	String brnadd4 = "";
	String brnadd5 = "";

	String address1 = "";
	String address2 = "";
	String address3 = "";
	String address4 = "";
	String address5 = "";

	String add1 = "";
	String add2 = "";
	String add3 = "";
	String add4 = "";

	String add11 = "";
	String add22 = "";
	String add33 = "";
	String add44 = "";

	String address11 = "";
	String address22 = "";
	String address33 = "";
	String address44 = "";

	String lastnumused = "";
	String Slflag = "";

	// voucher values
	private String branch;
	private String tranDate;
	private String batno;
	private String olclcliaaccno = "";
	private String olcintaccno = "";

	// Changes P.Subramani-Chn-21/02/2008
	private String basecurr = "";

	// Changes P.Subramani-Chn-10/04/2008 Beg
	private String olcusnchgs = "";
	private String olcusnchgstakendays = "";
	private String olccommchgs = "";
	private String olccommchgstakendays = "";
	// Changes P.Subramani-Chn-10/04/2008 End

	// Changes P.Subramani-Chn-19-06-2008 Beg
	private String usancechgcode = "";
	private String commchgcode = "";
	// Changes P.Subramani-Chn-19-06-2008 End

	// Changes P.Subramani-Chn-17/10/2008 Beg
	private String olctotalcashmargin = "";
	private double marginbal = 0;
	// Changes P.Subramani-Chn-17/10/2008 End
	// S.Suresh Babu Changes 24-09-2009
	private String conver_rate = "";

	// treasury changes by PRASHANTH chn 05-08-2017
	private String tsry_enabled = "0";

	// changes in eolc on 26-may-2018 start
	private String LC_FORM_OF_DOC_CREDIT = "";
	private String LC_REFERENCE_TO_PREADVICE = "";
	private String LC_APPLICABLE_RULES = "";
	private boolean LC_APPLICANT_REQ = false;
	private String LC_APPLICANT = "";
	private String LC_APPLICANT_TYPE = "";
	private String LC_APPLICANT_BRN_CODE = "";
	private String LC_APPLICANT_BIC_CODE = "";
	private String LC_APPLICANT_ROUTID = "";
	private String LC_APPLICANT_BNK_CODE = "";
	private String LC_APPLICANT_ADDRESS = "";
	private String LC_APPLICANT_CNTRY_CODE = "";
	private String LC_AVAILABLE_WITH_TYPE = "";
	private String LC_AVAILABLE_WITH_BRN_CODE = "";
	private String LC_AVAILABLE_WITH_CODE = "";
	private String LC_AVAILABLE_WITH_ROUTID = "";
	private String LC_AVAILABLE_WITH_BNK_CODE = "";
	private String LC_AVAILABLE_WITH_ADDRESS = "";
	private String LC_AVAILABLE_WITH_CNTRY = "";
	private String LC_AVAILABLE_WITH_CODETYP = "";
	private String LC_DRAFTS_AT = "";
	private boolean LC_DRAWEE_REQ = false;
	private String LC_DRAWEE_TYPE = "";
	private String LC_DRAWEE_BRN_CODE = "";
	private String LC_DRAWEE_BIC_CODE = "";
	private String LC_DRAWEE_ROUTID = "";
	private String LC_DRAWEE_BNK_CODE = "";
	private String LC_DRAWEE_ADDRESS = "";
	private String LC_DRAWEE_CNTRY_CODE = "";
	private String LC_MIXED_PAY_DETAILS = "";
	private String LC_DEFERRED_PAY_DETAILS = "";
	private String LC_PARTIAL_SHIPMENTS = "";
	private String LC_TRANSHIPMENT = "";
	private String LC_PLACE_OF_TAKING_IN_CHARGE = "";
	private String LC_PORT_OF_LOADING = "";
	private String LC_PORT_OF_DISCHARGE = "";
	private String LC_PLACE_OF_FINAL_DEST = "";
	private String LC_DESC_GOODS_SER1 = "";
	private String LC_DESC_GOODS_SER2 = "";
	private String LC_DESC_GOODS_SER3 = "";
	private String LC_DOC_REQ1 = "";
	private String LC_DOC_REQ2 = "";
	private String LC_DOC_REQ3 = "";
	private String LC_ADD_CONDITION1 = "";
	private String LC_ADD_CONDITION2 = "";
	private String LC_ADD_CONDITION3 = "";
	private String LC_CHARGES = "";
	private String LC_PER_PRESENTATION_DAY = "";
	private String LC_CONFIRMATION_INST = "";
	private boolean LC_REIMB_REQ = false;
	private String LC_REIMB_TYPE = "";
	private String LC_REIMB_BRN_CODE = "";
	private String LC_REIMB_BIC_CODE = "";
	private String LC_REIMB_ROUTID = "";
	private String LC_REIMB_BNK_CODE = "";
	private String LC_REIMB_ADDRESS = "";
	private String LC_REIMB_CNTRY_CODE = "";
	private String LC_INST_PAYING = "";
	private boolean LC_SECOND_ADV_REQ = false;
	private String LC_SECOND_ADV_TYPE = "";
	private String LC_SECOND_ADV_BRN_CODE = "";
	private String LC_SECOND_ADV_BIC_CODE = "";
	private String LC_SECOND_ADV_ROUTID = "";
	private String LC_SECOND_ADV_BNK_CODE = "";
	private String LC_SECOND_ADV_ADDRESS = "";
	private String LC_SECOND_ADV_CNTRYCODE = "";
	private String LC_SNDR_REC_INFO = "";
	private String LC_DOC_CREDIT_TYPE = "";
	private String LC_APPLICABLE_RULES_TYPE = "";
	private String LC_PARTSHPMNT_TYPE = "";
	private String LC_TRANSHIPMENT_TYPE = "";
	private String LC_SHIPMENT_PERIOD = "";
	private String LC_REC_BIC_CODE = "";

	String[] applicant_add = null;
	String[] availbl_with_add = null;
	String[] drawee_add = null;
	String[] reimb_add = null;
	String[] second_adv_add = null;
	String[] def_pay_details = null;
	String[] mixed_pay_details = null;
	String[] drafts = null;
	String[] chgs = null;
	String[] instr_paying = null;
	String[] send_to_rec = null;
	String a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12;
	String[] bank_addr = null;
	String[] shpmnt_prd = null;
	String[] desc_goods1 = null;
	String[] desc_goods2 = null;
	String[] desc_goods3 = null;
	String[] doc_req1 = null;
	String[] doc_req2 = null;
	String[] doc_req3 = null;
	String[] add_con1 = null;
	String[] add_con2 = null;
	String[] add_con3 = null;
	private String _brnAuth = "";
	private String temp_str = "";
	String[] _desp = null;
	double outstng_amt = 0.0;
	double pendng_amt = 0.0;
	// changes in eolc on 26-may-2018 end
	double amt_agnst_curr = 0.0;// ADDED ON 01/10/2018
	private String _roundoff = "";

	gridXML revallcpsGrid1 = new gridXML();
	DTObject revalDTO = new DTObject();
	DTObject inputDTO = new DTObject();

	QueryManager QueryManagerInstance = new QueryManager();
	eolcval eolcvalinstance = new eolcval();

	public String getOlcBrnCode() {
		return olcBrnCode;
	}

	public void setOlcBrnCode(String olcBrnCode) {
		this.olcBrnCode = olcBrnCode;
	}

	public String getOlcLcType() {
		return olcLcType;
	}

	public void setOlcLcType(String olcLcType) {
		this.olcLcType = olcLcType;
	}

	public String getOlcLcYear() {
		return olcLcYear;
	}

	public void setOlcLcYear(String olcLcYear) {
		this.olcLcYear = olcLcYear;
	}

	public String getOlcLcSl() {
		return olcLcSl;
	}

	public void setOlcLcSl(String olcLcSl) {
		this.olcLcSl = olcLcSl;
	}

	public String getOlcLcPresancDate() {
		return olcLcPresancDate;
	}

	public void setOlcLcPresancDate(String olcLcPresancDate) {
		this.olcLcPresancDate = olcLcPresancDate;
	}

	public String getOlcLcPresancDaySl() {
		return olcLcPresancDaySl;
	}

	public void setOlcLcPresancDaySl(String olcLcPresancDaySl) {
		this.olcLcPresancDaySl = olcLcPresancDaySl;
	}

	public String getOlcLcDate() {
		return olcLcDate;
	}

	public void setOlcLcDate(String olcLcDate) {
		this.olcLcDate = olcLcDate;
	}

	public String getOlcBenefCode() {
		return olcBenefCode;
	}

	public void setOlcBenefCode(String olcBenefCode) {
		this.olcBenefCode = olcBenefCode;
	}

	public String getOlcBenefName() {
		return olcBenefName;
	}

	public void setOlcBenefName(String olcBenefName) {
		this.olcBenefName = olcBenefName;
	}

	public String getOlcBenefAddr1() {
		return olcBenefAddr1;
	}

	public void setOlcBenefAddr1(String olcBenefAddr1) {
		this.olcBenefAddr1 = olcBenefAddr1;
	}

	public String getOlcBenefCntryCode() {
		return olcBenefCntryCode;
	}

	public void setOlcBenefCntryCode(String olcBenefCntryCode) {
		this.olcBenefCntryCode = olcBenefCntryCode;
	}

	public String getOlcLcIssBkCode() {
		return olcLcIssBkCode;
	}

	public void setOlcLcIssBkCode(String olcLcIssBkCode) {
		this.olcLcIssBkCode = olcLcIssBkCode;
	}

	public String getOlcLcIssBrnCode() {
		return olcLcIssBrnCode;
	}

	public void setOlcLcIssBrnCode(String olcLcIssBrnCode) {
		this.olcLcIssBrnCode = olcLcIssBrnCode;
	}

	public String getOlcLcIssPlace() {
		return olcLcIssPlace;
	}

	public void setOlcLcIssPlace(String olcLcIssPlace) {
		this.olcLcIssPlace = olcLcIssPlace;
	}

	public String getOlcLcIssCntry() {
		return olcLcIssCntry;
	}

	public void setOlcLcIssCntry(String olcLcIssCntry) {
		this.olcLcIssCntry = olcLcIssCntry;
	}

	public String getOlcLcCurrCode() {
		return olcLcCurrCode;
	}

	public void setOlcLcCurrCode(String olcLcCurrCode) {
		this.olcLcCurrCode = olcLcCurrCode;
	}

	public String getOlcLcAmount() {
		return olcLcAmount;
	}

	public void setOlcLcAmount(String olcLcAmount) {
		this.olcLcAmount = olcLcAmount;
	}

	public boolean isOlcDevAllwd() {
		return olcDevAllwd;
	}

	public void setOlcDevAllwd(boolean olcDevAllwd) {
		this.olcDevAllwd = olcDevAllwd;
		if (olcDevAllwd) {
			olcDevAllwd_bol = "1";
		} else {
			olcDevAllwd_bol = "0";
		}
	}

	public String getOlcPosDevAllwd() {
		return olcPosDevAllwd;
	}

	public void setOlcPosDevAllwd(String olcPosDevAllwd) {
		this.olcPosDevAllwd = olcPosDevAllwd;
	}

	public String getOlcNegDevAllwd() {
		return olcNegDevAllwd;
	}

	public void setOlcNegDevAllwd(String olcNegDevAllwd) {
		this.olcNegDevAllwd = olcNegDevAllwd;
	}

	public String getOlcDevAmount() {
		return olcDevAmount;
	}

	public void setOlcDevAmount(String olcDevAmount) {
		this.olcDevAmount = olcDevAmount;
	}

	public String getOlcDevBal() {
		return olcDevBal;
	}

	public void setOlcDevBal(String olcDevBal) {
		this.olcDevBal = olcDevBal;
	}

	public String getOlcPriceTerms() {
		return olcPriceTerms;
	}

	public void setOlcPriceTerms(String olcPriceTerms) {
		this.olcPriceTerms = olcPriceTerms;
	}

	public String getOlcLastDateOfNeg() {
		return olcLastDateOfNeg;
	}

	public void setOlcLastDateOfNeg(String olcLastDateOfNeg) {
		this.olcLastDateOfNeg = olcLastDateOfNeg;
	}

	public String getOlcPlaceOfExpiry() {
		return olcPlaceOfExpiry;
	}

	public void setOlcPlaceOfExpiry(String olcPlaceOfExpiry) {
		this.olcPlaceOfExpiry = olcPlaceOfExpiry;
	}

	public String getOlcLatestDateOfShpmnt() {
		return olcLatestDateOfShpmnt;
	}

	public void setOlcLatestDateOfShpmnt(String olcLatestDateOfShpmnt) {
		this.olcLatestDateOfShpmnt = olcLatestDateOfShpmnt;
	}

	public String getOlcNofTenors() {
		return olcNofTenors;
	}

	public void setOlcNofTenors(String olcNofTenors) {
		this.olcNofTenors = olcNofTenors;
	}

	public String getOlcTotLiabLcCurr() {
		return olcTotLiabLcCurr;
	}

	public void setOlcTotLiabLcCurr(String olcTotLiabLcCurr) {
		this.olcTotLiabLcCurr = olcTotLiabLcCurr;
	}

	public String getOlcConvRateBaseCurr() {
		return olcConvRateBaseCurr;
	}

	public void setOlcConvRateBaseCurr(String olcConvRateBaseCurr) {
		this.olcConvRateBaseCurr = olcConvRateBaseCurr;
	}

	public String getOlcTotLiabBaseCurr() {
		return olcTotLiabBaseCurr;
	}

	public void setOlcTotLiabBaseCurr(String olcTotLiabBaseCurr) {
		this.olcTotLiabBaseCurr = olcTotLiabBaseCurr;
	}

	public String getOlcConvRateLimCurr() {
		return olcConvRateLimCurr;
	}

	public void setOlcConvRateLimCurr(String olcConvRateLimCurr) {
		this.olcConvRateLimCurr = olcConvRateLimCurr;
	}

	public String getOlcTotLiabLimCurr() {
		return olcTotLiabLimCurr;
	}

	public void setOlcTotLiabLimCurr(String olcTotLiabLimCurr) {
		this.olcTotLiabLimCurr = olcTotLiabLimCurr;
	}

	public String getOlcPaymntCurr() {
		return olcPaymntCurr;
	}

	public void setOlcPaymntCurr(String olcPaymntCurr) {
		this.olcPaymntCurr = olcPaymntCurr;
	}

	public String getOlcTotChrgsInPaymntCurr() {
		return olcTotChrgsInPaymntCurr;
	}

	public void setOlcTotChrgsInPaymntCurr(String olcTotChrgsInPaymntCurr) {
		this.olcTotChrgsInPaymntCurr = olcTotChrgsInPaymntCurr;
	}

	public String getOlcCashMarginBal() {
		return olcCashMarginBal;
	}

	public void setOlcCashMarginBal(String olcCashMarginBal) {
		this.olcCashMarginBal = olcCashMarginBal;
	}

	public String getOlcPercRcPaidByApplcnt() {
		return olcPercRcPaidByApplcnt;
	}

	public void setOlcPercRcPaidByApplcnt(String olcPercRcPaidByApplcnt) {
		this.olcPercRcPaidByApplcnt = olcPercRcPaidByApplcnt;
	}

	public String getOlcNostroAlphaCode() {
		return olcNostroAlphaCode;
	}

	public void setOlcNostroAlphaCode(String olcNostroAlphaCode) {
		this.olcNostroAlphaCode = olcNostroAlphaCode;
	}

	public String getOlcAdvThruBk() {
		return olcAdvThruBk;
	}

	public void setOlcAdvThruBk(String olcAdvThruBk) {
		this.olcAdvThruBk = olcAdvThruBk;
	}

	public String getOlcAdvThruBrn() {
		return olcAdvThruBrn;
	}

	public void setOlcAdvThruBrn(String olcAdvThruBrn) {
		this.olcAdvThruBrn = olcAdvThruBrn;
	}

	public String getOlcRestrictedBkCode() {
		return olcRestrictedBkCode;
	}

	public void setOlcRestrictedBkCode(String olcRestrictedBkCode) {
		this.olcRestrictedBkCode = olcRestrictedBkCode;
	}

	public String getOlcRestrictedBrnCode() {
		return olcRestrictedBrnCode;
	}

	public void setOlcRestrictedBrnCode(String olcRestrictedBrnCode) {
		this.olcRestrictedBrnCode = olcRestrictedBrnCode;
	}

	public void setOlcPercDftValue(String olcPercDftValue) {
		this.olcPercDftValue = olcPercDftValue;
	}

	public String getOlcDftOnBk() {
		return olcDftOnBk;
	}

	public void setOlcDftOnBk(String olcDftOnBk) {
		this.olcDftOnBk = olcDftOnBk;
	}

	public String getOlcDftOnBrn() {
		return olcDftOnBrn;
	}

	public void setOlcDftOnBrn(String olcDftOnBrn) {
		this.olcDftOnBrn = olcDftOnBrn;
	}

	public String getOlcSpecText1() {
		return olcSpecText1;
	}

	public void setOlcSpecText1(String olcSpecText1) {
		this.olcSpecText1 = olcSpecText1;
	}

	public String getOlcSpecText2() {
		return olcSpecText2;
	}

	public void setOlcSpecText2(String olcSpecText2) {
		this.olcSpecText2 = olcSpecText2;
	}

	public String getOlcSpecText3() {
		return olcSpecText3;
	}

	public void setOlcSpecText3(String olcSpecText3) {
		this.olcSpecText3 = olcSpecText3;
	}

	public String getOlcSpecText4() {
		return olcSpecText4;
	}

	public void setOlcSpecText4(String olcSpecText4) {
		this.olcSpecText4 = olcSpecText4;
	}

	public String getOlcCancelledOn() {
		return olcCancelledOn;
	}

	public void setOlcCancelledOn(String olcCancelledOn) {
		this.olcCancelledOn = olcCancelledOn;
	}

	public String getTranchgsChgsSl() {
		return tranchgsChgsSl;
	}

	public void setTranchgsChgsSl(String tranchgsChgsSl) {
		this.tranchgsChgsSl = tranchgsChgsSl;
	}

	public String getTrancratesRateSl() {
		return trancratesRateSl;
	}

	public void setTrancratesRateSl(String trancratesRateSl) {
		this.trancratesRateSl = trancratesRateSl;
	}

	public String getTranstlmntInvNum() {
		return transtlmntInvNum;
	}

	public void setTranstlmntInvNum(String transtlmntInvNum) {
		this.transtlmntInvNum = transtlmntInvNum;
	}

	public String getMtxnStatus() {
		return mtxnStatus;
	}

	public String getMerrmsg() {
		return merrmsg;
	}

	public void setMerrmsg(String merrmsg) {
		this.merrmsg = merrmsg;
	}

	public void setMtxnStatus(String mtxnStatus) {
		this.mtxnStatus = mtxnStatus;
	}

	public String getMuserOption() {
		return muserOption;
	}

	public void setMuserOption(String muserOption) {
		this.muserOption = muserOption;
	}

	public String getSerial() {
		return serial;
	}

	public void setSerial(String serial) {
		this.serial = serial;
	}

	// 1.0 Optimization Changes 08-Feb-2008 - Beg
	public void setreturnvalue() {
		sethiddenidValues("txtintaccno#xmlerrmsg#mxmlstr1#txtchargecurr#txtchargeamt#txtchargesl#txtconratsl#txtintno#txtprevlcdate#txtserial#txtrefnoo#txtchargessl1#txtconratesl1#txtinvenno1#txtusnchgstakendays#txtcommchgstakendays", getOlcintaccno() + "#" + getXmlerrmsg() + "#" + getMxmlstr1() + "#" + getOlcPaymntCurr() + "#" + getOlcTotChrgsInPaymntCurr() + "#" + getTranchgsChgsSl() + "#" + getTrancratesRateSl() + "#" + getTranstlmntInvNum() + "#" + getPrevLcdate() + "#" + getSerial() + "#" + getRefno() + "#" + getChargesSl1() + "#" + getConrateSl1() + "#" + getInvenNo1() + "#" + getOlcusnchgstakendays() + "#" + getOlccommchgstakendays());
		setV_view_component_Id("txnstatus#errmsg##txtbatchnum");
		setcommonvalues(getMtxnStatus(), getMerrmsg(), "", getBatnum());
	}

	// 1.0 Optimization Changes 08-Feb-2008 - End

	public String PersistData() {
		// Changes P.Subramani-Chn-21/02/2008
		basecurr = getM_BCurrCode();
		if (RevalidateOLC() == true) {
			CommonDelegate CDelagate = null;
			DTObject inputDTO = new DTObject();
			inputDTO.clearMap();
			inputDTO.setValue("TSRY_INTF_ENABLED", tsry_enabled);
			inputDTO.setValue("UserOption", muserOption);
			inputDTO.setValue("OLC_BRN_CODE", olcBrnCode);
			inputDTO.setValue("OLC_LC_TYPE", olcLcType);
			inputDTO.setValue("OLC_LC_YEAR", olcLcYear);
			inputDTO.setValue("SL_FLAG", Slflag);
			if (Slflag.equalsIgnoreCase("YES")) {
				inputDTO.setValue("OLC_LC_SL", lastnumused);
				inputDTO.setValue("OLC_CORR_REF_NUM", correfno);
			} else if (Slflag.equalsIgnoreCase("NO")) {
				inputDTO.setValue("OLC_LC_SL", olcLcSl);
				inputDTO.setValue("OLC_CORR_REF_NUM", correfno);
			} else {
				inputDTO.setValue("OLC_LC_SL", olcLcSl);
				inputDTO.setValue("TRANCHGS_CHGS_SL1", chargesSl1);
				inputDTO.setValue("TRANCRATES_RATE_SL1", conrateSl1);
				inputDTO.setValue("TRANSTLMNT_INV_NUM1", invenNo1);
				inputDTO.setValue("OLC_CORR_REF_NUM", olcLcCorrrefNo);
			}

			inputDTO.setValue("OLC_LC_PRESANC_DATE", olcLcPresancDate);
			inputDTO.setValue("OLC_LC_PRESANC_DAY_SL", olcLcPresancDaySl);
			inputDTO.setValue("OLC_LC_DATE", olcLcDate);
			inputDTO.setValue("PREV_LC_DATE", prevLcdate);
			inputDTO.setValue("CURRDATE", getM_CurrBusDate());
			inputDTO.setValue("BASE_CURR", getM_BCurrCode());
			if (olcCustNo.equalsIgnoreCase("")) {
				olcCustNo = "0";
			}
			inputDTO.setValue("OLC_CUST_NUM", olcCustNo);
			inputDTO.setValue("OLC_BENEF_CODE", olcBenefCode);
			inputDTO.setValue("OLC_BENEF_NAME", olcBenefName);
			inputDTO.setValue("OLC_BENEF_ADDR1", address1);
			inputDTO.setValue("OLC_BENEF_ADDR2", address2);
			inputDTO.setValue("OLC_BENEF_ADDR3", address3);
			inputDTO.setValue("OLC_BENEF_ADDR4", address4);
			inputDTO.setValue("OLC_BENEF_ADDR5", address5);
			inputDTO.setValue("OLC_BENEF_CNTRY_CODE", olcBenefCntryCode);
			inputDTO.setValue("OLC_LC_ISS_BK_CODE", olcLcIssBkCode);
			inputDTO.setValue("OLC_LC_ISS_BRN_CODE", olcLcIssBrnCode);

			inputDTO.setValue("OLC_LC_ISS_BRN_NAME", olcLcIssBrnname);
			inputDTO.setValue("OLC_LC_ISS_BRN_ADD1", brnadd1);
			inputDTO.setValue("OLC_LC_ISS_BRN_ADD2", brnadd2);
			inputDTO.setValue("OLC_LC_ISS_BRN_ADD3", brnadd3);
			inputDTO.setValue("OLC_LC_ISS_BRN_ADD4", brnadd4);
			inputDTO.setValue("OLC_LC_ISS_BRN_ADD5", brnadd5);

			inputDTO.setValue("OLC_LC_ISS_PLACE", olcLcIssPlace);
			inputDTO.setValue("OLC_LC_ISS_CNTRY", olcLcIssCntry);
			inputDTO.setValue("OLC_LC_ADV_THRU", olcLcAdvThru);
			inputDTO.setValue("OLC_LC_CURR_CODE", olcLcCurrCode);
			if (olcLcAmount.equalsIgnoreCase("")) {
				olcLcAmount = "0";
			}
			inputDTO.setValue("OLC_LC_AMOUNT", olcLcAmount);
			inputDTO.setValue("OLC_LC_BALANCE", olcLcAmount);
			inputDTO.setValue("OLC_DEV_ALLWD", String.valueOf(olcDevAllwd_bol));
			if (olcPosDevAllwd.equalsIgnoreCase("")) {
				olcPosDevAllwd = "0";
			}
			inputDTO.setValue("OLC_POS_DEV_ALLWD", olcPosDevAllwd);
			if (olcNegDevAllwd.equalsIgnoreCase("")) {
				olcNegDevAllwd = "0";
			}
			inputDTO.setValue("OLC_NEG_DEV_ALLWD", olcNegDevAllwd);
			if (olcDevAmount.equalsIgnoreCase("")) {
				olcDevAmount = "0";
			}
			inputDTO.setValue("OLC_DEV_AMOUNT", olcDevAmount);
			inputDTO.setValue("OLC_DEV_BAL", olcDevAmount);
			inputDTO.setValue("OLC_AMT_QUALFR", olcAmtQualfr);
			inputDTO.setValue("OLC_ADD_AMT_COV1", add1);
			inputDTO.setValue("OLC_ADD_AMT_COV2", add2);
			inputDTO.setValue("OLC_ADD_AMT_COV3", add3);
			inputDTO.setValue("OLC_ADD_AMT_COV4", add4);
			inputDTO.setValue("OLC_PRICE_TERMS", olcPriceTerms);
			if (olcLastDateOfNeg.equalsIgnoreCase("")) {
				olcLastDateOfNeg = null;
			}
			inputDTO.setValue("OLC_LAST_DATE_OF_NEG", olcLastDateOfNeg);
			inputDTO.setValue("OLC_PLACE_OF_EXPIRY", olcPlaceOfExpiry);
			if (olcLatestDateOfShpmnt.equalsIgnoreCase("")) {
				olcLatestDateOfShpmnt = null;
			}
			inputDTO.setValue("OLC_LATEST_DATE_OF_SHPMNT", olcLatestDateOfShpmnt);

			inputDTO.setValue("OLC_SHIP_TEXT1", add11);
			inputDTO.setValue("OLC_SHIP_TEXT2", add22);
			inputDTO.setValue("OLC_SHIP_TEXT3", add33);
			inputDTO.setValue("OLC_SHIP_TEXT4", add44);

			inputDTO.setValue("OLC_PRE_DTL1", address11);
			inputDTO.setValue("OLC_PRE_DTL2", address22);
			inputDTO.setValue("OLC_PRE_DTL3", address33);
			inputDTO.setValue("OLC_PRE_DTL4", address44);

			try {

				inputDTO.addColumn("OLCTENORS", 0, "OLCT_TENOR_TYPE");
				inputDTO.addColumn("OLCTENORS", 1, "OLCT_TENOR_AMT");
				inputDTO.addColumn("OLCTENORS", 2, "OLCT_USANCE_PERD");
				inputDTO.addColumn("OLCTENORS", 3, "OLCT_USANCE_FROM");
				inputDTO.addColumn("OLCTENORS", 4, "OLCT_OTHER_DATE_DESC");
				inputDTO.addColumn("OLCTENORS", 5, "OLCT_OTHER_DATE_START_FROM");
				inputDTO.addColumn("OLCTENORS", 6, "OLCT_USANCE_INT_RATE");
				inputDTO.addColumn("OLCTENORS", 7, "OLCT_USANCE_INT_AMT");
				inputDTO.addColumn("OLCTENORS", 8, "OLCT_DOC_DELIVERY");
				// Changes P.Subramani-Chn23/08/2008 Beg
				inputDTO.addColumn("OLCTENORS", 9, "OLCT_USN_CHRG_TAKEN_DAYS");
				// Changes P.Subramani-Chn23/08/2008 End
				inputDTO.setXMLDTDObject("OLCTENORS", mxmlstr1);
			}

			catch (Exception e1) {
				e1.printStackTrace();
			}

			inputDTO.setValue("OLC_WITHIN_VALIDATE_LC", olcWithinValidateLcval);
			inputDTO.setValue("OLC_LC_UI_BORNE_BY_APPLCNT", olcUsanceInterestval);
			inputDTO.setValue("OLC_NOF_TENORS", olcNofTenors);
			inputDTO.setValue("OLC_TOTALAMT_CURRCODE", olctotalcurr);
			inputDTO.setValue("OLC_LC_UNDER_CONTRACT", olcLcUnderContractval);
			if (olctotalAmt.equalsIgnoreCase("")) {
				olctotalAmt = "0";
			}
			inputDTO.setValue("OLC_TOT_LIAB_LC_CURR", olctotalAmt);

			// Muthukumaran chen 27-aprl-2010 added BEG
			if (totalliabamt.equalsIgnoreCase("")) {
				totalliabamt = "0";
			}
			inputDTO.setValue("OLC_TOT_LIAB_LC_CURR", totalliabamt);
			// Muthukumaran chen 27-aprl-2010 added END

			// olcConvRateBaseCurr="0";
			if (olcTotLiabBaseCurr.equalsIgnoreCase("")) {
				olcTotLiabBaseCurr = "0";
			}
			// inputDTO.setValue("OLC_CONV_RATE_BASE_CURR",olcConvRateBaseCurr);
			if (olcTotLiabBaseCurr.equalsIgnoreCase("")) {
				olcTotLiabBaseCurr = "0";
			}
			inputDTO.setValue("OLC_TOT_LIAB_BASE_CURR", olcTotLiabBaseCurr);
			// S.Suresh Babu Changes 24-09-2009
			if (conver_rate.equalsIgnoreCase(""))
				conver_rate = "0";
			inputDTO.setValue("OLC_CONV_RATE_BASE_CURR", conver_rate);
			if (olcConvRateLimCurr.equalsIgnoreCase("")) {
				olcConvRateLimCurr = "0";
			}
			inputDTO.setValue("OLC_CONV_RATE_LIM_CURR", olcConvRateLimCurr);
			if (olcTotLiabLimCurr.equalsIgnoreCase("")) {
				olcTotLiabLimCurr = "0";
			}
			inputDTO.setValue("OLC_TOT_LIAB_LIM_CURR", olcTotLiabLimCurr);
			inputDTO.setValue("OLC_PAYMNT_CURR", olcPaymntCurr);
			if (olcTotChrgsInPaymntCurr.equalsIgnoreCase("")) {
				olcTotChrgsInPaymntCurr = "0";
			}
			inputDTO.setValue("OLC_TOT_CHRGS_IN_PAYMNT_CURR", olcTotChrgsInPaymntCurr);
			inputDTO.setValue("OLC_CASH_MARGIN_BAL", olcCashMarginBal);
			olcReimbChrgsBy = " ";
			inputDTO.setValue("OLC_REIMB_CHRGS_BY", olcReimbChrgsBy);
			olcPercRcPaidByApplcnt = "0";
			inputDTO.setValue("OLC_PERC_RC_PAID_BY_APPLCNT", olcPercRcPaidByApplcnt);
			olcNostroAlphaCode = " ";
			inputDTO.setValue("OLC_NOSTRO_ALPHA_CODE", olcNostroAlphaCode);
			olcAdvThruBk = " ";
			inputDTO.setValue("OLC_ADV_THRU_BK", olcAdvThruBk);
			olcAdvThruBrn = " ";
			inputDTO.setValue("OLC_ADV_THRU_BRN", olcAdvThruBrn);
			olcLcToBeCnfrmd = " ";
			// ADDED BY PRASHANTH ON 29 JANUARY 2018
			if (LC_CONFIRMATION_INST.equals("1")) {
				inputDTO.setValue("OLC_LC_TO_BE_CNFRMD", "3");
			} else if (LC_CONFIRMATION_INST.equals("2")) {
				inputDTO.setValue("OLC_LC_TO_BE_CNFRMD", "2");
			} else if (LC_CONFIRMATION_INST.equals("3")) {
				inputDTO.setValue("OLC_LC_TO_BE_CNFRMD", "1");
			}
			
			//Changes Sanjay1 22-07-2019 Begin
			// olcLcToBeCnfrmdByBk = " ";// commentted BY PRASHANTH ON 29 JANUARY 2018
			/*inputDTO.setValue("OLC_LC_TO_BE_CNFRMD_BY_BK", olcLcToBeCnfrmdByBk);
			// olcLcToBeCnfrmdByBrn = " ";// commentted BY PRASHANTH ON 29 JANUARY 2018
			if(olcLcToBeCnfrmdByBrn.equals("")){
				inputDTO.setValue("OLC_LC_TO_BE_CNFRMD_BY_BRN", "0");
			}
			else
			inputDTO.setValue("OLC_LC_TO_BE_CNFRMD_BY_BRN", olcLcToBeCnfrmdByBrn);*/
			//Changes Sanjay1 22-07-2019 End
			
			// ADDED BY PRASHANTH ON 29 JANUARY 2018
			olcRestricted = " ";
			olcRestricted = " ";
			olcRestrictedToUs = " ";
			olcRestrictedBkCode = " ";
			olcRestrictedBrnCode = " ";
			olcCrAvlblBy = " ";
			olcIrrevocable = " ";
			olcPartShpmnt = " ";
			olcLcTransfrbl = " ";
			olcDftReqd = " ";
			olcPercDftValue = "0";
			olcMaxShipAge = "0";
			olcPercOfInsValueCvrd = "0";
			olcInsDate = null;
			olcInsAmt = "0";
			olcPremiumAmt = "0";
			olcIntermediaryTrade = "0";
			olcInspTestCertReq = "0";
			olcCancelledOn = null;
			olcDftOnBk = " ";
			olcDftOnBrn = " ";
			olcSpecText1 = " ";
			olcSpecText2 = " ";
			olcSpecText3 = " ";
			olcSpecText4 = " ";
			olcShpmntMode = " ";
			olcLloydsClauseReq = " ";
			olcShortFormOfBl = " ";
			olcLashTransDocsAllwd = " ";
			olcInsPolicyNum = " ";
			olcInsCurr = " ";
			olcPremiumCurr = " ";
			olcInsCompany = " ";
			olcInsCompanyName = " ";
			olcCooIssBy = " ";
			olcOtherCompAuth = " ";
			olcCertBy = " ";
			olcImpUnder = " ";
			olcImpPolicyDet = " ";
			olcImpRef = " ";

			inputDTO.setValue("OLC_RESTRICTED", olcRestricted);
			inputDTO.setValue("OLC_RESTRICTED_TO_US", olcRestrictedToUs);
			inputDTO.setValue("OLC_RESTRICTED_BK_CODE", olcRestrictedBkCode);
			inputDTO.setValue("OLC_RESTRICTED_BRN_CODE", olcRestrictedBrnCode);

			// ADDED BY PRASHANTH ON 29 JANUARY 2018
			inputDTO.setValue("OLC_CR_AVLBL_BY", LC_AVAILABLE_WITH_CODETYP);

			if (LC_PARTIAL_SHIPMENTS.trim().equalsIgnoreCase("1")) {
				inputDTO.setValue("OLC_PART_SHPMNT", "1");
			} else if (LC_PARTIAL_SHIPMENTS.trim().equalsIgnoreCase("2")) {
				inputDTO.setValue("OLC_PART_SHPMNT", "");
			} else if (LC_PARTIAL_SHIPMENTS.trim().equalsIgnoreCase("3")) {
				inputDTO.setValue("OLC_PART_SHPMNT", "0");
			} else {
				inputDTO.setValue("OLC_PART_SHPMNT", "");
			}

			if (LC_TRANSHIPMENT.trim().equalsIgnoreCase("1")) {
				inputDTO.setValue("OLC_TRAN_SHPMNT", "1");
			} else if (LC_TRANSHIPMENT.trim().equalsIgnoreCase("2")) {
				inputDTO.setValue("OLC_TRAN_SHPMNT", "");
			} else if (LC_TRANSHIPMENT.trim().equalsIgnoreCase("3")) {
				inputDTO.setValue("OLC_TRAN_SHPMNT", "0");
			} else {
				inputDTO.setValue("OLC_TRAN_SHPMNT", "");
			}

			// ADDED BY PRASHANTH ON 29 JANUARY 2018
			if (LC_FORM_OF_DOC_CREDIT.trim().equalsIgnoreCase("1")) {
				inputDTO.setValue("OLC_IRREVOCABLE", "1");
				inputDTO.setValue("OLC_LC_TRANSFRBL", "0");
			} else if (LC_FORM_OF_DOC_CREDIT.trim().equalsIgnoreCase("2")) {
				inputDTO.setValue("OLC_IRREVOCABLE", "0");
				inputDTO.setValue("OLC_LC_TRANSFRBL", "0");
			} else if (LC_FORM_OF_DOC_CREDIT.trim().equalsIgnoreCase("3")) {
				inputDTO.setValue("OLC_IRREVOCABLE", "1");
				inputDTO.setValue("OLC_LC_TRANSFRBL", "1");
			} else if (LC_FORM_OF_DOC_CREDIT.trim().equalsIgnoreCase("4")) {
				inputDTO.setValue("OLC_IRREVOCABLE", "0");
				inputDTO.setValue("OLC_LC_TRANSFRBL", "1");
			} else if (LC_FORM_OF_DOC_CREDIT.trim().equalsIgnoreCase("5")) {
				inputDTO.setValue("OLC_IRREVOCABLE", "1");
				inputDTO.setValue("OLC_LC_TRANSFRBL", "");
			} else if (LC_FORM_OF_DOC_CREDIT.trim().equalsIgnoreCase("6")) {
				inputDTO.setValue("OLC_IRREVOCABLE", "0");
				inputDTO.setValue("OLC_LC_TRANSFRBL", "");
			} else if (LC_FORM_OF_DOC_CREDIT.trim().equalsIgnoreCase("7")) {
				inputDTO.setValue("OLC_IRREVOCABLE", "1");
				inputDTO.setValue("OLC_LC_TRANSFRBL", "1");
			} else {
				inputDTO.setValue("OLC_IRREVOCABLE", "");
				inputDTO.setValue("OLC_LC_TRANSFRBL", "");
			}

			if (!LC_DRAFTS_AT.equals("")) {
				inputDTO.setValue("OLC_DFT_REQD", "1");
			} else {
				inputDTO.setValue("OLC_DFT_REQD", "0");
			}
			// ADDED BY PRASHANTH ON 29 JANUARY 2018

			inputDTO.setValue("OLC_PERC_DFT_VALUE", olcPercDftValue);

			inputDTO.setValue("OLC_DFT_TO_BE_DRAWN_ON", olcDftToBeDrawnOnval);
			inputDTO.setValue("OLC_DFT_ON_BK", olcDftOnBk);
			inputDTO.setValue("OLC_DFT_ON_BRN", olcDftOnBrn);
			inputDTO.setValue("OLC_SPEC_TEXT1", olcSpecText1);
			inputDTO.setValue("OLC_SPEC_TEXT2", olcSpecText2);
			inputDTO.setValue("OLC_SPEC_TEXT3", olcSpecText3);
			inputDTO.setValue("OLC_SPEC_TEXT4", olcSpecText4);
			inputDTO.setValue("OLC_PRIME_RATE_CLAUSE_REQ", olcPrimeRateClauseReqval);
			inputDTO.setValue("OLC_SHPMNT_MODE", olcShpmntMode);
			inputDTO.setValue("OLC_LLOYDS_CLAUSE_REQ", olcLloydsClauseReq);
			inputDTO.setValue("OLC_MAX_SHIP_AGE", olcMaxShipAge);
			inputDTO.setValue("OLC_SHORT_FORM_OF_BL", olcShortFormOfBl);
			inputDTO.setValue("OLC_LASH_TRANS_DOCS_ALLWD", olcLashTransDocsAllwd);
			inputDTO.setValue("OLC_PERC_OF_INS_VALUE_CVRD", olcPercOfInsValueCvrd);
			inputDTO.setValue("OLC_INS_POLICY_NUM", olcInsPolicyNum);
			inputDTO.setValue("OLC_INS_DATE", olcInsDate);
			inputDTO.setValue("OLC_INS_CURR", olcInsCurr);
			inputDTO.setValue("OLC_INS_AMT", olcInsAmt);
			inputDTO.setValue("OLC_PREMIUM_CURR", olcPremiumCurr);
			inputDTO.setValue("OLC_PREMIUM_AMT", olcPremiumAmt);
			inputDTO.setValue("OLC_INS_COMPANY", olcInsCompany);
			inputDTO.setValue("OLC_INS_COMPANY_NAME", olcInsCompanyName);
			inputDTO.setValue("OLC_COO_ISS_BY", olcCooIssBy);
			inputDTO.setValue("OLC_OTHER_COMP_AUTH", olcOtherCompAuth);
			inputDTO.setValue("OLC_INTERMEDIARY_TRADE", olcIntermediaryTrade);
			inputDTO.setValue("OLC_INSP_TEST_CERT_REQ", olcInspTestCertReq);
			inputDTO.setValue("OLC_CERT_BY", olcCertBy);
			inputDTO.setValue("OLC_IMP_UNDER", olcImpUnder);
			inputDTO.setValue("OLC_IMP_POLICY_DET", olcImpPolicyDet);
			inputDTO.setValue("OLC_IMP_REF", olcImpRef);
			inputDTO.setValue("OLC_CANCELLED_ON", olcCancelledOn);
			if (tfmchargesdetail != null) {
				inputDTO = tfmchargesdetail.getDTObject(inputDTO);
			}
			// Changes P.Subramani-Chn-22/02/2008
			if (!(olcLcCurrCode.equalsIgnoreCase(basecurr))) {
				if (tfmcratesdetail != null) {
					inputDTO = tfmcratesdetail.getDTObject(inputDTO);
				}
			}
			// Changes P.Subramani-Chn-22/02/2008
			if (!(tfmchargesdetail.getTRANCHGS_TOTAL_CHGS().equalsIgnoreCase("0.00")) || (tfmchargesdetail.getTRANCHGS_TOTAL_CHGS().equalsIgnoreCase("0"))) {
				if (translmnt != null) {
					inputDTO = translmnt.getDTObject(inputDTO);
				}
			}
			inputDTO.setValue("TRANCHGS_CHGS_SL", tranchgsChgsSl);
			inputDTO.setValue("TRANCRATES_RATE_SL", trancratesRateSl);
			inputDTO.setValue("TRANSTLMNT_INV_NUM", transtlmntInvNum);

			// voucher values
			if (muserOption.equalsIgnoreCase("M")) {
				inputDTO.setValue("POST_TRAN_BRN", branch);
			} else {
				inputDTO.setValue("POST_TRAN_BRN", "0");
			}
			if (muserOption.equalsIgnoreCase("M")) {
				inputDTO.setValue("POST_TRAN_DATE", tranDate);
			} else {
				inputDTO.setValue("POST_TRAN_DATE", getM_CurrBusDate());
			}
			if (muserOption.equalsIgnoreCase("M")) {
				inputDTO.setValue("POST_TRAN_BATCH_NUM", batno);
			} else {
				inputDTO.setValue("POST_TRAN_BATCH_NUM", "0");
			}
			inputDTO.setValue("LC_LIA_ACC_NO", olclcliaaccno);

			inputDTO.setValue("MAGGIN_CURR", olcMarginCurr);
			if (olcMarginper.equalsIgnoreCase("")) {
				olcMarginper = "0";
				inputDTO.setValue("MAGGIN_PER", olcMarginper);
			} else {
				inputDTO.setValue("MAGGIN_PER", olcMarginper);
			}
			if (olcEolMarginper.equalsIgnoreCase("")) {
				olcEolMarginper = "0";
				inputDTO.setValue("EOL_MAGGIN_PER", olcEolMarginper);
			} else {
				inputDTO.setValue("EOL_MAGGIN_PER", olcEolMarginper);
			}
			if (olcMarginAmt.equalsIgnoreCase("")) {
				olcMarginAmt = "0";
				inputDTO.setValue("MAGGIN_AMT", olcMarginAmt);
			} else {
				inputDTO.setValue("MAGGIN_AMT", olcMarginAmt);
			}
			if (olcEolMarginAmt.equalsIgnoreCase("")) {
				olcEolMarginAmt = "0";
				inputDTO.setValue("EOL_MAGGIN_AMT", olcEolMarginAmt);
			} else {
				inputDTO.setValue("EOL_MAGGIN_AMT", olcEolMarginAmt);
			}
			if (olcCashMargin.equalsIgnoreCase("")) {
				olcCashMargin = "0";
				inputDTO.setValue("CASH_MAGGIN", olcCashMargin);
			} else {
				inputDTO.setValue("CASH_MAGGIN", olcCashMargin);
			}
			if (olcEolCashMargin.equalsIgnoreCase("")) {
				olcEolCashMargin = "0";
				inputDTO.setValue("EOL_CASH_MAGGIN", olcEolCashMargin);

			} else {
				inputDTO.setValue("EOL_CASH_MAGGIN", olcEolCashMargin);
			}
			inputDTO.setValue("MAGGIN_TYPE", olcMarginType);
			if (olcExcessOverLimit.equalsIgnoreCase("")) {
				inputDTO.setValue("EXCESS_LIMI", "0");
			} else {
				inputDTO.setValue("EXCESS_LIMI", olcExcessOverLimit);
			}
			inputDTO.setValue("INT_ACC_NO", olcintaccno);

			// Changes P.Subramani-Chn-10/04/2008 Beg
			inputDTO.setValue("USANCE_CHARGES", olcusnchgs);

			// Changes P.Subramani-Chn-23/08/2008 BEg
			if (olcusnchgstakendays.equalsIgnoreCase("")) {
				inputDTO.setValue("OLC_USN_CHG_TAKEN_DAYS", "0");
			} else {
				inputDTO.setValue("OLC_USN_CHG_TAKEN_DAYS", olcusnchgstakendays);
			}
			// Changes P.Subramani-Chn-23/08/2008 End
			inputDTO.setValue("COMMITMENT_CHARGES", olccommchgs);
			// Changes P.Subramani-Chn-23/08/2008 Beg
			if (olccommchgstakendays.equalsIgnoreCase("")) {
				inputDTO.setValue("OLC_COMMIT_CHG_TAKEN_DAYS", "0");
			} else {
				inputDTO.setValue("OLC_COMMIT_CHG_TAKEN_DAYS", olccommchgstakendays);
			}
			// Changes P.Subramani-Chn-23/08/2008 End

			// Changes P.Subramani-Chn-10/04/2008 End

			// Changes P.Subramani-Chn-19-06-2008 Beg
			inputDTO.setValue("TRCHG_USANCE_CHGCD", usancechgcode);
			inputDTO.setValue("TRCHG_COMMITMNT_CHGCD", commchgcode);
			// Changes P.Subramani-Chn-19-06-2008 End
			// S.Suresh Babu Add 30-06-2009

			// Muthukumaran chen 27-04-2010 changes beg
			// inputDTO.setValue("OLC_COMMIT_SERV_TAX",commitservtax);
			// inputDTO.setValue("OLC_USANCE_SERV_TAX",usanceservtax);
			if (usanceservtax.equalsIgnoreCase("")) {
				inputDTO.setValue("OLC_USANCE_SERV_TAX", "0");
			} else {
				inputDTO.setValue("OLC_USANCE_SERV_TAX", usanceservtax);
			}
			if (commitservtax.equalsIgnoreCase("")) {
				inputDTO.setValue("OLC_COMMIT_SERV_TAX", "0");
			} else {
				inputDTO.setValue("OLC_COMMIT_SERV_TAX", commitservtax);
			}
			// Muthukumaran chen 27-04-2010 end

			// Changes P.Subramani-Chn-17/10/2008 Beg
			inputDTO.setValue("OLC_MARGIN_CURR", olcMarginCurr);
			inputDTO.setValue("OLC_MARGIN_AMT", olcCashMarginBal);
			inputDTO.setValue("OLC_CASH_MAR_AMT", olctotalcashmargin);
			marginbal = Double.parseDouble(olcCashMarginBal) - Double.parseDouble(olctotalcashmargin);
			inputDTO.setValue("OLC_MARGIN_BAL", String.valueOf(marginbal));
			inputDTO.setValue("OLC_CASH_MAR_BAL", olctotalcashmargin);
			inputDTO.setValue("OLC_CASH_MAR_REC", "0");
			inputDTO.setValue("OLC_DEP_MAR_REC", "0");
			inputDTO.setValue("OLC_OTH_SEC_REC", "0");
			// Changes P.Subramani-Chn-17/10/2008 End

			// Changes M.S.JAYANTHI-Chn-11/11/2009 BEG
			inputDTO.setValue("TNOMEN_INLAND_OVERSEAS", inover);
			// Changes M.S.JAYANTHI-Chn-11/11/2009 end

			// changes in eolc on 26-May-2018 start
			if (olcLcType.trim().equals("OLC")) {
				// Form of Credit
				if (LC_FORM_OF_DOC_CREDIT.trim().equalsIgnoreCase(""))
					inputDTO.setValue("LC_FORM_OF_DOC_CREDIT", "0");
				else
					inputDTO.setValue("LC_FORM_OF_DOC_CREDIT", LC_FORM_OF_DOC_CREDIT);

				if (LC_REFERENCE_TO_PREADVICE.trim().equals(""))
					inputDTO.setValue("LC_REFERENCE_TO_PREADVICE", "");
				else
					inputDTO.setValue("LC_REFERENCE_TO_PREADVICE", LC_REFERENCE_TO_PREADVICE);

				// Applicable Rules
				if (LC_APPLICABLE_RULES.trim().equalsIgnoreCase(""))
					inputDTO.setValue("LC_APPLICABLE_RULES", "0");
				else
					inputDTO.setValue("LC_APPLICABLE_RULES", LC_APPLICABLE_RULES);

				// Applicant
				inputDTO.setValue("LC_APPLICANT_REQ", (LC_APPLICANT_REQ == true) ? "1" : "0");
				if (LC_APPLICANT_TYPE.trim().equals(""))
					inputDTO.setValue("LC_APPLICANT_TYPE", "0");
				else
					inputDTO.setValue("LC_APPLICANT_TYPE", LC_APPLICANT_TYPE);

				if (LC_APPLICANT_TYPE.trim().equals("1")) {
					inputDTO.setValue("LC_APPLICANT_BIC_CODE", LC_APPLICANT_BIC_CODE);
					inputDTO.setValue("LC_APPLICANT_BRN_CODE", LC_APPLICANT_BRN_CODE);
				} else {
					inputDTO.setValue("LC_APPLICANT_BIC_CODE", "");
					inputDTO.setValue("LC_APPLICANT_BRN_CODE", "");
				}
				if (LC_APPLICANT_TYPE.trim().equals("2")) {
					inputDTO.setValue("LC_APPLICANT_BNK_CODE", LC_APPLICANT_BNK_CODE);
					inputDTO.setValue("LC_APPLICANT_ROUTID", LC_APPLICANT_ROUTID);

					if (!LC_APPLICANT_ADDRESS.equals("")) {
						applicant_add = LC_APPLICANT_ADDRESS.split("\n");
						inputDTO.setValue("LC_APPLICANT_ADDR1", applicant_add[0].trim());
						inputDTO.setValue("LC_APPLICANT_ADDR2", ((applicant_add.length > 1) ? applicant_add[1].trim() : " "));
						inputDTO.setValue("LC_APPLICANT_ADDR3", ((applicant_add.length > 2) ? applicant_add[2].trim() : " "));
						inputDTO.setValue("LC_APPLICANT_ADDR4", ((applicant_add.length > 3) ? applicant_add[3].trim() : " "));
						inputDTO.setValue("LC_APPLICANT_ADDR5", ((applicant_add.length > 4) ? applicant_add[4].trim() : " "));
					} else {
						inputDTO.setValue("LC_APPLICANT_ADDR1", " ");
						inputDTO.setValue("LC_APPLICANT_ADDR2", " ");
						inputDTO.setValue("LC_APPLICANT_ADDR3", " ");
						inputDTO.setValue("LC_APPLICANT_ADDR4", " ");
						inputDTO.setValue("LC_APPLICANT_ADDR5", " ");
					}
					inputDTO.setValue("LC_APPLICANT_CNTRY_CODE", LC_APPLICANT_CNTRY_CODE);
				} else {
					inputDTO.setValue("LC_APPLICANT_BNK_CODE", "");
					inputDTO.setValue("LC_APPLICANT_ROUTID", "");
					inputDTO.setValue("LC_APPLICANT_ADDR1", "");
					inputDTO.setValue("LC_APPLICANT_ADDR2", "");
					inputDTO.setValue("LC_APPLICANT_ADDR3", "");
					inputDTO.setValue("LC_APPLICANT_ADDR4", "");
					inputDTO.setValue("LC_APPLICANT_ADDR5", "");
					inputDTO.setValue("LC_APPLICANT_CNTRY_CODE", "");
				}

				// Available ..with..By Type
				if (LC_AVAILABLE_WITH_CODETYP.trim().equals(""))
					inputDTO.setValue("LC_AVAILABLE_WITH_CODETYP", "0");
				else
					inputDTO.setValue("LC_AVAILABLE_WITH_CODETYP", LC_AVAILABLE_WITH_CODETYP);

				// Available With..By..
				if (LC_AVAILABLE_WITH_TYPE.trim().equals(""))
					inputDTO.setValue("LC_AVAILABLE_WITH_TYPE", "0");
				else
					inputDTO.setValue("LC_AVAILABLE_WITH_TYPE", LC_AVAILABLE_WITH_TYPE);

				if (LC_AVAILABLE_WITH_TYPE.trim().equals("1")) {
					inputDTO.setValue("LC_AVAILABLE_WITH_BRN_CODE", LC_AVAILABLE_WITH_BRN_CODE);
					inputDTO.setValue("LC_AVAILABLE_WITH_CODE", LC_AVAILABLE_WITH_CODE);
				} else {
					inputDTO.setValue("LC_AVAILABLE_WITH_BRN_CODE", "");
					inputDTO.setValue("LC_AVAILABLE_WITH_CODE", "");
				}

				if (LC_AVAILABLE_WITH_TYPE.trim().equals("2")) {
					inputDTO.setValue("LC_AVAILABLE_WITH_BNK_CODE", LC_AVAILABLE_WITH_BNK_CODE);
					inputDTO.setValue("LC_AVAILABLE_WITH_ROUTID", LC_AVAILABLE_WITH_ROUTID);

					if (!LC_AVAILABLE_WITH_ADDRESS.equals("")) {
						availbl_with_add = LC_AVAILABLE_WITH_ADDRESS.split("\n");
						inputDTO.setValue("LC_AVAILABLE_WITH_ADDR1", availbl_with_add[0].trim());
						inputDTO.setValue("LC_AVAILABLE_WITH_ADDR2", ((availbl_with_add.length > 1) ? availbl_with_add[1].trim() : " "));
						inputDTO.setValue("LC_AVAILABLE_WITH_ADDR3", ((availbl_with_add.length > 2) ? availbl_with_add[2].trim() : " "));
						inputDTO.setValue("LC_AVAILABLE_WITH_ADDR4", ((availbl_with_add.length > 3) ? availbl_with_add[3].trim() : " "));
						inputDTO.setValue("LC_AVAILABLE_WITH_ADDR5", ((availbl_with_add.length > 4) ? availbl_with_add[4].trim() : " "));
					} else {
						inputDTO.setValue("LC_AVAILABLE_WITH_ADDR1", " ");
						inputDTO.setValue("LC_AVAILABLE_WITH_ADDR2", " ");
						inputDTO.setValue("LC_AVAILABLE_WITH_ADDR3", " ");
						inputDTO.setValue("LC_AVAILABLE_WITH_ADDR4", " ");
						inputDTO.setValue("LC_AVAILABLE_WITH_ADDR5", " ");
					}
					inputDTO.setValue("LC_AVAILABLE_WITH_CNTRY", LC_AVAILABLE_WITH_CNTRY);
				} else {
					inputDTO.setValue("LC_AVAILABLE_WITH_BNK_CODE", "");
					inputDTO.setValue("LC_AVAILABLE_WITH_ROUTID", "");
					inputDTO.setValue("LC_AVAILABLE_WITH_ADDR1", "");
					inputDTO.setValue("LC_AVAILABLE_WITH_ADDR2", "");
					inputDTO.setValue("LC_AVAILABLE_WITH_ADDR3", "");
					inputDTO.setValue("LC_AVAILABLE_WITH_ADDR4", "");
					inputDTO.setValue("LC_AVAILABLE_WITH_ADDR5", "");
					inputDTO.setValue("LC_AVAILABLE_WITH_CNTRY", "");
				}

				// Deferred Payment
				if (LC_AVAILABLE_WITH_CODETYP.trim().equals("2")) {
					if (!LC_DEFERRED_PAY_DETAILS.equals("")) {
						def_pay_details = LC_DEFERRED_PAY_DETAILS.split("\n");
						inputDTO.setValue("LC_DEFERRED_PAY_DETAILS1", def_pay_details[0].trim());
						inputDTO.setValue("LC_DEFERRED_PAY_DETAILS2", ((def_pay_details.length > 1) ? def_pay_details[1].trim() : " "));
						inputDTO.setValue("LC_DEFERRED_PAY_DETAILS3", ((def_pay_details.length > 2) ? def_pay_details[2].trim() : " "));
						inputDTO.setValue("LC_DEFERRED_PAY_DETAILS4", ((def_pay_details.length > 3) ? def_pay_details[3].trim() : " "));
					} else {
						inputDTO.setValue("LC_DEFERRED_PAY_DETAILS1", " ");
						inputDTO.setValue("LC_DEFERRED_PAY_DETAILS2", " ");
						inputDTO.setValue("LC_DEFERRED_PAY_DETAILS3", " ");
						inputDTO.setValue("LC_DEFERRED_PAY_DETAILS4", " ");
					}
				}
				// Mixed Payment
				else if (LC_AVAILABLE_WITH_CODETYP.trim().equals("3")) {
					if (!LC_MIXED_PAY_DETAILS.equals("")) {
						mixed_pay_details = LC_MIXED_PAY_DETAILS.split("\n");
						inputDTO.setValue("LC_MIXED_PAY_DETAILS1", mixed_pay_details[0].trim());
						inputDTO.setValue("LC_MIXED_PAY_DETAILS2", ((mixed_pay_details.length > 1) ? mixed_pay_details[1].trim() : " "));
						inputDTO.setValue("LC_MIXED_PAY_DETAILS3", ((mixed_pay_details.length > 2) ? mixed_pay_details[2].trim() : " "));
						inputDTO.setValue("LC_MIXED_PAY_DETAILS4", ((mixed_pay_details.length > 3) ? mixed_pay_details[3].trim() : " "));
					} else {
						inputDTO.setValue("LC_MIXED_PAY_DETAILS1", " ");
						inputDTO.setValue("LC_MIXED_PAY_DETAILS2", " ");
						inputDTO.setValue("LC_MIXED_PAY_DETAILS3", " ");
						inputDTO.setValue("LC_MIXED_PAY_DETAILS4", " ");
					}
				}

				// Drafts At...
				if (!LC_DRAFTS_AT.equals("")) {
					drafts = LC_DRAFTS_AT.split("\n");
					inputDTO.setValue("LC_DRAFTS_AT1", drafts[0].trim());
					inputDTO.setValue("LC_DRAFTS_AT2", ((drafts.length > 1) ? drafts[1].trim() : " "));
					inputDTO.setValue("LC_DRAFTS_AT3", ((drafts.length > 2) ? drafts[2].trim() : " "));
				} else {
					inputDTO.setValue("LC_DRAFTS_AT1", " ");
					inputDTO.setValue("LC_DRAFTS_AT2", " ");
					inputDTO.setValue("LC_DRAFTS_AT3", " ");
				}

				// Drawee
				inputDTO.setValue("LC_DRAWEE_REQ", (LC_DRAWEE_REQ == true) ? "1" : "0");
				if (LC_DRAWEE_TYPE.trim().equals(""))
					inputDTO.setValue("LC_DRAWEE_TYPE", "0");
				else
					inputDTO.setValue("LC_DRAWEE_TYPE", LC_DRAWEE_TYPE);
				if (LC_DRAWEE_TYPE.trim().equals("1")) {
					inputDTO.setValue("LC_DRAWEE_BRN_CODE", LC_DRAWEE_BRN_CODE);
					inputDTO.setValue("LC_DRAWEE_BIC_CODE", LC_DRAWEE_BIC_CODE);
				} else {
					inputDTO.setValue("LC_DRAWEE_BRN_CODE", "");
					inputDTO.setValue("LC_DRAWEE_BIC_CODE", "");
				}

				if (LC_DRAWEE_TYPE.trim().equals("2")) {
					inputDTO.setValue("LC_DRAWEE_BNK_CODE", LC_DRAWEE_BNK_CODE);
					inputDTO.setValue("LC_DRAWEE_ROUTID", LC_DRAWEE_ROUTID);

					if (!LC_DRAWEE_ADDRESS.equals("")) {
						drawee_add = LC_DRAWEE_ADDRESS.split("\n");
						inputDTO.setValue("LC_DRAWEE_ADDR1", drawee_add[0].trim());
						inputDTO.setValue("LC_DRAWEE_ADDR2", ((drawee_add.length > 1) ? drawee_add[1].trim() : " "));
						inputDTO.setValue("LC_DRAWEE_ADDR3", ((drawee_add.length > 2) ? drawee_add[2].trim() : " "));
						inputDTO.setValue("LC_DRAWEE_ADDR4", ((drawee_add.length > 3) ? drawee_add[3].trim() : " "));
						inputDTO.setValue("LC_DRAWEE_ADDR5", ((drawee_add.length > 4) ? drawee_add[4].trim() : " "));
					} else {
						inputDTO.setValue("LC_DRAWEE_ADDR1", " ");
						inputDTO.setValue("LC_DRAWEE_ADDR2", " ");
						inputDTO.setValue("LC_DRAWEE_ADDR3", " ");
						inputDTO.setValue("LC_DRAWEE_ADDR4", " ");
						inputDTO.setValue("LC_DRAWEE_ADDR5", " ");
					}
					inputDTO.setValue("LC_DRAWEE_CNTRY_CODE", LC_DRAWEE_CNTRY_CODE);
				} else {
					inputDTO.setValue("LC_DRAWEE_BNK_CODE", "");
					inputDTO.setValue("LC_DRAWEE_ROUTID", "");
					inputDTO.setValue("LC_DRAWEE_ADDR1", "");
					inputDTO.setValue("LC_DRAWEE_ADDR2", "");
					inputDTO.setValue("LC_DRAWEE_ADDR3", "");
					inputDTO.setValue("LC_DRAWEE_ADDR4", "");
					inputDTO.setValue("LC_DRAWEE_ADDR5", "");
					inputDTO.setValue("LC_DRAWEE_CNTRY_CODE", "");
				}

				// Partial Shipment Type
				if (LC_PARTIAL_SHIPMENTS.trim().equals(""))
					inputDTO.setValue("LC_PARTIAL_SHIPMENTS", "0");
				else
					inputDTO.setValue("LC_PARTIAL_SHIPMENTS", LC_PARTIAL_SHIPMENTS);
				// Shipment Type
				if (LC_TRANSHIPMENT.trim().equals(""))
					inputDTO.setValue("LC_TRANSHIPMENT", "0");
				else
					inputDTO.setValue("LC_TRANSHIPMENT", LC_TRANSHIPMENT);
				// Place of Charge
				if (LC_PLACE_OF_TAKING_IN_CHARGE.trim().equals(""))
					inputDTO.setValue("LC_PLACE_OF_TAKING_IN_CHARGE", "");
				else
					inputDTO.setValue("LC_PLACE_OF_TAKING_IN_CHARGE", LC_PLACE_OF_TAKING_IN_CHARGE);
				// Port of loading
				if (LC_PORT_OF_LOADING.trim().equals(""))
					inputDTO.setValue("LC_PORT_OF_LOADING", "");
				else
					inputDTO.setValue("LC_PORT_OF_LOADING", LC_PORT_OF_LOADING);
				// Port of discharge
				if (LC_PORT_OF_DISCHARGE.trim().equals(""))
					inputDTO.setValue("LC_PORT_OF_DISCHARGE", "");
				else
					inputDTO.setValue("LC_PORT_OF_DISCHARGE", LC_PORT_OF_DISCHARGE);
				// Place of Final Destination
				if (LC_PLACE_OF_FINAL_DEST.trim().equals(""))
					inputDTO.setValue("LC_PLACE_OF_FINAL_DEST", "");
				else
					inputDTO.setValue("LC_PLACE_OF_FINAL_DEST", LC_PLACE_OF_FINAL_DEST);

				// Shipment Period
				if (!LC_SHIPMENT_PERIOD.equals("")) {
					shpmnt_prd = LC_SHIPMENT_PERIOD.split("\n");
					inputDTO.setValue("LC_SHIPMENT_PERIOD1", shpmnt_prd[0].trim());
					inputDTO.setValue("LC_SHIPMENT_PERIOD2", ((shpmnt_prd.length > 1) ? shpmnt_prd[1].trim() : " "));
					inputDTO.setValue("LC_SHIPMENT_PERIOD3", ((shpmnt_prd.length > 2) ? shpmnt_prd[2].trim() : " "));
					inputDTO.setValue("LC_SHIPMENT_PERIOD4", ((shpmnt_prd.length > 3) ? shpmnt_prd[3].trim() : " "));
					inputDTO.setValue("LC_SHIPMENT_PERIOD5", ((shpmnt_prd.length > 4) ? shpmnt_prd[4].trim() : " "));
					inputDTO.setValue("LC_SHIPMENT_PERIOD6", ((shpmnt_prd.length > 5) ? shpmnt_prd[5].trim() : " "));
				} else {
					inputDTO.setValue("LC_SHIPMENT_PERIOD1", " ");
					inputDTO.setValue("LC_SHIPMENT_PERIOD2", " ");
					inputDTO.setValue("LC_SHIPMENT_PERIOD3", " ");
					inputDTO.setValue("LC_SHIPMENT_PERIOD4", " ");
					inputDTO.setValue("LC_SHIPMENT_PERIOD5", " ");
					inputDTO.setValue("LC_SHIPMENT_PERIOD6", " ");
				}

				// Description of Goods

				if (LC_DESC_GOODS_SER1.trim().equals(""))
					inputDTO.setValue("LC_DESC_GOODS_SER1", "");
				else
					inputDTO.setValue("LC_DESC_GOODS_SER1", LC_DESC_GOODS_SER1);
				if (LC_DESC_GOODS_SER2.trim().equals(""))
					inputDTO.setValue("LC_DESC_GOODS_SER2", "");
				else
					inputDTO.setValue("LC_DESC_GOODS_SER2", LC_DESC_GOODS_SER2.trim().toString());
				if (LC_DESC_GOODS_SER3.trim().equals(""))
					inputDTO.setValue("LC_DESC_GOODS_SER3", "");
				else
					inputDTO.setValue("LC_DESC_GOODS_SER3", LC_DESC_GOODS_SER3.trim().toString());
				// Document Required
				if (LC_DOC_REQ1.trim().equals(""))
					inputDTO.setValue("LC_DOC_REQ1", "");
				else
					inputDTO.setValue("LC_DOC_REQ1", LC_DOC_REQ1.trim().toString());
				if (LC_DOC_REQ2.trim().equals(""))
					inputDTO.setValue("LC_DOC_REQ2", "");
				else
					inputDTO.setValue("LC_DOC_REQ2", LC_DOC_REQ2.trim().toString());
				if (LC_DOC_REQ3.trim().equals(""))
					inputDTO.setValue("LC_DOC_REQ3", "");
				else
					inputDTO.setValue("LC_DOC_REQ3", LC_DOC_REQ3.trim().toString());
				// Additional Condition
				if (LC_ADD_CONDITION1.trim().equals(""))
					inputDTO.setValue("LC_ADD_CONDITION1", "");
				else
					inputDTO.setValue("LC_ADD_CONDITION1", LC_ADD_CONDITION1.trim().toString());
				if (LC_ADD_CONDITION2.trim().equals(""))
					inputDTO.setValue("LC_ADD_CONDITION2", "");
				else
					inputDTO.setValue("LC_ADD_CONDITION2", LC_ADD_CONDITION2.trim().toString());
				if (LC_ADD_CONDITION3.trim().equals(""))
					inputDTO.setValue("LC_ADD_CONDITION3", "");
				else
					inputDTO.setValue("LC_ADD_CONDITION3", LC_ADD_CONDITION3.trim().toString());
				// Charges
				if (!LC_CHARGES.equals("")) {
					chgs = LC_CHARGES.split("\n");
					inputDTO.setValue("LC_CHARGES1", chgs[0].trim());
					inputDTO.setValue("LC_CHARGES2", ((chgs.length > 1) ? chgs[1].trim() : " "));
					inputDTO.setValue("LC_CHARGES3", ((chgs.length > 2) ? chgs[2].trim() : " "));
					inputDTO.setValue("LC_CHARGES4", ((chgs.length > 3) ? chgs[3].trim() : " "));
					inputDTO.setValue("LC_CHARGES5", ((chgs.length > 4) ? chgs[4].trim() : " "));
					inputDTO.setValue("LC_CHARGES6", ((chgs.length > 5) ? chgs[5].trim() : " "));
				} else {
					inputDTO.setValue("LC_CHARGES1", " ");
					inputDTO.setValue("LC_CHARGES2", " ");
					inputDTO.setValue("LC_CHARGES3", " ");
					inputDTO.setValue("LC_CHARGES4", " ");
					inputDTO.setValue("LC_CHARGES5", " ");
					inputDTO.setValue("LC_CHARGES6", " ");
				}
				// Presentation day
				if (LC_PER_PRESENTATION_DAY.trim().equals(""))
					inputDTO.setValue("LC_PER_PRESENTATION_DAY", "0");
				else
					inputDTO.setValue("LC_PER_PRESENTATION_DAY", LC_PER_PRESENTATION_DAY);

				if (olcPresentDetail.trim().equals(""))
					inputDTO.setValue("LC_PER_PRESENTATION_REMARKS", "");
				else
					inputDTO.setValue("LC_PER_PRESENTATION_REMARKS", olcPresentDetail);
				//Changes Sanjay1 22-07-2019 Begin
				// Confirmation Instruction
				if (LC_CONFIRMATION_INST.trim().equals(""))
				{
					inputDTO.setValue("LC_CONFIRMATION_INST", "0");
				}
				else
				{
					inputDTO.setValue("LC_CONFIRMATION_INST", LC_CONFIRMATION_INST);
					if(!LC_CONFIRMATION_INST.equals("3"))
					{
						if (LC_REIMB_CFM_TYPE.trim().equals(""))
							inputDTO.setValue("LC_CFM_REIMB_TYPE", "");
						else
							inputDTO.setValue("LC_CFM_REIMB_TYPE", LC_REIMB_CFM_TYPE);
						if (LC_REIMB_CFM_TYPE.trim().equals("1")) {
							inputDTO.setValue("LC_CFM_REIMB_BRN_CODE", LC_REIMB_CFM_BRN_CODE);
							inputDTO.setValue("LC_CFM_REIMB_BIC_CODE", LC_REIMB_CFM_BIC_CODE);
						} else {
							inputDTO.setValue("LC_CFM_REIMB_BRN_CODE", "");
							inputDTO.setValue("LC_CFM_REIMB_BIC_CODE", "");
						}

						if (LC_REIMB_CFM_TYPE.trim().equals("2")) {
							inputDTO.setValue("LC_CFM_REIMB_BNK_CODE", LC_CFM_REIMB_BNK_CODE);
							inputDTO.setValue("LC_CFM_REIMB_ROUTID", LC_CFM_REIMB_ROUTID);

							if (!LC_CFM_REIMB_ADDRESS.equals("")) {
								reimb_cfm_add = LC_CFM_REIMB_ADDRESS.split("\n");
								inputDTO.setValue("LC_CFM_REIMB_ADDR1", reimb_cfm_add[0].trim());
								inputDTO.setValue("LC_CFM_REIMB_ADDR2", ((reimb_cfm_add.length > 1) ? reimb_cfm_add[1].trim() : " "));
								inputDTO.setValue("LC_CFM_REIMB_ADDR3", ((reimb_cfm_add.length > 2) ? reimb_cfm_add[2].trim() : " "));
								inputDTO.setValue("LC_CFM_REIMB_ADDR4", ((reimb_cfm_add.length > 3) ? reimb_cfm_add[3].trim() : " "));
								inputDTO.setValue("LC_CFM_REIMB_ADDR5", ((reimb_cfm_add.length > 4) ? reimb_cfm_add[4].trim() : " "));
							} else {
								inputDTO.setValue("LC_CFM_REIMB_ADDR1", " ");
								inputDTO.setValue("LC_CFM_REIMB_ADDR2", " ");
								inputDTO.setValue("LC_CFM_REIMB_ADDR3", " ");
								inputDTO.setValue("LC_CFM_REIMB_ADDR4", " ");
								inputDTO.setValue("LC_CFM_REIMB_ADDR5", " ");
							}
							inputDTO.setValue("LC_CFM_REIMB_CNTRY_CODE", LC_CFM_REIMB_CNTRY_CODE);// should
							// add
						} else {
							inputDTO.setValue("LC_CFM_REIMB_BNK_CODE", "");
							inputDTO.setValue("LC_CFM_REIMB_ROUTID", "");
							inputDTO.setValue("LC_CFM_REIMB_ADDR1", "");
							inputDTO.setValue("LC_CFM_REIMB_ADDR2", "");
							inputDTO.setValue("LC_CFM_REIMB_ADDR3", "");
							inputDTO.setValue("LC_CFM_REIMB_ADDR4", "");
							inputDTO.setValue("LC_CFM_REIMB_ADDR5", "");
							inputDTO.setValue("LC_CFM_REIMB_CNTRY_CODE", "");// should add
						}
					}
				}
				//Changes Sanjay1 22-07-2019 End
				// Reimbursing Bank
				inputDTO.setValue("LC_REIMB_REQ", (LC_REIMB_REQ == true) ? "1" : "0");
				if (LC_REIMB_TYPE.trim().equals(""))
					inputDTO.setValue("LC_REIMB_TYPE", "");
				else
					inputDTO.setValue("LC_REIMB_TYPE", LC_REIMB_TYPE);
				if (LC_REIMB_TYPE.trim().equals("1")) {
					inputDTO.setValue("LC_REIMB_BRN_CODE", LC_REIMB_BRN_CODE);
					inputDTO.setValue("LC_REIMB_BIC_CODE", LC_REIMB_BIC_CODE);
				} else {
					inputDTO.setValue("LC_REIMB_BRN_CODE", "");
					inputDTO.setValue("LC_REIMB_BIC_CODE", "");
				}

				if (LC_REIMB_TYPE.trim().equals("2")) {
					inputDTO.setValue("LC_REIMB_BNK_CODE", LC_REIMB_BNK_CODE);
					inputDTO.setValue("LC_REIMB_ROUTID", LC_REIMB_ROUTID);

					if (!LC_REIMB_ADDRESS.equals("")) {
						reimb_add = LC_REIMB_ADDRESS.split("\n");
						inputDTO.setValue("LC_REIMB_ADDR1", reimb_add[0].trim());
						inputDTO.setValue("LC_REIMB_ADDR2", ((reimb_add.length > 1) ? reimb_add[1].trim() : " "));
						inputDTO.setValue("LC_REIMB_ADDR3", ((reimb_add.length > 2) ? reimb_add[2].trim() : " "));
						inputDTO.setValue("LC_REIMB_ADDR4", ((reimb_add.length > 3) ? reimb_add[3].trim() : " "));
						inputDTO.setValue("LC_REIMB_ADDR5", ((reimb_add.length > 4) ? reimb_add[4].trim() : " "));
					} else {
						inputDTO.setValue("LC_REIMB_ADDR1", " ");
						inputDTO.setValue("LC_REIMB_ADDR2", " ");
						inputDTO.setValue("LC_REIMB_ADDR3", " ");
						inputDTO.setValue("LC_REIMB_ADDR4", " ");
						inputDTO.setValue("LC_REIMB_ADDR5", " ");
					}
					inputDTO.setValue("LC_REIMB_CNTRY_CODE", LC_REIMB_CNTRY_CODE);
				} else {
					inputDTO.setValue("LC_REIMB_BNK_CODE", "");
					inputDTO.setValue("LC_REIMB_ROUTID", "");
					inputDTO.setValue("LC_REIMB_ADDR1", "");
					inputDTO.setValue("LC_REIMB_ADDR2", "");
					inputDTO.setValue("LC_REIMB_ADDR3", "");
					inputDTO.setValue("LC_REIMB_ADDR4", "");
					inputDTO.setValue("LC_REIMB_ADDR5", "");
					inputDTO.setValue("LC_REIMB_CNTRY_CODE", "");
				}
				// Instructions to Paying
				if (!LC_INST_PAYING.equals("")) {
					instr_paying = LC_INST_PAYING.split("\n");
					inputDTO.setValue("LC_INST_PAYING1", instr_paying[0].trim());
					inputDTO.setValue("LC_INST_PAYING2", ((instr_paying.length > 1) ? instr_paying[1].trim() : " "));
					inputDTO.setValue("LC_INST_PAYING3", ((instr_paying.length > 2) ? instr_paying[2].trim() : " "));
					inputDTO.setValue("LC_INST_PAYING4", ((instr_paying.length > 3) ? instr_paying[3].trim() : " "));
					inputDTO.setValue("LC_INST_PAYING5", ((instr_paying.length > 4) ? instr_paying[4].trim() : " "));
					inputDTO.setValue("LC_INST_PAYING6", ((instr_paying.length > 5) ? instr_paying[5].trim() : " "));
					inputDTO.setValue("LC_INST_PAYING7", ((instr_paying.length > 6) ? instr_paying[6].trim() : " "));
					inputDTO.setValue("LC_INST_PAYING8", ((instr_paying.length > 7) ? instr_paying[7].trim() : " "));
					inputDTO.setValue("LC_INST_PAYING9", ((instr_paying.length > 8) ? instr_paying[8].trim() : " "));
					inputDTO.setValue("LC_INST_PAYING10", ((instr_paying.length > 9) ? instr_paying[9].trim() : " "));
					inputDTO.setValue("LC_INST_PAYING11", ((instr_paying.length > 10) ? instr_paying[10].trim() : " "));
					inputDTO.setValue("LC_INST_PAYING12", ((instr_paying.length > 11) ? instr_paying[11].trim() : " "));
				} else {
					inputDTO.setValue("LC_INST_PAYING1", " ");
					inputDTO.setValue("LC_INST_PAYING2", " ");
					inputDTO.setValue("LC_INST_PAYING3", " ");
					inputDTO.setValue("LC_INST_PAYING4", " ");
					inputDTO.setValue("LC_INST_PAYING5", " ");
					inputDTO.setValue("LC_INST_PAYING6", " ");
					inputDTO.setValue("LC_INST_PAYING7", " ");
					inputDTO.setValue("LC_INST_PAYING8", " ");
					inputDTO.setValue("LC_INST_PAYING9", " ");
					inputDTO.setValue("LC_INST_PAYING10", " ");
					inputDTO.setValue("LC_INST_PAYING11", " ");
					inputDTO.setValue("LC_INST_PAYING12", " ");
				}
				// Second Advising Bank
				inputDTO.setValue("LC_SECOND_ADV_REQ", (LC_SECOND_ADV_REQ == true) ? "1" : "0");
				if (LC_SECOND_ADV_TYPE.trim().equals(""))
					inputDTO.setValue("LC_SECOND_ADV_TYPE", "");
				else
					inputDTO.setValue("LC_SECOND_ADV_TYPE", LC_SECOND_ADV_TYPE);
				if (LC_SECOND_ADV_TYPE.trim().equals("1")) {
					inputDTO.setValue("LC_SECOND_ADV_BRN_CODE", LC_SECOND_ADV_BRN_CODE);
					inputDTO.setValue("LC_SECOND_ADV_BIC_CODE", LC_SECOND_ADV_BIC_CODE);
				} else {
					inputDTO.setValue("LC_SECOND_ADV_BRN_CODE", "");
					inputDTO.setValue("LC_SECOND_ADV_BIC_CODE", "");
				}

				if (LC_SECOND_ADV_TYPE.trim().equals("2")) {
					inputDTO.setValue("LC_SECOND_ADV_BNK_CODE", LC_SECOND_ADV_BNK_CODE);
					inputDTO.setValue("LC_SECOND_ADV_ROUTID", LC_SECOND_ADV_ROUTID);

					if (!LC_SECOND_ADV_ADDRESS.equals("")) {
						second_adv_add = LC_SECOND_ADV_ADDRESS.split("\n");
						inputDTO.setValue("LC_SECOND_ADV_ADDR1", second_adv_add[0].trim());
						inputDTO.setValue("LC_SECOND_ADV_ADDR2", ((second_adv_add.length > 1) ? second_adv_add[1].trim() : " "));
						inputDTO.setValue("LC_SECOND_ADV_ADDR3", ((second_adv_add.length > 2) ? second_adv_add[2].trim() : " "));
						inputDTO.setValue("LC_SECOND_ADV_ADDR4", ((second_adv_add.length > 3) ? second_adv_add[3].trim() : " "));
						inputDTO.setValue("LC_SECOND_ADV_ADDR5", ((second_adv_add.length > 4) ? second_adv_add[4].trim() : " "));
					} else {
						inputDTO.setValue("LC_SECOND_ADV_ADDR1", " ");
						inputDTO.setValue("LC_SECOND_ADV_ADDR2", " ");
						inputDTO.setValue("LC_SECOND_ADV_ADDR3", " ");
						inputDTO.setValue("LC_SECOND_ADV_ADDR4", " ");
						inputDTO.setValue("LC_SECOND_ADV_ADDR5", " ");
					}
					inputDTO.setValue("LC_SECOND_ADV_CNTRYCODE", LC_SECOND_ADV_CNTRYCODE);
				} else {
					inputDTO.setValue("LC_SECOND_ADV_BNK_CODE", "");
					inputDTO.setValue("LC_SECOND_ADV_ROUTID", "");
					inputDTO.setValue("LC_SECOND_ADV_ADDR1", "");
					inputDTO.setValue("LC_SECOND_ADV_ADDR2", "");
					inputDTO.setValue("LC_SECOND_ADV_ADDR3", "");
					inputDTO.setValue("LC_SECOND_ADV_ADDR4", "");
					inputDTO.setValue("LC_SECOND_ADV_ADDR5", "");
					inputDTO.setValue("LC_SECOND_ADV_CNTRYCODE", "");
				}

				// Sender to Receiver
				if (!LC_SNDR_REC_INFO.equals("")) {
					send_to_rec = LC_SNDR_REC_INFO.split("\n");
					inputDTO.setValue("LC_SNDR_REC_INFO1", send_to_rec[0].trim());
					inputDTO.setValue("LC_SNDR_REC_INFO2", ((send_to_rec.length > 1) ? send_to_rec[1].trim() : " "));
					inputDTO.setValue("LC_SNDR_REC_INFO3", ((send_to_rec.length > 2) ? send_to_rec[2].trim() : " "));
					inputDTO.setValue("LC_SNDR_REC_INFO4", ((send_to_rec.length > 3) ? send_to_rec[3].trim() : " "));
					inputDTO.setValue("LC_SNDR_REC_INFO5", ((send_to_rec.length > 4) ? send_to_rec[4].trim() : " "));
					inputDTO.setValue("LC_SNDR_REC_INFO6", ((send_to_rec.length > 5) ? send_to_rec[5].trim() : " "));
				} else {
					inputDTO.setValue("LC_SNDR_REC_INFO1", " ");
					inputDTO.setValue("LC_SNDR_REC_INFO2", " ");
					inputDTO.setValue("LC_SNDR_REC_INFO3", " ");
					inputDTO.setValue("LC_SNDR_REC_INFO4", " ");
					inputDTO.setValue("LC_SNDR_REC_INFO5", " ");
					inputDTO.setValue("LC_SNDR_REC_INFO6", " ");
				}
				inputDTO.setValue("CBD", getM_CurrBusDate());
				inputDTO.setValue("LC_REC_BIC_CODE", LC_REC_BIC_CODE);
			}

			inputDTO.setValue("USER_BRNAUTH", _brnAuth);

			// changes in eolc on 26-may-2018 end

			inputDTO.setValue("Class", JNDINames.EOLCBO_EJBHOME);
			inputDTO.setValue("USERID", getM_Userid());
			inputDTO.setValue("USRBRNCODE", getM_BranchCode());
			inputDTO.setValue("IPADDRESS", get_IPaddress());
			try {
				CDelagate = new CommonDelegate();
				DTOResult = CDelagate.setInfo(inputDTO);

				System.out.println(DTOResult.getValue("Result"));
			} catch (Exception e) {
				System.out.println(e.getMessage());
			} finally {
				if ("SUCCESS".equals(DTOResult.getValue("Result"))) {
					// 0 is used indicate success
					if (DTOResult.containsKey("SERIAL")) {
						serial = DTOResult.getValue("SERIAL");
						batnum = DTOResult.getValue("BatchNumber");
						setSerial(serial + "\n" + "Corr Ref Num=" + correfno + "\n" + batnum);
					} else {
						batnum = DTOResult.getValue("BatchNumber");
						setBatnum(batnum);
						serial = "";
					}

					mtxnStatus = "0";
				} else {
					// 1 is used to indicate failure
					mtxnStatus = "1";
					merrmsg = "";
					if (DTOResult.containsKey("Errmsg"))
						;
					{
						merrmsg = DTOResult.getValue("Errmsg");
					}
				}
			}
			{
				setreturnvalue();
				return "success";
			}
		} else {
			{
				setreturnvalue();
				return "failure";
			}
		}
	}

	// private method to revalidate all the received values form the bean before
	// proceeding to persist data
	private boolean RevalidateOLC() {
		// ADDED BY PRASHANTH PATTERNS FOR TSRY_HOLIDAY 06 OCTOBER 2017
		if (revalTsryHoliday("")) {
			merrmsg = "MF:txtbrncode|" + TsryHolErr;
			return false;
		}
		// ADDED BY PRASHANTH PATTERNS FOR TSRY_HOLIDAY 06 OCTOBER 2017

		// treasury changes by PRASHANTH chn 01-08-2017
		SetTsryStatus();
		// treasury changes by PRASHANTH chn 01-08-2017
		if (!revalOption()) {
			return false;
		}

		if (!revalolcBrnCode()) {
			return false;
		}

		if (!revalolcLcType()) {
			return false;
		}

		if (!revalolcLcYear()) {
			return false;
		}

		if ((muserOption.equalsIgnoreCase("A")) && (auto_num.equalsIgnoreCase("0"))) {
			if (!revalolcLcSl()) {
				return false;
			}
		}
		if (muserOption.equalsIgnoreCase("M")) {
			if (!revalolcLcSl()) {
				return false;
			}
		}

		if (!revalolcLcPresancDate()) {
			return false;
		}

		if (!revalolcLcPresancDaySl()) {
			return false;
		}

		if (!revalolcLcDate()) {
			return false;
		}

		/*
		 * if(!(olcBenefCode.equalsIgnoreCase(""))) {
		 */// COMMENTED ON 11/10/2018
		if (!revalolcBenefCode()) {
			return false;
		}
		// }

		if (olcBenefCode.equalsIgnoreCase("")) {
			if (!revalolcBenefName()) {
				return false;
			}
			if (!revalolcBenefAdd()) {
				return false;
			}
		}

		if (!revalolcBenefCntryCode()) {
			return false;
		}

		if (!revalolcLcIssBkCode()) {
			return false;
		}

		if (!(olcLcIssBrnCode.equalsIgnoreCase(""))) {
			if (!revalolcLcIssBrnCode()) {
				return false;
			}

		} else {
			if (!revalolcLcIssBrnName()) {
				return false;
			}
			if (!revalolcLcIssBrnAdd()) {
				return false;
			}

		}
		if (!olcLcIssBrnAdd.equalsIgnoreCase("")) {
			if (!revalolcLcIssBrnAdd1()) {
				return false;
			}
		} else {
			brnadd1 = " ";
			brnadd2 = " ";
			brnadd3 = " ";
			brnadd4 = " ";
			brnadd5 = " ";
		}

		if (!revalolcLcIssCntryCode()) {
			return false;
		}
		if (!revalolcLcIssThru()) {
			return false;
		}

		if (!revalolcLcCurrCode()) {
			return false;
		}

		if (!revalolcLcAmount()) {
			return false;
		}

		if (olcDevAllwd_bol.equalsIgnoreCase("1")) {
			if (!revalolcPosDevia()) {
				return false;
			}

			if (!revalolcNegDevia()) {
				return false;
			}

			if (!revalolcDeviaAmt()) {
				return false;
			}
			if (!revalolcAmtQuali()) {
				return false;
			}
		}
		if (!revalAddiAmtsCovered()) {
			return false;
		}
		if (!revalolcTermsOfPrice()) {
			return false;
		}
		if (!revalolcLastDateOfNego()) {
			return false;
		}
		if (!revalShipmentPeriod()) {
			return false;
		}
		if (!revalPresentationDtl()) {
			return false;
		}
		if (!revalolcNoOfTenors()) {
			return false;
		}
		if (!revallcpsGrid1()) {
			return false;
		}
		// Changes P.Subramani-Chn-22/02/2008
		// tfmcratesdetail.setRecovCurr(basecurr);
		// tfmcratesdetail.set_TOTAMT_CONV();
		if (!(olcLcCurrCode.equalsIgnoreCase(basecurr))) {
			if (!tfmcratesdetail.isValid()) {
				merrmsg = tfmcratesdetail.get_errMsg();
				return false;
			}
		}
		// S.Suresh Babu Add 24-09-2009
		if (!olcLcCurrCode.equalsIgnoreCase(getM_BCurrCode())) {
			if (!revalfetchconvRate()) {
				return false;
			}
		}

		if (!revalolcConrateToLimitCurr()) {
			return false;
		}

		if (!revalolclimitvalue()) {
			return false;
		}

		if (!revalolcMaginCurr()) {
			return false;
		}

		if (!tfmchargesdetail.isValid()) {
			merrmsg = tfmchargesdetail.getErrMsg();
			return false;
		}

		// Changes P.Subramani-Chn-19-06-20008 Beg
		if (!revalchargecode()) {
			return false;
		}
		// Changes P.Subramani-Chn-19-06-20008 End

		// Changes P.Subramani-Chn-22/02/2008
		if (!(tfmchargesdetail.getTRANCHGS_TOTAL_CHGS().equalsIgnoreCase("0.00")) || (tfmchargesdetail.getTRANCHGS_TOTAL_CHGS().equalsIgnoreCase("0"))) {
			if (!revalcomp()) {
				return false;
			}
		}

		// changes in eolc on 27-may-2018 start
		if (olcLcType.trim().equals("OLC")) {
			if (!revalformOfCredit()) {
				return false;
			}

			if (!revalRefToPreAdvice()) {
				return false;
			}

			if (!revalAppRuleType()) {
				return false;
			}

			// Applicant
			if (LC_APPLICANT_REQ == true) {
				if (!revalApplicantBankOurType()) {
					return false;
				}
				if (!revalBankType(1, LC_APPLICANT_TYPE, 1)) {
					return false;
				}
				if (!revalSwiftBankBic(1, LC_APPLICANT_TYPE, LC_APPLICANT_BIC_CODE, 1)) {
					return false;
				}

				if (!revalSwiftBranchCode(1, LC_APPLICANT_TYPE, LC_APPLICANT_BRN_CODE, 1)) {
					return false;
				}

				if (!revalSwiftBankName(1, LC_APPLICANT_TYPE, LC_APPLICANT_BNK_CODE, 1)) {
					return false;
				}

				if (!revalSwiftBankAddress(1, LC_APPLICANT_TYPE, LC_APPLICANT_ADDRESS, 1)) {
					return false;
				}

				if (!revalSwiftCountryCode(1, LC_APPLICANT_TYPE, LC_APPLICANT_CNTRY_CODE, 1)) {
					return false;
				}

				if (!revalSwiftRoutingId(1, LC_APPLICANT_TYPE, LC_APPLICANT_ROUTID, 1)) {
					return false;
				}
			}
			// Available..With..By
			if (!revalAvailableWithBankType()) {
				return false;
			}
			if (!LC_AVAILABLE_WITH_CODETYP.trim().equals("")) {
				if (!revalBankType(1, LC_AVAILABLE_WITH_TYPE, 2)) {
					return false;
				}
				if (!revalSwiftBankBic(1, LC_AVAILABLE_WITH_TYPE, LC_AVAILABLE_WITH_CODE, 2)) {
					return false;
				}

				if (!revalSwiftBranchCode(1, LC_AVAILABLE_WITH_TYPE, LC_AVAILABLE_WITH_BRN_CODE, 2)) {
					return false;
				}

				if (!revalSwiftBankName(1, LC_AVAILABLE_WITH_TYPE, LC_AVAILABLE_WITH_BNK_CODE, 2)) {
					return false;
				}

				if (!revalSwiftBankAddress(1, LC_AVAILABLE_WITH_TYPE, LC_AVAILABLE_WITH_ADDRESS, 2)) {
					return false;
				}

				if (!revalSwiftCountryCode(1, LC_AVAILABLE_WITH_TYPE, LC_AVAILABLE_WITH_CNTRY, 2)) {
					return false;
				}

				if (!revalSwiftRoutingId(1, LC_AVAILABLE_WITH_TYPE, LC_AVAILABLE_WITH_ROUTID, 2)) {
					return false;
				}
			}
			// Drawee
			if (LC_DRAWEE_REQ == true) {
				if (!revalBankType(1, LC_DRAWEE_TYPE, 3)) {
					return false;
				}
				if (!revalSwiftBankBic(1, LC_DRAWEE_TYPE, LC_DRAWEE_BIC_CODE, 3)) {
					return false;
				}

				if (!revalSwiftBranchCode(1, LC_DRAWEE_TYPE, LC_DRAWEE_BRN_CODE, 3)) {
					return false;
				}

				if (!revalSwiftBankName(1, LC_DRAWEE_TYPE, LC_DRAWEE_BNK_CODE, 3)) {
					return false;
				}

				if (!revalSwiftBankAddress(1, LC_DRAWEE_TYPE, LC_DRAWEE_ADDRESS, 3)) {
					return false;
				}

				if (!revalSwiftCountryCode(1, LC_DRAWEE_TYPE, LC_DRAWEE_CNTRY_CODE, 3)) {
					return false;
				}

				if (!revalSwiftRoutingId(1, LC_DRAWEE_TYPE, LC_DRAWEE_ROUTID, 3)) {
					return false;
				}
			}
			
			//Changes Sanjay1 22-07-2019 Begin
			
			if ((LC_CONFIRMATION_INST.equals("1")) || (LC_CONFIRMATION_INST.equals("2"))) {
				if (!revalBankType(1, LC_REIMB_CFM_TYPE, 6)) {
					return false;
				}
				if (!revalSwiftBankBic(1, LC_REIMB_CFM_TYPE, LC_REIMB_CFM_BIC_CODE, 6)) {
					return false;
				}

				if (!revalSwiftBranchCode(1, LC_REIMB_CFM_TYPE, LC_REIMB_CFM_BRN_CODE, 6)) {
					return false;
				}

				if (!revalSwiftBankName(1, LC_REIMB_CFM_TYPE, LC_CFM_REIMB_BNK_CODE, 6)) {
					return false;
				}

				if (!revalSwiftBankAddress(1, LC_REIMB_CFM_TYPE, LC_CFM_REIMB_ADDRESS, 6)) {
					return false;
				}

				if (!revalSwiftCountryCode(1, LC_REIMB_CFM_TYPE, LC_CFM_REIMB_CNTRY_CODE, 6)) {
					return false;
				}

				if (!revalSwiftRoutingId(1, LC_REIMB_CFM_TYPE, LC_CFM_REIMB_ROUTID, 6)) {
					return false;
				}
			}
			//Changes Sanjay1 22-07-2019 End
			
			// Reimbursing Bank
			if (LC_REIMB_REQ == true) {
				if (!revalBankType(1, LC_REIMB_TYPE, 4)) {
					return false;
				}
				if (!revalSwiftBankBic(1, LC_REIMB_TYPE, LC_REIMB_BIC_CODE, 4)) {
					return false;
				}

				if (!revalSwiftBranchCode(1, LC_REIMB_TYPE, LC_REIMB_BRN_CODE, 4)) {
					return false;
				}

				if (!revalSwiftBankName(1, LC_REIMB_TYPE, LC_REIMB_BNK_CODE, 4)) {
					return false;
				}

				if (!revalSwiftBankAddress(1, LC_REIMB_TYPE, LC_REIMB_ADDRESS, 4)) {
					return false;
				}

				if (!revalSwiftCountryCode(1, LC_REIMB_TYPE, LC_REIMB_CNTRY_CODE, 4)) {
					return false;
				}

				if (!revalSwiftRoutingId(1, LC_REIMB_TYPE, LC_REIMB_ROUTID, 4)) {
					return false;
				}
			}
			// Second Advising Bank
			if (LC_SECOND_ADV_REQ == true) {
				if (!revalBankType(1, LC_SECOND_ADV_TYPE, 5)) {
					return false;
				}
				if (!revalSwiftBankBic(1, LC_SECOND_ADV_TYPE, LC_SECOND_ADV_BIC_CODE, 5)) {
					return false;
				}

				if (!revalSwiftBranchCode(1, LC_SECOND_ADV_TYPE, LC_SECOND_ADV_BRN_CODE, 5)) {
					return false;
				}

				if (!revalSwiftBankName(1, LC_SECOND_ADV_TYPE, LC_SECOND_ADV_BNK_CODE, 5)) {
					return false;
				}

				if (!revalSwiftBankAddress(1, LC_SECOND_ADV_TYPE, LC_SECOND_ADV_ADDRESS, 5)) {
					return false;
				}

				if (!revalSwiftCountryCode(1, LC_SECOND_ADV_TYPE, LC_SECOND_ADV_CNTRYCODE, 5)) {
					return false;
				}

				if (!revalSwiftRoutingId(1, LC_SECOND_ADV_TYPE, LC_SECOND_ADV_ROUTID, 5)) {
					return false;
				}
			}

			// Drafts At..
			if (!revalSwiftDraftsAt()) {
				return false;
			}

			// Mixed Payment
			if (!revalSwiftMixedPaymentDetails()) {
				return false;
			}

			// Deferred Paymnet
			if (!revalSwiftDeferredPaymentDetails()) {
				return false;
			}

			// Place of Taking Charge
			if (!revalSwiftPlaceOfTakingCharge()) {
				return false;
			}

			// Port of Loading
			if (!revalSwiftPortOfLoading()) {
				return false;
			}

			// Port of Discharge
			if (!revalSwiftPortOfDischarge()) {
				return false;
			}

			// Port Of Final Destination
			if (!revalSwiftPortOfFinalDestination()) {
				return false;
			}

			// Shipment Period
			if (!revalSwiftSipmentPeriod()) {
				return false;
			}

			// Description of Goods and Services
			if (!revalSwiftDescriptionOfGoodsAndServices1()) {
				return false;
			}
			if (!revalSwiftDescriptionOfGoodsAndServices2()) {
				return false;
			}
			if (!revalSwiftDescriptionOfGoodsAndServices3()) {
				return false;
			}

			// Documnets Required
			if (!revalSwiftDocumentsRequired1()) {
				return false;
			}
			if (!revalSwiftDocumentsRequired2()) {
				return false;
			}
			if (!revalSwiftDocumentsRequired3()) {
				return false;
			}

			// Additional Conditions
			if (!revalSwiftAdditionalCondition1()) {
				return false;
			}
			if (!revalSwiftAdditionalCondition2()) {
				return false;
			}
			if (!revalSwiftAdditionalCondition3()) {
				return false;
			}

			// ADDED BY PRASHANTH ON 29 JANUARY 2018
			//Changes Sanjay1 22-07-2019 Begin
			/*if (!revalolcAdvThruBk()) {
				return false;
			}
			if (!revalolcAdvThruBrn()) {
				return false;
			}
			if (!revalolcAdvBrnName()) {
				return false;
			}*/
			//Changes Sanjay1 22-07-2019 End
			// ADDED BY PRASHANTH ON 29 JANUARY 2018
	
			
			// Charges
			if (!revalSwiftCharges()) {
				return false;
			}

			// Presentation DAy
			if (!revalSwiftPeriodForPresentation()) {
				return false;
			}

			// Confirmation Instruction
			if (!revalSwiftConfirmationInstruction()) {
				return false;
			}
			
			
			
			
			
			
			// Instruction to the Paying
			if (!revalSwiftInstructionPaying()) {
				return false;
			}

			// Sender to Receiver Informtion
			if (!revalSwiftSendToRecInfo()) {
				return false;
			}

			// Overall BIC Val
			if (!revalSwiftOverallBICCode(LC_APPLICANT_BIC_CODE, LC_AVAILABLE_WITH_CODE, LC_DRAWEE_BIC_CODE, LC_REIMB_BIC_CODE, LC_SECOND_ADV_BIC_CODE)) {
				return false;
			}
		}

		// changes in eolc on 27-may-2018 end

		merrmsg = "";
		return true;
	}

	// S.Suresh Babu Add 24-09-2009
	private boolean revalfetchconvRate() {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("LC_CURR", olcLcCurrCode);
		inputDTO.setValue("BASE_CURR", getM_BCurrCode());
		inputDTO.setValue("TOT_EQV_AMT", FormatDoubleValue(Double.parseDouble((tfmcratesdetail.get_TOTEQUIV_AMT()))));
		inputDTO.setValue("AMT_CONV", FormatDoubleValue(Double.parseDouble((tfmcratesdetail.get_TOTAMT_CONV()))));
		// ADDED ON 01/10/2018 START
		inputDTO.setValue("TRAN_DATE", olcLcDate);
		inputDTO.setValue("TYPE", "N");
		// ADDED ON 01/10/2018 END
		revalDTO = eolcvalinstance.fetchconvrate(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtConRateToLimitCurr|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		} else {
			conver_rate = revalDTO.getValue("CONVER_RATE");
			_roundoff = revalDTO.getValue("ROUND_OFF_AMOUNT1");
		}
		return true;
	}

	private boolean revalOption() {

		if (muserOption.trim().equalsIgnoreCase("")) {
			merrmsg = "MF:seluseroption|Select Option";
			return false;
		}
		return true;
	}

	private boolean revalolcBrnCode() {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("OLC_BRN_CODE", olcBrnCode);
		inputDTO.setValue("USER_ROLE_CODE", getM_UserRoleCode());
		revalDTO = eolcvalinstance.olcBrnCodekeypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtbrncode|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}

		_brnAuth = revalDTO.getValue("USER_BRN_AUTH");// changes in EOLC on
		// 12-Jun-2018

		return true;
	}

	private boolean revalolcLcType() {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("OLC_TYPE", olcLcType);
		inputDTO.setValue("CBD", getM_CurrBusDate());
		revalDTO = eolcvalinstance.olcTypekeypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtconttype|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}
		num_choice = revalDTO.getValue("TNOMEN_NUM_CHOICE");
		auto_num = revalDTO.getValue("TNOMEN_AUTO_NUM");
		// Changes-M.S.Jayanthi-11/11/2009-chn-beg
		inover = revalDTO.getValue("TNOMEN_INLAND_OVERSEAS");
		// Changes-M.S.Jayanthi-11/11/2009-chn-end
		return true;
	}

	private boolean revalolcLcYear() {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("OLC_YEAR", olcLcYear);
		inputDTO.setValue("TNOMEN_NUM_CHOICE", num_choice);
		inputDTO.setValue("TNOMEN_AUTO_NUM", auto_num);
		inputDTO.setValue("USER_OPTION", muserOption);
		inputDTO.setValue("CBD", getM_CurrBusDate());
		inputDTO.setValue("OLC_BRN_CODE", olcBrnCode);
		inputDTO.setValue("OLC_TYPE", olcLcType);
		revalDTO = eolcvalinstance.olcYearkeypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtcontyear|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		} else {
			if ((muserOption.equalsIgnoreCase("A")) && (auto_num.equalsIgnoreCase("1"))) {
				correfno = revalDTO.getValue("CORR_REF_NUM");
				lastnumused = revalDTO.getValue("OLC_LAST_NUM_USED");
				Slflag = "YES";
			}
		}
		return true;
	}

	private boolean revalolcLcSl() {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("OLC_YEAR", olcLcYear);
		inputDTO.setValue("USER_OPTION", muserOption);
		inputDTO.setValue("OLC_SL", olcLcSl);
		inputDTO.setValue("OLC_BRN_CODE", olcBrnCode);
		inputDTO.setValue("OLC_TYPE", olcLcType);
		revalDTO = eolcvalinstance.olcSlnokeypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtcontsl|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		} else {
			if (muserOption.equalsIgnoreCase("A")) {
				correfno = revalDTO.getValue("CORR_REF_NUM");
				Slflag = "NO";
			} else {
				inputDTO.clearMap();
				revalDTO.clearMap();
				inputDTO.setValue("SQLToken", "Valolc1");
				String Args = olcBrnCode + "|" + olcLcType + "|" + olcLcYear + "|" + olcLcSl;
				inputDTO.setValue("Args", Args);
				inputDTO.setValue("DataTypes", "N|S|N|N");
				revalDTO = QueryManagerInstance.getInfo(inputDTO);
				if (revalDTO.getValue("Result").equalsIgnoreCase("RowPresent")) {
					branch = revalDTO.getValue("POST_TRAN_BRN");
					tranDate = revalDTO.getValue("POST_TRAN_DATE");
					batno = revalDTO.getValue("POST_TRAN_BATCH_NUM");
					muserOption = "M";
				} else if (revalDTO.getValue("Result").equalsIgnoreCase("RowNotPresent")) {
					muserOption = "A";
				}
			}
		}
		return true;
	}

	private boolean revalolcLcPresancDate() {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("CBD", getM_CurrBusDate());
		inputDTO.setValue("OLC_SANCTION_DATE", olcLcPresancDate);
		revalDTO = eolcvalinstance.olcPresanctionDatekeypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtpresanDate|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalolcLcPresancDaySl() {
		int fl = 1;
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("OLC_TYPE", olcLcType);
		inputDTO.setValue("OLC_YEAR", olcLcYear);
		inputDTO.setValue("USER_OPTION", muserOption);
		inputDTO.setValue("OLC_DAY_SER", olcLcPresancDaySl);
		inputDTO.setValue("OLC_BRANCH_CODE", olcBrnCode);
		inputDTO.setValue("OLC_ENTRY_DATE", olcLcPresancDate);
		inputDTO.setValue("OLC_ENTRY_DATE", olcLcPresancDate);
		// Changes M.S.JAYANTHI-Chn-11/11/2009 BEG
		inputDTO.setValue("TNOMEN_INLAND_OVERSEAS", inover);

		// Changes M.S.JAYANTHI-Chn-11/11/2009 end
		revalDTO = eolcvalinstance.olcSanctionDaySlkeypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtpresansl|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}
		intaccno = revalDTO.getValue("INTERNAL_ACNT_NUM");
		limitcurr = revalDTO.getValue("LCPS_LC_CURR");
		limitlineno = revalDTO.getValue("LCPS_LIMIT_LINE_NUM");
		return true;
	}

	private boolean revalolcLcDate() {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("CBD", getM_CurrBusDate());
		inputDTO.setValue("OLC_LC_DATE", olcLcDate);
		inputDTO.setValue("OLC_SANCTION_DATE", olcLcDate);
		revalDTO = eolcvalinstance.olcLcDatekeypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtLCDate|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalolcBenefCode() {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("EOLC_BENEF_CODE", olcBenefCode);
		// ADDED ON 02/08/2018 START
		inputDTO.setValue("PGM_ID", "EOLC");
		inputDTO.setValue("BRN_CODE", olcBrnCode);
		inputDTO.setValue("NOMEN", olcLcType);
		inputDTO.setValue("YEAR", olcLcYear);
		inputDTO.setValue("SERIAL", olcLcSl);
		inputDTO.setValue("PAYMENT_SERIAL", "0");
		// ADDED ON 02/08/2018 END
		revalDTO = eolcvalinstance.eolcBenefCodekeypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtBeneficiaryCode|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalolcBenefName() {

		int lencount = 0;
		if (olcBenefName.trim().equals(""))
			lencount = 0;
		if (olcBenefName.equalsIgnoreCase("")) {
			merrmsg = "MF:txtBeneficiaryName|Should not be blank";
			return false;
		}
		// changes in eolc on 30-May-2018 start
		else {
			lencount = olcBenefName.length();
			if (lencount > 35) {
				merrmsg = "MF:txtBeneficiaryName|Maximum Length 35. Entered " + olcBenefName.length() + " Characters";
				return false;
			}
		}
		// changes in eolc on 30-May-2018 end
		return true;
	}

	// B.Naveen Kumar Changes 21-11-07
	private boolean revalolcBenefAdd() {
		if (olcBenefAddr1.equalsIgnoreCase("")) {
			merrmsg = "MF:txtAddress1|Should not be blank";
			return false;
		} else {
			benefadd = olcBenefAddr1.split("\n");
			len = benefadd.length;
			address1 = benefadd[0].trim();
			address2 = ((benefadd.length > 1) ? benefadd[1].trim() : " ");
			address3 = ((benefadd.length > 2) ? benefadd[2].trim() : " ");
			address4 = ((benefadd.length > 3) ? benefadd[3].trim() : " ");
			address5 = ((benefadd.length > 4) ? benefadd[4].trim() : " ");
			if ((address1.length() > 35) || (address2.length() > 35) || (address3.length() > 35) || (address4.length() > 35) || (address5.length() > 35)) {

				merrmsg = "MF:txtAddress1|Only 35 Characters Allowed In a Line";
				return false;
			}
		}
		return true;
	}

	private boolean revalolcBenefCntryCode() {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("OLC_CNTRY_CODE", olcBenefCntryCode);
		revalDTO = eolcvalinstance.olcBeneficiaryCntrykeypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtCountryCode|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalolcLcIssBkCode() {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("OLC_BNK", olcLcIssBkCode);
		revalDTO = eolcvalinstance.olcBnkkeypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtLcIssuedthruBank|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalolcLcIssBrnCode() {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("OLC_BNK", olcLcIssBkCode);
		inputDTO.setValue("OLC_BRN", olcLcIssBrnCode);
		revalDTO = eolcvalinstance.olcBrnkeypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtLcIssuedthruBranch|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalolcLcIssBrnName() {
		if (olcLcIssBrnname.equalsIgnoreCase("")) {
			merrmsg = "MF:txtLcIssuedBranchName|Should not be blank";
			return false;
		}
		return true;
	}

	private boolean revalolcLcIssBrnAdd() {
		if (olcLcIssBrnAdd.equalsIgnoreCase("")) {
			merrmsg = "MF:txtAddress21|Should not be blank";
			return false;
		}
		return true;
	}

	private boolean revalolcLcIssBrnAdd1() {
		if (!olcLcIssBrnAdd.equalsIgnoreCase("")) {
			brnadd = olcLcIssBrnAdd.split("\n");
			brnlen = brnadd.length;
			brnadd1 = brnadd[0].trim();
			brnadd2 = ((brnadd.length > 1) ? brnadd[1].trim() : " ");
			brnadd3 = ((brnadd.length > 2) ? brnadd[2].trim() : " ");
			brnadd4 = ((brnadd.length > 3) ? brnadd[3].trim() : " ");
			brnadd5 = ((brnadd.length > 4) ? brnadd[4].trim() : " ");
			if ((brnadd1.length() > 35) || (brnadd2.length() > 35) || (brnadd3.length() > 35) || (brnadd4.length() > 35) || (brnadd5.length() > 35)) {

				merrmsg = "MF:txtAddress21|Only 35 Characters Allowed In a Line";
				return false;
			}
		}

		return true;

	}

	private boolean revalolcLcIssCntryCode() {
		inputDTO.clearMap();
		revalDTO.clearMap();
		int flag = 1;
		inputDTO.setValue("OLC_CNTRY_CODE", olcLcIssCntry);
		// Changes M.S.JAYANTHI-Chn-11/11/2009 BEG
		inputDTO.setValue("TNOMEN_INLAND_OVERSEAS", inover);
		// Changes M.S.JAYANTHI-Chn-11/11/2009 end
		revalDTO = eolcvalinstance.olcCntrykeypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtLcIssuedOncntry|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}

		return true;
	}

	private boolean revalolcLcIssThru() {
		if (olcLcAdvThru.equalsIgnoreCase("")) {
			merrmsg = "MF:lstAdThru|Select Option";
			return false;

		}
		return true;
	}

	private boolean revalolcLcCurrCode() {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("OLC_LC_CURR", olcLcCurrCode);
		revalDTO = eolcvalinstance.olcLcCurrkeypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtLCCurr|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalolcLcAmount() {
		double lcamt;
		if (olcLcAmount.equalsIgnoreCase("")) {
			merrmsg = "MF:txtLCAmt|Should not be blank";
			return false;
		} else {
			lcamt = Double.parseDouble(olcLcAmount);
		}
		if (lcamt == 0) {
			merrmsg = "MF:txtLCAmt|Should be > 0";
			return false;
		}
		return true;
	}

	private boolean revalolcPosDevia() {
		double pos;
		String s[] = null;

		if (olcPosDevAllwd.equalsIgnoreCase("")) {
			merrmsg = "MF:txtdeviationallow|Should not be blank";
			return false;
		} else {
			pos = Double.parseDouble(olcPosDevAllwd);
			s = olcPosDevAllwd.trim().split("\\.");
		}
		if (!(pos <= 100)) {
			merrmsg = "MF:txtdeviationallow|Should be <= 100";
			return false;
		}
		// changes on EOLC in 06-Jun-2018 start
		else if (olcAmtQualfr.trim().equals("3") && (pos - (int) pos) != 0) {
			merrmsg = "MF:txtdeviationallow|Decimal is not allowed ";
			return false;
		} else if (olcAmtQualfr.trim().equals("3") && s[0].length() > 2) {
			merrmsg = "MF:txtdeviationallow|Length should two digit ";
			return false;
		}
		// changes on EOLC in 06-Jun-2018 end
		return true;
	}

	private boolean revalolcNegDevia() {
		double neg;
		String s1[] = null;
		if (olcLcAmount.equalsIgnoreCase("")) {
			merrmsg = "MF:txtdeviationallow1|Should not be blank";
			return false;
		} else {
			neg = Double.parseDouble(olcNegDevAllwd);
			s1 = olcNegDevAllwd.trim().split("\\.");
		}
		if (!(neg <= 100)) {
			merrmsg = "MF:txtdeviationallow1|Should be <= 100";
			return false;
		}
		// changes on EOLC in 06-Jun-2018 start
		else if (olcAmtQualfr.trim().equals("3") && (neg - (int) neg) != 0) {
			merrmsg = "MF:txtdeviationallow1|Decimal is not allowed ";
			return false;
		} else if (olcAmtQualfr.trim().equals("3") && s1[0].length() > 2) {
			merrmsg = "MF:txtdeviationallow1|Length should two digit ";
			return false;
		}
		// changes on EOLC in 06-Jun-2018 end
		return true;
	}

	private boolean revalolcDeviaAmt() {
		double damt;
		if (olcDevAmount.equalsIgnoreCase("")) {
			merrmsg = "MF:txtDeviationAmt|Should not be blank";
			return false;
		} else {
			damt = Double.parseDouble(olcDevAmount);
		}
		if (!(damt >= 0)) {
			merrmsg = "MF:txtDeviationAmt|Should be >= 0";
			return false;
		}
		return true;
	}

	private boolean revalolcAmtQuali() {
		if (olcAmtQualfr.equalsIgnoreCase("")) {
			merrmsg = "MF:lstAmtquali|Select Option";
			return false;
		}
		return true;
	}

	private boolean revalAddiAmtsCovered() {
		if (olcAddAmtCovered.equalsIgnoreCase("")) {
			add1 = " ";
			add2 = " ";
			add3 = " ";
			add4 = " ";

		} else {
			addarr = olcAddAmtCovered.split("\n");
			len1 = addarr.length;
			add1 = addarr[0].trim();
			add2 = ((addarr.length > 1) ? addarr[1].trim() : " ");
			add3 = ((addarr.length > 2) ? addarr[2].trim() : " ");
			add4 = ((addarr.length > 3) ? addarr[3].trim() : " ");
			if ((add1.length() > 35) || (add2.length() > 35) || (add3.length() > 35) || (add4.length() > 35)) {

				merrmsg = "MF:txtAdditionalamtcover|Only 35 Characters Allowed In a Line";
				return false;
			}
		}
		return true;

	}

	private boolean revalolcTermsOfPrice() {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("TERMS_OF_PRICE", olcPriceTerms);
		revalDTO = eolcvalinstance.olcTermsOfPricekeypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtTermsOfprice|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalolcLastDateOfNego() {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("OLC_LC_DATE", olcLcDate);
		inputDTO.setValue("LAST_DATE", olcLastDateOfNeg);
		revalDTO = eolcvalinstance.olcLastDatekeypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtLastDateOfNego|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalShipmentPeriod() {
		if (olcShipmentPeriod.equalsIgnoreCase("")) {
			add11 = " ";
			add22 = " ";
			add33 = " ";
			add44 = " ";

		} else {
			shiparray = olcShipmentPeriod.split("\n");
			len2 = shiparray.length;// changes in EOLC on 29/05/2018
			add11 = shiparray[0].trim();
			add22 = ((shiparray.length > 1) ? shiparray[1].trim() : " ");
			add33 = ((shiparray.length > 2) ? shiparray[2].trim() : " ");
			add44 = ((shiparray.length > 3) ? shiparray[3].trim() : " ");
			if ((add11.length() > 35) || (add22.length() > 35) || (add33.length() > 35) || (add44.length() > 35)) {

				merrmsg = "MF:txtShipmentperod|Only 35 Characters Allowed In a Line";
				return false;
			}
		}
		return true;

	}

	private boolean revalPresentationDtl() {
		int _presentDay = 0;
		if (!LC_PER_PRESENTATION_DAY.trim().equals("")) {
			_presentDay = Integer.parseInt(LC_PER_PRESENTATION_DAY);
		}
		if (_presentDay > 0) // changes in eolc in 28-may-2018
		{
			if (olcPresentDetail.trim().equals("")) {
				address11 = " ";
				address22 = " ";
				address33 = " ";

				merrmsg = "MF:txtpresentationdetails|Should not Be Blank";
				return false;

			} else {
				presentarray = olcPresentDetail.split("\n");
				len1 = presentarray.length;
				address11 = presentarray[0].trim();
				address22 = ((presentarray.length > 1) ? presentarray[1].trim() : " ");
				address33 = ((presentarray.length > 2) ? presentarray[2].trim() : " ");
				if ((address11.length() > 35) || (address22.length() > 35) || (address33.length() > 35)) {

					merrmsg = "MF:txtpresentationdetails|Only 35 Characters Allowed In a Line";
					return false;
				}
			}
		}

		return true;

	}

	private boolean revalolcNoOfTenors() {
		int drawdown;
		if (olcNofTenors.equalsIgnoreCase("")) {
			merrmsg = "MF:txtDrawDowns|Should not be blank";
			return false;
		} else {
			drawdown = Integer.parseInt(olcNofTenors);
		}
		if (!(drawdown > 0)) {
			merrmsg = "MF:txtDrawDowns|should be >0 and <= 5";
			return false;
		} else if (!(drawdown <= 5)) {
			merrmsg = "MF:txtDrawDowns|should be >0 and <= 5";
			return false;
		}
		return true;
	}

	private boolean revalolcConrateToLimitCurr() {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("OLC_LC_CURR", olcLcCurrCode);
		inputDTO.setValue("OLC_LIMIT_CURR", limitcurr);
		inputDTO.setValue("TOTAL", olctotalAmt);
		inputDTO.setValue("OLC_CONV_RATE_LIM_CURR", olcConvRateLimCurr);
		inputDTO.setValue("OLC_LIMIT_LINE_NO", limitlineno);
		inputDTO.setValue("OLC_CUST_NO", olcCustNo);
		inputDTO.setValue("OLC_BRANCH_CODE", olcBrnCode);
		inputDTO.setValue("OLC_INTERNAL_ACC_NO", intaccno);
		// Vinoth S Changes on 23-Dec-2010 Beg
		inputDTO.setValue("TRAN_DATE", olcLcDate);
		inputDTO.setValue("TYPE", "N");
		// Vinoth S Changes on 23-Dec-2010 End
		revalDTO = eolcvalinstance.olcConvRateLimCurrkeypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtConRateToLimitCurr|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}

		if (revalDTO.getValue("OUTSTD_AMT").trim().equals(""))
			outstng_amt = 0.0;
		else
			outstng_amt = Double.parseDouble(revalDTO.getValue("OUTSTD_AMT"));
		if (revalDTO.getValue("PEND_AMT").trim().equals(""))
			pendng_amt = 0.0;
		else
			pendng_amt = Double.parseDouble(revalDTO.getValue("PEND_AMT"));
		// ADDED ON 01/10/2018 START
		if (revalDTO.getValue("AMT_AGNST_CURR").trim().equals(""))
			amt_agnst_curr = 0.0;
		else
			amt_agnst_curr = Double.parseDouble(revalDTO.getValue("AMT_AGNST_CURR"));
		// ADDED ON 01/10/2018 END
		return true;
	}

	private boolean revalolclimitvalue() {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("OLC_BRN_CODE", olcBrnCode);
		inputDTO.setValue("OLC_DAY_SERIAL", olcLcPresancDaySl);
		inputDTO.setValue("OLC_ENTRY_DATE", olcLcPresancDate);
		inputDTO.setValue("OLC_OUTSANDING_AMT", String.valueOf(outstng_amt));
		inputDTO.setValue("OLC_LC_PENDING_AMT", String.valueOf(_roundoff));// MODIFIED
		// ON
		// 01/10/2018
		revalDTO = eolcvalinstance.olclimitvalue(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtConRateToLimitCurr|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalolcMaginCurr() {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("OLC_LC_CURR", olcMarginCurr);
		revalDTO = eolcvalinstance.olcLcCurrkeypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtmargincurr|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalcomp() {
		if (translmnt != null) {
			if (!translmnt.isValid()) {
				merrmsg = translmnt.getErrMsg();
				return false;
			} else
				return true;
		} else
			return true;
	}

	// Changes P.Subramani-Chn-19-06-2008 Beg
	private boolean revalchargecode() {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("OLC_LC_CURR", olcLcCurrCode);
		inputDTO.setValue("OLC_LC_TYPE", olcLcType);
		revalDTO = eolcvalinstance.olcChargeskeypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtusnchgsamt1|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}
		usancechgcode = revalDTO.getValue("TRCHG_USANCE_CHGCD");
		commchgcode = revalDTO.getValue("TRCHG_COMMITMNT_CHGCD");
		return true;
	}

	// Changes P.Subramani-Chn-19-06-2008 End

	public TFMChargesDetails getTfmchargesdetail() {
		return tfmchargesdetail;
	}

	public void setTfmchargesdetail(TFMChargesDetails tfmchargesdetail) {
		this.tfmchargesdetail = tfmchargesdetail;
	}

	public TFMCRatesDetails getTfmcratesdetail() {
		return tfmcratesdetail;
	}

	public void setTfmcratesdetail(TFMCRatesDetails tfmcratesdetail) {
		this.tfmcratesdetail = tfmcratesdetail;
	}

	public String getOlcLcSanctionDate() {
		return olcLcSanctionDate;
	}

	public void setOlcLcSanctionDate(String olcLcSanctionDate) {
		this.olcLcSanctionDate = olcLcSanctionDate;
	}

	public String getOlcAmtQualfr() {
		return olcAmtQualfr;
	}

	public void setOlcAmtQualfr(String olcAmtQualfr) {
		this.olcAmtQualfr = olcAmtQualfr;
	}

	public boolean isOlcWithinValidateLc() {
		return olcWithinValidateLc;
	}

	public void setOlcWithinValidateLc(boolean olcWithinValidateLc) {
		this.olcWithinValidateLc = olcWithinValidateLc;
		if (olcWithinValidateLc) {
			olcWithinValidateLcval = "1";
		} else {
			olcWithinValidateLcval = "0";
		}
	}

	public boolean isOlcUsanceInterest() {
		return olcUsanceInterest;
	}

	public void setOlcUsanceInterest(boolean olcUsanceInterest) {
		this.olcUsanceInterest = olcUsanceInterest;
		if (olcUsanceInterest) {
			olcUsanceInterestval = "1";
		} else {
			olcUsanceInterestval = "0";
		}
	}

	public boolean isOlcLcUnderContract() {
		return olcLcUnderContract;
	}

	public void setOlcLcUnderContract(boolean olcLcUnderContract) {
		this.olcLcUnderContract = olcLcUnderContract;
		if (olcLcUnderContract) {
			olcLcUnderContractval = "1";
		} else {
			olcLcUnderContractval = "0";
		}

	}

	public String getOlcCustNo() {
		return olcCustNo;
	}

	public void setOlcCustNo(String olcCustNo) {
		this.olcCustNo = olcCustNo;
	}

	public String getOlctotalAmt() {
		return olctotalAmt;
	}

	public void setOlctotalAmt(String olctotalAmt) {
		this.olctotalAmt = olctotalAmt;
	}

	public String getOlcMarginCurr() {
		return olcMarginCurr;
	}

	public void setOlcMarginCurr(String olcMarginCurr) {
		this.olcMarginCurr = olcMarginCurr;
	}

	public TranStlmntPostDetails getTranslmnt() {
		return translmnt;
	}

	public void setTranslmnt(TranStlmntPostDetails translmnt) {
		this.translmnt = translmnt;
	}

	public String getOlcLcCorrrefNo() {
		return olcLcCorrrefNo;
	}

	public void setOlcLcCorrrefNo(String olcLcCorrrefNo) {
		this.olcLcCorrrefNo = olcLcCorrrefNo;
	}

	public boolean isOlcDftToBeDrawnOn() {
		return olcDftToBeDrawnOn;
	}

	public void setOlcDftToBeDrawnOn(boolean olcDftToBeDrawnOn) {
		this.olcDftToBeDrawnOn = olcDftToBeDrawnOn;
		if (olcDftToBeDrawnOn) {
			olcDftToBeDrawnOnval = "1";
		} else {
			olcDftToBeDrawnOnval = "0";
		}
	}

	public boolean isOlcPrimeRateClauseReq() {
		return olcPrimeRateClauseReq;
	}

	public void setOlcPrimeRateClauseReq(boolean olcPrimeRateClauseReq) {
		this.olcPrimeRateClauseReq = olcPrimeRateClauseReq;
		if (olcPrimeRateClauseReq) {
			olcPrimeRateClauseReqval = "1";
		} else {
			olcPrimeRateClauseReqval = "0";
		}
	}

	public String getOlcAddAmtCovered() {
		return olcAddAmtCovered;
	}

	public void setOlcAddAmtCovered(String olcAddAmtCovered) {
		this.olcAddAmtCovered = olcAddAmtCovered;
	}

	public String getOlcShipmentPeriod() {
		return olcShipmentPeriod;
	}

	public void setOlcShipmentPeriod(String olcShipmentPeriod) {
		this.olcShipmentPeriod = olcShipmentPeriod;
	}

	public String getOlcPresentDetail() {
		return olcPresentDetail;
	}

	public void setOlcPresentDetail(String olcPresentDetail) {
		this.olcPresentDetail = olcPresentDetail;
	}

	public String getOlcMarginper() {
		return olcMarginper;
	}

	public void setOlcMarginper(String olcMarginper) {
		this.olcMarginper = olcMarginper;
	}

	public String getOlcEolMarginper() {
		return olcEolMarginper;
	}

	public void setOlcEolMarginper(String olcEolMarginper) {
		this.olcEolMarginper = olcEolMarginper;
	}

	public String getOlcMarginAmt() {
		return olcMarginAmt;
	}

	public void setOlcMarginAmt(String olcMarginAmt) {
		this.olcMarginAmt = olcMarginAmt;
	}

	public String getOlcEolMarginAmt() {
		return olcEolMarginAmt;
	}

	public void setOlcEolMarginAmt(String olcEolMarginAmt) {
		this.olcEolMarginAmt = olcEolMarginAmt;
	}

	public String getOlcCashMargin() {
		return olcCashMargin;
	}

	public void setOlcCashMargin(String olcCashMargin) {
		this.olcCashMargin = olcCashMargin;
	}

	public String getOlcEolCashMargin() {
		return olcEolCashMargin;
	}

	public void setOlcEolCashMargin(String olcEolCashMargin) {
		this.olcEolCashMargin = olcEolCashMargin;
	}

	public String getOlcMarginType() {
		return olcMarginType;
	}

	public void setOlcMarginType(String olcMarginType) {
		this.olcMarginType = olcMarginType;
	}

	public String getOlcExcessOverLimit() {
		return olcExcessOverLimit;
	}

	public void setOlcExcessOverLimit(String olcExcessOverLimit) {
		this.olcExcessOverLimit = olcExcessOverLimit;
	}

	private boolean revallcpsGrid1() {
		int row = 0;
		String slabserial = "";
		String tenortype = "";
		String tenoramt = "";
		String usancedays = "";
		String usanceperiod = "";
		String otherdate = "";
		String othdateforup = "";
		String interestrate = "";
		String intcurr = "";
		String usanceamt = "";
		String docdel = "";
		String prevtenortype = null;

		if (mxmlstr1.equalsIgnoreCase("")) {
			merrmsg = "MF:gridEoladd|Please press F12 and then save|" + 1 + "|ttype";
			xmlerrmsg = "MF:gridEoladd|Please press F12 and then save|" + 1 + "|ttype";
			return false;
		}
		try {
			revallcpsGrid1.setXMLFormat("OLCTENORS", "panacea.common", mxmlstr1);
		}

		catch (Exception e) {
			e.printStackTrace();
		}

		if ((revallcpsGrid1.getRowcount()) < 1) {
			merrmsg = "MF:gridEoladd|Atleast One row Should Be Given|" + 1 + "|ttype";
			xmlerrmsg = "MF:gridEoladd|Atleast One row Should Be Given|" + 1 + "|ttype";
			return false;

		}

		for (row = 0; row < revallcpsGrid1.getRowcount(); row++) {
			slabserial = String.valueOf(row + 1);
			tenortype = revallcpsGrid1.GetValue(row, "OLCT_TENOR_TYPE");
			tenoramt = revallcpsGrid1.GetValue(row, "OLCT_TENOR_AMT");
			usancedays = revallcpsGrid1.GetValue(row, "OLCT_USANCE_PERD");
			usanceperiod = revallcpsGrid1.GetValue(row, "OLCT_USANCE_FROM");
			otherdate = revallcpsGrid1.GetValue(row, "OLCT_OTHER_DATE_DESC");
			othdateforup = revallcpsGrid1.GetValue(row, "OLCT_OTHER_DATE_START_FROM");
			interestrate = revallcpsGrid1.GetValue(row, "OLCT_USANCE_INT_RATE");
			usanceamt = revallcpsGrid1.GetValue(row, "OLCT_USANCE_INT_AMT");
			docdel = revallcpsGrid1.GetValue(row, "OLCT_DOC_DELIVERY");

			if (Integer.parseInt(slabserial) > 1) {
				prevtenortype = revallcpsGrid1.GetValue(row - 1, "OLCT_TENOR_TYPE");
			}

			if (revallcpsGrid1.GetValue(row, "OLCT_TENOR_TYPE").equalsIgnoreCase("")) {
				merrmsg = "MF:gridEoladd|Select Option|" + (row + 1) + "|ttype";
				xmlerrmsg = "MF:gridEoladd|Select Option|" + (row + 1) + "|ttype";
				return false;
			}

			if (tenortype.equalsIgnoreCase("S")) {
				if (!(usancedays.equalsIgnoreCase("0"))) {
					merrmsg = "MF:gridEoladd|Usance Days Should be Zero|" + (row + 1) + "|udays";
					xmlerrmsg = "MF:gridEoladd|Usance Days Should be Zero|" + (row + 1) + "|udays";
					return false;
				}
				// Changes P.Subramani-Chn-19/08/2008
				else if (!(usanceamt.equalsIgnoreCase("0.00"))) {
					merrmsg = "MF:gridEoladd|Usance Interest Amount Should be Zero|" + (row + 1) + "|intamt";
					xmlerrmsg = "MF:gridEoladd|Usance Interest Amount Should be Zero|" + (row + 1) + "|intamt";
					return false;
				} else if (!(docdel.equalsIgnoreCase("2"))) {
					merrmsg = "MF:gridEoladd|Document Delivery Should be DP|" + (row + 1) + "|docdel";
					xmlerrmsg = "MF:gridEoladd|Document Delivery Should be DP|" + (row + 1) + "|docdel";
					return false;
				}
			}

			if (Integer.parseInt(slabserial) > 1) {
				// NaveenNaidu-Chennai-29/11/2007-beg
				if (tenortype.equalsIgnoreCase("S")) {
					if (prevtenortype.equalsIgnoreCase("S")) {
						merrmsg = "MF:gridEoladd|Sight Should not be Duplicated|" + (row + 1) + "|ttype";
						xmlerrmsg = "MF:gridEoladd|Sight Should not be Duplicated|" + (row + 1) + "|ttype";
						return false;
					}
				}// NaveenNaidu-Chennai-29/11/2007-end
			}

			if (!tenoramt.equalsIgnoreCase("")) {
				revalDTO.clearMap();
				inputDTO.clearMap();
				revalDTO.setValue("TENOR_AMT", tenoramt);
				revalDTO.setValue("LC_AMOUNT", olcLcAmount);
				revalDTO.setValue("DRAW_DOWNS", olcNofTenors);
				revalDTO.setValue("TOTAL_TEN_AMT", olcLcTotalTenoramt);
				revalDTO.setValue("NO_OF_ROWS", slabserial);
				inputDTO = eolcvalinstance.olcTenorAmtkeypress(revalDTO);
				if (!inputDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
					merrmsg = "MF:gridEoladd|" + inputDTO.getValue(ErrorKey).toString();
					xmlerrmsg = "MF:gridEoladd|" + inputDTO.getValue(ErrorKey).toString();
					return false;
				}
			}

			if (tenortype.equalsIgnoreCase("U")) {
				if (revallcpsGrid1.GetValue(row, "LCPSTENOR_USANCE_DAYS").equalsIgnoreCase("")) {
					merrmsg = "MF:gridEoladd|Should not be blank|" + (row + 1) + "|udays";
					xmlerrmsg = "MF:gridEoladd|Should not be blank|" + (row + 1) + "|udays";
					return false;
				} else if (revallcpsGrid1.GetValue(row, "LCPSTENOR_USANCE_DAYS").equalsIgnoreCase("0")) {
					merrmsg = "MF:gridEoladd|Should not be zero|" + (row + 1) + "|udays";
					xmlerrmsg = "MF:gridEoladd|Should not be zero|" + (row + 1) + "|udays";
					return false;
				}
			}

			if (revallcpsGrid1.GetValue(row, "LCPSTENOR_DOC_DELIVERY").equalsIgnoreCase("")) {
				merrmsg = "MF:gridEoladd|Should not be blank|" + (row + 1) + "|docdel";
				xmlerrmsg = "MF:gridEoladd|Should not be blank|" + (row + 1) + "|docdel";
				return false;
			}
		}

		return true;
	}

	// treasury changes by PRASHANTH chn 05-08-2017
	private boolean SetTsryStatus() {
		CommonValidator comnval = new CommonValidator();
		try {
			inputDTO.clearMap();
			inputDTO.setValue("BRN_CODE", getM_BranchCode());
			inputDTO.setValue("PROGRAM_ID", "EOLC");
			revalDTO = comnval.validateProgramEnabledInterface(inputDTO);
			if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
				merrmsg = "MF:txtinstrumentnum|" + revalDTO.getValue(ErrorKey).toString();
				return false;
			} else {
				tsry_enabled = revalDTO.getValue("TSRY_ENABLED");
			}
		} catch (Exception e) {
			merrmsg = "Error in SetTsryStatus";
		}

		return true;
	}

	// treasury changes by PRASHANTH chn 05-08-2017

	// changes in eolc on 27-may-2018 start
	private boolean revalformOfCredit() {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("LC_DOC_CREDIT", LC_FORM_OF_DOC_CREDIT);
		revalDTO = eolcvalinstance.Olc_Doc_CreditKeypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:lstcredit|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalRefToPreAdvice() {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("LC_REF_PRE_ADVICE", LC_REFERENCE_TO_PREADVICE);
		revalDTO = eolcvalinstance.Olc_Reference_To_PreAdvice_Keypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtRefPreAdv|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalAppRuleType() {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("LC_APP_RULE_TYPE", LC_APPLICABLE_RULES);
		revalDTO = eolcvalinstance.Olc_Applicable_RuleKeypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:lstAppRule|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalApplicantBankOurType() {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("LC_APPLICANT_REQ", (LC_APPLICANT_REQ == true) ? "1" : "0");
		inputDTO.setValue("LC_APPLICANT", LC_APPLICANT);
		revalDTO = eolcvalinstance.Olc_Applicable_BankOurTypeKeypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:lstAppBank|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalBankType(int chkbox, String type, int fieldno) {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("LC_FIELD_NO", String.valueOf(fieldno));
		inputDTO.setValue("LC_CHKBOX_REQ", String.valueOf(chkbox));
		inputDTO.setValue("LC_DROPDWN_TYPE", type);
		revalDTO = eolcvalinstance.Olc_ApplicantBankTypeKeypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			if (fieldno == 1)
				merrmsg = "MF:lstBICdtl|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 2)
				merrmsg = "MF:lstAvlBICdtl|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 3)
				merrmsg = "MF:lstDrwBICdtl|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 4)
				merrmsg = "MF:lstReimbBank|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 5)
				merrmsg = "MF:lstAdviseBank|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 6)
				merrmsg = "MF:lstReimbcfmBank|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalAvailableWithBankType() {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("LC_AVL_WITH", LC_AVAILABLE_WITH_CODETYP);
		revalDTO = eolcvalinstance.Olc_AvailableWithKeypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:lstAvl|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalSwiftBankBic(int chkbox, String type, String bankbic, int fieldno) {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("LC_CHKBOX_REQ", String.valueOf(chkbox));
		inputDTO.setValue("LC_DROPDWN_TYPE", type);
		inputDTO.setValue("LC_BIC_CODE", bankbic);
		revalDTO = eolcvalinstance.Olc_ApplicantBicKeypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			if (fieldno == 1)
				merrmsg = "MF:txtAppBicCode|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 2)
				merrmsg = "MF:txtAvlBicCode|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 3)
				merrmsg = "MF:txtDrwBicCode|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 4)
				merrmsg = "MF:txtReimBicCode|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 5)
				merrmsg = "MF:txtAdviseBicCode|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 6)
				merrmsg = "MF:txtReimcfmBicCode|" + revalDTO.getValue(ErrorKey).toString();

			return false;
		}
		return true;
	}

	private boolean revalSwiftBranchCode(int chkbox, String type, String bankbrn, int fieldno) {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("LC_CHKBOX_REQ", String.valueOf(chkbox));
		inputDTO.setValue("LC_DROPDWN_TYPE", type);
		inputDTO.setValue("LC_BRANCH_CODE", bankbrn);
		revalDTO = eolcvalinstance.Olc_ApplicantBankBrachCodeKeypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			if (fieldno == 1)
				merrmsg = "MF:txtAppBicBrn|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 2)
				merrmsg = "MF:txtAvlBicBrn|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 3)
				merrmsg = "MF:txtDrwBicBrn|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 4)
				merrmsg = "MF:txtReimBicBrn|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 5)
				merrmsg = "MF:txtAdviseBicBrn|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 6)
				merrmsg = "MF:txtReimcfmBicBrn|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalSwiftBankName(int chkbox, String type, String bnkName, int fieldno) {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("LC_CHKBOX_REQ", String.valueOf(chkbox));
		inputDTO.setValue("LC_DROPDWN_TYPE", type);
		inputDTO.setValue("LC_BANK_NAME", bnkName);
		revalDTO = eolcvalinstance.Olc_ApplicantBankNameKeypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			if (fieldno == 1)
				merrmsg = "MF:txtAppBankName|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 2)
				merrmsg = "MF:txtAvlBankName|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 3)
				merrmsg = "MF:txtDrwBankName|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 4)
				merrmsg = "MF:txtReimBankName|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 5)
				merrmsg = "MF:txtAdviseBankName|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 6)
				merrmsg = "MF:txtcfmReimBankName|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalSwiftBankAddress(int chkbox, String type, String bankadrres, int fieldno) {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("LC_CHKBOX_REQ", String.valueOf(chkbox));
		inputDTO.setValue("LC_DROPDWN_TYPE", type);
		inputDTO.setValue("LC_BANK_ADDRESS", bankadrres);
		revalDTO = eolcvalinstance.Olc_ApplicantBankAddressKeypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			if (fieldno == 1)
				merrmsg = "MF:txtAppAddress|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 2)
				merrmsg = "MF:txtAvlAddress|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 3)
				merrmsg = "MF:txtDrwAddress|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 4)
				merrmsg = "MF:txtReimAddress|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 5)
				merrmsg = "MF:txtAdviseAddress|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 6)
				merrmsg = "MF:txtcfmReimAddress|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}
		if (!(bankadrres.equalsIgnoreCase(""))) {
			bank_addr = bankadrres.split("\n");
			a1 = bank_addr[0].trim();
			a2 = ((bank_addr.length > 1) ? bank_addr[1].trim() : " ");
			a3 = ((bank_addr.length > 2) ? bank_addr[2].trim() : " ");
			a4 = ((bank_addr.length > 3) ? bank_addr[3].trim() : " ");
			a5 = ((bank_addr.length > 4) ? bank_addr[4].trim() : " ");
			if ((a1.length() > 35) || (a2.length() > 35) || (a3.length() > 35) || (a4.length() > 35) || (a5.length() > 35)) {
				if (fieldno == 1)
					merrmsg = "MF:txtAppAddress|Only 35 Characters Allowed In A Line";
				if (fieldno == 2)
					merrmsg = "MF:txtAvlAddress|Only 35 Characters Allowed In A Line";
				if (fieldno == 3)
					merrmsg = "MF:txtDrwAddress|Only 35 Characters Allowed In A Line";
				if (fieldno == 4)
					merrmsg = "MF:txtReimAddress|Only 35 Characters Allowed In A Line";
				if (fieldno == 5)
					merrmsg = "MF:txtAdviseAddress|Only 35 Characters Allowed In A Line";
				if (fieldno == 6)
					merrmsg = "MF:txtcfmReimAddress|Only 35 Characters Allowed In A Line";
				return false;
			}
		}
		return true;
	}

	private boolean revalSwiftCountryCode(int chkbox, String type, String cntrycode, int fieldno) {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("LC_CHKBOX_REQ", String.valueOf(chkbox));
		inputDTO.setValue("LC_DROPDWN_TYPE", type);
		inputDTO.setValue("LC_BANK_COUNTRY_CODE", cntrycode);
		inputDTO.setValue("LC_TYPE", olcLcType);
		revalDTO = eolcvalinstance.Olc_ApplicantBankCntryCodeKeypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			if (fieldno == 1)
				merrmsg = "MF:txtAppCntry|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 2)
				merrmsg = "MF:txtAvlCntry|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 3)
				merrmsg = "MF:txtDrwCntry|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 4)
				merrmsg = "MF:txtReimCntry|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 5)
				merrmsg = "MF:txtAdviseCntry|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 6)
				merrmsg = "MF:txtcfmReimCntry|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalSwiftRoutingId(int chkbox, String type, String Rout_Id, int fieldno) {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("LC_CHKBOX_REQ", String.valueOf(chkbox));
		inputDTO.setValue("LC_DROPDWN_TYPE", type);
		inputDTO.setValue("LC_ROUNTING_ID", Rout_Id);
		revalDTO = eolcvalinstance.Olc_ApplicantAccountNumberKeypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			if (fieldno == 1)
				merrmsg = "MF:txtAppAcnt|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 2)
				merrmsg = "MF:txtAvlAcnt|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 3)
				merrmsg = "MF:txtDrwAcnt|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 4)
				merrmsg = "MF:txtReimAcnt|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 5)
				merrmsg = "MF:txtAdviseAcnt|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 6)
				merrmsg = "MF:txtcfmReimAcnt|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalSwiftDraftsAt() {
		drafts = null;
		if (!(LC_DRAFTS_AT.equalsIgnoreCase(""))) {
			drafts = LC_DRAFTS_AT.split("\n");
			a1 = drafts[0].trim();
			a2 = ((drafts.length > 1) ? drafts[1].trim() : " ");
			a3 = ((drafts.length > 2) ? drafts[2].trim() : " ");
			if ((a1.length() > 35) || (a2.length() > 35) || (a3.length() > 35)) {
				merrmsg = "MF:txtDraft|Only 35 Characters Allowed In A Line";
				return false;
			}
		}
		return true;
	}

	private boolean revalSwiftMixedPaymentDetails() {
		mixed_pay_details = null;
		if (LC_AVAILABLE_WITH_TYPE.trim().equals("3")) {
			if (!(LC_MIXED_PAY_DETAILS.equalsIgnoreCase(""))) {
				mixed_pay_details = LC_MIXED_PAY_DETAILS.split("\n");
				a1 = mixed_pay_details[0].trim();
				a2 = ((mixed_pay_details.length > 1) ? mixed_pay_details[1].trim() : " ");
				a3 = ((mixed_pay_details.length > 2) ? mixed_pay_details[2].trim() : " ");
				a4 = ((mixed_pay_details.length > 3) ? mixed_pay_details[3].trim() : " ");
				if ((a1.length() > 35) || (a2.length() > 35) || (a3.length() > 35) || (a4.length() > 35)) {
					merrmsg = "MF:txtMixedPaydtl|Only 35 Characters Allowed In A Line";
					return false;
				}
			}
		}

		return true;
	}

	private boolean revalSwiftDeferredPaymentDetails() {
		def_pay_details = null;
		if (LC_AVAILABLE_WITH_TYPE.trim().equals("2")) {
			if (!(LC_DEFERRED_PAY_DETAILS.equalsIgnoreCase(""))) {
				def_pay_details = LC_DEFERRED_PAY_DETAILS.split("\n");
				a1 = def_pay_details[0].trim();
				a2 = ((def_pay_details.length > 1) ? def_pay_details[1].trim() : " ");
				a3 = ((def_pay_details.length > 2) ? def_pay_details[2].trim() : " ");
				a4 = ((def_pay_details.length > 3) ? def_pay_details[3].trim() : " ");
				if ((a1.length() > 35) || (a2.length() > 35) || (a3.length() > 35) || (a4.length() > 35)) {
					merrmsg = "MF:txtDeferPaydtl|Only 35 Characters Allowed In A Line";
					return false;
				}
			}
		}

		return true;
	}

	private boolean revalSwiftPlaceOfTakingCharge() {
		if (!LC_PLACE_OF_TAKING_IN_CHARGE.trim().equals("")) {
			if ((LC_PLACE_OF_TAKING_IN_CHARGE.length() > 65)) {
				merrmsg = "MF:txtTakCharge|Only 65 Characters Allowed In A Line";
				return false;
			}
		}

		return true;
	}

	private boolean revalSwiftPortOfLoading() {
		if (!LC_PORT_OF_LOADING.trim().equals("")) {
			if ((LC_PORT_OF_LOADING.length() > 65)) {
				merrmsg = "MF:txtPortLoad|Only 65 Characters Allowed In A Line";
				return false;
			}
		}

		return true;
	}

	private boolean revalSwiftPortOfDischarge() {
		if (!LC_PORT_OF_DISCHARGE.trim().equals("")) {
			if ((LC_PORT_OF_DISCHARGE.length() > 65)) {
				merrmsg = "MF:txtPortDis|Only 65 Characters Allowed In A Line";
				return false;
			}
		}

		return true;
	}

	private boolean revalSwiftPortOfFinalDestination() {
		if (!LC_PLACE_OF_FINAL_DEST.trim().equals("")) {
			if ((LC_PLACE_OF_FINAL_DEST.length() > 65)) {
				merrmsg = "MF:txtPortDest|Only 65 Characters Allowed In A Line";
				return false;
			}
		}

		return true;
	}

	private boolean revalSwiftSipmentPeriod() {
		shpmnt_prd = null;

		if (!(LC_SHIPMENT_PERIOD.equalsIgnoreCase(""))) {
			shpmnt_prd = LC_SHIPMENT_PERIOD.split("\n");
			a1 = shpmnt_prd[0].trim();
			a2 = ((shpmnt_prd.length > 1) ? shpmnt_prd[1].trim() : " ");
			a3 = ((shpmnt_prd.length > 2) ? shpmnt_prd[2].trim() : " ");
			a4 = ((shpmnt_prd.length > 3) ? shpmnt_prd[3].trim() : " ");
			a5 = ((shpmnt_prd.length > 4) ? shpmnt_prd[4].trim() : " ");
			a6 = ((shpmnt_prd.length > 5) ? shpmnt_prd[5].trim() : " ");
			if ((a1.length() > 65) || (a2.length() > 65) || (a3.length() > 65) || (a4.length() > 65) || (a5.length() > 65) || (a6.length() > 65)) {
				merrmsg = "MF:txtShipPeriod|Only 65 Characters Allowed In A Line";
				return false;
			}
		}

		return true;
	}

	private boolean revalSwiftDescriptionOfGoodsAndServices1() {

		if (LC_DESC_GOODS_SER1.length() == 0 && LC_DESC_GOODS_SER2.length() > 0) {
			merrmsg = "MF:txtDesGood1|Should  not be blank";
			return false;
		} else if (LC_DESC_GOODS_SER1.length() == 0 && LC_DESC_GOODS_SER3.length() > 0) {
			merrmsg = "MF:txtDesGood1|Should  not be blank";
			return false;
		}
		if (LC_DESC_GOODS_SER1.length() > 6500) {
			merrmsg = "MF:txtDesGood1|Maximum 6500 characters. Entered " + LC_DESC_GOODS_SER1.length() + " characters";
			return false;
		}
		if (!LC_DESC_GOODS_SER1.trim().equalsIgnoreCase("")) {
			boolean result1 = lineNumberValidation(LC_DESC_GOODS_SER1, 1);
			if (result1) {

				inputDTO.clearMap();
				inputDTO.setValue("OLC_TYPE", olcLcType);
				inputDTO.setValue("OLC_YEAR", olcLcYear);
				inputDTO.setValue("OLC_DAY_SER", olcLcPresancDaySl);
				inputDTO.setValue("OLC_BRANCH_CODE", olcBrnCode);
				inputDTO.setValue("OLC_ENTRY_DATE", olcLcPresancDate);
				inputDTO.setValue("OLC_CLOB", LC_DESC_GOODS_SER1);
				inputDTO.setValue("OLC_CUST_NO", olcCustNo);
				inputDTO.setValue("OLC_COLUMNNAME", "LC_DESC_GOODS_SER1");

				if (excludespecialChar(inputDTO, 1))
					LC_DESC_GOODS_SER1 = temp_str;
				else
					return false;
			} else
				return false;
		}
		return true;
	}

	private boolean revalSwiftDescriptionOfGoodsAndServices2() {
		int _good1 = LC_DESC_GOODS_SER1.split("\n").length;
		if (LC_DESC_GOODS_SER1.length() > 0) {
			if (LC_DESC_GOODS_SER1.length() < 6500 && LC_DESC_GOODS_SER2.length() > 0 && _good1 > 100) {
				merrmsg = "MF:txtDesGood1|Maximum 6500 characters. Entered " + LC_DESC_GOODS_SER1.length() + " characters";
				return false;
			}
			if (LC_DESC_GOODS_SER2.length() == 0 && LC_DESC_GOODS_SER3.length() > 0) {
				merrmsg = "MF:txtDesGood2|Should  not be blank";
				return false;
			}

			if (LC_DESC_GOODS_SER2.length() > 6500) {
				merrmsg = "MF:txtDesGood2|Maximum 6500 characters. Entered " + LC_DESC_GOODS_SER2.length() + " characters";
				return false;
			}
		}
		if (!LC_DESC_GOODS_SER2.trim().equalsIgnoreCase("")) {
			boolean result1 = lineNumberValidation(LC_DESC_GOODS_SER2, 2);
			if (result1) {

				inputDTO.clearMap();
				inputDTO.setValue("OLC_TYPE", olcLcType);
				inputDTO.setValue("OLC_YEAR", olcLcYear);
				inputDTO.setValue("OLC_DAY_SER", olcLcPresancDaySl);
				inputDTO.setValue("OLC_BRANCH_CODE", olcBrnCode);
				inputDTO.setValue("OLC_ENTRY_DATE", olcLcPresancDate);
				inputDTO.setValue("OLC_CLOB", LC_DESC_GOODS_SER2);
				inputDTO.setValue("OLC_CUST_NO", olcCustNo);
				inputDTO.setValue("OLC_COLUMNNAME", "LC_DESC_GOODS_SER2");

				if (excludespecialChar(inputDTO, 2))
					LC_DESC_GOODS_SER2 = temp_str;
				else
					return false;
			} else
				return false;
		}

		return true;
	}

	private boolean lineNumberValidation(String input, int fieldno) {
		if (!input.trim().equals("")) {
			int startindex = input.lastIndexOf("\n");
			System.out.println("startindex:" + startindex);
			if (startindex != -1 && startindex != input.length()) {
				String ip1 = input.substring(startindex + 1);
				System.out.println("ip1:" + ip1);
				if (ip1.indexOf(" ") > 0 || ip1.indexOf(" ") == -1) {
					String str_input = input.trim();
					System.out.println(str_input);
					input = str_input;
				}

			}
			// String str=StringUtils.chomp(input);

			_desp = input.split("\n");
			int _lineNumber = 1;
			// changes in EOLC on 01-Oct-2018 start
			if (_desp.length > 100) {
				if (fieldno == 1)
					merrmsg = "MF:txtDesGood1|Only 100 Rows Allowed. Entered Row: " + _desp.length;
				if (fieldno == 2)
					merrmsg = "MF:txtDesGood2|Only 100 Rows Allowed. Entered Row: " + _desp.length;
				if (fieldno == 3)
					merrmsg = "MF:txtDesGood3|Only 100 Rows Allowed. Entered Row: " + _desp.length;
				if (fieldno == 4)
					merrmsg = "MF:txtDocRequired1|Only 100 Rows Allowed. Entered Row: " + _desp.length;
				if (fieldno == 5)
					merrmsg = "MF:txtDocRequired2|Only 100 Rows Allowed. Entered Row: " + _desp.length;
				if (fieldno == 6)
					merrmsg = "MF:txtDocRequired3|Only 100 Rows Allowed. Entered Row: " + _desp.length;
				if (fieldno == 7)
					merrmsg = "MF:txtAddCond1|Only 100 Rows Allowed. Entered Row: " + _desp.length;
				if (fieldno == 8)
					merrmsg = "MF:txtAddCond2|Only 100 Rows Allowed. Entered Row: " + _desp.length;
				if (fieldno == 9)
					merrmsg = "MF:txtAddCond3|Only 100 Rows Allowed. Entered Row: " + _desp.length;
				return false;
			} else // changes in EOLC on 01-Oct-2018 end
			{
				for (int i = 0; i < _desp.length; i++) {
					if (_desp.length > i) {
						if (_desp[i].length() > 65) {
							_lineNumber += i;
							if (fieldno == 1)
								merrmsg = "MF:txtDesGood1|Only 65 Characters Allowed.Error in Line Number:" + _lineNumber;
							if (fieldno == 2)
								merrmsg = "MF:txtDesGood2|Only 65 Characters Allowed.Error in Line Number:" + _lineNumber;
							if (fieldno == 3)
								merrmsg = "MF:txtDesGood3|Only 65 Characters Allowed.Error in Line Number: " + _lineNumber;
							if (fieldno == 4)
								merrmsg = "MF:txtDocRequired1|Only 65 Characters Allowed.Error in Line Number:" + _lineNumber;
							if (fieldno == 5)
								merrmsg = "MF:txtDocRequired2|Only 65 Characters Allowed.Error in Line Number: " + _lineNumber;
							if (fieldno == 6)
								merrmsg = "MF:txtDocRequired3|Only 65 Characters Allowed.Error in Line Number: " + _lineNumber;
							if (fieldno == 7)
								merrmsg = "MF:txtAddCond1|Only 65 Characters Allowed.Error in Line Number: " + _lineNumber;
							if (fieldno == 8)
								merrmsg = "MF:txtAddCond2|Only 65 Characters Allowed.Error in Line Number: " + _lineNumber;
							if (fieldno == 9)
								merrmsg = "MF:txtAddCond3|Only 65 Characters Allowed.Error in Line Number: " + _lineNumber;
							return false;
						}
					}
				}
			}

		}
		return true;
	}

	private boolean revalSwiftDescriptionOfGoodsAndServices3() {
		int _good2 = LC_DESC_GOODS_SER2.split("\n").length;
		if (LC_DESC_GOODS_SER2.length() > 0) {
			if (LC_DESC_GOODS_SER2.length() < 6500 && LC_DESC_GOODS_SER3.length() > 0 && _good2 > 100) {
				merrmsg = "MF:txtDesGood2|Maximum 6500 characters. Entered " + LC_DESC_GOODS_SER2.length() + " characters";
				return false;
			}

			if (LC_DESC_GOODS_SER3.length() > 6500) {
				merrmsg = "MF:txtDesGood3|Maximum 6500 characters. Entered " + LC_DESC_GOODS_SER3.length() + " characters";
				return false;
			}
		}
		if (!LC_DESC_GOODS_SER3.trim().equalsIgnoreCase("")) {
			boolean result1 = lineNumberValidation(LC_DESC_GOODS_SER3, 3);
			if (result1) {

				inputDTO.clearMap();
				inputDTO.setValue("OLC_TYPE", olcLcType);
				inputDTO.setValue("OLC_YEAR", olcLcYear);
				inputDTO.setValue("OLC_DAY_SER", olcLcPresancDaySl);
				inputDTO.setValue("OLC_BRANCH_CODE", olcBrnCode);
				inputDTO.setValue("OLC_ENTRY_DATE", olcLcPresancDate);
				inputDTO.setValue("OLC_CLOB", LC_DESC_GOODS_SER3);
				inputDTO.setValue("OLC_CUST_NO", olcCustNo);
				inputDTO.setValue("OLC_COLUMNNAME", "LC_DESC_GOODS_SER3");

				if (excludespecialChar(inputDTO, 3))
					LC_DESC_GOODS_SER3 = temp_str;
				else
					return false;
			} else
				return false;
		}

		return true;
	}

	private boolean revalSwiftDocumentsRequired1() {
		if (LC_DOC_REQ1.length() == 0 && LC_DOC_REQ2.length() > 0) {
			merrmsg = "MF:txtDocRequired1|Should  not be blank";
			return false;
		} else if (LC_DOC_REQ1.length() == 0 && LC_DOC_REQ3.length() > 0) {
			merrmsg = "MF:txtDocRequired1|Should  not be blank";
			return false;
		}
		if (LC_DOC_REQ1.length() > 6500) {
			merrmsg = "MF:txtDocRequired1|Maximum 6500 characters. Entered " + LC_DOC_REQ1.length() + " characters";
			return false;
		}
		if (!LC_DOC_REQ1.trim().equalsIgnoreCase("")) {
			boolean result1 = lineNumberValidation(LC_DOC_REQ1, 4);
			if (result1) {

				inputDTO.clearMap();
				inputDTO.setValue("OLC_TYPE", olcLcType);
				inputDTO.setValue("OLC_YEAR", olcLcYear);
				inputDTO.setValue("OLC_DAY_SER", olcLcPresancDaySl);
				inputDTO.setValue("OLC_BRANCH_CODE", olcBrnCode);
				inputDTO.setValue("OLC_ENTRY_DATE", olcLcPresancDate);
				inputDTO.setValue("OLC_CLOB", LC_DOC_REQ1);
				inputDTO.setValue("OLC_CUST_NO", olcCustNo);
				inputDTO.setValue("OLC_COLUMNNAME", "LC_DOC_REQ1");

				if (excludespecialChar(inputDTO, 4))
					LC_DOC_REQ1 = temp_str;
				else
					return false;
			} else
				return false;
		}

		return true;
	}

	private boolean revalSwiftDocumentsRequired2() {
		int doc1 = LC_DOC_REQ1.split("\n").length;
		if (LC_DOC_REQ1.length() > 0) {
			if (LC_DOC_REQ1.length() < 6500 && LC_DOC_REQ2.length() > 0 && doc1 > 100) {
				merrmsg = "MF:txtDocRequired1|Maximum 6500 characters. Entered " + LC_DOC_REQ1.length() + " characters";
				return false;
			}

			if (LC_DOC_REQ2.length() == 0 && LC_DOC_REQ3.length() > 0) {
				merrmsg = "MF:txtDocRequired2|Should  not be blank";
				return false;
			}
			if (LC_DOC_REQ2.length() > 6500) {
				merrmsg = "MF:txtDocRequired2|Maximum 6500 characters. Entered " + LC_DOC_REQ2.length() + " characters";
				return false;
			}
		}
		if (!LC_DOC_REQ2.trim().equalsIgnoreCase("")) {
			boolean result1 = lineNumberValidation(LC_DOC_REQ2, 5);
			if (result1) {

				inputDTO.clearMap();
				inputDTO.setValue("OLC_TYPE", olcLcType);
				inputDTO.setValue("OLC_YEAR", olcLcYear);
				inputDTO.setValue("OLC_DAY_SER", olcLcPresancDaySl);
				inputDTO.setValue("OLC_BRANCH_CODE", olcBrnCode);
				inputDTO.setValue("OLC_ENTRY_DATE", olcLcPresancDate);
				inputDTO.setValue("OLC_CLOB", LC_DOC_REQ2);
				inputDTO.setValue("OLC_CUST_NO", olcCustNo);
				inputDTO.setValue("OLC_COLUMNNAME", "LC_DOC_REQ2");

				if (excludespecialChar(inputDTO, 5))
					LC_DOC_REQ2 = temp_str;
				else
					return false;
			} else
				return false;
		}

		return true;
	}

	private boolean revalSwiftDocumentsRequired3() {
		int doc2 = LC_DOC_REQ2.split("\n").length;
		if (LC_DOC_REQ2.length() > 0) {
			if (LC_DOC_REQ2.length() < 6500 && LC_DOC_REQ3.length() > 0 && doc2 > 100) {
				merrmsg = "MF:txtDocRequired2|Maximum 6500 characters. Entered " + LC_DOC_REQ2.length() + " characters";
				return false;
			}

			if (LC_DOC_REQ3.length() > 6500) {
				merrmsg = "MF:txtDocRequired3|Maximum 6500 characters. Entered " + LC_DOC_REQ3.length() + " characters";
				return false;
			}
		}
		if (!LC_DOC_REQ3.trim().equalsIgnoreCase("")) {
			boolean result1 = lineNumberValidation(LC_DOC_REQ3, 6);
			if (result1) {

				inputDTO.clearMap();
				inputDTO.setValue("OLC_TYPE", olcLcType);
				inputDTO.setValue("OLC_YEAR", olcLcYear);
				inputDTO.setValue("OLC_DAY_SER", olcLcPresancDaySl);
				inputDTO.setValue("OLC_BRANCH_CODE", olcBrnCode);
				inputDTO.setValue("OLC_ENTRY_DATE", olcLcPresancDate);
				inputDTO.setValue("OLC_CLOB", LC_DOC_REQ3);
				inputDTO.setValue("OLC_CUST_NO", olcCustNo);
				inputDTO.setValue("OLC_COLUMNNAME", "LC_DOC_REQ3");

				if (excludespecialChar(inputDTO, 6))
					LC_DOC_REQ3 = temp_str;
				else
					return false;
			} else
				return false;
		}

		return true;
	}

	private boolean revalSwiftAdditionalCondition1() {
		if (LC_ADD_CONDITION1.length() == 0 && LC_ADD_CONDITION2.length() > 0) {
			merrmsg = "MF:txtAddCond1|Should  not be blank";
			return false;
		} else if (LC_ADD_CONDITION1.length() == 0 && LC_ADD_CONDITION3.length() > 0) {
			merrmsg = "MF:txtAddCond1|Should  not be blank";
			return false;
		}
		if (LC_ADD_CONDITION1.length() > 6500) {
			merrmsg = "MF:txtAddCond1|Maximum 6500 characters. Entered " + LC_ADD_CONDITION1.length() + " characters";
			return false;
		}
		if (!LC_ADD_CONDITION1.trim().equalsIgnoreCase("")) {
			boolean result1 = lineNumberValidation(LC_ADD_CONDITION1, 7);
			if (result1) {

				inputDTO.clearMap();
				inputDTO.setValue("OLC_TYPE", olcLcType);
				inputDTO.setValue("OLC_YEAR", olcLcYear);
				inputDTO.setValue("OLC_DAY_SER", olcLcPresancDaySl);
				inputDTO.setValue("OLC_BRANCH_CODE", olcBrnCode);
				inputDTO.setValue("OLC_ENTRY_DATE", olcLcPresancDate);
				inputDTO.setValue("OLC_CLOB", LC_ADD_CONDITION1);
				inputDTO.setValue("OLC_CUST_NO", olcCustNo);
				inputDTO.setValue("OLC_COLUMNNAME", "LC_ADD_CONDITION1");

				if (excludespecialChar(inputDTO, 7))
					LC_ADD_CONDITION1 = temp_str;
				else
					return false;
			} else
				return false;
		}

		return true;
	}

	private boolean revalSwiftAdditionalCondition2() {
		int addcon1 = LC_ADD_CONDITION1.split("\n").length;
		if (LC_ADD_CONDITION1.length() > 0) {
			if (LC_ADD_CONDITION1.length() < 6500 && LC_ADD_CONDITION2.length() > 0 && addcon1 > 100) {
				merrmsg = "MF:txtAddCond1|Maximum 6500 characters. Entered " + LC_ADD_CONDITION1.length() + " characters";
				return false;
			}
			if (LC_ADD_CONDITION2.length() == 0 && LC_ADD_CONDITION3.length() > 0) {
				merrmsg = "MF:txtAddCond2|Should  not be blank";
				return false;
			}
			if (LC_ADD_CONDITION2.length() > 6500) {
				merrmsg = "MF:txtAddCond2|Maximum 6500 characters. Entered " + LC_ADD_CONDITION2.length() + " characters";
				return false;
			}
		}
		if (!LC_ADD_CONDITION2.trim().equalsIgnoreCase("")) {
			boolean result1 = lineNumberValidation(LC_ADD_CONDITION2, 8);
			if (result1) {

				inputDTO.clearMap();
				inputDTO.setValue("OLC_TYPE", olcLcType);
				inputDTO.setValue("OLC_YEAR", olcLcYear);
				inputDTO.setValue("OLC_DAY_SER", olcLcPresancDaySl);
				inputDTO.setValue("OLC_BRANCH_CODE", olcBrnCode);
				inputDTO.setValue("OLC_ENTRY_DATE", olcLcPresancDate);
				inputDTO.setValue("OLC_CLOB", LC_ADD_CONDITION2);
				inputDTO.setValue("OLC_CUST_NO", olcCustNo);
				inputDTO.setValue("OLC_COLUMNNAME", "LC_ADD_CONDITION2");

				if (excludespecialChar(inputDTO, 8))
					LC_ADD_CONDITION2 = temp_str;
				else
					return false;
			} else
				return false;
		}

		return true;
	}

	private boolean revalSwiftAdditionalCondition3() {
		int addcon2 = LC_ADD_CONDITION2.split("\n").length;
		if (LC_ADD_CONDITION2.length() > 0) {
			if (LC_ADD_CONDITION2.length() < 6500 && LC_ADD_CONDITION3.length() > 0 && addcon2 > 100) {
				merrmsg = "MF:txtAddCond2|Maximum 6500 characters. Entered " + LC_ADD_CONDITION2.length() + " characters";
				return false;
			}

			if (LC_ADD_CONDITION3.length() > 6500) {
				merrmsg = "MF:txtAddCond3|Maximum 6500 characters. Entered " + LC_ADD_CONDITION3.length() + " characters";
				return false;
			}
		}
		if (!LC_ADD_CONDITION3.trim().equalsIgnoreCase("")) {
			boolean result1 = lineNumberValidation(LC_ADD_CONDITION3, 9);
			if (result1) {

				inputDTO.clearMap();
				inputDTO.setValue("OLC_TYPE", olcLcType);
				inputDTO.setValue("OLC_YEAR", olcLcYear);
				inputDTO.setValue("OLC_DAY_SER", olcLcPresancDaySl);
				inputDTO.setValue("OLC_BRANCH_CODE", olcBrnCode);
				inputDTO.setValue("OLC_ENTRY_DATE", olcLcPresancDate);
				inputDTO.setValue("OLC_CLOB", LC_ADD_CONDITION3);
				inputDTO.setValue("OLC_CUST_NO", olcCustNo);
				inputDTO.setValue("OLC_COLUMNNAME", "LC_ADD_CONDITION3");

				if (excludespecialChar(inputDTO, 9))
					LC_ADD_CONDITION3 = temp_str;
				else
					return false;
			} else
				return false;
		}

		return true;
	}

	private boolean revalSwiftCharges() {
		chgs = null;
		if (!(LC_CHARGES.equalsIgnoreCase(""))) {
			chgs = LC_CHARGES.split("\n");
			a1 = chgs[0].trim();
			a2 = ((chgs.length > 1) ? chgs[1].trim() : " ");
			a3 = ((chgs.length > 2) ? chgs[2].trim() : " ");
			a4 = ((chgs.length > 3) ? chgs[3].trim() : " ");
			a5 = ((chgs.length > 4) ? chgs[4].trim() : " ");
			a6 = ((chgs.length > 5) ? chgs[5].trim() : " ");
			if ((a1.length() > 35) || (a2.length() > 35) || (a3.length() > 35) || (a4.length() > 35) || (a5.length() > 35) || (a6.length() > 35)) {
				merrmsg = "MF:txtCharge|Only 35 Characters Allowed In A Line";
				return false;
			}
		}

		return true;
	}

	private boolean revalSwiftPeriodForPresentation() {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("LC_PRESENTATION_DAY", LC_PER_PRESENTATION_DAY);
		revalDTO = eolcvalinstance.Olc_PresentationDayKeyPress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtperiod|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalSwiftConfirmationInstruction() {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("LC_CONFIRM_INSTRUCT", LC_CONFIRMATION_INST);
		revalDTO = eolcvalinstance.Olc_Confirmation_InstKeyPress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:lstConfInst|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalSwiftInstructionPaying() {
		instr_paying = null;
		if (!(LC_INST_PAYING.equalsIgnoreCase(""))) {
			instr_paying = LC_INST_PAYING.split("\n");
			a1 = instr_paying[0].trim();
			a2 = ((instr_paying.length > 1) ? instr_paying[1].trim() : " ");
			a3 = ((instr_paying.length > 2) ? instr_paying[2].trim() : " ");
			a4 = ((instr_paying.length > 3) ? instr_paying[3].trim() : " ");
			a5 = ((instr_paying.length > 4) ? instr_paying[4].trim() : " ");
			a6 = ((instr_paying.length > 5) ? instr_paying[5].trim() : " ");
			a7 = ((instr_paying.length > 6) ? instr_paying[6].trim() : " ");
			a8 = ((instr_paying.length > 7) ? instr_paying[7].trim() : " ");
			a9 = ((instr_paying.length > 8) ? instr_paying[8].trim() : " ");
			a10 = ((instr_paying.length > 9) ? instr_paying[9].trim() : " ");
			a11 = ((instr_paying.length > 10) ? instr_paying[10].trim() : " ");
			a12 = ((instr_paying.length > 11) ? instr_paying[11].trim() : " ");

			if ((a1.length() > 65) || (a2.length() > 65) || (a3.length() > 65) || (a4.length() > 65) || (a5.length() > 65) || (a6.length() > 65) || (a7.length() > 65) || (a8.length() > 65) || (a9.length() > 65) || (a10.length() > 65) || (a11.length() > 65) || (a12.length() > 65)) {
				merrmsg = "MF:txtInstPay|Only 65 Characters Allowed In A Line";
				return false;
			}
		}
		return true;
	}

	private boolean revalSwiftSendToRecInfo() {
		send_to_rec = null;
		if (!(LC_SNDR_REC_INFO.equalsIgnoreCase(""))) {
			send_to_rec = LC_SNDR_REC_INFO.split("\n");
			a1 = send_to_rec[0].trim();
			a2 = ((send_to_rec.length > 1) ? send_to_rec[1].trim() : " ");
			a3 = ((send_to_rec.length > 2) ? send_to_rec[2].trim() : " ");
			a4 = ((send_to_rec.length > 3) ? send_to_rec[3].trim() : " ");
			a5 = ((send_to_rec.length > 4) ? send_to_rec[4].trim() : " ");
			a6 = ((send_to_rec.length > 5) ? send_to_rec[5].trim() : " ");
			if ((a1.length() > 35) || (a2.length() > 35) || (a3.length() > 35) || (a4.length() > 35) || (a5.length() > 35) || (a6.length() > 35)) {
				merrmsg = "MF:txtSendInfo|Only 35 Characters Allowed In A Line";
				return false;
			}
		}

		return true;
	}

	private boolean revalSwiftOverallBICCode(String bic1, String bic2, String bic3, String bic4, String bic5) {

		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("LC_APPLICANT_BIC_CODE", bic1);
		inputDTO.setValue("LC_AVAILABLE_WITH_CODE", bic2);
		inputDTO.setValue("LC_DRAWEE_BIC_CODE", bic3);
		inputDTO.setValue("LC_REIMB_BIC_CODE", bic4);
		inputDTO.setValue("LC_SECOND_ADV_BIC_CODE", bic5);
		revalDTO = eolcvalinstance.Olc_OverallBIC(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			if (revalDTO.getValue("OUTFIELDNO").equals("2"))
				merrmsg = "MF:txtAvlBicCode|" + revalDTO.getValue(ErrorKey).toString();
			if (revalDTO.getValue("OUTFIELDNO").equals("3"))
				merrmsg = "MF:txtDrwBicCode|" + revalDTO.getValue(ErrorKey).toString();
			if (revalDTO.getValue("OUTFIELDNO").equals("4"))
				merrmsg = "MF:txtReimBicCode|" + revalDTO.getValue(ErrorKey).toString();
			if (revalDTO.getValue("OUTFIELDNO").equals("5"))
				merrmsg = "MF:txtAdviseBicCode|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;

	}

	// chnages in eolc on 27-may-2018 end

	// changes in eolc on 12-jun-2018 start

	private boolean excludespecialChar(DTObject input, int fieldno) {
		revalDTO.clearMap();
		revalDTO = eolcvalinstance.Special_Char_Validation(input);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			if (fieldno == 1)
				merrmsg = "MF:txtDesGood1|Special Character not Allowed";
			if (fieldno == 2)
				merrmsg = "MF:txtDesGood2|Special Character not Allowed";
			if (fieldno == 3)
				merrmsg = "MF:txtDesGood3|Special Character not Allowed";
			if (fieldno == 4)
				merrmsg = "MF:txtDocRequired1|Special Character not Allowed";
			if (fieldno == 5)
				merrmsg = "MF:txtDocRequired2|Special Character not Allowed";
			if (fieldno == 6)
				merrmsg = "MF:txtDocRequired3|Special Character not Allowed";
			if (fieldno == 7)
				merrmsg = "MF:txtAddCond1|Special Character not Allowed";
			if (fieldno == 8)
				merrmsg = "MF:txtAddCond2|Special Character not Allowed";
			if (fieldno == 9)
				merrmsg = "MF:txtAddCond3|Special Character not Allowed";
			return false;
		}
		temp_str = "";
		temp_str = revalDTO.getValue("TEMP");
		return true;
	}

	// changes in eolc on 12-jun-2018 end

	// ADDED BY PRASHANTH ON 29 JANUARY 2018
	//Changes Sanjay1 22-07-2019 Begin
	/*private boolean revalolcAdvThruBk() {
		if (LC_CONFIRMATION_INST.equals("1")) {
			if(olcLcToBeCnfrmdByBk.trim().equals(""))
			{
				merrmsg = "MF:txtConfirmedByBank|" + "Field Should Be Not Be Blank";
				return false;
			}
			
			inputDTO.clearMap();
			inputDTO.setValue("OLC_ADV_BANK_CODE", olcLcToBeCnfrmdByBk);
			revalDTO = eolcvalinstance.olcAdvBankCodekeypress(inputDTO);
			if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
				merrmsg = "MF:txtConfirmedByBank|" + revalDTO.getValue(ErrorKey).toString();
				return false;
			}
		}
		else{
			if(!olcLcToBeCnfrmdByBk.trim().equals(""))
			{
				merrmsg = "MF:txtConfirmedByBank|" + "Field Should Be Blank For the selected Option";
				return false;
			}
		}
		return true;
	}

	private boolean revalolcAdvThruBrn() {
		if (LC_CONFIRMATION_INST.equals("1")) {
			if(olcLcToBeCnfrmdByBrn.trim().equals(""))
			{
				merrmsg = "MF:txtConfirmedBYBranch|" + "Field Should Be Not Be Blank";
				return false;
			}
			inputDTO.clearMap();
			inputDTO.setValue("OLC_ADV_BRNCH_CODE", olcLcToBeCnfrmdByBrn);
			inputDTO.setValue("OLC_ADV_BANK_CODE", olcLcToBeCnfrmdByBk);
			revalDTO = eolcvalinstance.olcAdvBranchCodekeypress(inputDTO);
			if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
				merrmsg = "MF:txtConfirmedBYBranch|" + revalDTO.getValue(ErrorKey).toString();
				return false;
			}
		}
		else{
			if(!olcLcToBeCnfrmdByBrn.trim().equals(""))
			{
				merrmsg = "MF:txtConfirmedBYBranch|" + "Field Should Be Blank For the selected Option";
				return false;
			}
			
		}
		return true;
	}

	private boolean revalolcAdvBrnName() {
		if (LC_CONFIRMATION_INST.equals("1")) {
			if(olcLcToBeCnfrmdByBrnName.trim().equals(""))
			{
				merrmsg = "MF:txtConfirmedBYBranchname|" + "Field Should Be Not Be Blank";
				return false;
			}
			
			inputDTO.clearMap();
			inputDTO.setValue("OLC_BRNCH_NAME", olcLcToBeCnfrmdByBrnName);
			revalDTO = eolcvalinstance.olcBranchNamekeypress(inputDTO);
			if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
				merrmsg = "MF:txtConfirmedBYBranch|" + revalDTO.getValue(ErrorKey).toString();
				return false;
			}
		}
		else{
			if(!olcLcToBeCnfrmdByBrnName.trim().equals(""))
			{
				merrmsg = "MF:txtConfirmedBYBranchname|" + "Field Should Be Blank For the selected Option";
				return false;
			}
			
		}
		return true;
	}*/
	//Changes Sanjay1 22-07-2019 End
	// ADDED BY PRASHANTH ON 29 JANUARY 2018

	public String getMxmlstr1() {
		return mxmlstr1;
	}

	public void setMxmlstr1(String mxmlstr1) {
		this.mxmlstr1 = mxmlstr1;
	}

	public String getOlcLcTotalTenoramt() {
		return olcLcTotalTenoramt;
	}

	public void setOlcLcTotalTenoramt(String olcLcTotalTenoramt) {
		this.olcLcTotalTenoramt = olcLcTotalTenoramt;
	}

	public String getPrevLcdate() {
		return prevLcdate;
	}

	public void setPrevLcdate(String prevLcdate) {
		this.prevLcdate = prevLcdate;
	}

	public String getRefno() {
		return refno;
	}

	public void setRefno(String refno) {
		this.refno = refno;
	}

	public String getChargesSl1() {
		return chargesSl1;
	}

	public void setChargesSl1(String chargesSl1) {
		this.chargesSl1 = chargesSl1;
	}

	public String getConrateSl1() {
		return conrateSl1;
	}

	public void setConrateSl1(String conrateSl1) {
		this.conrateSl1 = conrateSl1;
	}

	public String getInvenNo1() {
		return invenNo1;
	}

	public void setInvenNo1(String invenNo1) {
		this.invenNo1 = invenNo1;
	}

	public String getXmlerrmsg() {
		return xmlerrmsg;
	}

	public void setXmlerrmsg(String xmlerrmsg) {
		this.xmlerrmsg = xmlerrmsg;
	}

	public String getBatchnum() {
		return batchnum;
	}

	public void setBatchnum(String batchnum) {
		this.batchnum = batchnum;
	}

	public String getOlcLcAdvThru() {
		return olcLcAdvThru;
	}

	public void setOlcLcAdvThru(String olcLcAdvThru) {
		this.olcLcAdvThru = olcLcAdvThru;
	}

	public String getOlcLcIssBrnname() {
		return olcLcIssBrnname;
	}

	public void setOlcLcIssBrnname(String olcLcIssBrnname) {
		this.olcLcIssBrnname = olcLcIssBrnname;
	}

	public String getOlcLcIssBrnAdd() {
		return olcLcIssBrnAdd;
	}

	public void setOlcLcIssBrnAdd(String olcLcIssBrnAdd) {
		this.olcLcIssBrnAdd = olcLcIssBrnAdd;
	}

	public String getOlclcliaaccno() {
		return olclcliaaccno;
	}

	public void setOlclcliaaccno(String olclcliaaccno) {
		this.olclcliaaccno = olclcliaaccno;
	}

	public String getOlcintaccno() {
		return olcintaccno;
	}

	public void setOlcintaccno(String olcintaccno) {
		this.olcintaccno = olcintaccno;
	}

	public String getBatnum() {
		return batnum;
	}

	public void setBatnum(String batnum) {
		this.batnum = batnum;
	}

	// Changes P.Subramani-Chn-16/02/2008
	public String getOlctotalcurr() {
		return olctotalcurr;
	}

	public void setOlctotalcurr(String olctotalcurr) {
		this.olctotalcurr = olctotalcurr;
	}

	// Changes P.Subramani-Chn-10/04/2008 Beg
	public String getOlccommchgs() {
		return olccommchgs;
	}

	public void setOlccommchgs(String olccommchgs) {
		this.olccommchgs = olccommchgs;
	}

	public String getOlcusnchgs() {
		return olcusnchgs;
	}

	public void setOlcusnchgs(String olcusnchgs) {
		this.olcusnchgs = olcusnchgs;
	}

	public String getOlccommchgstakendays() {
		return olccommchgstakendays;
	}

	public void setOlccommchgstakendays(String olccommchgstakendays) {
		this.olccommchgstakendays = olccommchgstakendays;
	}

	public String getOlcusnchgstakendays() {
		return olcusnchgstakendays;
	}

	public void setOlcusnchgstakendays(String olcusnchgstakendays) {
		this.olcusnchgstakendays = olcusnchgstakendays;
	}

	// Changes P.Subramani-Chn-10/04/2008 End

	public String getOlctotalcashmargin() {
		return olctotalcashmargin;
	}

	public void setOlctotalcashmargin(String olctotalcashmargin) {
		this.olctotalcashmargin = olctotalcashmargin;
	}

	public String getUsanceservtax() {
		return usanceservtax;
	}

	public void setUsanceservtax(String usanceservtax) {
		this.usanceservtax = usanceservtax;
	}

	public String getCommitservtax() {
		return commitservtax;
	}

	public void setCommitservtax(String commitservtax) {
		this.commitservtax = commitservtax;
	}

	public String getTotalliabamt() {
		return totalliabamt;
	}

	public void setTotalliabamt(String totalliabamt) {
		this.totalliabamt = totalliabamt;
	}

	public String getTsry_enabled() {
		return tsry_enabled;
	}

	public void setTsry_enabled(String tsry_enabled) {
		this.tsry_enabled = tsry_enabled;
	}

	public String getLC_FORM_OF_DOC_CREDIT() {
		return LC_FORM_OF_DOC_CREDIT;
	}

	public void setLC_FORM_OF_DOC_CREDIT(String lc_form_of_doc_credit) {
		LC_FORM_OF_DOC_CREDIT = lc_form_of_doc_credit;
	}

	public String getLC_REFERENCE_TO_PREADVICE() {
		return LC_REFERENCE_TO_PREADVICE;
	}

	public void setLC_REFERENCE_TO_PREADVICE(String lc_reference_to_preadvice) {
		LC_REFERENCE_TO_PREADVICE = lc_reference_to_preadvice;
	}

	public String getLC_APPLICABLE_RULES() {
		return LC_APPLICABLE_RULES;
	}

	public void setLC_APPLICABLE_RULES(String lc_applicable_rules) {
		LC_APPLICABLE_RULES = lc_applicable_rules;
	}

	public String getLC_APPLICANT_TYPE() {
		return LC_APPLICANT_TYPE;
	}

	public void setLC_APPLICANT_TYPE(String lc_applicant_type) {
		LC_APPLICANT_TYPE = lc_applicant_type;
	}

	public String getLC_APPLICANT_BRN_CODE() {
		return LC_APPLICANT_BRN_CODE;
	}

	public void setLC_APPLICANT_BRN_CODE(String lc_applicant_brn_code) {
		LC_APPLICANT_BRN_CODE = lc_applicant_brn_code;
	}

	public String getLC_APPLICANT_BIC_CODE() {
		return LC_APPLICANT_BIC_CODE;
	}

	public void setLC_APPLICANT_BIC_CODE(String lc_applicant_bic_code) {
		LC_APPLICANT_BIC_CODE = lc_applicant_bic_code;
	}

	public String getLC_APPLICANT_ROUTID() {
		return LC_APPLICANT_ROUTID;
	}

	public void setLC_APPLICANT_ROUTID(String lc_applicant_routid) {
		LC_APPLICANT_ROUTID = lc_applicant_routid;
	}

	public String getLC_APPLICANT_BNK_CODE() {
		return LC_APPLICANT_BNK_CODE;
	}

	public void setLC_APPLICANT_BNK_CODE(String lc_applicant_bnk_code) {
		LC_APPLICANT_BNK_CODE = lc_applicant_bnk_code;
	}

	public String getLC_AVAILABLE_WITH_TYPE() {
		return LC_AVAILABLE_WITH_TYPE;
	}

	public void setLC_AVAILABLE_WITH_TYPE(String lc_available_with_type) {
		LC_AVAILABLE_WITH_TYPE = lc_available_with_type;
	}

	public String getLC_AVAILABLE_WITH_BRN_CODE() {
		return LC_AVAILABLE_WITH_BRN_CODE;
	}

	public void setLC_AVAILABLE_WITH_BRN_CODE(String lc_available_with_brn_code) {
		LC_AVAILABLE_WITH_BRN_CODE = lc_available_with_brn_code;
	}

	public String getLC_AVAILABLE_WITH_CODE() {
		return LC_AVAILABLE_WITH_CODE;
	}

	public void setLC_AVAILABLE_WITH_CODE(String lc_available_with_code) {
		LC_AVAILABLE_WITH_CODE = lc_available_with_code;
	}

	public String getLC_AVAILABLE_WITH_ROUTID() {
		return LC_AVAILABLE_WITH_ROUTID;
	}

	public void setLC_AVAILABLE_WITH_ROUTID(String lc_available_with_routid) {
		LC_AVAILABLE_WITH_ROUTID = lc_available_with_routid;
	}

	public String getLC_AVAILABLE_WITH_BNK_CODE() {
		return LC_AVAILABLE_WITH_BNK_CODE;
	}

	public void setLC_AVAILABLE_WITH_BNK_CODE(String lc_available_with_bnk_code) {
		LC_AVAILABLE_WITH_BNK_CODE = lc_available_with_bnk_code;
	}

	public String getLC_DRAWEE_TYPE() {
		return LC_DRAWEE_TYPE;
	}

	public void setLC_DRAWEE_TYPE(String lc_drawee_type) {
		LC_DRAWEE_TYPE = lc_drawee_type;
	}

	public String getLC_DRAWEE_BRN_CODE() {
		return LC_DRAWEE_BRN_CODE;
	}

	public void setLC_DRAWEE_BRN_CODE(String lc_drawee_brn_code) {
		LC_DRAWEE_BRN_CODE = lc_drawee_brn_code;
	}

	public String getLC_DRAWEE_BIC_CODE() {
		return LC_DRAWEE_BIC_CODE;
	}

	public void setLC_DRAWEE_BIC_CODE(String lc_drawee_bic_code) {
		LC_DRAWEE_BIC_CODE = lc_drawee_bic_code;
	}

	public String getLC_DRAWEE_ROUTID() {
		return LC_DRAWEE_ROUTID;
	}

	public void setLC_DRAWEE_ROUTID(String lc_drawee_routid) {
		LC_DRAWEE_ROUTID = lc_drawee_routid;
	}

	public String getLC_DRAWEE_BNK_CODE() {
		return LC_DRAWEE_BNK_CODE;
	}

	public void setLC_DRAWEE_BNK_CODE(String lc_drawee_bnk_code) {
		LC_DRAWEE_BNK_CODE = lc_drawee_bnk_code;
	}

	public String getLC_PLACE_OF_TAKING_IN_CHARGE() {
		return LC_PLACE_OF_TAKING_IN_CHARGE;
	}

	public void setLC_PLACE_OF_TAKING_IN_CHARGE(String lc_place_of_taking_in_charge) {
		LC_PLACE_OF_TAKING_IN_CHARGE = lc_place_of_taking_in_charge;
	}

	public String getLC_PORT_OF_LOADING() {
		return LC_PORT_OF_LOADING;
	}

	public void setLC_PORT_OF_LOADING(String lc_port_of_loading) {
		LC_PORT_OF_LOADING = lc_port_of_loading;
	}

	public String getLC_PORT_OF_DISCHARGE() {
		return LC_PORT_OF_DISCHARGE;
	}

	public void setLC_PORT_OF_DISCHARGE(String lc_port_of_discharge) {
		LC_PORT_OF_DISCHARGE = lc_port_of_discharge;
	}

	public String getLC_PLACE_OF_FINAL_DEST() {
		return LC_PLACE_OF_FINAL_DEST;
	}

	public void setLC_PLACE_OF_FINAL_DEST(String lc_place_of_final_dest) {
		LC_PLACE_OF_FINAL_DEST = lc_place_of_final_dest;
	}

	public String getLC_DESC_GOODS_SER1() {
		return LC_DESC_GOODS_SER1;
	}

	public void setLC_DESC_GOODS_SER1(String lc_desc_goods_ser1) {
		LC_DESC_GOODS_SER1 = lc_desc_goods_ser1;
	}

	public String getLC_DESC_GOODS_SER2() {
		return LC_DESC_GOODS_SER2;
	}

	public void setLC_DESC_GOODS_SER2(String lc_desc_goods_ser2) {
		LC_DESC_GOODS_SER2 = lc_desc_goods_ser2;
	}

	public String getLC_DESC_GOODS_SER3() {
		return LC_DESC_GOODS_SER3;
	}

	public void setLC_DESC_GOODS_SER3(String lc_desc_goods_ser3) {
		LC_DESC_GOODS_SER3 = lc_desc_goods_ser3;
	}

	public String getLC_DOC_REQ1() {
		return LC_DOC_REQ1;
	}

	public void setLC_DOC_REQ1(String lc_doc_req1) {
		LC_DOC_REQ1 = lc_doc_req1;
	}

	public String getLC_DOC_REQ2() {
		return LC_DOC_REQ2;
	}

	public void setLC_DOC_REQ2(String lc_doc_req2) {
		LC_DOC_REQ2 = lc_doc_req2;
	}

	public String getLC_DOC_REQ3() {
		return LC_DOC_REQ3;
	}

	public void setLC_DOC_REQ3(String lc_doc_req3) {
		LC_DOC_REQ3 = lc_doc_req3;
	}

	public String getLC_ADD_CONDITION1() {
		return LC_ADD_CONDITION1;
	}

	public void setLC_ADD_CONDITION1(String lc_add_condition1) {
		LC_ADD_CONDITION1 = lc_add_condition1;
	}

	public String getLC_ADD_CONDITION2() {
		return LC_ADD_CONDITION2;
	}

	public void setLC_ADD_CONDITION2(String lc_add_condition2) {
		LC_ADD_CONDITION2 = lc_add_condition2;
	}

	public String getLC_ADD_CONDITION3() {
		return LC_ADD_CONDITION3;
	}

	public void setLC_ADD_CONDITION3(String lc_add_condition3) {
		LC_ADD_CONDITION3 = lc_add_condition3;
	}

	public String getLC_PER_PRESENTATION_DAY() {
		return LC_PER_PRESENTATION_DAY;
	}

	public void setLC_PER_PRESENTATION_DAY(String lc_per_presentation_day) {
		LC_PER_PRESENTATION_DAY = lc_per_presentation_day;
	}

	public String getLC_REIMB_TYPE() {
		return LC_REIMB_TYPE;
	}

	public void setLC_REIMB_TYPE(String lc_reimb_type) {
		LC_REIMB_TYPE = lc_reimb_type;
	}

	public String getLC_REIMB_BRN_CODE() {
		return LC_REIMB_BRN_CODE;
	}

	public void setLC_REIMB_BRN_CODE(String lc_reimb_brn_code) {
		LC_REIMB_BRN_CODE = lc_reimb_brn_code;
	}

	public String getLC_REIMB_BIC_CODE() {
		return LC_REIMB_BIC_CODE;
	}

	public void setLC_REIMB_BIC_CODE(String lc_reimb_bic_code) {
		LC_REIMB_BIC_CODE = lc_reimb_bic_code;
	}

	public String getLC_REIMB_ROUTID() {
		return LC_REIMB_ROUTID;
	}

	public void setLC_REIMB_ROUTID(String lc_reimb_routid) {
		LC_REIMB_ROUTID = lc_reimb_routid;
	}

	public String getLC_REIMB_BNK_CODE() {
		return LC_REIMB_BNK_CODE;
	}

	public void setLC_REIMB_BNK_CODE(String lc_reimb_bnk_code) {
		LC_REIMB_BNK_CODE = lc_reimb_bnk_code;
	}

	public String getLC_SECOND_ADV_TYPE() {
		return LC_SECOND_ADV_TYPE;
	}

	public void setLC_SECOND_ADV_TYPE(String lc_second_adv_type) {
		LC_SECOND_ADV_TYPE = lc_second_adv_type;
	}

	public String getLC_SECOND_ADV_BRN_CODE() {
		return LC_SECOND_ADV_BRN_CODE;
	}

	public void setLC_SECOND_ADV_BRN_CODE(String lc_second_adv_brn_code) {
		LC_SECOND_ADV_BRN_CODE = lc_second_adv_brn_code;
	}

	public String getLC_SECOND_ADV_BIC_CODE() {
		return LC_SECOND_ADV_BIC_CODE;
	}

	public void setLC_SECOND_ADV_BIC_CODE(String lc_second_adv_bic_code) {
		LC_SECOND_ADV_BIC_CODE = lc_second_adv_bic_code;
	}

	public String getLC_SECOND_ADV_ROUTID() {
		return LC_SECOND_ADV_ROUTID;
	}

	public void setLC_SECOND_ADV_ROUTID(String lc_second_adv_routid) {
		LC_SECOND_ADV_ROUTID = lc_second_adv_routid;
	}

	public String getLC_SECOND_ADV_BNK_CODE() {
		return LC_SECOND_ADV_BNK_CODE;
	}

	public void setLC_SECOND_ADV_BNK_CODE(String lc_second_adv_bnk_code) {
		LC_SECOND_ADV_BNK_CODE = lc_second_adv_bnk_code;
	}

	public String getLC_DOC_CREDIT_TYPE() {
		return LC_DOC_CREDIT_TYPE;
	}

	public void setLC_DOC_CREDIT_TYPE(String lc_doc_credit_type) {
		LC_DOC_CREDIT_TYPE = lc_doc_credit_type;
	}

	public String getLC_PARTSHPMNT_TYPE() {
		return LC_PARTSHPMNT_TYPE;
	}

	public void setLC_PARTSHPMNT_TYPE(String lc_partshpmnt_type) {
		LC_PARTSHPMNT_TYPE = lc_partshpmnt_type;
	}

	public String getLC_TRANSHIPMENT_TYPE() {
		return LC_TRANSHIPMENT_TYPE;
	}

	public void setLC_TRANSHIPMENT_TYPE(String lc_transhipment_type) {
		LC_TRANSHIPMENT_TYPE = lc_transhipment_type;
	}

	public String getLC_APPLICABLE_RULES_TYPE() {
		return LC_APPLICABLE_RULES_TYPE;
	}

	public void setLC_APPLICABLE_RULES_TYPE(String lc_applicable_rules_type) {
		LC_APPLICABLE_RULES_TYPE = lc_applicable_rules_type;
	}

	public String getLC_APPLICANT_ADDRESS() {
		return LC_APPLICANT_ADDRESS;
	}

	public void setLC_APPLICANT_ADDRESS(String lc_applicant_address) {
		LC_APPLICANT_ADDRESS = lc_applicant_address;
	}

	public String getLC_AVAILABLE_WITH_ADDRESS() {
		return LC_AVAILABLE_WITH_ADDRESS;
	}

	public void setLC_AVAILABLE_WITH_ADDRESS(String lc_available_with_address) {
		LC_AVAILABLE_WITH_ADDRESS = lc_available_with_address;
	}

	public String getLC_DRAFTS_AT() {
		return LC_DRAFTS_AT;
	}

	public void setLC_DRAFTS_AT(String lc_drafts_at) {
		LC_DRAFTS_AT = lc_drafts_at;
	}

	public String getLC_DRAWEE_ADDRESS() {
		return LC_DRAWEE_ADDRESS;
	}

	public void setLC_DRAWEE_ADDRESS(String lc_drawee_address) {
		LC_DRAWEE_ADDRESS = lc_drawee_address;
	}

	public String getLC_MIXED_PAY_DETAILS() {
		return LC_MIXED_PAY_DETAILS;
	}

	public void setLC_MIXED_PAY_DETAILS(String lc_mixed_pay_details) {
		LC_MIXED_PAY_DETAILS = lc_mixed_pay_details;
	}

	public String getLC_DEFERRED_PAY_DETAILS() {
		return LC_DEFERRED_PAY_DETAILS;
	}

	public void setLC_DEFERRED_PAY_DETAILS(String lc_deferred_pay_details) {
		LC_DEFERRED_PAY_DETAILS = lc_deferred_pay_details;
	}

	public String getLC_CHARGES() {
		return LC_CHARGES;
	}

	public void setLC_CHARGES(String lc_charges) {
		LC_CHARGES = lc_charges;
	}

	public String getLC_REIMB_ADDRESS() {
		return LC_REIMB_ADDRESS;
	}

	public void setLC_REIMB_ADDRESS(String lc_reimb_address) {
		LC_REIMB_ADDRESS = lc_reimb_address;
	}

	public String getLC_INST_PAYING() {
		return LC_INST_PAYING;
	}

	public void setLC_INST_PAYING(String lc_inst_paying) {
		LC_INST_PAYING = lc_inst_paying;
	}

	public String getLC_SECOND_ADV_ADDRESS() {
		return LC_SECOND_ADV_ADDRESS;
	}

	public void setLC_SECOND_ADV_ADDRESS(String lc_second_adv_address) {
		LC_SECOND_ADV_ADDRESS = lc_second_adv_address;
	}

	public String getLC_SNDR_REC_INFO() {
		return LC_SNDR_REC_INFO;
	}

	public void setLC_SNDR_REC_INFO(String lc_sndr_rec_info) {
		LC_SNDR_REC_INFO = lc_sndr_rec_info;
	}

	public String getLC_APPLICANT_CNTRY_CODE() {
		return LC_APPLICANT_CNTRY_CODE;
	}

	public void setLC_APPLICANT_CNTRY_CODE(String lc_applicant_cntry_code) {
		LC_APPLICANT_CNTRY_CODE = lc_applicant_cntry_code;
	}

	public String getLC_AVAILABLE_WITH_CNTRY() {
		return LC_AVAILABLE_WITH_CNTRY;
	}

	public void setLC_AVAILABLE_WITH_CNTRY(String lc_available_with_cntry) {
		LC_AVAILABLE_WITH_CNTRY = lc_available_with_cntry;
	}

	public String getLC_AVAILABLE_WITH_CODETYP() {
		return LC_AVAILABLE_WITH_CODETYP;
	}

	public void setLC_AVAILABLE_WITH_CODETYP(String lc_available_with_codetyp) {
		LC_AVAILABLE_WITH_CODETYP = lc_available_with_codetyp;
	}

	public boolean isLC_APPLICANT_REQ() {
		return LC_APPLICANT_REQ;
	}

	public void setLC_APPLICANT_REQ(boolean lc_applicant_req) {
		LC_APPLICANT_REQ = lc_applicant_req;
	}

	public boolean isLC_DRAWEE_REQ() {
		return LC_DRAWEE_REQ;
	}

	public void setLC_DRAWEE_REQ(boolean lc_drawee_req) {
		LC_DRAWEE_REQ = lc_drawee_req;
	}

	public boolean isLC_REIMB_REQ() {
		return LC_REIMB_REQ;
	}

	public void setLC_REIMB_REQ(boolean lc_reimb_req) {
		LC_REIMB_REQ = lc_reimb_req;
	}

	public boolean isLC_SECOND_ADV_REQ() {
		return LC_SECOND_ADV_REQ;
	}

	public void setLC_SECOND_ADV_REQ(boolean lc_second_adv_req) {
		LC_SECOND_ADV_REQ = lc_second_adv_req;
	}

	public String getLC_DRAWEE_CNTRY_CODE() {
		return LC_DRAWEE_CNTRY_CODE;
	}

	public void setLC_DRAWEE_CNTRY_CODE(String lc_drawee_cntry_code) {
		LC_DRAWEE_CNTRY_CODE = lc_drawee_cntry_code;
	}

	/*
	 * public String getLC_CONFIRM_INST_TYPE() { return LC_CONFIRM_INST_TYPE; }
	 * 
	 * public void setLC_CONFIRM_INST_TYPE(String lc_confirm_inst_type) {
	 * LC_CONFIRM_INST_TYPE = lc_confirm_inst_type; }
	 */

	public String getLC_REIMB_CNTRY_CODE() {
		return LC_REIMB_CNTRY_CODE;
	}

	public void setLC_REIMB_CNTRY_CODE(String lc_reimb_cntry_code) {
		LC_REIMB_CNTRY_CODE = lc_reimb_cntry_code;
	}

	public String getLC_SECOND_ADV_CNTRYCODE() {
		return LC_SECOND_ADV_CNTRYCODE;
	}

	public void setLC_SECOND_ADV_CNTRYCODE(String lc_second_adv_cntrycode) {
		LC_SECOND_ADV_CNTRYCODE = lc_second_adv_cntrycode;
	}

	public String getLC_PARTIAL_SHIPMENTS() {
		return LC_PARTIAL_SHIPMENTS;
	}

	public void setLC_PARTIAL_SHIPMENTS(String lc_partial_shipments) {
		LC_PARTIAL_SHIPMENTS = lc_partial_shipments;
	}

	public String getLC_TRANSHIPMENT() {
		return LC_TRANSHIPMENT;
	}

	public void setLC_TRANSHIPMENT(String lc_transhipment) {
		LC_TRANSHIPMENT = lc_transhipment;
	}

	public String getLC_CONFIRMATION_INST() {
		return LC_CONFIRMATION_INST;
	}

	public void setLC_CONFIRMATION_INST(String lc_confirmation_inst) {
		LC_CONFIRMATION_INST = lc_confirmation_inst;
	}

	public String getLC_SHIPMENT_PERIOD() {
		return LC_SHIPMENT_PERIOD;
	}

	public void setLC_SHIPMENT_PERIOD(String lc_shipment_period) {
		LC_SHIPMENT_PERIOD = lc_shipment_period;
	}

	public String getLC_APPLICANT() {
		return LC_APPLICANT;
	}

	public void setLC_APPLICANT(String lc_applicant) {
		LC_APPLICANT = lc_applicant;
	}

	public String getLC_REC_BIC_CODE() {
		return LC_REC_BIC_CODE;
	}

	public void setLC_REC_BIC_CODE(String lc_rec_bic_code) {
		LC_REC_BIC_CODE = lc_rec_bic_code;
	}

	public String getLC_REIMB_CFM_TYPE() {
		return LC_REIMB_CFM_TYPE;
	}

	public void setLC_REIMB_CFM_TYPE(String lc_reimb_cfm_type) {
		LC_REIMB_CFM_TYPE = lc_reimb_cfm_type;
	}

	public String getLC_REIMB_CFM_BIC_CODE() {
		return LC_REIMB_CFM_BIC_CODE;
	}

	public void setLC_REIMB_CFM_BIC_CODE(String lc_reimb_cfm_bic_code) {
		LC_REIMB_CFM_BIC_CODE = lc_reimb_cfm_bic_code;
	}

	public String getLC_REIMB_CFM_BRN_CODE() {
		return LC_REIMB_CFM_BRN_CODE;
	}

	public void setLC_REIMB_CFM_BRN_CODE(String lc_reimb_cfm_brn_code) {
		LC_REIMB_CFM_BRN_CODE = lc_reimb_cfm_brn_code;
	}

	public String getLC_CFM_REIMB_ROUTID() {
		return LC_CFM_REIMB_ROUTID;
	}

	public void setLC_CFM_REIMB_ROUTID(String lc_cfm_reimb_routid) {
		LC_CFM_REIMB_ROUTID = lc_cfm_reimb_routid;
	}

	public String getLC_CFM_REIMB_BNK_CODE() {
		return LC_CFM_REIMB_BNK_CODE;
	}

	public void setLC_CFM_REIMB_BNK_CODE(String lc_cfm_reimb_bnk_code) {
		LC_CFM_REIMB_BNK_CODE = lc_cfm_reimb_bnk_code;
	}

	public String getLC_CFM_REIMB_ADDRESS() {
		return LC_CFM_REIMB_ADDRESS;
	}

	public void setLC_CFM_REIMB_ADDRESS(String lc_cfm_reimb_address) {
		LC_CFM_REIMB_ADDRESS = lc_cfm_reimb_address;
	}

	public String getLC_CFM_REIMB_CNTRY_CODE() {
		return LC_CFM_REIMB_CNTRY_CODE;
	}

	public void setLC_CFM_REIMB_CNTRY_CODE(String lc_cfm_reimb_cntry_code) {
		LC_CFM_REIMB_CNTRY_CODE = lc_cfm_reimb_cntry_code;
	}

}

/** ****************************************************************************************************** */
