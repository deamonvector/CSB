
package panacea.OLCaction;

import java.io.BufferedReader;
import java.io.Reader;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Types;
import java.text.DecimalFormat;

import panacea.Validator.AccountValidator;
import panacea.Validator.BranchValidator;
import panacea.Validator.ClientValidator;
import panacea.Validator.CommonValidator;
import panacea.Validator.DDPOValidator;
import panacea.Validator.GlValidator;
import panacea.Validator.IBCValidator;
import panacea.Validator.IRSValidator;
import panacea.Validator.LimitValidator;
import panacea.Validator.OLCValidator;
import panacea.Validator.ProductValidator;
import panacea.Validator.SwiftValidator;
import panacea.Validator.TFMValidator;
import panacea.Validator.WebManager;
import panacea.Validator.cbsglobal;
import panacea.common.DTObject;
import panacea.common.DateUtility;
import panacea.common.FormatUtils;
import java.sql.SQLException; 



// *********************************************************************************************************
    /*Method Name -								olcBrnCodekeypress
    *  Input 	- 								Key =OLC_BRN_CODE
    *  User ID									Key	=USER_ID	
     * User Branch	-						    Key	=USER_BRANCH
     * User Role Code -							Key	=UROLE_CODE	
      
    * 
    * Output	: Error Message  		- 		Key = ErrorMsg
    * 											Key = MBRN_NAME
    */

public class eolcval extends WebManager
{
	BranchValidator brnval	=	new BranchValidator();
	IRSValidator irsval     =   new IRSValidator ();
	DDPOValidator	ddpoval	=	new DDPOValidator();
	ClientValidator clieval	=	new ClientValidator();
	CommonValidator comnval	=	new	CommonValidator();
	TFMValidator tfmval		=	new	TFMValidator();
	AccountValidator accval	=	new AccountValidator();
	GlValidator	glval		=	new	GlValidator();
	IBCValidator	ibcval	=	new	IBCValidator();
	OLCValidator	olcval	=	new	OLCValidator();
	SwiftValidator swval	=	new SwiftValidator();//Changes in EOLC on 27-May-2018
	DTObject dtobj	=	new DTObject();
	
	
    public DTObject olcBrnCodekeypress(DTObject InputoBj)
        {
        try
            {       		
        	
                int  _olcBrnCode = 0;
                 
                String _BranchName="";
                if (InputoBj.getValue("OLC_BRN_CODE").trim().equalsIgnoreCase(""))
                {
                    _olcBrnCode = 0;
                }
                else
                {
                    _olcBrnCode = Integer.parseInt(  InputoBj.getValue("OLC_BRN_CODE") .trim().toString());
                }
                
               //changes in EOLC on 12-Jun-2018  start
                
                int _brnAuthcount = 0;
	    	 	String _userRoleCode = "";
	    	 	
	    	 	if (InputoBj.containsKey("USER_ROLE_CODE") == true)
	    	 	{
		    	 	if(InputoBj.getValue("USER_ROLE_CODE").trim().equalsIgnoreCase(""))
		            {
		            	_userRoleCode = "";
		            }
		            else
		            {
		            	_userRoleCode = InputoBj.getValue("USER_ROLE_CODE") .trim().toString();
		            }
	    	 	}
	    	 	else
	    	 	{
	    	 		_userRoleCode ="";
	    	 	}
	    	 	//changes in EOLC on 12-Jun-2018 end
	    	 	
                Init_ResultObj(InputoBj);
                
                if(!String.valueOf(_olcBrnCode).trim().equalsIgnoreCase(""))
                {
                	if(_olcBrnCode==0) 
                		if ((InputoBj.containsKey("OLC_BRN_CODE") == true) && (InputoBj.getValue("OLC_BRN_CODE").trim().equalsIgnoreCase("")))
                			Resultobj.setValue(ErrorKey,BLANK_CHECK);
                        else
                        Resultobj.setValue(ErrorKey,ZERO_CHECK);
                }
                
               if(Check_Result_Status())
               {
            	   dtobj.clearMap();
            	   dtobj.setValue("MBRN_CODE",String.valueOf(_olcBrnCode));
            	   Resultobj=brnval.chkBrnValid(dtobj);
            	   _BranchName=Resultobj.getValue("MBRN_NAME");
               }
               
               if(Check_Result_Status())
               {
            	   Resultobj.setValue("MBRN_NAME",_BranchName);
            	   
               }
               
             //changes in EOLC on 12-Jun-2018 start
               
               if(Check_Result_Status())
				{
					_QueryStr ="SELECT COUNT(*) FROM USERROLES WHERE UROLE_CODE = ? AND UROLE_ACCESS_FOR_BRN_DATA ='3' ";
					Set_preparedStatement(_QueryStr);
					_pstmt.setString(1, _userRoleCode);
					
					ResultSet rs1=ExecuteQuery();
					if(rs1.next())
					{
						_brnAuthcount = rs1.getInt(1);
						if(_brnAuthcount > 0)
						{
							Resultobj.setValue("USER_BRN_AUTH","1");
						}
						else
						{
							Resultobj.setValue("USER_BRN_AUTH","0");
						}
					}
				}
               
             //changes in EOLC on 12-Jun-2018 end
               
               
            }
        catch(Exception e)
            {
                Resultobj.setValue(ErrorKey,"Error in irttBrnCodekeypress" );
            }
        return Resultobj.copyofDTO();
        }
    // *********************************************************************************************************
    // *********************************************************************************************************
    /*Method Name - 							olcTypekeypress
    * Input 				- 					Key =OLC_TYPE
    * 											Key =CBD
    * 
    * Output	: Error Message  		- 		Key = ErrorMsg
    * 											Key = TNOMEN_AUTO_NUM
    * 											Key = TNOMEN_NUM_CHOICE
    * 											Key = FIN_YEAR
    * 											
    */
    
    public DTObject olcTypekeypress(DTObject InputoBj)
        {
        try
            {
                String  _olcType = "";
                String finyear="";		
                String _currBusDate="";
                String _coll_prod="";
                String _prodesc="";
                {
                	_olcType =   InputoBj.getValue("OLC_TYPE") .trim().toString();
                }
            Init_ResultObj(InputoBj);
                if(String.valueOf(_olcType).trim().equalsIgnoreCase(""))
                {
                    Resultobj.setValue(ErrorKey,BLANK_CHECK);
                }
                _currBusDate=InputoBj.getValue("CBD").trim().toString();
                finyear=getFinYear(_currBusDate);
                if(Check_Result_Status())
                {  
                	tfmval = new TFMValidator();
                	dtobj.clearMap();
                	dtobj.setValue("TNOMEN_NOMEN_CODE",_olcType);
                	dtobj.setValue(FetchReq,"true");
                	dtobj.setValue("FetchColumns","TNOMEN_LC_BILL_BG,TNOMEN_IW_OW,TNOMEN_AUTO_NUM,TNOMEN_NUM_CHOICE,TNOMEN_INLAND_OVERSEAS");
                	Resultobj=tfmval.valtnomen(dtobj);
                	String lcBillBg=Resultobj.getValue("TNOMEN_LC_BILL_BG");
	            	String lcIwOw=Resultobj.getValue("TNOMEN_IW_OW");
	            	String lcautonum=Resultobj.getValue("TNOMEN_AUTO_NUM");
                	String lcnumChoice=Resultobj.getValue("TNOMEN_NUM_CHOICE");
                	//changes-M.S.Jayanthi-11/11/2009-beg
                	String lcinover=Resultobj.getValue("TNOMEN_INLAND_OVERSEAS");
                	//changes-M.S.Jayanthi-11/11/2009-end
                	if(Check_Result_Status())
                    {
    	            	if(!lcBillBg.equalsIgnoreCase("L"))
    	            	{
    	            		 Resultobj.setValue(ErrorKey,"LC Type Should be Marked for Letter of Credit" );
    	            	}
    	            	if(Check_Result_Status())
    	                {
    		            	if(!lcIwOw.equalsIgnoreCase("O"))
    		            	{
    		            		 Resultobj.setValue(ErrorKey,"LC Type Should be Marked for Outward" );
    		            	}
    	                }
                     }
                	
                	if(Check_Result_Status())
              		 {
        				_QueryStr = "Select TRAC_COLL_PROD FROM TRACPARAM WHERE TRAC_NOMEN_CODE =?" ;
        				Set_preparedStatement(_QueryStr);
	                    _pstmt.setString(1, _olcType);
	                    Resultobj=Get_Value_From_Main("TRACPARAM");
	                    if(Check_Result_Status())
	                    {
	                    	 _coll_prod=Resultobj.getValue("TRAC_COLL_PROD");
	                        
	                    	if(Check_Result_Status())
	                        {
	                        	ProductValidator pv = new ProductValidator();
	                        	DTObject dtoinput1 = new DTObject();
	                        	dtoinput1.setValue("PRODUCT_CODE",_coll_prod);
	                        	Resultobj = pv.prodValid(dtoinput1);
	                        	_prodesc = Resultobj.getValue("PRODUCT_NAME");
	                        	
	                        }
	                    }
              		 }    

                	
	                if(Check_Result_Status())
	                {
	                	Resultobj.setValue("PRODUCT_CODE",_coll_prod);
	                	Resultobj.setValue("PRODUCT_NAME",_prodesc);
	                	Resultobj.setValue("TNOMEN_AUTO_NUM",lcautonum);
	            		Resultobj.setValue("TNOMEN_NUM_CHOICE",lcnumChoice);
	            		Resultobj.setValue("TNOMEN_INLAND_OVERSEAS",lcinover);
	            		Resultobj.setValue("FIN_YEAR",finyear);
	                	Resultobj.setValue(ErrorKey,"" );
	                }
                 }
            }
                
            
        catch(Exception e)
            {
                Resultobj.setValue(ErrorKey,"Error in olcTypekeypress" );
            }
        return Resultobj.copyofDTO();
        }

      // *********************************************************************************************************
    

    // *********************************************************************************************************
    /* Method Name - 				  	olcYearkeypress
    *  Input 	- 						Key	=OLC_BRN_CODE
    * 									Key	=OLC_TYPE
    * 									Key =OLC_YEAR
    *								    Key	=TNOMEN_AUTO_NUM 
    * 									Key =TNOMEN_NUM_CHOICE 
    * 									Key	=USER_OPTION
    * 									Key	=CBD
    * 									
    * 									
    									 
    * Output	: Error Message  	 - Key = ErrorMsg
       											 
     */
    
    
	public DTObject olcYearkeypress(DTObject InputoBj)
        {
        try
            {
                int  _olcYear = 0;
                int _olcBrnCode=0;
                String _currBusDate="";
                String _olcNumChoice="";
                String _olcAutoNum="";
                String _olcType="";
                String option="";
                long _orLastslused=0;
                long lastserial=0;
                String finyear="";
                String _corrRef_no="";
                String sl="";
                
                String s=InputoBj.getValue("OLC_YEAR");
                _currBusDate = InputoBj.getValue("CBD").trim().toString();
                String _dateStr[]=_currBusDate.split("-");
            	String str=_dateStr[2];


                if (InputoBj.getValue("OLC_YEAR").trim().equalsIgnoreCase(""))
                {
                	Resultobj.setValue(ErrorKey,BLANK_CHECK);
                }
                else
                {
                	_olcYear = Integer.parseInt(InputoBj.getValue("OLC_YEAR") .trim().toString());
                	_olcType =   InputoBj.getValue("OLC_TYPE") .trim().toString();
                	_olcNumChoice=InputoBj.getValue("TNOMEN_NUM_CHOICE") .trim().toString();
                	_olcAutoNum=InputoBj.getValue("TNOMEN_AUTO_NUM") .trim().toString();
                    _olcBrnCode = Integer.parseInt(  InputoBj.getValue("OLC_BRN_CODE") .trim().toString());
                     option=InputoBj.getValue("USER_OPTION") .trim().toString();
                }
                    Init_ResultObj(InputoBj);

                    finyear=getFinYear(_currBusDate);
                    
                    	if(_olcYear==0) 
                    	{	
                    		Resultobj.setValue(ErrorKey,ZERO_CHECK);
                    	}	
                    if(Check_Result_Status())
                    {
                    	if(!(_olcYear>=1900))
                    	{
                    		Resultobj.setValue(ErrorKey,"Year Should be greater than or equal to 1900");
                    	}
                    }	
                    	if(Check_Result_Status())
                    	{
                    		
                    		if ((InputoBj.getValue("TNOMEN_NUM_CHOICE").trim().equalsIgnoreCase("C"))&&( _olcYear > Integer.parseInt(str)))
                        		{
                        			Resultobj.setValue(ErrorKey,"Reference Year Should be <= Current Year" );
                        		}
                    		else if((InputoBj.getValue("TNOMEN_NUM_CHOICE").trim().equalsIgnoreCase("F"))&&( _olcYear > Integer.parseInt(finyear)))
                    			{
                    			Resultobj.setValue(ErrorKey,"Reference Year Should be <= Financial Year" );
                    			}
                    	}	
                				if(Check_Result_Status())
                    			{
                    				if ((InputoBj.getValue("USER_OPTION").trim().equalsIgnoreCase("A"))&&(InputoBj.getValue("TNOMEN_AUTO_NUM").trim().equalsIgnoreCase("1")))
                            		{
                    					 _QueryStr = "select TBILLSL_BRN_CODE,TBILLSL_NOMEN_CODE,TBILLSL_YEAR,TBILLSL_START_SL_NUM,TBILLSL_LAST_NUM_USED from TBILLSERIAL where TBILLSL_BRN_CODE=? and TBILLSL_NOMEN_CODE=? and TBILLSL_YEAR=?";
                    	                    Set_preparedStatement(_QueryStr);
                    	                    _pstmt.setInt(1,_olcBrnCode);
                    	                    _pstmt.setString(2,_olcType);
                    	                    _pstmt.setInt(3,_olcYear);
                    	                    Resultobj=Get_Value_From_Main("TBILLSERIAL");
                    	                    if(Check_Result_Status())
                    	                    {
                    	                    	if (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowNotPresent))
                                                {
                                                    Resultobj.setValue(ErrorKey,"Transaction Number Control Parameter Not Specified");
                                                }
                    	                    	else
                    	                    	{
                    	                    		_orLastslused=Long.parseLong(Resultobj.getValue("TBILLSL_LAST_NUM_USED"));
                        	                    	lastserial=_orLastslused+1;
                    	                    	}
                    	                    }
                    	                    if(Check_Result_Status())
                                    		{
                                    			tfmval		=	new	TFMValidator();
                                    			dtobj.clearMap();
                                            	dtobj.setValue("MBRN_CODE",String.valueOf(_olcBrnCode));
                                            	dtobj.setValue("TRFUNC_LINK_CODE",_olcType);
                                            	dtobj.setValue("TRFUNC_CLASSIFICATION","N");
                                            	dtobj.setValue("YEAR",String.valueOf(_olcYear));
                                            	dtobj.setValue("SERIAL",String.valueOf(lastserial));
                                            	Resultobj=tfmval.valtrcorefnum(dtobj);
                                            	_corrRef_no=Resultobj.getValue("CORR_REF_NUM");
                                            	if(!(Check_Result_Status()))
                                        		{
                                            		 Resultobj.setValue(ErrorKey,"Functional Code not Specified" );
                                        		}
                                    		}
                    	                    if(Check_Result_Status())
                    	                    {
                    	                    	Resultobj.setValue("CORR_REF_NUM",_corrRef_no);
                    	                    	Resultobj.setValue("OLC_LAST_NUM_USED",String.valueOf(_orLastslused));
                    	                    }
                    	            }
                    			}
                				
            }       			
          catch(Exception e)
            {
                Resultobj.setValue(ErrorKey,"Error in olcYearkeypress" );
            }
          return Resultobj.copyofDTO();
       }


    // *********************************************************************************************************
    // *********************************************************************************************************
    /*Method Name -						olcSlnokeypress
    * Input 	- 						Key =OLC_SL
    * 									Key =OLC_BRN_CODE                                         
    									Key =OLC_TYPE                                     
    									Key =OLC_YEAR 
    									Key =USER_OPTION
    									
    * Output: Error Message  	    - Key = ErrorMsg
    */
    
    public DTObject olcSlnokeypress(DTObject InputoBj)
        {
        try
            {
                int  _olcSlno = 0;
                int  _olcBranCode = 0;
                int  _olcYear = 0;
                int  _olcSl = 0;
                String _olcType="";
                String  _userOption="";
                String _corrRef_no="";
                
                 if (InputoBj.getValue("OLC_SL").trim().equalsIgnoreCase(""))
                 {
                	 Resultobj.setValue(ErrorKey,BLANK_CHECK);
                 }
                else
                 {
                	_olcSlno = Integer.parseInt(InputoBj.getValue("OLC_SL") .trim().toString());
                 }
                 _olcBranCode=Integer.parseInt(  InputoBj.getValue("OLC_BRN_CODE") .trim().toString());
                 _olcType=InputoBj.getValue("OLC_TYPE") .trim().toString();
                 _olcYear = Integer.parseInt(  InputoBj.getValue("OLC_YEAR") .trim().toString());
                 _userOption=InputoBj.getValue("USER_OPTION") .trim().toString();
                    

                    Init_ResultObj(InputoBj);
                   if(_olcSlno==0) 
                   	{
                	   Resultobj.setValue(ErrorKey,ZERO_CHECK);
                   	}
                        if(Check_Result_Status())
                        {
                        	//Changes P.Subramani-Chn-14/04/2008 Beg
                        	_QueryStr = "SELECT OLCA_AUTH_BY,OLCA_REJ_BY FROM OLCAMD WHERE OLCA_BRN_CODE = ? AND OLCA_LC_TYPE=? AND OLCA_LC_YEAR=? AND OLCA_LC_SL=? ";
    	                    Set_preparedStatement(_QueryStr);
    	                    _pstmt.setInt(1, _olcBranCode);
    	                    _pstmt.setString(2,_olcType);
    	                    _pstmt.setInt(3, _olcYear);
    	                    _pstmt.setInt(4, _olcSlno);
    	                    Get_Value_From_Main("OLCAMD");
    	                    if(Check_Result_Status())
    	                    {
    	                    	if(_userOption.equalsIgnoreCase("M"))
    	                    	{
	    	                    	if (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowPresent))
	                                {
	                                    Resultobj.setValue(ErrorKey,"Record Already Amended cannot Modify");
	                                }
	    	                    	else
	        	                    {
	    	                    		_QueryStr = "SELECT OLC_CORR_REF_NUM,OLC_AUTH_BY,OLC_REJ_BY FROM OLC WHERE OLC_BRN_CODE = ? AND OLC_LC_TYPE=? AND OLC_LC_YEAR=? AND OLC_LC_SL=? ";
	            	                    Set_preparedStatement(_QueryStr);
	            	                    _pstmt.setInt(1, _olcBranCode);
	            	                    _pstmt.setString(2,_olcType);
	            	                    _pstmt.setInt(3, _olcYear);
	            	                    _pstmt.setInt(4, _olcSlno);
	            	                    Get_Value_From_Main("OLC");
	            	                    if(Check_Result_Status())
	            	                    {//Changes P.Subramani-Chn-11/09/2008 Beg
            	                    		if (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowNotPresent))
	            	                    	{
	            	                    		Resultobj.setValue(ErrorKey,"Record Does Not Exist to Modify" );
	            	                    	}
	            	                    	if (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowPresent))
            	                    		{
            	                    			if(!(Resultobj.getValue("OLC_AUTH_BY")==null))
            	                    			{
            	                    				Resultobj.setValue(ErrorKey,"Record Already Authorised Cannot Modify" );
            	                    			}
            	                    			if(!(Resultobj.getValue("OLC_REJ_BY")==null))
            	                    			{
            	                    				Resultobj.setValue(ErrorKey,"Record Already Rejected Cannot Modify" );
            	                    			}
            	                    		}
	            	                    }//Changes P.Subramani-Chn-11/09/2008 End	
//	            	                  Removed P.Subramani-chn-11/09/2008 Beg
            	                    	/*else
            	                    	{
	            	                    	if ((_userOption.equalsIgnoreCase("A"))&& (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowPresent)))
	            	                    	{
	            	                    		Resultobj.setValue(ErrorKey,"Record Already Exists" );
	            	                    	}
	            	                    	if(Check_Result_Status())
	            	                    	{
		            	                    	if ((_userOption.equalsIgnoreCase("A"))&& (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowNotPresent)))
		            	                    	{
		            	                    		tfmval		=	new	TFMValidator();
		                                			dtobj.clearMap();
		                                        	dtobj.setValue("MBRN_CODE",String.valueOf(_olcBranCode));
		                                        	dtobj.setValue("TRFUNC_LINK_CODE",_olcType);
		                                        	dtobj.setValue("TRFUNC_CLASSIFICATION","N");
		                                        	dtobj.setValue("YEAR",String.valueOf(_olcYear));
		                                        	dtobj.setValue("SERIAL",String.valueOf(_olcSlno));
		                                        	Resultobj=tfmval.valtrcorefnum(dtobj);
		                                        	_corrRef_no=Resultobj.getValue("CORR_REF_NUM");
		                                        	if(!(Check_Result_Status()))
		                                    		{
		                                        		 Resultobj.setValue(ErrorKey,"Functional Code not Specified" );
		                                    		}
		            	                    	}
	            	                    	}
            	                    	}*/	//Removed P.Subramani-chn-11/09/2008 End
			            	        }
	        	                }
	    	                }
    	                //Changes P.Subramani-Chn-14/04/2008 End
    	                }
                        /*if(Check_Result_Status())
                        {
                        	Resultobj.setValue("CORR_REF_NUM",_corrRef_no); 
                        	Resultobj.setValue(ErrorKey,"" );
                        }*/
                    }
                catch(Exception e)
                    {
                	  // _pstmt.close();
                        Resultobj.setValue(ErrorKey,"Error in olcSlnokeypress" );
                    }
                return Resultobj.copyofDTO();
                }
    // *********************************************************************************************************
    // *********************************************************************************************************
    /*Method Name					-	olcPresanctionDatekeypress
    * Input 	- 						
    * 									Key =OLC_SANCTION_DATE
    * 									kEY =CBD
    *
    *Output	: Error Message  		- Key = ErrorMsg
    */
    
    public DTObject olcPresanctionDatekeypress(DTObject InputoBj)
        {
        try
            {
                String  _olcPresanctionDate = "";
                String  _currBusDate="";
                _currBusDate=InputoBj.getValue("CBD") .trim().toString();

                {
                	_olcPresanctionDate =   InputoBj.getValue("OLC_SANCTION_DATE") .trim().toString();
                }
            Init_ResultObj(InputoBj);
                if(String.valueOf(_olcPresanctionDate).trim().equalsIgnoreCase(""))
                {
                    Resultobj.setValue(ErrorKey,BLANK_CHECK);
                }
                if(!_olcPresanctionDate.equalsIgnoreCase(""))
                {
                if(Check_Result_Status())
                    {
                	 CheckDate(_olcPresanctionDate);	
                	 if(Check_Result_Status())
                     {
                     	if (!(DateUtility.DateLessThanOrEqual(_olcPresanctionDate,_currBusDate)))
                     	{
                     		Resultobj.setValue(ErrorKey,DATE_LESS_EQ_CBD);
                     	}
                     }
                 }
             }
             if(Check_Result_Status())
             {
             	 Resultobj.setValue(ErrorKey,"" );
             }
         }
     catch(Exception e)
         {
             Resultobj.setValue(ErrorKey,"Error in olcPresanctionDatekeypress" );
         }
     return Resultobj.copyofDTO();
     }
//  *********************************************************************************************************
    // *********************************************************************************************************
    /*Method Name					-	olcSanctionDaySlkeypress
    * Input 	- 						Key =OLC_BRANCH_CODE
    * 									Key =OLC_TYPE
    * 									Key=OLC_ENTRY_DATE
    * 									Key=OLC_DAY_SER
    * 									Key=USER_OPTION
    * 
    * Output	: Error Message   		Key = ErrorMsg
										Key = 
										Key = 
										Key = NOSTROSTMT_AMOUNT,
										Key = NOSTROSTMT_VALUE_DATE,
										Key = NOSTROSTMT_CREDIT_TO_ACC,
										Key = NOSTROSTMT_PARTICULARS,
										Key = NOSTROSTMT_BENEF_NAME,
										Key = NOSTROSTMT_UTILISED_AMT
										Key = NOSTROUTIL_UTIL_AMT
										     
    * 
    * 
    */
    
    public DTObject olcSanctionDaySlkeypress(DTObject InputoBj)
        {
        try
            {
        		int  _olcBrnCode = 0;
        		int  _olc_day_serial = 0;
        		String _olc_entry_date="";
        		String _userOption="";
        		String _olcType="";
        		String _BranchName="";
                
        		String _lcps_lc_type="";
                String _lcps_sanction_date="";
                String _lcps_san_not_san="";
                String _lcps_lc_year="";
                String _lcps_lc_Sl="";
                String _lcps_cust_no="";
                String _lcps_bene_code="";
                
                String _lcps_san_Date=""; 
                
                String _lcps_con_rate="";
                String _lcps_lc_lia_acc="";
                String _lcps_lc_brn="";
                String _lcps_lc_curr="";
                String _lcps_lc_amt="";
                String _lcps_pos_dev="";
                String _lcps_neg_dev="";
                String _lcps_bene_name="";
                String _lcps_bene_cntry="";
                String _lcps_no_of_tenors="";
                String _lcps_tot_lia_lc_curr="";
                String _lcps_tot_lia_base_curr="";
                String _lcps_marg_curr="";
                String _lcps_marg_amt="";
                String _lcps_marg_perc="";
                String _lcps_excess_limit_marg_perc="";
                String _lcps_lim_curr="";
                String _lcps_tot_lia_lim_curr="";
                String _lcps_usance_int_by_appl="";
                String _lcps_approval_refusal="";
                String _lcps_appvl_rej_ref_no ="";
                String _lcps_approval_by="";
                
                
                String _client_name="";
                String _client_add1="";
                String _client_add2="";
                String _client_add3="";
                String _client_add4="";
                String _client_add5="";
                
                String bene_add1="";
                String bene_add2="";
                String bene_add3="";
                String bene_add4="";
                String bene_add5="";
                
                String _currencyName="";
                String _totliablimcurr="";
        		String _currcode="";
        		String _currname="";
        		String _basecurrname="";
        		int _limline=0;
        		String _lmtlinedesc="";
        		String _acntnum="";
        		String _intacntnum="";
        		String _acntname="";
        		String _effbal="";
        		String _outstdamt="";
        		String _sanccurr="";
        		String _sancamt="";
        		String _declength="";
        		String baseCurrency=get_base_curr_code();
        		String intaccno="";
        		//Changes P.Subramani-Chn23/10/2008 
        		String _lcps_exc_marg_amt="";
        		String tnomen_inland_overseas="";
        		
                
                Init_ResultObj(InputoBj);
                
                if (InputoBj.getValue("OLC_BRANCH_CODE").trim().equalsIgnoreCase(""))
                	{
                	Resultobj.setValue(ErrorKey,"Should not be Blank" );
                	}
                else if (InputoBj.getValue("OLC_ENTRY_DATE").trim().equalsIgnoreCase(""))
                	{
                	Resultobj.setValue(ErrorKey,"Should not be Blank" );
                	}	
                else if (InputoBj.getValue("OLC_DAY_SER").trim().equalsIgnoreCase(""))
                    {
                    	Resultobj.setValue(ErrorKey,"Should not be Blank" );
                    }
                else if (InputoBj.getValue("OLC_TYPE").trim().equalsIgnoreCase(""))
                    {
                    	Resultobj.setValue(ErrorKey,"Should not be Blank" );
                    }	
                    else
                    	{
	                	_olcBrnCode = Integer.parseInt(  InputoBj.getValue("OLC_BRANCH_CODE") .trim().toString());
	                	_olc_day_serial = Integer.parseInt( InputoBj.getValue("OLC_DAY_SER") .trim().toString());
	                	_olc_entry_date = InputoBj.getValue("OLC_ENTRY_DATE") .trim().toString();
	                    _userOption=InputoBj.getValue("USER_OPTION").trim().toString();
	                    _olcType=InputoBj.getValue("OLC_TYPE").trim().toString();
	                    tnomen_inland_overseas=InputoBj.getValue("TNOMEN_INLAND_OVERSEAS").trim().toString();
                    	}
                
                
                if(Check_Result_Status())
                {
                	
                	dtobj.clearMap();
                	dtobj.setValue("BRANCH_CODE",String.valueOf(_olcBrnCode));
                	dtobj.setValue("ENTRY_DATE",_olc_entry_date);
                	dtobj.setValue("DAY_SERIAL",String.valueOf(_olc_day_serial));
                	dtobj.setValue("FetchReq","true");
                	//Changes P.Subramani-Chn-23/10/2008 
                	dtobj.setValue("FetchColumns","LCPS_LIMIT_LINE_NUM,LCPS_CONV_RATE_LIM_CURR,LCPS_CUST_LIAB_ACC_NUM,facno(LCPS_CUST_LIAB_ACC_NUM)LCPS_CUST_LIAB_ACC_NUM1,LCPS_LC_BRANCH,LCPS_CUST_NUM,LCPS_LC_TYPE,LCPS_LC_SL,LCPS_LC_YR,LCPS_LC_CURR,LCPS_LC_AMT,LCPS_POS_DEV,LCPS_NEG_DEV,LCPS_BENEF_CODE,LCPS_BENEF_NAME,LCPS_BENEF_CNTRY,LCPS_NO_OF_TENORS,LCPS_TOT_LIAB_LC_CURR,LCPS_TOT_LIAB_BASE_CURR,LCPS_MARG_CURR,LCPS_MARG_AMT,LCPS_MARG_PERC,LCPS_EXCESS_LIMIT_MARG_PERC,LCPS_EXCESS_LIMIT_MARG_AMT,LCPS_LIM_CURR,LCPS_TOT_LIAB_LIM_CURR,LCPS_USANCE_INT_BY_APPL,LCPS_APPROVAL_REFUSAL,LCPS_DATE_OF_APPROVAL,LCPS_APPVL_REJ_REF_NUM,LCPS_APPROVAL_BY");
                	Resultobj=olcval.vallcps(dtobj);
                	
                	if(Check_Result_Status())
                    {
                	_limline=Integer.parseInt(Resultobj.getValue("LCPS_LIMIT_LINE_NUM"));
                	_lcps_cust_no = Resultobj.getValue("LCPS_CUST_NUM");
                	_lcps_lc_type=Resultobj.getValue("LCPS_LC_TYPE");
                	_lcps_lc_Sl = Resultobj.getValue("LCPS_LC_SL");
                	_lcps_lc_year= Resultobj.getValue("LCPS_LC_YR");
                	_lcps_sanction_date=Resultobj.getValue("LCPS_DATE_OF_APPROVAL");
                	_lcps_san_not_san=Resultobj.getValue("LCPS_APPROVAL_REFUSAL");
                	_lcps_bene_code=Resultobj.getValue("LCPS_BENEF_CODE");
                	
                	_lcps_con_rate=Resultobj.getValue("LCPS_CONV_RATE_LIM_CURR");
                	_lcps_lc_lia_acc=Resultobj.getValue("LCPS_CUST_LIAB_ACC_NUM1");
                	 intaccno=Resultobj.getValue("LCPS_CUST_LIAB_ACC_NUM");
                	_lcps_lc_brn=Resultobj.getValue("LCPS_LC_BRANCH");
                	_lcps_lc_curr=Resultobj.getValue("LCPS_LC_CURR");
                	_lcps_lc_amt=Resultobj.getValue("LCPS_LC_AMT");
                	_lcps_pos_dev=Resultobj.getValue("LCPS_POS_DEV");
                	_lcps_neg_dev=Resultobj.getValue("LCPS_NEG_DEV");
                	_lcps_bene_code=Resultobj.getValue("LCPS_BENEF_CODE");
                	_lcps_bene_name=Resultobj.getValue("LCPS_BENEF_NAME");
                	_lcps_bene_cntry=Resultobj.getValue("LCPS_BENEF_CNTRY");
                	_lcps_no_of_tenors=Resultobj.getValue("LCPS_NO_OF_TENORS");
                	_lcps_tot_lia_lc_curr=Resultobj.getValue("LCPS_TOT_LIAB_LC_CURR");
                	_lcps_tot_lia_base_curr=Resultobj.getValue("LCPS_TOT_LIAB_BASE_CURR");
                	_lcps_marg_curr=Resultobj.getValue("LCPS_MARG_CURR");
                	_lcps_marg_amt= Resultobj.getValue("LCPS_MARG_AMT");
                	_lcps_marg_perc = Resultobj.getValue("LCPS_MARG_PERC");
                	_lcps_excess_limit_marg_perc = Resultobj.getValue("LCPS_EXCESS_LIMIT_MARG_PERC");
                	//Changes P.Subramani-Chn-23/10/2008
                	_lcps_exc_marg_amt= Resultobj.getValue("LCPS_MARG_AMT");
                	_lcps_lim_curr = Resultobj.getValue("LCPS_LIM_CURR");
                	_lcps_tot_lia_lim_curr = Resultobj.getValue("LCPS_TOT_LIAB_LIM_CURR");
                	_lcps_usance_int_by_appl = Resultobj.getValue("LCPS_USANCE_INT_BY_APPL");
                	_lcps_approval_refusal = Resultobj.getValue("LCPS_APPROVAL_REFUSAL");
                	_lcps_appvl_rej_ref_no = Resultobj.getValue("LCPS_APPVL_REJ_REF_NUM");
                	_lcps_approval_by = Resultobj.getValue("LCPS_APPROVAL_BY");
                    }
                }
              //Changes M.S.JAYANTHI-Chn-11/11/2009 BEG
                if(Check_Result_Status()){
                	if((tnomen_inland_overseas.equalsIgnoreCase("I"))&&
                	(!_lcps_lc_curr.equalsIgnoreCase(get_base_curr_code()))){
                		Resultobj.setValue(ErrorKey,"Presanction LC Currency Should be Base Currency for Inland LCs");
                	}
                }
              //Changes M.S.JAYANTHI-Chn-11/11/2009 end
               if(Check_Result_Status())
                {
                	if (_lcps_lc_type.equalsIgnoreCase(_olcType))
                		{
                		if(!(_lcps_sanction_date==null))
                		{
                		 if(!(_lcps_sanction_date.equalsIgnoreCase("")))
                		 	{
                			 if(_lcps_san_not_san.equalsIgnoreCase("A"))
                			 	{
                				 if(_userOption.equalsIgnoreCase("A"))
                				 	{
                					 if(!(_lcps_lc_year.equalsIgnoreCase("0") && _lcps_lc_Sl.equalsIgnoreCase("0") ))
                							 {
                						 		Resultobj.setValue(ErrorKey,"LC Already Issued for this Presanction Entry " );
                							 }
                				 	}
                			 	}
                			 	else
                			 		{
                			 			Resultobj.setValue(ErrorKey,"Presanction Entry is Rejected" );
                			 		}
                			 }
                		 	else
                		 		{
                		 			Resultobj.setValue(ErrorKey,"Presanction Entry is Not Approved" );
                		 		}
                			}
                			else
                			{
        		 			Resultobj.setValue(ErrorKey,"Presanction Entry is Not Approved" );
                			}
                		}
                		else
       			 			{
                				Resultobj.setValue(ErrorKey,"Presanction LC Type And This LC Type Should Be Same" );
       			 			}
                } 
                if(Check_Result_Status())
                {	
                	clieval	=	new ClientValidator();
                	dtobj.clearMap();
    	    		dtobj.setValue("CLIENTS_CODE",_lcps_cust_no);
    	    		dtobj.setValue(FetchReq,"true");
    	    		Resultobj=clieval.clientValid(dtobj);
    	    		_client_name=Resultobj.getValue("CLIENTS_NAME");
    	    		_client_add1=Resultobj.getValue("CLIENTS_ADDR1");
    	    		_client_add2=Resultobj.getValue("CLIENTS_ADDR2");
    	    		_client_add3=Resultobj.getValue("CLIENTS_ADDR3");
    	    		_client_add4=Resultobj.getValue("CLIENTS_ADDR4");
    	    		_client_add5=Resultobj.getValue("CLIENTS_ADDR5");
                }
                if(Check_Result_Status())
                {
               	if(!(_lcps_bene_code==null))
                {
                	tfmval	=	new	TFMValidator();
                	dtobj.clearMap();
    	    		dtobj.setValue("CPARTY_ALPHA_CODE",_lcps_bene_code);
    	    		dtobj.setValue("FetchColumns","CPARTY_ADDR1,CPARTY_ADDR2,CPARTY_ADDR3,CPARTY_ADDR4,CPARTY_ADDR5,CPARTY_CNTRY_CODE");
    	    		dtobj.setValue(FetchReq,"true");
    	    		Resultobj=tfmval.valcparty(dtobj);
    	    		bene_add1=Resultobj.getValue("CPARTY_ADDR1");
    	    		bene_add2=Resultobj.getValue("CPARTY_ADDR2");
    	    		bene_add3=Resultobj.getValue("CPARTY_ADDR3");
    	    		bene_add4=Resultobj.getValue("CPARTY_ADDR4");
    	    		bene_add5=Resultobj.getValue("CPARTY_ADDR5");
                }
                }
                if(Check_Result_Status())
                {
                if(String.valueOf(_lcps_lc_lia_acc).trim().equalsIgnoreCase(""))
                {
                    Resultobj.setValue(ErrorKey,BLANK_CHECK);
                }
                }
                if(Check_Result_Status())
                {
                	 AccountValidator AV=new AccountValidator();
            		 DTObject dtoinput = new DTObject();
            		 dtoinput.setValue("BRANCH_CODE",String.valueOf(_olcBrnCode));
            		 dtoinput.setValue("ACCOUNT_NUMBER",String.valueOf(_lcps_lc_lia_acc));
            		 dtoinput.setValue("FetchReq","true");
                 	 dtoinput.setValue("FetchColumns","ACNTS_CURR_CODE");
                 	 Resultobj = AV.chkacntstatus(dtoinput);
                 	 _currcode = Resultobj.getValue("ACNTS_CURR_CODE");
                 	_acntnum = Resultobj.getValue("ACNTS_ACCOUNT_NUMBER");
                 	 _intacntnum = Resultobj.getValue("ACNTS_INTERNAL_ACNUM");
                 	 _acntname = Resultobj.getValue("ACNTS_AC_NAME1");
                 	_effbal = Resultobj.getValue("EFF_BALANCE");
               }
                if(Check_Result_Status())
                {
                	comnval	=	new	CommonValidator();
                	dtobj.clearMap();
                	dtobj.setValue("CURR_CODE",_lcps_lc_curr);
                	Resultobj=comnval.valcurrcd(dtobj);
                	_currencyName=Resultobj.getValue("CURR_NAME");
                	
                	if(Check_Result_Status())
                	{ 
                		
                		
                    	_declength =String.valueOf( cbsglobal.getcurrdeclength(_lcps_lc_curr));
                     }
                	
                     
                }
               	if(Check_Result_Status())
                {
             	if(!(_lcps_lc_brn==null))
                {
             	   dtobj.clearMap();
             	   dtobj.setValue("MBRN_CODE",String.valueOf(_lcps_lc_brn));
             	   Resultobj=brnval.chkBrnValid(dtobj);
             	   _BranchName=Resultobj.getValue("MBRN_NAME");
                }
                }
                if(Check_Result_Status())
                	{
                	if(_limline!=0)
         				{
         				LimitValidator LV1=new LimitValidator();
         				DTObject dtoinput = new DTObject();
         				dtoinput.setValue("LMTLINE_NUM",String.valueOf(_limline));
         				dtoinput.setValue("LMTLINE_CLIENT_CODE",String.valueOf(_lcps_cust_no));
         				Resultobj = LV1.vallimitline(dtoinput);
         				_lmtlinedesc = Resultobj.getValue("LMTLINE_FACILITY_DESCN");
         				}
                	}
                if(Check_Result_Status())
                {	
                	Resultobj.setValue("LMTLINE_FACILITY_DESCN",_lmtlinedesc);
                	Resultobj.setValue("MBRN_NAME",_BranchName);
                	Resultobj.setValue("LCPS_LIMIT_LINE_NUM",String.valueOf(_limline));
                	Resultobj.setValue("OLC_CURR_NAME",_currencyName);
                    Resultobj.setValue("LIMIT_DEC_LEN",_declength);
                	Resultobj.setValue("LCPS_CONV_RATE_LIM_CURR",_lcps_con_rate);
                	Resultobj.setValue("LCPS_CUST_LIAB_ACC_NUM1",_lcps_lc_lia_acc);
                	Resultobj.setValue("LCPS_CUST_LIAB_ACC_NUM",intaccno);
                	Resultobj.setValue("LCPS_LC_BRANCH",_lcps_lc_brn);
                	Resultobj.setValue("LCPS_CUST_NUM",_lcps_cust_no);
                	Resultobj.setValue("LCPS_LC_TYPE",_lcps_lc_type);
                	Resultobj.setValue("LCPS_LC_SL",_lcps_lc_Sl);
                	Resultobj.setValue("LCPS_LC_YR",_lcps_lc_year);
                	Resultobj.setValue("LCPS_DATE_OF_APPROVAL",_lcps_sanction_date);
                	Resultobj.setValue("LCPS_APPROVAL_REFUSAL",_lcps_san_not_san);
                	Resultobj.setValue("LCPS_BENEF_CODE",_lcps_bene_code);
                	Resultobj.setValue("LCPS_LC_CURR",_lcps_lc_curr);
                	Resultobj.setValue("LCPS_LC_AMT",_lcps_lc_amt);
                	Resultobj.setValue("LCPS_POS_DEV",_lcps_pos_dev);
                	Resultobj.setValue("LCPS_NEG_DEV",_lcps_neg_dev);
                	Resultobj.setValue("LCPS_BENEF_CODE",_lcps_bene_code);
                	Resultobj.setValue("LCPS_BENEF_NAME",_lcps_bene_name);
                	Resultobj.setValue("LCPS_BENEF_CNTRY",_lcps_bene_cntry);
                	Resultobj.setValue("LCPS_NO_OF_TENORS",_lcps_no_of_tenors);
                	Resultobj.setValue("LCPS_TOT_LIAB_LC_CURR",_lcps_tot_lia_lc_curr);
                	Resultobj.setValue("LCPS_TOT_LIAB_BASE_CURR",_lcps_tot_lia_base_curr);
                	Resultobj.setValue("LCPS_MARG_CURR",_lcps_marg_curr);
                	Resultobj.setValue("LCPS_MARG_AMT",_lcps_marg_amt);
                	Resultobj.setValue("LCPS_MARG_PERC",_lcps_marg_perc);
                	Resultobj.setValue("LCPS_EXCESS_LIMIT_MARG_PERC",_lcps_excess_limit_marg_perc);
                	//Changes P.Subramani-Chn-23/10/2008 
                	Resultobj.setValue("LCPS_EXCESS_LIMIT_MARG_AMT",_lcps_exc_marg_amt);
                	Resultobj.setValue("LCPS_LIM_CURR",_lcps_lim_curr);
                	Resultobj.setValue("LCPS_TOT_LIAB_LIM_CURR",_lcps_tot_lia_lim_curr);
                	Resultobj.setValue("LCPS_USANCE_INT_BY_APPL",_lcps_usance_int_by_appl);
                	Resultobj.setValue("LCPS_APPROVAL_REFUSAL",_lcps_approval_refusal);
                	Resultobj.setValue("LCPS_APPVL_REJ_REF_NUM",_lcps_appvl_rej_ref_no);
                	Resultobj.setValue("LCPS_APPROVAL_BY",_lcps_approval_by);
                	
                	Resultobj.setValue("CLIENTS_NAME",_client_name);
    	    		Resultobj.setValue("CLIENTS_ADDR1",_client_add1);
    	    		Resultobj.setValue("CLIENTS_ADDR2",_client_add2);
    	    		Resultobj.setValue("CLIENTS_ADDR3",_client_add3);
    	    		Resultobj.setValue("CLIENTS_ADDR4",_client_add4);
    	    		Resultobj.setValue("CLIENTS_ADDR5",_client_add5);
    	    		
    	    		
    	    		Resultobj.setValue("CPARTY_ADDR1",bene_add1);
    	    		Resultobj.setValue("CPARTY_ADDR2",bene_add2);
    	    		Resultobj.setValue("CPARTY_ADDR3",bene_add3);
    	    		Resultobj.setValue("CPARTY_ADDR4",bene_add4);
    	    		Resultobj.setValue("CPARTY_ADDR5",bene_add5);
    	    		
    	    		
    	    		Resultobj.setValue("CURR_CODE",_currcode);
    	    		Resultobj.setValue("ACTUAL_ACNT_NUM",_acntnum);
    	    		Resultobj.setValue("INTERNAL_ACNT_NUM",_intacntnum);
    	    		Resultobj.setValue("ACNT_NAME",_acntname);
    	    		Resultobj.setValue("EFF_BAL",_effbal);
                	Resultobj.setValue(ErrorKey,"" );	
                }
            }
        
        catch(Exception e)
            {
                Resultobj.setValue(ErrorKey,"Error in olcSanctionDaySlkeypress" );
            }
        return Resultobj.copyofDTO();
        }
    
   //  *********************************************************************************************************
    // *********************************************************************************************************
    /*Method Name					-	olcLcDatekeypress
    * Input 	- 						
    * 									Key =OLC_LC_DATE
    * 									Key =OLC_SANCTION_DATE
    * 									kEY =CBD
    *
    *Output	: Error Message  		- Key = ErrorMsg
    */
    
    public DTObject olcLcDatekeypress(DTObject InputoBj)
        {
        try
            {
                String  _olcLcDate = "";
                String  _olcSanctionDate = "";
                String  _currBusDate="";
                _currBusDate=InputoBj.getValue("CBD") .trim().toString();

                {
                	_olcLcDate =   InputoBj.getValue("OLC_LC_DATE") .trim().toString();
                	_olcSanctionDate =   InputoBj.getValue("OLC_SANCTION_DATE") .trim().toString();
                }
            Init_ResultObj(InputoBj);
                if(String.valueOf(_olcSanctionDate).trim().equalsIgnoreCase(""))
                {
                    Resultobj.setValue(ErrorKey,BLANK_CHECK);
                }
                if(String.valueOf(_olcLcDate).trim().equalsIgnoreCase(""))
                {
                    Resultobj.setValue(ErrorKey,BLANK_CHECK);
                }
                if(!_olcLcDate.equalsIgnoreCase(""))
                {
                if(Check_Result_Status())
                    {
                	 CheckDate(_olcLcDate);	
                	 if(Check_Result_Status())
                     {
                     	if (!(DateUtility.DateLessThanOrEqual(_olcLcDate,_currBusDate)))
                     	{
                     		Resultobj.setValue(ErrorKey,DATE_LESS_EQ_CBD);
                     	}
                     	else if(!(DateUtility.DateGreaterThanOrEqual(_olcLcDate,_olcSanctionDate)))
                     	{
                     		Resultobj.setValue(ErrorKey,"LC Date Should be >= LC Sanctioned On Date");
                     	}
                     }
                 }
             }
             if(Check_Result_Status())
             {
             	 Resultobj.setValue(ErrorKey,"" );
             }
         }
     catch(Exception e)
         {
             Resultobj.setValue(ErrorKey,"Error in olcLcDatekeypress" );
         }
     return Resultobj.copyofDTO();
     }
    
    
    
// *********************************************************************************************************
// *********************************************************************************************************
   
    /*Method Name					-		olcBeneficiaryCntrykeypress 
     * 
    * Input 	- 							Key =OLC_CNTRY_CODE
    * Output	: Error Message  		- 		
    * 											Key = ErrorMsg
    * 											Key	= CNTRY_NAME
    */
    
    public DTObject olcBeneficiaryCntrykeypress(DTObject InputoBj)
        {
        try
            {
                String  _olcCntry = "";
                {
                    _olcCntry =   InputoBj.getValue("OLC_CNTRY_CODE") .trim().toString();
                }
            Init_ResultObj(InputoBj);
                if(String.valueOf(_olcCntry).trim().equalsIgnoreCase(""))
                {
                    Resultobj.setValue(ErrorKey,BLANK_CHECK);
                }
                if(Check_Result_Status())
                {
                	comnval	=	new	CommonValidator();
                	dtobj.clearMap();
                	dtobj.setValue("CNTRY_CODE",_olcCntry);
                	Resultobj=comnval.valcntrycd(dtobj);
                }
                if(Check_Result_Status())
                {
                	 Resultobj.setValue(ErrorKey,"" );
                }
            }
        catch(Exception e)
            {
                Resultobj.setValue(ErrorKey,"Error in olcBeneficiaryCntrykeypress" );
            }
        return Resultobj.copyofDTO();
        }
    
//  *********************************************************************************************************
    // *********************************************************************************************************
    /*Method Name			-			olcBnkkeypress
    * Input 	- 						Key =OLC_BNK
    * 
    * Output	: Error Message  		Key = ErrorMsg
    * 									Key	= BANKCD_NAME
    */
    
    public DTObject olcBnkkeypress(DTObject InputoBj)
        {
        try
            {
                String  _olcBnk = "";
                {
                    _olcBnk =   InputoBj.getValue("OLC_BNK") .trim().toString();
                }
                    Init_ResultObj(InputoBj);
                    if(String.valueOf(_olcBnk).trim().equalsIgnoreCase(""))
                    {
                        Resultobj.setValue(ErrorKey,BLANK_CHECK);
                    }
                    if(Check_Result_Status())
                    {
                	comnval	=	new	CommonValidator();    
                	dtobj.clearMap();
    	        	dtobj.setValue("BANKCD_CODE",_olcBnk);
    	        	Resultobj=comnval.valbankcd(dtobj);
                    }
    	        	if(Check_Result_Status())
                    {
                    	 Resultobj.setValue(ErrorKey,"" );
                    }
                }
            catch(Exception e)
                {
                    Resultobj.setValue(ErrorKey,"Error in olcBnkkeypress" );
                }
            return Resultobj.copyofDTO();
            }

    // *********************************************************************************************************
    // *********************************************************************************************************
    /*Method Name				-		olcBrnkeypress
    * 
    * Input 	- 						Key =OLC_BRN
    * 									Key= OLC_BNK
    * 
    * Output	: Error Message  		Key = ErrorMsg
    * 									Key	= MBKBRN_NAME
    */
    
    public DTObject olcBrnkeypress(DTObject InputoBj)
        {
        try
            {
                String  _olcBrn = "";
                String _olcBnk ="";
                String brnname="";
                String add1="";
                String add2="";
                String add3="";
                String add4="";
                String add5="";
                
                {
                	_olcBrn =   InputoBj.getValue("OLC_BRN") .trim().toString();
                }
                _olcBnk	=	InputoBj.getValue("OLC_BNK") .trim().toString();

                Init_ResultObj(InputoBj);
                if (!InputoBj.getValue("OLC_BNK").trim().equalsIgnoreCase(""))
                {
                    if(String.valueOf(_olcBrn).trim().equalsIgnoreCase(""))
                    {
                        Resultobj.setValue(ErrorKey,BLANK_CHECK);
                    }
                }
                if(Check_Result_Status())
                {
                	comnval	=	new	CommonValidator();
                	dtobj.clearMap();
                    dtobj.setValue("MBKBRN_BANK_CODE",_olcBnk);
                    dtobj.setValue("MBKBRN_BRN_CODE",_olcBrn);
                    dtobj.setValue("FetchColumns","MBKBRN_ADDR1,MBKBRN_ADDR2,MBKBRN_ADDR3,MBKBRN_ADDR4,MBKBRN_ADDR5");
                    dtobj.setValue(FetchReq,"true");
                    Resultobj=comnval.valmbkbrn(dtobj);
                    brnname=Resultobj.getValue("MBKBRN_NAME");
                    add1=Resultobj.getValue("MBKBRN_ADDR1");
                    add2=Resultobj.getValue("MBKBRN_ADDR2");
                    add3=Resultobj.getValue("MBKBRN_ADDR3");
                    add4=Resultobj.getValue("MBKBRN_ADDR4");
                    add5=Resultobj.getValue("MBKBRN_ADDR5");
                }
                if(Check_Result_Status())
                {
                	 Resultobj.setValue("MBKBRN_NAME",brnname); 
                	 Resultobj.setValue("MBKBRN_ADDR1",add1);
                     Resultobj.setValue("MBKBRN_ADDR2",add2);
                     Resultobj.setValue("MBKBRN_ADDR3",add3);
                     Resultobj.setValue("MBKBRN_ADDR4",add4);
                     Resultobj.setValue("MBKBRN_ADDR5",add5); 
                	Resultobj.setValue(ErrorKey,"" );
                }
                }
            catch(Exception e)
                {
                    Resultobj.setValue(ErrorKey,"Error in olcBrnkeypress" );
                }
            return Resultobj.copyofDTO();
            }

//  *********************************************************************************************************
    // *********************************************************************************************************
    /*Method Name					-		olcCntrykeypress 
     * 
    * Input 	- 							Key =OLC_CNTRY_CODE
    * Output	: Error Message  		- 		
    * 											Key = ErrorMsg
    * 											Key	= CNTRY_NAME
    */
    
    public DTObject olcCntrykeypress(DTObject InputoBj)
        {
        try
            {
                String  _olcCntry = "";
                String  tnomen_inland_overseas = "";
                {
                    _olcCntry =   InputoBj.getValue("OLC_CNTRY_CODE").trim().toString();
                    tnomen_inland_overseas =   InputoBj.getValue("TNOMEN_INLAND_OVERSEAS").trim().toString();
                }
            Init_ResultObj(InputoBj);
                if(String.valueOf(_olcCntry).trim().equalsIgnoreCase(""))
                {
                    Resultobj.setValue(ErrorKey,BLANK_CHECK);
                }
                if(Check_Result_Status())
                {
                	comnval	=	new	CommonValidator();
                	dtobj.clearMap();
                	dtobj.setValue("CNTRY_CODE",_olcCntry);
                	Resultobj=comnval.valcntrycd(dtobj);
                }
              //Changes M.S.JAYANTHI-Chn-11/11/2009 BEG
                if(Check_Result_Status())
                {
                	if((tnomen_inland_overseas.equalsIgnoreCase("I"))&&
                			(!_olcCntry.equalsIgnoreCase(get_our_cntry_code())))
                	 Resultobj.setValue(ErrorKey,"Country Code Should be Installation Country for Inland LCs");
                }
              //Changes M.S.JAYANTHI-Chn-11/11/2009 end
            }
        catch(Exception e)
            {
                Resultobj.setValue(ErrorKey,"Error in olcCntrykeypress" );
            }
        return Resultobj.copyofDTO();
        }
  
    
    
    
    
    // *********************************************************************************************************
    // *********************************************************************************************************
    /*Method Name				-			olcTermsOfPricekeypress
    * 
    * Input 	- 							Key =TERMS_OF_PRICE
    * 									
    * Output	: Error Message  		- 	Key = ErrorMsg
    */
    
    public DTObject olcTermsOfPricekeypress(DTObject InputoBj)
        {
        try
            {
                String  _olcTermsOfPrice = "";
                String _termname="";
                {
                	_olcTermsOfPrice =   InputoBj.getValue("TERMS_OF_PRICE") .trim().toString();
                }
                
                Init_ResultObj(InputoBj);
                
                if(String.valueOf(_olcTermsOfPrice).trim().equalsIgnoreCase(""))
                {
                    Resultobj.setValue(ErrorKey,BLANK_CHECK);
                }
                
                if(Check_Result_Status())
                {
                	tfmval = new TFMValidator();
                	dtobj.clearMap();
                	dtobj.setValue("TERMS_CODE",_olcTermsOfPrice);
                	Resultobj=tfmval.valterms(dtobj);
                	_termname=Resultobj.getValue("TERMS_DESCN");
                }
                if(Check_Result_Status())
                {
                	Resultobj.setValue("TERMS_DESCN",_termname); 
                	Resultobj.setValue(ErrorKey,"" );
                }
            }
        catch(Exception e)
            {
                Resultobj.setValue(ErrorKey,"Error in olcTermsOfPricekeypress" );
            }
        return Resultobj.copyofDTO();
        }
//  *********************************************************************************************************
    // *********************************************************************************************************
    /*Method Name					-	olcLastDatekeypress
    * Input 	- 						
    * 									Key =OLC_LC_DATE
    * 									kEY =LAST_DATE
    *
    *Output	: Error Message  		- Key = ErrorMsg
    */
    
    public DTObject olcLastDatekeypress(DTObject InputoBj)
        {
        try
            {
                String  _olclastDate = "";
                String  _olc_lc_date="";
                _olc_lc_date=InputoBj.getValue("OLC_LC_DATE") .trim().toString();

                {
                	_olclastDate =   InputoBj.getValue("LAST_DATE") .trim().toString();
                }
            Init_ResultObj(InputoBj);
                if(String.valueOf(_olclastDate).trim().equalsIgnoreCase(""))
                {
                    Resultobj.setValue(ErrorKey,BLANK_CHECK);
                }
                if(!_olclastDate.equalsIgnoreCase(""))
                {
                if(Check_Result_Status())
                    {
                	 CheckDate(_olclastDate);	
                	 if(Check_Result_Status())
                     {
                     	if (!(DateUtility.DateGreaterThanOrEqual(_olclastDate,_olc_lc_date)))
                     	{
                     		Resultobj.setValue(ErrorKey,"Last date of negotiation should be >= LC Date");
                     	}
                     }
                 }
             }
             if(Check_Result_Status())
             {
             	 Resultobj.setValue(ErrorKey,"" );
             }
         }
     catch(Exception e)
         {
             Resultobj.setValue(ErrorKey,"Error in olcLastDatekeypress" );
         }
     return Resultobj.copyofDTO();
     }    
   
    // *********************************************************************************************************
    // *********************************************************************************************************
    /*Method Name     - 						irttRemitCurrkeypress
    * Input 	- 							    Key =OLC_LC_CURR
    * 											
    * Output	: Error Message  		- 		Key = ErrorMsg
    * 											Key	= REM_DEC_LEN
    * 											
    * 											key=REM_CURR_NAME
    * 
    */
    
    public DTObject olcLcCurrkeypress(DTObject InputoBj)
        {
        try
            {
                String  _olcLcCurr = "";
                String _declength="";
                String _currencyName="";
                {
                	_olcLcCurr =   InputoBj.getValue("OLC_LC_CURR") .trim().toString();
                }
                Init_ResultObj(InputoBj);
                if(String.valueOf(_olcLcCurr).trim().equalsIgnoreCase(""))
                {
                    Resultobj.setValue(ErrorKey,BLANK_CHECK);
                }
                
                if(Check_Result_Status())
                {
                	comnval	=	new	CommonValidator();
                	dtobj.clearMap();
                	dtobj.setValue("CURR_CODE",_olcLcCurr);
                	Resultobj=comnval.valcurrcd(dtobj);
                	_currencyName=Resultobj.getValue("CURR_NAME");
                	
                	if(Check_Result_Status())
                	{ 
                		
                		
                    	_declength =String.valueOf( cbsglobal.getcurrdeclength(_olcLcCurr));
                     }
                	
                     Resultobj.setValue("REM_CURR_NAME",_currencyName);
                     Resultobj.setValue("REM_DEC_LEN",_declength);
                }	
                
            }
        catch(Exception e)
            {
                Resultobj.setValue(ErrorKey,"Error in olcLcCurrkeypress" );
            }
        
        return Resultobj.copyofDTO();
        }
    // *********************************************************************************************************
    // *********************************************************************************************************
    /*Method Name			-				olcTenorAmtkeypress
    * 
    * Input 	- 							Key =LC_AMOUNT
    * 										Key =DRAW_DOWNS
    * 										Key =TOTAL_TEN_AMT
    *										Key =TENOR_AMT
    *										Key =NO_OF_ROWS
    *										
    * Output	: Error Message  		- 	Key = ErrorMsg
    */
    
    public DTObject olcTenorAmtkeypress(DTObject InputoBj)
        {
        try
            {
                double  _olcTenorAmt = 0;
                double  _olcTotTenorAmt = 0;
                double  _olcLcAmt = 0;
                int  _drawdown= 0;
                int  _no_of_rows= 0;
                
                if (InputoBj.getValue("TENOR_AMT").trim().equalsIgnoreCase(""))
                	{
                    	_olcTenorAmt = 0;
                	}
                else
                	{
                	_olcTenorAmt = Double.parseDouble(InputoBj.getValue("TENOR_AMT"));
                	_olcTotTenorAmt = Double.parseDouble(InputoBj.getValue("TOTAL_TEN_AMT")); 
                	_olcLcAmt = Double.parseDouble(InputoBj.getValue("LC_AMOUNT"));
                	_drawdown =  Integer.parseInt(InputoBj.getValue("DRAW_DOWNS"));
                	_no_of_rows =  Integer.parseInt(InputoBj.getValue("NO_OF_ROWS"));
                	}
            Init_ResultObj(InputoBj);
                
                if(!String.valueOf(_olcTenorAmt).trim().equalsIgnoreCase(""))
                	{
                    if(_olcTenorAmt==0)
                        if ((InputoBj.containsKey("TENOR_AMT") == true) && (InputoBj.getValue("TENOR_AMT").equalsIgnoreCase("")))
                            Resultobj.setValue(ErrorKey,BLANK_CHECK);
                        else
                        Resultobj.setValue(ErrorKey,ZERO_CHECK);
                	}
                
                if(Check_Result_Status())
                {
                	if(_olcTenorAmt > _olcLcAmt)
                	{
                		Resultobj.setValue(ErrorKey,"Tenor Amount Does Not Tally");
                	}
                }
                if(Check_Result_Status())
                {
                	
                	if( _olcTenorAmt != _olcLcAmt)
                		{
                		 if(_drawdown==1)	
                		 	 {
                			 Resultobj.setValue(ErrorKey,"Tenor Amount Does Not Tally");
                		 	 }
                		}
                }	
                if(Check_Result_Status())
                {	
                	if( _olcTotTenorAmt != _olcLcAmt)
            		{
            		 if(_drawdown==_no_of_rows)	
            		 	{
                		Resultobj.setValue(ErrorKey,"Tenor Amount Does Not Tally");
            		 	}
            		}
                }	
                if(Check_Result_Status())
                {	
                	Resultobj.setValue(ErrorKey,"" );
                
                }	
               
            }       
        catch(Exception e)
            {
                Resultobj.setValue(ErrorKey,"Error in olcTenorAmtkeypress" );
            }
        return Resultobj.copyofDTO();
        }
    
    
  
//  *********************************************************************************************************
// *********************************************************************************************************
    /*Method Name			-		eolcBenefCodekeypress
    * Input 	- 						Key =EOLC_BENEF_CODE
    * Output	: Error Message  		- 		Key = ErrorMsg
    *										    Key	= CLIENTS_NAME
    * 											Key = CLIENTS_ADDR1
    * 												Key = CLIENTS_ADDR2
    * 												Key = CLIENTS_ADDR3
    * 												Key = CLIENTS_ADDR4
    * 												Key = CLIENTS_ADDR5
    */
    
    public DTObject eolcBenefCodekeypress(DTObject InputoBj)
        {
        try
            {
                String  _eolcbenecode ="";
                String _cpartyname="";
                String _cpartycntrycode="";
                String _cpartycntryname="";
                String _cpartyaddress1=""; 
                String _cpartyaddress2=""; 
                String _cpartyaddress3=""; 
                String _cpartyaddress4=""; 
                String _cpartyaddress5=""; 
                
                //ADDED ON 02/08/2018 START
                
                String pgm_id = "";
      			String brn_Code="";
      			String nomen="";
      			String year="";
      			String serial="";
      			String paysl="";
      			String _swiftDisplay="";
      			
      				pgm_id = InputoBj.getValue("PGM_ID").trim().toString();
      				brn_Code=InputoBj.getValue("BRN_CODE").trim().toString();
      				nomen=InputoBj.getValue("NOMEN").trim().toString();
      				year=InputoBj.getValue("YEAR").trim().toString();
      				serial=InputoBj.getValue("SERIAL").trim().toString();
      				paysl=InputoBj.getValue("PAYMENT_SERIAL").trim().toString();
      			
      		//ADDED ON 02/08/2018 END
      			
                {
                	_eolcbenecode =InputoBj.getValue("EOLC_BENEF_CODE") .trim().toString();
                }
            Init_ResultObj(InputoBj);
            
          //ADDED ON 02/08/2018 START
            
            if(Check_Result_Status())
            {
            	_QueryStr ="SELECT PKG_CSB_SWIFT.SWIFT_DISPLAY(?,?,?,?,?,?) DISPLAY_STATUS FROM DUAL";
            	openConnection();
                Set_preparedStatement(_QueryStr);
                _pstmt.setString(1,pgm_id);
                _pstmt.setString(2,nomen);
                _pstmt.setString(3,brn_Code);                 
                _pstmt.setString(4,year);
                _pstmt.setString(5,serial);
                _pstmt.setString(6,paysl);
              
                ResultSet rs=ExecuteQuery();
                if(rs.next())
                {
               	 _swiftDisplay = rs.getString("DISPLAY_STATUS").trim();
               	 Resultobj.setValue("DISPLAY_STATUS",_swiftDisplay);
                	
     	         }
                if(_swiftDisplay.trim().equals("2") && _eolcbenecode.trim().equals(""))
                {
                	Resultobj.setValue("ErrorKey",BLANK_CHECK);
                }
            }
            
          //ADDED ON 02/08/2018 END
            
            if(Check_Result_Status() && !_eolcbenecode.trim().equals(""))  //ADDED ON 02/08/2018
            {            	
            	/*if(String.valueOf(_eolcbenecode).trim().equalsIgnoreCase(""))
                {
            		Resultobj.setValue(ErrorKey,BLANK_CHECK);
                }*///COMMENTED ON 16/10/2018
            	 if(Check_Result_Status())
                {
                	tfmval	=	new	TFMValidator();
                	dtobj.clearMap();
    	    		dtobj.setValue("CPARTY_ALPHA_CODE",String.valueOf(_eolcbenecode));
    	    		dtobj.setValue("FetchColumns","CPARTY_ADDR1,CPARTY_ADDR2,CPARTY_ADDR3,CPARTY_ADDR4,CPARTY_ADDR5,CPARTY_CNTRY_CODE");
    	    		dtobj.setValue(FetchReq,"true");
    	    		Resultobj=tfmval.valcparty(dtobj);
    	    		_cpartyname=Resultobj.getValue("CPARTY_NAME");
    	    		_cpartycntrycode=Resultobj.getValue("CPARTY_CNTRY_CODE");
    	    		_cpartyaddress1=Resultobj.getValue("CPARTY_ADDR1");
    	    		_cpartyaddress2=Resultobj.getValue("CPARTY_ADDR2");
    	    		_cpartyaddress3=Resultobj.getValue("CPARTY_ADDR3");
    	    		_cpartyaddress4=Resultobj.getValue("CPARTY_ADDR4");
    	    		_cpartyaddress5=Resultobj.getValue("CPARTY_ADDR5");
    	    		
                }
                if(Check_Result_Status() && !_swiftDisplay.trim().equals("2") && !_eolcbenecode.trim().equals(""))  //ADDED ON 02/08/2018
                {
                	comnval	=	new	CommonValidator();
                	dtobj.clearMap();
                	dtobj.setValue("CNTRY_CODE",_cpartycntrycode);
                	Resultobj=comnval.valcntrycd(dtobj);
                	_cpartycntryname=Resultobj.getValue("CNTRY_NAME");
                }
            }
            if(Check_Result_Status())
            {
            	Resultobj.setValue("EOLC_BENE_NAME",_cpartyname);
            	Resultobj.setValue("EOLC_CNTRY_CODE",_cpartycntrycode);
            	Resultobj.setValue("EOLC_CNTRY_NAME",_cpartycntryname);
            	Resultobj.setValue("EOLC_BENE_ADD1",_cpartyaddress1);
            	Resultobj.setValue("EOLC_BENE_ADD2",_cpartyaddress2);
            	Resultobj.setValue("EOLC_BENE_ADD3",_cpartyaddress3);
            	Resultobj.setValue("EOLC_BENE_ADD4",_cpartyaddress4);
            	Resultobj.setValue("EOLC_BENE_ADD5",_cpartyaddress5);
            	Resultobj.setValue(ErrorKey,"" );
            }
	            
            }
        catch(Exception e)
            {
                Resultobj.setValue(ErrorKey,"Error in eolcBenefCodekeypress" );
            }
        return Resultobj.copyofDTO();
        }    

//  *********************************************************************************************************
    /*
    * Input 	: LC Currency						-		Key = OLC_LC_CURR
    * 			  Base Currency						-		Key = OLC_LIMIT_CURR
    * 			  Total Amount						-		Key = TOTAL						
    * 			  Convertion rate to limit Currency - 		Key = OLC_CONV_RATE_LIM_CURR
    * 														key = OLC_LIMIT_LINE_NO
    * 														Key = OLC_CUST_NO
    * 														Key = OLC_BRANCH_CODE
    * 														Key = OLC_INTERNAL_ACC_NO					
    * 													
    * Output	: Against Amount					-		Key = AGAINST_AMT1
    * 			  Error Message  					- 		Key = ErrorMsg
    */
// *********************************************************************************************************    
    
    public DTObject olcConvRateLimCurrkeypress(DTObject InputoBj)
        {
        try
            {
        	String _totliablimcurr="";
    		String _currcode="";
    		String _currname="";
    		String _basecurrname="";
    		int _limline=0;
    		String _lmtlinedesc="";
    		String _acntnum="";
    		String _intacntnum="";
    		String _acntname="";
    		String _effbal="";
    		String _outstdamt="";
    		String _sanccurr="";
    		String _sancamt="";
    		String _lcps_cust_no="";
    		String _declength1="";
    		String penamt="";
        		
    		int olcbrncode=0;
    		long olcintaccno=0;
    		
    		long	_declength=0;
	        	String _agnstamt="";
	        	String baseCurrency=get_base_curr_code();    
	        	String _lccurr="";
	        	String _limitcurr="";
	        	String _lctotamt="";
	        	String _olctrandate="";
	        	String san=" ";
	        	
        		double  _lcpsConvRateLimCurr = 0;
                
        		if (InputoBj.getValue("OLC_CONV_RATE_LIM_CURR").trim().equalsIgnoreCase(""))
                {
                    _lcpsConvRateLimCurr = 0;
                }
                else
                {
                    _lcpsConvRateLimCurr = Double.parseDouble(  InputoBj.getValue("OLC_CONV_RATE_LIM_CURR") .trim().toString());
                }
        		_lccurr = InputoBj.getValue("OLC_LC_CURR") .trim().toString();
        		_lctotamt = InputoBj.getValue("TOTAL") .trim().toString();
        		_limitcurr=InputoBj.getValue("OLC_LIMIT_CURR") .trim().toString();
        		_limline=Integer.parseInt(InputoBj.getValue("OLC_LIMIT_LINE_NO"));
        		_lcps_cust_no=InputoBj.getValue("OLC_CUST_NO") .trim().toString();
        		olcbrncode=Integer.parseInt(InputoBj.getValue("OLC_BRANCH_CODE"));
        		olcintaccno=Long.parseLong(InputoBj.getValue("OLC_INTERNAL_ACC_NO"));
        		
        		Init_ResultObj(InputoBj);
        		
                if(String.valueOf(_lcpsConvRateLimCurr).trim().equalsIgnoreCase(""))
                {
                    Resultobj.setValue(ErrorKey,BLANK_CHECK);
                }
                
                if(Check_Result_Status())
         		{
         			CommonValidator cv = new CommonValidator();
         			DTObject dtoinput = new DTObject();
         			dtoinput.setValue("FOR_CURR",_lccurr);
         			dtoinput.setValue("AGNST_CURR",_limitcurr);
         			dtoinput.setValue("AMT_FOR_CURR",_lctotamt);
         			dtoinput.setValue("CONVER_RATE",String.valueOf(_lcpsConvRateLimCurr));
         			Resultobj = cv.calAgnstVal(dtoinput);
         			_agnstamt = Resultobj.getValue("AMT_AGNST_CURR");
         			
         			if(Check_Result_Status())
                	{
                		_declength =cbsglobal.getcurrdeclength(_limitcurr);
                	}
                	
                }
                if(Check_Result_Status())
         		{
         			if(_limline!=0)
         			{
         				LimitValidator LV1=new LimitValidator();
         				DTObject dtoinput = new DTObject();
         				dtoinput.setValue("LMTLINE_NUM",String.valueOf(_limline));
         				dtoinput.setValue("LMTLINE_CLIENT_CODE",String.valueOf(_lcps_cust_no));
         				dtoinput.setValue("FetchReq","true");
         				dtoinput.setValue("FetchColumns","LMTLINE_SANCTION_CURR,LMTLINE_SANCTION_AMT");
         				Resultobj = LV1.vallimitline(dtoinput);
         				_lmtlinedesc = Resultobj.getValue("LMTLINE_FACILITY_DESCN");
         				_sanccurr = Resultobj.getValue("LMTLINE_SANCTION_CURR");
         				_sancamt = Resultobj.getValue("LMTLINE_SANCTION_AMT");
         				
         				
         				if(Check_Result_Status())
             			{
             				CommonValidator curr = new CommonValidator();
             				dtoinput.setValue("CURR_CODE",_sanccurr);
             				Resultobj = curr.valcurrcd(dtoinput);
             				_currname = Resultobj.getValue("CURR_NAME");
             			}
         				if(Check_Result_Status())
                    	{ 
         					_declength1 =String.valueOf( cbsglobal.getcurrdeclength(_sanccurr));
                         }
         				
         				if(Check_Result_Status())
                 		{
             				LimitValidator LV2=new LimitValidator();
             				dtoinput.setValue("LMTLINE_NUM",String.valueOf(_limline));
             				dtoinput.setValue("CLIENT_CODE",String.valueOf(_lcps_cust_no));
             				Resultobj = LV2.valllacntos(dtoinput);
             				_outstdamt = Resultobj.getValue("OUT_STANDING_AMT");
                 		}
         			}
         		
         		}
                if(Check_Result_Status())
         		{
         			CommonValidator curr1 = new CommonValidator();
         			DTObject dtoinput = new DTObject();
         			dtoinput.setValue("CURR_CODE",baseCurrency);
         			Resultobj = curr1.valcurrcd(dtoinput);
         			_basecurrname = Resultobj.getValue("CURR_NAME");
         		}
                
                if(Check_Result_Status())
         		{
                _QueryStr = "select sum(LCPS_TOT_LIAB_LIM_CURR)LCPS_TOT_LIAB_LIM_CURR from LCPS where LCPS_BRN_CODE=? and LCPS_CUST_LIAB_ACC_NUM=? and LCPS_APPROVAL_REFUSAL= ? ";
                Set_preparedStatement(_QueryStr);
                _pstmt.setInt(1, olcbrncode);
                _pstmt.setLong(2, olcintaccno);
                _pstmt.setString(3,san);
                Resultobj=Get_Value_From_Main("LCPS");
                penamt=Resultobj.getValue("LCPS_TOT_LIAB_LIM_CURR");
                if(penamt==null)
                {
                	penamt="";
                }
         		}
                
                Resultobj.setValue("AMT_AGNST_CURR",_agnstamt);
                Resultobj.setValue("PEND_AMT",penamt);
                Resultobj.setValue("CURR_NAME",_currname);
                Resultobj.setValue("BASE_CURR_NAME",_basecurrname);
                Resultobj.setValue("LMTLINE_NUM",String.valueOf(_limline));
                Resultobj.setValue("LMTLINE_DESCN",_lmtlinedesc);
                Resultobj.setValue("SANC_CURR",_sanccurr);
                Resultobj.setValue("SANC_AMT",_sancamt);
                Resultobj.setValue("OUTSTD_AMT",_outstdamt);
                //Vinoth S Changes on 23-Dec-2010 Beg
                if(Check_Result_Status())
                {
                     if(baseCurrency.equalsIgnoreCase(get_base_curr_code()))
                     {
                     String _trandate =InputoBj.getValue("TRAN_DATE") .trim().toString();
                     String _type=InputoBj.getValue("TYPE").trim().toString();
                     String _ircamtloccurr="";
                     String AgainstAmt=Resultobj.getValue("AMT_AGNST_CURR");
                     if(Check_Result_Status())
                       {
                     	 CallableStatement _cstmt=null;
                          openConnection();
                     	 _cstmt = connDB.prepareCall("CALL PKG_FX_RND_PARAM.SP_FX_ROUNDOFF(TO_DATE(?,'DD-MM-YYYY'),?,?,?)");
                     	 _cstmt.setString(1,_trandate);
                     	 _cstmt.setString(2,AgainstAmt);
                          _cstmt.setString(3,_type);
                          _cstmt.registerOutParameter(4,Types.INTEGER);
                          _cstmt.execute();
                          _ircamtloccurr	=  _cstmt.getString(4);
                          closeConnection();
                          Resultobj.setValue("AMT_AGNST_CURR",_ircamtloccurr);
                          Resultobj.setValue("DEC_LEN2",String.valueOf(_declength));
                       }
                     }
                }
    		    //Vinoth S Changes on 23-Dec-2010 End
            }
         catch(Exception e)
            {
                Resultobj.setValue(ErrorKey,"Error in olcConvRateLimCurrkeypress" );
            }
        return Resultobj.copyofDTO();
        }
 
    // *********************************************************************************************************
    // *********************************************************************************************************
    /*Method Name -						olcConvRateBaseCurrkeypress
    * Input 	- 						
    * 									Key =OLC_LC_CURR                                         
    									Key =BASE_CURR  
    									Key =TOTAL  
    									Key =OLC_CONV_RATE_LIM_CURR                                     
    									
    * Output: Error Message  	    - 	Key = ErrorMsg
    */
    
    public DTObject olcConvRateBaseCurrkeypress(DTObject InputoBj)
        {
        try
            {
                String  _olcCurr="";
                String _basecurrname="";
                String baseCurrency=get_base_curr_code();
                String _lctotamt="";
                String conrate="";
                String _agnstamt="";
                long	_declength=0;
                 if (InputoBj.getValue("OLC_LC_CURR").trim().equalsIgnoreCase(""))
                 {
                	 Resultobj.setValue(ErrorKey,BLANK_CHECK);
                 }
                 if (InputoBj.getValue("BASE_CURR").trim().equalsIgnoreCase(""))
                 {
                	 Resultobj.setValue(ErrorKey,BLANK_CHECK);
                 }
                 if (InputoBj.getValue("TOTAL").trim().equalsIgnoreCase(""))
                 {
                	 Resultobj.setValue(ErrorKey,BLANK_CHECK);
                 }
                 if (InputoBj.getValue("OLC_CONV_RATE_LIM_CURR").trim().equalsIgnoreCase(""))
                 {
                	 Resultobj.setValue(ErrorKey,BLANK_CHECK);
                 }
                else
                 {
                	_olcCurr = InputoBj.getValue("OLC_LC_CURR") .trim().toString();
                	_basecurrname = InputoBj.getValue("BASE_CURR") .trim().toString();
                	_lctotamt = InputoBj.getValue("TOTAL") .trim().toString();
                	conrate = InputoBj.getValue("OLC_CONV_RATE_LIM_CURR") .trim().toString();
                 }
                     
                 Init_ResultObj(InputoBj);
                       
                 if(Check_Result_Status())
          			{
          			CommonValidator cv = new CommonValidator();
          			DTObject dtoinput = new DTObject();
          			dtoinput.setValue("FOR_CURR",_olcCurr);
          			dtoinput.setValue("AGNST_CURR",_basecurrname);
          			dtoinput.setValue("AMT_FOR_CURR",_lctotamt);
          			dtoinput.setValue("CONVER_RATE",conrate);
          			Resultobj = cv.calAgnstVal(dtoinput);
          			_agnstamt = Resultobj.getValue("AMT_AGNST_CURR");
          			
          			if(Check_Result_Status())
                 	{
                 		_declength =cbsglobal.getcurrdeclength(_basecurrname);
                 	}
                 	
                 }
                 
                 
                 
                 
                 if(Check_Result_Status())
       				{
                	 Resultobj.setValue("AGAINST_AMT",_agnstamt);
                	 Resultobj.setValue("BASE_CURR_DECI_LEN",String.valueOf(_declength));
       			    }
                 //Vinoth S Changes on 23-Dec-2010 Beg
         		/*
                 
                 if(Check_Result_Status())
                 {
                      if(baseCurrency.equalsIgnoreCase(get_base_curr_code()))
                      {
                      String _trandate =InputoBj.getValue("TRAN_DATE").trim().toString();
                      String _type=InputoBj.getValue("TYPE").trim().toString();
                      String _olcamtloccurr="";
                      String AgainstAmt=Resultobj.getValue("AMT_AGNST_CURR");
                      if(Check_Result_Status())
                        {
                      	 CallableStatement _cstmt=null;
                           openConnection();
                      	 _cstmt = connDB.prepareCall("CALL PKG_FX_RND_PARAM.SP_FX_ROUNDOFF(TO_DATE(?,'DD-MM-YYYY'),?,?,?)");
                      	 _cstmt.setString(1,_trandate);
                      	 _cstmt.setString(2,AgainstAmt);
                           _cstmt.setString(3,_type);
                           _cstmt.registerOutParameter(4,Types.INTEGER);
                           _cstmt.execute();
                           _olcamtloccurr	=  _cstmt.getString(4);
                           closeConnection();
                           Resultobj.setValue("AGAINST_AMT",_olcamtloccurr);
                           Resultobj.setValue("BASE_CURR_DECI_LEN",String.valueOf(_declength));
                        }
                      }
                 }
     		    //Vinoth S Changes on 23-Dec-2010 End
  */
            }     
        catch(Exception e)
        {
            Resultobj.setValue(ErrorKey,"Error in olcConvRateBaseCurrkeypress" );
        }
    return Resultobj.copyofDTO();
    }     
    
    
    
    // *********************************************************************************************************
    
    // *********************************************************************************************************
    /*Method Name -						olcChargeskeypress
    * Input 	- 						
    * 									Key =OLC_LC_CURR                                         
    									Key =OLC_LC_TYPE                                     
    									
    * Output: Error Message  	    - 	Key = ErrorMsg
    */
    
    public DTObject olcChargeskeypress(DTObject InputoBj)
        {
        try
            {
                 String _olcType="";
                String  _olcCurr="";
                String optype="1";
                String TRCHG_COMMN_CHGCD="";
                String TRCHG_COURIER_CHGCD="";
                String TRCHG_POSTAL_CHGCD="";
                String TRCHG_HANDLING_CHGCD="";
                String TRCHG_SWIFT_CHGCD="";
                String TRCHG_USANCE_CHGCD="";
                String TRCHG_COMMITMNT_CHGCD="";
                
                 if (InputoBj.getValue("OLC_LC_CURR").trim().equalsIgnoreCase(""))
                 {
                	 Resultobj.setValue(ErrorKey,BLANK_CHECK);
                 }
                 if (InputoBj.getValue("OLC_LC_TYPE").trim().equalsIgnoreCase(""))
                 {
                	 Resultobj.setValue(ErrorKey,BLANK_CHECK);
                 }
                else
                 {
                	_olcType = InputoBj.getValue("OLC_LC_TYPE") .trim().toString();
                	_olcCurr = InputoBj.getValue("OLC_LC_CURR") .trim().toString();
                 }
                     
                 Init_ResultObj(InputoBj);
                       
                 if(Check_Result_Status())
                        {
                        	_QueryStr = "select TRCHG_COMMN_CHGCD,TRCHG_HANDLING_CHGCD,TRCHG_COURIER_CHGCD,TRCHG_POSTAL_CHGCD,TRCHG_SWIFT_CHGCD,TRCHG_COMMITMNT_CHGCD,TRCHG_USANCE_CHGCD from TRCHGPARAM where TRCHG_NOMEN_CODE=? and TRCHG_OPT_TYPE=? and TRCHG_FACILITY_CURR=?";
        	                    Set_preparedStatement(_QueryStr);
        	                    _pstmt.setString(1,_olcType);
        	                    _pstmt.setString(2,optype);
        	                    _pstmt.setString(3,_olcCurr);
        	                    Resultobj=Get_Value_From_Main("TRCHGPARAM");
        	                    TRCHG_COMMITMNT_CHGCD = Resultobj.getValue("TRCHG_COMMITMNT_CHGCD");
        	                    TRCHG_USANCE_CHGCD = Resultobj.getValue("TRCHG_USANCE_CHGCD");
        	                    if(Check_Result_Status())
        	                    {
        	                   	 if(Resultobj.getValue(ResultKey).equalsIgnoreCase(RowNotPresent))
        	                   	 {
        	                   		//Changes P.Subramani-Chn-19-06-2008 Beg
        	                   		 _QueryStr = "select TRCHG_COMMN_CHGCD,TRCHG_HANDLING_CHGCD,TRCHG_COURIER_CHGCD,TRCHG_POSTAL_CHGCD,TRCHG_SWIFT_CHGCD,TRCHG_COMMITMNT_CHGCD,TRCHG_USANCE_CHGCD from TRCHGPARAM where TRCHG_NOMEN_CODE=? and TRCHG_OPT_TYPE=? and TRCHG_FACILITY_CURR=?";
            	                    Set_preparedStatement(_QueryStr);
            	                    _pstmt.setString(1,_olcType);
            	                    _pstmt.setString(2,optype);
            	                    _pstmt.setString(3," ");
            	                    Resultobj=Get_Value_From_Main("TRCHGPARAM");
            	                    TRCHG_COMMITMNT_CHGCD = Resultobj.getValue("TRCHG_COMMITMNT_CHGCD");
            	                    TRCHG_USANCE_CHGCD = Resultobj.getValue("TRCHG_USANCE_CHGCD");
            	                    if(Resultobj.getValue(ResultKey).equalsIgnoreCase(RowNotPresent))
            	    	          	   {
            	    	          		   Resultobj.setValue(ErrorKey,"Charges Not Exists");
            	    	          	   }
            	                    //Changes P.Subramani-Chn-20-06-2008 Beg 
            	                    else if(TRCHG_COMMITMNT_CHGCD==null)
            	                    {
            	                    	Resultobj.setValue(ErrorKey,"Commitment Charges Parameter Not Exists");
            	                    }	
            	                    else if(TRCHG_USANCE_CHGCD==null)
            	                    {
            	                    	Resultobj.setValue(ErrorKey,"Usance Charges Parameter Not Exists");
            	                    }	
            	                    //Changes P.Subramani-Chn-20-06-2008 End
            	                    
        	                   	 }
        	                   	 //Changes P.Subramani-Chn-20-06-2008 Beg          
        	                   	else if(TRCHG_COMMITMNT_CHGCD==null)
        	                    {
        	                     	  Resultobj.setValue(ErrorKey,"Commitment Charges Parameter Not Exists");
        	        	        }
        	                    else if(TRCHG_USANCE_CHGCD==null)
	    	                    {
        	                    	  Resultobj.setValue(ErrorKey,"Usance Charges Parameter Not Exists");
	    	                    }
         	                      //Changes P.Subramani-Chn-20-06-2008 End
        	                    }
                        }     
        	                    TRCHG_COMMN_CHGCD=Resultobj.getValue("TRCHG_COMMN_CHGCD");
        	                    TRCHG_COURIER_CHGCD=Resultobj.getValue("TRCHG_COURIER_CHGCD");
        	                    TRCHG_POSTAL_CHGCD=Resultobj.getValue("TRCHG_POSTAL_CHGCD");
        	                    TRCHG_HANDLING_CHGCD=Resultobj.getValue("TRCHG_HANDLING_CHGCD");
        	                    TRCHG_SWIFT_CHGCD=Resultobj.getValue("TRCHG_SWIFT_CHGCD");
        	                    TRCHG_COMMITMNT_CHGCD=Resultobj.getValue("TRCHG_COMMITMNT_CHGCD");
        	                    TRCHG_USANCE_CHGCD=Resultobj.getValue("TRCHG_USANCE_CHGCD");
        	          
        	          
                        
                 if(Check_Result_Status())
                 {
                	 Resultobj.setValue(ErrorKey,"");
                	 Resultobj.setValue("TRCHG_COMMN_CHGCD",TRCHG_COMMN_CHGCD);
	                 Resultobj.setValue("TRCHG_COURIER_CHGCD",TRCHG_COURIER_CHGCD);
	                 Resultobj.setValue("TRCHG_POSTAL_CHGCD",TRCHG_POSTAL_CHGCD);
	                 Resultobj.setValue("TRCHG_HANDLING_CHGCD",TRCHG_HANDLING_CHGCD);
	                 Resultobj.setValue("TRCHG_SWIFT_CHGCD",TRCHG_SWIFT_CHGCD);
	                 Resultobj.setValue("TRCHG_COMMITMNT_CHGCD",TRCHG_COMMITMNT_CHGCD);
	                 Resultobj.setValue("TRCHG_USANCE_CHGCD",TRCHG_USANCE_CHGCD);
	                 //Changes P.Subramani-Chn-19-06-2008 End
                 }
            }  	 
        catch(Exception e)
        {
            Resultobj.setValue(ErrorKey,"Error in olcChargeskeypress" );
        }
    return Resultobj.copyofDTO();
    }
    
 //Changes P.Subramani-10/04/2008 Beg   
// *********************************************************************************************************
/*Method Name -						olcChargeskeypress
* Input 	- 						Key =TENOR_TYPE                                         
									
* Output:   	    			 	Key = CHGCD_CHG_CURR_OPTION
*/
    
    public DTObject olctenortypechgcodecurroptionkeypress(DTObject InputoBj)
        {
        try
            {
                String tenortype="";
                String Chgcodecurropt="";
                 if (InputoBj.getValue("TENOR_TYPE").trim().equalsIgnoreCase(""))
                 {
                	 Resultobj.setValue(ErrorKey,BLANK_CHECK);
                 }
                 else
                 {
                	tenortype = InputoBj.getValue("TENOR_TYPE") .trim().toString();
                	
                 }
                 Init_ResultObj(InputoBj);
                       
                if(Check_Result_Status())
                {
                	_QueryStr = "select CHGCD_CHG_CURR_OPTION from CHGCD where CHGCD_CHARGE_CODE=?";
                    Set_preparedStatement(_QueryStr);
                    _pstmt.setString(1,tenortype);
                    Resultobj=Get_Value_From_Main("CHGCD");
                    Chgcodecurropt=Resultobj.getValue("CHGCD_CHG_CURR_OPTION");
	            }     
        	Resultobj.setValue("CHGCD_CHG_CURR_OPTION",Chgcodecurropt);
	        }  	 
        catch(Exception e)
        {
            Resultobj.setValue(ErrorKey,"Error in olcChargeskeypress" );
        }
    return Resultobj.copyofDTO();
    }
    
    
//*****************************************************************************************************************    
    public DTObject olcusancekeypress(DTObject InputoBj)
    {
    try
    {
    		int usancechgs=0;
    	    int usancechgstakendays=0;
    	    
    	    Connection _conn=null;
			CallableStatement _cstmt = null;
			_conn=openConnection();
			_cstmt = _conn.prepareCall("CALL USANCE_CHARGES(?,?,?,?,?,?,?,?)");
			_cstmt.setString(1,InputoBj.getValue("OLC_PROD_CODE"));
			_cstmt.setString(2,InputoBj.getValue("OLC_LC_TYPE"));
			_cstmt.setInt(3,Integer.parseInt(InputoBj.getValue("OLC_CUST_NUM")));
			_cstmt.setDouble(4,Double.parseDouble(InputoBj.getValue("OLC_LC_AMT")));
			_cstmt.setInt(5,Integer.parseInt(InputoBj.getValue("OLC_LC_DAYS")));
			_cstmt.setString(6,InputoBj.getValue("OLC_TENOR_TYPE"));
			_cstmt.registerOutParameter(7,Types.INTEGER);
			_cstmt.registerOutParameter(8,Types.INTEGER);
			_cstmt.execute();
			
			usancechgs = _cstmt.getInt(7);
			usancechgstakendays = _cstmt.getInt(8);
			
			if(Check_Result_Status())
			{
				Resultobj.setValue("USANCE_CHGS",String.valueOf(usancechgs));
				Resultobj.setValue("USANCE_CHGS_TAKEN_DAYS",String.valueOf(usancechgstakendays)); 
			}
		}
		catch(Exception e)
    	{
    		Resultobj.setValue(ErrorKey,"Error in olcusancekeypress" ); 
    	}
    	return Resultobj.copyofDTO();
    }
    
//*****************************************************************************************************************    
    public DTObject olccommkeypress(DTObject InputoBj)
    {
    try
    {
    		int commchgs=0;
    		int commchgstakendays=0;
    		
    		Connection _conn=null;
			CallableStatement _cstmt = null;
			_conn=openConnection();
			_cstmt = _conn.prepareCall("CALL COMMITMENT_CHARGES(?,?,?,?,?,?,?)");
			_cstmt.setString(1,InputoBj.getValue("OLC_PROD_CODE"));
			_cstmt.setString(2,InputoBj.getValue("OLC_LC_TYPE"));
			_cstmt.setInt(3,Integer.parseInt(InputoBj.getValue("OLC_CUST_NUM")));
			_cstmt.setDouble(4,Double.parseDouble(InputoBj.getValue("OLC_LC_AMT")));
			_cstmt.setInt(5,Integer.parseInt(InputoBj.getValue("OLC_LC_DAYS")));
			_cstmt.registerOutParameter(6,Types.INTEGER);
			_cstmt.registerOutParameter(7,Types.INTEGER);
			_cstmt.execute();
			
			commchgs = _cstmt.getInt(7);
			commchgstakendays = _cstmt.getInt(6);
			
			if(Check_Result_Status())
			{
				Resultobj.setValue("COMM_CHGS",String.valueOf(commchgs));
				Resultobj.setValue("COMM_CHGS_TAKEN_DAYS",String.valueOf(commchgstakendays)); 
			}
		}
    	catch(Exception e)
    	{
    		Resultobj.setValue(ErrorKey,"Error in olccommkeypress" );
    	}
    	return Resultobj.copyofDTO();
    }
    
    //Changes P.Subramani-10/04/2008 End
//********************************************************************************************************************    

//  Changes P.Subramani-28/04/2008 Beg   
//  *********************************************************************************************************
 /*Method Name -						olccustnumkeypress
 * Input 	- 						Key =OLC_PROD_CODE                                         
 									Key =OLC_LC_TYPE
 									Key =OLC_CUST_NUM
 									
 * Output:   	    			 	Key = CUSTOMER_NUMBER
 */
     
     public DTObject olccustnumkeypress(DTObject InputoBj)
         {
         try
             {
                 String prodcode="";
                 String lctype="";
                 String custnum="";
                 prodcode = InputoBj.getValue("OLC_PROD_CODE") .trim().toString();
                 lctype = InputoBj.getValue("OLC_LC_TYPE") .trim().toString();
                 custnum = InputoBj.getValue("OLC_CUST_NUM") .trim().toString();
                 Init_ResultObj(InputoBj);
                 if(Check_Result_Status())
                 {
                 	_QueryStr = "SELECT LCC_CUSTOMERWISE_CHGS_REQD,LCC_CUST_NUM FROM LCCOMM WHERE LCC_PROD_CODE=? AND LCC_LC_TYPE=? AND LCC_CUST_NUM=?";
                     Set_preparedStatement(_QueryStr);
                     _pstmt.setInt(1,Integer.parseInt(prodcode));
                     _pstmt.setString(2,lctype);
                     _pstmt.setInt(3,Integer.parseInt(custnum));
                     Resultobj=Get_Value_From_Main("LCCOMM");
                     
                     if(Check_Result_Status())
                     {
                    	 if(Resultobj.getValue(ResultKey).equalsIgnoreCase(RowPresent))
                    	 {
                    		 if(Resultobj.getValue("LCC_CUSTOMERWISE_CHGS_REQD").equalsIgnoreCase("0"))
                    		 {
                    			 custnum="0";
                    		 }
                    		 else
                    		 {
                    			 custnum=Resultobj.getValue("LCC_CUST_NUM");
                    		 }
                    	 }
                    	 else if(Resultobj.getValue(ResultKey).equalsIgnoreCase(RowNotPresent))
	    	          	 {
                    		 custnum="0";
	    	          	 }
                     }
                }     
         	Resultobj.setValue("CUSTOMER_NUMBER",String.valueOf(custnum));
 	        }  	 
         catch(Exception e)
         {
             Resultobj.setValue(ErrorKey,"Error in olccustnumkeypress" );
         }
     return Resultobj.copyofDTO();
     }
     
//   Changes P.Subramani-28/04/2008 End    
// *****************************************************************************************************************
//S.Suresh Babu Add 30-06-2009
//*****************************************************************************************************************
	    /*
		 * Input 							Key = ACTUAL_CHG_AMT
		 *									Key = BASE_CURR_CODE
		 * 									Key = INTERNAL_ACC_NUM
		 * 									Key = CHARGE_CODE								
		 * 
		 * Output	: Error Message  		Key = ErrorMsg
		 * 								
	    */
		    
     
	    public DTObject servicetaxkeypress(DTObject InputoBj)   
	        {
	        try
	            {
	        	double  _chargeAmount = 0;
	        	if (InputoBj.getValue("ACTUAL_CHG_AMT").trim().equalsIgnoreCase(""))
	        		_chargeAmount = 0;
             else
             	_chargeAmount = Double.parseDouble(InputoBj.getValue("ACTUAL_CHG_AMT").trim().toString());
	        	 String _baseCurrCode = InputoBj.getValue("BASE_CURR_CODE").trim().toString();
	             String _internalAccNum = InputoBj.getValue("INTERNAL_ACC_NUM").trim().toString();
	             String _lockerChargeCode = InputoBj.getValue("CHARGE_CODE").trim().toString();
	           //SUGANYA BEGIN 19-JUN-2017
	             String _brncode = InputoBj.getValue("BRN_CODE").trim().toString();
	     		
	     		//SUGANYA END 19-JUN-2017
	             
	             //String _lockerChargeCode = "0.0";
	             Init_ResultObj(InputoBj);
	        	
	        	if(Check_Result_Status())
	        	{
	        		CommonValidator common = new CommonValidator();
	        		DTObject dto = new DTObject();
	        		dto.clearMap();
	        		dto.setValue("BRANCH_CODE",_brncode);//SUGANYA ADDED ON 19-JUN-2017
	        		dto.setValue("INTERNAL_ACC_NUM",_internalAccNum);
	        		dto.setValue("CHGCD_CODE",_lockerChargeCode);
	        		dto.setValue("CHGS_RECOV_CURR",_baseCurrCode);
	        		dto.setValue("CHGS_AMT_RECOV_CURR",String.valueOf(_chargeAmount));
	        		Resultobj = common.valrecalcstax(dto);
	        	}
	        	}
	        catch(Exception e)
	            {
	                Resultobj.setValue(ErrorKey,"Error in servicetaxkeypress" );
	            }
	        return Resultobj.copyofDTO();
	        }
//***********************************************************************************************************************
//S.Suresh Babu Add 24-09-2009 Beg
		    //*********************************************************************************************************
		    /*Method Name -						fetchconvrate
		    * Input 	- 						
		    * 									Key =LC_CURR                                         
		    *									Key =BASE_CURR  
		    *									Key =TOT_EQV_AMT  
		    *									Key =AMT_CONV                                     
		    *									
		    * Output: Error Message  	    - 	Key = ErrorMsg
		    */
//*********************************************************************************************************		    
		    public DTObject fetchconvrate(DTObject InputoBj)
		        {
		        try
		            {
		                String  lc_curr="";
		                String base_curr="";
		                String tot_eqv_amt="";
		                String amt_conv="";
		                long	_declength1=0;
		                
		                 if (InputoBj.getValue("LC_CURR").trim().equalsIgnoreCase(""))
		                 {
		                	 Resultobj.setValue(ErrorKey,BLANK_CHECK);
		                 }
		                 if (InputoBj.getValue("BASE_CURR").trim().equalsIgnoreCase(""))
		                 {
		                	 Resultobj.setValue(ErrorKey,BLANK_CHECK);
		                 }
		                 if (InputoBj.getValue("TOT_EQV_AMT").trim().equalsIgnoreCase(""))
		                 {
		                	 Resultobj.setValue(ErrorKey,BLANK_CHECK);
		                 }
		                 if (InputoBj.getValue("AMT_CONV").trim().equalsIgnoreCase(""))
		                 {
		                	 Resultobj.setValue(ErrorKey,BLANK_CHECK);
		                 }
		                 else
		                 {
		                	lc_curr = InputoBj.getValue("LC_CURR") .trim().toString();
		                	base_curr = InputoBj.getValue("BASE_CURR") .trim().toString();
		                	tot_eqv_amt = InputoBj.getValue("TOT_EQV_AMT") .trim().toString();
		                	amt_conv = InputoBj.getValue("AMT_CONV") .trim().toString();
		                 }
		                 Init_ResultObj(InputoBj);
		                 if(Check_Result_Status())
		          		 {
		          			CommonValidator cv = new CommonValidator();
		          			DTObject dtoinput = new DTObject();
		          			dtoinput.setValue("FOR_CURR",lc_curr);
		          			dtoinput.setValue("AGNST_CURR",base_curr);
		          			dtoinput.setValue("AMT_AGNST_CURR",tot_eqv_amt);
		          			dtoinput.setValue("AMT_FOR_CURR",amt_conv);
		          			Resultobj = cv.calConvRate(dtoinput);
		          		}
		                 
		                 if(Check_Result_Status())
		                 	{
		                 		/*_declength1 =cbsglobal.getcurrdeclength(base_curr);
		                 		 Resultobj.setValue("BASE_CURR_DECI_LEN1",String.valueOf(_declength1));*/
		                	 String _trandate =InputoBj.getValue("TRAN_DATE").trim().toString();
		                     String _type=InputoBj.getValue("TYPE").trim().toString();
		                     String _roundoffamt ="";
		                	 if (Check_Result_Status()) {
		         				CallableStatement _cstmt = null;
		         				openConnection();
		         				_cstmt = connDB.prepareCall("CALL PKG_FX_RND_PARAM.SP_FX_ROUNDOFF(TO_DATE(?,'DD-MM-YYYY'),?,?,?)");
		         				_cstmt.setString(1, _trandate);
		         				_cstmt.setString(2, tot_eqv_amt);
		         				_cstmt.setString(3, _type);
		         				_cstmt.registerOutParameter(4, Types.INTEGER);
		         				_cstmt.execute();
		         				_roundoffamt = _cstmt.getString(4);
		         				closeConnection();
		         				Resultobj.setValue("ROUND_OFF_AMOUNT1", _roundoffamt);
		         			}
		                 	}
		            }     
		        catch(Exception e)
		        {
		            Resultobj.setValue(ErrorKey,"Error in fetchconvrate" );
		        }
		    return Resultobj.copyofDTO();
		    }     
		    
		    
		  //S.Suresh Babu Add 24-09-2009 End		    
		    // *********************************************************************************************************
		    //Pradeep- Add -02-04-2009 Begin	
		    // *********************************************************************************************************
		    /*Method Name					-		qolcCntrykeypress 
		     * 
		    * Input 	- 							Key =OLC_CNTRY_CODE
		    * Output	: Error Message  		- 		
		    * 											Key = ErrorMsg
		    * 											Key	= CNTRY_NAME
		    */
		    
		    public DTObject qolcCntrykeypress(DTObject InputoBj)
		        {
		        try
		            {
		                String  _olcCntry = "";
		                {
		                    _olcCntry =   InputoBj.getValue("OLC_CNTRY_CODE").trim().toString();
		                }
		            Init_ResultObj(InputoBj);
		                
		                if(Check_Result_Status())
		                {
		                	comnval	=	new	CommonValidator();
		                	dtobj.clearMap();
		                	dtobj.setValue("CNTRY_CODE",_olcCntry);
		                	Resultobj=comnval.valcntrycd(dtobj);
		                }
		            
		            }
		        catch(Exception e)
		            {
		                Resultobj.setValue(ErrorKey,"Error in qolcCntrykeypress" );
		            }
		        return Resultobj.copyofDTO();
		        }
		  
		    
		    
		    
		    
		    // *********************************************************************************************************
		    
		    //CHN-PRASHANTH-05-08-2017-TRSYCOMP_CHANGES-ENDS
		    
		    public DTObject getConvRate(DTObject InputoBj)
	         {
		    	String rateType =   InputoBj.getValue("RATE_TYPE") .trim().toString();
		    	String  _crconvenCurrCode1 = InputoBj.getValue("CRCONVEN_CURR_CODE1").trim().toString();
		  	    String  _crconvenCurrCode2 = InputoBj.getValue("CRCONVEN_CURR_CODE2").trim().toString();
	             String _rateTypeFlag=InputoBj.getValue("RATE_FLAG") .trim().toString();
	              double w_conv_rate =0;
	         try
	             {
	        	 _QueryStr = "SELECT CRATES_PUR_RATE,CRATES_SEL_RATE,CRATES_MID_RATE FROM CRATES WHERE CRATES_TYPE_CODE=? AND CRATES_FOR_CURR=? AND CRATES_AGNST_CURR=? ";
	              Set_preparedStatement(_QueryStr);
	              _pstmt.setString(1, rateType);
	              _pstmt.setString(2, _crconvenCurrCode1);
	              _pstmt.setString(3, _crconvenCurrCode2);
	              Get_Value_From_Main("CRATES");
		             if(Check_Result_Status() == true)
	                  {
		 		             if (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowNotPresent))
		                      {
		                    	 Resultobj.setValue(ErrorKey,"Conversion Rate details not specified");
		                      }
		 		             else
		 		             {
		 		            	 if(_rateTypeFlag.trim().toString().equalsIgnoreCase("P"))
		 		            	 {
		 		            		w_conv_rate=java.lang.Double.parseDouble(Resultobj.getValue("CRATES_PUR_RATE"));
		 		            	 }
		 		            	 if(_rateTypeFlag.trim().toString().equalsIgnoreCase("S"))
		 		            	 {
		 		            		w_conv_rate=java.lang.Double.parseDouble(Resultobj.getValue("CRATES_SEL_RATE"));
		 		            	 }
		 		            	 if(_rateTypeFlag.trim().toString().equalsIgnoreCase("M"))
		 		            	 {
		 		            		w_conv_rate=java.lang.Double.parseDouble(Resultobj.getValue("CRATES_MID_RATE"));
		 		            	 }
		 		             }
	                  }
		             if(Check_Result_Status() == true)
                     {
		            	 Resultobj.setValue("CONV_RATES",String.valueOf(w_conv_rate));
                     }
	 	        }  	 
	         catch(Exception e)
	         {
	             Resultobj.setValue(ErrorKey,"Error in calculation of Conv Rate" );
	         }
	     return Resultobj.copyofDTO();
	     }
		    //CHN-PRASHANTH-05-08-2017-TRSYCOMP_CHANGES-ENDS

//******************************************************************************************
		    //changes in eolc on 27-may-2018 start
		    public DTObject Olc_Doc_CreditKeypress(DTObject InputoBj)
	        {
		    	try 
				{		
					Resultobj.clearMap();
					Resultobj=swval.Form_of_Documentary_Credit(InputoBj);
				} 
				catch (Exception e) {
					Resultobj.setValue(ErrorKey, "Error in Olc_Doc_CreditKeypress");
				}
				return Resultobj.copyofDTO();
	    }     
//******************************************************************************************	
		    
		    public DTObject Olc_Reference_To_PreAdvice_Keypress(DTObject InputoBj)
	        {
		    	try 
				{		
					Resultobj.clearMap();
					Resultobj=swval.Reference_To_PreAdvice(InputoBj);
				} 
				catch (Exception e) {
					Resultobj.setValue(ErrorKey, "Error in Olc_Reference_To_PreAdvice_Keypress");
				}
				return Resultobj.copyofDTO();
	    }     
//******************************************************************************************	
		    public DTObject Olc_Applicable_RuleKeypress(DTObject InputoBj)
	        {
		    	try 
				{		
					Resultobj.clearMap();
					Resultobj=swval.Applicable_Rule(InputoBj);
				} 
				catch (Exception e) {
					Resultobj.setValue(ErrorKey, "Error in Olc_Applicable_RuleKeypress");
				}
				return Resultobj.copyofDTO();
	    }     
//****************************************************************************************** 
		    public DTObject Olc_Applicable_BankOurTypeKeypress(DTObject InputoBj)
	        {
		    	try 
				{		
					Resultobj.clearMap();
					Resultobj=swval.Applicable_BankOur(InputoBj);
				} 
				catch (Exception e) {
					Resultobj.setValue(ErrorKey, "Error in Olc_Applicable_BankTypeKeypress");
				}
				return Resultobj.copyofDTO();
	    }     
//****************************************************************************************** 
		    public DTObject Olc_AvailableWithKeypress(DTObject InputoBj)
	        {
		    	try 
				{		
					Resultobj.clearMap();
					Resultobj=swval.AvailableWith_Bank(InputoBj);
				} 
				catch (Exception e) {
					Resultobj.setValue(ErrorKey, "Error in Olc_AvailableWithKeypress");
				}
				return Resultobj.copyofDTO();
	    }     
//****************************************************************************************** 
		    
		    public DTObject Olc_ApplicantBicKeypress(DTObject InputoBj)
	        {
		    	try 
				{		
					Resultobj.clearMap();
					Resultobj=swval.ApplicantBankBic(InputoBj);
				} 
				catch (Exception e) {
					Resultobj.setValue(ErrorKey, "Error in Olc_ApplicantBicKeypress");
				}
				return Resultobj.copyofDTO();
	    }     
//****************************************************************************************** 
		    public DTObject Olc_ApplicantBankTypeKeypress(DTObject InputoBj)
	        {
		    	try 
				{		
					Resultobj.clearMap();
					Resultobj=swval.ApplicantBankType(InputoBj);
				} 
				catch (Exception e) {
					Resultobj.setValue(ErrorKey, "Error in Olc_ApplicantBankTypeKeypress");
				}
				return Resultobj.copyofDTO();
	    }     
//****************************************************************************************** 
		    public DTObject Olc_ApplicantBankNameKeypress(DTObject InputoBj)
	        {
		    	try 
				{		
					Resultobj.clearMap();
					Resultobj=swval.ApplicantBankName(InputoBj);
				} 
				catch (Exception e) {
					Resultobj.setValue(ErrorKey, "Error in Olc_ApplicantBankNameKeypress");
				}
				return Resultobj.copyofDTO();
	    }     
//****************************************************************************************** 
		    public DTObject Olc_ApplicantBankBrachCodeKeypress(DTObject InputoBj)
	        {
		    	try 
				{		
					Resultobj.clearMap();
					Resultobj=swval.ApplicantBankBranch(InputoBj);
				} 
				catch (Exception e) {
					Resultobj.setValue(ErrorKey, "Error in Olc_ApplicantBankBrachCodeKeypress");
				}
				return Resultobj.copyofDTO();
	    }     
//****************************************************************************************** 
		    public DTObject Olc_ApplicantBankAddressKeypress(DTObject InputoBj)
	        {
		    	try 
				{		
					Resultobj.clearMap();
					Resultobj=swval.ApplicantBankAddress(InputoBj);
				} 
				catch (Exception e) {
					Resultobj.setValue(ErrorKey, "Error in Olc_ApplicantBankAddressKeypress");
				}
				return Resultobj.copyofDTO();
	    }     
//****************************************************************************************** 
		    public DTObject Olc_ApplicantBankCntryCodeKeypress(DTObject InputoBj)
	        {
		    	try 
				{		
					Resultobj.clearMap();
					Resultobj=swval.ApplicantBankCountryCode(InputoBj);
				} 
				catch (Exception e) {
					Resultobj.setValue(ErrorKey, "Error in Olc_ApplicantBankCntryCodeKeypress");
				}
				return Resultobj.copyofDTO();
	    }     
//******************************************************************************************
		    public DTObject Olc_ApplicantAccountNumberKeypress(DTObject InputoBj)
	        {
		    	try 
				{		
					Resultobj.clearMap();
					Resultobj=swval.ApplicantAccountNumber(InputoBj);
				} 
				catch (Exception e) {
					Resultobj.setValue(ErrorKey, "Error in Olc_ApplicantAccountNumberKeypress");
				}
				return Resultobj.copyofDTO();
	    }     
//****************************************************************************************** 
		    public DTObject Olc_PresentationDayKeyPress(DTObject InputoBj)
	        {
		    	try 
				{		
					Resultobj.clearMap();
					Resultobj=swval.PresentationDay(InputoBj);
				} 
				catch (Exception e) {
					Resultobj.setValue(ErrorKey, "Error in Olc_PresentationDayKeyPress");
				}
				return Resultobj.copyofDTO();
	    }     
//****************************************************************************************** 
		    public DTObject Olc_Confirmation_InstKeyPress(DTObject InputoBj)
	        {
		    	try 
				{		
					Resultobj.clearMap();
					Resultobj=swval.ConfirmationInstruction(InputoBj);
				} 
				catch (Exception e) {
					Resultobj.setValue(ErrorKey, "Error in Olc_Confirmation_InstKeyPress");
				}
				return Resultobj.copyofDTO();
	        }     
//****************************************************************************************** 
		    public DTObject Olc_Reciever_BICKeyPress(DTObject InputoBj)
	        {
		    	try 
				{		
					Resultobj.clearMap();
					Resultobj=swval.RecieverBICCode(InputoBj);
				} 
				catch (Exception e) {
					Resultobj.setValue(ErrorKey, "Error in Olc_Reciever_BICKeyPress");
				}
				return Resultobj.copyofDTO();
	        }     
//****************************************************************************************** 
		    public DTObject Olc_OverallBIC(DTObject InputoBj)
	        {
		    	try 
				{		
					Resultobj.clearMap();
					Resultobj=swval.CommonBICCodeValidation(InputoBj);
				} 
				catch (Exception e) {
					Resultobj.setValue(ErrorKey, "Error in Olc_OverallBIC");
				}
				return Resultobj.copyofDTO();
	        }     
//*****************************************************************************************
//changes in eolc on 27-may-2018 end

//changes in eolc on 12-jun-2018 start
 public DTObject Special_Char_Validation(DTObject InputoBj)
	        {
	 Clob _result =null;
	 String temp1 = "";
	 String temp3 = "";
	 int  _olcSlno = 0;
     int  _olcBranCode = 0;
     int  _olcYear = 0;
     int  _olcSl = 0;
     String _olcType="";
     String  spChar="";
     int  _olc_day_serial = 0;
	String _olc_entry_date="";
	String _lcps_cust_no ="";
	String olc_column_name="";
	//String olc_sl="";
	
	try 
	
				{
		
		 _olcBranCode=Integer.parseInt(  InputoBj.getValue("OLC_BRANCH_CODE") .trim().toString());
         _olcType=InputoBj.getValue("OLC_TYPE") .trim().toString();
         _olcYear = Integer.parseInt(  InputoBj.getValue("OLC_YEAR") .trim().toString());
         _olc_day_serial = Integer.parseInt( InputoBj.getValue("OLC_DAY_SER") .trim().toString());
     	_olc_entry_date = FormatUtils.formatToDDMonYear(InputoBj.getValue("OLC_ENTRY_DATE") .trim().toString());
     	_lcps_cust_no=InputoBj.getValue("OLC_CUST_NO") .trim().toString();
     	olc_column_name=InputoBj.getValue("OLC_COLUMNNAME") .trim().toString();
     	
		
		if(!InputoBj.getValue("OLC_CLOB").trim().equalsIgnoreCase(""))
		{
			spChar = InputoBj.getValue("OLC_CLOB").trim().toString();
		}
		else
		{
			spChar = "";
		}
		
		Connection con=null;
		con=openConnection();
		
		/*_QueryStr = "select MAX(OLC_LC_SL) OLC_LC_SL FROM OLC WHERE OLC_BRN_CODE=? AND OLC_LC_TYPE='OLC' AND OLC_LC_YEAR=? ";
        Set_preparedStatement(_QueryStr);
        _pstmt.setInt(1, _olcBranCode);
        _pstmt.setInt(2, _olcYear);
        Get_Value_From_Main("OLC");
        if(Check_Result_Status() == true)
        {
        	if (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowNotPresent))
            {
          	 Resultobj.setValue(ErrorKey,"No Row");
            }
        	else
        	{
        		olc_sl=Resultobj.getValue("OLC_LC_SL");
        	}
        }*/
		
		con.setAutoCommit(false);
		_QueryStr="delete from tempolc where TEMPOLC_BRN="+ _olcBranCode+ " and TEMPOLC_TYP ='"+_olcType+"' and TEMPOLC_YEAR="+_olcYear+" and TEMPOLC_ENTRY_DATE= '"+_olc_entry_date+"' and TEMPOLC_PRES_SL="+_olc_day_serial+ "  and TEMPOLC_COLUMNNAME='"+olc_column_name+"'";
		PreparedStatement pstmt1=con.prepareStatement(_QueryStr);
		pstmt1.executeUpdate();
		pstmt1.close();
		
		_QueryStr = "insert into tempolc values("+_olcBranCode+",'"+_olcType+"',"+_olcYear+",'"+_olc_entry_date+"',"+_olc_day_serial+",'"+olc_column_name+"',"+"empty_clob()) ";
		Statement stmt=con.createStatement();
		  ResultSet rs11=stmt.executeQuery(_QueryStr);
		  String sqll="select TEMPOLC_CLOBDATA from tempolc  where TEMPOLC_BRN="+ _olcBranCode+ " and TEMPOLC_TYP ='"+_olcType+"' and TEMPOLC_YEAR="+_olcYear+" and TEMPOLC_ENTRY_DATE= '"+_olc_entry_date+"' and TEMPOLC_PRES_SL="+_olc_day_serial+"  and TEMPOLC_COLUMNNAME='"+olc_column_name+"' for update";    
		  ResultSet rss=stmt.executeQuery(sqll);
		  if(rss.next()){
			   //CLOB clob = ((OracleResultSet)rss).getCLOB(1);
			 oracle.sql.CLOB  clob= (oracle.sql.CLOB)rss.getClob("TEMPOLC_CLOBDATA");
			   clob.putString(1,spChar);
			   _QueryStr="update tempolc set TEMPOLC_CLOBDATA=? where TEMPOLC_BRN="+ _olcBranCode+ " and TEMPOLC_TYP ='"+_olcType+"' and TEMPOLC_YEAR="+_olcYear+" and TEMPOLC_ENTRY_DATE= '"+_olc_entry_date+"' and TEMPOLC_PRES_SL="+_olc_day_serial+ "  and TEMPOLC_COLUMNNAME='"+olc_column_name+"'";
			   PreparedStatement pstmt=con.prepareStatement(_QueryStr);
			   pstmt.setClob(1,clob);
			   pstmt.executeUpdate();
			   pstmt.close();
			  }  
			  con.commit();
		
		Clob aclob1;
		Reader allClob1;
		BufferedReader br1;
		
		CallableStatement _cstmt = null;
		Connection _conn = null;
		_conn = openConnection();
		String newline = System.getProperty("line.separator");
		String line=""; 
		if(Check_Result_Status())
        {
        	String qstr="SELECT PKG_CSB_SWIFT.EXSPCHARVAL(?,?,?,?,?,?,?) AS LEN_VAL FROM DUAL";
             PreparedStatement _pstmt = _conn.prepareStatement(qstr);
         	_pstmt.setInt(1,_olcBranCode);
        	_pstmt.setString(2,_olcType);
        	_pstmt.setInt(3,_olcYear);
        	_pstmt.setString(4,_olc_entry_date);
                       	_pstmt.setInt(5,_olc_day_serial);
                     	_pstmt.setString(6,_lcps_cust_no);
                     	_pstmt.setString(7,olc_column_name);
                   	  ResultSet rs=_pstmt.executeQuery();
                   	  if(rs.next())
                   	  {
                   		
                   		  	 aclob1=rs.getClob(1);                   		  		
                   		  	 allClob1 = aclob1.getCharacterStream();
            		  		 br1=new BufferedReader(allClob1);
            		  		long ii =0;
            		  		 while( (line = br1.readLine()) != null) { 
            		  			
            		  			 if(ii  == 0)
            		  			 {
            		  				 temp3 = line;
            		  			 }
            		  			 else
            		  			 {
            		  				 temp3 = temp3 + newline + line;
            		  			 }
            		  			 ii++;
                   		
            		  		 }
                   		}
                   	 
                   	System.out.println("test "+ temp3);
                   		  	 
                   		  	 aclob1 = null;
                   	    	
                   	    	 br1 = null;
                   	    	
                   	    	 allClob1 = null;
                   	    	 
                   	    Resultobj.setValue("TEMP", temp3);
                   	 }
                   } 
				catch (Exception e) {
					Resultobj.setValue(ErrorKey, "Error in Special_Char_Validation");
				}
				return Resultobj.copyofDTO();
	        }   
/*//******************************************************************************************	
 public DTObject LngthOfClob(String ipdata)
 {
 	try 
		{		
			Resultobj.clearMap();
			Resultobj=swval.LngthOfClob(ipdata);
		} 
		catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in LngthOfClob");
		}
		return Resultobj.copyofDTO();
 }     
//******************************************************************************************
*/
//changes in eolc on 12-jun-2018 end
 
 //*****************************************************************************************
 
 public static String getGroupedFormat(String amt,long deciLength)
	{
		 String pattern = "0.";
 	 for(int i=1;i<=deciLength;i++)
 	 {
 		pattern += "0";
 	 }
	     pattern = pattern.trim();
		 DecimalFormat df2 = new DecimalFormat(pattern);
		 df2.setGroupingSize(3);
		 df2.setGroupingUsed(true);
		 String abc = df2.format(Double.parseDouble(FormatUtils.removeFormat(amt)));
		 return abc;
	}	
 
 public DTObject olclimitvalue(DTObject InputoBj)
 {
 try
     {
         int brncode=0;
         int day_sl=0;
         String entry_date="";
         double outsnd_amt=0.0;
         double pend_amt=0.0;
         int dec_length = 2;
         String outsnd_amt_tot="";
         String pend_amt_tot="";
         String errmsg="";
         
        if (!InputoBj.getValue("OLC_BRN_CODE").trim().equals(""))
  		{
        	 brncode = Integer.parseInt(InputoBj.getValue("OLC_BRN_CODE") .trim().toString());
  		}
  		else
  		{
  			brncode=0;
  		}
        if (!InputoBj.getValue("OLC_DAY_SERIAL").trim().equals(""))
  		{
        	day_sl = Integer.parseInt(InputoBj.getValue("OLC_DAY_SERIAL") .trim().toString());
  		}
  		else
  		{
  			day_sl=0;
  		}
        if (!InputoBj.getValue("OLC_ENTRY_DATE").trim().equals(""))
  		{
        	entry_date = FormatUtils.formatToDDMonYear(InputoBj.getValue("OLC_ENTRY_DATE") .trim().toString());
  		}
  		else
  		{
  			entry_date="";
  		}
        if (!InputoBj.getValue("OLC_OUTSANDING_AMT").trim().equals(""))
  		{
        	outsnd_amt = Double.parseDouble(FormatUtils.removeFormat(InputoBj.getValue("OLC_OUTSANDING_AMT") .trim().toString()));
        	outsnd_amt_tot = getGroupedFormat(String.valueOf(outsnd_amt),dec_length);
        	outsnd_amt_tot=removeFormat(outsnd_amt_tot);
  		}
  		else
  		{
  			outsnd_amt=0.0;
  			outsnd_amt_tot="0.0";
  		}
        if (!InputoBj.getValue("OLC_LC_PENDING_AMT").trim().equals(""))
  		{
        	pend_amt = Double.parseDouble(FormatUtils.removeFormat(InputoBj.getValue("OLC_LC_PENDING_AMT") .trim().toString()));
        	pend_amt_tot = getGroupedFormat(String.valueOf(pend_amt),dec_length);
        	pend_amt_tot=removeFormat(pend_amt_tot);
  		}
  		else
  		{
  			pend_amt=0;
  		}
        
         Init_ResultObj(InputoBj);
         if(Check_Result_Status())
         {
        	 Connection _conn = null;
				CallableStatement _cstmt = null;
				_conn = openConnection();
				_cstmt = _conn.prepareCall("CALL PKG_CSB_LIMITOLC.UNUSED_LIMIT(?,?,?,?,?,?,?,?,?)");
				_cstmt.setInt(1,day_sl);
				_cstmt.setString(2,entry_date);
				_cstmt.setInt(3,brncode);
				_cstmt.setDouble(4,Double.parseDouble(outsnd_amt_tot));
				_cstmt.setDouble(5, pend_amt);
		    	_cstmt.registerOutParameter(6,Types.NUMERIC);
		    	_cstmt.registerOutParameter(7,Types.NUMERIC);
		    	_cstmt.registerOutParameter(8,Types.NUMERIC);
		    	_cstmt.registerOutParameter(9,Types.VARCHAR);
		    	_cstmt.execute();
		    	errmsg	= (_cstmt.getString(9)== null) ? "" : _cstmt.getString(9);
				
				if ( errmsg != null || !errmsg.trim().equals(""))
				 {
					Resultobj.setValue(ErrorKey,errmsg);					
				 }	
				else
				{
					Resultobj.setValue(ErrorKey,"");					
				}
				Resultobj.setValue("UNUSED_LIMIT_BAL",_cstmt.getString(6));
				Resultobj.setValue("AFTER_LC",_cstmt.getString(7));
				Resultobj.setValue("EXCESS_LIMIT",_cstmt.getString(8));
        	
         }     
 	
     }  	 
 catch(Exception e)
 {
     Resultobj.setValue(ErrorKey,"Error in olclimitvalue" );
 }
return Resultobj.copyofDTO();
}
 //*****************************************************************************************
 public DTObject Split_clob_Data(DTObject InputoBj)
 {
	 try
	 {
		
		 
		 int lc_brn=0;
		 String lc_type="";
		 int lc_year=0;
		 int lc_serial=0;		 
		 Clob good1=null;
		 Clob good2=null;
		 Clob good3=null;
		 Clob doc_req1=null;
		 Clob doc_req2=null;
		 Clob doc_req3=null;
		 Clob add1=null;
		 Clob add2=null;
		 Clob add3=null;
		 
		 DTObject dto_good1=new DTObject();
		 DTObject dto_good2=new DTObject();
		 DTObject dto_good3=new DTObject();
		 DTObject dto_doc_req1=new DTObject();
		 DTObject dto_doc_req2=new DTObject();
		 DTObject dto_doc_req3=new DTObject();
		 DTObject dto_add1=new DTObject();
		 DTObject dto_add2=new DTObject();
		 DTObject dto_add3=new DTObject();
		 DTObject Resultobj1=new DTObject();
		 
		 Connection _conn = null;
		_conn = openConnection();
		
		
		 if (!InputoBj.getValue("OLC_YEAR").trim().equals(""))
	  		{
			 lc_year = Integer.parseInt(InputoBj.getValue("OLC_YEAR") .trim().toString());
	  		}
	  		else
	  		{
	  			lc_year=0;
	  		}
		 if (!InputoBj.getValue("OLC_SL").trim().equals(""))
	  		{
			 lc_serial = Integer.parseInt(InputoBj.getValue("OLC_SL") .trim().toString());
	  		}
	  		else
	  		{
	  			lc_serial=0;
	  		}
		 if (!InputoBj.getValue("OLC_BRN_CODE").trim().equals(""))
	  		{
			 lc_brn = Integer.parseInt(InputoBj.getValue("OLC_BRN_CODE") .trim().toString());
	  		}
	  		else
	  		{
	  			lc_brn=0;
	  		}
		 if (!InputoBj.getValue("OLC_TYPE").trim().equals(""))
	  		{
			 lc_type = InputoBj.getValue("OLC_TYPE") .trim().toString();
	  		}
	  		else
	  		{
	  			lc_type="";
	  		}
		 	 
		 Resultobj.clearMap();	
		 good1=GetClobData(lc_brn,lc_type,lc_year,lc_serial,"LC_DESC_GOODS_SER1");
		 good2=GetClobData(lc_brn,lc_type,lc_year,lc_serial,"LC_DESC_GOODS_SER2");
		 good3=GetClobData(lc_brn,lc_type,lc_year,lc_serial,"LC_DESC_GOODS_SER3");
		 doc_req1=GetClobData(lc_brn,lc_type,lc_year,lc_serial,"LC_DOC_REQ1");
		 doc_req2=GetClobData(lc_brn,lc_type,lc_year,lc_serial,"LC_DOC_REQ2");
		 doc_req3=GetClobData(lc_brn,lc_type,lc_year,lc_serial,"LC_DOC_REQ3");
		 add1=GetClobData(lc_brn,lc_type,lc_year,lc_serial,"LC_ADD_CONDITION1");
		 add2=GetClobData(lc_brn,lc_type,lc_year,lc_serial,"LC_ADD_CONDITION2");
		 add3=GetClobData(lc_brn,lc_type,lc_year,lc_serial,"LC_ADD_CONDITION3");
		 
		 //Resultobj.clearMap();	
		 Resultobj1=Resultobj.copyofDTO();      
		 if(good1 != null && good1.length() > 0) 
		 {
			 dto_good1=FetchClobData(lc_brn,lc_type,lc_year,lc_serial,good1,"LC_DESC_GOODS_SER1");
			 Resultobj.setValue("LC_DESC_GOODS_SER1", dto_good1.getValue("LC_DESC_GOODS_SER1"));
		 }
			 
		 if(good2 != null && good2.length() > 0) 
		 {
			 dto_good2=FetchClobData(lc_brn,lc_type,lc_year,lc_serial,good2,"LC_DESC_GOODS_SER2");
			 Resultobj.setValue("LC_DESC_GOODS_SER2", dto_good2.getValue("LC_DESC_GOODS_SER2"));
		 }
			 
		 if(good3 != null && good3.length() > 0) 
		 {
			 dto_good3=FetchClobData(lc_brn,lc_type,lc_year,lc_serial,good3,"LC_DESC_GOODS_SER3");
			 Resultobj.setValue("LC_DESC_GOODS_SER3", dto_good3.getValue("LC_DESC_GOODS_SER3"));
		 }
			 
		 if(doc_req1 != null && doc_req1.length() > 0) 
		 {
			 dto_doc_req1=FetchClobData(lc_brn,lc_type,lc_year,lc_serial,doc_req1,"LC_DOC_REQ1");
			 Resultobj.setValue("LC_DOC_REQ1", dto_doc_req1.getValue("LC_DOC_REQ1"));
		 }
			 
		 if(doc_req2 != null && doc_req2.length() > 0) 
		 {
			 dto_doc_req2=FetchClobData(lc_brn,lc_type,lc_year,lc_serial,doc_req2,"LC_DOC_REQ2");
			 Resultobj.setValue("LC_DOC_REQ2", dto_doc_req2.getValue("LC_DOC_REQ2"));
		 }
			 
		 if(doc_req3 != null && doc_req3.length() > 0) 
		 {
			 dto_doc_req3=FetchClobData(lc_brn,lc_type,lc_year,lc_serial,doc_req3,"LC_DOC_REQ3");
			 Resultobj.setValue("LC_DOC_REQ3", dto_doc_req3.getValue("LC_DOC_REQ3"));
		 }
			 
		 if(add1 != null && add1.length() > 0) 
		 {
			 dto_add1=FetchClobData(lc_brn,lc_type,lc_year,lc_serial,add1,"LC_ADD_CONDITION1");
			 Resultobj.setValue("LC_ADD_CONDITION1", dto_add1.getValue("LC_ADD_CONDITION1"));
		 }
			 
		 if(add2 != null && add2.length() > 0) 
		 {
			 dto_add2=FetchClobData(lc_brn,lc_type,lc_year,lc_serial,add2,"LC_ADD_CONDITION2");
			 Resultobj.setValue("LC_ADD_CONDITION2", dto_add2.getValue("LC_ADD_CONDITION2"));
		 }
			 
		 if(add3 != null && add3.length() > 0) 
		 {
			 dto_add3=FetchClobData(lc_brn,lc_type,lc_year,lc_serial,add3,"LC_ADD_CONDITION3");
			 Resultobj.setValue("LC_ADD_CONDITION3", dto_add3.getValue("LC_ADD_CONDITION3"));
		 }
		 Resultobj1.setMap(Resultobj.copyofDTO().getMap());
     	 Resultobj=Resultobj1; 
		 
		 _conn.close();
	 }
	 catch(Exception e)
	 {
	     Resultobj.setValue(ErrorKey, "Error in Split_clob_Data" );
	 }
	return Resultobj.copyofDTO();
 }
//******************************************************************************************	
 
 public Clob GetClobData(int lc_brn, String lc_type,int lc_year,int lc_serial, String column_name ) throws SQLException
 {
	 Clob clob_value=null;
	 Connection _conn = null;
	 _conn = openConnection();
	 
	 try
	 {
		 if(Check_Result_Status())
		 {
			 
			 String qstr2="SELECT "+column_name+" AS CDATA FROM  LC_DETAILS WHERE LC_BRN_CODE=? AND LC_LC_TYPE=? AND LC_LC_YEAR=? AND LC_LC_SL=?";
             PreparedStatement _pstmt2 = _conn.prepareStatement(qstr2);
             _pstmt2.setInt(1,lc_brn);
             _pstmt2.setString(2,lc_type);
             _pstmt2.setInt(3,lc_year);
             _pstmt2.setInt(4,lc_serial);
            ResultSet rs2=_pstmt2.executeQuery();
            if(rs2.next())
            {
            	clob_value=rs2.getClob("CDATA");
            }
            
		 }
	 }
	 catch(Exception e)
	 {
		e.printStackTrace();
	 }
	 
	 return clob_value;
 }
 
 //********************************************************************************************
 public DTObject FetchClobData(int lc_brn, String lc_type,int lc_year,int lc_serial, Clob clob_data, String column_name ) throws SQLException
 {
	 
	 Connection _conn = null;
	 String result_data="";
	 String result_data1="";
	 _conn = openConnection();
	// Resultobj.clearMap();
	 
	 try
	 {
		 if(Check_Result_Status())
		 {
			 String qstr="SELECT dbms_lob.substr(?,4000,1) AS CLOB_DATA FROM  LC_DETAILS WHERE LC_BRN_CODE=? AND LC_LC_TYPE=? AND LC_LC_YEAR=? AND LC_LC_SL=?";
             PreparedStatement _pstmt = _conn.prepareStatement(qstr);
             _pstmt.setClob(1,clob_data);
         	_pstmt.setInt(2,lc_brn);
        	_pstmt.setString(3,lc_type);
        	_pstmt.setInt(4,lc_year);
        	_pstmt.setInt(5,lc_serial);
            ResultSet rs=_pstmt.executeQuery();
            if(rs.next())
            {
            	result_data=rs.getString("CLOB_DATA");
            }
            
            String qstr1="SELECT dbms_lob.substr(?,4000,4001) AS CLOB_DATA1 FROM  LC_DETAILS WHERE LC_BRN_CODE=? AND LC_LC_TYPE=? AND LC_LC_YEAR=? AND LC_LC_SL=?";
            PreparedStatement _pstmt1 = _conn.prepareStatement(qstr1);
            _pstmt1.setClob(1,clob_data);
         	_pstmt1.setInt(2,lc_brn);
        	_pstmt1.setString(3,lc_type);
        	_pstmt1.setInt(4,lc_year);
        	_pstmt1.setInt(5,lc_serial);
           ResultSet rs1=_pstmt1.executeQuery();
           if(rs1.next())
           {
        	   result_data1=rs1.getString("CLOB_DATA1");
           }
           
           Resultobj.setValue(column_name, result_data+result_data1);
		 }
	 }
	 catch(Exception e)
	 {
		 Resultobj.setValue(ErrorKey, "Error in fetching clob details");
	 }
	 
	 return Resultobj.copyofDTO();
 }
 
 //********************************************************************************************
 public DTObject olcmarginval(DTObject InputoBj)
 {
 try
     {
         int brncode=0;
         int day_sl=0;
         String entry_date="";
         double outsnd_amt=0.0;
         double pend_amt=0.0;
         int dec_length = 2;
         String outsnd_amt_tot="";
         String pend_amt_tot="";
         String errmsg="";
         
        if (!InputoBj.getValue("OLC_BRN_CODE").trim().equals(""))
  		{
        	 brncode = Integer.parseInt(InputoBj.getValue("OLC_BRN_CODE") .trim().toString());
  		}
  		else
  		{
  			brncode=0;
  		}
        if (!InputoBj.getValue("OLC_DAY_SERIAL").trim().equals(""))
  		{
        	day_sl = Integer.parseInt(InputoBj.getValue("OLC_DAY_SERIAL") .trim().toString());
  		}
  		else
  		{
  			day_sl=0;
  		}
        if (!InputoBj.getValue("OLC_ENTRY_DATE").trim().equals(""))
  		{
        	entry_date = FormatUtils.formatToDDMonYear(InputoBj.getValue("OLC_ENTRY_DATE") .trim().toString());
  		}
  		else
  		{
  			entry_date="";
  		}
        
        
         Init_ResultObj(InputoBj);
         if(Check_Result_Status())
         {
        	 Connection _conn = null;
				CallableStatement _cstmt = null;
				_conn = openConnection();
				_cstmt = _conn.prepareCall("CALL PKG_CSB_LIMITOLC.CASHMARGIN(?,?,?,?,?)");
				_cstmt.setInt(1,brncode);
				_cstmt.setString(2,entry_date);
				_cstmt.setInt(3,day_sl);
		    	_cstmt.registerOutParameter(4,Types.NUMERIC);
		    	_cstmt.registerOutParameter(5,Types.VARCHAR);
		    	_cstmt.execute();
		    	errmsg	= (_cstmt.getString(5)== null) ? "" : _cstmt.getString(5);
				
				if ( errmsg != null || !errmsg.trim().equals(""))
				 {
					Resultobj.setValue(ErrorKey,errmsg);					
				 }	
				else
				{
					Resultobj.setValue(ErrorKey,"");					
				}
				Resultobj.setValue("LCPS_CASH_MARGIN",_cstmt.getString(4));
        	
         }     
 	
     }  	 
 catch(Exception e)
 {
     Resultobj.setValue(ErrorKey,"Error in olcmarginval" );
 }
return Resultobj.copyofDTO();
}
 
//******************************************************************************************

 
 
 public DTObject olcBankCodekeypress(DTObject InputoBj)
 {
 try
     {
         String  olcBnkCode = "";
         {
         	olcBnkCode =  InputoBj.getValue("OLC_BANK_CODE") .trim().toString();
         }
     Init_ResultObj(InputoBj);
         if(String.valueOf(olcBnkCode).trim().equalsIgnoreCase(""))
         {
             Resultobj.setValue(ErrorKey,BLANK_CHECK);
         }
         if(Check_Result_Status())
         {
         	CommonValidator comnval	=	new	CommonValidator();
 			DTObject dtobj = new DTObject();
 			dtobj.clearMap();
         	dtobj.setValue("BANKCD_CODE",olcBnkCode);
         	Resultobj=comnval.valbankcd(dtobj);
         }	
     }
 catch(Exception e)
     {
         Resultobj.setValue(ErrorKey,"Error in olcAdvBankCodekeypress" );
     }
 return Resultobj.copyofDTO();
 }
// *********************************************************************************************************

// *********************************************************************************************************
/*
* Input 	- 						Key =OLC_ADV_BANK_CODE
* Output	: Error Message  		- 		Key = ErrorMsg
* 									
*/											

public DTObject olcAdvBranchCodekeypress(DTObject InputoBj)
{
try
    {
        String  olcAdvBrnchCode = "";
        String olcAdvBnkCode = "";
        olcAdvBrnchCode =   InputoBj.getValue("OLC_ADV_BRNCH_CODE") .trim().toString();
        olcAdvBnkCode =   InputoBj.getValue("OLC_ADV_BANK_CODE") .trim().toString();
        if(Check_Result_Status())
         {
        	CommonValidator comnval	=	new	CommonValidator();
			DTObject dtobj = new DTObject();
			dtobj.clearMap();
         dtobj.setValue("MBKBRN_BANK_CODE",olcAdvBnkCode);
         dtobj.setValue("MBKBRN_BRN_CODE",olcAdvBrnchCode);
         Resultobj=comnval.valmbkbrn(dtobj);
         }	
    }
catch(Exception e)
    {
        Resultobj.setValue(ErrorKey,"Error in olcAdvBankCodekeypress" );
    }
return Resultobj.copyofDTO();
}

// *********************************************************************************************************

// *********************************************************************************************************
/*
* Input 	- 						Key =
* Output	: Error Message  		- 		Key = ErrorMsg
* 									
*/											

public DTObject olcBranchNamekeypress(DTObject InputoBj)
{
try
    {
        String  olcBrnchName = "";
        {
     	   olcBrnchName =  InputoBj.getValue("OLC_BRNCH_NAME") .trim().toString();
        }
    Init_ResultObj(InputoBj);
        if(String.valueOf(olcBrnchName).trim().equalsIgnoreCase(""))
        {
            Resultobj.setValue(ErrorKey,BLANK_CHECK);
        }
    }
catch(Exception e)
    {
        Resultobj.setValue(ErrorKey,"Error in olcAdvBranchNamekeypress" );
    }
return Resultobj.copyofDTO();
}


public DTObject olcAdvBankCodekeypress(DTObject InputoBj)
{
try
    {
        String  olcAdvBnkCode = "";
        	olcAdvBnkCode =   InputoBj.getValue("OLC_ADV_BANK_CODE") .trim().toString();
        if(Check_Result_Status())
        {
        	CommonValidator comnval	=	new	CommonValidator();
			DTObject dtobj = new DTObject();
			dtobj.clearMap();
        	dtobj.setValue("BANKCD_CODE",olcAdvBnkCode);
        	Resultobj=comnval.valbankcd(dtobj);
        }	
    }
catch(Exception e)
    {
        Resultobj.setValue(ErrorKey,"Error in olcAdvBankCodekeypress" );
    }
return Resultobj.copyofDTO();
}
}
   
