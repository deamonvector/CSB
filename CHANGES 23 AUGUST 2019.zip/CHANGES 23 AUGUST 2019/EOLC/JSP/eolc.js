			var dlength;
			var calendar = new CalendarPopup('caldiv');
			var gridSubmenu;
			var gridEoladd;
			var decilength;
			var	decilength3=3;
			var decilength6=6;
			var decilength2=2;
			var combo;
		    var combo1;
		    var combo2;
		    var combo3;
		    var row=1;
		    var col=0;
		    var numchoice;
		    var autonum;
		    var res;
		    var tottenoramt;
		    var mardecilen;
		    var marginper;
		    var lcpsmarginper;
		    var intaccno;
		    var focusflag;
		    
		    var w_eolm_pc=0;
		    var w_totliabm=0;
			var w_eolm=0;
			var w_amt=0;
			var marginper=0;
			var eolmarginper=0;
			var marginamt=0;
			var eolmarginamt=0;
			//var cashmarginamt=0;
			var eolcashmarginamt=0;
			var limitdecilen;
			var drawdown;
			var recoverycurr;
			var totalamount;
			var objXMLApplet1 = new xmlHTTPValidator();
			var objXMLAppletGrid=new xmlHTTPValidator();
			var objXMLAppletGrid1 = new xmlHTTPValidator();
			var objXMLApplet2 = new xmlHTTPValidator();
			var objXMLApplet3 = new xmlHTTPValidator();//CHANGED ADDED ON 27/05/2018
			var objXMLApplet4 = new xmlHTTPValidator();//CHANGED ADDED ON 27/05/2018
			var objXMLApplet5 = new xmlHTTPValidator();//CHANGED ADDED ON 27/05/2018
			var objXMLApplet6 = new xmlHTTPValidator();//CHANGED ADDED ON 27/05/2018
			var trancrates_sl;
			var trancharges_sl;
			// var baseCurrency;
			//var currbusDate;
			var invoiceNumber;
			// var userBranchCode;
			// var usercountry;
			var equiamt;
			var amttobecon;
			var basedecilen;
			var flag1;
			var f2flag;
			var product_name;
			var product_code;
			//Changes P.Subramani-Chn-11/04/2008 Beg
			var olcusancedays;
			var olcusancemonth;
			var olccommmonth;
			var chargecurroption;
			var usancecharge;
			//Changes P.Subramani-Chn-11/04/2008 End
			
			//Changes P.Subramani-Chn-28/04/2008
			var custno;
			//S.Suresh Babu Add 30-06-2009
			var callflag="";
			var trchg_commitmnt_chgcd="";
			var	trchg_usance_chgcd="";
			
				//  CHN-prashanth -PATTERNS- 01-08-2017-TRSYCOMP_CHANGES.
			this.deciLength1 = 3;
			this.deciLength2 = 3;
			var TSRY_ENABLED="0";	     
			var rateType="";
			var rateFlag="";
			var w_conv_rate="";
           var amtConverted="0"; // CHN-prashanth 
			
			
			 // ADDED BY PRASHANTH 28 DEC 2017
			var ConvAmt="";			
			 // ADDED BY PRASHANTH 28 DEC 2017
			 
			 //CHANGED ADDED ON 27/05/2018 START
			 
			 var banklst = "";
			 var txtlst ="";
			 var bankBic="";
			 var lstchk="";
			 var bankBrn="";
			 var bankName ="";
			 var bankAddr="";
			 var bankCntry="";
			 var bankRout="";
			 var _copy =""; //changes in eolc on 14-Jun-2018
			 var copy_brn_code="";
			 var copy_sl="";
			 var copy_date="";
			 var copy_benf_code="";
			 var copy_benf_name="";
			 var copy_client_id="";
			 var copy_year="";
			 
			 //CHANGED ADDED ON 27/05/2018 END
			
//-----------------------------------------------------------------------------------------------------------------------------			
     function InitJSvar()
     {
        objXMLApplet2 = new xmlHTTPValidator();
        objXMLAppletGrid1 = new xmlHTTPValidator();
        objXMLAppletGrid=new xmlHTTPValidator();
        objXMLApplet1 = new xmlHTTPValidator();
        objXMLApplet3 = new xmlHTTPValidator();//CHANGED ADDED ON 27/05/2018
        objXMLApplet4 = new xmlHTTPValidator();//CHANGED ADDED ON 27/05/2018
        objXMLApplet5 = new xmlHTTPValidator();//CHANGED ADDED ON 27/05/2018
        objXMLApplet6 = new xmlHTTPValidator();//CHANGED ADDED ON 27/05/2018
        eolcashmarginamt=0;
        //cashmarginamt=0;
        eolmarginamt=0;
        marginamt=0;
        eolmarginper=0;
        marginper=0;
        w_amt=0;
        w_eolm=0;
        w_totliabm=0;
        w_eolm_pc=0;
        row=1;
        decilength2=2;
        decilength6=6;
        focusflag=false;
        decilength3=3;
        //Changes P.Subramani-Chn-11/04/2008 Beg
        olcusancedays="";
        olcusancemonth="";
        olccommmonth="";
        chargecurroption="";
        var usancecharge="";
        //Changes P.Subramani-Chn-11/04/2008 End
       
        //Changes P.Subramani-Chn-28/04/2008
		custno="";
        calendar = new CalendarPopup('caldiv');
        gridEoladd.setxmlcolumn("0,1,0,1,1,1,1,1,0,1,0,0,1,1");
        init_grid_values(gridEoladd);
        objTFMCharges.init_sess_variables();
        objCRates.init_sess_variables();
   		try {com_init_values();}catch(e){}
	}
//-----------------------------------------------------------------------------------------------------------------------------				
	function InitPara()
	{
		// ADDED BY PRASHANTH PATTERNS FOR TSRY_HOLIDAY 06 OCTOBER 2017
	    validateTrsyOperations();
		// ADDED BY PRASHANTH PATTERNS FOR TSRY_HOLIDAY 06 OCTOBER 2017
		
		
		InitJSvar();
		PGM_VERSION="1";
		TSRY_ENABLED = getTsryEnabledStatus();   					// treasury changes by PRASHANTH chn 05-08-2017
		setTabfocus("maintab","tcontent1");
		if(gid('MF:mxmlstr1').value!="")
		{
			gridEoladd.clearAll();
			gridEoladd.setxmlcolumn("0,1,0,1,1,1,1,1,0,1,0,0,1,1,0,0,0,0,0,1");
			gridEoladd.loadXMLString(gid('MF:mxmlstr1').value);
		}	
		if(gid('MF:txtserial').value!="")
		{
			DISPLAY_STATUS("MF:seluseroption","MF:txnstatus","MF:errmsg","MF:txtserial");
		}
		else
		{
			DISPLAY_STATUS("MF:seluseroption","MF:txnstatus","MF:errmsg","","MF:txtbatchnum");
			//alert(gid('MF:errmsg').value);
		}
		
		//CHANGED ADDED ON 26/05/2018 START
		
		 if(gid('MF:errmsg').value =="")
        	{
          		InitializeTab();
          	}
          	
		//CHANGED ADDED ON 26/05/2018 END
		
		// treasury changes by PRASHANTH chn 05-08-2017
		  if(TSRY_ENABLED=='1'){
		 	// getConversionRateParams();
		 	// getConvRate();
			gid('MF:TFMCRatesDetails:txtconvamt').readOnly=true;
			gid('MF:TFMCRatesDetails:txtconvrate').readOnly=true;
			gid("MF:TFMCRatesDetails:selconvrates").value="1";
			gid('MF:TFMCRatesDetails:selconvrates').disabled=true;
			document.getElementById('dealdetails').style.visibility = "hidden";
			document.getElementById('dealdetails_trsy').style.visibility = "hidden";
            objCRates.TRANCRATES_RATE_TYPE="1";
            AddRowToGrid(gridConvRates);
			gridConvRates.cells(1,1).setValue("1");
			}
			else{
			gid('MF:TFMCRatesDetails:txtconvamt').readOnly=false;
			gid('MF:TFMCRatesDetails:txtconvrate').readOnly=false;
			gid("MF:TFMCRatesDetails:selconvrates").value="0";
			gid('MF:TFMCRatesDetails:selconvrates').disabled=false;
			}
			//  treasury changes by PRASHANTH chn 05-08-2017
		
	}
		
	// treasury changes by PRASHANTH chn 05-08-2017
     function getTsryEnabledStatus()
    {
    		var status='0';
			objXMLApplet.clearMap();
		    objXMLApplet.setValue("Package","panacea.Validator.CommonValidator");
		    objXMLApplet.setValue("ValidateToken","true");
		    objXMLApplet.setValue("Method","validateProgramEnabledInterface");
		    objXMLApplet.setValue("PROGRAM_ID","EOLC");
		    objXMLApplet.setValue("BRN_CODE",userBranchCode);
    		objXMLApplet.sendAndReceive();
		    if (objXMLApplet.getValue("ErrorMsg") != "")
			{
				setMsg(objXMLApplet.getValue("ErrorMsg"));
			}
			else
			{
				status= objXMLApplet.getValue("TSRY_ENABLED");
		}
		return status;
    }
    
    		// treasury changes by PRASHANTH chn 05-08-2017
	function getConversionRateParams(){
			rateType= "";
			rateFlag= "";
			objXMLApplet.clearMap();
		    objXMLApplet.setValue("Package","panacea.Validator.CommonValidator");
		    objXMLApplet.setValue("ValidateToken","true");
		    objXMLApplet.setValue("Method","getConversionRateParams");
		    objXMLApplet.setValue("PROGRAM_ID","EOLC");
		    objXMLApplet.setValue("PURPOSE_CODE",gid('MF:txtconttype').value);  //PRASHANTH TREASURY CHANGES
		    
    		objXMLApplet.sendAndReceive();
		    if (objXMLApplet.getValue("ErrorMsg") != "")
			{
				setMsg("Error Occured  While fetching Rate Pickup Parameters");
				alert("Error Occured  While fetching Rate Pickup Parameters");
				setTabfocus("maintab","tcontent3");
				gid("MF:chkLcunderCon").focus();
			    return false;
			}
			else
			{
				rateType= objXMLApplet.getValue("RATEPICK_CARD_RATE_TYPE");
				rateFlag= objXMLApplet.getValue("RATEPICK_RATE_FLG");
			}
				return true;
	}
	
	//COMMENTED BY PRASHANTH ON 28 DECEMBER 2017
			// treasury changes by PRASHANTH chn 05-08-2017
				// treasury changes by PRASHANTH chn 05-08-2017
	
	/* function getConvRate(){
	        objXMLApplet.clearMap();
			objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
		    objXMLApplet.setValue("ValidateToken","true");
		    objXMLApplet.setValue("Method","getConvRate");
		    objXMLApplet.setValue("PROGRAM_ID","EOLC");
		    objXMLApplet.setValue("RATE_TYPE",rateType);
		    objXMLApplet.setValue("RATE_FLAG",rateFlag);
  		    objXMLApplet.setValue("CRCONVEN_CURR_CODE1",gid('MF:txtLCCurr').value);  //USD
  		    objXMLApplet.setValue("CRCONVEN_CURR_CODE2",baseCurrency );   //INR
    		objXMLApplet.sendAndReceive();
		    if (objXMLApplet.getValue("ErrorMsg") != "")
			{
				setMsg(objXMLApplet.getValue("ErrorMsg"));
			}
			else
			{
				w_conv_rate= objXMLApplet.getValue("CONV_RATES");
			}
				return true;
	}
	*/
	 // treasury changes by PRASHANTH chn 05-08-2017
	//COMMENTED BY PRASHANTH ON 28 DECEMBER 2017
	
	
	
	//ADDED  BY PRASHANTH 28 DEC 2017
			function getConvRate(){
		        objXMLApplet.clearMap();
				objXMLApplet.setValue("Package","panacea.Validator.TFMValidator");
			    objXMLApplet.setValue("ValidateToken","true");
			    objXMLApplet.setValue("Method","checkforSpecialRates");
			    objXMLApplet.setValue("PGM_ID","EOLC");
   			    objXMLApplet.setValue("CLIENT_ID",trim(gid('MF:txtcustnum1').value));
			    objXMLApplet.setValue("TYPE_OF_RATE","1");
			    if(gid('MF:txtcustnum1').value=="")
				gid('MF:txtcustnum1').value = 0;
	  		//    objXMLApplet.setValue("TRAN_CURRENCY",gid('MF:txtBillAmount').value);  //USD
	  		//    objXMLApplet.setValue("SRC_TRAN_CURR",baseCurrency );   //INR
	  		 	objXMLApplet.setValue("SRC_TRAN_CURR",gid('MF:txtLCCurr').value);  //USD
	  		    objXMLApplet.setValue("TRAN_CURRENCY",baseCurrency);   //INR
	  		    objXMLApplet.setValue("PURP_CODE",gid('MF:txtconttype').value);
	  		    objXMLApplet.setValue("SRC_TRAN_AMOUNT",unFormat(gid('MF:txtTotalAmt').value));//USD AMOUNT
	    		objXMLApplet.sendAndReceive();
			  /*  if (objXMLApplet.getValue("ErrorMsg") != "" && objXMLApplet.getValue("ErrorMsg")!="Rate request is made for the customer and not utilized for the day. Do you want continue with card rate ?")
				{
					setMsg(objXMLApplet.getValue("ErrorMsg"));
				}
				
				else
				{
				*/      
				    ConvAmt= objXMLApplet.getValue("CONV_AMOUNT"); 
					w_conv_rate= objXMLApplet.getValue("CONV_RATE");
				//}
					return true;
			}
			
		  // ADDED BY PRASHANTH 28 DEC 2017
			
	
	
	function updateRateValues(){
	 gid('MF:TFMCRatesDetails:txtconvrate').value=trim(w_conv_rate);
	 return true;
	
	}
	function updateGridValues(){
	   gridConvRates.clearAll();
	   gid('MF:TFMCRatesDetails:txtdisbreccurr').value = baseCurrency;
	   gid('MF:TFMCRatesDetails:outtxtconvcurr').value = gid('MF:txtLCCurr').value;	
	   gid('MF:TFMCRatesDetails:outtxtconvamt').value = gid('MF:txtTotalAmt').value;	
	   gid('MF:TFMCRatesDetails:txtconvamt').value = gid('MF:txtTotalAmt').value;	
      //  amtConverted=Math.round(trim(parseFloat(w_conv_rate)* parseFloat(unFormat(gid('MF:txtTotalAmt').value)))); //COMMENTED BY PRASHANTH 28 DECEMBER
       amtConverted=ConvAmt; //ADDED BY PRASHANTH 28 DEC
       gid('MF:TFMCRatesDetails:txtamtcurr').innerText = gid('MF:txtLCCurr').value;		//		CONV_CURR		USD
	   gid('MF:TFMCRatesDetails:txtconvrate').value=trim(w_conv_rate);
	   gid('MF:TFMCRatesDetails:txtamtcurr1').value=trim(baseCurrency);   //INR
	   gid('MF:TFMCRatesDetails:txtequivamt').value=trim(amtConverted);
	   gid('MF:TFMCRatesDetails:outtotamtcurr').value=trim(gid('MF:txtLCCurr').value);
	   gid('MF:TFMCRatesDetails:outtotconvamt').value=trim(unFormat(gid('MF:txtTotalAmt').value)); 
	   gid('MF:TFMCRatesDetails:outequivamtcurr').value=trim(baseCurrency);   //RECOVERY_CURR INR
	   gid('MF:TFMCRatesDetails:outequivamt').value=trim(amtConverted);
	   
	    //format changes 28 december by prashanth
	  // formattedAmt=formatAmount(gid('MF:txtBillAmount1'),this.deciLength2);
	  formatAmount(gid('MF:TFMCRatesDetails:outtxtconvamt'),this.deciLength1);
	  formatAmount(gid('MF:TFMCRatesDetails:txtconvamt'),this.deciLength1);
	  formatAmount(gid('MF:TFMCRatesDetails:outtotconvamt'),this.deciLength1);
	  
	  setAmountValue(objCRates.controlId+":outtxtconvamt",gid('MF:txtTotalAmt').value);
	  setAmountValue(objCRates.controlId+":txtconvamt",gid('MF:txtTotalAmt').value);
	  setAmountValue(objCRates.controlId+":outtotconvamt",gid('MF:txtTotalAmt').value);
	  setAmountValue(objCRates.controlId+":txtequivamt",trim(amtConverted));
	  setAmountValue(objCRates.controlId+":outequivamt",trim(amtConverted));
	  
	   //format changes 28 december by prashanth
	
	
		AddRowToGrid(gridConvRates);
		gridConvRates.cells(1,1).setValue("1");
		gridConvRates.cells(1,2).setValue("");
		gridConvRates.cells(1,3).setValue(0);
		gridConvRates.cells(1,4).setValue(0);
		gridConvRates.cells(1,5).setValue("");
		gridConvRates.cells(1,6).setValue("");
		gridConvRates.cells(1,7).setValue(0);	   
		gridConvRates.cells(1,8).setValue(gid('MF:txtLCCurr').value);
		gridConvRates.cells(1,9).setValue(this.deciLength2);
		gridConvRates.cells(1,10).setValue("");	//OUTSTAND
		gridConvRates.cells(1,11).setValue(gid('MF:txtLCCurr').value);   //tranccy  USD
		gridConvRates.cells(1,12).setValue(this.deciLength2);
		gridConvRates.cells(1,13).setValue(unFormat(gid('MF:txtTotalAmt').value));   //CONVAMT
		gridConvRates.cells(1,14).setValue(this.deciLength2);
	// 	gridConvRates.cells(1,15).setValue(gid('MF:TFMCRatesDetails:txtconvrate').value);
		gridConvRates.cells(1,15).setValue(w_conv_rate);
		gridConvRates.cells(1,16).setValue(baseCurrency);   //recovery ccy
		gridConvRates.cells(1,17).setValue(this.deciLength1);
		gridConvRates.cells(1,18).setValue(amtConverted);
		
		gridConvRates.cells(1,20).setValue("0");
		   //getTRANCRATES_EQV_PAYMENT_CURR
	    gid('MF:TFMCRatesDetails:txtconvamt').readOnly=true;
        gid('MF:TFMCRatesDetails:txtconvrate').readOnly=true;
		gid("MF:TFMCRatesDetails:selconvrates").value="1";
	    gid('MF:TFMCRatesDetails:selconvrates').disabled=true;
	    
	    
	    
	    	objCRates.branchcode = gid('MF:txtbrncode').value;
			objCRates.AddOrModify = gid('MF:seluseroption').value;
			objCRates.trandate = gid('MF:txtLCDate').value;
			if(gid('MF:txtcustnum1').value=="")
				objCRates.custnumber = 0;
			else
				objCRates.custnumber = gid('MF:txtcustnum1').value;
			objCRates.recovcurr = baseCurrency;
			objCRates.basecurrency = baseCurrency;
			
		  objCRates.amttobeconv = gid('MF:txtTotalAmt').value;
		  
		  
		  
	 	objCRates.trsy_enabled = TSRY_ENABLED;					// treasury changes by PRASHANTH chn 01-08-2017
        objCRates.ProgramID = "EOLC";              
        objCRates.purposeCode = gid('MF:txtconttype').value;// treasury changes by PRASHANTH chn 01-08-2017
                                                    
		 return true;
	}
	
   //CHN-PRASHANTH-05-08-2017-TRSYCOMP_CHANGES-ENDS


	
//-----------------------------------------------------------------------------------------------------------------------------			
	function gotFocusEvents(fldobj) 
	{
		lastEntdFld =fldobj;
	}	
//-----------------------------------------------------------------------------------------------------------------------------	
	function clearFields()
    {
   		gid('MF:txtbrncode').value=userBranchCode;
    	gid('MF:txtconttype').value="";
    	gid('MF:txtcontyear').value="";
    	gid('MF:txtcontsl').value="";
    	clearNonKeyFields() ;
    }
//-----------------------------------------------------------------------------------------------------------------------------	
	function clearNonKeyFields()
    {
    	setMsg("");
    	gid('MF:txtpresanDate').value="";
    	gid('MF:txtpresansl').value="";
    	gid('MF:txtRefNo').value="";
    	gid('MF:txtsanctionDate').value="";
    	gid('MF:txtLCDate').value="";
    	gid('MF:txtcustnum1').value="";
    	gid('MF:outlblcustnum1').innerText="";
    	gid('MF:txtAddress2').value="";
    	gid('MF:txtLcOfBranch').value="";
    	gid('MF:outlblLcBranch').innerText="";
    	gid('MF:txtBeneficiaryCode').value="";
    	gid('MF:txtBeneficiaryName').value="";
    	gid('MF:txtAddress1').value="";
    	gid('MF:txtCountryCode').value="";
    	gid('MF:outlblCountryCode').innerText="";
    	gid('MF:txtLcIssuedthruBank').value="";
    	gid('MF:outlblLcIssThruBank').innerText="";
    	gid('MF:txtLcIssuedthruBranch').value="";
    	gid('MF:txtLcIssuedBranchName').value="";
    	gid('MF:txtAddress21').value="";
    	gid('MF:txtLcIssuedOnplace').value="";
    	gid('MF:txtLcIssuedOncntry').value="";
    	gid('MF:outlblLcIssoncntry').innerText="";
    	gid('MF:lstAdThru').value="";
    	gid('MF:txtLCCurr').value="";
    	gid('MF:txtLCAmt').value="";
    	gid('MF:chkdeviationallowed').checked=false;
    	gid('MF:outlbldeviallowed').innerText="No";
    	gid('MF:txtdeviationallow').value="";
    	gid('MF:txtdeviationallow1').value="";
    	gid('MF:txtDeviationAmt').value="";
    	gid('MF:lstAmtquali').value="";
    	gid('MF:txtAdditionalamtcover').value="";
    	gid('MF:txtTermsOfprice').value="";
    	gid('MF:outlbltermsOfprice').innerText="";
    	gid('MF:txtLastDateOfNego').value="";
    	gid('MF:txtplaceOfexpy').value="";
    	gid('MF:txtLatestDateOfNego').value="";
    	gid('MF:txtShipmentperod').value="";
    	gid('MF:txtpresentationdetails').value="";
    	gid('MF:chkWithInValOfLC').checked=false;
		gid('MF:outlblWithInValOfLC').innerText="No";
		gid('MF:chkUsanceInterest').checked=false;
    	gid('MF:outlblUsanceInterest').innerText="No"; 
    	gid('MF:txtDrawDowns').value="";
    	gid('MF:chkUsanceInterest').checked=false;
    	gid('MF:outlblLcunderCon').innerText="No";
    	gid('MF:txtLcCurr11').value="";
    	gid('MF:txtLcAmt11').value="";
    	gid('MF:txtPositiveDeviaCurr').value="";
    	gid('MF:chkLcunderCon').checked=false;
    	gid('MF:outlblLcunderCon').innerText="No"; 
    	gid('MF:txtPositiveDeviaAmt').value="";
    	gid('MF:txtusanceIntCurr').value="";
    	gid('MF:txtusanceIntAmt').value=""; 
    	gid('MF:txtTotalCurr').value="";
    	gid('MF:txtTotalAmt').value="";
    	gid('MF:txtproductcode').value="";
    	gid('MF:outlblproductcode').innerText=""; 
    	gid('MF:txtcustlcliaAcc').value="";
    	gid('MF:outlblcustlcliaAcc').innerText="";  
    	gid('MF:txtLimitLineNo').value=""; 
    	gid('MF:outlblLimitLineNo').innerText=""; 
    	gid('MF:txtFacilityCurr').value=""; 
    	gid('MF:outlblcustlcliaAcc').value=""; 
    	gid('MF:outlblFacilityCurr').innerText=""; 
    	gid('MF:txtpresentLcLiaCurr').value=""; 
    	gid('MF:txtpresentLcLiaAmt').value=""; 
    	gid('MF:txtConRateToLimitCurr').value=""; 
    	gid('MF:txtLcLiaAmtlimitCurr').value=""; 
    	gid('MF:txtLcLiaAmtlimitAmt').value=""; 
    	gid('MF:txtFacilitylimitCurr').value=""; 
    	gid('MF:txtFacilitylimitAmt').value=""; 
    	//Changes P.Subramani-Chn-22/02/2008 Beg
    	gid('MF:txtoutstandingbeforeLcCurr').value=""; 
    	gid('MF:txtoutstandingbeforeLcAmt').value=""; 
    	gid('MF:txtLcPendingCurr').value=""; 
    	gid('MF:txtLcPendingAmt').value="";
    	gid('MF:txtoutstandingafterLcCurr').value=""; 
    	gid('MF:txtoutstandingafterLcAmt').value="";
    	//Changes P.Subramani-Chn-22/02/2008 End  
    	//commented on 07-Jul-2018 satrt
    	//gid('MF:txtExcessOverCurr').value=""; 
    	//gid('MF:txtExcessOverAmt').value=""; 
    	// commented on 07-Jul-2018 end
    	gid('MF:txtExcOverlimitDueCurrTrancurr').value=""; 
    	gid('MF:txtExcOverlimitDueCurrTrancurrAmt').value=""; 
    	
    	//Removed P.Subramani-Chn-22/07/2008 Beg
    	/*gid('MF:txtLcoutStandcurr').value=""; 
    	gid('MF:txtLcoutStandAmt').value=""; 
    	gid('MF:txtBilloutStandcurr').value=""; 
    	gid('MF:txtBilloutStandAmt').value=""; 
    	gid('MF:txtCrystalBillsOscurr').value=""; 
    	gid('MF:txtCrystalBillsOs').value=""; 
    	gid('MF:txtTotalOsLiabilitycurr').value=""; 
    	gid('MF:txtTotalOsLiabilityAmt').value=""; */
    	//Removed P.Subramani-Chn-22/07/2008 End
    	
    	gid('MF:txtmargincurr').value=""; 
    	gid('MF:outlblmargincurr').innerText=""; 
    	gid('MF:txtmarginpercentage').value=""; 
    	gid('MF:txtmarginpercentage1').value=""; 
    	gid('MF:txtmarginamtcurr').value=""; 
    	gid('MF:txtmarginamt1').value=""; 
    	gid('MF:txtmarginamt2').value=""; 
    	gid('MF:txtmarginamt3').value=""; 
		gid('MF:txtcashmargincurr').value=""; 
		gid('MF:txtcashmarginamt1').value=""; 
		gid('MF:txtcashmarginamt2').value=""; 
		gid('MF:txtcashmarginamt3').value=""; 
		gid('MF:lstmargintypeforLC').value="";
		//Changes P.Subramani-Chn-10/04/2008 Beg
		gid('MF:txtusnchgscurr').value="";
		gid('MF:txtusnchgsamt').value="";
		gid('MF:txtusnchgscurr1').value="";
		gid('MF:txtusnchgsamt1').value="";
		gid('MF:txtcommchgscurr').value="";
		gid('MF:txtcommchgsamt').value="";
		gid('MF:txtcommchgscurr1').value="";
		gid('MF:txtcommchgsamt1').value="";
		//Changes P.Subramani-Chn-10/04/2008 End 
		gridEoladd.clearAll();
		AddRowToGrid(gridEoladd);
		objTFMCharges.clearControl();	
		objCRates.clearControl();	
		objTranStmntPost.clearControl();
		//S.Suresh Babu Add 30-06-2009
		gid('MF:txtusanceservamt1').value="";
		gid('MF:txtcommservamt1').value="";
						//  CHN-prashanth -PATTERNS- 01-08-2017-TRSYCOMP_CHANGES
		//  	TSRY_ENABLED="0";	     
			 rateType="";
			 rateFlag="";
           gid('MF:TFMCRatesDetails:txtdisbreccurr').value = "";						
		   gid('MF:TFMCRatesDetails:outtxtconvcurr').value = "";
           gid('MF:TFMCRatesDetails:txtamtcurr').innerText = "";				
		   gid('MF:TFMCRatesDetails:txtconvamt').value="";
		   gid('MF:TFMCRatesDetails:txtconvrate').value="";
		   gid('MF:TFMCRatesDetails:txtamtcurr1').value="";
		   gid('MF:TFMCRatesDetails:txtequivamt').value="";
		   gid('MF:TFMCRatesDetails:outtotamtcurr').value="";
		   gid('MF:TFMCRatesDetails:outtotconvamt').value="";
		   gid('MF:TFMCRatesDetails:outequivamtcurr').value="";
		   gid('MF:TFMCRatesDetails:outequivamt').value="";
		   gid('MF:txtTotalAmount').value="";
		 gridConvRates.clearAll();
			
			//CHANGED ADDED ON 27/05/2018 START
			
			gid('MF:txtperiod').value ="";
			gid('MF:lstcredit').value="";
			gid('MF:txtRefPreAdv').value="";
			gid('MF:lstAppRule').value="";
			
			gid('MF:chkAppBank').checked=false;
    		gid('MF:outlblAppBank').innerText="No";
			gid('MF:lstAppBank').value="";
			
			gid('MF:lstBICdtl').value="";
			clearAppBic();
			clearAppAddr();

			
			gid('MF:lstAvl').value="";
			gid('MF:lstAvlBICdtl').value="";
			clearAVLBic();
			clearAVLAddr();
			
			gid('MF:txtDraft').value="";
			
			gid('MF:chkDrawee').checked=false;
    		gid('MF:outlblDrawee').innerText="No";	
    		
			gid('MF:lstDrwBICdtl').value="";
			clearDraweeBic();
			clearDraweeAddr();
			
			gid('MF:txtMixedPaydtl').value="";
			gid('MF:txtDeferPaydtl').value="";
			
			gid('MF:lstparShip').value="";
			gid('MF:lsttranShip').value="";
			gid('MF:txtTakCharge').value="";
			gid('MF:txtPortLoad').value="";
			gid('MF:txtPortDis').value="";
			gid('MF:txtPortDest').value="";
			gid('MF:txtDesGood1').value="";
			gid('MF:txtDesGood2').value="";
			gid('MF:txtDesGood3').value="";
			
			gid('MF:txtDesGood2').readOnly = true;
			gid('MF:txtDesGood3').readOnly = true;
			gid('MF:txtpresentationdetails').readOnly = true;
			
			gid('MF:txtShipPeriod').value="";
			
			gid('MF:txtDocRequired1').value="";
			gid('MF:txtDocRequired2').value="";
			gid('MF:txtDocRequired3').value="";
			gid('MF:txtDocRequired2').readOnly = true;
			gid('MF:txtDocRequired3').readOnly = true;
			
			gid('MF:txtAddCond1').value="";
			gid('MF:txtAddCond2').value="";
			gid('MF:txtAddCond3').value="";
			gid('MF:txtAddCond2').readOnly = true;
			gid('MF:txtAddCond3').readOnly = true;
			gid('MF:txtCharge').value="";
			
			gid('MF:lstConfInst').value="";
			
			gid('MF:chkReimb').checked=false;
    		gid('MF:outlblReimb').innerText="No";	
			
			gid('MF:lstReimbBank').value="";
			clearReimbBic();
			clearReimbAddr();
			
			gid('MF:txtInstPay').value="";
			
			gid('MF:chkAdvise').checked=false;
    		gid('MF:outlblAdvise').innerText="No";	
			
			gid('MF:lstAdviseBank').value="";
			clearAdvThrBic();
			clearAdvThrAddr();
			
			gid('MF:txtSendInfo').value="";
			gid('MF:txtrecbic').value="";
			
			banklst = "";
			txtlst ="";
			bankBic="";
			lstchk="";
			bankBrn="";
			bankName="";
			bankAddr="";
			bankCntry="";
			bankRout="";
			_copy =""; //changes in eolc on 14-Jun-2018
			copy_sl="";
			copy_date="";
			copy_benf_code="";
			copy_benf_name="";
			copy_client_id="";
			copy_brn_code="";
			copy_year="";
			//CHANGED ADDED ON 27/05/2018 END
			
		//ADDED BY PRASHANTH ON 29 JANUARY 2018
		//Changes Sanjay1 22-07-2019 Begin
			/*gid('MF:txtConfirmedByBank').value="";	
			gid('MF:outlblConfirmedByBank').innerText="";
			gid('MF:txtConfirmedBYBranch').value="";
			gid('MF:txtConfirmedBYBranchname').value="";*/
			gid('MF:lstReimbcfmBank').value="";
			clearReimbCfmBic();
		    clearReimbCfmAddr();
		//Changes Sanjay1 22-07-2019 End
		//ADDED BY PRASHANTH ON 29 JANUARY 2018
	}
	
//-----------------------------------------------------------------------------------------------------------------------------	
	function setFocus(fldobj)
	{
    	switch (trim(fldobj)) 
    	{
			case "MF:seluseroption" 				:  gid('MF:seluseroption').focus() ;break;
			case "MF:txtbrncode" 		    		:  gid('MF:txtbrncode').focus() ;break;
			case "MF:txtconttype" 					:  gid('MF:txtconttype').focus() ;break;
			case "MF:txtcontyear" 					:  gid('MF:txtcontyear').focus() ;break;
			case "MF:txtcontsl" 		    		:  gid('MF:txtcontsl').focus() ;break;
			
			//----------------------------------1 st tab-------------------------------------------------------------------------------------------------------------
			
			case "MF:txtpresanDate" 				: setTabfocus("maintab","tcontent1"); gid('MF:txtpresanDate').focus() ;break;
			case "MF:txtpresansl" 					: setTabfocus("maintab","tcontent1"); gid('MF:txtpresansl').focus() ;break;
			case "MF:txtLCDate" 					: setTabfocus("maintab","tcontent1"); gid('MF:txtLCDate').focus() ;break;
			case "MF:txtcustnum1" 					: setTabfocus("maintab","tcontent1"); gid('MF:txtcustnum1').focus() ;break;
			case "MF:txtLcOfBranch" 				: setTabfocus("maintab","tcontent1"); gid('MF:txtLcOfBranch').focus() ;break;
			case "MF:txtBeneficiaryCode" 			: setTabfocus("maintab","tcontent1"); gid('MF:txtBeneficiaryCode').focus() ;break;
			case "MF:txtBeneficiaryName" 			: setTabfocus("maintab","tcontent1"); gid('MF:txtBeneficiaryName').focus() ;break;
			case "MF:txtAddress1" 					: setTabfocus("maintab","tcontent1");focusTextArea('MF:txtAddress1');break;
			case "MF:txtCountryCode" 				: setTabfocus("maintab","tcontent1"); gid('MF:txtCountryCode').focus() ;break;
			case "MF:txtLcIssuedthruBank" 			: setTabfocus("maintab","tcontent1"); gid('MF:txtLcIssuedthruBank').focus() ;break;
			case "MF:txtLcIssuedthruBranch" 		: setTabfocus("maintab","tcontent1"); gid('MF:txtLcIssuedthruBranch').focus() ;break;
			case "MF:txtLcIssuedBranchName" 		: setTabfocus("maintab","tcontent1"); gid('MF:txtLcIssuedBranchName').focus() ;break;
			case "MF:txtAddress21" 					: setTabfocus("maintab","tcontent1"); focusTextArea('MF:txtAddress21');break;
			
			case "MF:txtLcIssuedOnplace" 			: setTabfocus("maintab","tcontent1"); gid('MF:txtLcIssuedOnplace').focus() ;break;
			case "MF:txtLcIssuedOncntry" 			: setTabfocus("maintab","tcontent1"); gid('MF:txtLcIssuedOncntry').focus() ;break;
			case "MF:lstAdThru" 					: setTabfocus("maintab","tcontent1"); gid('MF:lstAdThru').focus() ;break;
			
			//----------------------------------2 nd tab-------------------------------------------------------------------------------------------------------------
			
			case "MF:txtLCCurr" 					: setTabfocus("maintab","tcontent2"); gid('MF:txtLCCurr').focus() ;break;
			case "MF:txtLCAmt" 						: setTabfocus("maintab","tcontent2"); gid('MF:txtLCAmt').focus() ;break;
			case "MF:chkdeviationallowed" 			: setTabfocus("maintab","tcontent2"); gid('MF:chkdeviationallowed').focus() ;break;
			case "MF:txtdeviationallow" 			: setTabfocus("maintab","tcontent2"); gid('MF:txtdeviationallow').focus() ;break;
			case "MF:txtdeviationallow1" 			: setTabfocus("maintab","tcontent2"); gid('MF:txtdeviationallow1').focus() ;break;
			case "MF:txtDeviationAmt" 				: setTabfocus("maintab","tcontent2"); gid('MF:txtDeviationAmt').focus() ;break;
			case "MF:lstAmtquali" 					: setTabfocus("maintab","tcontent2"); gid('MF:lstAmtquali').focus() ;break;
			case "MF:txtAdditionalamtcover" 		: setTabfocus("maintab","tcontent2"); focusTextArea('MF:txtAdditionalamtcover');break;
			case "MF:txtTermsOfprice" 				: setTabfocus("maintab","tcontent2"); gid('MF:txtTermsOfprice').focus() ;break;
			
			case "MF:txtLastDateOfNego" 			: setTabfocus("maintab","tcontent2"); gid('MF:txtLastDateOfNego').focus() ;break;	
			case "MF:txtplaceOfexpy" 				: setTabfocus("maintab","tcontent2"); gid('MF:txtplaceOfexpy').focus() ;break;
			case "MF:txtLatestDateOfNego" 			: setTabfocus("maintab","tcontent2"); gid('MF:txtLatestDateOfNego').focus() ;break;
			case "MF:txtShipmentperod" 				: setTabfocus("maintab","tcontent2"); focusTextArea('MF:txtShipmentperod');break;
			case "MF:txtperiod" 					: setTabfocus("maintab","tcontent2"); gid('MF:txtperiod').focus() ;break;//CHANGED ADDED ON 27/05/2018
			case "MF:txtpresentationdetails" 		: setTabfocus("maintab","tcontent2"); focusTextArea('MF:txtpresentationdetails');break;
			case "MF:chkWithInValOfLC" 				: setTabfocus("maintab","tcontent2"); gid('MF:chkWithInValOfLC').focus() ;break;	
			
			//----------------------------------3 rd tab-------------------------------------------------------------------------------------------------------------
			
			case "MF:chkUsanceInterest" 			: setTabfocus("maintab","tcontent3"); gid('MF:chkUsanceInterest').focus() ;break;
			case "MF:txtDrawDowns" 					: setTabfocus("maintab","tcontent3"); gid('MF:txtDrawDowns').focus() ;break;	
			case "MF:chkLcunderCon" 				: setTabfocus("maintab","tcontent3"); gid('MF:chkLcunderCon').focus() ;break;
			case "MF:gridEoladd"					:   if(gid("MF:errmsg").value != "")
										      			{
										      				setTabfocus("maintab","tcontent3");
															SetFocus(gridEoladd,ErrorRow,ErrorColName); break;
										      			} 
										      			else
										      			{
										      				setTabfocus("maintab","tcontent3");
											      			SetFocus(gridEoladd,1,"ttype"); 
											      			SetFocus(gridEibill,1,"ttype");
										      			}
										      			break;
																
			//---------------------------------- 5th  tab-------------------------------------------------------------------------------------------------------------
			//S.Suresh Babu Changes 24-09-2009
			case "MF:txtConRateToLimitCurr"			: setTabfocus("maintab","tcontent5"); gid('MF:txtConRateToLimitCurr').focus() ;break;
			case "MF:Next" 							: setTabfocus("maintab","tcontent5"); gid('MF:Next').focus() ;break;
			//----------------------------------6 th tab-------------------------------------------------------------------------------------------------------------
			
			case "MF:txtmargincurr" 				: setTabfocus("maintab","tcontent6"); gid('MF:txtmargincurr').focus() ;break;
			case "MF:txtmarginpercentage" 			: setTabfocus("maintab","tcontent6"); gid('MF:txtmarginpercentage').focus() ;break;
			case "MF:txtmarginpercentage1"			: setTabfocus("maintab","tcontent6"); gid('MF:txtmarginpercentage1').focus() ;break;
			case "MF:txtmarginamt1"					: setTabfocus("maintab","tcontent6"); gid('MF:txtmarginamt1').focus() ;break;
			case "MF:txtmarginamt2"					: setTabfocus("maintab","tcontent6"); gid('MF:txtmarginamt2').focus() ;break;
			case "MF:txtcashmarginamt1"				: setTabfocus("maintab","tcontent6"); gid('MF:txtcashmarginamt1').focus() ;break;
			case "MF:txtcashmarginamt2"				: setTabfocus("maintab","tcontent6"); gid('MF:txtcashmarginamt2').focus() ;break;
			case "MF:lstmargintypeforLC"			: setTabfocus("maintab","tcontent6"); gid('MF:lstmargintypeforLC').focus() ;break;
			
			//Changes P.Subramani-Chn-10/04/2008 Beg
			//-----------------------------------7 th tab-----------------------------------------------------------------------------------------------
			case "MF:txtusnchgsamt1"				: setTabfocus("maintab","tcontent7"); gid('MF:txtusnchgsamt1').focus() ;break;
			case "MF:txtcommchgsamt1"				: setTabfocus("maintab","tcontent7"); gid('MF:txtcommchgsamt1').focus() ;break;
			case "MF:Next1"							:setTabfocus("maintab","tcontent7");gid('MF:Next1').focus() ;break;
			//Changes P.Subramani-Chn-10/04/2008 End
			
			//----------------------------------9th tab ---1 st sub tab-------------------------------------------------------------------------------------------------------------
			
			case "MF:lstcredit" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1"); gid('MF:lstcredit').focus() ;break;
			case "MF:txtRefPreAdv" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1"); gid('MF:txtRefPreAdv').focus() ;break;
			case "MF:lstAppRule" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1"); gid('MF:lstAppRule').focus() ;break;
			case "MF:chkAppBank" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1"); gid('MF:chkAppBank').focus() ;break;
			case "MF:lstAppBank" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1"); gid('MF:lstAppBank').focus() ;break;
			case "MF:lstBICdtl" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1"); gid('MF:lstBICdtl').focus() ;break;
			case "MF:txtAppBicCode" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1"); focusTextArea('MF:txtAppBicCode');break;//gid('MF:txtAppBicCode').focus()
			case "MF:txtAppBicBank" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1"); gid('MF:txtAppBicBank').focus() ;break;
			case "MF:txtAppBicBrn" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1"); focusTextArea('MF:txtAppBicBrn');break;//gid('MF:txtAppBicBrn').focus()
			case "MF:txtAppBankName" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1"); focusTextArea('MF:txtAppBankName');break;//gid('MF:txtAppBankName').focus() 
			case "MF:txtAppAcnt" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1"); focusTextArea('MF:txtAppAcnt');break;//gid('MF:txtAppAcnt').focus()
			case "MF:txtAppAddress" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1"); focusTextArea('MF:txtAppAddress');break;
			case "MF:txtAppCntry" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1"); focusTextArea('MF:txtAppCntry');break;//gid('MF:txtAppCntry').focus()
			
			case "MF:lstAvl" 						: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent10"); gid('MF:lstAvl').focus() ;break;
			case "MF:lstAvlBICdtl" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent10"); gid('MF:lstAvlBICdtl').focus() ;break;
			case "MF:txtAvlBicCode" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent10"); focusTextArea('MF:txtAvlBicCode');break;//gid('MF:txtAvlBicCode').focus()
			
			case "MF:txtAvlBicBank" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent10"); gid('MF:txtAvlBicBank').focus() ;break;
			case "MF:txtAvlBicBrn" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent10"); focusTextArea('MF:txtAvlBicBrn');break;//gid('MF:txtAvlBicBrn').focus()
			case "MF:txtAvlBankName" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent10"); focusTextArea('MF:txtAvlBankName');break;//gid('MF:txtAvlBankName').focus()
			case "MF:txtAvlAcnt" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent10"); focusTextArea('MF:txtAvlAcnt');break;//gid('MF:txtAvlAcnt').focus()
			case "MF:txtAvlAddress" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent10"); focusTextArea('MF:txtAvlAddress') ;break;
			case "MF:txtAvlCntry" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent10"); focusTextArea('MF:txtAvlCntry') ;break;//gid('MF:txtAvlCntry').focus()
			case "MF:txtDraft" 						: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent10"); focusTextArea('MF:txtDraft');break;
			case "MF:cmdcopylc"						: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1"); gid('MF:cmdcopylc').focus() ;break;
		
		//----------------------------------9th tab ---2 nd sub tab-------------------------------------------------------------------------------------------------------------
			
			case "MF:chkDrawee" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2"); gid('MF:chkDrawee').focus() ;break;
			case "MF:lstDrwBICdtl" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2"); gid('MF:lstDrwBICdtl').focus() ;break;
			case "MF:txtDrwBicCode" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2"); focusTextArea('MF:txtDrwBicCode');break;//gid('MF:txtDrwBicCode').focus()
			case "MF:txtDrwBicBank" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2"); gid('MF:txtDrwBicBank').focus() ;break;
			case "MF:txtDrwBicBrn" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2"); focusTextArea('MF:txtDrwBicBrn');break;//gid('MF:txtDrwBicBrn').focus()
			case "MF:txtDrwBankName" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2"); focusTextArea('MF:txtDrwBankName');break;//gid('MF:txtDrwBankName').focus()
			case "MF:txtDrwAcnt" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2"); focusTextArea('MF:txtDrwAcnt');break;//gid('MF:txtDrwAcnt').focus()
			case "MF:txtDrwAddress" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2"); focusTextArea('MF:txtDrwAddress') ;break;
			case "MF:txtDrwCntry" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2"); focusTextArea('MF:txtDrwCntry');break;//gid('MF:txtDrwCntry').focus()
			case "MF:txtMixedPaydtl" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2"); focusTextArea('MF:txtMixedPaydtl') ;break;
			case "MF:txtDeferPaydtl" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2"); focusTextArea('MF:txtDeferPaydtl') ;break;
			case "MF:lstparShip" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2"); gid('MF:lstparShip').focus() ;break;
			case "MF:lsttranShip" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2"); gid('MF:lsttranShip').focus() ;break;
			
			case "MF:txtTakCharge" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2"); focusTextArea('MF:txtTakCharge');break;
			case "MF:txtPortLoad" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2"); focusTextArea('MF:txtPortLoad') ;break;
			case "MF:txtPortDis" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent3"); focusTextArea('MF:txtPortDis') ;break;
			case "MF:txtPortDest"					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent3"); focusTextArea('MF:txtPortDest') ;break;
			
		//----------------------------------9th tab ---3 rd sub tab-------------------------------------------------------------------------------------------------------------
			
			case "MF:txtShipPeriod" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent3"); focusTextArea('MF:txtShipPeriod');break;
			case "MF:txtDesGood1" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent3"); focusTextArea('MF:txtDesGood1') ;break;
			case "MF:txtDesGood2" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent3"); focusTextArea('MF:txtDesGood2') ;break;
			case "MF:txtDesGood3" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent3"); focusTextArea('MF:txtDesGood3') ;break;
		
		//----------------------------------9th tab ---4 th sub tab-------------------------------------------------------------------------------------------------------------
			
			case "MF:txtDocRequired1" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent4"); focusTextArea('MF:txtDocRequired1') ;break;
			case "MF:txtDocRequired2" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent4"); focusTextArea('MF:txtDocRequired2') ;break;
			case "MF:txtDocRequired3" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent4"); focusTextArea('MF:txtDocRequired3').focus() ;break;
			
		//----------------------------------9th tab ---5 th sub tab-------------------------------------------------------------------------------------------------------------
			
			case "MF:txtAddCond1" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent5"); focusTextArea('MF:txtAddCond1');break;
			case "MF:txtAddCond2" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent5"); focusTextArea('MF:txtAddCond2');break;
			case "MF:txtAddCond3" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent5"); focusTextArea('MF:txtAddCond3');break;
			case "MF:txtCharge" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent5"); focusTextArea('MF:txtCharge');break;
		
		//----------------------------------9th tab ---6 th sub tab-------------------------------------------------------------------------------------------------------------
			
			case "MF:lstConfInst" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); gid('MF:lstConfInst').focus() ;break;
			case "MF:chkReimb" 						: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); gid('MF:chkReimb').focus() ;break;
			case "MF:lstReimbBank" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); gid('MF:lstReimbBank').focus() ;break;
			case "MF:txtReimBicCode" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); focusTextArea('MF:txtReimBicCode');break;//gid('MF:txtReimBicCode').focus()
			case "MF:txtReimBicBank" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); gid('MF:txtReimBicBank').focus() ;break;
			case "MF:txtReimBicBrn" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); focusTextArea('MF:txtReimBicBrn');break;//gid('MF:txtReimBicBrn').focus()			
			case "MF:txtReimBankName" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); focusTextArea('MF:txtReimBankName');break;//gid('MF:txtReimBankName').focus()
			case "MF:txtReimAcnt" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); focusTextArea('MF:txtReimAcnt');break;//gid('MF:txtReimAcnt').focus()
			case "MF:txtReimAddress" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); focusTextArea('MF:txtReimAddress');break;
			case "MF:txtReimCntry" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); focusTextArea('MF:txtReimCntry');break;//gid('MF:txtReimCntry').focus()
			case "MF:txtInstPay" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); focusTextArea('MF:txtInstPay');break;
			
	//----------------------------------9th tab ---7 th sub tab-------------------------------------------------------------------------------------------------------------
		
			case "MF:chkAdvise" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent7"); gid('MF:chkAdvise').focus() ;break;
			case "MF:lstAdviseBank" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent7"); gid('MF:lstAdviseBank').focus() ;break;			
			case "MF:txtAdviseBicBank" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent7"); gid('MF:txtAdviseBicBank').focus() ;break;
			case "MF:txtAdviseBicCode" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent7"); focusTextArea('MF:txtAdviseBicCode');break;//gid('MF:txtAdviseBicCode').focus()
			case "MF:txtAdviseBicBrn" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent7"); gid('MF:txtAdviseBicBrn').focus() ;break;//gid('MF:txtAdviseBicBrn').focus()
			case "MF:txtAdviseBankName" 			: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent7"); focusTextArea('MF:txtAdviseBankName');break;//gid('MF:txtAdviseBankName').focus()
			case "MF:txtAdviseAddress" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent7"); focusTextArea('MF:txtAdviseAddress');break;
			case "MF:txtAdviseCntry" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent7"); focusTextArea('MF:txtAdviseCntry');break;//gid('MF:txtAdviseCntry').focus()
			case "MF:txtAdviseAcnt" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent7"); focusTextArea('MF:txtAdviseAcnt');break;//gid('MF:txtAdviseAcnt').focus()
			case "MF:txtSendInfo" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent7"); focusTextArea('MF:txtSendInfo');break;
			case "MF:txtrecbic" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent7"); focusTextArea('MF:txtrecbic');break;
			
		}
	}
	
//-----------------------------------------------------------------------------------------------------------------------------			
	function keyDownEvents(fldobj)
	{
    	setMsg("");
		if (window.event.keyCode == KEY_TAB) 
		{
        	if(window.event.shiftKey == false)
			{
				window.event.keyCode = 13;
				keyPressEvents(fldobj);
			}
		    else 
			{
				window.event.keyCode =0 ;
				PERFORM_BACKTRACK(fldobj);
				return ;
		 	}
		}
		switch (window.event.keyCode) 
		{
			case  KEY_F2 :PERFORM_BACKTRACK(fldobj); break;
			case  KEY_F5 :SHOW_HELP(fldobj); break ; 
		}
	}
//-----------------------------------------------------------------------------------------------------------------------------		  
	function PERFORM_BACKTRACK(fldobj)
	{ 
		switch (fldobj.name) 
		{	
			case "MF:txtbrncode" 	       	    	:gid('MF:seluseroption').focus() ;break;
			case "MF:txtconttype" 	       	    	:gid('MF:txtbrncode').focus() ;break;
			case "MF:txtcontyear" 	       	    	:gid('MF:txtconttype').focus() ;break;
			case "MF:txtcontsl" 	       	    	:gid('MF:txtcontyear').focus() ;break;
			
			//----------------------------------1 st tab-------------------------------------------------------------------------------------------------------------
			
			case "MF:txtpresanDate" 	       	    :if(gid('MF:txtcontsl').value=="")
													 {
													 	gid('MF:txtcontyear').focus();
													 }
													 else
													 {	
													 	gid('MF:txtcontsl').focus() ; 
													 }break;
			case "MF:txtpresansl" 	       	    	:setTabfocus("maintab","tcontent1");gid('MF:txtpresanDate').focus();break;
			case "MF:txtLCDate" 	       	    	:if(gid('MF:seluseroption').value=="M")
													 {
													 	gid('MF:txtcontsl').focus(); 
													 }
													 else	
													 {
													 	setTabfocus("maintab","tcontent1");gid('MF:txtpresansl').focus();
													 }break;
			case "MF:txtBeneficiaryCode" 	       	:setTabfocus("maintab","tcontent1");gid('MF:txtLCDate').focus();break;
			case "MF:txtBeneficiaryName" 	       	:setTabfocus("maintab","tcontent1");gid('MF:txtBeneficiaryCode').focus();break;
			case "MF:txtAddress1" 	       	    	:setTabfocus("maintab","tcontent1");gid('MF:txtBeneficiaryName').focus();break;
			case "MF:txtCountryCode" 	       	    :setTabfocus("maintab","tcontent1");focusTextArea('MF:txtAddress1');break;
			case "MF:txtLcIssuedthruBank" 	    	:setTabfocus("maintab","tcontent1");gid('MF:txtCountryCode').focus();break;
			case "MF:txtLcIssuedthruBranch" 	    :setTabfocus("maintab","tcontent1");gid('MF:txtLcIssuedthruBank').focus();break;
			case "MF:txtLcIssuedBranchName" 	    :setTabfocus("maintab","tcontent1");gid('MF:txtLcIssuedthruBranch').focus();break;
			case "MF:txtAddress21" 	       			:setTabfocus("maintab","tcontent1");gid('MF:txtLcIssuedBranchName').focus();break;
			case "MF:txtLcIssuedOnplace" 	       	:setTabfocus("maintab","tcontent1");focusTextArea('MF:txtAddress21');break;
			case "MF:txtLcIssuedOncntry" 	       	:setTabfocus("maintab","tcontent1");gid('MF:txtLcIssuedOnplace').focus();break;
			case "MF:lstAdThru" 	       	    	:setTabfocus("maintab","tcontent1");gid('MF:txtLcIssuedOncntry').focus();break;
			
			//----------------------------------2 nd tab-------------------------------------------------------------------------------------------------------------
			
			//Changes P.Subramani-Chn-23/05/2008 Beg
			case "MF:chkdeviationallowed" 	    	:setTabfocus("maintab","tcontent1");gid('MF:lstAdThru').focus();break;
			//Changes P.Subramani-Chn-23/05/2008 End
			case "MF:txtdeviationallow" 	       	:setTabfocus("maintab","tcontent2");gid('MF:chkdeviationallowed').focus();break;
			case "MF:txtdeviationallow1" 	       	:setTabfocus("maintab","tcontent2");gid('MF:txtdeviationallow').focus();break;
			
			case "MF:txtDeviationAmt" 	       		:setTabfocus("maintab","tcontent2");gid('MF:txtdeviationallow1').focus();break;
			case "MF:lstAmtquali" 	       	    	:setTabfocus("maintab","tcontent2");gid('MF:txtDeviationAmt').focus();break;
			case "MF:txtAdditionalamtcover" 	    :setTabfocus("maintab","tcontent2");gid('MF:lstAmtquali').focus();break;
			case "MF:txtTermsOfprice" 	       		:if(gid('MF:chkdeviationallowed').checked==true)
													 {
													 	setTabfocus("maintab","tcontent2"); gid('MF:txtAdditionalamtcover').focus() ;
													 }
													 else
													 {	
													 	setTabfocus("maintab","tcontent2"); gid('MF:chkdeviationallowed').focus() ; 
													 }break;
			case "MF:txtLastDateOfNego" 	       	:setTabfocus("maintab","tcontent2");gid('MF:txtTermsOfprice').focus();break;
			case "MF:txtplaceOfexpy" 	       	    :setTabfocus("maintab","tcontent2");gid('MF:txtLastDateOfNego').focus();break;
			case "MF:txtLatestDateOfNego" 	    	:setTabfocus("maintab","tcontent2");gid('MF:txtplaceOfexpy').focus();break;
			case "MF:txtShipmentperod" 	       		:setTabfocus("maintab","tcontent2");gid('MF:txtLatestDateOfNego').focus();break;
			
			//CHANGED ADDED ON 27/05/2018 START
			
			case "MF:txtperiod" 					: if(gid('MF:txtLatestDateOfNego').value=="")
													 {
													 	setTabfocus("maintab","tcontent2");gid('MF:txtShipmentperod').focus() ;break;
													 }
												     else
													 {	
													 	setTabfocus("maintab","tcontent2");gid('MF:txtLatestDateOfNego').focus() ;break; 
													 }
			case "MF:txtpresentationdetails" 	    :setTabfocus("maintab","tcontent2");gid('MF:txtperiod').focus() ;break;
			
			//CHANGED ADDED ON 27/05/2018 END
			
			case "MF:chkWithInValOfLC" 	       	    :setTabfocus("maintab","tcontent2");gid('MF:txtpresentationdetails').focus();break;
		
		//----------------------------------3 rd tab-------------------------------------------------------------------------------------------------------------
			case "MF:chkUsanceInterest" 	       	:setTabfocus("maintab","tcontent2");gid('MF:chkWithInValOfLC').focus();break;
			case "MF:txtDrawDowns" 	       	    	:setTabfocus("maintab","tcontent3");gid('MF:chkUsanceInterest').focus();break;
			case "MF:chkLcunderCon" 				:setTabfocus("maintab","tcontent3");SetFocus(gridEoladd,(gridEoladd.getRowsNum()),"docdel");break;
		
		//----------------------------------4 th tab-------------------------------------------------------------------------------------------------------------
		
		//----------------------------------5 th tab-------------------------------------------------------------------------------------------------------------
			case "MF:Nextlimit"			 				:setTabfocus("maintab","tcontent4");gid("MF:TFMCRatesDetails:cmdOk").focus();break;
			case "MF:txtConRateToLimitCurr"				:setTabfocus("maintab","tcontent4");gid("MF:Nextlimit").focus();break;
			case "MF:Next" 	    		 				:if(baseCurrency == gid('MF:txtFacilityCurr').value)
														 {
													 	 	setTabfocus("maintab","tcontent5");gid("MF:Nextlimit").focus();
														 }
														 else
														 {
														 	setTabfocus("maintab","tcontent5");gid('MF:txtConRateToLimitCurr').focus();break;
														 }break;
		//----------------------------------6 th tab-------------------------------------------------------------------------------------------------------------
		
			case "MF:txtmargincurr" 	    			:setTabfocus("maintab","tcontent5");gid('MF:Next').focus();break;
			case "MF:txtmarginpercentage" 				:setTabfocus("maintab","tcontent6");gid('MF:txtmargincurr').focus();break;
			case "MF:txtmarginpercentage1"				:setTabfocus("maintab","tcontent6");gid('MF:txtmarginpercentage').focus();break;
			
			case "MF:txtmarginamt1"						:if(flag1==1)
														 {
														 	setTabfocus("maintab","tcontent6");gid('MF:txtmarginpercentage').focus();
														 }
														 else if(flag1==3)
														 {
															setTabfocus("maintab","tcontent6");gid('MF:txtmarginpercentage1').focus();
														 }break;	
			case "MF:txtmarginamt2"						:if(flag1==2)
														 {
															setTabfocus("maintab","tcontent6");gid('MF:txtmarginpercentage1').focus();
														 }
														 else if(flag1==3)
														 {
															setTabfocus("maintab","tcontent6");gid('MF:txtmarginamt1').focus();
														 }break;	
													
			case "MF:txtcashmarginamt1"					:if(flag1==1)
														 {
														 	setTabfocus("maintab","tcontent6");gid('MF:txtmarginamt1').focus();
														 }
														 else if(flag1==3)
														 {
															setTabfocus("maintab","tcontent6");gid('MF:txtmarginamt2').focus();
														 }break;	
													
			case "MF:txtcashmarginamt2"					:if(flag1==2)
														 {
															setTabfocus("maintab","tcontent6");gid('MF:txtmarginamt2').focus();
														 }
														 else if(flag1==3)
														 {
															setTabfocus("maintab","tcontent6");gid('MF:txtcashmarginamt1').focus();
														 }break;	
													
			case "MF:lstmargintypeforLC"				:if(flag1==1)
														 {
															setTabfocus("maintab","tcontent6");gid('MF:txtcashmarginamt1').focus();
														 }
														 else if(flag1==2)
														 {
															setTabfocus("maintab","tcontent6");gid('MF:txtcashmarginamt2').focus();
														 }
														 else if(flag1==3)
														 {
															setTabfocus("maintab","tcontent6");gid('MF:txtcashmarginamt2').focus();
														 }break;
			
			//Changes P.Subramani-Chn-10/04/2008 Beg										
			case "MF:txtusnchgsamt1"					: setTabfocus("maintab","tcontent7");objTFMCharges.FocusPrevious();break; 
			case "MF:txtcommchgsamt1"					: setTabfocus("maintab","tcontent7"); gid('MF:txtusnchgsamt1').focus() ;break;
			case "MF:Next1"								:setTabfocus("maintab","tcontent7");gid('MF:txtcommchgsamt1').focus() ;break;
			//Changes P.Subramani-Chn-10/04/2008 End
			
			
			//Changes P.Subramani-Chn-22/02/2008
			
			//CHANGED ADDED ON 27/05/2018 START
			//----------------------------------9th tab ---1 st sub tab-------------------------------------------------------------------------------------------------------------
			
			case "MF:cmdokbutton"					:
														if(parseFloat(unFormat(document.getElementById('MF:TFMChargesDetails:outtxttotal').value)) > 0)
	    												{
	    													setTabfocus("maintab","tcontent8");document.getElementById('MF:translmt:txtGLAccessCode').focus();	break;											
	    												}
	    												else
	    												{
	    													setTabfocus("maintab","tcontent7");objTFMCharges.FocusPrevious();break;
	    												}
			case "MF:lstcredit" 					: setTabfocus("maintab","tcontent8");gid('MF:cmdokbutton').focus() ;break;
			case "MF:txtRefPreAdv" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1"); gid('MF:lstcredit').focus() ;break;
			case "MF:lstAppRule" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1"); gid('MF:txtRefPreAdv').focus() ;break;
			case "MF:chkAppBank" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1"); gid('MF:lstAppRule').focus() ;break;
			case "MF:lstAppBank" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1"); gid('MF:chkAppBank').focus() ;break;
			case "MF:lstBICdtl" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1"); gid('MF:lstAppBank').focus() ;break;
			case "MF:txtAppBicCode" 				: 
													  if(gid('MF:lstBICdtl').disabled == false )
   													 {
   														setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1"); gid('MF:lstBICdtl').focus() ;break;
   													 }
   													 else
   													 {
   														setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1"); gid('MF:lstAppBank').focus() ;break;
   													 }
   													 
			case "MF:txtAppBicBank" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1"); gid('MF:txtAppBicCode').focus() ;break;
			case "MF:txtAppBicBrn" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1"); gid('MF:txtAppBicBank').focus() ;break;
			case "MF:txtAppAcnt" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1"); gid('MF:lstBICdtl').focus() ;break;
			case "MF:txtAppBankName" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1"); gid('MF:txtAppAcnt').focus() ;break;
			case "MF:txtAppAddress" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1"); gid('MF:txtAppBankName').focus() ;break;
			case "MF:txtAppCntry" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1"); focusTextArea('MF:txtAppAddress') ;break;
			
			case "MF:lstAvl" 						: 
													 if(gid('MF:lstBICdtl').disabled == false )
   													 {
														 if(trim(gid('MF:lstBICdtl').value) == "1" || trim(gid('MF:lstBICdtl').value) == "")
	   													 {
	   														setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1"); gid('MF:txtAppBicBrn').focus() ;break;
	   													 }
	   													 else
	   													 {
	   														setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1"); gid('MF:txtAppCntry').focus() ;break;
	   													 }
   													 }
   													 else
   													 {
   													 	setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1"); gid('MF:chkAppBank').focus() ;break;
   													 }
			case "MF:lstAvlBICdtl" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent10"); gid('MF:lstAvl').focus() ;break;
			case "MF:txtAvlBicCode" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent10"); gid('MF:lstAvlBICdtl').focus() ;break;
			
			case "MF:txtAvlBicBank" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent10"); gid('MF:txtAvlBicCode').focus() ;break;
			case "MF:txtAvlBicBrn" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent10"); gid('MF:txtAvlBicBank').focus() ;break;
			case "MF:txtAvlAcnt" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent10"); gid('MF:lstAvlBICdtl').focus() ;break;
			case "MF:txtAvlBankName" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent10"); gid('MF:txtAvlAcnt').focus() ;break;
			case "MF:txtAvlAddress" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent10"); gid('MF:txtAvlBankName').focus() ;break;
			case "MF:txtAvlCntry" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent10"); focusTextArea('MF:txtAvlAddress') ;break;
			case "MF:txtDraft" 						: 
													if(trim(gid('MF:lstAvlBICdtl').value) == "1" || trim(gid('MF:lstAvlBICdtl').value) == "")
   													 {
   														setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent10"); gid('MF:txtAvlBicBrn').focus() ;break;
   													 }
   													 else
   													 {
   														setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent10"); gid('MF:txtAvlCntry').focus() ;break;
   													 }
		
		//----------------------------------9th tab ---2 nd sub tab-------------------------------------------------------------------------------------------------------------
			
			case "MF:chkDrawee" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent10"); focusTextArea('MF:txtDraft') ;break;
			case "MF:lstDrwBICdtl" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2"); gid('MF:chkDrawee').focus() ;break;
			case "MF:txtDrwBicCode" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2"); gid('MF:lstDrwBICdtl').focus() ;break;
			case "MF:txtDrwBicBank" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2"); gid('MF:txtDrwBicCode').focus() ;break;
			case "MF:txtDrwBicBrn" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2"); gid('MF:txtDrwBicBank').focus() ;break;
			case "MF:txtDrwAcnt" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2"); gid('MF:lstDrwBICdtl').focus() ;break;
			case "MF:txtDrwBankName" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2"); gid('MF:txtDrwAcnt').focus() ;break;
			case "MF:txtDrwAddress" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2"); focusTextArea('MF:txtDrwBankName') ;break;
			case "MF:txtDrwCntry" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2"); gid('MF:txtDrwAddress').focus() ;break;
			case "MF:txtMixedPaydtl" 				: 
													if(gid('MF:lstDrwBICdtl').disabled == false )
   													 {
														if(trim(gid('MF:lstDrwBICdtl').value) == "1" || trim(gid('MF:lstDrwBICdtl').value) == "")
	   													 {
	   														setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2"); gid('MF:txtDrwBicBrn').focus() ;break;
	   													 }
	   													 else
	   													 {
	   														setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2"); gid('MF:txtDrwCntry').focus() ;break;
	   													 }
   													 }
   													 else
   													 {
   													 	setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2"); gid('MF:chkDrawee').focus() ;break;
   													 }
			case "MF:txtDeferPaydtl" 				: if(gid('MF:lstDrwBICdtl').disabled == false )
   													 {
														if(trim(gid('MF:lstDrwBICdtl').value) == "1" || trim(gid('MF:lstDrwBICdtl').value) == "")
	   													 {
	   														setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2"); gid('MF:txtDrwBicBrn').focus() ;break;
	   													 }
	   													 else
	   													 {
	   														setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2"); gid('MF:txtDrwCntry').focus() ;break;
	   													 }
   													 }
   													 else
   													 {
   													 	setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2"); gid('MF:chkDrawee').focus() ;break;
   													 }
			case "MF:lstparShip" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2"); focusTextArea('MF:txtDeferPaydtl') ;break;
			case "MF:lsttranShip" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2"); gid('MF:lstparShip').focus() ;break;
			
			case "MF:txtTakCharge" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2"); gid('MF:lsttranShip').focus() ;break;
			case "MF:txtPortLoad" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2"); focusTextArea('MF:txtTakCharge') ;break;
			case "MF:txtPortDis" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2"); focusTextArea('MF:txtPortLoad');break;
			case "MF:txtPortDest"					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent3"); focusTextArea('MF:txtPortDis');break;
			
		//----------------------------------9th tab ---3 rd sub tab-------------------------------------------------------------------------------------------------------------
			
			case "MF:txtShipPeriod" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent3"); focusTextArea('MF:txtPortDest') ;break;
			case "MF:txtDesGood1" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent3"); focusTextArea('MF:txtShipPeriod') ;break;
			case "MF:txtDesGood2" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent3"); focusTextArea('MF:txtDesGood1');break;
			case "MF:txtDesGood3" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent3"); focusTextArea('MF:txtDesGood2') ;break;
		
		//----------------------------------9th tab ---4 th sub tab-------------------------------------------------------------------------------------------------------------
			
			case "MF:txtDocRequired1" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent3"); focusTextArea('MF:txtDesGood3') ;break;
			case "MF:txtDocRequired2" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent4"); focusTextArea('MF:txtDocRequired1') ;break;
			case "MF:txtDocRequired3" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent4"); focusTextArea('MF:txtDocRequired2') ;break;
			
		//----------------------------------9th tab ---5 th sub tab-------------------------------------------------------------------------------------------------------------
			
			case "MF:txtAddCond1" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent4"); focusTextArea('MF:txtDocRequired3') ;break;
			case "MF:txtAddCond2" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent5"); focusTextArea('MF:txtAddCond1');break;
			case "MF:txtAddCond3" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent5"); focusTextArea('MF:txtAddCond2') ;break;
			case "MF:txtCharge" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent5"); focusTextArea('MF:txtAddCond3') ;break;
		
		//----------------------------------9th tab ---6 th sub tab-------------------------------------------------------------------------------------------------------------
			
			case "MF:lstConfInst" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent5"); focusTextArea('MF:txtCharge') ;break;
			
			//ADDED BY PRASHANTH
			//Changes Sanjay1 22-07-2019 Begin
			case "MF:lstReimbcfmBank" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); gid('MF:lstConfInst').focus() ;break;
			case "MF:txtReimcfmBicCode" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); gid('MF:lstReimbcfmBank').focus() ;break;
			case "MF:txtReimcfmBicBank" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); gid('MF:txtReimcfmBicCode').focus() ;break;
			case "MF:txtReimcfmBicBrn" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); gid('MF:txtReimcfmBicBank').focus() ;break;
			
           
            case "MF:txtcfmReimAcnt" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); gid('MF:lstReimbcfmBank').focus() ;break;
			case "MF:txtcfmReimBankName" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); gid('MF:txtcfmReimAcnt').focus() ;break;
			case "MF:txtcfmReimAddress" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); gid('MF:txtcfmReimBankName').focus() ;break;
			case "MF:txtcfmReimCntry" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); focusTextArea('MF:txtcfmReimAddress') ;break;
			
			/*case "MF:txtConfirmedByBank" 			: gid('MF:lstConfInst').focus() ;break;
		    case "MF:txtConfirmedBYBranchname" 		: gid('MF:txtConfirmedBYBranch').focus() ;break;
			case "MF:txtConfirmedBYBranch" 			: gid('MF:txtConfirmedByBank').focus() ;break;*/
			
			
			case "MF:chkReimb" 						: if(gid('MF:lstReimbcfmBank').disabled == false )
   													 {
														if(trim(gid('MF:lstReimbcfmBank').value) == "1" || trim(gid('MF:lstReimbcfmBank').value) == "")
	   													 {
	   														setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); gid('MF:txtReimcfmBicBrn').focus() ;break;
	   													 }
	   													 else
	   													 {
	   														setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); gid('MF:txtcfmReimCntry').focus() ;break;
	   													 }
   													 }
   													 else
   													 {
   													 	setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); gid('MF:lstConfInst').focus() ;break;
   													 }
			//ADDED BY PRASHANTH ON 29 JANUARY 2018
			/*if(gid("MF:lstConfInst").value=="1"){
			    setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6");gid('MF:txtConfirmedByBank').focus() ;break;
			}else{
				setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); 
				gid('MF:lstConfInst').focus() ;break;
			
			}
			case "MF:txtConfirmedByBank" 						: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); focusTextArea('MF:lstConfInst') ;break;
		    case "MF:txtConfirmedBYBranch" 						: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); focusTextArea('MF:txtConfirmedByBank') ;break;
		    case "MF:txtConfirmedBYBranchname" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); focusTextArea('MF:txtConfirmedBYBranch') ;break;*/
			//Changes Sanjay1 22-07-2019 End
			
			//ADDED BY PRASHANTH ON 29 JANUARY 2018
			case "MF:lstReimbBank" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); gid('MF:chkReimb').focus() ;break;
			case "MF:txtReimBicCode" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); gid('MF:lstReimbBank').focus() ;break;
			case "MF:txtReimBicBank" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); gid('MF:txtReimBicCode').focus() ;break;
			case "MF:txtReimBicBrn" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); gid('MF:txtReimBicBank').focus() ;break;
			
			case "MF:txtReimAcnt" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); gid('MF:lstReimbBank').focus() ;break;
			case "MF:txtReimBankName" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); gid('MF:txtReimAcnt').focus() ;break;
			case "MF:txtReimAddress" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); gid('MF:txtReimBankName').focus() ;break;
			case "MF:txtReimCntry" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); focusTextArea('MF:txtReimAddress') ;break;
			case "MF:txtInstPay" 					:
													if(gid('MF:lstReimbBank').disabled == false )
   													 {
														if(trim(gid('MF:lstReimbBank').value) == "1" || trim(gid('MF:lstReimbBank').value) == "")
	   													 {
	   														setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); gid('MF:txtReimBicBrn').focus() ;break;
	   													 }
	   													 else
	   													 {
	   														setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); gid('MF:txtReimCntry').focus() ;break;
	   													 }
   													 }
   													 else
   													 {
   													 	setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); gid('MF:chkReimb').focus() ;break;
   													 }
			
	//----------------------------------9th tab ---7 th sub tab---------------------------------------------------------------------------------------------------------------------
		
			case "MF:chkAdvise" 					: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6"); focusTextArea('MF:txtInstPay') ;break;
			case "MF:lstAdviseBank" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent7"); gid('MF:chkAdvise').focus() ;break;
			case "MF:txtAdviseBicCode"				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent7"); gid('MF:lstAdviseBank').focus() ;break;
			case "MF:txtAdviseBicBank" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent7"); gid('MF:txtAdviseBicCode').focus() ;break;
			case "MF:txtAdviseBicBrn" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent7"); gid('MF:txtAdviseBicBank').focus() ;break;
			case "MF:txtAdviseAcnt" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent7"); gid('MF:lstAdviseBank').focus() ;break;
			case "MF:txtAdviseBankName" 			: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent7"); gid('MF:txtAdviseAcnt').focus() ;break;
			case "MF:txtAdviseAddress" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent7"); gid('MF:txtAdviseBankName').focus() ;break;
			case "MF:txtAdviseCntry" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent7"); focusTextArea('MF:txtAdviseAddress');break;
			case "MF:txtSendInfo" 					: 
													if(gid('MF:lstAdviseBank').disabled == false )
   													 {
														if(trim(gid('MF:lstAdviseBank').value) == "1" || trim(gid('MF:lstAdviseBank').value) == "")
	   													 {
	   														setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent7"); gid('MF:txtAdviseBicBrn').focus() ;break;
	   													 }
	   													 else
	   													 {
	   														setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent7"); gid('MF:txtAdviseCntry').focus() ;break;
	   													 }
	   												}
	   												else
	   												{
	   													setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent7"); gid('MF:chkAdvise').focus() ;break;
	   												}
       												
		 case "MF:txtrecbic" 				: setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent7"); focusTextArea('MF:txtSendInfo');break;
	//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			
			case "MF:Submit" 	    					:setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent7"); focusTextArea('MF:txtrecbic') ;break;
			
			case "MF:Cancel" 	    					:setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent7"); focusTextArea('MF:txtSendInfo') ;break;
			case "MF:Exit" 	    						:setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent7"); focusTextArea('MF:txtSendInfo') ;break;
		
			//CHANGED ADDED ON 27/05/2018 END
			
		}
	}			
//-----------------------------------------------------------------------------------------------------------------------------		  
	function SHOW_HELP(fldobj)
	{
		switch (fldobj.name)
		{
			case "MF:txtbrncode"		: 
									    	helpToken = "Hlpeolc1";
											fldArgs = gid('MF:txtbrncode').value ;
											showHelp(helpToken,fldobj,fldArgs);
											break;
				
			case "MF:txtconttype"		: 
									    	helpToken = "Hlpeolc2";
											fldArgs = gid('MF:txtconttype').value ;
											showHelp(helpToken,fldobj,fldArgs);
											break;
				
		   case "MF:txtcontsl"			: 
									    	helpToken = "Hlpeolc3";
											fldArgs = gid('MF:txtbrncode').value+"|"+gid('MF:txtconttype').value+"|"+gid('MF:txtcontyear').value;
											//Changes P.Subramani-Chn-18/02/2008
											showHelp(helpToken,fldobj,fldArgs,3);
											break;
				
		   case "MF:txtpresansl"		: 
									    	helpToken = "Hlpeolc4";
											fldArgs = gid('MF:txtbrncode').value+"|"+gid('MF:txtpresanDate').value;
											//Changes P.Subramani-Chn-18/02/2008
											showHelp(helpToken,fldobj,fldArgs,3);
											break;
				
		  case "MF:txtBeneficiaryCode"	: 
									    	helpToken = "Hlpeolc5";
											fldArgs = gid('MF:txtBeneficiaryCode').value;
											showHelp(helpToken,fldobj,fldArgs);
											break;
				
		 case "MF:txtCountryCode"		: 
									    	helpToken = "Hlpeolc6";
											fldArgs = gid('MF:txtCountryCode').value;
											showHelp(helpToken,fldobj,fldArgs);
											break;
				
		case "MF:txtLcIssuedthruBank"	: 
									    	helpToken = "Hlpeolc7";
											fldArgs = gid('MF:txtLcIssuedthruBank').value;
											showHelp(helpToken,fldobj,fldArgs);
											break;	
		
		case "MF:txtLcIssuedthruBranch"	: 
									    	helpToken = "Hlpeolc8";
											fldArgs = gid('MF:txtLcIssuedthruBank').value;
											showHelp(helpToken,fldobj,fldArgs);
											break;	
		
		case "MF:txtLcIssuedOncntry"	: 
									    	helpToken = "Hlpeolc6";
											fldArgs = gid('MF:txtLcIssuedOncntry').value;
											showHelp(helpToken,fldobj,fldArgs);
											break;							
				
		case "MF:txtLCCurr"				: 
									    	helpToken = "Hlpeolc9";
											fldArgs = gid('MF:txtLCCurr').value;
											showHelp(helpToken,fldobj,fldArgs);
											break;
				
		case "MF:txtTermsOfprice"		: 
									    	helpToken = "Hlpeolc10";
											fldArgs = gid('MF:txtTermsOfprice').value;
											showHelp(helpToken,fldobj,fldArgs);
											break;	
											
	    case "MF:txtmargincurr"			: 
									    	helpToken = "Hlpeolc9";
											fldArgs = gid('MF:txtmargincurr').value;
											showHelp(helpToken,fldobj,fldArgs);
											break;	
		
		//CHANGED ADDED ON 27/05/2018 START
											
		case "MF:txtAppBicCode" 		: 
									     	helpToken = "HlpswiftBicCode";
									     	fldArgs = gid('MF:txtAppBicCode').value ;
									     	registerAddInfo("TEXT");
											showHelp(helpToken,fldobj,fldArgs);
											break ; 									
									    	
		case "MF:txtAppBicBrn" 	: 
											helpToken = "Hlpeoutremswftbrn";
										    fldArgs = gid('MF:txtAppBicCode').value ;
											showHelp(helpToken,fldobj,fldArgs);
											break ; 
											
		case "MF:txtAvlBicCode" 		: 
									     	helpToken = "HlpswiftBicCode";
									     	fldArgs = gid('MF:txtAvlBicCode').value ;
									     	registerAddInfo("TEXT");
											showHelp(helpToken,fldobj,fldArgs);
											break ; 									
									    	
		case "MF:txtAvlBicBrn" 	: 
											helpToken = "Hlpeoutremswftbrn";
										    fldArgs = gid('MF:txtAvlBicCode').value ;
											showHelp(helpToken,fldobj,fldArgs);
											break ; 
											
											
		case "MF:txtDrwBicCode" 		: 
									     	helpToken = "HlpswiftBicCode";
									     	fldArgs = gid('MF:txtDrwBicCode').value ;
									     	registerAddInfo("TEXT");
											showHelp(helpToken,fldobj,fldArgs);
											break ; 									
									    	
		case "MF:txtDrwBicBrn" 	: 
											helpToken = "Hlpeoutremswftbrn";
										    fldArgs = gid('MF:txtDrwBicCode').value ;
											showHelp(helpToken,fldobj,fldArgs);
											break ; 
											
		case "MF:txtReimBicCode" 		: 
									     	helpToken = "HlpswiftBicCode";
									     	fldArgs = gid('MF:txtReimBicCode').value ;
									     	registerAddInfo("TEXT");
											showHelp(helpToken,fldobj,fldArgs);
											break ; 									
									    	
		case "MF:txtReimBicBrn" 	: 
											helpToken = "Hlpeoutremswftbrn";
										    fldArgs = gid('MF:txtReimBicCode').value ;
											showHelp(helpToken,fldobj,fldArgs);
											break ; 
		//Changes Sanjay1 22-07-2019 Begin
		case "MF:txtReimcfmBicCode" 		: 
									     	helpToken = "HlpswiftBicCode";
									     	fldArgs = gid('MF:txtReimcfmBicCode').value ;
									     	registerAddInfo("TEXT");
											showHelp(helpToken,fldobj,fldArgs);
											break ; 									
									    	
		case "MF:txtReimcfmBicBrn" 	: 
											helpToken = "Hlpeoutremswftbrn";
										    fldArgs = gid('MF:txtReimcfmBicCode').value ;
											showHelp(helpToken,fldobj,fldArgs);
											break ; 
		//Changes Sanjay1 22-07-2019 End							
		case "MF:txtAdviseBicCode" 		: 
									     	helpToken = "HlpswiftBicCode";
									     	fldArgs = gid('MF:txtAdviseBicCode').value ;
									     	registerAddInfo("TEXT");
											showHelp(helpToken,fldobj,fldArgs);
											break ; 									
									    	
		case "MF:txtAdviseBicBrn" 	: 
											helpToken = "Hlpeoutremswftbrn";
										    fldArgs = gid('MF:txtAdviseBicCode').value ;
											showHelp(helpToken,fldobj,fldArgs);
											break ; 
											
		case "MF:txtAppCntry" 	: 
										     	{
													helpToken = "Hlpeoutrem5";
										     	 	fldArgs = gid('MF:txtAppCntry').value ;
												 	showHelp(helpToken,fldobj,fldArgs);
													break ; 									
										    	}
										    	
		case "MF:txtAvlCntry" 	: 
										     	{
													helpToken = "Hlpeoutrem5";
										     	 	fldArgs = gid('MF:txtAvlCntry').value ;
												 	showHelp(helpToken,fldobj,fldArgs);
													break ; 									
										    	}
										    	
		case "MF:txtDrwCntry" 	: 
										     	{
													helpToken = "Hlpeoutrem5";
										     	 	fldArgs = gid('MF:txtDrwCntry').value ;
												 	showHelp(helpToken,fldobj,fldArgs);
													break ; 									
										    	}
										    	
		case "MF:txtReimCntry" 	: 
										     	{
													helpToken = "Hlpeoutrem5";
										     	 	fldArgs = gid('MF:txtReimCntry').value ;
												 	showHelp(helpToken,fldobj,fldArgs);
													break ; 									
										    	}
		
		//Changes Sanjay1 22-07-2019 Begin
		case "MF:txtcfmReimCntry" 	: 
										     	{
													helpToken = "Hlpeoutrem5";
										     	 	fldArgs = gid('MF:txtcfmReimCntry').value ;
												 	showHelp(helpToken,fldobj,fldArgs);
													break ; 									
										    	}										    	
										    	
		//Changes Sanjay1 22-07-2019 End								    	
		case "MF:txtAdviseCntry" 	: 
										     	{
													helpToken = "Hlpeoutrem5";
										     	 	fldArgs = gid('MF:txtAdviseCntry').value ;
												 	showHelp(helpToken,fldobj,fldArgs);
													break ; 									
										    	}
		case "MF:cmdcopylc" 	: 
										     	{
													helpToken = "HlpCopyOlc1";
										     	 	fldArgs = gid('MF:txtcustnum1').value;
										     	 	registerAddInfo("TEXT");
												 	showHelp(helpToken,fldobj,fldArgs);
												 	window.event.returnValue=false;	
													break ; 									
										    	}							    							    									    									    									    																																																
											
		//CHANGED ADDED ON 27/05/2018 END  
		
		
		//ADDED BY PRASHANTH ON 29 JANUARY 2018
		//Changes Sanjay1 22-07-2019 Begin
		/*case "MF:txtConfirmedByBank" 	: 
			          									{
			          										 helpToken = "Hlpeolcconditions5";
										        			 fldArgs =gid('MF:txtConfirmedByBank').value;
															 showHelp(helpToken,fldobj,fldArgs);
			          									}break;	
		 case "MF:txtConfirmedBYBranch" 	: 
			          									{
			          										 helpToken = "Hlpeolcconditions6";
										        			 fldArgs =gid('MF:txtConfirmedByBank').value;
															 showHelp(helpToken,fldobj,fldArgs);
			          									}break;	*/
		//Changes Sanjay1 22-07-2019 End
		//ADDED BY PRASHANTH ON 29 JANUARY 2018
			          									
			          									
			          									
											
		}
	}
	
//CHANGED ADDED ON 27/05/2018 START

function getAdddetails(addinfo)
	{	
		if(trim(addinfo)!= "")
		{
			strhelp =addinfo.split("|");
		    switch(lastEntdFld.name) 
	   		{
				case "MF:txtAppBicCode":
		   		{
		   			clearAppBic();
		   			gid('MF:txtAppBicCode').value=strhelp[0];
		   			gid('MF:txtAppBicBrn').value=strhelp[1];
		   		}
		   		break;
		   		
		   		case "MF:txtAvlBicCode":
		   		{
		   			clearAVLAddr();
		   			gid('MF:txtAvlBicCode').value=strhelp[0];
		   			gid('MF:txtAvlBicBrn').value=strhelp[1];
		   		}
		   		break;
		   		
		   		case "MF:txtDrwBicCode":
		   		{
		   			clearDraweeBic();
		   			gid('MF:txtDrwBicCode').value=strhelp[0];
		   			gid('MF:txtDrwBicBrn').value=strhelp[1];
		   		}
		   		break;
		   		
		   		case "MF:txtAdviseBicCode":
		   		{
		   			
					clearAdvThrBic();
		   			gid('MF:txtAdviseBicCode').value=strhelp[0];
		   			gid('MF:txtAdviseBicBrn').value=strhelp[1];
		   		}
		   		break;
		   		
		   		case "MF:txtReimBicCode":
		   		{
		   			clearReimbBic();
		   			gid('MF:txtReimBicCode').value=strhelp[0];
		   			gid('MF:txtReimBicBrn').value=strhelp[1];
		   		}
		   		break;
		   		//Changes Sanjay1 22-07-2019 Begin
		   		case "MF:txtReimcfmBicCode":
		   		{
		   			clearReimbCfmBic();
		   			gid('MF:txtReimcfmBicCode').value=strhelp[0];
		   			gid('MF:txtReimcfmBicBrn').value=strhelp[1];
		   		}
		   		break;
		   		//Changes Sanjay1 22-07-2019 End
		   		case "MF:cmdcopylc":
		   		{
		   			copy_client_id=strhelp[0];
		   			copy_brn_code=strhelp[1];
		   			copy_year=strhelp[2];
		   			copy_sl=strhelp[3];
		   			copy_date=strhelp[4];		   			
		   			copy_benf_code=strhelp[5];
		   			copy_benf_name=strhelp[6];
		   			_copy ="C";
					FetchlcDetails();	   				   			
		   		}
		   		break;
		   	}
		} 	
		   	
	}
	
//CHANGED ADDED ON 27/05/2018 END
	
//-----------------------------------------------------------------------------------------------------------------------------			
	function keyPressEvents(fldobj)	
	{
		if (fldobj.name =="MF:txtAddress1")
		{
			validateTextArea("MF:txtAddress1",5,35,"validateBenefAddress()");
			return;
		}
    	if (fldobj.name =="MF:txtAdditionalamtcover")
		{
			validateTextArea("MF:txtAdditionalamtcover",4,35,"validateAddiAmtCovered()");
			return;
		}
		if (fldobj.name =="MF:txtShipmentperod")
		{
			validateTextArea("MF:txtShipmentperod",4,35,"validateShipmentSchedule()");
			return;
		}
		if (fldobj.name =="MF:txtpresentationdetails")
		{
			validateTextArea("MF:txtpresentationdetails",3,35,"validatePresentationDetails()");
			return;
		}		
		if (fldobj.name =="MF:txtAddress21")
		{
			validateTextArea("MF:txtAddress21",5,35,"validateBranchAdd()");
			return;
		}
		//CHANGED ADDED ON 27/05/2018 START
		
		if (fldobj.name =="MF:txtAppAddress")
		{
			validateTextArea("MF:txtAppAddress",3,35,"validateAppAddr()");
			return;
		}
		if (fldobj.name =="MF:txtAvlAddress")
		{
			validateTextArea("MF:txtAvlAddress",3,35,"validateAvlAddr()");
			return;
		}
		if (fldobj.name =="MF:txtDrwAddress")
		{
			validateTextArea("MF:txtDrwAddress",3,35,"validateDraweeAddr()");
			return;
		}
		if (fldobj.name =="MF:txtReimAddress")
		{
			validateTextArea("MF:txtReimAddress",3,35,"validateReimbAddr()");
			return;
		}
		if (fldobj.name =="MF:txtAdviseAddress")
		{
			validateTextArea("MF:txtAdviseAddress",3,35,"validateAdvAddr()");
			return;
		}
		//Changes Sanjay1 22-07-2019 Begin
		if (fldobj.name =="MF:txtcfmReimAddress")
		{
			validateTextArea("MF:txtcfmReimAddress",3,35,"validateReimbcfmAddr()");
			return;
		}
		//Changes Sanjay1 22-07-2019 End
		if (fldobj.name =="MF:txtDraft")
		{
			validateTextArea("MF:txtDraft",3,35,"validateDraft()");
			return;
		}
		if (fldobj.name =="MF:txtMixedPaydtl")
		{
			validateTextArea("MF:txtMixedPaydtl",4,35,"validateMixedPay()");
			return;
		}
		if (fldobj.name =="MF:txtDeferPaydtl")
		{
			validateTextArea("MF:txtDeferPaydtl",4,35,"validateDeferPay()");
			return;
		}
		if (fldobj.name =="MF:txtTakCharge")
		{
			validateTextArea("MF:txtTakCharge",1,65,"validateTakCharge()");
			return;
		}
		if (fldobj.name =="MF:txtPortLoad")
		{
			validateTextArea("MF:txtPortLoad",1,65,"validatePortLoad()");
			return;
		}
		if (fldobj.name =="MF:txtPortDis")
		{
			validateTextArea("MF:txtPortDis",1,65,"validatePortDis()");
			return;
		}
		if (fldobj.name =="MF:txtPortDest")
		{
			validateTextArea("MF:txtPortDest",1,65,"validatePortDest()");
			return;
		}
		
		if (fldobj.name =="MF:txtShipPeriod")
		{
			validateTextArea("MF:txtShipPeriod",6,65,"validateShipPeriod()");
			return;
		}
		
		if (fldobj.name =="MF:txtDesGood1")
		{
			validateTextArea("MF:txtDesGood1",100,65,"validateDesGood1()");
			return;
		}
		if (fldobj.name =="MF:txtDesGood2")
		{
			validateTextArea("MF:txtDesGood2",100,65,"validateDesGood2()");
			return;
		}
		if (fldobj.name =="MF:txtDesGood3")
		{
			validateTextArea("MF:txtDesGood3",100,65,"validateDesGood3()");
			return;
		}
		
		if (fldobj.name =="MF:txtDocRequired1")
		{
			validateTextArea("MF:txtDocRequired1",100,65,"validateDocRequired1()");
			return;
		}
		if (fldobj.name =="MF:txtDocRequired2")
		{
			validateTextArea("MF:txtDocRequired2",100,65,"validateDocRequired2()");
			return;
		}
		if (fldobj.name =="MF:txtDocRequired3")
		{
			validateTextArea("MF:txtDocRequired3",100,65,"validateDocRequired3()");
			return;
		}
		
		if (fldobj.name =="MF:txtAddCond1")
		{
			validateTextArea("MF:txtAddCond1",100,65,"validateAddCond1()");
			return;
		}
		if (fldobj.name =="MF:txtAddCond2")
		{
			validateTextArea("MF:txtAddCond2",100,65,"validateAddCond2()");
			return;
		}
		if (fldobj.name =="MF:txtAddCond3")
		{
			validateTextArea("MF:txtAddCond3",100,65,"validateAddCond3()");
			return;
		}
		if (fldobj.name =="MF:txtCharge")
		{
			validateTextArea("MF:txtCharge",6,35,"validateCharges()");
			return;
		}
		if (fldobj.name =="MF:txtInstPay")
		{
			validateTextArea("MF:txtInstPay",12,65,"validateInstructPay()");
			return;
		}
		if (fldobj.name =="MF:txtSendInfo")
		{
			validateTextArea("MF:txtSendInfo",6,35,"validateSendInfo()");
			return;
		}
		//CHANGED ADDED ON 27/05/2018 END
			
		if (window.event.keyCode == KEY_TAB || isEnterKeyPressed())
 		{
        	setMsg("");
	  		switch (fldobj.name)
			{
				case "MF:seluseroption"				:	validateoption();break;
				case "MF:txtbrncode"				:	validateBranchCode();break;
				case "MF:txtconttype"				:	validateConType();break;
				case "MF:txtcontyear"				:	validateConYear();break;
				case "MF:txtcontsl"					:	validateConSNo();break;
				case "MF:txtpresanDate"				:	validatePresanctonDate();break;
				case "MF:txtpresansl"				:	validatePresanctonDaySl();break;
				case "MF:txtLCDate"					:	validateLCDate();break;
				case "MF:txtBeneficiaryCode"		:	validateBenefCode();break;
				case "MF:txtBeneficiaryName"		:	validateBenefName();break;
				case "MF:txtAddress1"				:	validateBenefAddress();break;
				case "MF:txtCountryCode"			:	validateBenefCntryCode();break;
				case "MF:txtLcIssuedthruBank"		:	validateIssuedthruBank();break;
				case "MF:txtLcIssuedthruBranch"		:	validateIssuedthruBranch();break;
				case "MF:txtLcIssuedBranchName"		:	validateBranchName();break;
				case "MF:txtAddress21"				:	validateBranchAdd();break;	
				case "MF:txtLcIssuedOnplace"		:	validateIssuedOnplace();break;		
	   			case "MF:txtLcIssuedOncntry"		:	validateIssuedOncnty();break;	
	   			case "MF:lstAdThru"					:	validateLcAdvThru();break;
	   			
	   			
	   			case "MF:txtLCCurr"					:	validateLCCurr();break;					   			
	   			case "MF:txtLCAmt"					:	validateLCAmt();break;
	   			case "MF:chkdeviationallowed"		:	validateDeviationAllow();break;
	   			case "MF:txtdeviationallow"			:	validatePostiveDevi();break;
	   			case "MF:txtdeviationallow1"		:	validateNegaTiveDevi();break;
	   			case "MF:txtDeviationAmt"			:	validateDeviAmt();break;
	   			case "MF:lstAmtquali"				:	validateAmtQualifier();break;
	   			case "MF:txtAdditionalamtcover"		:	validateAddiAmtCovered();break;
	   			case "MF:txtTermsOfprice"			:	validateTermsOfPrice();break;
	   			
	   			case "MF:txtLastDateOfNego"			:	validateLastdateofNego();break;
	   			case "MF:txtplaceOfexpy"			:	validatePlaceOfExp();break;
	   			case "MF:txtLatestDateOfNego"		:	validateLatestdateOfShip();break;
	   			case "MF:txtShipmentperod"			:	validateShipmentSchedule();break;
	   			case "MF:txtperiod"					:	validatePeriod();break;
	   			//case "MF:txtpresentationdetails"	:	validatePresentationDetails();break;
	   			case "MF:chkWithInValOfLC"			:	validatechkWithInValOfLC();break;
	   			
	   			case "MF:chkUsanceInterest"			:	validateUsanceIntRate();break;
	   			case "MF:txtDrawDowns"				:	validateDrawDowns();break;
	   			case "MF:chkLcunderCon"				:	validateLCUnderContract();break;
	   			
	   			case "MF:txtConRateToLimitCurr"		:	validateConvRatetoLmtCurr();break;
	   			
	   			case "MF:txtmargincurr"				:	validateMarginCurrency();break;
	   			case "MF:txtmarginpercentage"		:	validateMarginPerc();break;
	   			case "MF:txtmarginpercentage1"		:	validateEOLMarginPerc();break;
	   			case "MF:txtmarginamt1"				:	validateMarginAmt();break;
	   			case "MF:txtmarginamt2"				:	validateEOLMarginAmt();break;
	   			case "MF:txtcashmarginamt1"			:	validateCashMargin();break;
	   			case "MF:txtcashmarginamt2"			:	validateEOLCashMargin();break;
	   			case "MF:lstmargintypeforLC"		:	validateMarginType();break;
	   			
	   			//Changes P.Subramani-Chn-10/04/2008 Beg
	   			case "MF:txtusnchgsamt1"			:	validateusnchgs();break;
	   			case "MF:txtcommchgsamt1"			:	validatecommchgs();break;
	   			//Changes P.Subramani-Chn-10/04/2008 End
	   			
	   			case "MF:lstcredit"					: 	validateDocCredit();break; 
	   			case "MF:txtRefPreAdv"				:	validateRefPreAdvice();break;
	   			case "MF:lstAppRule"				:	validateAppRule();break;
	   			case "MF:chkAppBank"				:	validateCheckAppBank();break;
	   			case "MF:chkAdvise"					:	validatecheckAdvise();break;
	   			case "MF:chkDrawee"					:	validatecheckDrawee();break;
	   			case "MF:chkReimb"					:	validatecheckReimb();break;
	   			case "MF:lstAppBank"				:	validatelistAppBank();break;
	   			case "MF:lstAvl"					:	validatelistAvl();break;
	   			case "MF:lstBICdtl"					:	validatelstBicdtl(gid('MF:lstBICdtl').value,"1");break;
	   			case "MF:lstAvlBICdtl"				:	validatelstBicdtl(gid('MF:lstAvlBICdtl').value,"2");break;
				case "MF:lstDrwBICdtl"				:	validatelstBicdtl(gid('MF:lstDrwBICdtl').value,"3");break;
				case "MF:lstReimbBank"				:	validatelstBicdtl(gid('MF:lstReimbBank').value,"4");break;
				case "MF:lstAdviseBank"				:	validatelstBicdtl(gid('MF:lstAdviseBank').value,"5");break;
	   			case "MF:lstReimbcfmBank"			:	validatelstBicdtl(gid('MF:lstReimbcfmBank').value,"6");break;	
	   			
	   			case "MF:txtAppBicCode"				:   validateBicCode(gid('MF:chkAppBank').checked,gid('MF:lstBICdtl').value,gid('MF:txtAppBicCode').value,"1");break;
	   			case "MF:txtAvlBicCode"				:	validateBicCode(true,gid('MF:lstAvlBICdtl').value,gid('MF:txtAvlBicCode').value,"2");break;
	   			case "MF:txtDrwBicCode"				:	validateBicCode(gid('MF:chkDrawee').checked,gid('MF:lstDrwBICdtl').value,gid('MF:txtDrwBicCode').value,"3");break;
	   			case "MF:txtReimBicCode"			:	validateBicCode(gid('MF:chkReimb').checked,gid('MF:lstReimbBank').value,gid('MF:txtReimBicCode').value,"4");break;
	   			case "MF:txtAdviseBicCode"			:	validateBicCode(gid('MF:chkAdvise').checked,gid('MF:lstAdviseBank').value,gid('MF:txtAdviseBicCode').value,"5");break;
	   			case "MF:txtReimcfmBicCode"			:	validateBicCode(true,gid('MF:lstReimbcfmBank').value,gid('MF:txtReimcfmBicCode').value,"6");break;
	   			
	   			case "MF:txtAppBicBrn"				:   validateBrnCode(gid('MF:chkAppBank').checked,gid('MF:lstBICdtl').value,gid('MF:txtAppBicBrn').value,"1");break;
	   			case "MF:txtAvlBicBrn"				:	validateBrnCode(true,gid('MF:lstAvlBICdtl').value,gid('MF:txtAvlBicBrn').value,"2");break;
	   			case "MF:txtDrwBicBrn"				:	validateBrnCode(gid('MF:chkDrawee').checked,gid('MF:lstDrwBICdtl').value,gid('MF:txtDrwBicBrn').value,"3");break;
	   			case "MF:txtReimBicBrn"				:	validateBrnCode(gid('MF:chkReimb').checked,gid('MF:lstReimbBank').value,gid('MF:txtReimBicBrn').value,"4");break;
	   			case "MF:txtAdviseBicBrn"			:	validateBrnCode(gid('MF:chkAdvise').checked,gid('MF:lstAdviseBank').value,gid('MF:txtAdviseBicBrn').value,"5");break;
	   			case "MF:txtReimcfmBicBrn"			:	validateBrnCode(true,gid('MF:lstReimbcfmBank').value,gid('MF:txtReimcfmBicBrn').value,"6");break;
	   			
	   			case "MF:txtAppBankName"			:   validateBankName(gid('MF:chkAppBank').checked,gid('MF:lstBICdtl').value,gid('MF:txtAppBankName').value,"1");break;
	   			case "MF:txtAvlBankName"			:	validateBankName(true,gid('MF:lstAvlBICdtl').value,gid('MF:txtAvlBankName').value,"2");break;
	   			case "MF:txtDrwBankName"			:	validateBankName(gid('MF:chkDrawee').checked,gid('MF:lstDrwBICdtl').value,gid('MF:txtDrwBankName').value,"3");break;
	   			case "MF:txtReimBankName"			:	validateBankName(gid('MF:chkReimb').checked,gid('MF:lstReimbBank').value,gid('MF:txtReimBankName').value,"4");break;
	   			case "MF:txtAdviseBankName"			:	validateBankName(gid('MF:chkAdvise').checked,gid('MF:lstAdviseBank').value,gid('MF:txtAdviseBankName').value,"5");break;
	   			case "MF:txtcfmReimBankName"		:	validateBankName(true,gid('MF:lstReimbcfmBank').value,gid('MF:txtcfmReimBankName').value,"6");break;
	   			
	   			case "MF:txtAppCntry"			:   validateBankCntry(gid('MF:chkAppBank').checked,gid('MF:lstBICdtl').value,gid('MF:txtAppCntry').value,"1");break;
	   			case "MF:txtAvlCntry"			:	validateBankCntry(true,gid('MF:lstAvlBICdtl').value,gid('MF:txtAvlCntry').value,"2");break;
	   			case "MF:txtDrwCntry"			:	validateBankCntry(gid('MF:chkDrawee').checked,gid('MF:lstDrwBICdtl').value,gid('MF:txtDrwCntry').value,"3");break;
	   			case "MF:txtReimCntry"			:	validateBankCntry(gid('MF:chkReimb').checked,gid('MF:lstReimbBank').value,gid('MF:txtReimCntry').value,"4");break;
	   			case "MF:txtAdviseCntry"		:	validateBankCntry(gid('MF:chkAdvise').checked,gid('MF:lstAdviseBank').value,gid('MF:txtAdviseCntry').value,"5");break;
	   			case "MF:txtcfmReimCntry"		:	validateBankCntry(true,gid('MF:lstReimbcfmBank').value,gid('MF:txtcfmReimCntry').value,"6");break;
	   			
	   			case "MF:txtAppAcnt"			:   validateBankRout(gid('MF:chkAppBank').checked,gid('MF:lstBICdtl').value,gid('MF:txtAppAcnt').value,"1");break;
	   			case "MF:txtAvlAcnt"			:	validateBankRout(true,gid('MF:lstAvlBICdtl').value,gid('MF:txtAvlAcnt').value,"2");break;
	   			case "MF:txtDrwAcnt"			:	validateBankRout(gid('MF:chkDrawee').checked,gid('MF:lstDrwBICdtl').value,gid('MF:txtDrwAcnt').value,"3");break;
	   			case "MF:txtReimAcnt"			:	validateBankRout(gid('MF:chkReimb').checked,gid('MF:lstReimbBank').value,gid('MF:txtReimAcnt').value,"4");break;
	   			case "MF:txtAdviseAcnt"			:	validateBankRout(gid('MF:chkAdvise').checked,gid('MF:lstAdviseBank').value,gid('MF:txtAdviseAcnt').value,"5");break;
	   			case "MF:txtcfmReimAcnt"		:	validateBankRout(true,gid('MF:lstReimbcfmBank').value,gid('MF:txtcfmReimAcnt').value,"6");break;
	   			
	   			case "MF:lstparShip"			:	validateparShip();break;
	   			case "MF:lsttranShip"			:	validatetranShip();break;
	   			case "MF:lstConfInst"			:	validateConfInst();break;
	   			
	  			//ADDED BY PRASHANTH ON 29 JANUARY 2018
	   			//Changes Sanjay1 22-07-2019 Begin
	   			/*case "MF:txtConfirmedByBank"			:			validateConfirmedByBank();break;	
		   		case "MF:txtConfirmedBYBranch"		:			validateConfirmedByBranch();break;
		   		case "MF:txtConfirmedBYBranchname"	:			validateConfirmedByBranchName();break;*/
		   		//Changes Sanjay1 22-07-2019 End	
	   			//ADDED BY PRASHANTH ON 29 JANUARY 2018
	   			
	   			
	   			case "MF:txtrecbic"				:	validaterecbic();break;
	   			
	   			
   			}
   		}
   		else if(fldobj.name=="MF:txtpresanDate")
		{
			seperatorappend(fldobj);
		}
		else if(fldobj.name=="MF:txtLCDate")
		{
			seperatorappend(fldobj);
		}
		else if(fldobj.name=="MF:txtLastDateOfNego")
		{
			seperatorappend(fldobj);
		}
		else if(fldobj.name=="MF:txtLatestDateOfNego")
		{
			seperatorappend(fldobj);
		}															
   		else if((fldobj.name=="MF:txtconttype"))
		{
			To_Uppercase(window.event.keyCode);
		}
		else if((fldobj.name=="MF:txtmargincurr"))
		{
			To_Uppercase(window.event.keyCode);
		}
		else if((fldobj.name=="MF:txtCountryCode"))
		{
			To_Uppercase(window.event.keyCode);
		}	
		else if((fldobj.name=="MF:txtLcIssuedthruBank"))
		{
			To_Uppercase(window.event.keyCode);
		}
		else if((fldobj.name=="MF:txtLcIssuedthruBranch"))
		{
			To_Uppercase(window.event.keyCode);
		}
		else if((fldobj.name=="MF:txtLcIssuedOncntry"))
		{
			To_Uppercase(window.event.keyCode);
		}	
		else if(fldobj.name =="MF:txtLCCurr") 
		{
			To_Uppercase(window.event.keyCode);
		}
		else if((fldobj.name=="MF:txtTermsOfprice"))
		{
			To_Uppercase(window.event.keyCode);
		}
		else if (fldobj.name == "MF:txtDrawDowns")
		{
			if(isNumeric(window.event.keyCode) == false)
			{
				setMsg(NUMBER_ALLOWED);
			}
		}
		else if (fldobj.name == "MF:txtcontyear")
		{
			if(isNumeric(window.event.keyCode) == false)
			{
				setMsg(NUMBER_ALLOWED);
			}
		}	
		else if (fldobj.name == "MF:txtcontsl")
		{
			if(isNumeric(window.event.keyCode) == false)
			{
				setMsg(NUMBER_ALLOWED);
			}
		}		
		else if (fldobj.name == "MF:txtpresansl" || fldobj.name == "MF:txtperiod") //CHANGED ADDED ON 27/05/2018
		{
			if(isNumeric(window.event.keyCode) == false)
			{
				setMsg(NUMBER_ALLOWED);
			}
		}
		
		//CHANGED ADDED ON 27/05/2018 START
		
		else if(fldobj.name =="MF:txtAppBankName" || fldobj.name =="MF:txtAppAddress" || fldobj.name =="MF:txtAppCntry" || fldobj.name =="MF:txtAvlBankName" ||  fldobj.name =="MF:txtAvlAddress" || fldobj.name =="MF:txtAvlCntry" ||fldobj.name =="MF:txtDrwBankName" ) 
		{
			To_Uppercase(window.event.keyCode,"true");
		}
		else if(fldobj.name =="MF:txtDrwAddress" || fldobj.name =="MF:txtDrwCntry" || fldobj.name =="MF:txtReimBankName" || fldobj.name =="F:txtReimAddress" ||  fldobj.name =="MF:txtReimCntry" || fldobj.name =="MF:txtAdviseBankName" ||fldobj.name =="MF:txtAdviseAddress" || fldobj.name =="MF:txtAdviseCntry" || fldobj.name =="MF:txtcfmReimBankName" || fldobj.name =="MF:txtcfmReimAddress" || fldobj.name =="MF:txtcfmReimCntry" ) 
		{
			To_Uppercase(window.event.keyCode,"true");
		}
		
		//CHANGED ADDED ON 27/05/2018 END
	}

//CHANGED ADDED ON 27/05/2018 START
//-----------------------------------------------------------------------------------------------------------------------------
function selectItemEvents(fldobj)
	       {
	       switch(fldobj.name){
	       
	     case "MF:lstAvl" : 
				      if(gid('MF:lstAvl').value=="2")
				       {
					     gid('MF:txtMixedPaydtl').readOnly=true;
						 gid('MF:txtMixedPaydtl').value ="";
						 gid('MF:txtDeferPaydtl').readOnly=false;
				       }
				       else if(gid('MF:lstAvl').value=="3")
				       {
				       	gid('MF:txtDeferPaydtl').readOnly=true;
						gid('MF:txtDeferPaydtl').value ="";
						gid('MF:txtMixedPaydtl').readOnly=false;
				       }
				       else
				       {
				       	gid('MF:txtMixedPaydtl').readOnly=true;
						gid('MF:txtMixedPaydtl').value ="";
						gid('MF:txtDeferPaydtl').value ="";
						gid('MF:txtDeferPaydtl').readOnly=true;
				       }	
				        break;
				        
		case "MF:lstAppBank" :
							  if(gid('MF:lstAppBank').value=="" || gid('MF:lstAppBank').value=="1" )
				       			{
					       			clearAppBic();
									clearAppAddr();
									gid('MF:lstBICdtl').value ="";
					       			appBank();
				       			
				       			}
				       			else if(gid('MF:lstAppBank').value=="2")
				       			{
					       			clearAppBic();
									clearAppAddr();
									gid('MF:lstBICdtl').value ="";
					       			appBankenable();
				       			
				       			}
				       			
										        
		case "MF:lstBICdtl"	:
							appBiclist();
						break;
						
		case "MF:lstAvlBICdtl" :
								avlBicList();
							break;
		
		case "MF:lstDrwBICdtl" :
								draweeBicList();
							break;
							
		case "MF:lstReimbBank" :
								reimbBiclist();
							break;
							
		case "MF:lstAdviseBank" :
								AvlThrBiclist();
							break;	
		//Changes Sanjay1 22-07-2019 Begin							
		case "MF:lstReimbcfmBank" :
								reimbcfmBiclist();
							break;
		//Changes Sanjay1 22-07-2019 End							
	}
}
		
function validateDocCredit()
{
	setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1");
	if(gid('MF:lstcredit').value == "")
   	 	{
   	 		setMsg(OPTION_MESSAGE);
    		gid('MF:lstcredit').focus();
   	 	}
   	 	else
   	 	{	
   	 		gid('MF:txtRefPreAdv').focus();
   	 	}
}	

function validateRefPreAdvice()
{
	setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1");
	if(gid('MF:txtRefPreAdv').value == "")
   	 	{
   	 		gid('MF:lstAppRule').focus();
   	 	}
   	 	else
   	 	{	
   	 		var _refPreAdv = gid('MF:txtRefPreAdv').value;
   	 		if(_refPreAdv.length > 16 )
   	 		{
   	 			setMsg("Reference to Pre-Advice(F23) Should be of maximum length 16");
   	 			gid('MF:txtRefPreAdv').focus(); 
   	 		}
   	 		else
   	 		{
   	 			gid('MF:lstAppRule').focus();
   	 		}
   	 	}
}

function validateAppRule()
{
	setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1");
	if(gid('MF:lstAppRule').value == "")
   	 	{
   	 		setMsg(OPTION_MESSAGE);
    		gid('MF:lstAppRule').focus();
   	 	}
   	 	else
   	 	{	
   	 		gid('MF:chkAppBank').focus();
   	 	}
}

function appBank()
	{
			gid('MF:lstBICdtl').disabled=true;
			gid('MF:txtAppBicCode').readOnly=true;
			gid('MF:txtAppBicBank').readOnly=true;
			gid('MF:txtAppBicBrn').readOnly=true;
			gid('MF:txtAppBankName').readOnly=true;
			gid('MF:txtAppAcnt').readOnly=true;
			gid('MF:txtAppAddress').readOnly=true;
			gid('MF:txtAppCntry').readOnly=true;
	}

function appBankenable()
{
	gid('MF:lstBICdtl').disabled=false;
	gid('MF:txtAppBicCode').readOnly=false;
	gid('MF:txtAppBicBank').readOnly=false;
	gid('MF:txtAppBicBrn').readOnly=false;
	gid('MF:txtAppBankName').readOnly=false;
	gid('MF:txtAppAcnt').readOnly=false;
	gid('MF:txtAppAddress').readOnly=false;
	gid('MF:txtAppCntry').readOnly=false;
}

	

function checkAppBank()
{
	//setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1");
	if(gid('MF:chkAppBank').checked==true)
		{
			gid('MF:outlblAppBank').innerText="Yes";
			//gid('MF:lstAppBank').value ="";
			//gid('MF:lstBICdtl').value ="";
			gid('MF:lstAppBank').disabled=false;
			//gid('MF:lstBICdtl').disabled=false;
			/*gid('MF:txtAppBicCode').readOnly=false;
			gid('MF:txtAppBicBank').readOnly=false;
			gid('MF:txtAppBicBrn').readOnly=false;
			gid('MF:txtAppBankName').readOnly=false;
			gid('MF:txtAppAcnt').readOnly=false;
			gid('MF:txtAppAddress').readOnly=false;
			gid('MF:txtAppCntry').readOnly=false;*/
		}
		else
		{
			gid('MF:outlblAppBank').innerText="No";
			gid('MF:lstAppBank').value ="";
			gid('MF:lstBICdtl').value="";
			gid('MF:lstAppBank').disabled=true;
			/*gid('MF:lstBICdtl').disabled=true;
			gid('MF:txtAppBicCode').readOnly=true;
			gid('MF:txtAppBicBank').readOnly=true;
			gid('MF:txtAppBicBrn').readOnly=true;
			gid('MF:txtAppBankName').readOnly=true;
			gid('MF:txtAppAcnt').readOnly=true;
			gid('MF:txtAppAddress').readOnly=true;
			gid('MF:txtAppCntry').readOnly=true;*/
		}
		
		if(gid('MF:seluseroption').value=="A")//CHANGED ADDED ON 11/10/2018
			{
			clearAppBic();
			clearAppAddr();
			}
		
}

function validateCheckAppBank()
{
	checkAppBank();
	
	if(gid('MF:chkAppBank').checked==true)
		{
			setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1");
			gid('MF:lstAppBank').focus();
		}
		else
		{
			setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent10");
			gid('MF:lstAvl').focus();
		}

}
function validateDraft()
{
	setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2");
	gid('MF:chkDrawee').focus();
}

function checkDrawee()
{
	//setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2");
	if(gid('MF:chkDrawee').checked==true)
		{
			gid('MF:outlblDrawee').innerText="Yes";
			//gid('MF:lstDrwBICdtl').value ="";
			gid('MF:lstDrwBICdtl').disabled=false;
			//gid('MF:lstBICdtl').disabled=false;
			gid('MF:txtDrwBicCode').readOnly=false;
			gid('MF:txtDrwBicBank').readOnly=false;
			gid('MF:txtDrwBicBrn').readOnly=false;
			gid('MF:txtDrwBankName').readOnly=false;
			gid('MF:txtDrwAcnt').readOnly=false;
			gid('MF:txtDrwAddress').readOnly=false;
			gid('MF:txtDrwCntry').readOnly=false;
		}
		else
		{
			gid('MF:outlblDrawee').innerText="No";
			gid('MF:lstDrwBICdtl').value ="";
			gid('MF:lstDrwBICdtl').disabled=true;
			//gid('MF:lstBICdtl').disabled=true;
			gid('MF:txtDrwBicCode').readOnly=true;
			gid('MF:txtDrwBicBank').readOnly=true;
			gid('MF:txtDrwBicBrn').readOnly=true;
			gid('MF:txtDrwBankName').readOnly=true;
			gid('MF:txtDrwAcnt').readOnly=true;
			gid('MF:txtDrwAddress').readOnly=true;
			gid('MF:txtDrwCntry').readOnly=true;
		}
		if(gid('MF:seluseroption').value=="A")//CHANGED ADDED ON 11/10/2018
			{
		clearDraweeBic();
		clearDraweeAddr();
		}
}

function validatecheckDrawee()
{
	checkDrawee();
	if(gid('MF:chkDrawee').checked==true)
		{
			setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2");
			gid('MF:lstDrwBICdtl').focus();
		}
		else
		{
			if(gid('MF:txtMixedPaydtl').readOnly==false)
			{
				setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2");
				gid('MF:txtMixedPaydtl').focus();
			}
			else if(gid('MF:txtDeferPaydtl').readOnly==false)
			{
				setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2");
				gid('MF:txtDeferPaydtl').focus();
			}
			else
			{
				setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2");
				gid('MF:lstparShip').focus();
			}
		}

}

function validateMixedPay()
{
	if(gid('MF:txtMixedPaydtl').value == "")
	{
	 	setMsg(BLANK_CHECK);
	 	gid('MF:txtMixedPaydtl').focus();
	 	return;
	}
	else
	{
		setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2");
		gid('MF:lstparShip').focus();
	}
}

function validateDeferPay()
{
	if(gid('MF:txtDeferPaydtl').value == "")
	{
		setMsg(BLANK_CHECK);
		gid('MF:txtDeferPaydtl').focus();
		return;
	}
	else
	{
		setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2");
		gid('MF:lstparShip').focus();
	}
}

function validateparShip()
{
	setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2");
	gid('MF:lsttranShip').focus();
}

function validatetranShip()
{
	setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2");
	focusTextArea('MF:txtTakCharge') ;
}

function validateTakCharge()
{
	setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2");
	focusTextArea('MF:txtPortLoad') ; 
}
function validatePortLoad()
{
	setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent3");
	focusTextArea('MF:txtPortDis') ;
}
function validatePortDis()
{
	setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent3");
	focusTextArea('MF:txtPortDest') ;
}
function validatePortDest()
{
	setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent3");
	focusTextArea('MF:txtShipPeriod') ;
}
function validateShipPeriod()
{
	setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent3");
	focusTextArea('MF:txtDesGood1') ;
}

function validateDesGood1()
{
	var _desgoodcount1 = gid('MF:txtDesGood1').value;
	var splitResults1 = _desgoodcount1.split("\n").length;
	
	
	if(_desgoodcount1.length == 6500 ||  splitResults1 == 100 )
	{
		gid('MF:txtDesGood2').readOnly = false;
		gid('MF:txtDesGood3').readOnly = true;
		gid('MF:txtDesGood3').value = "";
		setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent3");
		focusTextArea('MF:txtDesGood2') ;
	}
	else if(_desgoodcount1.length < 6500 && splitResults1 < 100)
	{
		gid('MF:txtDesGood2').readOnly = true;
		gid('MF:txtDesGood3').readOnly = true;
		gid('MF:txtDesGood2').value = "";
		gid('MF:txtDesGood3').value = "";
		setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent4");
		focusTextArea('MF:txtDocRequired1') ;
	}
	else if(_desgoodcount1.length > 6500 ||  splitResults1 > 100 )
	{
		setMsg("The Line entered exceeded 6500 character typed " + _desgoodcount1.length + " lines" + splitResults1 );
		gid('MF:txtDesGood1').focus();
		return false;
	}
	
}
function validateDesGood2()
{
	var _desgoodcount2 = gid('MF:txtDesGood2').value;
	var splitResults2 = _desgoodcount2.split("\n").length;
	
	if(_desgoodcount2.length == 6500 ||  splitResults2 == 100)
	{
		gid('MF:txtDesGood3').readOnly = false;
		setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent3");
		focusTextArea('MF:txtDesGood3') ;
	}
	else if(_desgoodcount2.length < 6500 && splitResults2 < 100)
	{
		gid('MF:txtDesGood3').readOnly = true;
		gid('MF:txtDesGood3').value = "";
		setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent4");
		focusTextArea('MF:txtDocRequired1') ;
	}
	else if(_desgoodcount2.length > 6500 ||  splitResults2 > 100)
	{
		setMsg("The Line entered exceeded 6500 character typed " + _desgoodcount2.length + " lines" + splitResults2 );
		gid('MF:txtDesGood2').focus();
		return false;
	}
}
function validateDesGood3()
{
	var _desgoodcount3 = gid('MF:txtDesGood3').value;
	var splitResults3 = _desgoodcount3.split("\n").length;
	
	if(_desgoodcount3.length <= 6500 ||  splitResults3 == 100)
	{
		setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent4");
		focusTextArea('MF:txtDocRequired1') ;
	}
	else if(_desgoodcount3.length > 6500 ||  splitResults3 > 100)
	{
		setMsg("The Line entered exceeded 6500 character typed " + _desgoodcount3.length + " lines" + splitResults3);
		gid('MF:txtDesGood3').focus();
		return false;
	}
}

function validateDocRequired1()
{
	var _DocRequired1 = gid('MF:txtDocRequired1').value;
	var splitResults4 = _DocRequired1.split("\n").length;
	
	if(_DocRequired1.length == 6500 ||  splitResults4 == 100)
	{
		gid('MF:txtDocRequired2').readOnly = false;
		gid('MF:txtDocRequired3').readOnly = true;
		gid('MF:txtDocRequired3').value ="";
		setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent4");
		focusTextArea('MF:txtDocRequired2') ;
	}
	else if(_DocRequired1.length < 6500 && splitResults4 < 100)
	{
		gid('MF:txtDocRequired2').readOnly = true;
		gid('MF:txtDocRequired3').readOnly = true;
		gid('MF:txtDocRequired2').value ="";
		gid('MF:txtDocRequired3').value ="";
		setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent5");
		focusTextArea('MF:txtAddCond1') ;
	}
	else if(_DocRequired1.length > 6500 || splitResults4 >  100)
	{
		setMsg("The Line entered exceeded 6500 character typed " + _DocRequired1.length + " lines" + splitResults4);
		gid('MF:txtDocRequired1').focus();
		return false;
	}
	
}
function validateDocRequired2()
{
	var _DocRequired2 = gid('MF:txtDocRequired2').value;
	var splitResults5 = _DocRequired2.split("\n").length;
	
	if(_DocRequired2.length == 6500 ||  splitResults5 == 100)
	{
		gid('MF:txtDocRequired3').readOnly = false;
		setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent4");
		focusTextArea('MF:txtDocRequired3')
	}
	else if(_DocRequired2.length < 6500 && splitResults5 < 100)
	{
		gid('MF:txtDocRequired3').readOnly = true;
		gid('MF:txtDocRequired3').value ="";
		setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent5");
		focusTextArea('MF:txtAddCond1') ;
	}
	else if(_DocRequired2.length > 6500 || splitResults5 > 100)
	{
		setMsg("The Line entered exceeded 6500 character typed " + _DocRequired2.length + " lines" + splitResults5);
		gid('MF:txtDocRequired2').focus();
		return false;
	}
}
function validateDocRequired3()
{
	var _DocRequired3 = gid('MF:txtDocRequired3').value;
	var splitResults6 = _DocRequired3.split("\n").length;
	
	if(_DocRequired3.length <= 6500 ||  splitResults6 == 100 )
	{
		setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent5");
		focusTextArea('MF:txtAddCond1');
	}
	else if(_DocRequired3.length > 6500 || splitResults6 > 100)
	{
		setMsg("The Line entered exceeded 6500 character typed " + _DocRequired3.length + " lines" + splitResults6);
		gid('MF:txtDocRequired3').focus();
		return false;
	}
}

function validateAddCond1()
{
	var _AddCond1 = gid('MF:txtAddCond1').value;
	var splitResults7 = _AddCond1.split("\n").length;
	
	if(_AddCond1.length == 6500 ||  splitResults7 == 100)
	{
		gid('MF:txtAddCond2').readOnly = false;
		gid('MF:txtAddCond3').readOnly = true;
		gid('MF:txtAddCond3').value ="";
		setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent5");
		focusTextArea('MF:txtAddCond2') ;
	}
	else if(_AddCond1.length < 6500 && splitResults7 < 100)
	{
		gid('MF:txtAddCond2').readOnly = true;
		gid('MF:txtAddCond3').readOnly = true;
		gid('MF:txtAddCond2').value = "";
		gid('MF:txtAddCond3').value = "";
		setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent5");
		focusTextArea('MF:txtCharge') ;
	}
	else if(_AddCond1.length > 6500 || splitResults7 > 100)
	{
		setMsg("The Line entered exceeded 6500 character typed " + _AddCond1.length + " lines" + splitResults7);
		gid('MF:txtAddCond1').focus();
		return false;
	}
}
function validateAddCond2()
{
	var _AddCond2 = gid('MF:txtAddCond2').value;
	var splitResults8 = _AddCond2.split("\n").length;
	
	if(_AddCond2.length == 6500 ||  splitResults8 == 100)
	{
		gid('MF:txtAddCond3').readOnly = false;
		setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent5");
		focusTextArea('MF:txtAddCond3') ;
	}
	else if(_AddCond2.length < 6500 && splitResults8 < 100)
	{
		gid('MF:txtAddCond3').readOnly = true;
		gid('MF:txtAddCond3').value = "";
		setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent5");
		focusTextArea('MF:txtCharge') ;
	}
	else if(_AddCond2.length > 6500 || splitResults8 > 100)
	{
		setMsg("The Line entered exceeded 6500 character typed " + _AddCond2.length + " lines" + splitResults8);
		gid('MF:txtAddCond2').focus();
		return false;
	}
}
function validateAddCond3()
{
	var _AddCond3 = gid('MF:txtDocRequired3').value;
	var splitResults9 = _AddCond3.split("\n").length;
	
	if(_AddCond3.length <= 6500 ||  splitResults9 <= 100)
	{
		setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent5");
		focusTextArea('MF:txtCharge') ;
	}
	else if(_AddCond3.length > 6500 || splitResults9 > 100)
	{
		setMsg("The Line entered exceeded 6500 character typed" + _AddCond3.length + " lines" + splitResults9);
		gid('MF:txtAddCond3').focus();
		return false;
	}
}

function validateCharges()
{
	setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6");
	gid('MF:lstConfInst').focus();
}

function validatePeriod()
{
//changes in eolc on 02-jun-2018 start
		if(gid("MF:txtconttype").value=="OLC")
		{
			if(gid('MF:txtperiod').value != "" && gid('MF:txtperiod').value != "0")
			{
			
				//gid('MF:txtpresentationdetails').value ="";
				gid('MF:txtpresentationdetails').readOnly = false;
				setTabfocus("maintab","tcontent2");
				focusTextArea('MF:txtpresentationdetails');
				
			}
			else
			{
			
				gid('MF:txtpresentationdetails').value ="";
				gid('MF:txtpresentationdetails').readOnly = true;
				setTabfocus("maintab","tcontent3");
				gid('MF:chkUsanceInterest').focus();
			}
		}
		else //changes in eolc on 02-jun-2018 end
			{
			
				gid('MF:txtpresentationdetails').value ="";
				gid('MF:txtpresentationdetails').readOnly = true;
				setTabfocus("maintab","tcontent3");
				gid('MF:chkUsanceInterest').focus();
			}
	
}

function validateConfInst()
{
	checkcfmReimb();
	if(gid("MF:lstConfInst").value=="")
		{
			setMsg(BLANK_CHECK);
			gid("MF:lstConfInst").focus();
			return;
		}
		else
		{
			setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6");
			//ADDED BY PRASHANTH ON 29 JANUARY 2018
			   //Changes Sanjay1 22-07-2019 Begin
			   if((gid("MF:lstConfInst").value=="1")||(gid("MF:lstConfInst").value=="2"))
				{
					gid('MF:lstReimbcfmBank').focus();
				}
				else
				{
					//gid('MF:txtConfirmedByBank').value="";
					//gid('MF:txtConfirmedBYBranch').value="";
					//gid('MF:txtConfirmedBYBranchname').value="";
					//gid('MF:outlblConfirmedByBank').innerText="";
					gid('MF:chkReimb').focus();  
				}
			//Changes Sanjay1 22-07-2019 End
			//ADDED BY PRASHANTH ON 29 JANUARY 2018
		}
}



//ADDED BY PRASHANTH ON 29 JANUARY 2018
//Changes Sanjay1 22-07-2019 Begin
/*
function validateConfirmedByBank()
	{
	gid('MF:outlblConfirmedByBank').innerText ="";
			if(trim(gid('MF:txtConfirmedByBank').value) == "")
	    	{
	    		if(gid('MF:lstConfInst').value == "1")
	 	 		{
		 	 		setMsg(BLANK_CHECK);
	 	 			gid('MF:txtConfirmedByBank').focus();
	 	 		}
	    	}
	    	else
	    	{
	    	   objXMLApplet.clearMap();
		       objXMLApplet.setValue("Package", "panacea.OLCaction.eolcval");
			   objXMLApplet.setValue("ValidateToken", "true");  
			   objXMLApplet.setValue("Method", "olcAdvBankCodekeypress");
		       objXMLApplet.setValue("OLC_ADV_BANK_CODE",trim(gid('MF:txtConfirmedByBank').value));
		       objXMLApplet.sendAndReceive();
		        if (objXMLApplet.getValue("ErrorMsg") != "")
			 	{
					setMsg(objXMLApplet.getValue("ErrorMsg"));
					gid('MF:txtConfirmedByBank').focus();
					return;
				}
				else
				{
					gid('MF:outlblConfirmedByBank').innerText = objXMLApplet.getValue("BANKCD_NAME");
					gid('MF:txtConfirmedBYBranch').focus();
				}
	    	}
	}
	function validateConfirmedByBranch()
	{
	    	if(trim(gid('MF:txtConfirmedBYBranch').value) == "")
	    	{
	    		if(gid('MF:lstConfInst').value == "1")
	 	 		{
		 	 		setMsg(BLANK_CHECK);
	 	 			gid('MF:txtConfirmedBYBranch').focus();
	 	 		}
	    	}
	    	
	    	else
	    	{
	    	   objXMLApplet.clearMap();
		       objXMLApplet.setValue("Package", "panacea.OLCaction.eolcval");
			   objXMLApplet.setValue("ValidateToken", "true");  
			   objXMLApplet.setValue("Method", "olcAdvBranchCodekeypress");
		       objXMLApplet.setValue("OLC_ADV_BRNCH_CODE",trim(gid('MF:txtConfirmedBYBranch').value));
   		       objXMLApplet.setValue("OLC_ADV_BANK_CODE",trim(gid('MF:txtConfirmedByBank').value));
		       objXMLApplet.sendAndReceive();
		        if (objXMLApplet.getValue("ErrorMsg") != "")
			 	{
					setMsg(objXMLApplet.getValue("ErrorMsg"));
					gid('MF:txtConfirmedBYBranch').focus();
					return;
				}
				else
				{
					gid('MF:txtConfirmedBYBranchname').value = objXMLApplet.getValue("MBKBRN_NAME");
					gid('MF:chkReimb').focus();
				}
	    	}
	}
	function validateConfirmedByBranchName()
	{
			if(trim(gid('MF:txtConfirmedBYBranchname').value) == "")
	    	{
	    	if(gid('MF:lstConfInst').value == "1")
	 	 		{
	    		setMsg(BLANK_CHECK);
	    		gid('MF:txtConfirmedBYBranchname').focus();
	    		}
	    	}
	    	else
	    	{
 		    	// rerturnFlag2 = "C";
		    	// gid('div2').style.visibility = "visible";
    		    // gid('MF:txtaddress2').readOnly = false;
				// focusTextArea('MF:txtaddress2');
	    		gid('MF:chkReimb').focus();
	    	}
	}



*/
//Changes Sanjay1 22-07-2019 End






//ADDED BY PRASHANTH ON 29 JANUARY 2018
function  validaterecbic()
{

	if(gid("MF:txtconttype").value=="OLC")
	{
		if(gid("MF:txtrecbic").value=="")
		{
			setMsg(BLANK_CHECK);
			gid("MF:txtrecbic").focus();
			return;
		}
		
		else
		{
			objXMLApplet.clearMap();
		    objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
		    objXMLApplet.setValue("ValidateToken","true");
		    objXMLApplet.setValue("Method","Olc_Reciever_BICKeyPress");
		    objXMLApplet.setValue("LC_REC_BIC_CODE",trim(gid("MF:txtrecbic").value));
		    objXMLApplet.sendAndReceive();
		    if (objXMLApplet.getValue("ErrorMsg") != "")
		    {
		    	setMsg(objXMLApplet.getValue("ErrorMsg"));
				setTabfocus("maintab","tcontent9");
				setTabfocus("subtab","tsubcontent7");
				gid('MF:txtrecbic').focus();
		    }
		    else
		    {
		    	setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent7");
				gid('MF:Submit').focus();  
		    }
			
	}	
 }
 		else
		    {
		    	setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent7");
				gid('MF:Submit').focus();  
		    }
}
function validateInstructPay()
{
	setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent7");
	gid('MF:chkAdvise').focus();

}
function validateSendInfo()
{
	setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent7");
	//gid('MF:Submit').focus();
	gid('MF:txtrecbic').focus();//changes in eolc on 01-Jun-2018
}

function checkReimb()
{
	//setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6");
	if(gid('MF:chkReimb').checked==true)
		{
			gid('MF:outlblReimb').innerText="Yes";
			//gid('MF:lstReimbBank').value ="";
			gid('MF:lstReimbBank').disabled=false;
			gid('MF:txtReimBicCode').disabled=false;
			gid('MF:txtReimBicBank').readOnly=false;
			gid('MF:txtReimBicBrn').readOnly=false;
			gid('MF:txtReimBankName').readOnly=false;
			gid('MF:txtReimAcnt').readOnly=false;
			gid('MF:txtReimAddress').readOnly=false;
			gid('MF:txtReimCntry').readOnly=false;
		}
		else
		{
			gid('MF:outlblReimb').innerText="No";
			gid('MF:lstReimbBank').value ="";
			gid('MF:lstReimbBank').disabled=true;
			gid('MF:txtReimBicCode').disabled=true;
			gid('MF:txtReimBicBank').readOnly=true;
			gid('MF:txtReimBicBrn').readOnly=true;
			gid('MF:txtReimBankName').readOnly=true;
			gid('MF:txtReimAcnt').readOnly=true;
			gid('MF:txtReimAddress').readOnly=true;
			gid('MF:txtReimCntry').readOnly=true;
		}
		
		if(gid('MF:seluseroption').value=="A")//CHANGED ADDED ON 11/10/2018
		{
		clearReimbBic();
		clearReimbAddr();
		}
}

		//Changes Sanjay1 22-07-2019 Begin
        function  checkcfmReimb()
        {
        	if((gid("MF:lstConfInst").value=="1")||(gid("MF:lstConfInst").value=="2"))
			{
				gid('MF:lstReimbcfmBank').disabled=false;
				gid('MF:txtReimcfmBicCode').disabled=false;
				gid('MF:txtReimcfmBicBank').readOnly=false;
				gid('MF:txtReimcfmBicBrn').readOnly=false;
				gid('MF:txtcfmReimAcnt').readOnly=false;
				gid('MF:txtcfmReimBankName').readOnly=false;
				gid('MF:txtcfmReimAddress').readOnly=false;
				gid('MF:txtcfmReimCntry').readOnly=false;
			}
			else
			{
				gid('MF:lstReimbcfmBank').value ="";
				gid('MF:lstReimbcfmBank').disabled=true;
				gid('MF:txtReimcfmBicCode').disabled=true;
				gid('MF:txtReimcfmBicBank').readOnly=true;
				gid('MF:txtReimcfmBicBrn').readOnly=true;
				gid('MF:txtcfmReimAcnt').readOnly=true;
				gid('MF:txtcfmReimBankName').readOnly=true;
				gid('MF:txtcfmReimAddress').readOnly=true;
				gid('MF:txtcfmReimCntry').readOnly=true;
				clearReimbCfmBic();
			    clearReimbCfmAddr();
			}
			
			if(gid('MF:seluseroption').value=="A")//CHANGED ADDED ON 11/10/2018
			{
				clearReimbCfmBic();
			    clearReimbCfmAddr();
			}
        }
        //Changes Sanjay1 22-07-2019 End

function validatecheckReimb()
{
	checkReimb();
	if(gid('MF:chkReimb').checked==true)
		{
			gid('MF:lstReimbBank').focus();
		}
		else
		{
			focusTextArea('MF:txtInstPay');
		}

}

function checkAdvise()
{
	//setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent7");
	if(gid('MF:chkAdvise').checked==true)
		{
			gid('MF:outlblAdvise').innerText="Yes";
			//gid('MF:lstAdviseBank').value ="";
			gid('MF:lstAdviseBank').disabled=false;
			gid('MF:txtAdviseBicCode').disabled=false;
			gid('MF:txtAdviseBicBank').readOnly=false;
			gid('MF:txtAdviseBicBrn').readOnly=false;
			gid('MF:txtAdviseBankName').readOnly=false;
			gid('MF:txtAdviseAddress').readOnly=false;
			gid('MF:txtAdviseCntry').readOnly=false;
			gid('MF:txtAdviseAcnt').readOnly=false;
			
		}
		else
		{
			gid('MF:outlblAdvise').innerText="No";
			gid('MF:lstAdviseBank').value ="";
			gid('MF:lstAdviseBank').disabled=true;
			gid('MF:txtAdviseBicCode').disabled=true;
			gid('MF:txtAdviseBicBank').readOnly=true;
			gid('MF:txtAdviseBicBrn').readOnly=true;
			gid('MF:txtAdviseBankName').readOnly=true;
			gid('MF:txtAdviseAddress').readOnly=true;
			gid('MF:txtAdviseCntry').readOnly=true;
			gid('MF:txtAdviseAcnt').readOnly=true;
		}
		if(gid('MF:seluseroption').value=="A")//ADDED ON 11/10/2018
		{
		clearAdvThrBic();
		clearAdvThrAddr();
		}
}

function validatecheckAdvise()
{
	checkAdvise();
	if(gid('MF:chkAdvise').checked==true)
		{
			gid('MF:lstAdviseBank').focus();
		}
		else
		{
			focusTextArea('MF:txtSendInfo');
		}

}

function validatelistAppBank()
{
	if(gid('MF:lstAppBank').value == "" && gid('MF:chkAppBank').checked==true )
   	 	{
   	 		setMsg(OPTION_MESSAGE);
   	 		gid('MF:lstAppBank').focus();
   	 	}
   	 	else if(gid('MF:lstAppBank').value == "1" && gid('MF:chkAppBank').checked==true )
   	 	{	
   	 		appBank();
   	 		setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent10");
   	 		gid('MF:lstAvl').focus();
   	 	}
   	 	else if(gid('MF:lstAppBank').value == "2" && gid('MF:chkAppBank').checked==true )
   	 	{	
   	 		appBankenable();
   	 		setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1");
   	 		gid('MF:lstBICdtl').focus();
   	 		
   	 	}
   	 	else
   	 	{
   	 		appBank();
   	 		gid('MF:chkAppBank').focus();
   	 	}

}

function validatelistAvl()
{
	if (trim(gid('MF:lstAvl').value) == "")
	{
		setMsg(OPTION_MESSAGE);
   	 	gid('MF:lstAvl').focus();
	}
	else
	{
		gid('MF:lstAvlBICdtl').focus();
	}

}

	function validateAppAddr()
	{
	 	validateBankAddr(gid('MF:chkAppBank').checked,gid('MF:lstBICdtl').value,gid('MF:txtAppAddress').value,"1");
	}
	function validateAvlAddr()
	{
	 	validateBankAddr(true,gid('MF:lstAvlBICdtl').value,gid('MF:txtAvlAddress').value,"2");
	}
	function validateDraweeAddr()
	{
	 	validateBankAddr(gid('MF:chkDrawee').checked,gid('MF:lstDrwBICdtl').value,gid('MF:txtDrwAddress').value,"3");
	}
	function validateReimbAddr()
	{
	 	validateBankAddr(gid('MF:chkReimb').checked,gid('MF:lstReimbBank').value,gid('MF:txtReimAddress').value,"4");
	}
	function validateAdvAddr()
	{
	 	validateBankAddr(gid('MF:chkAdvise').checked,gid('MF:lstAdviseBank').value,gid('MF:txtAdviseAddress').value,"5");
	}
	//Changes Sanjay1 22-07-2019 Begin
	function validateReimbcfmAddr()
	{
	 	validateBankAddr(true,gid('MF:lstReimbcfmBank').value,gid('MF:txtcfmReimAddress').value,"6");
	}
	//Changes Sanjay1 22-07-2019 End

function validatelstBicdtl(banklst,txtlst)
	{
	
		if(txtlst == "1")
		{
			appBiclist() ;
			setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1");
			if(banklst == "" )
			{
			 	setMsg(BLANK_CHECK);
			 	gid('MF:lstBICdtl').focus();
			 	return;
			}
			else if(banklst == "1" )
			{
				
				gid('MF:txtAppBicCode').focus();
			}
			else if(banklst == "2")
			{
				gid('MF:txtAppAcnt').focus();
			}
			
		}
		
		if(txtlst == "2")
		{
			avlBicList();
			setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent10");
			if(banklst == "")
			{
				setMsg(BLANK_CHECK);
				gid('MF:lstAvlBICdtl').focus();
				return;
			}
			else if(banklst == "1")
			{
				gid('MF:txtAvlBicCode').focus();
			}
			else if(banklst == "2")
			{
				gid('MF:txtAvlAcnt').focus();
			}
			
		}
		
		if(txtlst == "3")
		{
			draweeBicList();
			setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2");
			if(banklst == "")
			{
				setMsg(BLANK_CHECK);
				gid('MF:lstDrwBICdtl').focus();
				return;
			}
			else if(banklst == "1")
			{
				gid('MF:txtDrwBicCode').focus();
			}
			else if(banklst == "2")
			{
				gid('MF:txtDrwAcnt').focus();
			}
			
		}
		
		if(txtlst == "4")
		{
			reimbBiclist();
			setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6");
			if(banklst == "")
			{
				setMsg(BLANK_CHECK);
				gid('MF:lstReimbBank').focus();
				return;
			}
			else if(banklst == "1")
			{
				gid('MF:txtReimBicCode').focus();
			}
			else if(banklst == "2")
			{
				gid('MF:txtReimAcnt').focus();
			}
			
		}
		
		if(txtlst == "5")
		{
			AvlThrBiclist();
			setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent7");
			if(banklst == "")
			{
				setMsg(BLANK_CHECK);
				gid('MF:lstAdviseBank').focus();
				return;
			}
			else if(banklst == "1")
			{
				gid('MF:txtAdviseBicCode').focus();
			}
			else if(banklst == "2")
			{
				gid('MF:txtAdviseAcnt').focus();
			}
			
		}
		//Changes Sanjay1 22-07-2019 Begin
		if(txtlst == "6")
		{
			reimbcfmBiclist();
			setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6");
			if(banklst == "")
			{
				setMsg(BLANK_CHECK);
				gid('MF:lstReimbcfmBank').focus();
				return;
			}
			else if(banklst == "1")
			{
				gid('MF:txtReimcfmBicCode').focus();
			}
			else if(banklst == "2")
			{
				gid('MF:txtcfmReimAcnt').focus();
			}
			
		}
		//Changes Sanjay1 22-07-2019 Begin
	} 
	
	function validateBicCode(lstchk,banklst,bankBic,txtlst)
	{
			var checkBiclist = "0";
			if(lstchk == true)
				checkBiclist="1";
			else
				checkBiclist="0";
			
			objXMLApplet.clearMap();
		    objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
		    objXMLApplet.setValue("ValidateToken","true");
		    objXMLApplet.setValue("Method","Olc_ApplicantBicKeypress");
		    objXMLApplet.setValue("LC_CHKBOX_REQ",trim(checkBiclist));
		    objXMLApplet.setValue("LC_DROPDWN_TYPE",trim(banklst));
		    objXMLApplet.setValue("LC_BIC_CODE",trim(bankBic));
		    objXMLApplet.sendAndReceive();
		    if (objXMLApplet.getValue("ErrorMsg") != "")
			{
				setMsg(objXMLApplet.getValue("ErrorMsg"));
				setTabfocus("maintab","tcontent9");
				if(trim(txtlst) =="1")	
				{
					setTabfocus("subtab","tsubcontent1");
					gid('MF:txtAppBicCode').focus();
				}
				else if(trim(txtlst) =="2")	
				{
					setTabfocus("subtab","tsubcontent10");
					gid('MF:txtAvlBicCode').focus();
				}
				else if(trim(txtlst) =="3")	
				{
					setTabfocus("subtab","tsubcontent2");
					gid('MF:txtDrwBicCode').focus();
				}
				else if(trim(txtlst) =="4")	
				{
					setTabfocus("subtab","tsubcontent6");
					gid('MF:txtReimBicCode').focus();
				}
				else if(trim(txtlst) =="5")	
				{
					setTabfocus("subtab","tsubcontent7");
					gid('MF:txtAdviseBicCode').focus();
				}			
				//Changes Sanjay1 22-07-2019 Begin
				else if(trim(txtlst) =="6")	
				{
					setTabfocus("subtab","tsubcontent6");
					gid('MF:txtReimcfmBicCode').focus();
				}	
				//Changes Sanjay1 22-07-2019 End
				return; 
		}
		else
		{
				setTabfocus("maintab","tcontent9");
				if(trim(txtlst) =="1")	
				{
					
					gid('MF:txtAppBicBank').value=objXMLApplet.getValue("SWIFT_BIC_BANKNAME");
					
					setTabfocus("subtab","tsubcontent1");
					gid('MF:txtAppBicBrn').focus();
				}
				else if(trim(txtlst) =="2")	
				{
					gid('MF:txtAvlBicBank').value=objXMLApplet.getValue("SWIFT_BIC_BANKNAME");
					
					setTabfocus("subtab","tsubcontent10");
					gid('MF:txtAvlBicBrn').focus();
				}
				else if(trim(txtlst) =="3")	
				{
					gid('MF:txtDrwBicBank').value=objXMLApplet.getValue("SWIFT_BIC_BANKNAME");
					
					setTabfocus("subtab","tsubcontent2");
					gid('MF:txtDrwBicBrn').focus();
				}
				else if(trim(txtlst) =="4")	
				{
					gid('MF:txtReimBicBank').value=objXMLApplet.getValue("SWIFT_BIC_BANKNAME");
					
					setTabfocus("subtab","tsubcontent6");
					gid('MF:txtReimBicBrn').focus();
				}
				else if(trim(txtlst) =="5")	
				{
					gid('MF:txtAdviseBicBank').value=objXMLApplet.getValue("SWIFT_BIC_BANKNAME");
					
					setTabfocus("subtab","tsubcontent7");
					gid('MF:txtAdviseBicBrn').focus();
				}			
				//Changes Sanjay1 22-07-2019 Begin
				else if(trim(txtlst) =="6")	
				{
					gid('MF:txtReimcfmBicBank').value=objXMLApplet.getValue("SWIFT_BIC_BANKNAME");
					
					setTabfocus("subtab","tsubcontent6");
					gid('MF:txtReimcfmBicBrn').focus();
				}	
				//Changes Sanjay1 22-07-2019 End
		}
	
	}
	
	function validateBrnCode(lstchk,banklst,bankBrn,txtlst)
	{
			var checkBiclist = "0";
			if(lstchk == true)
				checkBiclist="1";
			else
				checkBiclist="0";
			
			objXMLApplet.clearMap();
		    objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
		    objXMLApplet.setValue("ValidateToken","true");
		    objXMLApplet.setValue("Method","Olc_ApplicantBankBrachCodeKeypress");
		    objXMLApplet.setValue("LC_CHKBOX_REQ",trim(checkBiclist));
		    objXMLApplet.setValue("LC_DROPDWN_TYPE",trim(banklst));
		    objXMLApplet.setValue("LC_BRANCH_CODE",trim(bankBrn));
		    objXMLApplet.sendAndReceive();
		    if (objXMLApplet.getValue("ErrorMsg") != "")
			{
				setMsg(objXMLApplet.getValue("ErrorMsg"));
				setTabfocus("maintab","tcontent9");
				if(trim(txtlst) =="1")	
				{
					setTabfocus("subtab","tsubcontent1");
					gid('MF:txtAppBicBrn').focus();
				}
				else if(trim(txtlst) =="2")	
				{
					setTabfocus("subtab","tsubcontent10");
					gid('MF:txtAvlBicBrn').focus();
				}
				else if(trim(txtlst) =="3")	
				{
					setTabfocus("subtab","tsubcontent2");
					gid('MF:txtDrwBicBrn').focus();
				}
				else if(trim(txtlst) =="4")	
				{
					setTabfocus("subtab","tsubcontent6");
					gid('MF:txtReimBicBrn').focus();
				}
				else if(trim(txtlst) =="5")	
				{
					setTabfocus("subtab","tsubcontent7");
					gid('MF:txtAdviseBicBrn').focus();
				}			
				//Changes Sanjay1 22-07-2019 Begin
				else if(trim(txtlst) =="6")	
				{
					setTabfocus("subtab","tsubcontent6");
					gid('MF:txtReimcfmBicBrn').focus();
				}
				//Changes Sanjay1 22-07-2019 End
				return; 
		}
		else
		{
				setTabfocus("maintab","tcontent9");
				if(trim(txtlst) =="1")	
				{
					
					setTabfocus("subtab","tsubcontent10");
					gid('MF:lstAvl').focus();
				}
				else if(trim(txtlst) =="2")	
				{
					setTabfocus("subtab","tsubcontent10");
					/*if(trim(gid('MF:lstAvl').value) =="2")
					{
						gid('MF:txtMixedPaydtl').readOnly=true;
						gid('MF:txtMixedPaydtl').value ="";
						gid('MF:txtDeferPaydtl').readOnly=false;
						//gid('MF:txtDeferPaydtl').focus();
					}
					else
					{
						gid('MF:txtDeferPaydtl').readOnly=true;
						gid('MF:txtDeferPaydtl').value="";
						gid('MF:txtMixedPaydtl').readOnly=false;
						//gid('MF:txtMixedPaydtl').focus();
					}*/
					focusTextArea('MF:txtDraft');
					
				}
				else if(trim(txtlst) =="3")	
				{
					setTabfocus("subtab","tsubcontent2");
					if(gid('MF:txtMixedPaydtl').readOnly==false)
						gid('MF:txtMixedPaydtl').focus();
					else if(gid('MF:txtDeferPaydtl').readOnly==false)
						gid('MF:txtDeferPaydtl').focus();
					else 
						gid('MF:lstparShip').focus();
				}
				else if(trim(txtlst) =="4")	
				{
					setTabfocus("subtab","tsubcontent6");
					focusTextArea('MF:txtInstPay');
				}
				else if(trim(txtlst) =="5")	
				{
					setTabfocus("subtab","tsubcontent7");
					gid('MF:txtSendInfo').focus();
				}	
				//Changes Sanjay1 22-07-2019 Begin
				else if(trim(txtlst) =="6")	
				{
					setTabfocus("subtab","tsubcontent6");
					focusTextArea('MF:chkReimb');
				}
				//Changes Sanjay1 22-07-2019 End		
		}
	
	}
	
	
	function validateBankRout(lstchk,banklst,bankRout,txtlst)
	{
		var checkBiclist = "0";
			if(lstchk == true)
				checkBiclist="1";
			else
				checkBiclist="0";
			
			objXMLApplet.clearMap();
		    objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
		    objXMLApplet.setValue("ValidateToken","true");
		    objXMLApplet.setValue("Method","Olc_ApplicantAccountNumberKeypress");
		    objXMLApplet.setValue("LC_CHKBOX_REQ",trim(checkBiclist));
		    objXMLApplet.setValue("LC_DROPDWN_TYPE",trim(banklst));
		    objXMLApplet.setValue("LC_ROUNTING_ID",trim(bankRout));
		    objXMLApplet.sendAndReceive();
		    if (objXMLApplet.getValue("ErrorMsg") != "")
			{
				setMsg(objXMLApplet.getValue("ErrorMsg"));
				setTabfocus("maintab","tcontent9");
				if(trim(txtlst) =="1")	
				{
					setTabfocus("subtab","tsubcontent1");
					gid('MF:txtAppAcnt').focus();
				}
				else if(trim(txtlst) =="2")	
				{
					setTabfocus("subtab","tsubcontent10");
					gid('MF:txtAvlAcnt').focus();
				}
				else if(trim(txtlst) =="3")	
				{
					setTabfocus("subtab","tsubcontent2");
					gid('MF:txtDrwAcnt').focus();
				}
				else if(trim(txtlst) =="4")	
				{
					setTabfocus("subtab","tsubcontent6");
					gid('MF:txtReimAcnt').focus();
				}
				else if(trim(txtlst) =="5")	
				{
					setTabfocus("subtab","tsubcontent7");
					gid('MF:txtAdviseAcnt').focus();
				}			
				//Changes Sanjay1 22-07-2019 Begin
				else if(trim(txtlst) =="6")	
				{
					setTabfocus("subtab","tsubcontent6");
					gid('MF:txtcfmReimAcnt').focus();
				}
				//Changes Sanjay1 22-07-2019 End
				return; 
		}
		else
		{
				setTabfocus("maintab","tcontent9");
				if(trim(txtlst) =="1")	
				{
					
					setTabfocus("subtab","tsubcontent1");
					focusTextArea('MF:txtAppBankName');
				}
				else if(trim(txtlst) =="2")	
				{
					setTabfocus("subtab","tsubcontent10");
					focusTextArea('MF:txtAvlBankName');
				}
				else if(trim(txtlst) =="3")	
				{
					setTabfocus("subtab","tsubcontent2");
					focusTextArea('MF:txtDrwBankName');
				}
				else if(trim(txtlst) =="4")	
				{
					setTabfocus("subtab","tsubcontent6");
					focusTextArea('MF:txtReimBankName');
				}
				else if(trim(txtlst) =="5")	
				{
					setTabfocus("subtab","tsubcontent7");
					focusTextArea('MF:txtAdviseBankName');
				}			
				//Changes Sanjay1 22-07-2019 Begin
				else if(trim(txtlst) =="6")	
				{
					setTabfocus("subtab","tsubcontent6");
					focusTextArea('MF:txtcfmReimBankName');
				}
				//Changes Sanjay1 22-07-2019 End
		}
	
	}
	
	
	function validateBankName(lstchk,banklst,bankName,txtlst)
	{
		var checkBiclist = "0";
			if(lstchk == true)
				checkBiclist="1";
			else
				checkBiclist="0";
			
			objXMLApplet.clearMap();
		    objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
		    objXMLApplet.setValue("ValidateToken","true");
		    objXMLApplet.setValue("Method","Olc_ApplicantBankNameKeypress");
		    objXMLApplet.setValue("LC_CHKBOX_REQ",trim(checkBiclist));
		    objXMLApplet.setValue("LC_DROPDWN_TYPE",trim(banklst));
		    objXMLApplet.setValue("LC_BANK_NAME",trim(bankName));
		    objXMLApplet.sendAndReceive();
		    if (objXMLApplet.getValue("ErrorMsg") != "")
			{
				setMsg(objXMLApplet.getValue("ErrorMsg"));
				setTabfocus("maintab","tcontent9");
				if(trim(txtlst) =="1")	
				{
					setTabfocus("subtab","tsubcontent1");
					gid('MF:txtAppBankName').focus();
				}
				else if(trim(txtlst) =="2")	
				{
					setTabfocus("subtab","tsubcontent10");
					gid('MF:txtAvlBankName').focus();
				}
				else if(trim(txtlst) =="3")	
				{
					setTabfocus("subtab","tsubcontent2");
					gid('MF:txtDrwBankName').focus();
				}
				else if(trim(txtlst) =="4")	
				{
					setTabfocus("subtab","tsubcontent6");
					gid('MF:txtReimBankName').focus();
				}
				else if(trim(txtlst) =="5")	
				{
					setTabfocus("subtab","tsubcontent7");
					gid('MF:txtAdviseBankName').focus();
				}		
				//Changes Sanjay1 22-07-2019 Begin
				else if(trim(txtlst) =="6")	
				{
					setTabfocus("subtab","tsubcontent6");
					gid('MF:txtcfmReimBankName').focus();
				}
				//Changes Sanjay1 22-07-2019 End	
				return; 
		}
		else
		{
				setTabfocus("maintab","tcontent9");
				if(trim(txtlst) =="1")	
				{
					
					setTabfocus("subtab","tsubcontent1");
					focusTextArea('MF:txtAppAddress');
				}
				else if(trim(txtlst) =="2")	
				{
					setTabfocus("subtab","tsubcontent10");
					focusTextArea('MF:txtAvlAddress');
				}
				else if(trim(txtlst) =="3")	
				{
					setTabfocus("subtab","tsubcontent2");
					focusTextArea('MF:txtDrwAddress');
				}
				else if(trim(txtlst) =="4")	
				{
					setTabfocus("subtab","tsubcontent6");
					focusTextArea('MF:txtReimAddress');
				}
				else if(trim(txtlst) =="5")	
				{
					setTabfocus("subtab","tsubcontent7");
					focusTextArea('MF:txtAdviseAddress');
				}			
				//Changes Sanjay1 22-07-2019 Begin
				else if(trim(txtlst) =="6")	
				{
					setTabfocus("subtab","tsubcontent6");
					focusTextArea('MF:txtcfmReimAddress');
				}
				//Changes Sanjay1 22-07-2019 End
		}
	
	}
	
	function validateBankAddr(lstchk,banklst,bankAddr,txtlst)
	{
		var checkBiclist = "0";
			if(lstchk == true)
				checkBiclist="1";
			else
				checkBiclist="0";
			
			objXMLApplet.clearMap();
		    objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
		    objXMLApplet.setValue("ValidateToken","true");
		    objXMLApplet.setValue("Method","Olc_ApplicantBankAddressKeypress");
		    objXMLApplet.setValue("LC_CHKBOX_REQ",trim(checkBiclist));
		    objXMLApplet.setValue("LC_DROPDWN_TYPE",trim(banklst));
		    objXMLApplet.setValue("LC_BANK_ADDRESS",trim(bankAddr));
		    objXMLApplet.sendAndReceive();
		    if (objXMLApplet.getValue("ErrorMsg") != "")
			{
				setMsg(objXMLApplet.getValue("ErrorMsg"));
				setTabfocus("maintab","tcontent9");
				if(trim(txtlst) =="1")	
				{
					setTabfocus("subtab","tsubcontent1");
					focusTextArea('MF:txtAppAddress');
				}
				else if(trim(txtlst) =="2")	
				{
					setTabfocus("subtab","tsubcontent10");
					focusTextArea('MF:txtAvlAddress');
				}
				else if(trim(txtlst) =="3")	
				{
					setTabfocus("subtab","tsubcontent2");
					focusTextArea('MF:txtDrwAddress');
				}
				else if(trim(txtlst) =="4")	
				{
					setTabfocus("subtab","tsubcontent6");
					focusTextArea('MF:txtReimAddress');
				}
				else if(trim(txtlst) =="5")	
				{
					setTabfocus("subtab","tsubcontent7");
					focusTextArea('MF:txtAdviseAddress');
				}			
				//Changes Sanjay1 22-07-2019 Begin
				else if(trim(txtlst) =="6")	
				{
					setTabfocus("subtab","tsubcontent6");
					focusTextArea('MF:txtcfmReimAddress');
				}		
				//Changes Sanjay1 22-07-2019 End
				return; 
		}
		else
		{
				setTabfocus("maintab","tcontent9");
				if(trim(txtlst) =="1")	
				{
					
					setTabfocus("subtab","tsubcontent1");
					gid('MF:txtAppCntry').focus();
				}
				else if(trim(txtlst) =="2")	
				{
					setTabfocus("subtab","tsubcontent10");
					gid('MF:txtAvlCntry').focus();
				}
				else if(trim(txtlst) =="3")	
				{
					setTabfocus("subtab","tsubcontent2");
					gid('MF:txtDrwCntry').focus();
				}
				else if(trim(txtlst) =="4")	
				{
					setTabfocus("subtab","tsubcontent6");
					gid('MF:txtReimCntry').focus();
				}
				else if(trim(txtlst) =="5")	
				{
					setTabfocus("subtab","tsubcontent7");
					gid('MF:txtAdviseCntry').focus();
				}			
				//Changes Sanjay1 22-07-2019 Begin
				else if(trim(txtlst) =="6")	
				{
					setTabfocus("subtab","tsubcontent6");
					gid('MF:txtcfmReimCntry').focus();
				}			
				//Changes Sanjay1 22-07-2019 End
		}
	
	}
	
	function validateBankCntry(lstchk,banklst,bankCntry,txtlst)
	{
		var checkBiclist = "0";
			if(lstchk == true)
				checkBiclist="1";
			else
				checkBiclist="0";
			
			objXMLApplet.clearMap();
		    objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
		    objXMLApplet.setValue("ValidateToken","true");
		    objXMLApplet.setValue("Method","Olc_ApplicantBankCntryCodeKeypress");
		    objXMLApplet.setValue("LC_CHKBOX_REQ",trim(checkBiclist)); 
		    objXMLApplet.setValue("LC_DROPDWN_TYPE",trim(banklst));
		    objXMLApplet.setValue("LC_BANK_COUNTRY_CODE",trim(bankCntry));
		    objXMLApplet.setValue("LC_TYPE",trim(gid('MF:txtconttype').value));
		    objXMLApplet.sendAndReceive();
		    if (objXMLApplet.getValue("ErrorMsg") != "")
			{
				setMsg(objXMLApplet.getValue("ErrorMsg"));
				setTabfocus("maintab","tcontent9");
				if(trim(txtlst) =="1")	
				{
					setTabfocus("subtab","tsubcontent1");
					gid('MF:txtAppCntry').focus();
				}
				else if(trim(txtlst) =="2")	
				{
					setTabfocus("subtab","tsubcontent10");
					gid('MF:txtAvlCntry').focus();
				}
				else if(trim(txtlst) =="3")	
				{
					setTabfocus("subtab","tsubcontent2");
					gid('MF:txtDrwCntry').focus();
				}
				else if(trim(txtlst) =="4")	
				{
					setTabfocus("subtab","tsubcontent6");
					gid('MF:txtReimCntry').focus();
				}
				else if(trim(txtlst) =="5")	
				{
					setTabfocus("subtab","tsubcontent7");
					gid('MF:txtAdviseCntry').focus();
				}			
				//Changes Sanjay1 22-07-2019 Begin
				else if(trim(txtlst) =="6")	
				{
					setTabfocus("subtab","tsubcontent6");
					gid('MF:txtcfmReimCntry').focus();
				}
				//Changes Sanjay1 22-07-2019 End
				return; 
		}
		else
		{
				setTabfocus("maintab","tcontent9");
				if(trim(txtlst) =="1")	
				{
					setTabfocus("subtab","tsubcontent10");
					gid('MF:lstAvl').focus();
				}
				else if(trim(txtlst) =="2")	
				{
					setTabfocus("subtab","tsubcontent10");
					/*if(trim(gid('MF:lstAvl').value) =="2")
					{
						gid('MF:txtMixedPaydtl').readOnly=true;
						gid('MF:txtMixedPaydtl').value ="";
						gid('MF:txtDeferPaydtl').readOnly=false;
						//gid('MF:txtDeferPaydtl').focus();
					}
					else
					{
						gid('MF:txtDeferPaydtl').readOnly=true;
						gid('MF:txtDeferPaydtl').value="";
						gid('MF:txtMixedPaydtl').readOnly=false;
						//gid('MF:txtMixedPaydtl').focus();
					}*/
					focusTextArea('MF:txtDraft');
				}
				else if(trim(txtlst) =="3")	
				{
					setTabfocus("subtab","tsubcontent2");
					if(gid('MF:txtMixedPaydtl').readOnly==false)
						gid('MF:txtMixedPaydtl').focus();
					else if(gid('MF:txtDeferPaydtl').readOnly==false)
						gid('MF:txtDeferPaydtl').focus();
					else
						gid('MF:lstparShip').focus();
					
				}
				else if(trim(txtlst) =="4")	
				{
					setTabfocus("subtab","tsubcontent6");
					focusTextArea('MF:txtInstPay');
				}
				else if(trim(txtlst) =="5")	
				{
					setTabfocus("subtab","tsubcontent7");
					focusTextArea('MF:txtSendInfo');
				}		
				//Changes Sanjay1 22-07-2019 Begin
				else if(trim(txtlst) =="6")	
				{
					setTabfocus("subtab","tsubcontent6");
					focusTextArea('MF:chkReimb');
				}
				//Changes Sanjay1 22-07-2019 End	
		}
	
	}

	function InitializeTab()
	{
		appBiclist();
		avlBicList();
		draweeBicList();
		reimbBiclist();
		//Changes Sanjay1 22-07-2019 Begin
		reimbcfmBiclist();
		checkcfmReimb();
		//Changes Sanjay1 22-07-2019 End
		AvlThrBiclist();
		checkAppBank();
		appBank();
		checkDrawee();
		checkAdvise();
		checkReimb();
		
		gid('MF:txtMixedPaydtl').readOnly = true;
		gid('MF:txtDeferPaydtl').readOnly = true;
		gid('MF:txtDesGood2').readOnly = true;
		gid('MF:txtDesGood3').readOnly = true;
		gid('MF:txtpresentationdetails').readOnly = true;

		gid('MF:txtDocRequired2').readOnly = true;
		gid('MF:txtDocRequired3').readOnly = true;

		gid('MF:txtAddCond2').readOnly = true;
		gid('MF:txtAddCond3').readOnly = true;
	 	
	 	banklst = "";
		txtlst ="";
		bankBic="";
		lstchk="";
		bankBrn="";
		bankName="";
		bankAddr="";
		bankCntry="";
		bankRout="";
	}
	
	
	function appBiclist()
	{
		if(trim(gid('MF:lstBICdtl').value) == "") 
	  	{   
	  		clearAppBic();
			clearAppAddr();
	  		document.getElementById('APPNAMEADDR').style.display = 'none';
			document.getElementById('APPBIC').style.display = 'block';
		}
	 	else if(trim(gid('MF:lstBICdtl').value) == "1")
	 	{
	 		clearAppAddr();
	 		document.getElementById('APPNAMEADDR').style.display = 'none';
	 		document.getElementById('APPBIC').style.display = 'block';
	 	}
	 	else if(trim(gid('MF:lstBICdtl').value) == "2")
	 	{
		 	clearAppBic();
		 	document.getElementById('APPNAMEADDR').style.display = 'block';
		 	document.getElementById('APPBIC').style.display = 'none';
	 	}
	}
	
	function draweeBicList()
	{
		if(trim(gid('MF:lstDrwBICdtl').value) == "")
	  	{   
	  		clearDraweeBic();
			clearDraweeAddr();
	  		document.getElementById('DRWBICBANK').style.display = 'none';
			document.getElementById('DRWBIC').style.display = 'block';
		}
	 	else if(trim(gid('MF:lstDrwBICdtl').value) == "1")
	 	{
	 		clearDraweeAddr();
	 		document.getElementById('DRWBICBANK').style.display = 'none';
	 		document.getElementById('DRWBIC').style.display = 'block';
	 	}
	 	else if(trim(gid('MF:lstDrwBICdtl').value) == "2")
	 	{
	 		clearDraweeBic();
	 		document.getElementById('DRWBICBANK').style.display = 'block';
	 		document.getElementById('DRWBIC').style.display = 'none';
	 	}
	}
	
	function reimbBiclist()
	{
		if(trim(gid('MF:lstReimbBank').value) == "")
	  	{   
	  		clearReimbBic();
			clearReimbAddr();
	  		document.getElementById('REIMNAMEADDR').style.display = 'none';
			document.getElementById('REIMBIC').style.display = 'block';
		}
	 	else if(trim(gid('MF:lstReimbBank').value) == "1")
	 	{
	 		clearReimbAddr();
	 		document.getElementById('REIMNAMEADDR').style.display = 'none';
	 		document.getElementById('REIMBIC').style.display = 'block';
	 	}
	 	else if(trim(gid('MF:lstReimbBank').value) == "2")
	 	{
	 		clearReimbBic();
	 		document.getElementById('REIMNAMEADDR').style.display = 'block';
	 		document.getElementById('REIMBIC').style.display = 'none';
	 	}
	}
	
	//Changes Sanjay1 22-07-2019 Begin
	function reimbcfmBiclist()
	{
		if(trim(gid('MF:lstReimbcfmBank').value) == "")
	  	{   
	  		clearReimbCfmBic();
		    clearReimbCfmAddr();
	  		document.getElementById('REIMCFMNAMEADDR').style.display = 'none';
			document.getElementById('REIMCFMBIC').style.display = 'block';
		}
	 	else if(trim(gid('MF:lstReimbcfmBank').value) == "1")
	 	{
	 		clearReimbCfmAddr();
	 		document.getElementById('REIMCFMNAMEADDR').style.display = 'none';
	 		document.getElementById('REIMCFMBIC').style.display = 'block';
	 	}
	 	else if(trim(gid('MF:lstReimbcfmBank').value) == "2")
	 	{
	 		clearReimbCfmBic();
	 		document.getElementById('REIMCFMNAMEADDR').style.display = 'block';
	 		document.getElementById('REIMCFMBIC').style.display = 'none';
	 	}
	}
	//Changes Sanjay1 22-07-2019 End

	function avlBicList()
	{
		if(trim(gid('MF:lstAvlBICdtl').value) == "")
	  	{      
	    	clearAVLBic();
			clearAVLAddr();
	    	document.getElementById('AVLNAMEADDR').style.display = 'none';
			document.getElementById('AVLBIC').style.display = 'block';
	 	}
	 	else if(trim(gid('MF:lstAvlBICdtl').value) == "1")
	 	{
	 		clearAVLAddr();
	 		document.getElementById('AVLNAMEADDR').style.display = 'none';
	 		document.getElementById('AVLBIC').style.display = 'block';
	 	}
	 	else if(trim(gid('MF:lstAvlBICdtl').value) == "2")
	 	{
		 	clearAVLBic();
		 	document.getElementById('AVLNAMEADDR').style.display = 'block';
		 	document.getElementById('AVLBIC').style.display = 'none';
	 	}
	}
	
	
	function AvlThrBiclist()
	{
		if(trim(gid('MF:lstAdviseBank').value) == "")
	  	{   
	  		clearAdvThrBic();
			clearAdvThrAddr();
	  		document.getElementById('ADVISENAMEADDR').style.display = 'none';
			document.getElementById('ADVISEBIC').style.display = 'block';
		}
	 	else if(trim(gid('MF:lstAdviseBank').value) == "1")
	 	{
	 		clearAdvThrAddr();
	 		document.getElementById('ADVISENAMEADDR').style.display = 'none';
	 		document.getElementById('ADVISEBIC').style.display = 'block';
	 	}
	 	else if(trim(gid('MF:lstAdviseBank').value) == "2")
	 	{
	 		clearAdvThrBic();
	 		document.getElementById('ADVISENAMEADDR').style.display = 'block';
	 		document.getElementById('ADVISEBIC').style.display = 'none';
	 	}
	}
	
	function clearAppBic()
	{
		gid('MF:txtAppBicCode').value="";
		gid('MF:txtAppBicBank').value="";
		gid('MF:txtAppBicBrn').value="";
	}
	
	function clearAppAddr()
	{
		gid('MF:txtAppBankName').value="";
		gid('MF:txtAppAcnt').value="";
		gid('MF:txtAppAddress').value="";
		gid('MF:txtAppCntry').value="";
	}
	
	function clearAVLBic()
	{
		gid('MF:txtAvlBicCode').value="";
		gid('MF:txtAvlBicBank').value="";
		gid('MF:txtAvlBicBrn').value="";
	}
	
	function clearAVLAddr()
	{
		gid('MF:txtAvlBankName').value="";
		gid('MF:txtAvlAcnt').value="";
		gid('MF:txtAvlAddress').value="";
		gid('MF:txtAvlCntry').value="";
	}
	
	function clearDraweeBic()
	{
		gid('MF:txtDrwBicCode').value="";
		gid('MF:txtDrwBicBank').value="";
		gid('MF:txtDrwBicBrn').value="";
	}
	
	function clearDraweeAddr()
	{
		gid('MF:txtDrwBankName').value="";
		gid('MF:txtDrwAcnt').value="";
		gid('MF:txtDrwAddress').value="";
		gid('MF:txtDrwCntry').value="";
	}
	
	function clearReimbBic()
	{
		gid('MF:txtReimBicCode').value="";
		gid('MF:txtReimBicBank').value="";
		gid('MF:txtReimBicBrn').value="";
	}
	
	function clearReimbAddr()
	{
		gid('MF:txtReimBankName').value="";
		gid('MF:txtReimAcnt').value="";
		gid('MF:txtReimAddress').value="";
		gid('MF:txtReimCntry').value="";
	}
	//Changes Sanjay1 22-07-2019 Begin
	function clearReimbCfmBic()
	{
		gid('MF:txtReimcfmBicCode').value="";
		gid('MF:txtReimcfmBicBank').value="";
		gid('MF:txtReimcfmBicBrn').value="";
	}
	
	function clearReimbCfmAddr()
	{
		gid('MF:txtcfmReimAcnt').value="";
		gid('MF:txtcfmReimBankName').value="";
		gid('MF:txtcfmReimAddress').value="";
		gid('MF:txtcfmReimCntry').value="";
	}
	//Changes Sanjay1 22-07-2019 End
	function clearAdvThrBic()
	{
		gid('MF:txtAdviseBicCode').value="";
		gid('MF:txtAdviseBicBank').value="";
		gid('MF:txtAdviseBicBrn').value="";
	}
	
	function clearAdvThrAddr()
	{
		gid('MF:txtAdviseBankName').value="";
		gid('MF:txtAdviseAddress').value="";
		gid('MF:txtAdviseCntry').value="";
		gid('MF:txtAdviseAcnt').value="";
	}

 function nextTab()
	{
	//changes in eolc on 01-jun-2018 start
		if(gid('MF:txtconttype').value=='OLC')
		{
			setTabfocus("maintab","tcontent9");
			setTabfocus("subtab","tsubcontent1");
			gid('MF:lstcredit').focus();
		}
		else
		{
			gid('MF:Submit').focus();
		}
		//changes in eolc on 01-jun-2018 end
		
	}

//-----------------------------------------------------------------------------------------------------------------------------		
//CHNAGED ADDED ON 27/05/2018 END	
//--------------------------------------------------------------------------------------------------------------------------

function changeoption()
{
	if(gid("MF:seluseroption").value!="A")
	    {
		 	gid('MF:lblcopylc').style.visibility="hidden" ;	
		 	gid('MF:cmdcopylc').style.visibility="hidden" ;	
		}	
		else
		{
			gid('MF:lblcopylc').style.visibility="visible" ;
			gid('MF:cmdcopylc').style.visibility="visible" ;	
		}
}

//-----------------------------------------------------------------------------------------------------------------------------				
	function validateoption()
	{
 	 	if(gid('MF:seluseroption').value == "")
   	 	{
   	 		setMsg(OPTION_MESSAGE);
    		gid('MF:seluseroption').focus();
   	 	}
   	 	else
   	 	{	
   	 		changeoption();//chnages
   	 		gid('MF:txtbrncode').focus();
   	 	}
	}
//-----------------------------------------------------------------------------------------------------------------------------	
	function validateBranchCode()
	{

		if(gid("MF:txtbrncode").value=="")
		{
			setMsg(BLANK_CHECK);
			gid("MF:txtbrncode").focus();
			return;
		}
		else if(gid("MF:txtbrncode").value==0)
		{
			setMsg(ZERO_CHECK);
			gid("MF:txtbrncode").focus();
			return;
		}
		else
		{
			objXMLApplet.clearMap();
			objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
			objXMLApplet.setValue("Method","olcBrnCodekeypress");
            objXMLApplet.setValue("ValidateToken", "true");
            objXMLApplet.setValue("OLC_BRN_CODE",trim(gid('MF:txtbrncode').value));
            objXMLApplet.sendAndReceive();
			if(objXMLApplet.getValue("ErrorMsg") != "")
			{
	    		setMsg(objXMLApplet.getValue("ErrorMsg"));
				gid('MF:txtbrncode').focus();
				return;  
			}
			else
        {   	objTFMCharges.brncode=gid('MF:txtbrncode').value;
				gid('MF:txtconttype').focus();
				objCRates.branchcode=gid('MF:txtbrncode').value;
			}
		}
	}	
//-----------------------------------------------------------------------------------------------------------------------------	
	function validateConType()
  	{
    	if(gid("MF:txtconttype").value=="")
		{
			setMsg(BLANK_CHECK);
			gid("MF:txtconttype").focus();
			return;
		}
		else
		{
			objXMLApplet.clearMap();
			objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
			objXMLApplet.setValue("Method","olcTypekeypress");
	        objXMLApplet.setValue("ValidateToken", "true");
	        objXMLApplet.setValue("CBD",currbusDate);
	        objXMLApplet.setValue("OLC_TYPE",trim(gid('MF:txtconttype').value));
			objXMLApplet.sendAndReceive();
			if(objXMLApplet.getValue("ErrorMsg") != "")
			{
	  			setMsg(objXMLApplet.getValue("ErrorMsg"));
				gid('MF:txtconttype').focus();
				return;  
			}
			else  
			{		
				//changes in eolc on 01-jun-2018 start
					if(gid('MF:txtconttype').value=='LC')
						disableTab("maintab","tcontent9");
					//changes in eolc on 01-jun-2018 end
				gid("MF:txtproductcode").value=objXMLApplet.getValue("PRODUCT_CODE");
				product_code=objXMLApplet.getValue("PRODUCT_CODE");
				gid("MF:outlblproductcode").innerText=objXMLApplet.getValue("PRODUCT_NAME");
				product_name=objXMLApplet.getValue("PRODUCT_NAME");
				numchoice=objXMLApplet.getValue("TNOMEN_NUM_CHOICE");
				autonum=objXMLApplet.getValue("TNOMEN_AUTO_NUM");
				//Changes-M.S.Jayanthi-10/11/2009-chn-beg
				gid("MF:txtinover").value=objXMLApplet.getValue("TNOMEN_INLAND_OVERSEAS");
				//Changes-M.S.Jayanthi-10/11/2009-chn-end
				if(objXMLApplet.getValue("TNOMEN_NUM_CHOICE")=="F")
				{
					gid("MF:txtcontyear").value=objXMLApplet.getValue("FIN_YEAR");
				}
				if(objXMLApplet.getValue("TNOMEN_NUM_CHOICE")=="C")
				{
					gid("MF:txtcontyear").value=currbusDate.substring(6,10);
				}
				if(objXMLApplet.getValue("TNOMEN_INLAND_OVERSEAS")=="I")
					gid("MF:txtLcIssuedOncntry").value=usercountry;
				gid("MF:txtcontyear").focus();
			}
		}
	}	
//-----------------------------------------------------------------------------------------------------------------------------			
	function validateConYear()
	{
	 	if(gid("MF:txtcontyear").value=="")
		{
			setMsg(BLANK_CHECK);
			gid("MF:txtcontyear").focus();
			return;
		}
		else if(gid("MF:txtcontyear").value==0)
		{
			setMsg(ZERO_CHECK);
			gid("MF:txtcontyear").focus();
			return;
		}
		else
		{
			if(validateYear())
			{
				objXMLApplet.clearMap();
				objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
				objXMLApplet.setValue("Method","olcYearkeypress");
                objXMLApplet.setValue("ValidateToken", "true");
                objXMLApplet.setValue("OLC_YEAR",trim(gid('MF:txtcontyear').value));
				objXMLApplet.setValue("TNOMEN_NUM_CHOICE",numchoice);
				objXMLApplet.setValue("TNOMEN_AUTO_NUM",autonum);
				objXMLApplet.setValue("USER_OPTION",trim(gid('MF:seluseroption').value));
				objXMLApplet.setValue("CBD",currbusDate);
				objXMLApplet.setValue("OLC_BRN_CODE",trim(gid('MF:txtbrncode').value));
				objXMLApplet.setValue("OLC_TYPE",trim(gid('MF:txtconttype').value));
				objXMLApplet.sendAndReceive();
				if(objXMLApplet.getValue("ErrorMsg") != "")
				{
	      			setMsg(objXMLApplet.getValue("ErrorMsg"));
					gid('MF:txtcontyear').focus();
					return;  
				}
				else  
				{
					if(autonum=="0" && gid('MF:seluseroption').value=="A" )
					{
						gid("MF:txtcontsl").focus();
					}
					if(autonum=="1" && gid('MF:seluseroption').value=="A" )
					{
						setTabfocus("maintab","tcontent1");
						gid("MF:txtpresanDate").focus();
					}
					if(gid('MF:seluseroption').value=="M")
					{
						gid("MF:txtcontsl").focus();
					}	
				}
			}
			else
			{
				setMsg("For Year Should be Greater than or Equal to 1900");
				gid('MF:txtcontyear').focus();
				return;
			}
	    }
	 }   		
//-----------------------------------------------------------------------------------------------------------------------------        	
	function  validateYear()
	{
		var year=gid("MF:txtcontyear").value;
		if(year>=1900)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
//-----------------------------------------------------------------------------------------------------------------------------	
	function validateConSNo()
    {
   		if(gid("MF:txtcontsl").value=="")
		{
			setMsg(BLANK_CHECK);
			gid("MF:txtcontsl").focus();
			return;
		}
		else if(gid("MF:txtcontsl").value==0)
		{
			setMsg(ZERO_CHECK);
			gid("MF:txtcontsl").focus();
			return;
		}
		else
		{
			objXMLApplet.clearMap();
			objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
			objXMLApplet.setValue("Method","olcSlnokeypress");
	        objXMLApplet.setValue("ValidateToken", "true");
	        objXMLApplet.setValue("OLC_YEAR",trim(gid('MF:txtcontyear').value));
			objXMLApplet.setValue("USER_OPTION",trim(gid('MF:seluseroption').value));
			objXMLApplet.setValue("OLC_SL",gid("MF:txtcontsl").value);
			objXMLApplet.setValue("OLC_BRN_CODE",trim(gid('MF:txtbrncode').value));
			objXMLApplet.setValue("OLC_TYPE",trim(gid('MF:txtconttype').value));
			objXMLApplet.sendAndReceive();
			if(objXMLApplet.getValue("ErrorMsg") != "")
			{
      			setMsg(objXMLApplet.getValue("ErrorMsg"));
				gid('MF:txtcontsl').focus();
				return;  
			}
			else  
			{
				if(gid('MF:seluseroption').value=="A")
				{
					setTabfocus("maintab","tcontent1");
					gid("MF:txtpresanDate").focus();
					return;
				}
				else
				{ objTFMCharges.brncode=gid('MF:txtbrncode').value;
					objXMLApplet1.clearMap();         			
					objXMLApplet1.setValue("Package", "panaceaweb.utility");
					objXMLApplet1.setValue("SQLToken","Valolc1");
					Args = gid('MF:txtbrncode').value+"|"+gid('MF:txtconttype').value+"|"+gid('MF:txtcontyear').value+"|"+gid("MF:txtcontsl").value;
					objXMLApplet1.setValue ("Args",Args);
					objXMLApplet1.setValue("DataTypes","N|S|N|N");     
					objXMLApplet1.sendAndReceive();
					if (objXMLApplet1.getValue("ErrorMsg") != "")
					{	
						setMsg(objXMLApplet1.getValue("ErrorMsg"));
						gid('MF:txtcontsl').focus();
						return;
					} 
					if(objXMLApplet1.getValue("Result")=="RowPresent")
					{
					
					
					//ADDED BY PRASHANTH ON  29 JANUARY 2018
					//Changes Sanjay1 22-07-2019 Begin
					//gid('MF:txtConfirmedByBank').value=objXMLApplet1.getValue("OLC_LC_TO_BE_CNFRMD_BY_BK");
					//gid('MF:txtConfirmedBYBranch').value=objXMLApplet1.getValue("OLC_LC_TO_BE_CNFRMD_BY_BRN");
					//Changes Sanjay1 22-07-2019 Begin
				    //ADDED BY PRASHANTH ON  29 JANUARY 2018
					
						//CHANGED ADDED ON 27/05/2018 START
						if(gid("MF:txtconttype").value=="OLC")
						{
							FetchlcDetails();
						}
						//CHANGED ADDED ON 27/05/2018 END
						gid('MF:txtchargessl1').value=objXMLApplet1.getValue("TRANCHGS_CHGS_SL");
						gid('MF:txtconratesl1').value=objXMLApplet1.getValue("TRANCRATES_RATE_SL");
						gid('MF:txtinvenno1').value=objXMLApplet1.getValue("TRANSTLMNT_INV_NUM");
						
						gid('MF:txtprevlcdate').value=objXMLApplet1.getValue("OLC_LC_DATE");
						gid('MF:txtRefNo').value=objXMLApplet1.getValue("OLC_CORR_REF_NUM");
						gid('MF:txtpresanDate').value=objXMLApplet1.getValue("OLC_LC_PRESANC_DATE");
						gid('MF:txtpresansl').value=objXMLApplet1.getValue("OLC_LC_PRESANC_DAY_SL");
						gid('MF:txtLCDate').value=objXMLApplet1.getValue("OLC_LC_DATE");
						gid('MF:txtcustnum1').value=objXMLApplet1.getValue("OLC_CUST_NUM");
						gid('MF:txtBeneficiaryCode').value=objXMLApplet1.getValue("OLC_BENEF_CODE");
						gid('MF:txtBeneficiaryName').value=objXMLApplet1.getValue("OLC_BENEF_NAME");
						gid('MF:txtCountryCode').value=objXMLApplet1.getValue("OLC_BENEF_CNTRY_CODE");
						gid('MF:txtLcIssuedthruBank').value=objXMLApplet1.getValue("OLC_LC_ISS_BK_CODE");
						gid('MF:txtLcIssuedthruBranch').value=objXMLApplet1.getValue("OLC_LC_ISS_BRN_CODE");
						gid('MF:txtLcIssuedBranchName').value=objXMLApplet1.getValue("OLC_LC_ISS_BRN_NAME");
						var add11="";
			         				
						if(trim(objXMLApplet1.getValue("OLC_LC_ISS_BRN_ADD1"))!="")
							add11=add11+objXMLApplet1.getValue("OLC_LC_ISS_BRN_ADD1")+"\n";
						if(trim(objXMLApplet1.getValue("OLC_LC_ISS_BRN_ADD2"))!="")
							add11=add11+objXMLApplet1.getValue("OLC_LC_ISS_BRN_ADD2")+"\n";
						if(trim(objXMLApplet1.getValue("OLC_LC_ISS_BRN_ADD3"))!="")
							add11=add11+objXMLApplet1.getValue("OLC_LC_ISS_BRN_ADD3")+"\n";
						if(trim(objXMLApplet1.getValue("OLC_LC_ISS_BRN_ADD4"))!="")
							add11=add11+objXMLApplet1.getValue("OLC_LC_ISS_BRN_ADD4")+"\n";
						if(trim(objXMLApplet1.getValue("OLC_LC_ISS_BRN_ADD5"))!="")
							add11=add11+objXMLApplet1.getValue("OLC_LC_ISS_BRN_ADD5");
							
						gid('MF:txtAddress21').value=add11;
						
						gid('MF:txtLcIssuedOnplace').value=objXMLApplet1.getValue("OLC_LC_ISS_PLACE");
						gid('MF:txtLcIssuedOncntry').value=objXMLApplet1.getValue("OLC_LC_ISS_CNTRY");
						gid('MF:txtLCCurr').value=objXMLApplet1.getValue("OLC_LC_CURR_CODE");
						var olc_lccurrcode=gid('MF:txtLCCurr').value;
						var add="";
				         				
						if(trim(objXMLApplet1.getValue("OLC_BENEF_ADDR1"))!="")
							add=add+objXMLApplet1.getValue("OLC_BENEF_ADDR1")+"\n";
						if(trim(objXMLApplet1.getValue("OLC_BENEF_ADDR2"))!="")
							add=add+objXMLApplet1.getValue("OLC_BENEF_ADDR2")+"\n";
						if(trim(objXMLApplet1.getValue("OLC_BENEF_ADDR3"))!="")
							add=add+objXMLApplet1.getValue("OLC_BENEF_ADDR3")+"\n";
						if(trim(objXMLApplet1.getValue("OLC_BENEF_ADDR4"))!="")
							add=add+objXMLApplet1.getValue("OLC_BENEF_ADDR4")+"\n";
						if(trim(objXMLApplet1.getValue("OLC_BENEF_ADDR5"))!="")
							add=add+objXMLApplet1.getValue("OLC_BENEF_ADDR5");
							
						gid('MF:txtAddress1').value=add;
						gid('MF:lstAdThru').value=objXMLApplet1.getValue("OLC_LC_ADV_THRU");
						
						gid('MF:txtLCAmt').value=objXMLApplet1.getValue("OLC_LC_AMOUNT");
						setAmount('MF:txtLCAmt',gid("MF:txtLCAmt").value);	
						gid('MF:txtdeviationallow').value=objXMLApplet1.getValue("OLC_POS_DEV_ALLWD");
						setAmount('MF:txtdeviationallow',gid("MF:txtdeviationallow").value);	
						gid('MF:txtdeviationallow1').value=objXMLApplet1.getValue("OLC_NEG_DEV_ALLWD");
						setAmount('MF:txtdeviationallow1',gid("MF:txtdeviationallow1").value);	
						gid('MF:txtDeviationAmt').value=objXMLApplet1.getValue("OLC_DEV_AMOUNT");
						setAmount('MF:txtDeviationAmt',gid("MF:txtDeviationAmt").value);	
						gid('MF:lstAmtquali').value=objXMLApplet1.getValue("OLC_AMT_QUALFR");
						gid('MF:txtTermsOfprice').value=objXMLApplet1.getValue("OLC_PRICE_TERMS");
						gid('MF:txtLastDateOfNego').value=objXMLApplet1.getValue("OLC_LAST_DATE_OF_NEG");
						gid('MF:txtplaceOfexpy').value=objXMLApplet1.getValue("OLC_PLACE_OF_EXPIRY");
						gid('MF:txtLatestDateOfNego').value=objXMLApplet1.getValue("OLC_LATEST_DATE_OF_SHPMNT");
						//Changes P.Subramani-Chn-18/02/2008 Beg
						if(objXMLApplet1.getValue("OLC_DEV_ALLWD")=="1")
						{
							gid('MF:chkdeviationallowed').checked=true;
							gid('MF:outlbldeviallowed').innerText="Yes";
						}
						else
						{
							gid('MF:chkdeviationallowed').checked=false;
							gid('MF:outlbldeviallowed').innerText="No";
						}
						if(objXMLApplet1.getValue("OLC_WITHIN_VALIDATE_LC")=="1")
						{
							gid('MF:chkWithInValOfLC').checked=true;
							gid('MF:outlblWithInValOfLC').innerText="Yes";
						}
						else
						{
							gid('MF:chkWithInValOfLC').checked=false;
							gid('MF:outlblWithInValOfLC').innerText="No";
						}
						if(objXMLApplet1.getValue("OLC_LC_UI_BORNE_BY_APPLCNT")=="1")
						{
							gid('MF:chkUsanceInterest').checked=true;
							gid('MF:outlblUsanceInterest').innerText="Yes";
						}
						else
						{
							gid('MF:chkUsanceInterest').checked=false;
							gid('MF:outlblUsanceInterest').innerText="No";
						}
						gid('MF:txtDrawDowns').value=objXMLApplet1.getValue("OLC_NOF_TENORS");
						if(objXMLApplet1.getValue("OLC_LC_UNDER_CONTRACT")=="1")
						{
							gid('MF:chkLcunderCon').checked=true;
							gid('MF:outlblLcunderCon').innerText="Yes";
						}
						else
						{
							gid('MF:chkLcunderCon').checked=false;
							gid('MF:outlblLcunderCon').innerText="No";
						}
						//Changes P.Subramani-Chn-18/02/2008 End
						gid('MF:txtTotalAmt').value=objXMLApplet1.getValue("OLC_TOT_LIAB_LC_CURR");
						setAmount('MF:txtTotalAmt',gid("MF:txtTotalAmt").value);
						gid('MF:txtpresentLcLiaAmt').value=objXMLApplet1.getValue("OLC_TOT_LIAB_BASE_CURR");
						setAmount('MF:txtpresentLcLiaAmt',gid("MF:txtpresentLcLiaAmt").value);
						gid('MF:txtConRateToLimitCurr').value=objXMLApplet1.getValue("OLC_CONV_RATE_LIM_CURR");
						setAmount('MF:txtConRateToLimitCurr',gid("MF:txtConRateToLimitCurr").value);
						gid('MF:txtLcLiaAmtlimitAmt').value=objXMLApplet1.getValue("OLC_TOT_LIAB_LIM_CURR");
						setAmount('MF:txtLcLiaAmtlimitAmt',gid("MF:txtLcLiaAmtlimitAmt").value);
						gid("MF:txtpresentLcLiaCurr").value=baseCurrency;
						
						
						//Changes P.Subramani-Chn-11/04/2008 Beg
						gid('MF:txtusnchgscurr').value=baseCurrency;
						gid('MF:txtusnchgsamt').value = objXMLApplet1.getValue("OLC_USANCE_CHARGES");
						setAmount('MF:txtusnchgsamt',gid('MF:txtusnchgsamt').value);
						gid('MF:txtusnchgscurr1').value=baseCurrency;
						gid('MF:txtusnchgsamt1').value = objXMLApplet1.getValue("OLC_USANCE_CHARGES");
						setAmount('MF:txtusnchgsamt1',gid('MF:txtusnchgsamt1').value);
						gid('MF:txtusnchgstakendays').value=objXMLApplet1.getValue("OLC_USN_CHG_TAKEN_DAYS");
						gid('MF:txtcommchgscurr').value=baseCurrency;
						gid('MF:txtcommchgsamt').value = objXMLApplet1.getValue("OLC_COMMITMENT_CHARGES");
						setAmount('MF:txtcommchgsamt',gid('MF:txtcommchgsamt').value);
						gid('MF:txtcommchgscurr1').value=baseCurrency;
						gid('MF:txtcommchgsamt1').value = objXMLApplet1.getValue("OLC_COMMITMENT_CHARGES");
						setAmount('MF:txtcommchgsamt1',gid('MF:txtcommchgsamt1').value);
						gid('MF:txtcommchgstakendays').value=objXMLApplet1.getValue("OLC_COMMIT_CHG_TAKEN_DAYS");
						//Changes P.Subramani-Chn-11/04/2008 End
						//S.Suresh Babu Add 30-06-2009
						setAmount('MF:txtusanceservamt1',objXMLApplet1.getValue("OLC_USANCE_SERV_TAX"));
						setAmount('MF:txtcommservamt1',objXMLApplet1.getValue("OLC_COMMIT_SERV_TAX"));
						
						if(objXMLApplet1.getValue("TRANSTLMNT_INV_NUM")!=0)
						{
							if(trim(gid("MF:seluseroption").value)=="M")
							{
					    		invoiceNumber = objXMLApplet1.getValue("TRANSTLMNT_INV_NUM");
					    		objTranStmntPost.InventoryNumber = invoiceNumber;
					    		objTranStmntPost.FetchFromTable=true;
					    		objTranStmntPost.ResultType="MAIN";
					    		objTranStmntPost.SourceKey=gid("MF:txtbrncode").value+"|"+gid("MF:txtconttype").value+"|"+gid("MF:txtcontyear").value+"|"+gid("MF:txtcontsl").value;
							}
					    	else
							{
								objTranStmntPost.InventoryNumber = 0;
							}
							objTranStmntPost.AddOrModify=gid("MF:seluseroption").value;
							objTranStmntPost.SourceTable="OLC";
							objTranStmntPost.isDbCr = "D";
							//Changes P.Subramani-Chn-28/07/2008 Beg
							objTranStmntPost.TranCurrCode=baseCurrency;
							//objXMLApplet1.getValue("OLC_PAYMNT_CURR");//gid("InwardRemittanceDisposalForm:txtAmtTotDisCurr3").value;
							//Changes P.Subramani-Chn-28/07/2008 End
							objTranStmntPost.TranAmount=objXMLApplet1.getValue("OLC_TOT_CHRGS_IN_PAYMNT_CURR");
							objTranStmntPost.TranBaseCurrEqu=objXMLApplet1.getValue("OLC_TOT_CHRGS_IN_PAYMNT_CURR");
							objTranStmntPost.BranchCode=gid("MF:txtbrncode").value;
							objTranStmntPost.valueDate=objXMLApplet1.getValue("OLC_LC_DATE");
							objTranStmntPost.ProgramID="EOLC";
					    	objTranStmntPost.fetch();
						}
						objTFMCharges.AddOrModify = gid('MF:seluseroption').value;
						objTFMCharges.TRANCHGS_SL = objXMLApplet1.getValue("TRANCHGS_CHGS_SL");
						//SUGANYA BEGIN 23-MAY-2017
						trancrates_sl = objXMLApplet1.getValue("TRANCRATES_RATE_SL");
						trancharges_sl=  objXMLApplet1.getValue("TRANCHGS_CHGS_SL");
						//Changes P.Subramani-Chn-22/02/2008

   						/*if(olc_lccurrcode!=baseCurrency)
						{
							objCRates.branchcode = gid('MF:txtbrncode').value;
							objCRates.AddOrModify = gid('MF:seluseroption').value;
							objCRates.trandate = gid('MF:txtLCDate').value;
							
							if(gid('MF:txtcustnum1').value=="")
								objCRates.custnumber = 0;
							else
								objCRates.custnumber = gid('MF:txtcustnum1').value;
								
							objCRates.recovcurr =baseCurrency;
							objCRates.basecurrency =baseCurrency;
							objCRates.amttobeconv = objXMLApplet1.getValue("OLC_TOT_LIAB_LC_CURR");
							objCRates.salepurchflag = "S";
							objCRates.disbrecovflag = "R";
							objCRates.trancurrency = gid('MF:txtLCCurr').value;
							objCRates.SourceTable = "OLC";
							objCRates.currbusDate = currbusDate;
							objCRates.SourceKey = trim(
							gid('MF:txtbrncode').value+"|"+						
							gid('MF:txtconttype').value+"|"+
							gid('MF:txtcontyear').value+"|"+
							gid('MF:txtcontsl').value);
							objCRates.corrrefnum = gid('MF:txtRefNo').value;
							objCRates.TRANCRATES_SL = trancrates_sl;
							objCRates.validateComponentOnLoad();
							objCRates.Focus(false);	
						}*/
						FetchlimitDetails();
						//Changes P.Subramani-Chn-25/07/2008 Beg
						FetchLiabDetails();
						//Changes P.Subramani-Chn-25/07/2008 End
						FetchMarginvalues();
						FectchOlcoTextvalues();
						FetchShipTextValues();
						FetchShipTextValues1();
						FetchGridValues();
							//  CHN-prashanth -PATTERNS- 01-08-2017-TRSYCOMP_CHANGES.
						
						if(olc_lccurrcode!=baseCurrency){
						
						var U1=0;
						var X=0;
					 	for(var i=1;i<=gridEoladd.getRowsNum();i++)
						{
							U1=unFormat(gridEoladd.cells(i,12).getValue())*1;	
						}
						var X=unFormat(gid("MF:txtLCAmt").value)*1;
						gid('MF:txtTotalAmount').value=X+U1;
						objCRates.amttobeconv = gid('MF:txtTotalAmount').value;
						objCRates.recovcurr = baseCurrency;
						objCRates.basecurrency = baseCurrency;
						objCRates.trancurrency = gid('MF:txtLCCurr').value;
			
			// treasury changes by PRASHANTH chn 05-08-2017
					if(TSRY_ENABLED=='1'){
						gridConvRates.clearAll();
						if(!getConversionRateParams()){
						return false;
						}
					 	getConvRate();
						gid('MF:TFMCRatesDetails:txtconvamt').readOnly=true;
						gid('MF:TFMCRatesDetails:txtconvrate').readOnly=true;
						document.getElementById('dealdetails').style.visibility = "hidden";
						document.getElementById('dealdetails_trsy').style.visibility = "hidden";
						AddRowToGrid(gridConvRates);
						gridConvRates.cells(1,1).setValue("1");
						gid("MF:TFMCRatesDetails:selconvrates").value="1";
						updateRateValues();
						updateGridValues();
						setTabfocus("maintab","tcontent4");
						gid("MF:TFMCRatesDetails:cmdOk").focus();
				}
				else{
							objCRates.branchcode = gid('MF:txtbrncode').value;
							objCRates.trandate = gid('MF:txtLCDate').value;
							
							if(gid('MF:txtcustnum1').value=="")
								objCRates.custnumber = 0;
							else
								objCRates.custnumber = gid('MF:txtcustnum1').value;
								
							objCRates.recovcurr =baseCurrency;
							objCRates.basecurrency =baseCurrency;
							objCRates.amttobeconv = objXMLApplet1.getValue("OLC_TOT_LIAB_LC_CURR");
							objCRates.salepurchflag = "S";
							objCRates.disbrecovflag = "R";
							objCRates.trancurrency = gid('MF:txtLCCurr').value;
							objCRates.SourceTable = "OLC";
							objCRates.currbusDate = currbusDate;
							objCRates.corrrefnum = gid('MF:txtRefNo').value;
							objCRates.TRANCRATES_SL = trancrates_sl;
							objCRates.validateComponentOnLoad();
				}
											    //  CHN-prashanth -PATTERNS- 01-08-2017-TRSYCOMP_CHANGES.
											    objCRates.SourceKey = trim(
							gid('MF:txtbrncode').value+"|"+						
							gid('MF:txtconttype').value+"|"+
							gid('MF:txtcontyear').value+"|"+
							gid('MF:txtcontsl').value);
   							objCRates.AddOrModify = gid('MF:seluseroption').value;
											    
							objTFMCharges.brncode=gid('MF:txtbrncode').value;
							//SUGANYA END 23-MAY-2017
					    	//SUGANYA BEGIN 28-FEB-2017
					    	
					    	
					    	//changed by prashanth  17-08-2017-TRSYCOMP_CHANGES.
					    	getcustno();
						 	objTFMCharges.customerno=custno;
						 	//changed by prashanth  17-08-2017-TRSYCOMP_CHANGES.
						 	
						 	
						 	
						//SUGANYA END 28-FEB-2017
									//Vinoth.S-Chns-09-12-2010-Beg
							    	objTFMCharges.trandate = gid('MF:txtLCDate').value;
								    //Vinoth.S-Chns-09-12-2010-End
									objTFMCharges.validateComponentOnLoad();
						}
						setTabfocus("maintab","tcontent1");	
						gid("MF:txtLCDate").focus();
						return;
					}
				}
			}	
	    }
    }	 				
//-----------------------------------------------------------------------------------------------------------------------------

//Changes in EOLC on 01-Oct-2018 for setting the clob values start
function FetchClobData()
{
	objXMLApplet6.clearMap();
	objXMLApplet6.setValue("Package","panacea.OLCaction.eolcval");
	objXMLApplet6.setValue("Method","Split_clob_Data");
	objXMLApplet6.setValue("ValidateToken", "true");
	objXMLApplet6.setValue("OLC_YEAR",trim(gid('MF:txtcontyear').value));
	objXMLApplet6.setValue("OLC_SL",gid("MF:txtcontsl").value);
	objXMLApplet6.setValue("OLC_BRN_CODE",trim(gid('MF:txtbrncode').value));
	objXMLApplet6.setValue("OLC_TYPE",trim(gid('MF:txtconttype').value));
	objXMLApplet6.sendAndReceive();
	if (objXMLApplet6.getValue("ErrorMsg") != "")
	{	
		setMsg(objXMLApplet6.getValue("ErrorMsg"));
		gid('MF:txtcontsl').focus();
		return;
	}
	else
	{
		gid('MF:txtDesGood1').value=objXMLApplet6.getValue("LC_DESC_GOODS_SER1");
		gid('MF:txtDesGood2').value=objXMLApplet6.getValue("LC_DESC_GOODS_SER2");
		gid('MF:txtDesGood3').value=objXMLApplet6.getValue("LC_DESC_GOODS_SER3");
		gid('MF:txtDocRequired1').value=objXMLApplet6.getValue("LC_DOC_REQ1");
		gid('MF:txtDocRequired2').value=objXMLApplet6.getValue("LC_DOC_REQ2");
		gid('MF:txtDocRequired3').value=objXMLApplet6.getValue("LC_DOC_REQ3");
		gid('MF:txtAddCond1').value=objXMLApplet6.getValue("LC_ADD_CONDITION1");
		gid('MF:txtAddCond2').value=objXMLApplet6.getValue("LC_ADD_CONDITION2");
		gid('MF:txtAddCond3').value=objXMLApplet6.getValue("LC_ADD_CONDITION3");
		
	}		
}
//Changes in EOLC on 01-Oct-2018 for setting the clob values end
//--------------------------------------------------------------------------------------------------------------------------------
function FetchlcDetails()
{
					objXMLApplet3.clearMap();         			
					objXMLApplet3.setValue("Package", "panaceaweb.utility");
					objXMLApplet3.setValue("SQLToken","Valolcdetails");
					if(_copy !="C")
						Args = gid('MF:txtbrncode').value+"|"+gid('MF:txtconttype').value+"|"+gid('MF:txtcontyear').value+"|"+gid("MF:txtcontsl").value;
					else
						Args=copy_brn_code+"|"+gid('MF:txtconttype').value+"|"+copy_year+"|"+copy_sl;
					objXMLApplet3.setValue ("Args",Args);
					objXMLApplet3.setValue("DataTypes","N|S|N|N");     
					objXMLApplet3.sendAndReceive();
					if (objXMLApplet3.getValue("ErrorMsg") != "")
					{	
						setMsg(objXMLApplet3.getValue("ErrorMsg"));
						gid('MF:txtcontsl').focus();
						return;
					}
					if(objXMLApplet3.getValue("Result")=="RowPresent")
					{
					gid('MF:txtperiod').value =objXMLApplet3.getValue("LC_PER_PRESENTATION_DAY");
					gid('MF:txtpresentationdetails').value = objXMLApplet3.getValue("LC_PER_PRESENTATION_REMARKS"); 
					gid('MF:lstcredit').value=objXMLApplet3.getValue("LC_FORM_OF_DOC_CREDIT");
					gid('MF:txtRefPreAdv').value=objXMLApplet3.getValue("LC_REFERENCE_TO_PREADVICE");
					gid('MF:lstAppRule').value=objXMLApplet3.getValue("LC_APPLICABLE_RULES");
					
					if(objXMLApplet3.getValue("LC_APPLICANT_REQ") == "0")
					{
						gid('MF:chkAppBank').checked=false;
			    		gid('MF:outlblAppBank').innerText="No";
		    		}
		    		else
		    		{
		    			gid('MF:chkAppBank').checked=true;
			    		gid('MF:outlblAppBank').innerText="Yes";
		    		}
					gid('MF:lstBICdtl').value=objXMLApplet3.getValue("LC_APPLICANT_TYPE");
					if(trim(gid('MF:lstBICdtl').value) != "" && gid('MF:chkAppBank').checked == true)
					{
						gid('MF:lstAppBank').value= "2";
					}
					else
					{
						gid('MF:lstAppBank').value="1";
					}
					
					
					gid('MF:txtAppBicCode').value=objXMLApplet3.getValue("LC_APPLICANT_BIC_CODE");
					//gid('MF:txtAppBicBank').value=objXMLApplet3.getValue("TRANCRATES_RATE_SL");
					gid('MF:txtAppBicBrn').value=objXMLApplet3.getValue("LC_APPLICANT_BRN_CODE");
					gid('MF:txtAppBankName').value=objXMLApplet3.getValue("LC_APPLICANT_BNK_CODE");
					gid('MF:txtAppAcnt').value=objXMLApplet3.getValue("LC_APPLICANT_ROUTID");
					gid('MF:txtAppAddress').value=trim(objXMLApplet3.getValue("LC_APPLICANT_ADDR1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("LC_APPLICANT_ADDR2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_APPLICANT_ADDR3"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_APPLICANT_ADDR4"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_APPLICANT_ADDR5"));
					gid('MF:txtAppCntry').value=objXMLApplet3.getValue("LC_APPLICANT_CNTRY_CODE");
		
					
					gid('MF:lstAvl').value=objXMLApplet3.getValue("LC_AVAILABLE_WITH_CODETYP");
					gid('MF:lstAvlBICdtl').value=objXMLApplet3.getValue("LC_AVAILABLE_WITH_TYPE");
					
					gid('MF:txtAvlBicCode').value=objXMLApplet3.getValue("LC_AVAILABLE_WITH_CODE");
					//gid('MF:txtAvlBicBank').value=objXMLApplet3.getValue("TRANCRATES_RATE_SL");;
					gid('MF:txtAvlBicBrn').value=objXMLApplet3.getValue("LC_AVAILABLE_WITH_BRN_CODE");
		
					gid('MF:txtAvlBankName').value=objXMLApplet3.getValue("LC_AVAILABLE_WITH_BNK_CODE");;
					gid('MF:txtAvlAcnt').value=objXMLApplet3.getValue("LC_AVAILABLE_WITH_ROUTID");
					gid('MF:txtAvlAddress').value=trim(objXMLApplet3.getValue("LC_AVAILABLE_WITH_ADDR1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("LC_AVAILABLE_WITH_ADDR2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_AVAILABLE_WITH_ADDR3"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_AVAILABLE_WITH_ADDR4"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_AVAILABLE_WITH_ADDR5"));
					gid('MF:txtAvlCntry').value=objXMLApplet3.getValue("LC_AVAILABLE_WITH_CNTRY");
		
					gid('MF:txtDraft').value=trim(objXMLApplet3.getValue("LC_DRAFTS_AT1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("LC_DRAFTS_AT2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_DRAFTS_AT3"))
					
					if(objXMLApplet3.getValue("LC_DRAWEE_REQ") == "0")
					{
						gid('MF:chkDrawee').checked=false;
		    			gid('MF:outlblDrawee').innerText="No";	
		    		}
		    		else
		    		{
		    			gid('MF:chkDrawee').checked=true;
		    			gid('MF:outlblDrawee').innerText="Yes";	
		    		}	
					gid('MF:lstDrwBICdtl').value=objXMLApplet3.getValue("LC_DRAWEE_TYPE");
					gid('MF:txtDrwBicCode').value=objXMLApplet3.getValue("LC_DRAWEE_BIC_CODE");
					//gid('MF:txtDrwBicBank').value=objXMLApplet3.getValue("TRANCRATES_RATE_SL");
					gid('MF:txtDrwBicBrn').value=objXMLApplet3.getValue("LC_DRAWEE_BRN_CODE");
					gid('MF:txtDrwBankName').value=objXMLApplet3.getValue("LC_DRAWEE_BNK_CODE");
					gid('MF:txtDrwAcnt').value=objXMLApplet3.getValue("LC_DRAWEE_ROUTID");
					gid('MF:txtDrwAddress').value=trim(objXMLApplet3.getValue("LC_DRAWEE_ADDR1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("LC_DRAWEE_ADDR2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_DRAWEE_ADDR3"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_DRAWEE_ADDR4"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_DRAWEE_ADDR5"));
					gid('MF:txtDrwCntry').value=objXMLApplet3.getValue("LC_DRAWEE_CNTRY_CODE");
	
					gid('MF:txtMixedPaydtl').value=trim(objXMLApplet3.getValue("LC_MIXED_PAY_DETAILS1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("LC_MIXED_PAY_DETAILS2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_MIXED_PAY_DETAILS3"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_MIXED_PAY_DETAILS4"));
					gid('MF:txtDeferPaydtl').value=trim(objXMLApplet3.getValue("LC_DEFERRED_PAY_DETAILS1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("LC_DEFERRED_PAY_DETAILS2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_DEFERRED_PAY_DETAILS3"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_DEFERRED_PAY_DETAILS4"));
					
					gid('MF:lstparShip').value=objXMLApplet3.getValue("LC_PARTIAL_SHIPMENTS");
					gid('MF:lsttranShip').value=objXMLApplet3.getValue("LC_TRANSHIPMENT");
					gid('MF:txtTakCharge').value=objXMLApplet3.getValue("LC_PLACE_OF_TAKING_IN_CHARGE");
					gid('MF:txtPortLoad').value=objXMLApplet3.getValue("LC_PORT_OF_LOADING");
					gid('MF:txtPortDis').value=objXMLApplet3.getValue("LC_PORT_OF_DISCHARGE");
					gid('MF:txtPortDest').value=objXMLApplet3.getValue("LC_PLACE_OF_FINAL_DEST");
					
								
					FetchClobData();//Changes in EOLC on 01-Oct-2018									
					gid('MF:txtShipPeriod').value=trim(objXMLApplet3.getValue("LC_SHIPMENT_PERIOD1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("LC_SHIPMENT_PERIOD2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_SHIPMENT_PERIOD3"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_SHIPMENT_PERIOD4"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_SHIPMENT_PERIOD5")) +"\r\n"+"" +trim(objXMLApplet3.getValue("LC_SHIPMENT_PERIOD6"));
					
					
					
					

					gid('MF:txtCharge').value=trim(objXMLApplet3.getValue("LC_CHARGES1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("LC_CHARGES2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_CHARGES3"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_CHARGES4"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_CHARGES5")) +"\r\n"+"" +trim(objXMLApplet3.getValue("LC_CHARGES6"));
					
					gid('MF:lstConfInst').value=objXMLApplet3.getValue("LC_CONFIRMATION_INST");
					
					if(objXMLApplet3.getValue("LC_REIMB_REQ") == "0")
					{
						gid('MF:chkReimb').checked=false;
			    		gid('MF:outlblReimb').innerText="No";
		    		}
		    		else
		    		{
		    			gid('MF:chkReimb').checked=true;
			    		gid('MF:outlblReimb').innerText="Yes";
		    		}	
		    		//Changes Sanjay1 22-07-2019 Begin
					gid('MF:lstReimbcfmBank').value=objXMLApplet3.getValue("LC_CFM_REIMB_TYPE");
					gid('MF:txtReimcfmBicBrn').value=objXMLApplet3.getValue("LC_CFM_REIMB_BRN_CODE");
					gid('MF:txtReimcfmBicCode').value=objXMLApplet3.getValue("LC_CFM_REIMB_BIC_CODE");
					gid('MF:txtcfmReimAcnt').value=objXMLApplet3.getValue("LC_CFM_REIMB_ROUTID");
					gid('MF:txtcfmReimBankName').value=objXMLApplet3.getValue("LC_CFM_REIMB_BNK_CODE");
				    gid('MF:txtcfmReimAddress').value=trim(objXMLApplet3.getValue("LC_CFM_REIMB_ADDR1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("LC_CFM_REIMB_ADDR2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_CFM_REIMB_ADDR3"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_CFM_REIMB_ADDR4"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_CFM_REIMB_ADDR5"));
				    gid('MF:txtcfmReimCntry').value=objXMLApplet3.getValue("LC_CFM_REIMB_CNTRY_CODE");
					//Changes Sanjay1 22-07-2019 End
					gid('MF:lstReimbBank').value=objXMLApplet3.getValue("LC_REIMB_TYPE");
		
					gid('MF:txtReimBicCode').value=objXMLApplet3.getValue("LC_REIMB_BIC_CODE");
					//gid('MF:txtReimBicBank').value=objXMLApplet3.getValue("TRANCRATES_RATE_SL");
					gid('MF:txtReimBicBrn').value=objXMLApplet3.getValue("LC_REIMB_BRN_CODE");
					
					gid('MF:txtReimBankName').value=objXMLApplet3.getValue("LC_REIMB_BNK_CODE");
					gid('MF:txtReimAcnt').value=objXMLApplet3.getValue("LC_REIMB_ROUTID");
					gid('MF:txtReimAddress').value=trim(objXMLApplet3.getValue("LC_REIMB_ADDR1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("LC_REIMB_ADDR2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_REIMB_ADDR3"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_REIMB_ADDR4"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_REIMB_ADDR5"));
					gid('MF:txtReimCntry').value=objXMLApplet3.getValue("LC_REIMB_CNTRY_CODE");
	
					gid('MF:txtInstPay').value=trim(objXMLApplet3.getValue("LC_INST_PAYING1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("LC_INST_PAYING2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_INST_PAYING3"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_INST_PAYING4"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_INST_PAYING5")) +"\r\n"+"" + trim(objXMLApplet3.getValue("LC_INST_PAYING6"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("LC_INST_PAYING7"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_INST_PAYING8"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_INST_PAYING9"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_INST_PAYING10"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_INST_PAYING11"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_INST_PAYING12"));

					if(objXMLApplet3.getValue("LC_SECOND_ADV_REQ") == "0")
					{
						gid('MF:chkAdvise').checked=false;
		    			gid('MF:outlblAdvise').innerText="No";
		    		}
		    		else
		    		{
		    			gid('MF:chkAdvise').checked=true;
		    			gid('MF:outlblAdvise').innerText="Yes";
		    		}
		    		
		    		gid('MF:lstAdviseBank').value = objXMLApplet3.getValue("LC_SECOND_ADV_TYPE");	
		    		gid('MF:txtAdviseBicCode').value=objXMLApplet3.getValue("LC_SECOND_ADV_BIC_CODE");
					//gid('MF:txtAdviseBicBank').value=objXMLApplet3.getValue("TRANCRATES_RATE_SL");
					gid('MF:txtAdviseBicBrn').value=objXMLApplet3.getValue("LC_SECOND_ADV_BNK_CODE");

					//gid('MF:txtAdviseBankName').value=objXMLApplet3.getValue("TRANCRATES_RATE_SL");
					gid('MF:txtAdviseAddress').value=trim(objXMLApplet3.getValue("LC_SECOND_ADV_ADDR1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("LC_SECOND_ADV_ADDR2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_SECOND_ADV_ADDR3"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_SECOND_ADV_ADDR4"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_SECOND_ADV_ADDR5"));
					gid('MF:txtAdviseCntry').value=objXMLApplet3.getValue("LC_SECOND_ADV_CNTRYCODE");
					gid('MF:txtAdviseAcnt').value=objXMLApplet3.getValue("LC_SECOND_ADV_ROUTID");
					
					gid('MF:txtAdviseBankName').value=objXMLApplet3.getValue("LC_SECOND_ADV_BNK_CODE");
					gid('MF:txtSendInfo').value=trim(objXMLApplet3.getValue("LC_SNDR_REC_INFO1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("LC_SNDR_REC_INFO2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_SNDR_REC_INFO3"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_SNDR_REC_INFO4"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_SNDR_REC_INFO5"));
					gid('MF:txtrecbic').value=objXMLApplet3.getValue("LC_REC_BIC_CODE");
					appBiclist();
					avlBicList();
					draweeBicList();
					reimbBiclist();
					//Changes Sanjay1 22-07-2019 Begin
					reimbcfmBiclist();
					//Changes Sanjay1 22-07-2019 End
					AvlThrBiclist();
					if(_copy =="C")
					{ 
						setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1");
						gid('MF:txtRefPreAdv').focus() ;
					}
					}
					else if(objXMLApplet3.getValue("Result")=="RowNotPresent")
					{
						alert("No REcords Present To Copy LC Details");
					}
}

//-----------------------------------------------------------------------------------------------------------------------------												
	function FetchlimitDetails()
	{
	    gid("MF:txtproductcode").value=product_code;
		gid("MF:outlblproductcode").innerText=product_name;
		objXMLApplet2.clearMap();
		objXMLApplet2.setValue("Package","panacea.OLCaction.eolcval");
		objXMLApplet2.setValue("Method","olcSanctionDaySlkeypress");
        objXMLApplet2.setValue("ValidateToken", "true");
        objXMLApplet2.setValue("OLC_TYPE",trim(gid('MF:txtconttype').value));
        objXMLApplet2.setValue("OLC_YEAR",trim(gid('MF:txtcontyear').value));
		objXMLApplet2.setValue("USER_OPTION",trim(gid('MF:seluseroption').value));
		objXMLApplet2.setValue("OLC_DAY_SER",gid("MF:txtpresansl").value);
		objXMLApplet2.setValue("OLC_BRANCH_CODE",trim(gid('MF:txtbrncode').value));
		objXMLApplet2.setValue("OLC_ENTRY_DATE",trim(gid('MF:txtpresanDate').value));
		 //Changes M.S.JAYANTHI-Chn-11/11/2009 BEG
		objXMLApplet2.setValue("TNOMEN_INLAND_OVERSEAS",trim(gid('MF:txtinover').value));
		 //Changes M.S.JAYANTHI-Chn-11/11/2009 end
		objXMLApplet2.sendAndReceive();
	
		gid('MF:txtsanctionDate').value=objXMLApplet2.getValue("LCPS_DATE_OF_APPROVAL");
		var add="";
         				
		if(trim(objXMLApplet2.getValue("CLIENTS_ADDR1"))!="")
			add=add+objXMLApplet2.getValue("CLIENTS_ADDR1")+"\n";
		if(trim(objXMLApplet2.getValue("CLIENTS_ADDR2"))!="")
			add=add+objXMLApplet2.getValue("CLIENTS_ADDR2")+"\n";
		if(trim(objXMLApplet2.getValue("CLIENTS_ADDR3"))!="")
			add=add+objXMLApplet2.getValue("CLIENTS_ADDR3")+"\n";
		if(trim(objXMLApplet2.getValue("CLIENTS_ADDR4"))!="")
			add=add+objXMLApplet2.getValue("CLIENTS_ADDR4")+"\n";
		if(trim(objXMLApplet2.getValue("CLIENTS_ADDR5"))!="")
			add=add+objXMLApplet2.getValue("CLIENTS_ADDR5");
			
		gid('MF:txtAddress2').value=add;
				
		gid('MF:txtLcOfBranch').value=objXMLApplet2.getValue("LCPS_LC_BRANCH");
		gid('MF:outlblLcBranch').innerText=objXMLApplet2.getValue("MBRN_NAME");
		intaccno=objXMLApplet2.getValue("INTERNAL_ACNT_NUM");
		limitdecilen=objXMLApplet2.getValue("LIMIT_DEC_LEN");
		gid('MF:txtcustnum1').value=objXMLApplet2.getValue("LCPS_CUST_NUM");
		gid('MF:outlblcustnum1').innerText=objXMLApplet2.getValue("CLIENTS_NAME");
		gid("MF:txtintaccno").value=objXMLApplet2.getValue("LCPS_CUST_LIAB_ACC_NUM");
		gid("MF:txtcustlcliaAcc").value=objXMLApplet2.getValue("LCPS_CUST_LIAB_ACC_NUM1");
		gid('MF:outlblcustlcliaAcc').innerText=objXMLApplet2.getValue("ACNT_NAME");
		gid("MF:txtLimitLineNo").value=objXMLApplet2.getValue("LCPS_LIMIT_LINE_NUM");
		gid('MF:outlblLimitLineNo').innerText=objXMLApplet2.getValue("LMTLINE_FACILITY_DESCN");
		gid("MF:txtFacilityCurr").value=objXMLApplet2.getValue("LCPS_LIM_CURR");
		gid("MF:outlblFacilityCurr").innerText=objXMLApplet2.getValue("CURR_NAME1");
		gid("MF:txtpresentLcLiaCurr").value=baseCurrency;
		
		//Removed P.Subramani-Chn-22/07/2008 Beg				
		/*gid("MF:txtLcoutStandcurr").value=objXMLApplet2.getValue("CURR_CODE");
		gid("MF:txtBilloutStandcurr").value=objXMLApplet2.getValue("CURR_CODE");
		gid("MF:txtCrystalBillsOscurr").value=objXMLApplet2.getValue("CURR_CODE");
		gid("MF:txtTotalOsLiabilitycurr").value=objXMLApplet2.getValue("CURR_CODE");
		gid("MF:txtBilloutStandAmt").value=0;
		gid("MF:txtCrystalBillsOs").value=0;
		setAmount('MF:txtLcoutStandAmt',objXMLApplet2.getValue("EFF_BAL"));
		setAmount('MF:txtBilloutStandAmt',gid("MF:txtBilloutStandAmt").value);
		setAmount('MF:txtCrystalBillsOs',gid("MF:txtCrystalBillsOs").value);
		var lcout=objXMLApplet2.getValue("EFF_BAL");
		var billout=unFormat(gid("MF:txtBilloutStandAmt").value)*1;
		var crysout=unFormat(gid("MF:txtCrystalBillsOs").value)*1;
		var a=1*(lcout)+1*(billout)+1*(crysout);
		gid("MF:txtTotalOsLiabilityAmt").value=a;
		setAmount('MF:txtTotalOsLiabilityAmt',gid("MF:txtTotalOsLiabilityAmt").value);	*/
    	//Removed P.Subramani-Chn-22/07/2008 End
	}
//-----------------------------------------------------------------------------------------------------------------------------													
	//Changes P.Subramani-Chn-25/07/2008 Beg
	function FetchLiabDetails()
	{
		objXMLApplet.clearMap();
		objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
		objXMLApplet.setValue("ValidateToken","true");
		objXMLApplet.setValue("Method","olcConvRateLimCurrkeypress");
		objXMLApplet.setValue("OLC_LC_CURR",gid('MF:txtLCCurr').value);
		objXMLApplet.setValue("OLC_LIMIT_CURR",gid('MF:txtFacilityCurr').value);
		objXMLApplet.setValue("TOTAL",unFormat(trim(gid('MF:txtTotalAmt').value)));
		objXMLApplet.setValue("OLC_CONV_RATE_LIM_CURR",gid('MF:txtConRateToLimitCurr').value);
		objXMLApplet.setValue("OLC_LIMIT_LINE_NO",gid('MF:txtLimitLineNo').value);
		objXMLApplet.setValue("OLC_CUST_NO",gid('MF:txtcustnum1').value);
		objXMLApplet.setValue("OLC_BRANCH_CODE",gid('MF:txtbrncode').value);
		objXMLApplet.setValue("OLC_INTERNAL_ACC_NO",intaccno);
		//Vinoth S Changes on 08-Dec-2010 Beg For Rounding Off Value
		objXMLApplet.setValue("TRAN_DATE",gid('MF:txtLCDate').value);
		objXMLApplet.setValue("TYPE","N");
	    //Vinoth S Changes on 08-Dec-2010 End
		objXMLApplet.sendAndReceive();

		limitdecilen=objXMLApplet.getValue("DEC_LEN2");
		gid("MF:txtLcLiaAmtlimitCurr").value=gid('MF:txtFacilityCurr').value;
		 //Vinoth S Changes on 08-Dec-2010 Beg
		//setAmount('MF:txtamtinbasecurra',objXMLApplet.getValue("AGAINST_AMT"));Removed
		gid('MF:txtLcLiaAmtlimitAmt').value=objXMLApplet.getValue("AMT_AGNST_CURR");
		 //Vinoth S Changes on 08-Dec-2010 End
		gid("MF:txtFacilitylimitCurr").value=objXMLApplet.getValue("SANC_CURR");
		gid("MF:txtoutstandingbeforeLcCurr").value=objXMLApplet.getValue("SANC_CURR");
		gid("MF:txtLcPendingCurr").value=objXMLApplet.getValue("SANC_CURR");
		gid("MF:txtoutstandingafterLcCurr").value=objXMLApplet.getValue("SANC_CURR");
		//commented on 07-Jul-2018 start
		//gid("MF:txtLcPendingAmt").value=objXMLApplet.getValue("PEND_AMT");
		//setAmount('MF:txtLcPendingAmt',objXMLApplet.getValue("PEND_AMT"));
		// commented on 07-Jul-2018 end
		//changes in eolc on 07-Jul-2018 start
		gid("MF:txtLcPendingAmt").value=gid('MF:txtLcLiaAmtlimitAmt').value;
		setAmount('MF:txtLcPendingAmt',gid('MF:txtLcLiaAmtlimitAmt').value);
		//changes in eolc on 07-Jul-2018 end
		//gid("MF:txtExcessOverCurr").value=objXMLApplet.getValue("SANC_CURR");
		gid("MF:txtExcOverlimitDueCurrTrancurr").value=objXMLApplet.getValue("SANC_CURR");
		setAmount('MF:txtFacilitylimitAmt',objXMLApplet.getValue("SANC_AMT"));

		var outstd_amt;
		var outstd_amt1;
		var outstd_amt3;
		//Changes P.Subramani-Chn-10/09/2008 Beg
		var  lcliabamtlimtamt;
		lcliabamtlimtamt=parseFloat(unFormat(gid("MF:txtLcLiaAmtlimitAmt").value));
		//Changes P.Subramani-Chn-10/09/2008 End
		outstd_amt = parseFloat(unFormat(objXMLApplet.getValue("OUTSTD_AMT")));
		if(outstd_amt < 0)
		{
			outstd_amt1 = outstd_amt * (-1);
			outstd_amt3 = outstd_amt;//ADDED ON 31/10/2018
			//Changes P.Subramani-Chn-10/09/2008 Beg
			if(gid('MF:seluseroption').value=="A")
			{
				gid('MF:txtoutstandingbeforeLcAmt').value=outstd_amt1;
			}
			else
			{
				if(outstd_amt1 > lcliabamtlimtamt)
				{
					gid('MF:txtoutstandingbeforeLcAmt').value=outstd_amt1-lcliabamtlimtamt;
				}
				else
				{
					gid('MF:txtoutstandingbeforeLcAmt').value=lcliabamtlimtamt-outstd_amt1;
				}	
			}	
			//Changes P.Subramani-Chn-10/09/2008 End
		}
		else
		{
			//Changes P.Subramani-Chn-10/09/2008 Beg
			if(gid('MF:seluseroption').value=="A")
			{
				gid('MF:txtoutstandingbeforeLcAmt').value=outstd_amt;
			}
			else
			{
				if(outstd_amt > lcliabamtlimtamt)
				{
					gid('MF:txtoutstandingbeforeLcAmt').value=outstd_amt-lcliabamtlimtamt;
				}
				else
				{
					gid('MF:txtoutstandingbeforeLcAmt').value=lcliabamtlimtamt-outstd_amt;
				}
			}	
			//Changes P.Subramani-Chn-10/09/2008 End
		}
		setAmount('MF:txtoutstandingbeforeLcAmt',gid('MF:txtoutstandingbeforeLcAmt').value);
		
		// Changes in eolc on 07-Jul-2018 start  
				
				objXMLApplet5.clearMap();
				objXMLApplet5.setValue("Package","panacea.OLCaction.eolcval");
				objXMLApplet5.setValue("ValidateToken","true");
				objXMLApplet5.setValue("Method","olclimitvalue");
				objXMLApplet5.setValue("OLC_BRN_CODE",gid('MF:txtbrncode').value);
				objXMLApplet5.setValue("OLC_DAY_SERIAL",gid('MF:txtpresansl').value);
				objXMLApplet5.setValue("OLC_ENTRY_DATE",gid('MF:txtpresanDate').value);
				objXMLApplet5.setValue("OLC_OUTSANDING_AMT",outstd_amt3);//MODIFIED ON 31/10/2018
				objXMLApplet5.setValue("OLC_LC_PENDING_AMT",gid("MF:txtLcPendingAmt").value);
				objXMLApplet5.sendAndReceive();
				var unused_limit;
				var after_lc;
				var excess_limit;
						
				unused_limit=objXMLApplet5.getValue("UNUSED_LIMIT_BAL");
				after_lc=objXMLApplet5.getValue("AFTER_LC");
				excess_limit=objXMLApplet5.getValue("EXCESS_LIMIT");
				
				gid('MF:txtunusedlimitCurr').value=objXMLApplet.getValue("SANC_CURR");
				gid('MF:txtunusedlimitAmt').value = unused_limit;
				setAmount('MF:txtunusedlimitAmt',gid('MF:txtunusedlimitAmt').value);
				gid('MF:txtoutstandingafterLcAmt').value = after_lc;
				setAmount('MF:txtoutstandingafterLcAmt',gid('MF:txtoutstandingafterLcAmt').value);
				gid('MF:txtExcOverlimitDueCurrTrancurrAmt').value = excess_limit;
				setAmount('MF:txtExcOverlimitDueCurrTrancurrAmt',gid('MF:txtExcOverlimitDueCurrTrancurrAmt').value);
				if(objXMLApplet5.getValue("ErrorMsg") != "")
				{
					setMsg(objXMLApplet5.getValue("ErrorMsg"));
					//gid('MF:txtConRateToLimitCurr').focus();
					return;  
				}
				// Changes in eolc on 07-Jul-2018  end
		
		var lcliaamtlimitcurr = unFormat(gid("MF:txtLcLiaAmtlimitAmt").value)*1;
		var pamt=unFormat(gid("MF:txtLcPendingAmt").value)*1;
		var osamt=unFormat(gid("MF:txtoutstandingbeforeLcAmt").value)*1;
		var osaftlc= (lcliaamtlimitcurr)+ (osamt) + (pamt);
		/*gid('MF:txtoutstandingafterLcAmt').value = osaftlc;
		setAmount('MF:txtoutstandingafterLcAmt',gid('MF:txtoutstandingafterLcAmt').value); commented on 07-Jul-2018*/
		
		//gid("MF:txtExcessOverAmt").value=""; commented on 07-Jul-2018
		//gid("MF:txtExcOverlimitDueCurrTrancurrAmt").value="";
				
		if( unFormat(gid('MF:txtoutstandingafterLcAmt').value)*1 > unFormat(gid('MF:txtFacilitylimitAmt').value)*1)
		{
			var _outstdaftlc1 = unFormat(trim(gid('MF:txtoutstandingafterLcAmt').value));
			var _faclmt = unFormat(trim(gid('MF:txtFacilitylimitAmt').value));
			var _excoverlmt = (_outstdaftlc1) - (_faclmt);
			//commented on 07-Jul-2018 start
			//gid('MF:txtExcessOverAmt').value = _excoverlmt ;
			//setAmount('MF:txtExcessOverAmt',gid('MF:txtExcessOverAmt').value);
			// commented on 07-Jul-2018 end
		}
		
		/*if(!gid('MF:txtExcessOverAmt').value=="")
		{
			if( unFormat(gid('MF:txtExcessOverAmt').value)*1 < unFormat(gid('MF:txtLcLiaAmtlimitAmt').value)*1 )
			{
			  gid('MF:txtExcOverlimitDueCurrTrancurrAmt').value = gid('MF:txtExcessOverAmt').value;
			  setAmount('MF:txtExcOverlimitDueCurrTrancurrAmt',gid('MF:txtExcOverlimitDueCurrTrancurrAmt').value);
			}
			else if( unFormat(gid('MF:txtExcessOverAmt').value)*1 > unFormat(gid('MF:txtLcLiaAmtlimitAmt').value)*1 )
			{
			  gid('MF:txtExcOverlimitDueCurrTrancurrAmt').value = gid('MF:txtLcLiaAmtlimitAmt').value;
			  setAmount('MF:txtExcOverlimitDueCurrTrancurrAmt',gid('MF:txtExcOverlimitDueCurrTrancurrAmt').value);
			}
		} commented on 07-Jul-2018 */
	}
	//Changes P.Subramani-Chn-25/07/2008 End		
//-----------------------------------------------------------------------------------------------------------------------------												
	function FetchMarginvalues()
	{	
		objXMLApplet1.clearMap();         			
		objXMLApplet1.setValue("Package", "panaceaweb.utility");
		objXMLApplet1.setValue("SQLToken","Valolc4");
		Args = gid('MF:txtbrncode').value+"|"+gid('MF:txtconttype').value+"|"+gid('MF:txtcontyear').value+"|"+gid("MF:txtcontsl").value;
		objXMLApplet1.setValue ("Args",Args);
		objXMLApplet1.setValue("DataTypes","N|S|N|N");     
		objXMLApplet1.sendAndReceive();
		
		if(objXMLApplet1.getValue("Result")=="RowPresent")
		{
			gid('MF:txtmargincurr').value=objXMLApplet1.getValue("OLCM_MARGIN_CURR");
			if(objXMLApplet1.getValue("OLCM_MARGIN_PERC")==0)
			{
				gid('MF:txtmarginpercentage').value="";
			}
			else
			{
				gid('MF:txtmarginpercentage').value=objXMLApplet1.getValue("OLCM_MARGIN_PERC");
			}
			if(objXMLApplet1.getValue("OLCM_EX_OVER_LIMIT_MARGIN_PERC")==0)
			{
				gid('MF:txtmarginpercentage1').value="";
			}
			else
			{
				gid('MF:txtmarginpercentage1').value=objXMLApplet1.getValue("OLCM_EX_OVER_LIMIT_MARGIN_PERC");
			}
			gid('MF:txtmarginamtcurr').value=objXMLApplet1.getValue("OLCM_MARGIN_CURR");
			if(objXMLApplet1.getValue("OLCM_MARGIN_AMT")==0)
			{
				gid('MF:txtmarginamt1').value="";
			}
			else
			{
				gid('MF:txtmarginamt1').value=objXMLApplet1.getValue("OLCM_MARGIN_AMT");
			}
			if(objXMLApplet1.getValue("OLCM_EX_OVER_LIMIT_MARGIN_AMT")==0)
			{
				gid('MF:txtmarginamt2').value="";
			}
			else
			{
				gid('MF:txtmarginamt2').value=objXMLApplet1.getValue("OLCM_EX_OVER_LIMIT_MARGIN_AMT");
			}
			gid('MF:txtcashmargincurr').value=objXMLApplet1.getValue("OLCM_MARGIN_CURR");
			if(objXMLApplet1.getValue("OLCM_CASH_MARGIN_AMT")==0)
			{
				gid('MF:txtcashmarginamt1').value="";
			}
			else
			{
				gid('MF:txtcashmarginamt1').value=objXMLApplet1.getValue("OLCM_CASH_MARGIN_AMT");
			}
			if(objXMLApplet1.getValue("OLCM_EOL_CASH_MARGIN_AMT")==0)
			{
				gid('MF:txtcashmarginamt2').value="";
			}
			else
			{
				gid('MF:txtcashmarginamt2').value=objXMLApplet1.getValue("OLCM_EOL_CASH_MARGIN_AMT");
			}
			gid('MF:lstmargintypeforLC').value=objXMLApplet1.getValue("OLCM_MARGIN_TYPE");
			gid('MF:lstmargintypeforLC').value=objXMLApplet1.getValue("OLCM_MARGIN_TYPE");
			//gid('MF:txtExcOverlimitDueCurrTrancurrAmt').value=objXMLApplet1.getValue("OLCM_EX_OVER_LIMIT");
		}
	}	
//-----------------------------------------------------------------------------------------------------------------------------													
	function FectchOlcoTextvalues()
	{
		objXMLApplet1.clearMap();         			
		objXMLApplet1.setValue("Package", "panaceaweb.utility");
		objXMLApplet1.setValue("SQLToken","Valolc2");
		Args = gid('MF:txtbrncode').value+"|"+gid('MF:txtconttype').value+"|"+gid('MF:txtcontyear').value+"|"+gid("MF:txtcontsl").value;
		objXMLApplet1.setValue ("Args",Args);
		objXMLApplet1.setValue("DataTypes","N|S|N|N");     
		objXMLApplet1.sendAndReceive();
		
		if(objXMLApplet1.getValue("Result")=="RowPresent")
		{
			var add="";
	        if(trim(objXMLApplet1.getValue("OLCOTX_ADDTNL_AMT_CVRD1"))!="")
				add=add+objXMLApplet1.getValue("OLCOTX_ADDTNL_AMT_CVRD1")+"\n";
			if(trim(objXMLApplet1.getValue("OLCOTX_ADDTNL_AMT_CVRD2"))!="")
				add=add+objXMLApplet1.getValue("OLCOTX_ADDTNL_AMT_CVRD2")+"\n";
			if(trim(objXMLApplet1.getValue("OLCOTX_ADDTNL_AMT_CVRD3"))!="")
				add=add+objXMLApplet1.getValue("OLCOTX_ADDTNL_AMT_CVRD3")+"\n";
			if(trim(objXMLApplet1.getValue("OLCOTX_ADDTNL_AMT_CVRD4"))!="")
				add=add+objXMLApplet1.getValue("OLCOTX_ADDTNL_AMT_CVRD4")+"\n";
			gid('MF:txtAdditionalamtcover').value=add;
		}
	}
//-----------------------------------------------------------------------------------------------------------------------------														
	function FetchGridValues()
	{
		objXMLAppletGrid.clearMap();         			
		objXMLAppletGrid.setValue("Package", "panaceaweb.utility");
		objXMLAppletGrid.setValue("SQLToken","Valolc5");
		Args = gid('MF:txtbrncode').value+"|"+gid('MF:txtconttype').value+"|"+gid('MF:txtcontyear').value+"|"+gid("MF:txtcontsl").value;
		objXMLAppletGrid.setValue ("Args",Args);
		objXMLAppletGrid.setValue("DataTypes","N|S|N|N");
		objXMLAppletGrid.setValue("GridToken","FetchGridData");       
		objXMLAppletGrid.sendAndReceive();
		
		if(objXMLAppletGrid.getValue("Result")=="RowPresent")
		{
			gridEoladd.clearAll();	
			gridEoladd.setxmlcolumn("0,1,0,1,1,1,1,1,0,1,0,0,1,1");
			gridEoladd.loadXMLString(objXMLAppletGrid.getValue("GetGridData"));
			//Changes P.Subramani-Chn-25/07/2008 
			LcCompValue(row,col);
		}
	}
//-----------------------------------------------------------------------------------------------------------------------------															
	function FetchShipTextValues()
	{
		objXMLApplet1.clearMap();         			
		objXMLApplet1.setValue("Package", "panaceaweb.utility");
		objXMLApplet1.setValue("SQLToken","Valolc6");
		Args = gid('MF:txtbrncode').value+"|"+gid('MF:txtconttype').value+"|"+gid('MF:txtcontyear').value+"|"+gid("MF:txtcontsl").value;
		objXMLApplet1.setValue ("Args",Args);
		objXMLApplet1.setValue("DataTypes","N|S|N|N");     
		objXMLApplet1.sendAndReceive();
		
		if(objXMLApplet1.getValue("Result")=="RowPresent")
		{
			var add="";
	        if(trim(objXMLApplet1.getValue("OLCST_TEXT1"))!="")
				add=add+objXMLApplet1.getValue("OLCST_TEXT1")+"\n";
			if(trim(objXMLApplet1.getValue("OLCST_TEXT2"))!="")
				add=add+objXMLApplet1.getValue("OLCST_TEXT2")+"\n";
			if(trim(objXMLApplet1.getValue("OLCST_TEXT3"))!="")
				add=add+objXMLApplet1.getValue("OLCST_TEXT3")+"\n";
			if(trim(objXMLApplet1.getValue("OLCST_TEXT4"))!="")
				add=add+objXMLApplet1.getValue("OLCST_TEXT4")+"\n";
			gid('MF:txtShipmentperod').value=add;
		}
	}
//-----------------------------------------------------------------------------------------------------------------------------														
	function FetchShipTextValues1()
	{
		objXMLApplet1.clearMap();         			
		objXMLApplet1.setValue("Package", "panaceaweb.utility");
		objXMLApplet1.setValue("SQLToken","Valolc3");
		Args = gid('MF:txtbrncode').value+"|"+gid('MF:txtconttype').value+"|"+gid('MF:txtcontyear').value+"|"+gid("MF:txtcontsl").value;
		objXMLApplet1.setValue ("Args",Args);
		objXMLApplet1.setValue("DataTypes","N|S|N|N");     
		objXMLApplet1.sendAndReceive();
		
		if(objXMLApplet1.getValue("Result")=="RowPresent")
		{
			var add="";
	        if(trim(objXMLApplet1.getValue("OLCST_TEXT1"))!="")
				add=add+objXMLApplet1.getValue("OLCST_TEXT1")+"\n";
			if(trim(objXMLApplet1.getValue("OLCST_TEXT2"))!="")
				add=add+objXMLApplet1.getValue("OLCST_TEXT2")+"\n";
			if(trim(objXMLApplet1.getValue("OLCST_TEXT3"))!="")
				add=add+objXMLApplet1.getValue("OLCST_TEXT3")+"\n";
			if(trim(objXMLApplet1.getValue("OLCST_TEXT4"))!="")
				add=add+objXMLApplet1.getValue("OLCST_TEXT4")+"\n";
			gid('MF:txtpresentationdetails').value=add;
		}
	}
//-----------------------------------------------------------------------------------------------------------------------------														
	function validatePresanctonDate()	
    {
		if(trim(gid('MF:txtpresanDate').value)=="")
     	{
     		gid('MF:txtpresanDate').value=currbusDate;
     		gid('MF:txtpresanDate').focus;
     	}
        else         
     	{
        	var dateok;
      		var dateobj=parseDate(gid('MF:txtpresanDate').value,"true");
  			if(dateobj==null)
  			{   
  				setMsg(INVALIDDATE);
  				return false;
  			}
  			dateobj = formatDate(dateobj,'dd-MM-yyyy');		
	    	gid('MF:txtpresanDate').value =dateobj;
			dateok = isDate(gid('MF:txtpresanDate').value,'dd-MM-yyyy');
			if (dateok == 1)
			{
				setMsg(INVALIDDATE);
				gid('MF:txtpresanDate').focus();
				return ;
			}		  
			var dateobj=parseDate(gid('MF:txtpresanDate').value,"true");
	        dateobj = formatDate(dateobj,'dd-MM-yyyy');
			gid('MF:txtpresanDate').value =dateobj;	
			dateok =compareDates(dateobj,'dd-MM-yyyy',currbusDate,'dd-MM-yyyy');
			if (dateok == 2) 
			{
				setMsg(DATE_LESS_EQ_CBD);
				gid('MF:txtpresanDate').focus();
				return ;
			}
			else if (dateok == -1) 
			{
				setMsg(INVALIDDATE);
				gid('MF:txtpresanDate').focus();
				return ;
			}
			else
			{
				objXMLApplet.clearMap();
    			objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
				objXMLApplet.setValue("ValidateToken","true");
				objXMLApplet.setValue("Method","olcPresanctionDatekeypress");
				objXMLApplet.setValue("CBD",currbusDate);
				objXMLApplet.setValue("OLC_SANCTION_DATE",gid('MF:txtpresanDate').value);
				objXMLApplet.sendAndReceive();
				if(objXMLApplet.getValue("ErrorMsg") != "")
	      		{
		      		setMsg(objXMLApplet.getValue("ErrorMsg"));
		      		setTabfocus("maintab","tcontent1");	
		      		gid('MF:txtpresanDate').focus();		
					return;
				}
				else
				{
					setTabfocus("maintab","tcontent1");
				    gid('MF:txtpresansl').focus();
				}
			}
	   }
   }	   		
//-----------------------------------------------------------------------------------------------------------------------------												
	function validatePresanctonDaySl()
    {
   		if(gid("MF:txtpresansl").value=="")
		{
			setMsg(BLANK_CHECK);
			gid("MF:txtpresansl").focus();
			return;
		}
		else if(gid("MF:txtpresansl").value==0)
		{
			setMsg(ZERO_CHECK);
			gid("MF:txtpresansl").focus();
			return;
		}
		else
		{
			objXMLApplet.clearMap();
			objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
			objXMLApplet.setValue("Method","olcSanctionDaySlkeypress");
	        objXMLApplet.setValue("ValidateToken", "true");
	        objXMLApplet.setValue("OLC_TYPE",trim(gid('MF:txtconttype').value));
	        objXMLApplet.setValue("OLC_YEAR",trim(gid('MF:txtcontyear').value));
			objXMLApplet.setValue("USER_OPTION",trim(gid('MF:seluseroption').value));
			objXMLApplet.setValue("OLC_DAY_SER",gid("MF:txtpresansl").value);
			objXMLApplet.setValue("OLC_BRANCH_CODE",trim(gid('MF:txtbrncode').value));
			objXMLApplet.setValue("OLC_ENTRY_DATE",trim(gid('MF:txtpresanDate').value));
			 //Changes M.S.JAYANTHI-Chn-11/11/2009 BEG
			objXMLApplet.setValue("TNOMEN_INLAND_OVERSEAS",trim(gid('MF:txtinover').value));
			 //Changes M.S.JAYANTHI-Chn-11/11/2009 end
			objXMLApplet.sendAndReceive();
			if(objXMLApplet.getValue("ErrorMsg") != "")
			{
      			setMsg(objXMLApplet.getValue("ErrorMsg"));
				gid('MF:txtpresansl').focus();
				return;  
			}
			else  
			{
				limitdecilen="";
				lcpsmarginper=unFormat(objXMLApplet.getValue("LCPS_MARG_PERC"));
				gid("MF:txtDrawDowns").value=objXMLApplet.getValue("LCPS_NO_OF_TENORS");
				gid('MF:txtsanctionDate').value=objXMLApplet.getValue("LCPS_DATE_OF_APPROVAL");
				var add="";
         				
				if(trim(objXMLApplet.getValue("CLIENTS_ADDR1"))!="")
					add=add+objXMLApplet.getValue("CLIENTS_ADDR1")+"\n";
				if(trim(objXMLApplet.getValue("CLIENTS_ADDR2"))!="")
					add=add+objXMLApplet.getValue("CLIENTS_ADDR2")+"\n";
				if(trim(objXMLApplet.getValue("CLIENTS_ADDR3"))!="")
					add=add+objXMLApplet.getValue("CLIENTS_ADDR3")+"\n";
				if(trim(objXMLApplet.getValue("CLIENTS_ADDR4"))!="")
					add=add+objXMLApplet.getValue("CLIENTS_ADDR4")+"\n";
				if(trim(objXMLApplet.getValue("CLIENTS_ADDR5"))!="")
					add=add+objXMLApplet.getValue("CLIENTS_ADDR5");
			
				gid('MF:txtAddress2').value=add;
		
				gid('MF:txtLcOfBranch').value=objXMLApplet.getValue("LCPS_LC_BRANCH");
				gid('MF:outlblLcBranch').innerText=objXMLApplet.getValue("MBRN_NAME");
				intaccno=objXMLApplet.getValue("INTERNAL_ACNT_NUM");
				limitdecilen=objXMLApplet.getValue("LIMIT_DEC_LEN");
			
				gid('MF:txtBeneficiaryCode').value=objXMLApplet.getValue("LCPS_BENEF_CODE");
				gid('MF:txtBeneficiaryName').value=objXMLApplet.getValue("LCPS_BENEF_NAME");
	       		gid('MF:txtCountryCode').value=objXMLApplet.getValue("LCPS_BENEF_CNTRY");
	       		var add1="";
	         				
				if(trim(objXMLApplet.getValue("CPARTY_ADDR1"))!="")
					add1=add1+objXMLApplet.getValue("CPARTY_ADDR1")+"\n";
				if(trim(objXMLApplet.getValue("CPARTY_ADDR2"))!="")
					add1=add1+objXMLApplet.getValue("CPARTY_ADDR2")+"\n";
				if(trim(objXMLApplet.getValue("CPARTY_ADDR3"))!="")
					add1=add1+objXMLApplet.getValue("CPARTY_ADDR3")+"\n";
				if(trim(objXMLApplet.getValue("CPARTY_ADDR4"))!="")
					add1=add1+objXMLApplet.getValue("CPARTY_ADDR4")+"\n";
				if(trim(objXMLApplet.getValue("CPARTY_ADDR5"))!="")
					add1=add1+objXMLApplet.getValue("CPARTY_ADDR5");
					
				gid('MF:txtAddress1').value=add1;	
		
				gid('MF:txtcustnum1').value=objXMLApplet.getValue("LCPS_CUST_NUM");
				gid('MF:outlblcustnum1').innerText=objXMLApplet.getValue("CLIENTS_NAME");
				gid("MF:txtLCCurr").value=objXMLApplet.getValue("LCPS_LC_CURR");
				
				gid("MF:txtLCAmt").value=objXMLApplet.getValue("LCPS_LC_AMT");
				//NaveenNaidu-chennai-3/12/2007-beg
				if((objXMLApplet.getValue("LCPS_POS_DEV")!=0)||(objXMLApplet.getValue("LCPS_NEG_DEV")!=0))
				{
					gid("MF:chkdeviationallowed").checked=true;
					gid("MF:outlbldeviallowed").innerText="Yes";
				}
				else
				{
					gid("MF:chkdeviationallowed").checked=false;
					gid("MF:outlbldeviallowed").innerText="No";
				}
				//NaveenNaidu-chennai-3/12/2007-end
				gid("MF:txtdeviationallow").value=objXMLApplet.getValue("LCPS_POS_DEV");
				gid("MF:txtdeviationallow1").value=objXMLApplet.getValue("LCPS_NEG_DEV");
				
				//Changes P.Subramani-Chn-16/02/2008 Beg
				if(objXMLApplet.getValue("LCPS_USANCE_INT_BY_APPL")=="1")
				{
					gid("MF:chkUsanceInterest").checked=true;
					gid("MF:outlblUsanceInterest").innerText="Yes";
				}
				else
				{
					gid("MF:chkUsanceInterest").checked=false;
					gid("MF:outlblUsanceInterest").innerText="No";
				}
				//Changes P.Subramani-Chn-16/02/2008 End
				gid("MF:txtintaccno").value=objXMLApplet.getValue("LCPS_CUST_LIAB_ACC_NUM");
				gid("MF:txtcustlcliaAcc").value=objXMLApplet.getValue("LCPS_CUST_LIAB_ACC_NUM1");
				gid('MF:outlblcustlcliaAcc').innerText=objXMLApplet.getValue("ACNT_NAME");
				gid("MF:txtLimitLineNo").value=objXMLApplet.getValue("LCPS_LIMIT_LINE_NUM");
				gid('MF:outlblLimitLineNo').innerText=objXMLApplet.getValue("LMTLINE_FACILITY_DESCN");
				gid("MF:txtFacilityCurr").value=objXMLApplet.getValue("LCPS_LIM_CURR");
				gid("MF:outlblFacilityCurr").innerText=objXMLApplet.getValue("CURR_NAME1");
				gid("MF:txtpresentLcLiaCurr").value=baseCurrency;

				gid("MF:txtmargincurr").value=objXMLApplet.getValue("LCPS_MARG_CURR");
				gid("MF:txtmarginpercentage").value=objXMLApplet.getValue("LCPS_MARG_PERC");
				gid("MF:txtmarginpercentage1").value=objXMLApplet.getValue("LCPS_EXCESS_LIMIT_MARG_PERC");
				//Changes P.Subramani-Chn-23/10/2008 BEg
				gid("MF:txtmarginamt1").value=objXMLApplet.getValue("LCPS_MARG_AMT");
				gid("MF:txtmarginamt2").value=objXMLApplet.getValue("LCPS_EXCESS_LIMIT_MARG_AMT");
				//Changes P.Subramani-Chn-23/10/2008 End				
		       	//Removed P.Subramani-Chn-22/07/2008 Beg		
				/*gid("MF:txtLcoutStandcurr").value=objXMLApplet.getValue("CURR_CODE");
				gid("MF:txtBilloutStandcurr").value=objXMLApplet.getValue("CURR_CODE");
				gid("MF:txtCrystalBillsOscurr").value=objXMLApplet.getValue("CURR_CODE");
				gid("MF:txtTotalOsLiabilitycurr").value=objXMLApplet.getValue("CURR_CODE");
				gid("MF:txtBilloutStandAmt").value=0;
				gid("MF:txtCrystalBillsOs").value=0;
				setAmount('MF:txtLcoutStandAmt',objXMLApplet.getValue("EFF_BAL"));
				setAmount('MF:txtBilloutStandAmt',gid("MF:txtBilloutStandAmt").value);
				setAmount('MF:txtCrystalBillsOs',gid("MF:txtCrystalBillsOs").value);
				var lcout=objXMLApplet.getValue("EFF_BAL");
				var billout=unFormat(gid("MF:txtBilloutStandAmt").value)*1;
				var crysout=unFormat(gid("MF:txtCrystalBillsOs").value)*1;
				var a=1*(lcout)+1*(billout)+1*(crysout);
				gid("MF:txtTotalOsLiabilityAmt").value=a;
				setAmount('MF:txtTotalOsLiabilityAmt',gid("MF:txtTotalOsLiabilityAmt").value);	*/
		       	//Removed P.Subramani-Chn-22/07/2008 End	
		
				if(gid('MF:seluseroption').value=="A")
				{
					objXMLAppletGrid1.clearMap();         			
					objXMLAppletGrid1.setValue("Package", "panaceaweb.utility");
					objXMLAppletGrid1.setValue("SQLToken","Valolc7");
					Args = gid('MF:txtbrncode').value+"|"+gid('MF:txtpresanDate').value+"|"+gid('MF:txtpresansl').value;
					objXMLAppletGrid1.setValue ("Args",Args);
					objXMLAppletGrid1.setValue("DataTypes","N|D|N");
					objXMLAppletGrid1.setValue("GridToken","FetchGridData");       
					objXMLAppletGrid1.sendAndReceive();
					if (objXMLAppletGrid1.getValue("ErrorMsg") != "")
					{	
						setMsg(objXMLAppletGrid1.getValue("ErrorMsg"));
						gid('MF:txtpresansl').focus();
						return;
					} 
					if(objXMLAppletGrid1.getValue("Result")=="RowPresent")
					{
						gridEoladd.clearAll();	
						gridEoladd.setxmlcolumn("0,1,0,1,1,0,0,0,0,0,0,0,1,1");
						gridEoladd.loadXMLString(objXMLAppletGrid1.getValue("GetGridData"));
					} 
				}
				setTabfocus("maintab","tcontent1");	
				gid("MF:txtLCDate").focus();
			}
		}
	}			
//-----------------------------------------------------------------------------------------------------------------------------												
	function validateLCDate()
	{
	
 		if(trim(gid('MF:txtLCDate').value)=="")
     	{
     		gid('MF:txtLCDate').value=currbusDate;
     		gid('MF:txtLCDate').focus;
     	}
        else         
     	{
        	var dateok;
   			dateobj=parseDate(gid('MF:txtLCDate').value,"true");
	   		if(dateobj == null)
	   		{
	   			setMsg(INVALIDDATE);
				gid('MF:txtLCDate').focus();
			   	return;		        
	   		}
	    	dateobj = formatDate(dateobj,'dd-MM-yyyy');
	  		gid('MF:txtLCDate').value =dateobj;
	  		dateok = isDate(gid('MF:txtLCDate').value,'dd-MM-yyyy');
			if (dateok == 0)
	   		{
		   		setMsg(INVALIDDATE);
		   		gid('MF:txtLCDate').focus();
		   		return ;
		   	}
	   		dateok =compareDates(dateobj,'dd-MM-yyyy',currbusDate,'dd-MM-yyyy');
			if (dateok == 2) 
			{
				setMsg(DATE_LESS_EQ_CBD);
				gid('MF:txtLCDate').focus();
				return ;
			}	
			dateobj=parseDate(gid('MF:txtLCDate').value,"true");	
			dateobj = formatDate(dateobj,'dd-MM-yyyy');
	  		gid('MF:txtLCDate').value =dateobj;
	  		dateok =compareDates(dateobj,'dd-MM-yyyy',gid('MF:txtsanctionDate').value,'dd-MM-yyyy');
	  		if (!(dateok == 2) && !(dateok == 1))
	   		{	
		   		setMsg("LC date should be >= LC Sanctioned On Date");
		   		gid('MF:txtLCDate').focus();
		   		return ;
	   		} 
	   		if (dateok == -1 ) 
	   		{
	   			setMsg(INVALIDDATE);
		   		gid('MF:txtLCDate').focus();
		   		return ;
	   		}
   			else
   			{
		   		objXMLApplet.clearMap();
				objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
				objXMLApplet.setValue("ValidateToken","true");
				objXMLApplet.setValue("Method","olcLcDatekeypress");
				objXMLApplet.setValue("CBD",currbusDate);
				objXMLApplet.setValue("OLC_LC_DATE",gid('MF:txtLCDate').value);
				objXMLApplet.setValue("OLC_SANCTION_DATE",gid('MF:txtsanctionDate').value);
				objXMLApplet.sendAndReceive();
				if(objXMLApplet.getValue("ErrorMsg") != "")
	      		{
		      		setMsg(objXMLApplet.getValue("ErrorMsg"));
		      		setTabfocus("maintab","tcontent1");	
		      		gid('MF:txtLCDate').focus();		
					return;
				}
				else
				{
					setTabfocus("maintab","tcontent1");
		 			gid('MF:txtBeneficiaryCode').focus();
		 		}
			} 
	 	}
    }	 
//-----------------------------------------------------------------------------------------------------------------------------	
	function validateBenefCode()
	{
		if((trim(gid('MF:txtconttype').value)=="OLC") && (trim(gid('MF:txtBeneficiaryCode').value)==""))
   	   	{
   	   		 setMsg(BLANK_CHECK);	
   	   		 setTabfocus("maintab","tcontent1");
  	     	 gid('MF:txtBeneficiaryCode').focus();
  	     	 return;
   	   	}
   		objXMLApplet.clearMap();
		objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
		objXMLApplet.setValue("Method","eolcBenefCodekeypress");
		objXMLApplet.setValue("ValidateToken", "true");
		objXMLApplet.setValue("EOLC_BENEF_CODE",trim(gid('MF:txtBeneficiaryCode').value));
		//ADDED ON 02/08/2018 START
		objXMLApplet.setValue("PGM_ID","EOLC");
		objXMLApplet.setValue("BRN_CODE",gid('MF:txtbrncode').value);
		objXMLApplet.setValue("NOMEN",gid('MF:txtconttype').value);
		objXMLApplet.setValue("YEAR",gid('MF:txtcontyear').value);
		objXMLApplet.setValue("SERIAL",gid('MF:txtcontsl').value);
		objXMLApplet.setValue("PAYMENT_SERIAL","0");
		//ADDED ON 02/08/2018 END
		objXMLApplet.sendAndReceive();
		if(objXMLApplet.getValue("ErrorMsg") != "")
		{
			setMsg(objXMLApplet.getValue("ErrorMsg"));
			gid('MF:txtBeneficiaryCode').focus();
			return;  
		}
		else
		{
   			gid('MF:txtBeneficiaryName').value=objXMLApplet.getValue("EOLC_BENE_NAME");
   			gid('MF:txtCountryCode').value=objXMLApplet.getValue("EOLC_CNTRY_CODE");
   			gid('MF:outlblCountryCode').innerText=objXMLApplet.getValue("EOLC_CNTRY_NAME");
   			var add1="";
     				
			if(trim(objXMLApplet.getValue("EOLC_BENE_ADD1"))!="")
				add1=add1+objXMLApplet.getValue("EOLC_BENE_ADD1")+"\n";
			if(trim(objXMLApplet.getValue("EOLC_BENE_ADD2"))!="")
				add1=add1+objXMLApplet.getValue("EOLC_BENE_ADD2")+"\n";
			if(trim(objXMLApplet.getValue("EOLC_BENE_ADD3"))!="")
				add1=add1+objXMLApplet.getValue("EOLC_BENE_ADD3")+"\n";
			if(trim(objXMLApplet.getValue("EOLC_BENE_ADD4"))!="")
				add1=add1+objXMLApplet.getValue("EOLC_BENE_ADD4")+"\n";
			if(trim(objXMLApplet.getValue("EOLC_BENE_ADD5"))!="")
				add1=add1+objXMLApplet.getValue("EOLC_BENE_ADD5");
				
			//ADDED ON 09/11/2018 START
			if(gid('MF:seluseroption').value=="A") 
			{	
				gid('MF:txtAddress1').value=add1;
			}
			else if(gid('MF:seluseroption').value=="M" && trim(gid('MF:txtBeneficiaryCode').value) != "")
			{
				gid('MF:txtAddress1').value=add1;
			}
			//ADDED ON 09/11/2018 END
			
	   		setTabfocus("maintab","tcontent1");
	    	gid('MF:txtBeneficiaryName').focus();
       }		
    }	
//-----------------------------------------------------------------------------------------------------------------------------	
	function validateBenefName()
	{
		if(gid('MF:txtBeneficiaryName').value=="")
		{
			if(gid('MF:txtBeneficiaryCode').value=="")
			{
				setMsg(BLANK_CHECK);
				gid("MF:txtBeneficiaryName").focus();
				return; 
		  	}
		  	else
		  	{
		  		setTabfocus("maintab","tcontent1");
		  		focusTextArea('MF:txtAddress1');
		  	}
		}
		else
		{
			setTabfocus("maintab","tcontent1");
			focusTextArea('MF:txtAddress1');
		}
	}
//-----------------------------------------------------------------------------------------------------------------------------	
	function validateBenefAddress()
	{
		if(gid('MF:txtAddress1').value=="")
	    {
			if(gid('MF:txtBeneficiaryCode').value=="")
			{
				setMsg(BLANK_CHECK);
				focusTextArea('MF:txtAddress1');
				return; 
		  	}
		  	else
		  	{
		  		setTabfocus("maintab","tcontent1");
		  		gid("MF:txtCountryCode").focus();
		  	}
		}
		else
		{
			setTabfocus("maintab","tcontent1");
			gid("MF:txtCountryCode").focus();
		}
	}
//-----------------------------------------------------------------------------------------------------------------------------	
	function validateBenefCntryCode()
	{
		if(gid('MF:txtCountryCode').value=="")
		{
			setMsg(BLANK_CHECK);
			gid('MF:txtCountryCode').focus();
			return; 
	  	}
	  
	  	else
	  	{
		  	objXMLApplet.clearMap();
			objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
			objXMLApplet.setValue("Method","olcBeneficiaryCntrykeypress");
			objXMLApplet.setValue("ValidateToken", "true");
			objXMLApplet.setValue("OLC_CNTRY_CODE",trim(gid('MF:txtCountryCode').value));
			objXMLApplet.sendAndReceive();
			if(objXMLApplet.getValue("ErrorMsg") != "")
			{
				setMsg(objXMLApplet.getValue("ErrorMsg"));
				gid('MF:txtCountryCode').focus();
				return;  
			}
			else
			{
	   			gid('MF:outlblCountryCode').innerText=objXMLApplet.getValue("CNTRY_NAME");
	   			setTabfocus("maintab","tcontent1");
	  	 		gid("MF:txtLcIssuedthruBank").focus();
		  	}
		}
	}	
//-----------------------------------------------------------------------------------------------------------------------------	
	function validateIssuedthruBank()
	{
	 	if(gid('MF:txtLcIssuedthruBank').value=="")
		{
			setMsg(BLANK_CHECK);
			gid('MF:txtLcIssuedthruBank').focus();
			return; 
	  	}
	  	else
	  	{
		 	objXMLApplet.clearMap();
			objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
			objXMLApplet.setValue("Method","olcBnkkeypress");
			objXMLApplet.setValue("ValidateToken", "true");
			objXMLApplet.setValue("OLC_BNK",trim(gid('MF:txtLcIssuedthruBank').value));
			objXMLApplet.sendAndReceive();
			if(objXMLApplet.getValue("ErrorMsg") != "")
			{
				setMsg(objXMLApplet.getValue("ErrorMsg"));
				gid('MF:txtLcIssuedthruBank').focus();
				return;  
			}
			else
			{
				gid('MF:outlblLcIssThruBank').innerText=objXMLApplet.getValue("BANKCD_NAME");
				setTabfocus("maintab","tcontent1");
		 		gid('MF:txtLcIssuedthruBranch').focus();
			}
		}
	}		
//-----------------------------------------------------------------------------------------------------------------------------	
	function validateIssuedthruBranch()
	{
		if(!(gid('MF:txtLcIssuedthruBranch').value==""))
	 	{	
		 	objXMLApplet.clearMap();
			objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
			objXMLApplet.setValue("Method","olcBrnkeypress");
			objXMLApplet.setValue("ValidateToken", "true");
			objXMLApplet.setValue("OLC_BNK",trim(gid('MF:txtLcIssuedthruBank').value));
			objXMLApplet.setValue("OLC_BRN",trim(gid('MF:txtLcIssuedthruBranch').value));
			objXMLApplet.sendAndReceive();
			if(objXMLApplet.getValue("ErrorMsg") != "")
			{
				setMsg(objXMLApplet.getValue("ErrorMsg"));
				gid('MF:txtLcIssuedthruBranch').focus();
				return;  
			}
			else
			{
				gid('MF:txtLcIssuedBranchName').value=objXMLApplet.getValue("MBKBRN_NAME");
				var add1="";
	         	if(trim(objXMLApplet.getValue("MBKBRN_ADDR1"))!="")
					add1=add1+objXMLApplet.getValue("MBKBRN_ADDR1")+"\n";
				if(trim(objXMLApplet.getValue("EOLC_BENE_ADD2"))!="")
					add1=add1+objXMLApplet.getValue("MBKBRN_ADDR2")+"\n";
				if(trim(objXMLApplet.getValue("MBKBRN_ADDR3"))!="")
					add1=add1+objXMLApplet.getValue("MBKBRN_ADDR3")+"\n";
				if(trim(objXMLApplet.getValue("MBKBRN_ADDR4"))!="")
					add1=add1+objXMLApplet.getValue("MBKBRN_ADDR4")+"\n";
				if(trim(objXMLApplet.getValue("MBKBRN_ADDR5"))!="")
					add1=add1+objXMLApplet.getValue("MBKBRN_ADDR5");
				gid('MF:txtAddress21').value=add1;
				setTabfocus("maintab","tcontent1");
				gid('MF:txtLcIssuedBranchName').focus();
			}
		}
	    else
	    {		
			 setTabfocus("maintab","tcontent1");
			 gid('MF:txtLcIssuedBranchName').focus();
		}
	}		
//-----------------------------------------------------------------------------------------------------------------------------		
	function validateBranchName()
	{
		if(gid('MF:txtLcIssuedthruBranch').value=="")
		{
			 if(gid('MF:txtLcIssuedBranchName').value=="")
			 {
			  	setMsg(BLANK_CHECK);
		 		gid('MF:txtLcIssuedBranchName').focus();
			 	return; 
			 }
			 else
			 {
			 	setTabfocus("maintab","tcontent1");
			 	focusTextArea('MF:txtAddress21');
			 }
		}
		else
		{
			setTabfocus("maintab","tcontent1");
			focusTextArea('MF:txtAddress21');
		} 
	}
//-----------------------------------------------------------------------------------------------------------------------------			
	function validateBranchAdd()
	{
		if(gid('MF:txtLcIssuedthruBranch').value=="")
		{
			if(gid('MF:txtAddress21').value=="")
			{
				setMsg(BLANK_CHECK);
				gid('MF:txtAddress21').focus();
				return; 
			}
	 		else
			{
				setTabfocus("maintab","tcontent1");
				gid("MF:txtLcIssuedOnplace").focus();
			}
		}
		else
		{
			setTabfocus("maintab","tcontent1");
			gid("MF:txtLcIssuedOnplace").focus();
		}
	}
//-----------------------------------------------------------------------------------------------------------------------------	
	function validateIssuedOnplace()
	{
		setTabfocus("maintab","tcontent1");
		gid("MF:txtLcIssuedOncntry").focus();
	}
//-----------------------------------------------------------------------------------------------------------------------------	
	function validateIssuedOncnty()
	{
		if(gid('MF:txtLcIssuedOncntry').value=="")
		{
			setMsg(BLANK_CHECK);
			gid('MF:txtLcIssuedOncntry').focus();
			return; 
	  	}
	  		
		
	  	else
	  	{
	  	    objXMLApplet.clearMap();
			objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
			objXMLApplet.setValue("Method","olcCntrykeypress");
			objXMLApplet.setValue("ValidateToken", "true");
			objXMLApplet.setValue("OLC_CNTRY_CODE",trim(gid('MF:txtLcIssuedOncntry').value));
			objXMLApplet.setValue("TNOMEN_INLAND_OVERSEAS",trim(gid('MF:txtinover').value));
			objXMLApplet.sendAndReceive();
			if(objXMLApplet.getValue("ErrorMsg") != "")
			{
				setMsg(objXMLApplet.getValue("ErrorMsg"));
				gid('MF:txtLcIssuedOncntry').focus();
				return;  
			}
			else
			{
		   		gid('MF:outlblLcIssoncntry').innerText=objXMLApplet.getValue("CNTRY_NAME");
	   			setTabfocus("maintab","tcontent1");
		  	 	gid("MF:lstAdThru").focus();
	  		}
		}
	}		
//-----------------------------------------------------------------------------------------------------------------------------	
	function validateLcAdvThru()
	{
		if(gid('MF:lstAdThru').value=="")
	    {
		 	setMsg(OPTION_MESSAGE);
			gid('MF:lstAdThru').focus();
			return; 
	    }
	 	else
	  	{
		   	setTabfocus("maintab","tcontent2");
		    //Changes P.Subramani-Chn-23/05/2008 Beg
		    gid("MF:chkdeviationallowed").focus();
		    //gid('MF:txtLCCurr').focus();
	  	}
	}
	//Changes P.Subramani-Chn-23/05/2008 End
//-----------------------------------------------------------------------------------------------------------------------------				
	function checkDeviAllow()
	{
		if(gid('MF:chkdeviationallowed').checked==true)
		{
			gid('MF:outlbldeviallowed').innerText="Yes";
		}
		else
		{
			gid('MF:outlbldeviallowed').innerText="No";
		}
	} 
//-----------------------------------------------------------------------------------------------------------------------------				
	function validateDeviationAllow() 
	{
		checkDeviAllow();
		if(gid('MF:chkdeviationallowed').checked==true)
		{
			setTabfocus("maintab","tcontent2");
			gid('MF:txtdeviationallow').focus();
		}
		else
		{
			gid("MF:txtdeviationallow").value=0;
			gid("MF:txtdeviationallow1").value=0;	
			setTabfocus("maintab","tcontent2");
			gid('MF:txtTermsOfprice').focus();
		}
	}
//-----------------------------------------------------------------------------------------------------------------------------					
	function validatePostiveDevi()
	{
		if(gid("MF:txtdeviationallow").value=="")
		{
			setMsg(BLANK_CHECK);
			gid('MF:txtdeviationallow').focus();
			return;
		}
  	    if(!(gid("MF:txtdeviationallow").value<=100))
  	    {
	  	  	setMsg("Should be <= 100");
			gid('MF:txtdeviationallow').focus();
			return;
  	    }
  	    else
  	    {
  	    	setTabfocus("maintab","tcontent2");
			gid("MF:txtdeviationallow1").focus();
  	    }
	}
//-----------------------------------------------------------------------------------------------------------------------------				
	function validateNegaTiveDevi()
	{
		if(gid("MF:txtdeviationallow1").value=="")
		{
			setMsg(BLANK_CHECK);
			gid('MF:txtdeviationallow1').focus();
			return;
		}
  	 	if(!(gid("MF:txtdeviationallow1").value<=100))
  	    {
	  	  	setMsg("Should be <= 100");
			gid('MF:txtdeviationallow1').focus();
			return;
  	    }
  	    else
  	    {
	  	    setTabfocus("maintab","tcontent2");
			gid("MF:txtDeviationAmt").focus();
  	    }
  	    calDeviAmt();
	}
//-----------------------------------------------------------------------------------------------------------------------------						
	function calDeviAmt()
	{
		 dlength=decilength;
		 var pdevi=parseFloat(unFormat(gid("MF:txtdeviationallow").value)*1);
		 var lcamt=parseFloat(unFormat(gid("MF:txtLCAmt").value)*1);
		 res=(pdevi/100)*(lcamt);
		 setAmount("MF:txtDeviationAmt",res+"");
		 setAmount("MF:txtDeviationAmt",gid('MF:txtDeviationAmt').value);
		 setTabfocus("maintab","tcontent2");
		 gid("MF:lstAmtquali").focus();
	}
//-----------------------------------------------------------------------------------------------------------------------------					
	function validateDeviAmt()
	{
		if(gid("MF:txtDeviationAmt").value=="")
	    {
			setMsg(BLANK_CHECK);
			gid('MF:txtDeviationAmt').focus();
		}
  	 	if(!(gid("MF:txtDeviationAmt").value>=0))
  	    {
  	  		setMsg("Should be >= 0");
			gid('MF:txtDeviationAmt').focus();
			return;
  	    }
  	    else
  	    {
  	    	setTabfocus("maintab","tcontent2");
			gid("MF:lstAmtquali").focus();
  	    }
	}	
//-----------------------------------------------------------------------------------------------------------------------------					
	function validateAmtQualifier()
	{
		if(gid("MF:lstAmtquali").value=="")
		{
			setMsg(OPTION_MESSAGE);
			gid('MF:lstAmtquali').focus();
			return;
		}
		else
		{
			setTabfocus("maintab","tcontent2");
			focusTextArea('MF:txtAdditionalamtcover');
  	    }
	}
//-----------------------------------------------------------------------------------------------------------------------------					
	function validateAddiAmtCovered()
	{
	 	setTabfocus("maintab","tcontent2");
		gid('MF:txtTermsOfprice').focus();
	}
//-----------------------------------------------------------------------------------------------------------------------------				
	function validateTermsOfPrice()
	{
		if(gid("MF:txtTermsOfprice").value=="")
		{
			setMsg(BLANK_CHECK);
			gid('MF:txtTermsOfprice').focus();
			return;
		}
		else
		{
			objXMLApplet.clearMap();
			objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
			objXMLApplet.setValue("Method","olcTermsOfPricekeypress");
			objXMLApplet.setValue("ValidateToken", "true");
			objXMLApplet.setValue("TERMS_OF_PRICE",trim(gid('MF:txtTermsOfprice').value));
			objXMLApplet.sendAndReceive();
			if(objXMLApplet.getValue("ErrorMsg") != "")
			{
				setMsg(objXMLApplet.getValue("ErrorMsg"));
				gid('MF:txtTermsOfprice').focus();
				return;  
			}
			else
			{
				gid('MF:outlbltermsOfprice').innerText=objXMLApplet.getValue("TERMS_DESCN");
				setTabfocus("maintab","tcontent2");
				gid('MF:txtLastDateOfNego').focus();
			}
		}
	}			
//-----------------------------------------------------------------------------------------------------------------------------				
	function validateLastdateofNego()
	{
		if(trim(gid('MF:txtLastDateOfNego').value)=="")
     	{
     		//Changes P.Subramani-Chn-29/02/2008
     		setMsg("");
     		setMsg(BLANK_CHECK);
			gid('MF:txtLastDateOfNego').focus();
			return;
		}
        else         
     	{
        	var dateok;
      		var dateobj=parseDate(gid('MF:txtLastDateOfNego').value,"true");
  			if(dateobj==null)
  			{   
  				setMsg(INVALIDDATE);
  				return false;
  			}
  			dateobj = formatDate(dateobj,'dd-MM-yyyy');		
	    	gid('MF:txtLastDateOfNego').value =dateobj;
			dateok = isDate(gid('MF:txtLastDateOfNego').value,'dd-MM-yyyy');
			if (dateok == 1)
			{
				setMsg(INVALIDDATE);
				gid('MF:txtLastDateOfNego').focus();
				return ;
			}
			var dateobj=parseDate(gid('MF:txtLastDateOfNego').value,"true");
	        dateobj = formatDate(dateobj,'dd-MM-yyyy');
			gid('MF:txtLastDateOfNego').value =dateobj;	
			dateok =compareDates(dateobj,'dd-MM-yyyy',gid('MF:txtLCDate').value,'dd-MM-yyyy');
			if (dateok == 0) 
			{
				setMsg("Last date of negotiation should be >= LC Date");
				gid('MF:txtLastDateOfNego').focus();
				return ;
			}
			else if (dateok == -1) 
			{
				setMsg(INVALIDDATE);
				gid('MF:txtLastDateOfNego').focus();
				return ;
			}
			else
			{
				objXMLApplet.clearMap();
    			objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
				objXMLApplet.setValue("ValidateToken","true");
				objXMLApplet.setValue("Method","olcLastDatekeypress");
				objXMLApplet.setValue("OLC_LC_DATE",gid('MF:txtLCDate').value);
				objXMLApplet.setValue("LAST_DATE",gid('MF:txtLastDateOfNego').value);
				objXMLApplet.sendAndReceive();
				if(objXMLApplet.getValue("ErrorMsg") != "")
	      		{
		      		setMsg(objXMLApplet.getValue("ErrorMsg"));
		      		gid('MF:txtLastDateOfNego').focus();		
					return;
				}
				else
				{
					setTabfocus("maintab","tcontent2");
					gid('MF:txtplaceOfexpy').focus();
				}
		   }
	    }
	}	
//-----------------------------------------------------------------------------------------------------------------------------				
	function validatePlaceOfExp()
	{
	//changes in eolc on 02-jun-2018 start
		if(gid("MF:txtconttype").value=="OLC")
		{
			if(gid("MF:txtplaceOfexpy").value=="")
			{
				setMsg(BLANK_CHECK);
				gid('MF:txtplaceOfexpy').focus();
				return;
			}
			else
			{
				setTabfocus("maintab","tcontent2");
				gid('MF:txtLatestDateOfNego').focus();
			}
		}
		
		else //changes in eolc on 02-jun-2018 end
		{
			setTabfocus("maintab","tcontent2");
			gid('MF:txtLatestDateOfNego').focus();
		}
		
	}
//-----------------------------------------------------------------------------------------------------------------------------				
	function validateLatestdateOfShip()
	{
		if(trim(gid('MF:txtLatestDateOfNego').value)=="")
     	{
     		setTabfocus("maintab","tcontent2");
     		focusTextArea('MF:txtShipmentperod');
		}
        else         
     	{
	     	var dateok;
	   		dateobj=parseDate(gid('MF:txtLatestDateOfNego').value,"true");
	   		
	  		if(dateobj == null)
	   		{
	   		    setMsg(INVALIDDATE);
				gid('MF:txtLatestDateOfNego').focus();
			   	return;		        
	   		}
	    	dateobj = formatDate(dateobj,'dd-MM-yyyy');
	  		gid('MF:txtLatestDateOfNego').value =dateobj;
	  		dateok = isDate(gid('MF:txtLatestDateOfNego').value,'dd-MM-yyyy');
			if (dateok == 0)
	   		{
		   		setMsg(INVALIDDATE);
		   		gid('MF:txtLatestDateOfNego').focus();
		   		return ;
		   	}		
	  		dateok =compareDates(dateobj,'dd-MM-yyyy',gid('MF:txtpresanDate').value,'dd-MM-yyyy');
	  		if (!(dateok == 2))
	   		{	
		   		setMsg("Latest Shipment Date Should Be > Entry Date");
		   		gid('MF:txtLatestDateOfNego').focus();
		   		return ;
	   		} 
	   		if (dateok == -1 ) 
	   		{
	   			setMsg(INVALIDDATE);
		   		gid('MF:txtLatestDateOfNego').focus();
		   		return ;
	   		}
	   		dateok =compareDates(dateobj,'dd-MM-yyyy',gid('MF:txtLastDateOfNego').value,'dd-MM-yyyy');
	  		if (dateok == 2)
	   		{	
		   		setMsg("Latest Shipment Date Should Be <= Negotiation Date");
		   		gid('MF:txtLatestDateOfNego').focus();
		   		return ;
	   		}
	   		else
	   		{
				setTabfocus("maintab","tcontent2");
				focusTextArea('MF:txtpresentationdetails');
			} 
     	}
	}
//-----------------------------------------------------------------------------------------------------------------------------				
	function validateShipmentSchedule()
	{
		setTabfocus("maintab","tcontent2");
		//focusTextArea('MF:txtpresentationdetails'); 
		gid('MF:txtperiod').focus();//changes in eolc on 29-may-2018
	}
//-----------------------------------------------------------------------------------------------------------------------------				
	function validatePresentationDetails()
	{
		/*if(gid('MF:txtpresentationdetails').value=="" &&  ( gid('MF:txtperiod').value =="" || gid('MF:txtperiod').value =="0" ))
		{
			setMsg(BLANK_CHECK);
			setTabfocus("maintab","tcontent3");
			gid('MF:chkUsanceInterest').focus();
			return;
		}
		else
		{
			setTabfocus("maintab","tcontent2");
			gid('MF:chkWithInValOfLC').focus();
		}	
		*/
		//changes in eolc on 02-jun-2018 start
		if(gid("MF:txtconttype").value=="OLC")
		{
			if(gid('MF:txtpresentationdetails').value=="" && ( gid('MF:txtperiod').value !="" ||  gid('MF:txtperiod').value !="0" ))
			{
				setMsg(BLANK_CHECK);
				setTabfocus("maintab","tcontent2");
				gid('MF:txtpresentationdetails').focus();
			}
			else
			{
				setTabfocus("maintab","tcontent2");
				gid('MF:chkWithInValOfLC').focus();
			}	
		} //changes in eolc on 02-jun-2018  end
		else
			{
				setTabfocus("maintab","tcontent2");
				gid('MF:chkWithInValOfLC').focus();
			}	
		
	}
//-----------------------------------------------------------------------------------------------------------------------------				
	function chkWithInValOfLC()
	{
		if(gid('MF:chkWithInValOfLC').checked==true)
		{
			gid('MF:outlblWithInValOfLC').innerText="Yes";
		}
		else
		{
			gid('MF:outlblWithInValOfLC').innerText="No";
		}
	} 
//-----------------------------------------------------------------------------------------------------------------------------				
	function validatechkWithInValOfLC()
	{
		chkWithInValOfLC();
		setTabfocus("maintab","tcontent3");
		gid('MF:chkUsanceInterest').focus();
	}
//-----------------------------------------------------------------------------------------------------------------------------				
	function checkUsanceIntRat()
	{
		if(gid('MF:chkUsanceInterest').checked==true)
		{
			gid('MF:outlblUsanceInterest').innerText="Yes";
		}
		else
		{
			gid('MF:outlblUsanceInterest').innerText="No";
		}
	}  
//-----------------------------------------------------------------------------------------------------------------------------		 
	function validateUsanceIntRate()
 	{
	 	checkUsanceIntRat();
	 	//NaveenNaidu-chennai-3/12/2006-beg;
	 	//setTabfocus("maintab","tcontent3");
	 	//gid('MF:txtDrawDowns').focus();
	 	setTabfocus("maintab","tcontent3");
		SetFocus(gridEoladd,1,"ttype");
		//NaveenNaidu-chennai-3/12/2006-end;
	}
//-----------------------------------------------------------------------------------------------------------------------------		 
	function validateDrawDowns()
    {
		if(gid("MF:txtDrawDowns").value=="")
		{
			setMsg(BLANK_CHECK);
			gid('MF:txtDrawDowns').focus();
			return;
		}
		if(!(gid("MF:txtDrawDowns").value>0))
		{
			setMsg("should be >0 and <= 5");
			gid('MF:txtDrawDowns').focus();
			return;
		}
		if(!(gid("MF:txtDrawDowns").value<=5))
		{
			setMsg("should be >0 and <= 5");
			gid('MF:txtDrawDowns').focus();
			return;
		}	
		else
		{
			setTabfocus("maintab","tcontent3");
			SetFocus(gridEoladd,1,"ttype");
		}
  	}
//-----------------------------------------------------------------------------------------------------------------------------		 	  
	function GridKeyDownF2(objname, row, col)
   	{
   		if(objname=="gridEoladd")
		{
        	if ((row == 1 ) && (col==1) )
		    {
		    	setTabfocus("maintab","tcontent3");
		        gid('MF:chkUsanceInterest').focus();
		    }
		    else if(col==1) 
		    {	
	       		if(gridEoladd.cells(row,1).getValue()=="")
	       		{
	       			gridEoladd.deleteRow(row);
	       		}	
	       		if(f2flag=="S")
	       		{
	       			SetFocus( gridEoladd,row-1,"ttype");
	       		}
	       		else 
	       		{
	       			SetFocus( gridEoladd,row-1,"docdel");
	       		}
		    }	
		    else if(col==3) 
		    {
		    	SetFocus( gridEoladd,row,"ttype");
		    }	
		    else if(col==4) 
		    {
		    	if(f2flag=="U")
		       	{
		       		SetFocus( gridEoladd,row,"ttype");
		       	}
		       	else
		       	{
		       		SetFocus( gridEoladd,row,"tamt");	
		       	}
		    }	
	        else if(col==5) 	
	        {
	       		SetFocus( gridEoladd,row,"udays");
	        }
		    else if(col==6) 	
		    {
		        SetFocus( gridEoladd,row,"uperiod");
		    }
		    else if(col==7) 	
		    {
		    	SetFocus( gridEoladd,row,"otherdate");
		    }
		    else if(col==9) 	
	        {
	       		if(f2flag=="O")
	       		{
	       			SetFocus( gridEoladd,row,"Stofusancepr");
	       		}
	       		else
	       		{
	        		SetFocus( gridEoladd,row,"uperiod");
	           	}
	        }
		    else if(col==12) 	
		    {
		    	SetFocus( gridEoladd,row,"intrat");
		    }
		    else if(col==13) 	
		    {
	       		if(f2flag=="S1")
	       		{
	       			SetFocus( gridEoladd,row,"tamt");
	       		}
	            else
	            {
	            	SetFocus( gridEoladd,row,"intamt");
	            }
		    }
		 }
         //Changes P.Subramani-Chn-23/05/2008 Beg
         else if(objname=="gridNormChgs") 
		 {
			if(row == 1)
	        {
		       	gid('MF:TFMChargesDetails:txtchgsreccurr').focus();	
	        }
		    else if(gridNormChgs.cells(row,5).getValue() != gridNormChgs.cells(row,10).getValue())
		    {
		      	SetFocus(gridNormChgs,row-1,"convrate");
		    }
			else	  		
			{
			   	SetFocus(gridNormChgs,row-1,"actamount");
			}	     
		 }
		 //Changes P.Subramani-Chn-23/05/2008 End
    }  
//-----------------------------------------------------------------------------------------------------------------------------		 	
	function gridEoladdKeypress(row,col)
	{
		switch(col)
       	{
       	  case 1:  validateTenorType(row,col); 			break;
       	  case 3:  validateTenorAmt(row,col);			break;
       	  case 4:  validateUsanceDays(row,col);			break;
       	  case 5:  validateUsancePeriod(row,col);		break;
       	  case 6:  validateOtherDate(row,col);			break;
       	  case 7:  validateDateForUsancePr(row,col);	break;
       	  case 9:  validateInterestRate(row,col);		break;
       	  case 12: validateInterestAmt(row,col);		break;
       	  case 13: validateDocumentDeliv(row,col);		break;
	   }
	}
//-----------------------------------------------------------------------------------------------------------------------------		 	
	function validateTenorType(row,col)
	{
		var drawdown=gid('MF:txtDrawDowns').value;
		var curr_row=row;
		setMsg("");
		if(curr_row>drawdown)
		{
			setMsg("");
			setMsg("Row Should not be > DrawDowns");
			SetFocus(gridEoladd,row,"ttype");
			return; 
		}
		if(gridEoladd.cells(row,col).getValue()=="")
	 	{  
			setMsg("");
			setMsg(OPTION_MESSAGE);
			SetFocus(gridEoladd,row,"ttype");
			return; 		
		}
		if(drawdown==1)
		{
			if(row==1 )
			{
			 	if(gridEoladd.cells(row,col).getValue()=="S")
				{
					setMsg("");
					f2flag="S";
					gridEoladd.cells(row,2).setValue(2);
					gridEoladd.cells(row,3).setValue(gid('MF:txtLCAmt').value);
					gridEoladd.cells(row,4).setValue("0");
	 	      		gridEoladd.cells(row,5).setValue(" ");
	 	      		gridEoladd.cells(row,9).setValue("0.00");
	 	      		gridEoladd.cells(row,10).setValue(gid("MF:txtLCCurr").value);
	 	      		gridEoladd.cells(row,12).setValue("0.00");
	 	      		gridEoladd.cells(row,13).setValue(2);
	 	      		// NaveenNaidu  03/12/07  chn-Beg
	 	      		
	 	      		//Changes P.Subramani-Chn-23/08/2008 Beg
	 	      		getusancemonth(row,col);
	 	      		TotalValue(row,col);
	 	      		//Changes P.Subramani-Chn-23/08/2008 End
	 	      		
	 	      		//Changes P.Subramani-Chn-11/09/2008 Beg
	 	      		LcCompValue(row,col);
	 	      		//Changes P.Subramani-Chn-11/09/2008 End
	 	      			 	      		
	 	      		gridEoladd.setxmlcolumn("0,1,0,1,1,1,1,1,0,1,0,0,1,1,0,0,0,0,0,1");
	 	      		gid('MF:mxmlstr1').value = GetXMLString(gridEoladd);
	 	      		//Value(row,col);
	 	      		
	 	      		
       			    setTabfocus("maintab","tcontent3");
	       			gid('MF:chkLcunderCon').focus();
	       			gid('MF:chkLcunderCon').focus(); 
					//AddRowToGrid(gridEoladd); 
					//SetFocus(gridEoladd,row+1,"ttype");
				}
				else if(gridEoladd.cells(row,col).getValue()=="U")
				{
					setMsg("");
					f2flag="U";
					gridEoladd.cells(row,2).setValue(2);
					gridEoladd.cells(row,3).setValue(gid('MF:txtLCAmt').value);
					SetFocus(gridEoladd,row,"udays");
				}
				else if(gid('MF:txtLcAmt11').value != gid('MF:txtLCAmt').value)
				{
					setMsg("");
					setMsg("Tenor Amount should be equal to the LC Amount");
					SetFocus(gridEoladd,row,"ttype");
					return;
				}
			}
			else if(row==2)
			{
				setMsg("");
				setMsg("Row should not be > DrawDowns");
			}
		}
		else if(drawdown>1 )
		{
			if(row==1)
			{
				 if(gridEoladd.cells(row,col).getValue()=="S")
				 {
					setMsg("");
					f2flag="S1";
					gridEoladd.cells(row,col+1).setValue(3);
					SetFocus(gridEoladd,row,"tamt");
				 }
				 else if(gridEoladd.cells(row,col).getValue()=="U")
				 {	
					setMsg("");
					gridEoladd.cells(row,col+1).setValue(2);
					SetFocus(gridEoladd,row,"tamt");
				 }
			}
			if(row>1)
			{
				 if(gridEoladd.cells(row,col).getValue()=="S")
				 {
				 		var rownum=gridEoladd.getRowsNum();
				 		var flag;
				 		//Changes P.Subramani-Chn28/08/2008 Beg
				 		//for(var i=1;i<rownum;i++)
				 		//{
					 		if(gridEoladd.cells(row,col).getValue()=="S")
					 		{
					 			if(gridEoladd.cells(row,col).getValue()==gridEoladd.cells(row-1,col).getValue())
					 			{
					 				flag=1;
						 			setMsg("Sight should not be Duplicated");
									SetFocus(gridEoladd,row,"ttype");
									return;
								}
								else
								{
									f2flag="S1";
									flag=0;
								}
								if(flag==0)
								{
									setMsg("");
									gridEoladd.cells(row,col+1).setValue(3);
									SetFocus(gridEoladd,row,"tamt");
									return;
								}
					 		}
							else
							{
								f2flag="S1";
								flag=0;
							}
						//}//Changes P.Subramani-Chn28/08/2008 End
						if(flag==0)
						{
							setMsg("");
							gridEoladd.cells(row,col+1).setValue(3);
							SetFocus(gridEoladd,row,"tamt");
							return;
						}
				 }
				 else if(gridEoladd.cells(row,col).getValue()=="U")
				 {
				 	setMsg("");
					gridEoladd.cells(row,col+1).setValue(2);
					SetFocus(gridEoladd,row,"tamt");
				 }
			}
		}
	}
//-----------------------------------------------------------------------------------------------------------------------------		 	
	function validateTenorAmt(row,col)
	{
		setMsg("");
	 	var drawdown=gid('MF:txtDrawDowns').value;
	 	tottenoramt=0;
	 	if(gridEoladd.getRowsNum()==1)
	 	{
	 		tottenoramt=unFormat(gridEoladd.cells(row,3).getValue())*1;
	 	}
	 	else
	 	{
	 		tottenoramt=0;
	 		for(var i=1;i<=gridEoladd.getRowsNum();i++)
			{
				tottenoramt=(tottenoramt*1)+unFormat(gridEoladd.cells(i,3).getValue())*1;
				tottenoramt=tottenoramt*1;
			}
	 	}
		if(gridEoladd.cells(row,col).getValue()=="")
		{
			setMsg("");
			setMsg(BLANK_CHECK);
			SetFocus(gridEoladd,row,"tamt");
			return;
		}
		else if(gridEoladd.cells(row,col).getValue()==0)
		{
			setMsg("");
			setMsg(ZERO_CHECK);
			SetFocus(gridEoladd,row,"tamt");
			return;
		}
		else
		{
			setMsg("");
		    var tamt=gridEoladd.cells(row,3).getValue();
			var rownno=gridEoladd.getRowsNum();
		    objXMLApplet.clearMap();
			objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
			objXMLApplet.setValue("Method","olcTenorAmtkeypress");
	        objXMLApplet.setValue("ValidateToken", "true");
	        objXMLApplet.setValue("LC_AMOUNT",unFormat(gid("MF:txtLCAmt").value)*1);
	        objXMLApplet.setValue("DRAW_DOWNS",gid('MF:txtDrawDowns').value);
	        objXMLApplet.setValue("TOTAL_TEN_AMT",tottenoramt);
	        objXMLApplet.setValue("TENOR_AMT",tamt);
	        objXMLApplet.setValue("NO_OF_ROWS",rownno);
			objXMLApplet.sendAndReceive();
			if(objXMLApplet.getValue("ErrorMsg") != "")
			{
	  			setMsg(objXMLApplet.getValue("ErrorMsg"));
				SetFocus(gridEoladd,row,"tamt");
				return;  
			}
			else 
			{
				if(gridEoladd.cells(row,1).getValue()=="S")
				{
					//Changes P.Subramani-Chn-28/08/2008 BEg
					var curr_row=row;
					//Changes P.Subramani-Chn-28/08/2008 End
					if(curr_row<drawdown)
					{
						gridEoladd.cells(row,4).setValue("0");
		 	      		gridEoladd.cells(row,5).setValue(" ");
		 	      		gridEoladd.cells(row,9).setValue("0.00");
		 	      		gridEoladd.cells(row,10).setValue(gid("MF:txtLCCurr").value);
		 	      		gridEoladd.cells(row,12).setValue("0.00");
		 	      		gridEoladd.cells(row,13).setValue(2);
		 	      		
		 	      		//Changes P.Subramani-Chn-23/08/2008 Beg
		 	      		getusancemonth(row,col);
		 	      		TotalValue(row,col);
		 	      		
						AddRowToGrid(gridEoladd); 
						SetFocus(gridEoladd,row+1,"ttype");
						return; 
					}
					else if(curr_row==drawdown)
					{
						gridEoladd.cells(row,4).setValue("0");
		 	      		gridEoladd.cells(row,5).setValue(" ");
		 	      		gridEoladd.cells(row,9).setValue("0.00");
		 	      		gridEoladd.cells(row,10).setValue(gid("MF:txtLCCurr").value);
		 	      		gridEoladd.cells(row,12).setValue("0.00");
		 	      		gridEoladd.cells(row,13).setValue(2);
						SetFocus(gridEoladd,row,"docdel");
						return; 
					}
				}
				else if(gridEoladd.cells(row,1).getValue()=="U")
				{
					SetFocus(gridEoladd,row,"udays");
				}
			}	
		}
	}    			
//-----------------------------------------------------------------------------------------------------------------------------		 	
	function validateUsanceDays(row,col)
	{
	 	setMsg("");
	 	if(gridEoladd.cells(row,4).getValue()=="")
	 	{  
	 		setMsg("");
			setMsg(BLANK_CHECK);
			SetFocus(gridEoladd,row,"udays");
			return; 		
	 	}
	 	else if(gridEoladd.cells(row,4).getValue()<=0)
	 	{	
	 	    setMsg("Should be > 0");
			SetFocus(gridEoladd,row,"udays");
			return; 		
		}
		else
		{
			setMsg("");
		  	SetFocus(gridEoladd,row,"uperiod");
		}
	}
//-----------------------------------------------------------------------------------------------------------------------------		 	
	function validateUsancePeriod(row,col)
	{
		if(gridEoladd.cells(row,5).getValue()=="")
	 	{  
	 		setMsg("");
			setMsg(OPTION_MESSAGE);
			SetFocus(gridEoladd,row,"uperiod");
			return; 		
	 	}
		else if(gridEoladd.cells(row,5).getValue()==4)
	 	{	
	 	    f2flag="O";
	 	    SetFocus(gridEoladd,row,"otherdate");
			return; 		
		}
		else
		{
			gridEoladd.cells(row,8).setValue(6);
			SetFocus(gridEoladd,row,"intrat");
			return; 
		}
	}
//-----------------------------------------------------------------------------------------------------------------------------		 	
	function validateOtherDate(row,col)
	{
		if(gridEoladd.cells(row,6).getValue()=="")
	 	{  
		 	setMsg("");
			SetFocus(gridEoladd,row,"Stofusancepr");
			return; 		
	 	}
	 	else 
	 	{	
	 	    setMsg("");
	 	    SetFocus(gridEoladd,row,"Stofusancepr");
			return; 		
		}
	}
//-----------------------------------------------------------------------------------------------------------------------------		 	
	function validateDateForUsancePr(row,col)
	{
 		if(gridEoladd.cells(row,7).getValue()=="")
 	 	{  
 	 
		  setMsg("");
		  SetFocus(gridEoladd,row,"intrat");
		  return; 		
 	 	}
 		else 		
 	 	{ 
 			var dateval=parseDate(gridEoladd.cells(row,col).getValue(),"true");			  
			if(dateval == null)
			{
			   setMsg(INVALIDDATE);
			   SetFocus(gridEoladd,row,"Stofusancepr");
			   return;		        
			}
			else
			{
			   setMsg("");
			   dateval = formatDate(dateval,'dd-MM-yyyy');
			   gridEoladd.cells(row,col).setValue(dateval);
			   gridEoladd.cells(row,8).setValue(6);
			   SetFocus(gridEoladd,row,"intrat");
			   gridEoladd.cells(row,col).setValue(dateval);
       		   return; 		
	        }
		}        
	}
//-----------------------------------------------------------------------------------------------------------------------------		 	
	function validateInterestRate(row,col)
	{
		if(gridEoladd.cells(row,9).getValue()=="")
	 	{  
	 		gridEoladd.cells(row,9).setValue("0");
	 		//Changes P.Subramani-Chn-19/08/2008
			gridEoladd.cells(row,11).setValue(2);
			SetFocus(gridEoladd,row,"intamt");
			gridEoladd.cells(row,9).setValue("0");
			return;  		
	 	}
	    else if(gridEoladd.cells(row,9).getValue()<0)
	 	{	
	 		setMsg("Should be >= 0");
			SetFocus(gridEoladd,row,"intrat");
			return; 		
		}
		else if(gridEoladd.cells(row,9).getValue()==0)
	 	{	
	 		//Changes P.Subramani-Chn-19/08/2008
	 	    gridEoladd.cells(row,11).setValue(2);
	 	    //Changes P.Subramani-Chn-23/05/2008 
	 	    gridEoladd.cells(row,12).setValue("0");
			SetFocus(gridEoladd,row,"intamt");
			return; 		
		}
	    else 
	 	{	
	 	  	var a1=unFormat(gridEoladd.cells(row,3).getValue())*1;
	      	var a2=unFormat(gid("MF:txtdeviationallow").value)*1;
 	      	var a3=unFormat(gridEoladd.cells(row,9).getValue())*1;
 	      	var a4=unFormat(gridEoladd.cells(row,4).getValue())*1;
 	      	//Changes P.Subramani-Chn-31/03/2008
 	      	var A=a1+((a1*a2)/100);
 	      	var B=(A*a3)/100;
 	      	var C=(B*a4)/360;
	 	    //setMsg("");
	 	    gridEoladd.cells(row,10).setValue(gid("MF:txtLCCurr").value);
   	 		//Changes P.Subramani-Chn-19/08/2008
	 	    gridEoladd.cells(row,11).setValue(2);
	 	    gridEoladd.cells(row,12).setValue(C);
	 	    SetFocus(gridEoladd,row,"intamt");
		}
	}
//-----------------------------------------------------------------------------------------------------------------------------		 	
	function validateInterestAmt(row,col)
	{
		if(gridEoladd.cells(row,12).getValue()=="")
	 	{  
	 		setMsg(BLANK_CHECK);
			SetFocus(gridEoladd,row,"intamt");
			return; 		
	 	}
	    else if(gridEoladd.cells(row,12).getValue()<0)
	 	{	
	 	    setMsg("Should be >= 0");
			SetFocus(gridEoladd,row,"intamt");
			return; 		
		}
	    else 
	 	{	
		   setMsg("");
 	       SetFocus(gridEoladd,row,"docdel");
		   return; 
		}	  
	}
//-----------------------------------------------------------------------------------------------------------------------------		 	
	function validateDocumentDeliv(row,col)
	{
		var drawdown=gid('MF:txtDrawDowns').value;
		var curr_row=row;
		if(gridEoladd.cells(row,13).getValue()=="")
		{
			setMsg("");
			setMsg(OPTION_MESSAGE);
			SetFocus(gridEoladd,row,"docdel");
			return;
		}
		else
		{
			setMsg("");
			if(drawdown==curr_row)
			{
				LcCompValue(row,col);
				var totaltenoramount = unFormat(gid("MF:txtLcAmt11").value)*1;
				if(totaltenoramount!=unFormat(gid("MF:txtLCAmt").value)*1)
				{
					setMsg("Total Tenor Amount doesn't tally with LC Amount");
					SetFocus(gridEoladd,row,"docdel");
					return; 
				}
				else
				{
					setMsg("");
					//Changes P.Subramani-Chn-23/08/2008 Beg
	 	      		getusancemonth(row,col);
	 	      		TotalValue(row,col);
	 	      		//Changes P.Subramani-Chn-23/08/2008 End
					
					gridEoladd.setxmlcolumn("0,1,0,1,1,1,1,1,0,1,0,0,1,1,0,0,0,0,0,1");
					gid('MF:mxmlstr1').value = GetXMLString(gridEoladd);
					
					       
					setTabfocus("maintab","tcontent3");
	       			gid('MF:chkLcunderCon').focus();
	       			gid('MF:chkLcunderCon').focus(); 	
				}
			}
			else if(drawdown!=curr_row)
			{
				//Changes P.Subramani-Chn-23/08/2008 Beg
 	      		getusancemonth(row,col);
 	      		TotalValue(row,col);
 	      		//Changes P.Subramani-Chn-23/08/2008 End
				AddRowToGrid(gridEoladd); 
				SetFocus(gridEoladd,row+1,"ttype");
			}
		}
	}
//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------- 			
	//Changes P.Subramani-Chn-23/08/2008 Beg
	function TotalValue(row,col)
	{
		var A1=unFormat(gridEoladd.cells(row,3).getValue())*1;
		var C1=unFormat(gridEoladd.cells(row,12).getValue())*1;	
		var x1=unFormat(gid("MF:txtdeviationallow").value)*1;
		var B1=(x1/100)*A1;
		var Total = A1+B1+C1;
		gridEoladd.cells(row,15).setValue(2);
		gridEoladd.cells(row,16).setValue(Total);
	}
	//Changes P.Subramani-Chn-23/08/2008 End	
//-----------------------------------------------------------------------------------------------------------------------------		 	
	//Changes P.Subramani-Chn-11/04/2008  Beg
	function getusancemonth(row,col)
	{	
		//Changes P.Subramani-Chn-23/08/2008 Beg
		if(gridEoladd.cells(row,1).getValue()=="S")
		{
			olcusancemonth=0;
		}
		else
		{
			olcusancedays = gridEoladd.cells(row,4).getValue();
			if( ( (olcusancedays/30) - parseInt(olcusancedays/30) ) > 0 )
			{
				olcusancemonth = parseInt(olcusancedays/30) + (1);
			}
			else
			{
				olcusancemonth = (olcusancedays/30);
			}
		}
		gridEoladd.cells(row,14).setValue(olcusancemonth);
		//Changes P.Subramani-Chn-23/08/2008 End		
	}
//-----------------------------------------------------------------------------------------------------------------------------		 			
	function getcommmonth()
	{
		var fromdate = gid('MF:txtLCDate').value;
		var todate = gid('MF:txtLastDateOfNego').value;
		olccommmonth = getMonthDiff(fromdate,todate);
	}
//-----------------------------------------------------------------------------------------------------------------------------		 		
	function gettenortypechargecurroption()
	{
		objXMLApplet.clearMap();
		objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
		objXMLApplet.setValue("Method","olctenortypechgcodecurroptionkeypress");
        objXMLApplet.setValue("ValidateToken","true");
        objXMLApplet.setValue("TENOR_TYPE","USANCE");
        objXMLApplet.sendAndReceive();
		chargecurroption = objXMLApplet.getValue("CHGCD_CHG_CURR_OPTION");
	}
	//Changes P.Subramani-Chn-11/04/2008  End
//-----------------------------------------------------------------------------------------------------------------------------		 	
	//Changes P.Subramani-Chn-28/04/2008 Beg
	function getcustno()
	{
		objXMLApplet.clearMap();
		objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
		objXMLApplet.setValue("Method","olccustnumkeypress");
        objXMLApplet.setValue("ValidateToken","true");
        objXMLApplet.setValue("OLC_PROD_CODE",trim(gid('MF:txtproductcode').value));
        objXMLApplet.setValue("OLC_LC_TYPE",trim(gid('MF:txtconttype').value));
		objXMLApplet.setValue("OLC_CUST_NUM",trim(gid('MF:txtcustnum1').value));
		objXMLApplet.sendAndReceive();
		custno = objXMLApplet.getValue("CUSTOMER_NUMBER");
	}
	//Changes P.Subramani-Chn-28/04/2008  End
//-----------------------------------------------------------------------------------------------------------------------------		 	
	function GridKeyDownF12(objname)
	{  
		switch (objname)
 		{
 			case "gridEoladd"		:	
			 							var drawdown = gid('MF:txtDrawDowns').value;
				 						var curr_row = gridEoladd.getRowsNum();
			 							if( curr_row == drawdown )
			 							{
				 							gridEoladd.setxmlcolumn("0,1,0,1,1,1,1,1,0,1,0,0,1,1,0,0,0,0,0,1");
				 							gid('MF:mxmlstr1').value = GetXMLString(gridEoladd);       
						       			    LcCompValue(row,col);
						       			    setTabfocus("maintab","tcontent3");
							       			gid('MF:chkLcunderCon').focus();
							       			gid('MF:chkLcunderCon').focus();       		
							       			setMsg("");	   		
								   			window.event.keyCode =0;
								   			return;
								   		}
								   		else
								   		{
								   			setMsg("");
								   			setMsg("No. Of Rows in Grid Should be = Draw Down Value");
								   			SetFocus(gridEoladd,curr_row,"docdel");
								   			return;
								   		}
										break;	
		}			
	}  	
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
	function getXML()
	{
	    gridEoladd.setxmlcolumn("0,1,0,1,1,1,1,1,0,1,0,0,1,1,0,0,0,0,0,1");
	  	gid('MF:mxmlstr1').value=GetXMLString(gridEoladd);
	    window.event.keyCode =0 ;
		gid('MF:Submit').focus();
	   	return;
	}	
//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------- 			
	function xmlParser()
	{
		xmlDOM1 = new ActiveXObject("Microsoft.XMLDOM");
		xmlDOM1.loadXML(griddata);
	 	for(var kt=0;kt<xmlDOM1.documentElement.childNodes.length;kt++)
	    {
		      xmlDOM1.documentElement.childNodes(kt).removeChild(xmlDOM1.documentElement.childNodes(kt).firstChild);
	    }
	    griddata = xmlDOM1.xml;
	    xmlDOM1.loadXML("<Data><Record></Record></Data>");	
	}		 			
//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------- 			
	function LcCompValue(row,col)
	{
		var A1=0;
		var C1=0;
	 	for(var i=1;i<=gridEoladd.getRowsNum();i++)
		{
			A1=A1+unFormat(gridEoladd.cells(i,3).getValue())*1;
			C1=C1+unFormat(gridEoladd.cells(i,12).getValue())*1;	
		}
		var x=unFormat(gid("MF:txtLCAmt").value)*1;
	 	var x1=unFormat(gid("MF:txtdeviationallow").value)*1;
	 	//Changes P.Subramani-Chn-23/08/2008 Beg
	 	var B1=(x1/100)*x;
	 	//Changes P.Subramani-Chn-23/08/2008 End	
		 gid("MF:txtLcAmt11").value=A1;
		 setAmount('MF:txtLcAmt11',gid("MF:txtLcAmt11").value);
		 gid("MF:txtPositiveDeviaAmt").value=B1;
		 setAmount('MF:txtPositiveDeviaAmt',gid("MF:txtPositiveDeviaAmt").value);
		 gid("MF:txtusanceIntAmt").value=C1;
		 setAmount('MF:txtusanceIntAmt',gid("MF:txtusanceIntAmt").value);
		 gid("MF:txtTotalAmt").value=A1+B1+C1;
		 setAmount('MF:txtTotalAmt',gid("MF:txtTotalAmt").value);
		 
		 gid("MF:txtLcCurr11").value=gid("MF:txtLCCurr").value;
		 gid("MF:txtPositiveDeviaCurr").value=gid("MF:txtLCCurr").value;
		 gid("MF:txtusanceIntCurr").value=gid("MF:txtLCCurr").value;
		 gid("MF:txtTotalCurr").value=gid("MF:txtLCCurr").value	;
		 gid("MF:txtLcCurr11").value=gid("MF:txtLCCurr").value;
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
	function checkLCUnderContract()
	{
		if(gid('MF:chkLcunderCon').checked==true)
		{
			gid('MF:outlblLcunderCon').innerText="Yes";
		}
		else
		{
			gid('MF:outlblLcunderCon').innerText="No";
		}
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
	function validateLCUnderContract()
	{
		checkLCUnderContract();
		if(gid("MF:txtLCCurr").value==baseCurrency)
		{
		//MUTHUKUMARAN ADDED 17-MAY-2010 BEG
			var U2=0;
			var X1=0;
		 	for(var i=1;i<=gridEoladd.getRowsNum();i++)
			{
				U2=unFormat(gridEoladd.cells(i,12).getValue())*1;	
			}
			var X1=unFormat(gid("MF:txtLCAmt").value)*1;
			gid('MF:txtTotalAmount').value=X1+U2;
			//objCRates.amttobeconv = gid('MF:txtTotalAmount').value;
			setTabfocus("maintab","tcontent5");
			gid("MF:Nextlimit").focus();
			//MUTHUKUMARAN ADDED 17-MAY-2010 END
		}
		else
		{
		
			//objCRates.clearControl();
			
			var U1=0;
			var X=0;
		 	for(var i=1;i<=gridEoladd.getRowsNum();i++)
			{
				U1=unFormat(gridEoladd.cells(i,12).getValue())*1;	
			}
			var X=unFormat(gid("MF:txtLCAmt").value)*1;
			gid('MF:txtTotalAmount').value=X+U1;
			objCRates.amttobeconv = gid('MF:txtTotalAmount').value;
			objCRates.recovcurr = baseCurrency;
			objCRates.basecurrency = baseCurrency;
			objCRates.trancurrency = gid('MF:txtLCCurr').value;
			objCRates.branchcode = gid('MF:txtbrncode').value;
			objCRates.AddOrModify = gid('MF:seluseroption').value;
			objCRates.trandate = gid('MF:txtLCDate').value;
			
			if(gid('MF:txtcustnum1').value=="")
				objCRates.custnumber = 0;
			else
				objCRates.custnumber = gid('MF:txtcustnum1').value;
			//added Irfan.S-Chn-08/02/2010 BEGIN
			//objCRates.amttobeconv = gid('MF:txtTotalAmt').value;
			//added Irfan.S-Chn-08/02/2010 end
			
			objCRates.salepurchflag = "S";
			objCRates.disbrecovflag = "R";
			
			if(gid('MF:seluseroption').value=="A")
				objCRates.TRANCRATES_SL = "0";
			else{
			objCRates.modifyflag="1";
			objCRates.TRANCRATES_SL = trancrates_sl;
			}
			objCRates.currbusDate = currbusDate;
			objCRates.SourceTable = "OLC";
			objCRates.SourceKey = trim(
			gid('MF:txtbrncode').value+"|"+						
			gid('MF:txtconttype').value+"|"+
			gid('MF:txtcontyear').value+"|"+
			gid('MF:txtcontsl').value);
			
			if(gid('MF:txtRefNo').value=="")
				objCRates.corrrefnum = "";
			else
				objCRates.corrrefnum = gid('MF:txtRefNo').value;
			// treasury changes by PRASHANTH chn 05-08-2017
				if(TSRY_ENABLED=='1'){
						gridConvRates.clearAll();
						if(!getConversionRateParams()){
						return false;
						}						getConvRate();
						gid('MF:TFMCRatesDetails:txtconvamt').readOnly=true;
						gid('MF:TFMCRatesDetails:txtconvrate').readOnly=true;
						document.getElementById('dealdetails').style.visibility = "hidden";
						document.getElementById('dealdetails_trsy').style.visibility = "hidden";
						AddRowToGrid(gridConvRates);
						gridConvRates.cells(1,1).setValue("1");
						gid("MF:TFMCRatesDetails:selconvrates").value="1";
						updateRateValues();
						updateGridValues();
						setTabfocus("maintab","tcontent4");
						gid("MF:TFMCRatesDetails:cmdOk").focus();
				}
	else{
			gid('MF:TFMCRatesDetails:txtconvamt').readOnly=false;
			gid('MF:TFMCRatesDetails:txtconvrate').readOnly=false;
			objCRates.Focus(true);
		}		
	}
}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
	function validateConvRatetoLmtCurr()
	{
		
		setMsg("");
		if(gid("MF:txtConRateToLimitCurr").value=="")
		{
			setMsg(BLANK_CHECK);
			setTabfocus("maintab","tcontent5");
			gid('MF:txtConRateToLimitCurr').focus();
			return;
		}
		else if(gid('MF:txtConRateToLimitCurr').value=="0")
		{
			setMsg("");
			setMsg(ZERO_CHECK);
			gid('MF:txtConRateToLimitCurr').focus();
			return;
		}
		else
		{
			gid('MF:txtConRateToLimitCurr').value =gid('MF:txtConRateToLimitCurr').value;
		}
		objXMLApplet.clearMap();
		objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
		objXMLApplet.setValue("ValidateToken","true");
		objXMLApplet.setValue("Method","olcConvRateLimCurrkeypress");
		objXMLApplet.setValue("OLC_LC_CURR",gid('MF:txtLCCurr').value);
		objXMLApplet.setValue("OLC_LIMIT_CURR",gid('MF:txtFacilityCurr').value);
		objXMLApplet.setValue("TOTAL",unFormat(trim(gid('MF:txtTotalAmt').value)));
		objXMLApplet.setValue("OLC_CONV_RATE_LIM_CURR",gid('MF:txtConRateToLimitCurr').value);
		objXMLApplet.setValue("OLC_LIMIT_LINE_NO",gid('MF:txtLimitLineNo').value);
		objXMLApplet.setValue("OLC_CUST_NO",gid('MF:txtcustnum1').value);
		objXMLApplet.setValue("OLC_BRANCH_CODE",gid('MF:txtbrncode').value);
		objXMLApplet.setValue("OLC_INTERNAL_ACC_NO",intaccno);
	    //Vinoth S Changes on 08-Dec-2010 Beg For Rounding Off Value
		objXMLApplet.setValue("TRAN_DATE",gid('MF:txtLCDate').value);
		objXMLApplet.setValue("TYPE","N");
	    //Vinoth S Changes on 08-Dec-2010 End
		objXMLApplet.sendAndReceive();
		if(objXMLApplet.getValue("ErrorMsg") != "")
		{
			setMsg(objXMLApplet.getValue("ErrorMsg"));
			gid('MF:txtConRateToLimitCurr').focus();
			return;  
		}
		else 
		{
			limitdecilen=objXMLApplet.getValue("DEC_LEN2");
			gid("MF:txtLcLiaAmtlimitCurr").value=gid('MF:txtFacilityCurr').value;
		 //Vinoth S Changes on 08-Dec-2010 Beg
		 //setAmount('MF:txtLcLiaAmtlimitAmt',objXMLApplet.getValue("AMT_AGNST_CURR"));Removed
		  gid('MF:txtLcLiaAmtlimitAmt').value=objXMLApplet.getValue("AMT_AGNST_CURR");
		 //Vinoth S Changes on 08-Dec-2010 End
	
			gid("MF:txtFacilitylimitCurr").value=objXMLApplet.getValue("SANC_CURR");
			//Changes P.Subramani-Chn-22/02/2008 
			gid("MF:txtoutstandingbeforeLcCurr").value=objXMLApplet.getValue("SANC_CURR");
			gid("MF:txtLcPendingCurr").value=objXMLApplet.getValue("SANC_CURR");
			//Changes P.Subramani-Chn-22/02/2008 
			gid("MF:txtoutstandingafterLcCurr").value=objXMLApplet.getValue("SANC_CURR");
			
			//Changes P.Subramani-Chn -24/07/2008 Beg
			/*if(gid('MF:seluseroption').value=="A")
			{*/
			/*gid("MF:txtLcPendingAmt").value=objXMLApplet.getValue("PEND_AMT");
			setAmount('MF:txtLcPendingAmt',objXMLApplet.getValue("PEND_AMT")); commented on 07-Jul-2018 */ 
			//changes in eolc on 07-Jul-2018 start
			gid("MF:txtLcPendingAmt").value=gid('MF:txtLcLiaAmtlimitAmt').value;
			setAmount('MF:txtLcPendingAmt',gid('MF:txtLcLiaAmtlimitAmt').value);
			//changes in eolc on 07-Jul-2018 end
			/*}
			else if(gid('MF:seluseroption').value == "M")
			{
				//Changes P.Subramani-Chn-04/04/2008 Beg
				if(objXMLApplet.getValue("PEND_AMT")=="")
				{
					gid('MF:txtLcPendingAmt').value=gid('MF:txtLcLiaAmtlimitAmt').value;
				}
				else
				{
					var _sumtotliablimcurr = unFormat(objXMLApplet.getValue("PEND_AMT"))*1;
					var _totliablimcurr = unFormat(gid('MF:txtLcLiaAmtlimitAmt').value)*1;
					var _lcpendsanc = (_sumtotliablimcurr)-(_totliablimcurr);
					gid('MF:txtLcPendingAmt').value = _lcpendsanc;
				}
				setAmount('MF:txtLcPendingAmt',gid('MF:txtLcPendingAmt').value);
				//Changes P.Subramani-Chn-04/04/2008 End
			}*/
			//Changes P.Subramani-Chn -24/07/2008 End
			
			//gid("MF:txtExcessOverCurr").value=objXMLApplet.getValue("SANC_CURR");
			gid("MF:txtExcOverlimitDueCurrTrancurr").value=objXMLApplet.getValue("SANC_CURR");
			setAmount('MF:txtFacilitylimitAmt',objXMLApplet.getValue("SANC_AMT"));
			//setAmount('MF:txtoutstandingbeforeLcAmt',objXMLApplet.getValue("OUTSTD_AMT"));
			
			//Changes P.Subramani-Chn-23/07/2008 Beg
				var outstd_amt;
				var outstd_amt1;
				var outstd_amt3;
				//Changes P.Subramani-Chn-10/09/2008 Beg
				var  lcliabamtlimtamt;
				lcliabamtlimtamt=parseFloat(unFormat(gid("MF:txtLcLiaAmtlimitAmt").value));
				//Changes P.Subramani-Chn-10/09/2008 End				
				outstd_amt = parseFloat(unFormat(objXMLApplet.getValue("OUTSTD_AMT")));
				if(outstd_amt < 0)
				{
					outstd_amt1 = outstd_amt * (-1);
					outstd_amt3 = outstd_amt;//ADDED ON 31/10/2018
					//Changes P.Subramani-Chn-10/09/2008 Beg
					if(gid('MF:seluseroption').value=="A")
					{
						gid('MF:txtoutstandingbeforeLcAmt').value=outstd_amt1;
					}
					else
					{
						if(outstd_amt1 > lcliabamtlimtamt)
						{
							gid('MF:txtoutstandingbeforeLcAmt').value=outstd_amt1-lcliabamtlimtamt;
						}
						else
						{
							gid('MF:txtoutstandingbeforeLcAmt').value=lcliabamtlimtamt-outstd_amt1;
						}
					}	
					//Changes P.Subramani-Chn-10/09/2008 End
				}
				else
				{
					//Changes P.Subramani-Chn-10/09/2008 Beg
					if(gid('MF:seluseroption').value=="A")
					{
						gid('MF:txtoutstandingbeforeLcAmt').value=outstd_amt;
					}
					else
					{
						if(outstd_amt > lcliabamtlimtamt)
						{
							gid('MF:txtoutstandingbeforeLcAmt').value=outstd_amt-lcliabamtlimtamt;
						}
						else
						{
							gid('MF:txtoutstandingbeforeLcAmt').value=lcliabamtlimtamt-outstd_amt;
						}
					}	
					//Changes P.Subramani-Chn-10/09/2008 End
				}
				setAmount('MF:txtoutstandingbeforeLcAmt',gid('MF:txtoutstandingbeforeLcAmt').value);
			//Changes P.Subramani-Chn-23/07/2008 End
			
			
			// Changes in eolc on 07-Jul-2018 start  
				
				objXMLApplet5.clearMap();
				objXMLApplet5.setValue("Package","panacea.OLCaction.eolcval");
				objXMLApplet5.setValue("ValidateToken","true");
				objXMLApplet5.setValue("Method","olclimitvalue");
				objXMLApplet5.setValue("OLC_BRN_CODE",gid('MF:txtbrncode').value);
				objXMLApplet5.setValue("OLC_DAY_SERIAL",gid('MF:txtpresansl').value);
				objXMLApplet5.setValue("OLC_ENTRY_DATE",gid('MF:txtpresanDate').value);
				objXMLApplet5.setValue("OLC_OUTSANDING_AMT",outstd_amt3);//MODIFIED ON 31/10/2018
				objXMLApplet5.setValue("OLC_LC_PENDING_AMT",gid("MF:txtLcPendingAmt").value);
				objXMLApplet5.sendAndReceive();
				var unused_limit;
				var after_lc;
				var excess_limit;
						
				unused_limit=objXMLApplet5.getValue("UNUSED_LIMIT_BAL");
				after_lc=objXMLApplet5.getValue("AFTER_LC");
				excess_limit=objXMLApplet5.getValue("EXCESS_LIMIT");
				
				gid('MF:txtunusedlimitCurr').value=objXMLApplet.getValue("SANC_CURR");
				gid('MF:txtunusedlimitAmt').value = unused_limit;
				setAmount('MF:txtunusedlimitAmt',gid('MF:txtunusedlimitAmt').value);
				gid('MF:txtoutstandingafterLcAmt').value = after_lc;
				setAmount('MF:txtoutstandingafterLcAmt',gid('MF:txtoutstandingafterLcAmt').value);
				gid('MF:txtExcOverlimitDueCurrTrancurrAmt').value = excess_limit;
				setAmount('MF:txtExcOverlimitDueCurrTrancurrAmt',gid('MF:txtExcOverlimitDueCurrTrancurrAmt').value);
				if(objXMLApplet5.getValue("ErrorMsg") != "")
				{
					setMsg(objXMLApplet5.getValue("ErrorMsg"));
					//gid('MF:txtConRateToLimitCurr').focus();
					return;  
				}
				// Changes in eolc on 07-Jul-2018  end
			
			
			//Changes P.Subramani-Chn-22/02/2008 Beg
			var lcliaamtlimitcurr = unFormat(gid("MF:txtLcLiaAmtlimitAmt").value)*1;
			var pamt=unFormat(gid("MF:txtLcPendingAmt").value)*1;
			var osamt=unFormat(gid("MF:txtoutstandingbeforeLcAmt").value)*1;
			//var facamt=unFormat(gid("MF:txtFacilitylimitAmt").value)*1;
			//Changes P.Subramani-Chn-22/02/2008 Beg
			var osaftlc= (lcliaamtlimitcurr)+ (osamt) + (pamt);
			/*gid('MF:txtoutstandingafterLcAmt').value = osaftlc;
			setAmount('MF:txtoutstandingafterLcAmt',gid('MF:txtoutstandingafterLcAmt').value); commented on 07-Jul-2018*/
			//gid("MF:txtExcessOverAmt").value=""; commented on 07-Jul-2018
			//gid("MF:txtExcOverlimitDueCurrTrancurrAmt").value="";
			
			if( unFormat(gid('MF:txtoutstandingafterLcAmt').value)*1 > unFormat(gid('MF:txtFacilitylimitAmt').value)*1)
			{
				var _outstdaftlc1 = unFormat(trim(gid('MF:txtoutstandingafterLcAmt').value));
				var _faclmt = unFormat(trim(gid('MF:txtFacilitylimitAmt').value));
				var _excoverlmt = (_outstdaftlc1) - (_faclmt);
				//commented on 07-Jul-2018 start
				//gid('MF:txtExcessOverAmt').value = _excoverlmt ;
				//setAmount('MF:txtExcessOverAmt',gid('MF:txtExcessOverAmt').value);
				//commented on 07-Jul-2018 end
			}
			/*if(!gid('MF:txtExcessOverAmt').value=="")
			{
				if( unFormat(gid('MF:txtExcessOverAmt').value)*1 < unFormat(gid('MF:txtLcLiaAmtlimitAmt').value)*1 )
				{
					 gid('MF:txtExcOverlimitDueCurrTrancurrAmt').value = gid('MF:txtExcessOverAmt').value;
					 setAmount('MF:txtExcOverlimitDueCurrTrancurrAmt',gid('MF:txtExcOverlimitDueCurrTrancurrAmt').value);
				}
				else if( unFormat(gid('MF:txtExcessOverAmt').value)*1 > unFormat(gid('MF:txtLcLiaAmtlimitAmt').value)*1 )
				{
					 gid('MF:txtExcOverlimitDueCurrTrancurrAmt').value = gid('MF:txtLcLiaAmtlimitAmt').value;
					 setAmount('MF:txtExcOverlimitDueCurrTrancurrAmt',gid('MF:txtExcOverlimitDueCurrTrancurrAmt').value);
				}
			} commented on 07-Jul-2018 */
			/*if(((pamt+osamt)-facamt) > 0)
			{
			gid("MF:txtExcessOverAmt").value=(pamt+osamt)-facamt;
			}
			else
			{
			gid("MF:txtExcessOverAmt").value=0;
			}
			setAmount('MF:txtExcessOverAmt',gid("MF:txtExcessOverAmt").value);
			
			var exceamt=unFormat(gid("MF:txtExcessOverAmt").value)*1;
			var lcliaamt=unFormat(gid("MF:txtLcLiaAmtlimitAmt").value)*1;
			var check;
			var w_eol_current_trans;
			
			check=lcliaamt-osamt+pamt;
			
			if(check>=facamt)
			{
			w_eol_current_trans=gid("MF:txtLcLiaAmtlimitAmt").value;
			}
			else if(facamt==0 || exceamt==0)
			{
			w_eol_current_trans=0;
			}
			else
			{
				if(exceamt > lcliaamt)
					{
						w_eol_current_trans=exceamt-lcliaamt;
						//gid("MF:txtExcOverlimitDueCurrTrancurrAmt").value=exceamt-lcliaamt;
					}
				else
					{
					w_eol_current_trans=exceamt;
					//gid("MF:txtExcOverlimitDueCurrTrancurrAmt").value=exceamt;
					}
			}		
			gid("MF:txtExcOverlimitDueCurrTrancurrAmt").value=w_eol_current_trans;
			setAmount('MF:txtExcOverlimitDueCurrTrancurrAmt',gid("MF:txtExcOverlimitDueCurrTrancurrAmt").value);*/
			setTabfocus("maintab","tcontent5");
			gid('MF:Next').focus();
		}
		//Changes P.Subramani-Chn-22/02/2008End
	}	
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
	function validateMarginCurrency()
	{
		if(gid("MF:txtmargincurr").value=="")
		{
			setMsg(BLANK_CHECK);
			gid('MF:txtmargincurr').focus();
			return;
		}
		else
		{
			objXMLApplet.clearMap();
			objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
			objXMLApplet.setValue("Method","olcLcCurrkeypress");
			objXMLApplet.setValue("ValidateToken", "true");
			objXMLApplet.setValue("OLC_LC_CURR",trim(gid('MF:txtmargincurr').value));
			objXMLApplet.sendAndReceive();
			if(objXMLApplet.getValue("ErrorMsg") != "")
			{
				setMsg(objXMLApplet.getValue("ErrorMsg"));
				gid('MF:txtmargincurr').focus();
				return;  
			}
			else
			{
				mardecilen="";
				mardecilen=objXMLApplet.getValue("REM_DEC_LEN");
				gid('MF:outlblmargincurr').innerText=objXMLApplet.getValue("REM_CURR_NAME");
				setTabfocus("maintab","tcontent6");
			}
	    }
  		/*if(unFormat(gid("MF:txtExcessOverAmt").value)*1==0 || unFormat(gid("MF:txtExcessOverAmt").value)*1==0.00)
  		{
			flag1=1;
			gid('MF:txtmarginpercentage1').value="";
			gid('MF:txtmarginamt2').value="";
			gid('MF:txtcashmarginamt2').value="";
			gid('MF:txtmarginpercentage1').disabled=true;
			gid('MF:txtmarginamt2').disabled=true;
			gid('MF:txtcashmarginamt2').disabled=true;
			gid('MF:txtmarginamtcurr').value=gid('MF:txtmargincurr').value;
			gid('MF:txtcashmargincurr').value=gid('MF:txtmargincurr').value;
			//gid("MF:txtmarginpercentage").value=100;
			gid("MF:txtmarginpercentage").focus();
  		} 
  		else commented on 07-Jul-2018 */ if(unFormat(gid("MF:txtExcOverlimitDueCurrTrancurrAmt").value)*1==unFormat(gid("MF:txtLcLiaAmtlimitAmt").value)*1)
  		{
			flag1=2;
			gid('MF:txtmarginpercentage').value="";
			gid('MF:txtmarginamt1').value="";
			gid('MF:txtcashmarginamt1').value="";
			gid('MF:txtmarginpercentage').disabled=true;
			gid('MF:txtmarginamt1').disabled=true;
			gid('MF:txtcashmarginamt1').disabled=true;
			gid('MF:txtmarginamtcurr').value=gid('MF:txtmargincurr').value;
			gid('MF:txtcashmargincurr').value=gid('MF:txtmargincurr').value;
	   		//gid("MF:txtmarginpercentage1").value=100;
	   		gid("MF:txtmarginpercentage1").focus();
		}
	    else
	    {
	   		flag1=3;
	   		gid("MF:txtmarginpercentage").focus();
			gid('MF:txtmarginamtcurr').value=gid('MF:txtmargincurr').value;
			gid('MF:txtcashmargincurr').value=gid('MF:txtmargincurr').value;
	    }
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
	function validateMarginPerc()
	{
		marginamt=0;
		w_eolm=0;
		if(gid("MF:txtmarginpercentage").value=="")
		{
			if(flag1==1)
			{
			setTabfocus("maintab","tcontent6");
			gid("MF:txtmarginamt1").focus();
			}
			else if(flag1==3)
			{
			setTabfocus("maintab","tcontent6");
			gid("MF:txtmarginpercentage1").focus();
			}
		}
		else
		{
			marginper=unFormat(gid("MF:txtmarginpercentage").value)*1;
		
			if( marginper > 100 )
			{
				setMsg("Margin Percentage Not To Exceed 100%");
				setTabfocus("maintab","tcontent6");
				gid("MF:txtmarginpercentage").focus();
			}
			/*else if(  ( marginper < lcpsmarginper ) )
			{
				setMsg("Margin Percentage Should Be >= LC PreSactioned Margin Percentage");
				setTabfocus("maintab","tcontent6");
				gid("MF:txtmarginpercentage").focus();
			}*/
			else
			{
			 	w_eolm_pc=unFormat(gid("MF:txtExcOverlimitDueCurrTrancurrAmt").value)/unFormat(gid("MF:txtLcLiaAmtlimitAmt").value);
	    		
	    		if(gid("MF:txtmargincurr").value==gid("MF:txtLCCurr").value)
    			{
    				w_totliabm=unFormat(gid("MF:txtTotalAmt").value);
    			}
	    		else if(gid("MF:txtmargincurr").value==baseCurrency)
    			{
    				w_totliabm=unFormat(gid("MF:txtpresentLcLiaAmt").value);
    			}
	    		else if(gid("MF:txtmargincurr").value==gid("MF:txtFacilityCurr").value)
    			{
    				w_totliabm=unFormat(gid("MF:txtLcLiaAmtlimitAmt").value);
    			}		
	    		
	    		if(unFormat(gid("MF:txtExcOverlimitDueCurrTrancurrAmt").value)!=0)
    			{
	    			w_eolm_pc=unFormat(gid("MF:txtExcOverlimitDueCurrTrancurrAmt").value)/unFormat(gid("MF:txtLcLiaAmtlimitAmt").value);
	    			w_eolm=w_totliabm*w_eolm_pc;
	    			w_amt=w_totliabm-w_eolm;
    			}
	    		else
    		   {
    		   		w_amt=w_totliabm;
    		   }	
	    			
	    	   if( marginper > 0 )
	    	   {
	    	   		if(unFormat(gid("MF:txtFacilitylimitAmt").value)!=0)
	    			{
		    			var moveamt=w_amt*(marginper/100);
		    			marginamt=moveamt;
		    			gid("MF:txtmarginamt1").value=moveamt;
		    			//setAmount('MF:txtmarginamt1',gid("MF:txtmarginamt1").value);
		    			//setTabfocus("maintab","tcontent6");
						
						if(flag1==1)
						{
							setTabfocus("maintab","tcontent6");
							gid("MF:txtmarginamt1").focus();
							return;
						}
						else if(flag1==3)
						{
							setTabfocus("maintab","tcontent6");
							gid("MF:txtmarginpercentage1").focus();
							return;
						}
	    			}
	    			else
	    			{
		    			var moveamt=w_totliabm*(marginper/100);
		    			marginamt=moveamt;
		    			gid("MF:txtmarginamt1").value=moveamt;
		    			//setAmount('MF:txtmarginamt1',gid("MF:txtmarginamt1").value);
		    			//setTabfocus("maintab","tcontent6");
		    			
						if(flag1==1)
						{
							setTabfocus("maintab","tcontent6");
							gid("MF:txtmarginamt1").focus();
						}
						else if(flag1==3)
						{
							setTabfocus("maintab","tcontent6");
							gid("MF:txtmarginpercentage1").focus();
						}
					}
	    		}	
    			else if(marginper==0)
    			{
					if(flag1==1)
					{
						setTabfocus("maintab","tcontent6");
						gid("MF:txtmarginamt1").focus();
					}
					else if(flag1==3)
					{
						setTabfocus("maintab","tcontent6");
						gid("MF:txtmarginpercentage1").focus();
					}
				}	
    	    }
	    }
     }	   
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
	function validateEOLMarginPerc() 
	{
		if(gid("MF:txtmarginpercentage1").value=="")
		{
			if(flag1==2)
			{
				setTabfocus("maintab","tcontent6");
				gid("MF:txtmarginamt2").focus();
			}
			else if(flag1==3)
			{
				setTabfocus("maintab","tcontent6");
				gid("MF:txtmarginamt1").focus();
			}
		}
		else
		{
			eolmarginper=unFormat(gid("MF:txtmarginpercentage1").value)*1;
			if( eolmarginper > 100 )
			{
				setMsg("Margin Percentage Not To Exceed 100%");
				setTabfocus("maintab","tcontent6");
				gid("MF:txtmarginpercentage1").focus();
				return;
			}
			if( eolmarginper > 0 )
			{
			 	w_eolm_pc=unFormat(gid("MF:txtExcOverlimitDueCurrTrancurrAmt").value)/unFormat(gid("MF:txtLcLiaAmtlimitAmt").value);
	    		
	    		if(w_eolm!=0)
    			{
	    			var moveamt1=w_eolm*(eolmarginper/100);
	    			gid("MF:txtmarginamt2").value="";//MODIFIED ON 31/10/2018 moveamt1
    			}
    			else
    			{
	    			if(gid("MF:txtmargincurr").value==gid("MF:txtLCCurr").value)
	    			{
	    				w_totliabm=unFormat(gid("MF:txtTotalAmt").value)*1;
	    			}
	    			if(gid("MF:txtmargincurr").value==baseCurrency)
	    			{
	    				w_totliabm=unFormat(gid("MF:txtpresentLcLiaAmt").value)*1;
	    			}
	    			if(gid("MF:txtmargincurr").value==gid("MF:txtFacilityCurr").value)
	    			{
	    				w_totliabm=unFormat(gid("MF:txtLcLiaAmtlimitAmt").value)*1;
	    			}		
	    			var eolamt=w_totliabm*(eolmarginper/100);
    				gid("MF:txtmarginamt2").value=eolamt;
    			}
				if(flag1==2)
				{
					setTabfocus("maintab","tcontent6");
					gid("MF:txtmarginamt2").focus();
				}
				else if(flag1==3)
				{
					setTabfocus("maintab","tcontent6");
					gid("MF:txtmarginamt1").focus();
				}
		  }
    	  else if(eolmarginper==0)
    	  {
    	  	if(flag1==2)
			{
				setTabfocus("maintab","tcontent6");
				gid("MF:txtmarginamt2").focus();
			}
			else if(flag1==3)
			{
				setTabfocus("maintab","tcontent6");
				gid("MF:txtmarginamt1").focus();
			}
		 }	
    	}
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------		
	function validateMarginAmt()
	{
		if(gid("MF:txtmarginamt1").value=="")
		{
			marginamt=unFormat(gid("MF:txtmarginamt1").value)*1;
						
			if(flag1==1)
			{
				gid("MF:txtmarginamt3").value="0";
				setTabfocus("maintab","tcontent6");
				gid("MF:txtcashmarginamt1").focus();
			}
			else if(flag1==3)
			{
				setTabfocus("maintab","tcontent6");
				gid("MF:txtmarginamt2").focus();
			}
		}
		
		marginamt=unFormat(gid("MF:txtmarginamt1").value)*1;
		
		if(marginamt>0)
		{
			if(gid("MF:txtmargincurr").value==gid("MF:txtLCCurr").value)
    		{
    			if( marginamt > unFormat(gid("MF:txtTotalAmt").value)*1 )
				{
					setMsg("Margin Amount Should Be <= LC Amount");
					setTabfocus("maintab","tcontent6");
					gid("MF:txtmarginamt1").focus();
					return;
				}
				else if(flag1==1)
				{
					gid("MF:txtmarginamt3").value=marginamt;
					setTabfocus("maintab","tcontent6");
					gid("MF:txtcashmarginamt1").focus();
					return;
				}
				else if(flag1==3)
				{
					setTabfocus("maintab","tcontent6");
					gid("MF:txtmarginamt2").focus();
					return;
				}	
			}		
			else if(gid("MF:txtmargincurr").value==gid("MF:txtFacilityCurr").value)
			{
				if( marginamt > unFormat(gid("MF:txtLcLiaAmtlimitAmt").value)*1 )
				{
					setMsg("Margin Amount Should Be <= LC Amount LC Liability Amount");
					setTabfocus("maintab","tcontent6");
					gid("MF:txtmarginamt1").focus();
					return;
				}
				else if(flag1==1)
				{
					gid("MF:txtmarginamt3").value=marginamt;
					setTabfocus("maintab","tcontent6");
					gid("MF:txtcashmarginamt1").focus();
				return;
				}
				else if(flag1==3)
				{
					setTabfocus("maintab","tcontent6");
					gid("MF:txtmarginamt2").focus();
					return;
				}	
			}
			else if(gid("MF:txtmargincurr").value==baseCurrency)
			{
				if( marginamt > unFormat(gid("MF:txtpresentLcLiaAmt").value)*1 )
				{
					setMsg("Margin Amount Should Be <= Amount in Base Currency");
					setTabfocus("maintab","tcontent6");
					gid("MF:txtmarginamt1").focus();
					return;
				}
				else if(flag1==1)
				{
					gid("MF:txtmarginamt3").value=marginamt;
					setTabfocus("maintab","tcontent6");
					gid("MF:txtcashmarginamt1").focus();
					return;
				}
				else if(flag1==3)
				{
					setTabfocus("maintab","tcontent6");
					gid("MF:txtmarginamt2").focus();
					return;
				}		
			}
		}
		else if(marginamt==0)
		{
			if(flag1==1)
			{
				gid("MF:txtmarginamt3").value=marginamt;
				setTabfocus("maintab","tcontent6");
				gid("MF:txtcashmarginamt1").focus();
			}
			else if(flag1==3)
			{
				setTabfocus("maintab","tcontent6");
				gid("MF:txtmarginamt2").focus();
			}	
		}
	}		
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------		
	function validateEOLMarginAmt()
	{
		if(gid("MF:txtmarginamt2").value=="")
		{
			eolmarginamt=unFormat(gid("MF:txtmarginamt2").value)*1;
			if(flag1==2)
			{
				gid("MF:txtmarginamt3").value="0";
				setTabfocus("maintab","tcontent6");
				gid("MF:txtcashmarginamt2").focus();
			}
			else if(flag1==3)
			{
				gid("MF:txtcashmarginamt3").value=marginamt;
				setTabfocus("maintab","tcontent6");
				gid("MF:txtcashmarginamt1").focus();
			}
		}
		eolmarginamt=unFormat(gid("MF:txtmarginamt2").value)*1;
		if(eolmarginamt > 0)
		{
			if(gid("MF:txtcashmarginamt2").value=="")
			{
				gid("MF:txtcashmarginamt2").value=eolmarginamt;
				if(flag1==2)
				{
					gid("MF:txtmarginamt3").value=eolmarginamt;
					setTabfocus("maintab","tcontent6");
					gid("MF:txtcashmarginamt2").focus();
				}
				else if(flag1==3)
				{
					gid("MF:txtmarginamt3").value=marginamt+eolmarginamt;
					setTabfocus("maintab","tcontent6");
					gid("MF:txtcashmarginamt1").focus();
				}
			}
			else
			{
				//Changes P.Subramani-Chn-23/05/2008 Beg
				gid("MF:txtcashmarginamt2").value=eolmarginamt;
				//Changes P.Subramani-Chn-23/05/2008 End
				if(flag1==2)
				{
					gid("MF:txtmarginamt3").value=eolmarginamt;
					setTabfocus("maintab","tcontent6");
					gid("MF:txtcashmarginamt2").focus();
				}
				else if(flag1==3)
				{
					gid("MF:txtmarginamt3").value=marginamt+eolmarginamt;
					setTabfocus("maintab","tcontent6");
					gid("MF:txtcashmarginamt1").focus();
				}
			}			
		}
		else if(eolmarginamt==0)
		{
			gid("MF:txtmarginamt3").value=marginamt+eolmarginamt;
			if(flag1==2)
			{
				gid("MF:txtmarginamt3").value=eolmarginamt;
				setTabfocus("maintab","tcontent6");
				gid("MF:txtcashmarginamt2").focus();
			}
			else if(flag1==3)
			{
				gid("MF:txtmarginamt3").value=marginamt+eolmarginamt;
				setTabfocus("maintab","tcontent6");
				gid("MF:txtcashmarginamt1").focus();
			}
		}
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------		
	function validateCashMargin()
	{
		var chargcode1;
		var chargcode2;
		var chargcode3;
		var totalcashamt; 
		 objTFMCharges.brncode=gid('MF:txtbrncode').value;
		 
		if(gid("MF:txtcashmarginamt1").value=="")
		{
			setMsg(BLANK_CHECK);
		    gid("MF:txtcashmarginamt1").focus();
		    return;
		}
		 
		if(gid("MF:txtcashmarginamt1").value=="0")
		{
			setMsg(ZERO_CHECK);
		    gid("MF:txtcashmarginamt1").focus();
		    return;
		}
	/*    if(gid("MF:txtcashmarginamt1").value=="")
		{
			if(flag1==1)
			{
				gid("MF:txtcashmarginamt3").value="0";
				setTabfocus("maintab","tcontent6");
				gid("MF:lstmargintypeforLC").focus();
				return;
			}
			else
			{
				setTabfocus("maintab","tcontent6");
				gid("MF:txtcashmarginamt2").focus();
				return;
			}
		}
	*/	
		if((unFormat(gid("MF:txtcashmarginamt1").value)*1)>(unFormat(gid("MF:txtmarginamt1").value)*1))
		{
			setMsg("Cash Margin Amount Should Be <= Margin Amount");
			gid('MF:txtcashmarginamt1').focus();
			return;  
		}
		
		//Changes P.Subramani-Chn-20/10/2008 
		var cashmarginamt=unFormat(gid("MF:txtcashmarginamt1").value)*1;
		
		if(cashmarginamt > 0)
		{
			if(flag1==1)
			{
				totalcashamt=cashmarginamt*1+unFormat(gid("MF:txtcashmarginamt2").value)*1;
				gid("MF:txtcashmarginamt3").value=totalcashamt;
				if(totalcashamt!=gid("MF:txtmarginamt3").value)
				{
					if(flag1==1)
					{
					setTabfocus("maintab","tcontent6");
					gid("MF:lstmargintypeforLC").focus();
					return;
					}
					else
					{
					setTabfocus("maintab","tcontent6");
					gid("MF:txtcashmarginamt2").focus();
					return;
					}
			   }
			   else
		 	   {
		 	   	    //Methods for calculating Usance and Commitment Charges
			    	//Changes P.Subramani-Chn-28/04/2008 Beg
			    	gettenortypechargecurroption();
			    	getcustno();
			    	//Changes P.Subramani-Chn-23/08/2008 Beg
			    	callusancechgs(row,col);
				    callusancechgstotvalue(row,col);
				    //Changes P.Subramani-Chn-23/08/2008 End
			    	
			    	
			    	getcommmonth();
				    callcommchgs();
				    //Changes P.Subramani-Chn-28/04/2008 End
							 
		 			if(gid('MF:seluseroption').value=="A")
		 			{
			 			objXMLApplet.clearMap();
						objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
						objXMLApplet.setValue("Method","olcChargeskeypress");
						objXMLApplet.setValue("ValidateToken", "true");
						objXMLApplet.setValue("OLC_LC_CURR",trim(gid('MF:txtLCCurr').value));
						objXMLApplet.setValue("OLC_LC_TYPE",trim(gid('MF:txtconttype').value));
						objXMLApplet.sendAndReceive();
						if(objXMLApplet.getValue("ErrorMsg") != "")
						{
							setMsg(objXMLApplet.getValue("ErrorMsg"));
							gid('MF:txtcashmarginamt1').focus();
							return;  
						}
						else
						{
							//S.Suresh Babu Add 30-06-2009
							trchg_commitmnt_chgcd=objXMLApplet.getValue("TRCHG_COMMITMNT_CHGCD");
							trchg_usance_chgcd=objXMLApplet.getValue("TRCHG_USANCE_CHGCD");
							chargcode1=objXMLApplet.getValue("TRCHG_COMMN_CHGCD");
							chargcode2=objXMLApplet.getValue("TRCHG_COURIER_CHGCD");
							chargcode3=objXMLApplet.getValue("TRCHG_POSTAL_CHGCD");
							/*var cahrgeList;
							cahrgeList=chargcode1;
							if(!(chargcode2==""))
							{
							cahrgeList=chargcode1+chargcode2;
							}
							if(!(chargcode3==""))
							{
							cahrgeList=chargcode1+"|"+chargcode2+"|"+chargcode3;
							}*///vv2
							objTFMCharges.prevTab="tcontent6";	
							objTFMCharges.prevFld="MF:txtcashmarginamt1";
						    objTFMCharges.nextFld="MF:txtusnchgsamt1";
							objTFMCharges.prevFld="MF:txtcashmarginamt1";
							objTFMCharges.custaccflag = 1;
						    objTFMCharges.internalaccno =intaccno;
						    //SUGANYA BEGIN 23-MAY-2017
							objTFMCharges.brncode=gid('MF:txtbrncode').value;
							
							//SUGANYA END 23-MAY-2017
						    //SUGANYA BEGIN 28-FEB-2017
							objTFMCharges.customerno=custno;
							objTFMCharges.brncode=gid('MF:txtbrncode').value;
							//SUGANYA END 28-FEB-2017
						    //Vinoth.S-Chns-09-12-2010-Beg
						     objTFMCharges.trandate = gid('MF:txtLCDate').value;
						    //Vinoth.S-Chns-09-12-2010-End
					    	objTFMCharges.AddOrModify  = gid('MF:seluseroption').value;
					    	objTFMCharges.chargeslist = objXMLApplet.getValue("TRCHG_COMMN_CHGCD")+"|"+objXMLApplet.getValue("TRCHG_COURIER_CHGCD")+"|"+objXMLApplet.getValue("TRCHG_POSTAL_CHGCD");
					    	objTFMCharges.trancurrency = baseCurrency;//gid('MF:txtLCCurr').value;
					    	objTFMCharges.tranamount = gid('MF:txtpresentLcLiaAmt').value;
					    	objTFMCharges.TRANCHGS_SL =  "0";
						    setTabfocus("maintab","tcontent7");
	                        objTFMCharges.Focus();	
						}
		 			}
		 			else
					{
						objTFMCharges.prevTab="tcontent6";	
						objTFMCharges.nextFld="MF:txtusnchgsamt1";
						objTFMCharges.prevFld="MF:txtcashmarginamt1";
						setTabfocus("maintab","tcontent7");
						objTFMCharges.FocusNextWithoutValidate();
					}
		 		}
			}
			else
			{
				setTabfocus("maintab","tcontent6");
				gid("MF:txtcashmarginamt2").focus();
				return;
			}	
		}
	}	
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------		
	function validateEOLCashMargin()
	{
		var chargcode1;
		var chargcode2;
		var chargcode3;
		
		//Changes P.Subramani-Chn-20/10/2008
		var cashmarginamt=unFormat(gid("MF:txtcashmarginamt1").value)*1;
	 objTFMCharges.brncode=gid('MF:txtbrncode').value;
		if(gid("MF:txtcashmarginamt2").value=="")
		{
			gid("MF:txtcashmarginamt3").value=cashmarginamt;
			setTabfocus("maintab","tcontent6");
			gid("MF:lstmargintypeforLC").focus();
			return;
		}
		if(eolmarginamt > 0)
		{
			eolcashmarginamt=unFormat(gid("MF:txtcashmarginamt2").value)*1;
			var tot=cashmarginamt+eolcashmarginamt;
			gid("MF:txtcashmarginamt3").value=tot;
			
			if(tot!=gid("MF:txtmarginamt3").value)
			{
				setTabfocus("maintab","tcontent6");
			 	gid("MF:lstmargintypeforLC").focus();
			 	return;
			}
			else
			{
				//Methods for calculating Usance and Commitment Charges
				//Changes P.Subramani-Chn-28/04/2008 Beg
			    gettenortypechargecurroption();
			    getcustno();
			    //Changes P.Subramani-Chn-23/08/2008 Beg
		    	callusancechgs(row,col);
			    callusancechgstotvalue(row,col);
			    //Changes P.Subramani-Chn-23/08/2008 End
			    
			    getcommmonth();
			    callcommchgs();
			    //Changes P.Subramani-Chn-28/04/2008 End
			
		 		if(gid('MF:seluseroption').value=="A")
		 		{
		 			objXMLApplet.clearMap();
					objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
					objXMLApplet.setValue("Method","olcChargeskeypress");
					objXMLApplet.setValue("ValidateToken", "true");
					objXMLApplet.setValue("OLC_LC_CURR",trim(gid('MF:txtLCCurr').value));
					objXMLApplet.setValue("OLC_LC_TYPE",trim(gid('MF:txtconttype').value));
					objXMLApplet.sendAndReceive();
					if(objXMLApplet.getValue("ErrorMsg") != "")
					{
						setMsg(objXMLApplet.getValue("ErrorMsg"));
						gid('MF:txtcashmarginamt2').focus();
						return;  
					}
					else
					{
						//S.Suresh Babu Add 30-06-2009
						trchg_commitmnt_chgcd=objXMLApplet.getValue("TRCHG_COMMITMNT_CHGCD");
						trchg_usance_chgcd=objXMLApplet.getValue("TRCHG_USANCE_CHGCD");
						chargcode1=objXMLApplet.getValue("TRCHG_COMMN_CHGCD");
						chargcode2=objXMLApplet.getValue("TRCHG_COURIER_CHGCD");
						chargcode3=objXMLApplet.getValue("TRCHG_POSTAL_CHGCD");
						/*var cahrgeList;
						cahrgeList=chargcode1;
						if(!(chargcode2==""))
						{
						cahrgeList=chargcode1+chargcode2;
						}
						if(!(chargcode3==""))
						{
						cahrgeList=chargcode1+"|"+chargcode2+"|"+chargcode3;
						}*///vv
						
						objTFMCharges.prevTab="tcontent6";	
						objTFMCharges.prevFld="MF:txtcashmarginamt2";
					    objTFMCharges.nextFld="MF:txtusnchgsamt1";
						objTFMCharges.custaccflag = 1;
						objTFMCharges.clearControl();//Jayakumaran CHG-02-06-2011
					    objTFMCharges.internalaccno =intaccno;
					     //SUGANYA BEGIN 23-MAY-2017
					objTFMCharges.brncode=gid('MF:txtbrncode').value;
					//SUGANYA END 23-MAY-2017
					    //SUGANYA BEGIN 28-FEB-2017
						objTFMCharges.customerno=gid('MF:txtcustnum1').value;
						
						//SUGANYA END 28-FEB-2017
					    
				        //Vinoth.S-Chns-09-12-2010-Beg
					    objTFMCharges.trandate = gid('MF:txtLCDate').value;
					    //Vinoth.S-Chns-09-12-2010-End
			    		objTFMCharges.AddOrModify  = gid('MF:seluseroption').value;
				    	objTFMCharges.chargeslist = objXMLApplet.getValue("TRCHG_COMMN_CHGCD")+"|"+objXMLApplet.getValue("TRCHG_COURIER_CHGCD")+"|"+objXMLApplet.getValue("TRCHG_POSTAL_CHGCD");
				    	objTFMCharges.trancurrency = baseCurrency;//gid('MF:txtLCCurr').value;
				    	objTFMCharges.tranamount = gid('MF:txtpresentLcLiaAmt').value;
				    	objTFMCharges.TRANCHGS_SL =  "0";
					    setTabfocus("maintab","tcontent7");
		                objTFMCharges.Focus();	
					}
		 		}
		 		else
				{
					objTFMCharges.prevTab="tcontent6";	
					objTFMCharges.prevFld="MF:txtcashmarginamt2";
				    objTFMCharges.nextFld="MF:txtusnchgsamt1";
					setTabfocus("maintab","tcontent7");
					objTFMCharges.FocusNextWithoutValidate();
				}		 	
			}
		}
	}	
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------				
	function validateMarginType()
	{     objTFMCharges.brncode=gid('MF:txtbrncode').value;
		/*if(gid("MF:lstmargintypeforLC").value=="")
		{
			setMsg(OPTION_MESSAGE);
			gid('MF:lstmargintypeforLC').focus();
			return;
		}
		else
		{*/
			//Methods for calculating Usance and Commitment Charges
			//Changes P.Subramani-Chn-10/04/2008 Beg
			gettenortypechargecurroption();
			getcustno();
			//Changes P.Subramani-Chn-23/08/2008 Beg
	    	callusancechgs(row,col);
		    callusancechgstotvalue(row,col);
		    //Changes P.Subramani-Chn-23/08/2008 End
		    
		    getcommmonth();
		    callcommchgs();
		    //Changes P.Subramani-Chn-10/04/2008 End
			
			//COMMENTED BY PRASHANTH
		   //BY PRASHANTH TREASURY CHANGES AND BUG IFX AS ON 18 AUGUST
			// if(gid('MF:seluseroption').value=="A")
	 		// {
	 			objXMLApplet.clearMap();
				objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
				objXMLApplet.setValue("Method","olcChargeskeypress");
				objXMLApplet.setValue("ValidateToken", "true");
				objXMLApplet.setValue("OLC_LC_CURR",trim(gid('MF:txtLCCurr').value));
				objXMLApplet.setValue("OLC_LC_TYPE",trim(gid('MF:txtconttype').value));
				objXMLApplet.sendAndReceive();
				if(objXMLApplet.getValue("ErrorMsg") != "")
				{
					setMsg(objXMLApplet.getValue("ErrorMsg"));
					gid('MF:lstmargintypeforLC').focus();
					return;  
				}
				else
				{
					//S.Suresh Babu Add 30-06-2009
					trchg_commitmnt_chgcd=objXMLApplet.getValue("TRCHG_COMMITMNT_CHGCD");
					trchg_usance_chgcd=objXMLApplet.getValue("TRCHG_USANCE_CHGCD");
					/*chargcode1=objXMLApplet.getValue("TRCHG_COMMN_CHGCD");
					chargcode2=objXMLApplet.getValue("TRCHG_COURIER_CHGCD");
					chargcode3=objXMLApplet.getValue("TRCHG_POSTAL_CHGCD");
					var cahrgeList;
					cahrgeList=chargcode1;
					if(!(chargcode2==""))
					{
					cahrgeList=chargcode1+chargcode2;
					}
					if(!(chargcode3==""))
					{
					cahrgeList=chargcode1+"|"+chargcode2+"|"+chargcode3;
					}*///vv1
					objTFMCharges.prevTab="tcontent6";	
					objTFMCharges.prevFld="MF:lstmargintypeforLC";
				    objTFMCharges.nextFld="MF:txtusnchgsamt1";
					objTFMCharges.custaccflag = 1;
			    	if(gid('MF:seluseroption').value=="A"){
				 	objTFMCharges.clearControl();//Jayakumaran CHG-06-06-2011	
					}
				  	objTFMCharges.AddOrModify  = gid('MF:seluseroption').value;
				  	   objTFMCharges.internalaccno =intaccno;
				  	   //SUGANYA BEGIN 23-MAY-2017
					objTFMCharges.brncode=gid('MF:txtbrncode').value;
					//SUGANYA END 23-MAY-2017
				  	   //SUGANYA BEGIN 28-FEB-2017
						objTFMCharges.customerno=gid('MF:txtcustnum1').value;
						
						//SUGANYA END 28-FEB-2017
			        //Vinoth.S-Chns-09-12-2010-Beg
				    objTFMCharges.trandate = gid('MF:txtLCDate').value;
				    //Vinoth.S-Chns-09-12-2010-End
		    	
			    	objTFMCharges.chargeslist = objXMLApplet.getValue("TRCHG_COMMN_CHGCD")+"|"+objXMLApplet.getValue("TRCHG_HANDLING_CHGCD")+"|"+objXMLApplet.getValue("TRCHG_COURIER_CHGCD")+"|"+objXMLApplet.getValue("TRCHG_POSTAL_CHGCD")+"|"+objXMLApplet.getValue("TRCHG_SWIFT_CHGCD");
			    	objTFMCharges.trancurrency = baseCurrency;//gid('MF:txtLCCurr').value;
			    	objTFMCharges.tranamount = gid('MF:txtpresentLcLiaAmt').value;
			    			   //BY PRASHANTH TREASURY CHANGES AND BUG IFX AS ON 18 AUGUST
			    	if(gid('MF:seluseroption').value=="A"){
			    	objTFMCharges.TRANCHGS_SL =  "0";
				    }
				    else{
   			    	objTFMCharges.TRANCHGS_SL =  gid('MF:txtchargessl1').value;
				    }
				    		   //BY PRASHANTH TREASURY CHANGES AND BUG IFX AS ON 18 AUGUST
				    //BY PRASHANTH TREASURY CHANGES AND BUG IFX AS ON 18 AUGUST
					objTFMCharges.prevTab="tcontent6";	
					objTFMCharges.prevFld="MF:lstmargintypeforLC";
					objTFMCharges.nextFld="MF:txtusnchgsamt1";
					setTabfocus("maintab","tcontent7");	
							   //BY PRASHANTH TREASURY CHANGES AND BUG IFX AS ON 18 AUGUST
			       if(gid('MF:seluseroption').value=="M"){
			       objTFMCharges.FocusNextWithoutValidate();
			       }
			       else{
			       objTFMCharges.Focus();
			       }
			       objTFMCharges.nextFld="MF:txtusnchgsamt1";
					  objTFMCharges.customerno=custno;
					  objTFMCharges.prevTab="tcontent6";	
						objTFMCharges.prevFld="MF:txtcashmarginamt2";
					    objTFMCharges.nextFld="MF:txtusnchgsamt1";
			       		   //BY PRASHANTH TREASURY CHANGES AND BUG IFX AS ON 18 AUGUST
			       
     				    //BY PRASHANTH TREASURY CHANGES AND BUG IFX AS ON 18 AUGUST
			       
				}
		}
		 	//}
		/* 	else
			{
				objTFMCharges.prevTab="tcontent6";	
				objTFMCharges.prevFld="MF:lstmargintypeforLC";
				objTFMCharges.nextFld="MF:txtusnchgsamt1";
				setTabfocus("maintab","tcontent7");
				objTFMCharges.FocusNextWithoutValidate();
			}*?
		//}
	}
	*/
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------			
	//Changes P.Subramani-Chn-10/04/2008 Beg
	function validateusnchgs()
	{
		//S.Suresh Babu Add 30-06-2009
		callflag="U";
		if(gid("MF:txtusnchgsamt1").value!="")
		{
			getservicetax();
		}
		else
		{
			setAmount('MF:txtusnchgsamt1',"0");
			setAmount('MF:txtusanceservamt1',"0");	
		}	
		setTabfocus("maintab","tcontent7");
		gid('MF:txtcommchgsamt1').focus();
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------			
	function validatecommchgs()
	{	
		//S.Suresh Babu Add 30-06-2009
		callflag="C";
		if(gid("MF:txtcommchgsamt1").value!="")
		{
			getservicetax();
		}
		else
		{
			setAmount('MF:txtcommchgsamt1',"0");
			setAmount('MF:txtcommservamt1',"0");
		}	
		//Changes P.Subramani-Chn-19/08/2008 Beg
		var usancecharge=unFormat(gid("MF:txtusnchgsamt1").value)*1;
		var commitcharge=unFormat(gid("MF:txtcommchgsamt1").value)*1;
		var usanceservamt=unFormat(gid("MF:txtusanceservamt1").value)*1;
		var commservamt=unFormat(gid("MF:txtcommservamt1").value)*1;
		var totalcharge=parseFloat(totalamount)+parseFloat(usancecharge)+parseFloat(commitcharge)+parseFloat(usanceservamt)+parseFloat(commservamt);
		//S.Suresh Babu Changes 24-09-2009
		gid('MF:txtchargeamt').value=totalcharge;
		if(parseFloat(totalcharge) == 0)
		//Changes P.Subramani-Chn-19/08/2008 End
		{
			//S.Suresh Babu Changes 24-09-2009
			objTranStmntPost.clearControl();
			//setTabfocus("maintab","tcontent7");
			//gid('MF:Submit').focus(); 
			setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1"); gid('MF:lstcredit').focus() ;
		}
		else
		{
			setTabfocus("maintab","tcontent7");
			gid('MF:Next1').focus();
		}
	}
	//S.Suresh Babu Add 30-06-2009
	function getservicetax()
	{
		objXMLApplet.clearMap();
		objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
		objXMLApplet.setValue("Method","servicetaxkeypress");
		objXMLApplet.setValue("ValidateToken","true");
		if(callflag=="C")
		{
			objXMLApplet.setValue("ACTUAL_CHG_AMT",gid('MF:txtcommchgsamt1').value);
			objXMLApplet.setValue("CHARGE_CODE",trchg_commitmnt_chgcd);
		}
		else
		{
		//vinoth- beg
			        objXMLApplet1.clearMap();         			
					objXMLApplet1.setValue("Package", "panaceaweb.utility");
					objXMLApplet1.setValue("SQLToken","Valolc1");
					Args = gid('MF:txtbrncode').value+"|"+gid('MF:txtconttype').value+"|"+gid('MF:txtcontyear').value+"|"+gid("MF:txtcontsl").value;
					objXMLApplet1.setValue ("Args",Args);
					objXMLApplet1.setValue("DataTypes","N|S|N|N");     
					objXMLApplet1.sendAndReceive();
					/*if (objXMLApplet1.getValue("ErrorMsg") != "")
					{	
						setMsg(objXMLApplet1.getValue("ErrorMsg"));
						gid('MF:txtcontsl').focus();
						return;
					} 
					if(objXMLApplet1.getValue("Result")=="RowPresent")
					{
					objXMLApplet.setValue("ACTUAL_CHG_AMT",gid('MF:txtusnchgsamt1').value);
					objXMLApplet.setValue("CHARGE_CODE",objXMLApplet1.getValue("OLC_USANCE_CHARGES");
					}
					*/
			objXMLApplet.setValue("ACTUAL_CHG_AMT",gid('MF:txtusnchgsamt1').value); //removed by vinoth
			objXMLApplet.setValue("CHARGE_CODE",trchg_usance_chgcd);//removed by vinoth
				//vinoth- end
			//vinoth   olc_usance_serv_tax
			
		}
		objXMLApplet.setValue("BASE_CURR_CODE",baseCurrency);
		objXMLApplet.setValue("INTERNAL_ACC_NUM",gid("MF:txtintaccno").value);
		//SUGANYA BEGIN 19-JUN-2017
		objXMLApplet.setValue("BRN_CODE",gid("MF:txtbrncode").value);
		//SUGANYA END 19-JUN-2017
		objXMLApplet.sendAndReceive();
		if (objXMLApplet.getValue("ErrorMsg") != "")
		{
			setMsg(objXMLApplet.getValue("ErrorMsg"));
			setTabfocus("maintab","tcontent7");
			if(callflag=="C")
				gid('MF:txtcommchgsamt1').focus();
			else
				gid('MF:txtusnchgsamt1').focus();
           	return false;
		}
		else
		{
			if(callflag=="C")
				setAmount('MF:txtcommservamt1',objXMLApplet.getValue("SERVICE_AMOUNT"));
			else
				setAmount('MF:txtusanceservamt1',objXMLApplet.getValue("SERVICE_AMOUNT"));
		}
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------					
	function callusancechgs(row,col)
	{
		//S.Suresh Babu Changes 24-09-2009 Beg
		//var convrate = parseFloat(equiamt)/parseFloat(amttobecon);
		var convrate;
		if(gid('MF:txtLCCurr').value==baseCurrency)
		{
			convrate="1";
		}
		else{
			gettingconvRate();	
			convrate=objXMLApplet.getValue("CONVER_RATE");
		}
		
		//S.Suresh Babu Changes 24-09-2009 End		
		for(var i=1;i<=gridEoladd.getRowsNum();i++)
		{
			objXMLApplet.clearMap();
			objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
			objXMLApplet.setValue("Method","olcusancekeypress");
	        objXMLApplet.setValue("ValidateToken","true");
	        objXMLApplet.setValue("OLC_PROD_CODE",trim(gid('MF:txtproductcode').value));
	        objXMLApplet.setValue("OLC_LC_TYPE",trim(gid('MF:txtconttype').value));
	        //Changes P.Subramani-Chn-28/04/2008
			objXMLApplet.setValue("OLC_CUST_NUM",custno);
			//Changes P.Subramani-Chn-16/06/2008 Beg
			//Changes P.Subramani-Chn-23/08/2008 Beg
			if(gid("MF:txtLCCurr").value==baseCurrency)
			{
				objXMLApplet.setValue("OLC_LC_AMT",unFormat(gridEoladd.cells(i,16).getValue()));
			}
			else
			{
				//if chargecurroption is basecurrency or transaction currency
				if(chargecurroption=="B")
				{
					if(gid("MF:TFMCRatesDetails:txtfwdconttype").value=="1")
					{
						objXMLApplet.setValue("OLC_LC_AMT",parseFloat(unFormat(gridEoladd.cells(i,16).getValue()))*parseFloat(unFormat(gid("MF:TFMCRatesDetails:txtconvrate").value)));
					}
					else
					{
						objXMLApplet.setValue("OLC_LC_AMT",parseFloat(unFormat(gridEoladd.cells(i,16).getValue()))* convrate);
					}
				}
				else
				{
					objXMLApplet.setValue("OLC_LC_AMT",unFormat(gridEoladd.cells(i,16).getValue()));
				}
			}
			//Changes P.Subramani-Chn-16/06/2008 End
			if(gridEoladd.cells(i,14).getValue()=="")
			{
				objXMLApplet.setValue("OLC_LC_DAYS",0);
			}
			else
			{
				objXMLApplet.setValue("OLC_LC_DAYS",gridEoladd.cells(i,14).getValue());
			}
			objXMLApplet.setValue("OLC_TENOR_TYPE",gridEoladd.cells(i,1).getValue());
			objXMLApplet.sendAndReceive();
			if(objXMLApplet.getValue("ErrorMsg") != "")
			{
	  			setMsg(objXMLApplet.getValue("ErrorMsg"));
	  			setTabfocus("maintab","tcontent7");
				gid('MF:txtusnchgsamt1').focus();
				return false;  
			}
			else  
			{
				/*//Changes P.Subramani-Chn-11/04/2008 Beg
				gid('MF:txtusnchgscurr').value=baseCurrency;
				setAmount('MF:txtusnchgsamt',objXMLApplet.getValue("USANCE_CHGS"));
				gid('MF:txtusnchgscurr1').value=baseCurrency;
				setAmount('MF:txtusnchgsamt1',objXMLApplet.getValue("USANCE_CHGS"));
				gid('MF:txtusnchgstakendays').value=objXMLApplet.getValue("USANCE_CHGS_TAKEN_DAYS");
				return true;
				//Changes P.Subramani-Chn-11/04/2008 End 	*/
				gridEoladd.cells(i,17).setValue(2);
				gridEoladd.cells(i,18).setValue(objXMLApplet.getValue("USANCE_CHGS"));
				gridEoladd.cells(i,19).setValue(objXMLApplet.getValue("USANCE_CHGS_TAKEN_DAYS"));
			}
		}
		//Changes P.Subramani-Chn-23/08/2008 End	
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------					
	//Changes P.Subramani-Chn-23/08/2008 Beg
	function callusancechgstotvalue(row,col)
	{
		var Total=0;
		for(var i=1;i<=gridEoladd.getRowsNum();i++)
		{
			Total=Total+unFormat(gridEoladd.cells(i,18).getValue())*1;
		}
		gid('MF:txtusnchgscurr').value=baseCurrency;
		gid('MF:txtusnchgsamt').value=Total;
		setAmount('MF:txtusnchgsamt',gid('MF:txtusnchgsamt').value);
		gid('MF:txtusnchgscurr1').value=baseCurrency;
		//S.Suresh Babu Changes 24-09-2009
		if(trim(gid('MF:txtusnchgsamt1').value)=="")
			gid('MF:txtusnchgsamt1').value=Total;
		setAmount('MF:txtusnchgsamt1',gid('MF:txtusnchgsamt1').value);
	}
	//Changes P.Subramani-Chn-23/08/2008 End	
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------			
	function callcommchgs()
	{
		objXMLApplet.clearMap();
		objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
		objXMLApplet.setValue("Method","olccommkeypress");
        objXMLApplet.setValue("ValidateToken","true");
        objXMLApplet.setValue("OLC_PROD_CODE",trim(gid('MF:txtproductcode').value));
        objXMLApplet.setValue("OLC_LC_TYPE",trim(gid('MF:txtconttype').value));
        //Changes P.Subramani-Chn-28/04/2008
		objXMLApplet.setValue("OLC_CUST_NUM",custno);
		//Changes P.Subramani-Chn-16/06/2008 Beg
		if(gid("MF:txtLCCurr").value==baseCurrency)
		{
			objXMLApplet.setValue("OLC_LC_AMT",unFormat(gid("MF:txtTotalAmt").value));
		}
		else
		{
			objXMLApplet.setValue("OLC_LC_AMT",unFormat(gid("MF:TFMCRatesDetails:txtequivamt").value));
		}
		//Changes P.Subramani-Chn-16/06/2008 End
		objXMLApplet.setValue("OLC_LC_DAYS",olccommmonth);
		objXMLApplet.sendAndReceive();
		if(objXMLApplet.getValue("ErrorMsg") != "")
		{
  			setMsg(objXMLApplet.getValue("ErrorMsg"));
  			setTabfocus("maintab","tcontent7");
			gid('MF:txtcommchgsamt1').focus();
			return;  
		}
		else  
		{
			//Changes P.Subramani-Chn-11/04/2008 Beg
			gid('MF:txtcommchgscurr').value=baseCurrency;
			setAmount('MF:txtcommchgsamt',objXMLApplet.getValue("COMM_CHGS"));
			gid('MF:txtcommchgscurr1').value=baseCurrency;
			//S.Suresh Babu Changes 24-09-2009			
			if(trim(gid('MF:txtcommchgsamt1').value)=="")
				setAmount('MF:txtcommchgsamt1',objXMLApplet.getValue("COMM_CHGS"));
			gid('MF:txtcommchgstakendays').value=objXMLApplet.getValue("COMM_CHGS_TAKEN_DAYS");
			//Changes P.Subramani-Chn-11/04/2008 End 
		}	
	}
//Changes P.Subramani-Chn-10/04/2008 End	
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------			
	function formKeyDown()
	{
		if (window.event.keyCode ==KEY_ESC)
	    {
			switch(lastEntdFld.name)
		    {
	    	   case"MF:seluseroption"				: 	
														exitPage();
	    	     									 	break;
    	     	case"MF:TFMCRatesDetails:cmdOk"		: 	
														conRateToBaseCurr();
	    	     									 	break;
    	     	default						 		: 
				        	     	   					cancelPage();
        	    				   						break;
	        }
        }
        		 //Changes P.Subramani-Chn-21/02/2008
        		/*if((window.event.keyCode == KEY_ENTER)&&(trim(gid("MF:TFMChargesDetails:outtxttotal").value) == 0)&&(objTFMCharges.exitCont==true))
		        {  
		        	focusflag=true;
		        	objTFMCharges.exitCont=false;
		        	gid('MF:txtchargeamt').value=gid("MF:TFMChargesDetails:outtxttotal").value;
		        	
		        }
		        if(focusflag==true)
		        {
		        	focusflag=false;
		        	gid('MF:Submit').focus();
		        }*/
        		 
		 if((window.event.keyCode == KEY_ENTER)&&(gid("MF:TFMChargesDetails:outtxttotal").value != ""))
	     {  
	       	recoverycurr = gid("MF:TFMChargesDetails:txtchgsreccurr").value;
	        totalamount  = gid("MF:TFMChargesDetails:outtxttotal").value;
	        //gid('MF:txtchargecurr').value=gid("MF:TFMChargesDetails:txtchgsreccurr").value;
	        //gid('MF:txtchargeamt').value=gid("MF:TFMChargesDetails:outtxttotal").value;   
	     }
	     if((window.event.keyCode == KEY_ENTER)&&(gid("MF:TFMCRatesDetails:txtequivamt").value != ""))
	     {
	      	equiamt= unFormat(gid("MF:TFMCRatesDetails:outequivamt").value)*1;
			amttobecon=unFormat(gid("MF:TFMCRatesDetails:outtotconvamt").value)*1;
		 }
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------				   	
	//S.Suresh Babu Changes 24-09-2009 Beg
	function gettingconvRate()
	{
		equiamt= unFormat(gid("MF:TFMCRatesDetails:outequivamt").value)*1;
		amttobecon=unFormat(gid("MF:TFMCRatesDetails:outtotconvamt").value)*1;
		objXMLApplet.clearMap();
		objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
		objXMLApplet.setValue("ValidateToken","true");
		objXMLApplet.setValue("Method","fetchconvrate");
		objXMLApplet.setValue("LC_CURR",gid('MF:txtLCCurr').value);
		objXMLApplet.setValue("BASE_CURR",baseCurrency);
		objXMLApplet.setValue("TOT_EQV_AMT",equiamt);
		objXMLApplet.setValue("AMT_CONV",amttobecon);
		//ADDED ON 01/10/2018 START
		objXMLApplet.setValue("TRAN_DATE",gid('MF:txtLCDate').value);
		objXMLApplet.setValue("TYPE","N");
		//ADDED ON 01/10/2018 END
		objXMLApplet.sendAndReceive();
		if(objXMLApplet.getValue("ErrorMsg") != "")
		{
			setMsg(objXMLApplet.getValue("ErrorMsg"));
			gid('MF:txtConRateToLimitCurr').focus();
			return;  
		}
	}
	//S.Suresh Babu Changes 24-09-2009 End
	function conRateToBaseCurr()
	{
		//Changes P.Subramani-Chn-21/02/2008
		var avg;
		if(gid('MF:txtLCCurr').value==baseCurrency)
		{
			avg=1;
		}
		else
		{
			//S.Suresh Babu Changes 24-09-2009 Beg
			//avg=parseFloat(equiamt)/parseFloat(amttobecon);
			gettingconvRate();
			avg=objXMLApplet.getValue("CONVER_RATE");
			//S.Suresh Babu Changes 24-09-2009 End
		}
		objXMLApplet.clearMap();
		objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
		objXMLApplet.setValue("ValidateToken","true");
		objXMLApplet.setValue("Method","olcConvRateBaseCurrkeypress");
		objXMLApplet.setValue("OLC_LC_CURR",gid('MF:txtLCCurr').value);
		objXMLApplet.setValue("BASE_CURR",baseCurrency);
		objXMLApplet.setValue("TOTAL",unFormat(trim(gid('MF:txtTotalAmt').value)));
		objXMLApplet.setValue("OLC_CONV_RATE_LIM_CURR",avg);
		objXMLApplet.sendAndReceive();
		if(objXMLApplet.getValue("ErrorMsg") != "")
		{
			setMsg(objXMLApplet.getValue("ErrorMsg"));
			gid('MF:txtConRateToLimitCurr').focus();
			return;  
		}
		else 
		{
			basedecilen=objXMLApplet.getValue("BASE_CURR_DECI_LEN");
			gid('MF:txtpresentLcLiaCurr').value=baseCurrency;
			if(gid('MF:txtLCCurr').value==baseCurrency)
			{
				setAmount('MF:txtpresentLcLiaAmt',gid('MF:txtTotalAmt').value);
			}
			else
			{
				setAmount('MF:txtpresentLcLiaAmt',objXMLApplet.getValue("AGAINST_AMT"));
			}
		}
		
		if(baseCurrency == gid('MF:txtFacilityCurr').value)
		{
			gid('MF:txtConRateToLimitCurr').value=avg;
			setAmount('MF:txtConRateToLimitCurr',gid("MF:txtConRateToLimitCurr").value);
			if(gid('MF:txtLCCurr').value==baseCurrency)
			{
				setAmount('MF:txtpresentLcLiaAmt',gid('MF:txtTotalAmt').value);
			}
			else
			{
				gid('MF:txtpresentLcLiaAmt').value=equiamt;
				setAmount('MF:txtpresentLcLiaAmt',gid('MF:txtpresentLcLiaAmt').value);
			}
			objXMLApplet.clearMap();
			objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
			objXMLApplet.setValue("ValidateToken","true");
			objXMLApplet.setValue("Method","olcConvRateLimCurrkeypress");
			objXMLApplet.setValue("OLC_LC_CURR",gid('MF:txtLCCurr').value);
			objXMLApplet.setValue("OLC_LIMIT_CURR",gid('MF:txtFacilityCurr').value);
			objXMLApplet.setValue("TOTAL",unFormat(trim(gid('MF:txtTotalAmt').value)));
			objXMLApplet.setValue("OLC_CONV_RATE_LIM_CURR",avg);
			objXMLApplet.setValue("OLC_LIMIT_LINE_NO",gid('MF:txtLimitLineNo').value);
			objXMLApplet.setValue("OLC_CUST_NO",gid('MF:txtcustnum1').value);
			objXMLApplet.setValue("OLC_BRANCH_CODE",gid('MF:txtbrncode').value);
			objXMLApplet.setValue("OLC_INTERNAL_ACC_NO",intaccno);
			//Vinoth S Changes on 08-Dec-2010 Beg For Rounding Off Value
			objXMLApplet.setValue("TRAN_DATE",gid('MF:txtLCDate').value);
			objXMLApplet.setValue("TYPE","N");
	    	//Vinoth S Changes on 08-Dec-2010 End
			objXMLApplet.sendAndReceive();
			if(objXMLApplet.getValue("ErrorMsg") != "")
			{
				setMsg(objXMLApplet.getValue("ErrorMsg"));
				gid('MF:txtConRateToLimitCurr').focus();
				return;  
			}
			else 
			{
				limitdecilen=objXMLApplet.getValue("DEC_LEN2");
				gid("MF:txtLcLiaAmtlimitCurr").value=gid('MF:txtFacilityCurr').value;
				gid("MF:txtLcLiaAmtlimitAmt").value=objXMLApplet.getValue("AMT_AGNST_CURR");
				//setAmount('MF:txtLcLiaAmtlimitAmt',gid("MF:txtLcLiaAmtlimitAmt").value);
				gid("MF:txtFacilitylimitCurr").value=objXMLApplet.getValue("SANC_CURR");
				//Changes P.Subramani-Chn-22/02/2008
				gid("MF:txtoutstandingbeforeLcCurr").value=objXMLApplet.getValue("SANC_CURR");
				gid("MF:txtLcPendingCurr").value=objXMLApplet.getValue("SANC_CURR");
				gid("MF:txtoutstandingafterLcCurr").value=objXMLApplet.getValue("SANC_CURR");
				
				//Changes P.Subramani-Chn-24/07/2008 Beg
				
				/*if(gid('MF:seluseroption').value=="A")
				{*/
				/*gid("MF:txtLcPendingAmt").value=objXMLApplet.getValue("PEND_AMT");
				setAmount('MF:txtLcPendingAmt',objXMLApplet.getValue("PEND_AMT")); commented on 07-Jul-2018 */ 
				//changes in eolc on 07-Jul-2018 start
				gid("MF:txtLcPendingAmt").value=gid('MF:txtLcLiaAmtlimitAmt').value;
				setAmount('MF:txtLcPendingAmt',gid('MF:txtLcLiaAmtlimitAmt').value);
				//changes in eolc on 07-Jul-2018 end
				/*}
				else if(gid('MF:seluseroption').value == "M")
				{
					//Changes P.Subramani-Chn-04/04/2008 Beg
					if(objXMLApplet.getValue("PEND_AMT")=="")
					{
						gid('MF:txtLcPendingAmt').value=gid('MF:txtLcLiaAmtlimitAmt').value;
					}
					else
					{
						var _sumtotliablimcurr = unFormat(trim(objXMLApplet.getValue("PEND_AMT")));
						var _totliablimcurr = unFormat(gid('MF:txtLcLiaAmtlimitAmt').value)*1;
						var _lcpendsanc = (_sumtotliablimcurr)-(_totliablimcurr);
						gid('MF:txtLcPendingAmt').value = _lcpendsanc;
					}	
					setAmount('MF:txtLcPendingAmt',gid('MF:txtLcPendingAmt').value);
					//Changes P.Subramani-Chn-04/04/2008 End
				}*/ 
				//Changes P.Subramani-Chn-24/07/2008 End
				//gid("MF:txtExcessOverCurr").value=objXMLApplet.getValue("SANC_CURR");
				gid("MF:txtExcOverlimitDueCurrTrancurr").value=objXMLApplet.getValue("SANC_CURR");
				setAmount('MF:txtFacilitylimitAmt',objXMLApplet.getValue("SANC_AMT"));
				//Changes P.Subramani-Chn-22/02/2008
				//setAmount('MF:txtoutstandingbeforeLcAmt',objXMLApplet.getValue("OUTSTD_AMT"));
			
				//Changes P.Subramani-Chn-23/07/2008 Beg
				var outstd_amt;
				var outstd_amt1;
				var outstd_amt3;
				//Changes P.Subramani-Chn-10/09/2008 Beg
				var  lcliabamtlimtamt;
				lcliabamtlimtamt=parseFloat(unFormat(gid("MF:txtLcLiaAmtlimitAmt").value));
				//Changes P.Subramani-Chn-10/09/2008 End
				outstd_amt = parseFloat(unFormat(objXMLApplet.getValue("OUTSTD_AMT")));
				if(outstd_amt < 0)
				{
					outstd_amt1 = outstd_amt * (-1);
					outstd_amt3 = outstd_amt;//ADDED ON 31/10/2018
					//Changes P.Subramani-Chn-10/09/2008 Beg
					if(gid('MF:seluseroption').value=="A")
					{
						gid('MF:txtoutstandingbeforeLcAmt').value=outstd_amt1;
					}
					else
					{
						if(outstd_amt1 > lcliabamtlimtamt)
						{
							gid('MF:txtoutstandingbeforeLcAmt').value=outstd_amt1-lcliabamtlimtamt;
						}
						else
						{
							gid('MF:txtoutstandingbeforeLcAmt').value=lcliabamtlimtamt-outstd_amt1;
						}
					}	
					//Changes P.Subramani-Chn-10/09/2008 End			
				}
				else
				{
					//Changes P.Subramani-Chn-10/09/2008 Beg
					if(gid('MF:seluseroption').value=="A")
					{
						gid('MF:txtoutstandingbeforeLcAmt').value=outstd_amt;
					}
					else
					{
						if(outstd_amt > lcliabamtlimtamt)
						{
							gid('MF:txtoutstandingbeforeLcAmt').value=outstd_amt-lcliabamtlimtamt;
						}
						else
						{
							gid('MF:txtoutstandingbeforeLcAmt').value=lcliabamtlimtamt-outstd_amt;
						}
					}
					//Changes P.Subramani-Chn-10/09/2008 End						
				}
				setAmount('MF:txtoutstandingbeforeLcAmt',gid('MF:txtoutstandingbeforeLcAmt').value);
				//Changes P.Subramani-Chn-23/07/2008 End
				
				// Changes in eolc on 07-Jul-2018 start  
				
				objXMLApplet5.clearMap();
				objXMLApplet5.setValue("Package","panacea.OLCaction.eolcval");
				objXMLApplet5.setValue("ValidateToken","true");
				objXMLApplet5.setValue("Method","olclimitvalue");
				objXMLApplet5.setValue("OLC_BRN_CODE",gid('MF:txtbrncode').value);
				objXMLApplet5.setValue("OLC_DAY_SERIAL",gid('MF:txtpresansl').value);
				objXMLApplet5.setValue("OLC_ENTRY_DATE",gid('MF:txtpresanDate').value);
				objXMLApplet5.setValue("OLC_OUTSANDING_AMT",outstd_amt3);//MODIFIED ON 31/10/2018
				objXMLApplet5.setValue("OLC_LC_PENDING_AMT",unFormat(gid("MF:txtLcPendingAmt").value));
				
				objXMLApplet5.sendAndReceive();
				
				var unused_limit;
				var after_lc;
				var excess_limit;
						
				unused_limit=objXMLApplet5.getValue("UNUSED_LIMIT_BAL");
				after_lc=objXMLApplet5.getValue("AFTER_LC");
				excess_limit=objXMLApplet5.getValue("EXCESS_LIMIT");
						
				gid('MF:txtunusedlimitCurr').value=objXMLApplet.getValue("SANC_CURR");
				gid('MF:txtunusedlimitAmt').value = unused_limit;
				setAmount('MF:txtunusedlimitAmt',gid('MF:txtunusedlimitAmt').value);
				gid('MF:txtoutstandingafterLcAmt').value = after_lc;
				setAmount('MF:txtoutstandingafterLcAmt',gid('MF:txtoutstandingafterLcAmt').value);
				gid('MF:txtExcOverlimitDueCurrTrancurrAmt').value = excess_limit;
				setAmount('MF:txtExcOverlimitDueCurrTrancurrAmt',gid('MF:txtExcOverlimitDueCurrTrancurrAmt').value);
				if(objXMLApplet5.getValue("ErrorMsg") != "")
				{
					setMsg(objXMLApplet5.getValue("ErrorMsg"));
					//gid('MF:txtConRateToLimitCurr').focus();
					return;  
				}
				// Changes in eolc on 07-Jul-2018  end
				  
				//var outamt=objXMLApplet.getValue("OUTSTD_AMT");
				//var outamt1=(outamt)*1+unFormat(gid("MF:txtLcLiaAmtlimitAmt").value)*1;
				//gid("MF:txtoutstandingbeforeLcAmt").value=outamt;
				
				//setAmount('MF:txtoutstandingbeforeLcAmt',gid("MF:txtoutstandingbeforeLcAmt").value);
				//Changes P.Subramani-Chn-22/02/2008 Beg
				var lcliaamtlimitcurr = unFormat(gid("MF:txtLcLiaAmtlimitAmt").value)*1;
				var pamt=unFormat(gid("MF:txtLcPendingAmt").value)*1;
				var osamt=unFormat(gid("MF:txtoutstandingbeforeLcAmt").value)*1;
				//var facamt=unFormat(gid("MF:txtFacilitylimitAmt").value)*1;
				//Changes P.Subramani-Chn-22/02/2008 Beg
				var osaftlc= (lcliaamtlimitcurr)+ (osamt) + (pamt);
				/*gid('MF:txtoutstandingafterLcAmt').value = osaftlc;
				setAmount('MF:txtoutstandingafterLcAmt',gid('MF:txtoutstandingafterLcAmt').value); commented on 07-Jul-2018*/
				//gid("MF:txtExcessOverAmt").value=""; commented on 07-Jul-2018
				//gid("MF:txtExcOverlimitDueCurrTrancurrAmt").value="";
				
				if( unFormat(gid('MF:txtoutstandingafterLcAmt').value)*1 > unFormat(gid('MF:txtFacilitylimitAmt').value)*1)
				{
					var _outstdaftlc1 = unFormat(trim(gid('MF:txtoutstandingafterLcAmt').value));
					var _faclmt = unFormat(trim(gid('MF:txtFacilitylimitAmt').value));
					var _excoverlmt = (_outstdaftlc1) - (_faclmt);
					//commented on 07-Jul-2018 startr
					//gid('MF:txtExcessOverAmt').value = _excoverlmt ;
					//setAmount('MF:txtExcessOverAmt',gid('MF:txtExcessOverAmt').value);
					// commented on 07-Jul-2018  end
				}
				/*if(!gid('MF:txtExcessOverAmt').value=="")
				{
					if( unFormat(gid('MF:txtExcessOverAmt').value)*1 < unFormat(gid('MF:txtLcLiaAmtlimitAmt').value)*1 )
					{
						 gid('MF:txtExcOverlimitDueCurrTrancurrAmt').value = gid('MF:txtExcessOverAmt').value;
						 setAmount('MF:txtExcOverlimitDueCurrTrancurrAmt',gid('MF:txtExcOverlimitDueCurrTrancurrAmt').value);
					}
					else if( unFormat(gid('MF:txtExcessOverAmt').value)*1 > unFormat(gid('MF:txtLcLiaAmtlimitAmt').value)*1 )
					{
						 gid('MF:txtExcOverlimitDueCurrTrancurrAmt').value = gid('MF:txtLcLiaAmtlimitAmt').value;
						 setAmount('MF:txtExcOverlimitDueCurrTrancurrAmt',gid('MF:txtExcOverlimitDueCurrTrancurrAmt').value);
					}
				} commented on 07-Jul-2018  */
				/*if(((pamt+osamt)-facamt) > 0)
				{
				gid("MF:txtExcessOverAmt").value=(pamt+osamt)-facamt;
				}
				else
				{
				gid("MF:txtExcessOverAmt").value=0;
				}
				setAmount('MF:txtExcessOverAmt',gid("MF:txtExcessOverAmt").value);
				
				var exceamt=unFormat(gid("MF:txtExcessOverAmt").value)*1;
				var lcliaamt=unFormat(gid("MF:txtLcLiaAmtlimitAmt").value)*1;
				var check;
				var w_eol_current_trans;
			
				check=lcliaamt-osamt+pamt;
			
				if(check>=facamt)
				{
				w_eol_current_trans=gid("MF:txtLcLiaAmtlimitAmt").value;
				}
				else if(facamt==0 || exceamt==0)
				{
				w_eol_current_trans=0;
				}
				else
				{
					if(exceamt > lcliaamt)
						{
							w_eol_current_trans=exceamt-lcliaamt;
							//gid("MF:txtExcOverlimitDueCurrTrancurrAmt").value=exceamt-lcliaamt;
						}
					else
						{
						w_eol_current_trans=exceamt;
						//gid("MF:txtExcOverlimitDueCurrTrancurrAmt").value=exceamt;
						}
				}		
				gid("MF:txtExcOverlimitDueCurrTrancurrAmt").value=w_eol_current_trans;
				setAmount('MF:txtExcOverlimitDueCurrTrancurrAmt',gid("MF:txtExcOverlimitDueCurrTrancurrAmt").value);*/
				setTabfocus("maintab","tcontent5");
				gid('MF:Next').focus();
			}
		}
		else
		{
			setTabfocus("maintab","tcontent5");
			gid('MF:txtConRateToLimitCurr').focus();
		}
	}
//-----------------------------------------------------------------------------------------------------------------------------	
	function cancelPage() 
	{
		if (confirm(CANCEL_ALERT)== true )
		{
			clearFields(); 
			gid('MF:seluseroption').value="";
			gid('MF:seluseroption').focus();
		} 
		else
		{	
			lastEntdFld.focus();
		}
	}
//-----------------------------------------------------------------------------------------------------------------------------	
	function exitPage() 
	{
		if (confirm (EXIT_ALERT) == true )
		{
			window.close();
		}
		else
		{
			lastEntdFld.focus();
		}
	}
//-----------------------------------------------------------------------------------------------------------------------------				
	function NextPage()
 	{ 
   		/*if(unFormat(gid('MF:txtExcOverlimitDueCurrTrancurrAmt').value)>0)
   		{	
   			if (confirm ("Exceeds Limit Do You Wish To Proceed ") == true )
			{
				setTabfocus("maintab","tcontent6");
   				gid('MF:txtmargincurr').focus();
			}
			else
			{
				gid('MF:Next').focus();
			}
		}
		else
		{	
   			setTabfocus("maintab","tcontent6");
   			gid('MF:txtmargincurr').focus();
   		} commented on 07-Jul-2018*/
   		//changes in eolc 0n 07-Jul-2018 start
   		if(objXMLApplet5.getValue("ErrorMsg") == "")	
   		{
   			setTabfocus("maintab","tcontent6");
   			gid('MF:txtmargincurr').focus();
   		}
   		else
   		{
   			gid('MF:Next').focus();
   			return;
   		}
   		//changes in eolc 0n 07-Jul-2018 end
 	}
//-----------------------------------------------------------------------------------------------------------------------------				
	function NextPage1()
 	{ 
		//Changes P.Subramani-Chn-18/06/2008 Beg
		var usancecharge1=unFormat(gid("MF:txtusnchgsamt1").value)*1;
		var commitcharge1=unFormat(gid("MF:txtcommchgsamt1").value)*1;
		//S.Suresh Babu Add 30-06-2009
		var usanceservamt1=unFormat(gid("MF:txtusanceservamt1").value)*1;
		var commservamt1=unFormat(gid("MF:txtcommservamt1").value)*1;
		var totalcharge1=parseFloat(totalamount)+parseFloat(usancecharge1)+parseFloat(commitcharge1)+parseFloat(usanceservamt1)+parseFloat(commservamt1);
		//var totalcharge=parseFloat(totalamount)+parseFloat(usancecharge)+parseFloat(commitcharge);
		gid('MF:txtchargeamt').value=totalcharge1;
		//S.Suresh Babu Changes 24-09-2009
		if(parseFloat(totalcharge1) == 0)
		{
			objTranStmntPost.clearControl();
			//setTabfocus("maintab","tcontent7");
			//gid('MF:Submit').focus();
			setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent1"); gid('MF:lstcredit').focus() ;
		}
		else
		{
			if(trim(gid("MF:seluseroption").value)=="M")
	    	{
	    		objTranStmntPost.InventoryNumber = invoiceNumber;
	    		objTranStmntPost.FetchFromTable=true;
	    		objTranStmntPost.ResultType="MAIN";
	    		objTranStmntPost.SourceKey=gid("MF:txtbrncode").value+"|"+gid("MF:txtconttype").value+"|"+gid("MF:txtcontyear").value+"|"+gid("MF:txtcontsl").value;
	    		objTranStmntPost.SourceTable="OLC";
	    		objTranStmntPost.isDbCr = "D";
	    		objTranStmntPost.SettlementType="T";
	    		objTranStmntPost.TranCurrCode=recoverycurr;//gid("MF:txtAmtTotDisCurr3").value;
	    		objTranStmntPost.TranAmount=totalcharge1;
				objTranStmntPost.TranBaseCurrEqu=totalcharge1;
				objTranStmntPost.BranchCode=gid("MF:txtbrncode").value;
				objTranStmntPost.valueDate=gid("MF:txtpresanDate").value;
				objTranStmntPost.ProgramID="EOLC";
				objTranStmntPost.SettlementClientNumber=gid("MF:txtcustnum1").value;
	    		
	    	}
	    	else
	    	{
				objTranStmntPost.InventoryNumber = 0;
	    	}
		 	objTranStmntPost.AddOrModify=gid("MF:seluseroption").value;
			objTranStmntPost.SourceTable="OLC";
			objTranStmntPost.isDbCr = "D";
			objTranStmntPost.TranCurrCode=recoverycurr;//gid("MF:txtAmtTotDisCurr3").value;
			objTranStmntPost.TranAmount=totalcharge1;
			objTranStmntPost.TranBaseCurrEqu=totalcharge1;
			objTranStmntPost.BranchCode=gid("MF:txtbrncode").value;
			objTranStmntPost.valueDate=gid("MF:txtpresanDate").value;
			objTranStmntPost.ProgramID="EOLC";
			setTabfocus("maintab","tcontent8");
			objTranStmntPost.Focus();
		}
		
		//Changes P.Subramani-Chn-18/06/2008 End
 	}
//-----------------------------------------------------------------------------------------------------------------------------				
	function ChangeEvents(fldobj)
	{
		   	  switch(fldobj.name)
		   	  {
		   	  	  case "MF:txtbrncode" : 
								  			{
								  	    		if (gid('MF:txtbrncode').value =="")
							  					{
							  						if(gid('MF:seluseroption').value !="A")
							  						{
								  						gid('MF:txtconttype').value="";
								  						gid('MF:txtcontyear').value="";
								  						gid('MF:txtcontsl').value="";
								  						clearNonKeyFields();
								  					}
							  					}
							  				}break;
							  				
		  	 	  case "MF:txtconttype" : 
								  			{
								  	    	  if (gid('MF:txtconttype').value =="")
							  				  {
							  				  		if(gid('MF:seluseroption').value !="A")
							  						{
							  							gid('MF:txtcontyear').value="";
							  							gid('MF:txtcontsl').value="";
							  							clearNonKeyFields();
							  						}
							  				   }		
							  				}break;
							  				
  				case "MF:txtcontyear" : 
								  			{
								  	    	  if (gid('MF:txtcontyear').value =="")
					  						  {
						  						  if(gid('MF:seluseroption').value !="A")
						  						  gid('MF:txtcontsl').value="";
												  clearNonKeyFields();
					  						  }
							  				}break;
			
				case "MF:txtcontsl" : 
							  			{
							  	    	  if (gid('MF:txtcontsl').value =="")
						  						{
						  						  if(gid('MF:seluseroption').value !="A")
						  						  clearNonKeyFields();
						  						}
						  				}break;
  				
  			 case "MF:txtBeneficiaryCode" : 
								  			{
								  	    	  if (gid('MF:txtBeneficiaryCode').value =="")
							  						{
							  						 gid('MF:txtBeneficiaryName').innerText="";
							  						 gid('MF:txtAddress1').innerText="";
							  						}
							  				}break;		
  				
  				
  			 case "MF:txtCountryCode" : 
							  			{
							  	    	  if (gid('MF:txtCountryCode').value =="")
						  						{
						  						 gid('MF:outlblCountryCode').innerText="";
						  						}
						  				}break;	
  				
  			case "MF:txtLcIssuedthruBank" : 
								  			{
								  	    	  if (gid('MF:txtLcIssuedthruBank').value =="")
							  						{
							  						 gid('MF:outlblLcIssThruBank').innerText="";
							  						}
							  				}break;	
  		
  			
  				
  			 case "MF:txtLcIssuedOncntry" : 
								  			{
								  	    	  if (gid('MF:txtLcIssuedOncntry').value =="")
							  						{
							  						 gid('MF:outlblLcIssoncntry').innerText="";
							  						}
							  				}break;				
  					
  			case "MF:txtTermsOfprice" : 
							  			{
							  	    	  if (gid('MF:txtTermsOfprice').value =="")
						  						{
						  						 gid('MF:outlbltermsOfprice').innerText="";
						  						}
						  				}break;
  					
  			case "MF:txtmargincurr" : 
							  			{
							  	    	  if (gid('MF:txtmargincurr').value =="")
						  						{
						  						 gid('MF:outlblmargincurr').innerText="";
						  						}
						  				}break;	
						  				
			case "MF:txtperiod" : 	
									{
									if(gid('MF:seluseroption').value=="A")//ADDED ON 11/10/2018
										{
										
											if(trim(gid('MF:txtperiod').value) == "" || trim(gid('MF:txtperiod').value) == "0")
											{
												gid('MF:txtpresentationdetails').value ="";
												gid('MF:txtpresentationdetails').readOnly = true;
											}
											else
											{
												gid('MF:txtpresentationdetails').value ="";
												gid('MF:txtpresentationdetails').readOnly = false;
											}
										}
								 }break;
								 
			
		//ADDED BY PRASHANTH ON 29 JANUARY 2018
 			case "MF:lstConfInst"			:	validateConfInst();break;
	  						 
		//ADDED BY PRASHANTH ON 29 JANUARY 2018
  	    	}
   	}	
   	
   	
   	function ClobChangeEvents(fldobj)
	{
	    switch(fldobj.name)
		   	  {
		   	  	  
			case "MF:txtDesGood1"	:
										var _good1 = gid('MF:txtDesGood1').value;
										
										var splitResults10 = _good1.split("\n").length;
										setMsg("Characters entered " + _good1.length + "Line Entered " +splitResults10);
										if(_good1.length == 6500 || splitResults10 == 100) 
										{
											gid('MF:txtDesGood2').readOnly = false;
											gid('MF:txtDesGood3').readOnly = true;
											gid('MF:txtDesGood3').value = ""; 
											setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent3");
											focusTextArea('MF:txtDesGood2') ;
										}
										else
										{
											gid('MF:txtDesGood2').readOnly = true;
											gid('MF:txtDesGood3').readOnly = true;
											gid('MF:txtDesGood2').value = "";
											gid('MF:txtDesGood3').value = "";
										}
										break;
										
			case "MF:txtDesGood2"	:	
										var _good2 = gid('MF:txtDesGood2').value;
										
										var splitResults11 = _good2.split("\n").length;
										setMsg("Characters entered " + _good2.length + "Line Entered " +splitResults11);
										if(_good2.length == 6500 || splitResults11 == 100) 
										{
											gid('MF:txtDesGood3').readOnly = false;
											setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent3");
											focusTextArea('MF:txtDesGood3') ;
										}
										else
										{
											gid('MF:txtDesGood3').readOnly = true;
											gid('MF:txtDesGood3').value = "";
										}
										break;															  					
  			
  			case "MF:txtDocRequired1"	:
  										var _doc1 = gid('MF:txtDocRequired1').value;										
  										var splitResults12 = _doc1.split("\n").length;
  										setMsg("Characters entered " + _doc1.length + "Line Entered " +splitResults12);
  										
  										if(_doc1.length == 6500 || splitResults12 == 100) 
										{
											gid('MF:txtDocRequired2').readOnly = false;
											gid('MF:txtDocRequired3').readOnly = true;
											gid('MF:txtDocRequired3').value ="";
											setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent4");
											focusTextArea('MF:txtDocRequired2') ;
											
										}
										else
										{
											gid('MF:txtDocRequired2').readOnly = true;
											gid('MF:txtDocRequired3').readOnly = true;
											gid('MF:txtDocRequired2').value ="";
											gid('MF:txtDocRequired3').value ="";
										}
										break;
										
  			case "MF:txtDocRequired2"	:
									  	var _doc2 = gid('MF:txtDocRequired2').value;
									  	var splitResults13 = _doc2.split("\n").length;
									  	setMsg("Characters entered " + _doc2.length + "Line Entered " +splitResults13);
									  	
  										if(_doc2.length == 6500 || splitResults13 == 100) 
										{
											gid('MF:txtDocRequired3').readOnly = false;
											setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent4");
											focusTextArea('MF:txtDocRequired3') ;
										}
										else
										{
											gid('MF:txtDocRequired3').readOnly = true;
											gid('MF:txtDocRequired3').value ="";
										}
  										break;
  										
  			case "MF:txtAddCond1" 		:
									  	var _add1 = gid('MF:txtAddCond1').value;
									  	var splitResults14 = _add1.split("\n").length;
									  	setMsg("Characters entered " + _add1.length + "Line Entered " +splitResults14);
									  	
  										if(_add1.length == 6500 || splitResults14 == 100) 
										{
											gid('MF:txtAddCond2').readOnly = false;
											gid('MF:txtAddCond3').readOnly = true;
											gid('MF:txtAddCond3').value ="";
											setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent5");
											focusTextArea('MF:txtAddCond2') ;
										}
										else
										{
											gid('MF:txtAddCond2').readOnly = true;
											gid('MF:txtAddCond3').readOnly = true;
											gid('MF:txtAddCond2').value = "";
											gid('MF:txtAddCond3').value = "";
										}
  											break;
  											
  			case "MF:txtAddCond2" 		:
  										var _add2 = gid('MF:txtAddCond2').value;
  										var splitResults15 = _add2.split("\n").length;
  										setMsg("Characters entered " + _add2.length + "Line Entered " +splitResults15);
  										
  										if(_add2.length == 6500 || splitResults15 == 100) 
										{
											gid('MF:txtAddCond3').readOnly = false;
											setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent5");
											focusTextArea('MF:txtAddCond3') ;
										}
										else
										{
											gid('MF:txtAddCond3').readOnly = true;
											gid('MF:txtAddCond3').value = "";
										}
  											break;	
  		  case "MF:txtperiod"		:
  		  							if(trim(gid('MF:txtperiod').value) == "" || trim(gid('MF:txtperiod').value) == "0")
									{
										gid('MF:txtpresentationdetails').value ="";
										gid('MF:txtpresentationdetails').readOnly = true;
									}
									else
									{
										gid('MF:txtpresentationdetails').value ="";
										gid('MF:txtpresentationdetails').readOnly = false;
									}													
								  					
  	    	}
   		} 
   	
//-----------------------------------------------------------------------------------------------------------------------------				
