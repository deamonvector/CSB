package panacea.IBILaction;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;

import panacea.common.DTObject;
import panacea.common.DateUtility;
import panacea.common.DTDObject;
import panacea.common.FormatUtils;
import panacea.common.PanaceaException;
import panacea.Validator.BranchValidator;
import panacea.Validator.IRSValidator;
import panacea.Validator.DDPOValidator;
import panacea.Validator.CommonValidator;
import panacea.Validator.ClientValidator;
import panacea.Validator.LimitValidator;
import panacea.Validator.OLCValidator;
import panacea.Validator.ProductValidator;
import panacea.Validator.SwiftValidator; //COMMENTTED BY PRASHANTH ON 01 AUGUST 2019
//import panacea.Validator.TBMLValidator;
//COMMENTTED BY PRASHANTH ON 01 AUGUST 2019

import panacea.Validator.TFMValidator;
import panacea.Validator.AccountValidator;
import panacea.Validator.CommonValidator;
import panacea.Validator.GlValidator;
import panacea.Validator.WebManager;
import panacea.Validator.cbsglobal;

public class eibillval extends WebManager {

	BranchValidator brnval = new BranchValidator();
	IRSValidator irsval = new IRSValidator();
	DDPOValidator ddpoval = new DDPOValidator();
	ClientValidator clieval = new ClientValidator();
	CommonValidator comnval = new CommonValidator();
	TFMValidator tfmval = new TFMValidator();
	AccountValidator accval = new AccountValidator();
	LimitValidator limval = new LimitValidator();
	ProductValidator proval = new ProductValidator();
	OLCValidator olcval = new OLCValidator();
	GlValidator glval = new GlValidator();
	SwiftValidator swval = new SwiftValidator();// Changes in eibill on
	// 11-Jun-2018
	DTObject dtobj = new DTObject();

	// // COMMENTTED BY PRASHANTH ON 01 AUGUST 2019
	// TBMLValidator tbmlval = new TBMLValidator();
	// COMMENTTED BY PRASHANTH ON 01 AUGUST 2019

	// *********************************************************************************************************
	/*
	 * Input - Key =IRCR_BRN_CODE key=USER_BRANCH key=USER_ID key=USER_ROLE
	 * Output : Error Message - Key = ErrorMsg
	 */

	public DTObject ibillBrnCodekeypress(DTObject InputoBj) {
		try {

			int _ircrBrnCode = 0;
			String _userBranch = "";
			String _userID = "";
			String _userRole = "";
			String _BranchName = "";

			if (InputoBj.getValue("IRCR_BRN_CODE").trim().equalsIgnoreCase("")) {
				_ircrBrnCode = 0;
			} else {
				_ircrBrnCode = Integer.parseInt(InputoBj.getValue("IRCR_BRN_CODE").trim().toString());
				_userBranch = InputoBj.getValue("USER_BRANCH").trim().toString();
				_userID = InputoBj.getValue("USER_ID").trim().toString();
				_userRole = InputoBj.getValue("USER_ROLE").trim().toString();

			}
			Init_ResultObj(InputoBj);
			if (!String.valueOf(_ircrBrnCode).trim().equalsIgnoreCase("")) {
				if (_ircrBrnCode == 0)
					if ((InputoBj.containsKey("IRCR_BRN_CODE") == true) && (InputoBj.getValue("IRCR_BRN_CODE").trim().equalsIgnoreCase("")))
						Resultobj.setValue(ErrorKey, BLANK_CHECK);
					else
						Resultobj.setValue(ErrorKey, ZERO_CHECK);
			}
			if (Check_Result_Status()) {
				dtobj.clearMap();
				dtobj.setValue("MBRN_CODE", String.valueOf(_ircrBrnCode));
				Resultobj = brnval.chkBrnValid(dtobj);

			}
			if (Check_Result_Status()) {
				_BranchName = Resultobj.getValue("MBRN_NAME");

				dtobj.clearMap();
				dtobj.setValue("USER_ID", _userID);
				dtobj.setValue("USER_BRANCH", _userBranch);
				dtobj.setValue("UROLE_CODE", _userRole);
				dtobj.setValue("BRANCH_CODE", String.valueOf(_ircrBrnCode));
				Resultobj = brnval.brnValid(dtobj);
			}
			if (Check_Result_Status()) {
				Resultobj.setValue("MBRN_NAME", _BranchName);

			}

		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in ibillBrnCodekeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	// *********************************************************************************************************
	/*
	 * Input - Key =IRCR_IR_TYPE Output : Error Message - Key = ErrorMsg
	 * key=IRT_REMIT_MODE key=IRT_TRAN_NUM_YEAR
	 */

	public DTObject ibillIrTypekeypress(DTObject InputoBj) {
		try {

			String _ircrIrType = "";
			String _ircrTNOMEN_LC_BILL_BG = "";
			String _ircrTNOMEN_IW_OW = "";
			String _ircrTNOMEN_AUTO_NUM = "";
			String _ircrTNOMEN_INLAND_OVERSEAS = "";
			String _ircrTNOMEN_NUM_CHOICE = "";
			String _ibillTNOMEN_BILL_TYPE = "";
			String tnomen_tenor_type = "";
			String _productType = "";
			String _productName = "";
			String product_glacc_code = "";
			{
				_ircrIrType = InputoBj.getValue("IRCR_IR_TYPE").trim().toString();
			}
			Init_ResultObj(InputoBj);
			if (String.valueOf(_ircrIrType).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (Check_Result_Status()) {

				tfmval = new TFMValidator();
				dtobj.clearMap();
				dtobj.setValue("TNOMEN_NOMEN_CODE", _ircrIrType);
				dtobj.setValue(FetchReq, "true");
				dtobj.setValue("FetchColumns", "TNOMEN_LC_BILL_BG,TNOMEN_IW_OW,TNOMEN_AUTO_NUM,TNOMEN_INLAND_OVERSEAS,TNOMEN_NUM_CHOICE,TNOMEN_BILL_TYPE,TNOMEN_TENOR_TYPE");
				Resultobj = tfmval.valtnomen(dtobj);
				if (Check_Result_Status()) {
					_ircrTNOMEN_LC_BILL_BG = Resultobj.getValue("TNOMEN_LC_BILL_BG");
					_ircrTNOMEN_INLAND_OVERSEAS = Resultobj.getValue("TNOMEN_INLAND_OVERSEAS");
					_ircrTNOMEN_IW_OW = Resultobj.getValue("TNOMEN_IW_OW");
					_ircrTNOMEN_AUTO_NUM = Resultobj.getValue("TNOMEN_AUTO_NUM");
					_ircrTNOMEN_NUM_CHOICE = Resultobj.getValue("TNOMEN_NUM_CHOICE");
					_ibillTNOMEN_BILL_TYPE = Resultobj.getValue("TNOMEN_BILL_TYPE");
					tnomen_tenor_type = Resultobj.getValue("TNOMEN_TENOR_TYPE");
					if (!_ircrTNOMEN_LC_BILL_BG.equalsIgnoreCase("B")) {
						Resultobj.setValue(ErrorKey, "Bill Type Should be Reserved for Bills");
					}
					if (!_ircrTNOMEN_INLAND_OVERSEAS.equalsIgnoreCase("O")) {
						Resultobj.setValue(ErrorKey, "Bill Type Should be Reserved for Overseas");
					}
					if (!_ircrTNOMEN_IW_OW.equalsIgnoreCase("I")) {
						// Changes P.Subramani-Chn-08/04/2008
						Resultobj.setValue(ErrorKey, "Bill Type Should be Reserved for Inward");
					}
				}
				if (Check_Result_Status()) {
					_QueryStr = "SELECT TRAC_COLL_PROD FROM TRACPARAM WHERE TRAC_NOMEN_CODE=?";
					Set_preparedStatement(_QueryStr);
					_pstmt.setString(1, _ircrIrType);
					Resultobj = Get_Value_From_Main("TRACPARAM");
					// S.Suresh Babu Changes 20/09/2008
					if (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowNotPresent)) {
						Resultobj.setValue(ErrorKey, "Accounting Parameters Not set");
					}

					// Changes P.Subramani-Chn-26/05/2008 Beg
					if (Check_Result_Status()) {
						_productType = Resultobj.getValue("TRAC_COLL_PROD");
						if (_productType.equalsIgnoreCase("0")) {
							Resultobj.setValue(ErrorKey, "Accounting Parameters Not set");
						} else {
							proval = new ProductValidator();
							dtobj.clearMap();
							dtobj.setValue("PRODUCT_CODE", _productType);
							dtobj.setValue(FetchReq, "true");
							Resultobj = proval.prodValid(dtobj);
							if (Check_Result_Status()) {
								_productName = Resultobj.getValue("PRODUCT_NAME");
								product_glacc_code = Resultobj.getValue("PRODUCT_GLACC_CODE");
							}
							if (Check_Result_Status()) {
								glval = new GlValidator();
								dtobj.clearMap();
								dtobj.setValue("GL_ACC_CODE", product_glacc_code);
								dtobj.setValue("CUS_ACC_FLG", "True");
								Resultobj = glval.glValidator(dtobj);
							}
						}
						// Changes P.Subramani-Chn-26/05/2008 End
					}
				}
			}
			if (Check_Result_Status()) {
				Resultobj.setValue("TNOMEN_AUTO_NUM", _ircrTNOMEN_AUTO_NUM);
				Resultobj.setValue("TNOMEN_NUM_CHOICE", _ircrTNOMEN_NUM_CHOICE);
				Resultobj.setValue("TNOMEN_BILL_TYPE", _ibillTNOMEN_BILL_TYPE);
				Resultobj.setValue("TNOMEN_TENOR_TYPE", tnomen_tenor_type);
				Resultobj.setValue("PRODUCT_CODE", _productType);
				Resultobj.setValue("PRODUCT_NAME", _productName);
				Resultobj.setValue("PRODUCT_GLACC_CODE", product_glacc_code);
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in ibillIrTypekeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	// *********************************************************************************************************
	/*
	 * Input - Key =IRCR_YEAR Key=BRANCH_CODE Key=BILL_TYPE
	 * key=TNOMEN_NUM_CHOICE key=CBD key=OPTION key=TNOMEN_AUTO_NUM
	 * 
	 * Output : Error Message - Key = ErrorMsg
	 */

	public DTObject ibillYearkeypress(DTObject InputoBj) {
		try {
			int _ircrYear = 0;
			String _ibill_TNOMEN_NUM_CHOICE = "";
			String _currBusDate = "";
			String _option = "";
			String _tenum_Auto_Num = "";
			int _branchCode = 0;
			String _billType = "";
			long _orLastslused = 0;
			long lastserial = 0;

			if (InputoBj.getValue("IRCR_YEAR").trim().equalsIgnoreCase("")) {
				_ircrYear = 0;
			} else {
				_ircrYear = Integer.parseInt(InputoBj.getValue("IRCR_YEAR").trim().toString());
			}
			Init_ResultObj(InputoBj);
			if (String.valueOf(_ircrYear).trim().equalsIgnoreCase("0")) {
				if (_ircrYear == 0)
					if ((InputoBj.containsKey("IRCR_YEAR") == true) && (InputoBj.getValue("IRCR_YEAR").trim().equalsIgnoreCase("")))
						Resultobj.setValue(ErrorKey, BLANK_CHECK);
					else
						Resultobj.setValue(ErrorKey, ZERO_CHECK);
			}
			if (Check_Result_Status()) {
				if (!(_ircrYear >= 1900)) {
					Resultobj.setValue(ErrorKey, "Year should be greater than or equal 1900");
				}
				if (Check_Result_Status()) {

					_ibill_TNOMEN_NUM_CHOICE = InputoBj.getValue("TNOMEN_NUM_CHOICE").trim().toString();
					_currBusDate = InputoBj.getValue("CBD").trim().toString();
					_option = InputoBj.getValue("OPTION").trim().toString();
					_tenum_Auto_Num = InputoBj.getValue("TNOMEN_AUTO_NUM").trim().toString();
					_branchCode = Integer.parseInt(InputoBj.getValue("BRANCH_CODE").trim().toString());
					_billType = InputoBj.getValue("BILL_TYPE").trim().toString();
					if (String.valueOf(_ibill_TNOMEN_NUM_CHOICE).equalsIgnoreCase("C")) {
						if (_ircrYear > Integer.parseInt(_currBusDate.substring(6, 10))) {
							Resultobj.setValue(ErrorKey, "Reference Year Should be less than or equal to Current Year");
						}
					} else {
						if (_ircrYear > Integer.parseInt(getFinYear(_currBusDate))) {
							Resultobj.setValue(ErrorKey, "Reference Year Should be less than or equal to  Financial Year");
						}
					}

				}
				if (Check_Result_Status()) {
					if ((_option.equalsIgnoreCase("A")) && (_tenum_Auto_Num.equalsIgnoreCase("1"))) {
						_QueryStr = "SELECT TBILLSL_LAST_NUM_USED, TBILLSL_ENTD_BY, TBILLSL_ENTD_ON FROM TBILLSERIAL WHERE TBILLSL_BRN_CODE=? AND TBILLSL_NOMEN_CODE=? AND TBILLSL_YEAR=?";
						Set_preparedStatement(_QueryStr);
						_pstmt.setInt(1, _branchCode);
						_pstmt.setString(2, _billType);
						_pstmt.setInt(3, _ircrYear);
						Resultobj = Get_Value_From_Main("TBILLSERIAL");
						if (Check_Result_Status()) {
							if (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowNotPresent)) {
								Resultobj.setValue(ErrorKey, "Transaction Number Control Parameter Not Specified");
							} else {
								_orLastslused = Long.parseLong(Resultobj.getValue("TBILLSL_LAST_NUM_USED"));
								lastserial = _orLastslused + 1;
							}
							if (Check_Result_Status()) {
								tfmval = new TFMValidator();
								dtobj.clearMap();
								dtobj.setValue("MBRN_CODE", String.valueOf(_branchCode));
								dtobj.setValue("TRFUNC_LINK_CODE", _billType);
								dtobj.setValue("TRFUNC_CLASSIFICATION", "N");
								dtobj.setValue("YEAR", String.valueOf(_ircrYear));
								dtobj.setValue("SERIAL", String.valueOf(lastserial));
								Resultobj = tfmval.valtrcorefnum(dtobj);

								// Changes P.Subramani-Chn-26/05/2008 Beg
								if (!(Check_Result_Status())) {
									Resultobj.setValue(ErrorKey, "Functional Code not Set");
								}
								// Changes P.Subramani-Chn-26/05/2008 End
							}
						}
					}
				}

			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in ibillYearkeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	// *********************************************************************************************************
	/*
	 * Input - Key =IBILL_BRN_CODE Key =IBILL_BILL_TYPE key=IBILL_BILL_YEAR
	 * key=IBILL_BILL_SL key=OPTION
	 * 
	 * 
	 * Output : Error Message - Key = ErrorMsg
	 * 
	 * 
	 */

	public DTObject ibillTranSerkeypress(DTObject InputoBj) {
		try {
			int _ibillSer = 0;
			int _ibill_year = 0;
			String _ibill_type = "";
			int _brn_Code = 0;
			String _Option = "";

			if (InputoBj.getValue("IBILL_BILL_SL").trim().equalsIgnoreCase("")) {
				_ibillSer = 0;
			} else {
				_ibillSer = Integer.parseInt(InputoBj.getValue("IBILL_BILL_SL").trim().toString());
			}
			Init_ResultObj(InputoBj);
			if (!String.valueOf(_ibillSer).trim().equalsIgnoreCase("")) {
				if (_ibillSer == 0)
					if ((InputoBj.containsKey("IBILL_BILL_SL") == true) && (InputoBj.getValue("IBILL_BILL_SL").trim().equalsIgnoreCase("")))
						Resultobj.setValue(ErrorKey, BLANK_CHECK);
					else
						Resultobj.setValue(ErrorKey, ZERO_CHECK);
			}
			if (Check_Result_Status()) {
				_ibill_year = Integer.parseInt(InputoBj.getValue("IBILL_BILL_YEAR").trim().toString());
				_ibill_type = InputoBj.getValue("IBILL_BILL_TYPE").trim().toString();
				_brn_Code = Integer.parseInt(InputoBj.getValue("IBILL_BRN_CODE").trim().toString());
				_Option = InputoBj.getValue("OPTION").trim().toString();
				if ((!String.valueOf(_ibillSer).trim().equalsIgnoreCase("")) && (!String.valueOf(_ibillSer).trim().equalsIgnoreCase(""))) {
					if (_ibillSer == 0)
						if ((InputoBj.containsKey("IBILL_BILL_SL") == true) && (InputoBj.getValue("IBILL_BRN_CODE").trim().equalsIgnoreCase("")))
							Resultobj.setValue(ErrorKey, BLANK_CHECK);
						else
							Resultobj.setValue(ErrorKey, ZERO_CHECK);
				}
				if (String.valueOf(_ibill_type).trim().equalsIgnoreCase("")) {
					Resultobj.setValue(ErrorKey, BLANK_CHECK);
				}
				if (Check_Result_Status()) {

					_QueryStr = "SELECT IBILL_ENTD_BY, IBILL_ENTD_ON,IBILL_AUTH_BY,IBILL_REJ_BY FROM IBILL WHERE IBILL_BRN_CODE = ? AND IBILL_BILL_TYPE=? AND IBILL_BILL_YEAR=? AND IBILL_BILL_SL=?";
					Set_preparedStatement(_QueryStr);
					_pstmt.setInt(1, _brn_Code);
					_pstmt.setString(2, _ibill_type);
					_pstmt.setInt(3, _ibill_year);
					_pstmt.setInt(4, _ibillSer);
					Resultobj = Get_Value_From_Main("IBILL");
					if (Check_Result_Status()) {
						String _auth_By = Resultobj.getValue("IBILL_AUTH_BY");
						String _rej_By = Resultobj.getValue("IBILL_REJ_BY");
						if ((Resultobj.getValue(ResultKey).equalsIgnoreCase(RowPresent)) && (_Option.equalsIgnoreCase("A"))) {
							Resultobj.setValue(ErrorKey, "Record Already Exists");
						}
						if ((Resultobj.getValue(ResultKey).equalsIgnoreCase(RowNotPresent)) && (_Option.equalsIgnoreCase("M"))) {
							Resultobj.setValue(ErrorKey, "Record Does Not Exist to Modify");
						} else if ((Resultobj.getValue(ResultKey).equalsIgnoreCase(RowPresent)) && (_Option.equalsIgnoreCase("M"))) {
							if (_auth_By != null) {
								Resultobj.setValue(ErrorKey, "Record Already Authorised Cannot Modify");
							} else if (_rej_By != null) {
								Resultobj.setValue(ErrorKey, "Record Already Rejected Cannot Modify");
							}
						}
					}
					if (_Option.equalsIgnoreCase("A")) {
						if (Check_Result_Status()) {
							tfmval = new TFMValidator();
							dtobj.clearMap();
							dtobj.setValue("MBRN_CODE", String.valueOf(_brn_Code));
							dtobj.setValue("TRFUNC_LINK_CODE", _ibill_type);
							dtobj.setValue("TRFUNC_CLASSIFICATION", "N");
							dtobj.setValue("YEAR", String.valueOf(_ibill_year));
							dtobj.setValue("SERIAL", String.valueOf(_ibillSer));
							Resultobj = tfmval.valtrcorefnum(dtobj);
						}
					}
				}
			}
		}

		catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in ibillTranSerkeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	// new method

	// *********************************************************************************************************
	/*
	 * Input - Key =IBILL_BILL_DATE \ kEY=CBD Output : Error Message - Key =
	 * ErrorMsg
	 */

	public DTObject ibillDatekeypress(DTObject InputoBj) {
		try {
			String _ibilldateDate = "";
			String _currBusDate = "";
			_currBusDate = InputoBj.getValue("CBD").trim().toString();
			{
				_ibilldateDate = InputoBj.getValue("IBILL_BILL_DATE").trim().toString();
			}
			Init_ResultObj(InputoBj);
			if (String.valueOf(_ibilldateDate).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (!_ibilldateDate.equalsIgnoreCase(""))
				if (Check_Result_Status()) {
					CheckDate(_ibilldateDate);
					if (Check_Result_Status()) {
						if (DateUtility.DateGreaterThan(_ibilldateDate, _currBusDate)) {
							Resultobj.setValue(ErrorKey, "Bill date should <= CBD");
						}
					}

				}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in ibillDatekeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	// *********************************************************************************************************
	/*
	 * Input - Key =IBILL_TRANS_BRN Key= USER_ID Key= USER_BRANCH Key= USER_ROLE
	 * Output : Error Message Key = ErrorMsg Key=MBRN_NAME
	 */

	public DTObject ibillTransactionbranch(DTObject InputoBj) {
		try {
			int ibillTransactionbranch = 0;
			String _BranchName = "";
			String _userID = "";
			int _userBranch = 0;
			String _userRole = "";
			{
				ibillTransactionbranch = Integer.parseInt(InputoBj.getValue("IBILL_TRANS_BRN").trim().toString());
				_userID = InputoBj.getValue("USER_ID").trim().toString();
				_userBranch = Integer.parseInt(InputoBj.getValue("USER_BRANCH").trim().toString());
				_userRole = InputoBj.getValue("USER_ROLE").trim().toString();
			}
			Init_ResultObj(InputoBj);

			if (!String.valueOf(ibillTransactionbranch).trim().equalsIgnoreCase("")) {
				if (ibillTransactionbranch == 0)
					if ((InputoBj.containsKey("IBILL_TRANS_BRN") == true) && (InputoBj.getValue("IBILL_TRANS_BRN").trim().equalsIgnoreCase("")))
						Resultobj.setValue(ErrorKey, BLANK_CHECK);
					else
						Resultobj.setValue(ErrorKey, ZERO_CHECK);
			}
			if (Check_Result_Status()) {
				dtobj.clearMap();
				dtobj.setValue("MBRN_CODE", String.valueOf(ibillTransactionbranch));
				Resultobj = brnval.chkBrnValid(dtobj);
			}
			if (Check_Result_Status()) {
				_BranchName = Resultobj.getValue("MBRN_NAME");

				dtobj.clearMap();
				dtobj.setValue("USER_ID", _userID);
				dtobj.setValue("USER_BRANCH", String.valueOf(_userBranch));
				dtobj.setValue("UROLE_CODE", _userRole);
				dtobj.setValue("BRANCH_CODE", String.valueOf(ibillTransactionbranch));
				Resultobj = brnval.brnValid(dtobj);
			}
			if (Check_Result_Status()) {
				Resultobj.setValue("MBRN_NAME", _BranchName);

			}

		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in ibillTransactionbranch");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	// *********************************************************************************************************
	/*
	 * Input - Key =IBILL_CUST_NO Output : Error Message - Key = ErrorMsg
	 * Key=CLIENTS_NAME
	 */

	public DTObject ibillClientCodeKeypress(DTObject InputoBj) {
		try {
			int _ibillClientCode = 0;
			String _addr1 = "";
			String _addr2 = "";
			String _addr3 = "";
			String _addr4 = "";
			String _addr5 = "";

			{
				_ibillClientCode = Integer.parseInt(InputoBj.getValue("IBILL_CUST_NO").trim().toString());
			}
			Init_ResultObj(InputoBj);
			if (!String.valueOf(_ibillClientCode).trim().equalsIgnoreCase("")) {
				if (_ibillClientCode == 0)
					if ((InputoBj.containsKey("IBILL_CUST_NO") == true) && (InputoBj.getValue("IBILL_CUST_NO").trim().equalsIgnoreCase("")))
						Resultobj.setValue(ErrorKey, BLANK_CHECK);
					else
						Resultobj.setValue(ErrorKey, ZERO_CHECK);
			}
			if (Check_Result_Status()) {
				clieval = new ClientValidator();
				dtobj.clearMap();
				dtobj.setValue("CLIENTS_CODE", String.valueOf(_ibillClientCode));
				dtobj.setValue("FetchReq", "true");
				Resultobj = clieval.clientValid(dtobj);
				if (Check_Result_Status()) {
					_addr1 = Resultobj.getValue("CLIENTS_ADDR1");
					_addr2 = Resultobj.getValue("CLIENTS_ADDR2");
					_addr3 = Resultobj.getValue("CLIENTS_ADDR3");
					_addr4 = Resultobj.getValue("CLIENTS_ADDR4");
					_addr5 = Resultobj.getValue("CLIENTS_ADDR5");
					Resultobj.setValue("CLIENTS_ADDR1", _addr1);
					Resultobj.setValue("CLIENTS_ADDR2", _addr2);
					Resultobj.setValue("CLIENTS_ADDR3", _addr3);
					Resultobj.setValue("CLIENTS_ADDR4", _addr4);
					Resultobj.setValue("CLIENTS_ADDR5", _addr5);
					System.out.println(_addr1);
				}
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in ibillClientCodeKeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	// *********************************************************************************************************
	/*
	 * Input - Key =IBILL_DRAWER_CODE Output : Error Message - Key = ErrorMsg
	 * key=ADDR1 Key=ADDR2 key=ADDR3 Key=ADDR4 Key=CPARTY_NAME key=COUNTRY_CODE
	 * Key=CPARTY_BRN_CODE Key=CPARTY_BANK_CODE
	 * 
	 */

	public DTObject iDraweeCodekeypress(DTObject InputoBj) {
		try {

			String _idraweecode = "";
			String _Addr1 = "";
			String _Addr2 = "";
			String _Addr3 = "";
			String _Addr4 = "";
			String _cpartyCountryCode = "";
			String _cpartybankCode = "";
			String _cpartyBranchCode = "";
			String _cpartyName = "";
			{
				_idraweecode = InputoBj.getValue("IBILL_DRAWER_CODE").trim().toString();
			}
			Init_ResultObj(InputoBj);
			if (String.valueOf(_idraweecode).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (Check_Result_Status()) {
				tfmval = new TFMValidator();
				dtobj.clearMap();
				dtobj.setValue("CPARTY_ALPHA_CODE", _idraweecode);
				dtobj.setValue(FetchReq, "true");
				dtobj.setValue("FetchColumns", "CPARTY_ADDR1, CPARTY_ADDR2,CPARTY_ADDR3, CPARTY_ADDR4, CPARTY_CNTRY_CODE, CPARTY_BANK_CODE, CPARTY_BRN_CODE");
				Resultobj = tfmval.valcparty(dtobj);
				if (Check_Result_Status()) {
					_cpartyName = Resultobj.getValue("CPARTY_NAME");
					_Addr1 = Resultobj.getValue("CPARTY_ADDR1");
					_Addr2 = Resultobj.getValue("CPARTY_ADDR2");
					_Addr3 = Resultobj.getValue("CPARTY_ADDR3");
					_Addr4 = Resultobj.getValue("CPARTY_ADDR4");
					_cpartyCountryCode = Resultobj.getValue("CPARTY_CNTRY_CODE");
					_cpartybankCode = Resultobj.getValue("CPARTY_BANK_CODE");
					_cpartyBranchCode = Resultobj.getValue("CPARTY_BRN_CODE");
					comnval = new CommonValidator();
					dtobj.clearMap();
					dtobj.setValue("CNTRY_CODE", _cpartyCountryCode);
					Resultobj = comnval.valcntrycd(dtobj);
					if (Check_Result_Status()) {
						Resultobj.setValue("ADDR1", _Addr1);
						Resultobj.setValue("ADDR2", _Addr2);
						Resultobj.setValue("ADDR3", _Addr3);
						Resultobj.setValue("ADDR4", _Addr4);
						Resultobj.setValue("CPARTY_NAME", _cpartyName);
						Resultobj.setValue("COUNTRY_CODE", _cpartyCountryCode);
						Resultobj.setValue("CPARTY_BANK_CODE", _cpartybankCode);
						Resultobj.setValue("CPARTY_BRN_CODE", _cpartyBranchCode);
					}
				}
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in iDraweeCodekeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	// *********************************************************************************************************
	/*
	 * Input - Key =IBILL_DRAWER_CNTRY
	 * 
	 * Output : Error Message - Key = ErrorMsg
	 */

	public DTObject ibillCounteryCodekeypress(DTObject InputoBj) {
		try {
			String _ibillCountryCode = "";
			{
				_ibillCountryCode = InputoBj.getValue("IBILL_DRAWER_CNTRY").trim().toString();
			}
			Init_ResultObj(InputoBj);
			if (String.valueOf(_ibillCountryCode).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (Check_Result_Status()) {
				comnval = new CommonValidator();
				dtobj.clearMap();
				dtobj.setValue("CNTRY_CODE", _ibillCountryCode);
				Resultobj = comnval.valcntrycd(dtobj);
				if (!Check_Result_Status()) {
					Resultobj.setValue(ErrorKey, INVALIDCODE);
				}

			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in ibillCounteryCodekeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	// *********************************************************************************************************
	/*
	 * Input - Key =IBILL_BILL_CURR
	 * 
	 * 
	 * Output : Error Message - Key = ErrorMsg
	 *  *
	 */

	public DTObject ibillCurrencyCodekeypress(DTObject InputoBj) {
		try {
			String _ibillCurr = "";
			String _declength = "";
			String _currName = "";
			{
				_ibillCurr = InputoBj.getValue("IBILL_BILL_CURR");
			}
			Init_ResultObj(InputoBj);
			if (String.valueOf(_ibillCurr).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (Check_Result_Status()) {
				comnval = new CommonValidator();
				dtobj.clearMap();
				dtobj.setValue("CURR_CODE", _ibillCurr);
				dtobj.setValue("FetchReq", "true");
				Resultobj = comnval.valcurrcd(dtobj);
				if (Check_Result_Status()) {
					_currName = Resultobj.getValue("CURR_NAME");
					_declength = String.valueOf(cbsglobal.getcurrdeclength(_ibillCurr));
					if (Check_Result_Status()) {
						Resultobj.setValue("CURR_NAME", _currName);
						Resultobj.setValue("DEC_LEN", _declength);
					}
				}

			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in ibillCurrencyCodekeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	// *********************************************************************************************************
	/*
	 * Input - Key =IBILL_SHIPMENT_DATE Key=IBILL_BILL_DATE key=CBD
	 * 
	 * 
	 * Output : Error Message - Key = ErrorMsg
	 * 
	 * 
	 */

	public DTObject ibillDateOfShipmentkeypress(DTObject InputoBj) {
		try {
			String _ibilldShipmentDate = "";
			String _currBusDate = "";
			String _ibillEntryDate = "";
			_currBusDate = InputoBj.getValue("CBD").trim().toString();
			{
				_ibilldShipmentDate = InputoBj.getValue("IBILL_SHIPMENT_DATE").trim().toString();
				_ibillEntryDate = InputoBj.getValue("IBILL_BILL_DATE").trim().toString();
			}
			Init_ResultObj(InputoBj);
			if (String.valueOf(_ibilldShipmentDate).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (!_ibilldShipmentDate.equalsIgnoreCase(""))
				if (Check_Result_Status()) {
					CheckDate(_ibilldShipmentDate);
					if (Check_Result_Status()) {
						if (DateUtility.DateGreaterThan(_ibilldShipmentDate, _currBusDate)) {
							Resultobj.setValue(ErrorKey, "Date of Shipment cannot be > CBD ");
						}
						if (DateUtility.DateGreaterThan(_ibilldShipmentDate, _ibillEntryDate)) {
							Resultobj.setValue(ErrorKey, "Date of Shipment cannot be > Bill Entry Date ");
						}

					}

				}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in ibillDateOfShipmentkeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	// *********************************************************************************************************
	/*
	 * Input - Key =IBILL_DRAWER_BANK key=USER_ID key=USER_ROLE key=USER_BRANCH
	 * 
	 * Output : Error Message - Key = ErrorMsg key=
	 */

	public DTObject ibillDrawerbankkeypress(DTObject InputoBj) {
		try {

			String _drawerBank = "";

			{
				_drawerBank = InputoBj.getValue("IBILL_DRAWER_BANK").trim().toString();
			}
			Init_ResultObj(InputoBj);
			if (String.valueOf(_drawerBank).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (Check_Result_Status()) {
				dtobj.clearMap();
				comnval = new CommonValidator();
				dtobj.setValue("BANKCD_CODE", String.valueOf(_drawerBank));
				Resultobj = comnval.valbankcd(dtobj);
			}
			if (!Check_Result_Status()) {
				Resultobj.setValue(ErrorKey, INVALIDCODE);
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in ibillDrawerbankkeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	// *********************************************************************************************************
	/*
	 * Input - Key=IBILL_DRAWER_BANK Key =IBILL_DRAWER_BRN Output : Error
	 * Message - Key = ErrorMsg
	 */

	public DTObject ibillDrawerBranchkeypress(DTObject InputoBj) {
		try {
			String _ibillDrawerBranch = "";
			String _ibillDrawerBank = "";
			{
				_ibillDrawerBranch = InputoBj.getValue("IBILL_DRAWER_BRN").trim().toString();
				_ibillDrawerBank = InputoBj.getValue("IBILL_DRAWER_BANK").trim().toString();
			}
			Init_ResultObj(InputoBj);
			if (String.valueOf(_ibillDrawerBranch).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (Check_Result_Status()) {
				comnval = new CommonValidator();
				dtobj.clearMap();
				dtobj.setValue("MBKBRN_BANK_CODE", _ibillDrawerBank);
				dtobj.setValue("MBKBRN_BRN_CODE", _ibillDrawerBranch);
				Resultobj = comnval.valmbkbrn(dtobj);
				if (Check_Result_Status()) {
					Resultobj.setValue(ErrorKey, "");
				}
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in ibillDrawerBranchkeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	// *********************************************************************************************************
	/*
	 * Input - Key =IBILL_INTER_BANK
	 * 
	 * Output : Error Message Key = ErrorMsg key=MBRN_NAME
	 */

	public DTObject ibillIntermidiatoryBankkeypress(DTObject InputoBj) {
		try {
			String _intermidiatorybank = "";
			{
				_intermidiatorybank = InputoBj.getValue("IBILL_INTER_BANK").trim().toString();
			}
			Init_ResultObj(InputoBj);
			if (String.valueOf(_intermidiatorybank).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (Check_Result_Status()) {
				dtobj.clearMap();
				comnval = new CommonValidator();
				dtobj.setValue("BANKCD_CODE", String.valueOf(_intermidiatorybank));
				Resultobj = comnval.valbankcd(dtobj);
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in ibillIntermidiatoryBankkeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	// *********************************************************************************************************
	/*
	 * Input - Key =IBILL_INTER_BRN key=IBILL_INTER_BANK
	 * 
	 * Output : Error Message - Key = ErrorMsg key= key= key=
	 */

	public DTObject ibillIntermidiatoryBranchkeypress(DTObject InputoBj) {
		try {
			String _ibillIntermidiatoryBranch = "";
			String _ibillIntermidiatoryBank = "";
			{
				_ibillIntermidiatoryBranch = InputoBj.getValue("IBILL_INTER_BRN");
				_ibillIntermidiatoryBank = InputoBj.getValue("IBILL_INTER_BANK");
			}
			Init_ResultObj(InputoBj);
			if (String.valueOf(_ibillIntermidiatoryBranch).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (Check_Result_Status()) {
				comnval = new CommonValidator();
				dtobj.clearMap();
				dtobj.setValue("MBKBRN_BANK_CODE", _ibillIntermidiatoryBank);
				dtobj.setValue("MBKBRN_BRN_CODE", _ibillIntermidiatoryBranch);
				Resultobj = comnval.valmbkbrn(dtobj);
				if (Check_Result_Status()) {
					Resultobj.setValue(ErrorKey, "");
				}
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in ibillIntermidiatoryBranchkeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	// *********************************************************************************************************
	/*
	 * Input - Key =IBILL_NOSTRO_CODE Output : Error Message - Key = ErrorMsg
	 * 
	 */

	public DTObject ibillNostroAiphaCodekeypress(DTObject InputoBj) {
		try {
			String _ibillnostroCode = "";
			String _accountNumber = "";
			String _nostroACWithBank = "";
			String _nostroACWithBranch = "";
			String _accountName = "";
			String _bankName = "";
			String _branchName = "";
			{
				_ibillnostroCode = InputoBj.getValue("IBILL_NOSTRO_CODE").trim().toString();
			}
			Init_ResultObj(InputoBj);
			if (String.valueOf(_ibillnostroCode).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (Check_Result_Status()) {
				dtobj.clearMap();
				comnval = new CommonValidator();
				dtobj.setValue("NOSTRO_AC_CODE", _ibillnostroCode);
				dtobj.setValue("FetchReq", "true");
				dtobj.setValue("FetchColumns", "facno(NOSTRO_NOSTRO_AC_NUM)NOSTRO_NOSTRO_AC_NUM, NOSTRO_AC_WITH_BANK, NOSTRO_AC_WITH_BRANCH");
				Resultobj = comnval.valnostro(dtobj);
				if (Check_Result_Status()) {
					_accountNumber = Resultobj.getValue("NOSTRO_NOSTRO_AC_NUM");
					_nostroACWithBank = Resultobj.getValue("NOSTRO_AC_WITH_BANK");
					_nostroACWithBranch = Resultobj.getValue("NOSTRO_AC_WITH_BRANCH");
					// S.SureshBabu Changes 25/09/08
					if (!_accountNumber.equalsIgnoreCase("0")) {
						dtobj.clearMap();
						accval = new AccountValidator();
						dtobj.setValue("ACCOUNT_NUMBER", _accountNumber);
						dtobj.setValue("VALIDATION_NUMBER", "2");
						Resultobj = accval.accValid(dtobj);
						if (Check_Result_Status())
							_accountName = Resultobj.getValue("ACNTS_AC_NAME1");
					}

					if (Check_Result_Status()) {
						dtobj.clearMap();
						comnval = new CommonValidator();
						dtobj.setValue("BANKCD_CODE", String.valueOf(_nostroACWithBank));
						Resultobj = comnval.valbankcd(dtobj);
						if (Check_Result_Status()) {
							_bankName = Resultobj.getValue("BANKCD_NAME");
							comnval = new CommonValidator();
							dtobj.clearMap();
							dtobj.setValue("MBKBRN_BANK_CODE", _nostroACWithBank);
							dtobj.setValue("MBKBRN_BRN_CODE", _nostroACWithBranch);
							Resultobj = comnval.valmbkbrn(dtobj);
						}
						if (Check_Result_Status()) {
							Resultobj.setValue("MBRN_NAME", _bankName);
							Resultobj.setValue("ACNTS_AC_NAME1", _accountName);
							Resultobj.setValue("NOSTRO_NOSTRO_AC_NUM", _accountNumber);
							Resultobj.setValue("BANK_CODE", _nostroACWithBank);
							Resultobj.setValue("BRANCH_CODE", _nostroACWithBranch);
						}
					}

				}

			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in ibillNostroAiphaCodekeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	/*
	 * InputKey=CBD outputKey=FINANCIAL_YEAR
	 */
	// ************************************************************************************************************
	public DTObject getFinancialYear(DTObject InputoBj) {
		try {

			String _currBusDate = InputoBj.getValue("CBD");

			Resultobj.setValue("FINANCIAL_YEAR", getFinYear(_currBusDate));
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in getFinancialYear");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	/*
	 * InputKey=CBD IBILL_NOSTRO_DB_DATE IBILL_BILL_DATE outputKey=ERROR_MSG
	 */
	// ************************************************************************************************************
	public DTObject ibillDateofDbtoNostroAckeypress(DTObject InputoBj) {
		try {
			String DateofDbtoNostroAc = "";
			String _currBusDate = "";
			String _billDate = "";
			_currBusDate = InputoBj.getValue("CBD").trim().toString();
			{
				DateofDbtoNostroAc = InputoBj.getValue("IBILL_NOSTRO_DB_DATE").trim().toString();
				_billDate = InputoBj.getValue("IBILL_BILL_DATE");
			}
			Init_ResultObj(InputoBj);
			if (String.valueOf(DateofDbtoNostroAc).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (!DateofDbtoNostroAc.equalsIgnoreCase("")) {
				if (Check_Result_Status()) {
					CheckDate(DateofDbtoNostroAc);
					if (Check_Result_Status()) {// Changes
						// P.Subramani-Chn-10/04/2008
						if (!(DateUtility.DateLessThanOrEqual(DateofDbtoNostroAc, _billDate))) {
							Resultobj.setValue(ErrorKey, "Date of Db to Nostro A/c should be Lessthan or Equalto Bill Date ");
						}

					}
				}
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in ibillDateofDbtoNostroAckeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	/*
	 * InputKey= IBDRFT_DRFT_DATE IBILL_BILL_DATE outputKey=ERROR_MSG
	 */
	// ************************************************************************************************************
	public DTObject ibillDraftDatekeypress(DTObject InputoBj) {
		try {
			String _draftDate = "";
			String _billDate = "";
			{
				_draftDate = InputoBj.getValue("IBDRFT_DRFT_DATE").trim().toString();
				_billDate = InputoBj.getValue("IBILL_BILL_DATE").trim().toString();
			}
			Init_ResultObj(InputoBj);
			if (String.valueOf(_draftDate).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (!_draftDate.equalsIgnoreCase("")) {
				if (Check_Result_Status()) {
					CheckDate(_draftDate);
					if (Check_Result_Status()) {
						if (!(DateUtility.DateLessThanOrEqual(_draftDate, _billDate))) {
							Resultobj.setValue(ErrorKey, "Draft Date should be less than or equal to Bill Date ");

						}

					}
				}
			}

		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in ibillDraftDatekeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	// *********************************************************************************************************
	/*
	 * Input - Key =IBILL_AGEN_CODE
	 * 
	 * Output : Error Message Key = ErrorMsg Key=CURR_NAME,
	 * 
	 */

	public DTObject ibillAgencyCurrencyCodekeypress(DTObject InputoBj) {
		try {
			String _ibillAgencyCurr = "";
			String _currName = "";
			String _declength2 = "";
			{
				_ibillAgencyCurr = InputoBj.getValue("IBILL_AGEN_CODE");
			}
			Init_ResultObj(InputoBj);
			if (String.valueOf(_ibillAgencyCurr).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (Check_Result_Status()) {
				comnval = new CommonValidator();
				dtobj.clearMap();
				dtobj.setValue("CURR_CODE", _ibillAgencyCurr);
				dtobj.setValue("FetchReq", "true");
				Resultobj = comnval.valcurrcd(dtobj);
				if (Check_Result_Status()) {
					_currName = Resultobj.getValue("CURR_NAME");
					_declength2 = String.valueOf(cbsglobal.getcurrdeclength(_ibillAgencyCurr));
					if (Check_Result_Status()) {
						Resultobj.setValue("CURR_NAME", _currName);
						Resultobj.setValue("DEC_LEN", _declength2);
					}
				}

			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in ibillCurrencyCodekeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	/*
	 * This Method is used to get the Grid values from OLCTENORS
	 */
	// *********************************************************************************************************
	// *********************************************************************************************************
	/*
	 * Input - Key=OLC_SL Key=BRANCH_CODE Key=OLC_YEAR Key=OLC_TYPE Key=TENOR_SL
	 * 
	 * Output : Error Message Key = ErrorMsg
	 * 
	 * 
	 */
	public DTObject ibillDrawDownkeypress(DTObject InputoBj) {
		try {
			int _olcSl = 0;
			int _DrawDown = 0;
			String _olcType = "";
			int _olcYear = 0;
			int _brnCode = 0;
			int _tenorSl = 0;
			{
				_brnCode = Integer.parseInt(InputoBj.getValue("BRANCH_CODE").trim().toString());
				_olcYear = Integer.parseInt(InputoBj.getValue("OLC_YEAR").trim().toString());
				_olcSl = Integer.parseInt(InputoBj.getValue("OLC_SL").trim().toString());
				// _DrawDown=Integer.parseInt(InputoBj.getValue("TENOR_SL").trim().toString());
				_olcType = InputoBj.getValue("OLC_TYPE").trim().toString();
				_tenorSl = Integer.parseInt(InputoBj.getValue("TENOR_SL").trim().toString());

			}
			Init_ResultObj(InputoBj);
			if ((!String.valueOf(_tenorSl).trim().equalsIgnoreCase("")) && (!String.valueOf(_olcYear).trim().equalsIgnoreCase("")) && (!String.valueOf(_brnCode).trim().equalsIgnoreCase("")) && (!String.valueOf(_olcSl).trim().equalsIgnoreCase(""))) {
				if ((_tenorSl == 0) && (_olcSl == 0) && (_olcYear == 0) && (_brnCode == 0))
					if (((InputoBj.containsKey("BRANCH_CODE") == true) && (InputoBj.getValue("BRANCH_CODE").trim().equalsIgnoreCase(""))) && ((InputoBj.containsKey("OLC_YEAR") == true) && (InputoBj.getValue("OLC_YEAR").trim().equalsIgnoreCase(""))) && ((InputoBj.containsKey("OLC_SL") == true) && (InputoBj.getValue("OLC_SL").trim().equalsIgnoreCase(""))) && ((InputoBj.containsKey("TENOR_SL") == true) && (InputoBj.getValue("TENOR_SL").trim().equalsIgnoreCase(""))))
						Resultobj.setValue(ErrorKey, BLANK_CHECK);
					else
						Resultobj.setValue(ErrorKey, ZERO_CHECK);
			}
			if (_olcType.equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (Check_Result_Status()) {// Changes P.Subramani-Chn-28/03/2008
				_QueryStr = "SELECT OLCT_TENOR_TYPE, OLCT_USANCE_PERD, OLCT_USANCE_FROM, OLCT_OTHER_DATE_DESC, OLCT_OTHER_DATE_START_FROM, OLCT_TENOR_AMT, OLCT_USANCE_INT_RATE, OLCT_USANCE_INT_AMT, OLCT_DOC_DELIVERY , OLCT_BAL_TENOR_AMT " + " FROM OLCTENORS WHERE  OLCT_BRN_CODE=? AND OLCT_LC_TYPE=? AND OLCT_LC_YEAR=? AND OLCT_LC_SL=? AND OLCT_TENOR_SL=?";
				Set_preparedStatement(_QueryStr);
				_pstmt.setInt(1, _brnCode);
				_pstmt.setString(2, _olcType);
				_pstmt.setInt(3, _olcYear);
				_pstmt.setInt(4, _olcSl);
				_pstmt.setInt(5, _tenorSl);
				Resultobj = Get_Value_From_Main("OLCTENORS");
			}
			if (Check_Result_Status()) {
				if (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowNotPresent)) {
					Resultobj.setValue(ErrorKey, "Invalid Drawdown No");
				}
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in ibillDrawDownkeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	// *********************************************************************************************************
	// *********************************************************************************************************
	/*
	 * Input - Key=DATE_OF_NEGO Key=CBD Key=BILL_ENTRY_DATE Output : Error
	 * Message Key = ErrorMsg
	 * 
	 * 
	 */
	public DTObject ibillDateOfNegkeypress(DTObject InputoBj) {
		try {
			String _dateNeg = "";
			String _CBD = "";
			String _billEntry = "";
			{
				_dateNeg = InputoBj.getValue("DATE_OF_NEGO").trim().toString();
				_CBD = InputoBj.getValue("CBD").trim().toString();
				_billEntry = InputoBj.getValue("BILL_ENTRY_DATE").trim().toString();
			}
			Init_ResultObj(InputoBj);

			if (String.valueOf(_dateNeg).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (!_dateNeg.equalsIgnoreCase("")) {
				if (Check_Result_Status()) {
					CheckDate(_dateNeg);
					if (Check_Result_Status()) {
						if (!(DateUtility.DateLessThanOrEqual(_dateNeg, _CBD))) {
							Resultobj.setValue(ErrorKey, "Date of Neg Should be Lessthan or Equal to Current Business Date ");
						}
						if (!(DateUtility.DateLessThanOrEqual(_dateNeg, _billEntry))) {
							Resultobj.setValue(ErrorKey, "Date of Neg Should Be Lessthan or Equal to Bill Entry Date ");
						}
					}
				}
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in ibillDateOfNegkeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	// *********************************************************************************************************
	/*
	 * Input - Key =OLC_TYPE Output : Error Message - Key = ErrorMsg key= key=
	 */

	public DTObject ibillOlcTypekeypress(DTObject InputoBj) {
		try {

			String _ircrolcType = "";
			String _ircrTNOMEN_LC_BILL_BG = "";
			String _ircrTNOMEN_IW_OW = "";
			String _ircrTNOMEN_AUTO_NUM = "";
			String _ircrTNOMEN_INLAND_OVERSEAS = "";
			String _ircrTNOMEN_NUM_CHOICE = "";
			String _ibillTNOMEN_BILL_TYPE = "";
			{
				_ircrolcType = InputoBj.getValue("OLC_TYPE").trim().toString();
			}
			Init_ResultObj(InputoBj);
			if (String.valueOf(_ircrolcType).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (Check_Result_Status()) {

				tfmval = new TFMValidator();
				dtobj.clearMap();
				dtobj.setValue("TNOMEN_NOMEN_CODE", _ircrolcType);
				dtobj.setValue(FetchReq, "true");
				dtobj.setValue("FetchColumns", "TNOMEN_LC_BILL_BG,TNOMEN_IW_OW,TNOMEN_INLAND_OVERSEAS,TNOMEN_BILL_TYPE,TNOMEN_AUTO_NUM,TNOMEN_NUM_CHOICE");
				Resultobj = tfmval.valtnomen(dtobj);
				if (Check_Result_Status()) {
					_ircrTNOMEN_LC_BILL_BG = Resultobj.getValue("TNOMEN_LC_BILL_BG");
					_ircrTNOMEN_INLAND_OVERSEAS = Resultobj.getValue("TNOMEN_INLAND_OVERSEAS");
					_ircrTNOMEN_IW_OW = Resultobj.getValue("TNOMEN_IW_OW");
					_ircrTNOMEN_AUTO_NUM = Resultobj.getValue("TNOMEN_AUTO_NUM");
					_ircrTNOMEN_NUM_CHOICE = Resultobj.getValue("TNOMEN_NUM_CHOICE");
					_ibillTNOMEN_BILL_TYPE = Resultobj.getValue("TNOMEN_BILL_TYPE");
					if (!_ircrTNOMEN_LC_BILL_BG.equalsIgnoreCase("L")) {
						Resultobj.setValue(ErrorKey, "LC Type Should be Marked for Letter of Credit");
					}
					if (!_ircrTNOMEN_IW_OW.equalsIgnoreCase("O")) {
						Resultobj.setValue(ErrorKey, "LC Type Should be Marked for Outward");
					}
					if (!_ircrTNOMEN_INLAND_OVERSEAS.equalsIgnoreCase("O")) {
						Resultobj.setValue(ErrorKey, "LC Type Should be Reserved for Overseas");
					}
				}
			}
			if (Check_Result_Status()) {
				Resultobj.setValue("TNOMEN_AUTO_NUM", _ircrTNOMEN_AUTO_NUM);
				Resultobj.setValue("TNOMEN_NUM_CHOICE", _ircrTNOMEN_NUM_CHOICE);
				Resultobj.setValue("TNOMEN_BILL_TYPE", _ibillTNOMEN_BILL_TYPE);
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in ibillOlcTypekeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	// *********************************************************************************************************

	// *********************************************************************************************************
	// *********************************************************************************************************
	/*
	 * Input - Key =BRANCH_CODE Key=OLC_TYPE Key=OLC_YEAR Key=OLC_SL Key=OPTION
	 * Output : Error Message - Key = ErrorMsg key=IRT_REMIT_MODE
	 * key=IRT_TRAN_NUM_YEAR
	 */

	public DTObject ibillOlcSlkeypress(DTObject InputoBj) {
		try {
			int _brnCode = 0;
			String _olcType = "";
			int _olcYear = 0;
			int _olcSl = 0;

			// ADDED BY PRASHANTH ON 14 AUGUST 2019
			String billType = "";
			int billYear = 0;
			int billSl = 0;
			String contraAmtSoFar = "";
			int rownum = 0;
			String authby = "";
			String rejby = "";
			// ADDED BY PRASHANTH ON 14 AUGUST 2019

			// ADDED BY PRASHANTH ON 29 MARCH 2019 FOR CONTRA WASH OFF
			String contrAmount = "";
			// ADDED BY PRASHANTH ON 29 MARCH 2019 FOR CONTRA WASH OFF

			// Changes P.Subramani-Chn-10/04/2008 Beg
			String olcconvratebasecurr = "";
			String olccorrrefnum = "";
			String olclcdate = "";
			String olccustnum = "";
			String olcbenefcode = "";
			String olcbenefname = "";
			String olclcissbkcode = "";
			String olclcissbrncode = "";
			String olclccurrcode = "";
			String olclcamount = "";
			String olclastdateofneg = "";
			String olclatestdateofshpmnt = "";
			String olclcbalance = "";
			String _amdSl = "";
			String olcnooftenors = "";
			String olcrejby = "";
			String billdate = "";
			String olccustliabaccnum = "";
			String _Option = "";
			// Changes P.Subramani-Chn-10/04/2008 End

			// Changes P.Subramani-Chn-28/04/2008
			String olcdevamt = "";
			// treasury changes by PRASHANTH chn 07-08-2017
			String treasuryEnabled = InputoBj.getValue("TREASURY_ENABLED");
			String trancratesRateSerial = "";
			double convrate = 0;
			// ADDED BY PRASHANTH ON 08 AUGUST 2019
			String olcAmdFinalTotalAmt = "";
			String olcAmdConvRate = "";
			String olcAmdFinalConvAmt = "";
			// ADDED BY PRASHANTH ON 08 AUGUST 2019
			
			String olcContraAmt="";
			
			// treasury changes by PRASHANTH chn 07-08-2017
			{
				_olcType = InputoBj.getValue("OLC_TYPE").trim().toString();
				_brnCode = Integer.parseInt(InputoBj.getValue("BRANCH_CODE").trim().toString().trim().toString());
				_olcSl = Integer.parseInt(InputoBj.getValue("OLC_SL").trim().toString().trim().toString());
				_olcYear = Integer.parseInt(InputoBj.getValue("OLC_YEAR").trim().toString().trim().toString());
				billdate = InputoBj.getValue("BILL_DATE").trim().toString();
				// Changes N.Saravanan-Chn-29/09/2008
				_Option = InputoBj.getValue("OPTION").trim().toString();

				// ADDED BY PRASHANTH ON 14 AUGUST 2019
				billType = InputoBj.getValue("BILL_TYPE").trim().toString();
				billYear = Integer.parseInt(InputoBj.getValue("BILL_YEAR").trim().toString().trim().toString());
				billSl = Integer.parseInt(InputoBj.getValue("BILL_SERIAL").trim().toString().trim().toString());
				// ADDED BY PRASHANTH ON 14 AUGUST 2019
			}
			Init_ResultObj(InputoBj);
			if (String.valueOf(_olcSl).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
				return Resultobj.copyofDTO();
			}

			// ADDED BY PRASHANTH ON 14 AUGUST 2019
			if (Check_Result_Status()) {
				_QueryStr = "SELECT COUNT(1)COUNT FROM IBILL I WHERE I.IBILL_BRN_CODE=? AND I.IBILL_OLC_TYPE=? AND I.IBILL_OLC_YEAR=? AND I.IBILL_OLC_SL=?  AND IBILL_FINAL_BILL='1' AND I.IBILL_REJ_BY IS NULL";
				if (_Option.equals("M")) {
					_QueryStr = _QueryStr + " AND I.IBILL_BRN_CODE<>? AND I.IBILL_BILL_TYPE<>? AND I.IBILL_BILL_YEAR<>? AND I.IBILL_BILL_SL<>?";
				}
				Set_preparedStatement(_QueryStr);
				_pstmt.setInt(1, _brnCode);
				_pstmt.setString(2, _olcType);
				_pstmt.setInt(3, _olcYear);
				_pstmt.setInt(4, _olcSl);
				if (_Option.equals("M")) {
					_pstmt.setInt(5, _brnCode);
					_pstmt.setString(6, billType);
					_pstmt.setInt(7, billYear);
					_pstmt.setInt(8, billSl);
				}
				Get_Value_From_Main("IBILL");
				if (Check_Result_Status()) {
					if (Integer.parseInt(Resultobj.getValue("COUNT")) > 0) {
						Resultobj.setValue(ErrorKey, "Olc Reference Has Already Been Marked As Final!!");
						return Resultobj.copyofDTO();
					}
				}
			}
			// ADDED BY PRASHANTH ON 14 AUGUST 2019

			if (Check_Result_Status()) {
				olcval = new OLCValidator();
				dtobj.clearMap();
				dtobj.setValue("OLC_BRN_CODE", String.valueOf(_brnCode));
				dtobj.setValue("OLC_LC_TYPE", _olcType);
				dtobj.setValue("OLC_LC_YEAR", String.valueOf(_olcYear));
				dtobj.setValue("OLC_LC_SL", String.valueOf(_olcSl));
				dtobj.setValue(FetchReq, "true");
				// Changes P.Subramani-Chn-28/04/2008
				// Changes N.Saravanan -Chn-02/09/2008-Beg

				// OLC_TOT_LIAB_BASE_CURR ADDED BY PRASHANTH ON 29 MARCH 2019
				// FOR CONTRA WASH OFF
				dtobj.setValue("FetchColumns", "OLC_TOT_LIAB_BASE_CURR,TRANCRATES_RATE_SL,OLC_CONV_RATE_BASE_CURR,OLC_CORR_REF_NUM,OLC_LC_DATE,OLC_CUST_NUM,OLC_BENEF_CODE,OLC_BENEF_NAME,OLC_BENEF_ADDR1,OLC_BENEF_ADDR2,OLC_BENEF_ADDR3,OLC_BENEF_ADDR4,OLC_BENEF_ADDR5,OLC_BENEF_CNTRY_CODE,OLC_LC_ISS_BK_CODE,OLC_LC_ISS_BRN_CODE,OLC_LC_CURR_CODE,OLC_LC_AMOUNT,OLC_LAST_DATE_OF_NEG,OLC_LATEST_DATE_OF_SHPMNT,OLC_LC_BALANCE,OLC_DEV_AMOUNT,OLC_AUTH_BY,OLC_REJ_BY,OLC_CUST_LIAB_ACC,OLC_NOF_TENORS");
				// OLC_TOT_LIAB_BASE_CURR ADDED BY PRASHANTH ON 29 MARCH 2019
				// FOR CONTRA WASH OFF
				// Changes N.Saravanan -Chn-02/09/2008-end
				Resultobj = olcval.valolc(dtobj);
				
				
				if (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowNotPresent)) {
					Resultobj.setValue(ErrorKey, "Invalid LC Reference");
					return Resultobj.copyofDTO();
				}

				// Changes P.Subramani-Chn-10/04/2008 Beg
				if (Check_Result_Status()) {
					// NaveenNaidu-Chennai-22/11/2006-beg
					// SUGANYA BEGIN 03-OCT-2016
					// if((Resultobj.getValue("OLC_AUTH_BY")==null))
					if ((Resultobj.getValue("OLC_AUTH_BY") == null) && (Resultobj.getValue("OLC_REJ_BY") == null))
					// SUGANYA END 03-OCT-2016
					{
						Resultobj.setValue(ErrorKey, "Transaction Not Authorised");
						return Resultobj.copyofDTO();
					}
					// NaveenNaidu-Chennai-22/11/2006-end
					if (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowNotPresent)) {
						Resultobj.setValue(ErrorKey, "Invalid LC Reference");
						return Resultobj.copyofDTO();
					} else if (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowPresent)) {
						if (Resultobj.getValue("OLC_REJ_BY") != null) {
							Resultobj.setValue(ErrorKey, "Transaction Rejected");
							return Resultobj.copyofDTO();
						}
					}

					if (Check_Result_Status()) {
						// ADDED BY PRASHANTH ON 29 MARCH 2019 FOR CONTRA WASH
						// OFF
						contrAmount = Resultobj.getValue("OLC_TOT_LIAB_BASE_CURR");
						// ADDED BY PRASHANTH ON 29 MARCH 2019 FOR CONTRA WASH
						// OFF

						olcconvratebasecurr = Resultobj.getValue("OLC_CONV_RATE_BASE_CURR");
						olccorrrefnum = Resultobj.getValue("OLC_CORR_REF_NUM");
						olclcdate = Resultobj.getValue("OLC_LC_DATE");
						olccustnum = Resultobj.getValue("OLC_CUST_NUM");
						olcbenefcode = Resultobj.getValue("OLC_BENEF_CODE");
						olcbenefname = Resultobj.getValue("OLC_BENEF_NAME");
						olclcissbkcode = Resultobj.getValue("OLC_LC_ISS_BK_CODE");
						olclcissbrncode = Resultobj.getValue("OLC_LC_ISS_BRN_CODE");
						olclccurrcode = Resultobj.getValue("OLC_LC_CURR_CODE");
						olclcamount = Resultobj.getValue("OLC_LC_AMOUNT");
						olclastdateofneg = Resultobj.getValue("OLC_LAST_DATE_OF_NEG");
						olclatestdateofshpmnt = Resultobj.getValue("OLC_LATEST_DATE_OF_SHPMNT");
						olclcbalance = Resultobj.getValue("OLC_LC_BALANCE");
						olcrejby = Resultobj.getValue("OLC_REJ_BY");
						olccustliabaccnum = Resultobj.getValue("OLC_CUST_LIAB_ACC");
						// Changes P.Subramani-Chn-28/04/2008
						olcdevamt = Resultobj.getValue("OLC_DEV_AMOUNT");
						// Changes N.Saravanan-Chn-02/09/2008 Beg
						olcnooftenors = Resultobj.getValue("OLC_NOF_TENORS");
						// Changes N.Saravanan-Chn-02/09/2008 End
						// Changes P.Subramani-Chn-22/04/2008 Beg
						// S.Suresh Babu Changes 22-09-2009
						if (Double.parseDouble(olclcbalance) == 0) {
							Resultobj.setValue(ErrorKey, "LC Balance is Zero");
							return Resultobj.copyofDTO();
						}
						// Changes P.Subramani-Chn-22/04/2008 Beg

						// treasury changes by PRASHANTH chn 07-08-2017
						trancratesRateSerial = Resultobj.getValue("TRANCRATES_RATE_SL");
					}
				}

				// ADDED BY PRASHANTH ON 14 AUGUST 2019
				_QueryStr = "SELECT OLCCN_AUTH_BY,OLCCN_REJ_BY,ROWNUM FROM OLCCAN WHERE OLCCN_BRN_CODE = ? AND OLCCN_LC_TYPE = ? AND OLCCN_LC_YEAR = ? AND OLCCN_LC_SL = ?";
				Set_preparedStatement(_QueryStr);
				_pstmt.setInt(1, _brnCode);
				_pstmt.setString(2, _olcType);
				_pstmt.setInt(3, _olcYear);
				_pstmt.setInt(4, _olcSl);
				Resultobj = Get_Value_From_Main("OLCCAN");
				if (Check_Result_Status()) {
					if (Resultobj.getValue("ROWNUM") != null) {
						rownum = Integer.parseInt(Resultobj.getValue("ROWNUM"));
						authby = Resultobj.getValue("OLCCN_AUTH_BY");
						rejby = Resultobj.getValue("OLCCN_REJ_BY");
						if (rownum == 1 && authby == null && rejby == null) {
							Resultobj.setValue(ErrorKey, "Unauthorised Cancellation record in Queue. Cannot Proceed!");
							return Resultobj.copyofDTO();
						} else if (rownum == 1 && authby != null && rejby == null) {
							Resultobj.setValue(ErrorKey, "LC is Cancelled. Cannot Proceed!");
							return Resultobj.copyofDTO();
						} else if (rownum == 1 && authby == null && rejby != null) {
							Resultobj.setValue(ErrorKey, "");
						}
					}
				}
				// ADDED BY PRASHANTH ON 14 AUGUST 2019

				if (Check_Result_Status()) {
					_QueryStr = "Select max(OLCA_AMD_SL) OLCA_AMD_SL from OLCAMD where OLCA_BRN_CODE = ? and OLCA_LC_TYPE = ? and OLCA_LC_YEAR = ? and OLCA_LC_SL=? AND TRIM(olca_rej_by) IS NULL";
					Set_preparedStatement(_QueryStr);
					_pstmt.setInt(1, _brnCode);
					_pstmt.setString(2, _olcType);
					_pstmt.setInt(3, _olcYear);
					_pstmt.setInt(4, _olcSl);
					Resultobj = Get_Value_From_Main("OLCAMD");

					if (Check_Result_Status()) {
						_amdSl = Resultobj.getValue("OLCA_AMD_SL");
					}

					if (_amdSl != null) {
						if (!_amdSl.equalsIgnoreCase("0")) {
							OLCValidator olcval1 = new OLCValidator();
							dtobj.clearMap();
							dtobj.setValue("BRANCH_CODE", String.valueOf(_brnCode));
							dtobj.setValue("LC_TYPE", _olcType);
							dtobj.setValue("LC_YEAR", String.valueOf(_olcYear));
							dtobj.setValue("LC_SERIAL", String.valueOf(_olcSl));
							dtobj.setValue("AMENDMENT_SERIAL", String.valueOf(_amdSl));
							dtobj.setValue(FetchReq, "true");
							// Changes P.Subramani-Chn-28/04/2008
							dtobj.setValue("FetchColumns", "OLCA_CONTRA_AMT,OLCA_TOT_LIAB_BASE_CURR,OLCA_TOT_LIAB_LC_CURR,OLCA_CONV_RATE_BASE_CURR,OLCA_ENTRY_DATE,OLCA_BENEF_CODE,OLCA_BENEF_NAME,OLCA_LC_CURR_CODE,OLCA_AMENDED_AMT,OLCA_LAST_DATE_OF_NEG,OLCA_LATEST_DATE_OF_SHPMNT,OLCA_REJ_BY,OLCA_DEV_AMT");
							Resultobj = olcval1.valolcamd(dtobj);

							if (Check_Result_Status()) {
								// NaveenNaidu-Chennai-22/11/2006-beg
								// if((Resultobj.getValue("OLC_AUTH_BY")==null))
								// {
								// Resultobj.setValue(ErrorKey,"Transaction Not
								// Authorised");
								// }
								// NaveenNaidu-Chennai-22/11/2006-end
								if (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowNotPresent)) {
									Resultobj.setValue(ErrorKey, "Invalid LC Reference");
									return Resultobj.copyofDTO();
								} else if (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowPresent)) {
									if (Resultobj.getValue("OLCA_REJ_BY") != null) {
										Resultobj.setValue(ErrorKey, "Transaction Rejected");
										return Resultobj.copyofDTO();
									}
								}
							}
							if (Check_Result_Status()) {
								olclcdate = Resultobj.getValue("OLCA_ENTRY_DATE");
								olcbenefcode = Resultobj.getValue("OLCA_BENEF_CODE");
								olcbenefname = Resultobj.getValue("OLCA_BENEF_NAME");
								olclccurrcode = Resultobj.getValue("OLCA_LC_CURR_CODE");
								olclcamount = Resultobj.getValue("OLCA_AMENDED_AMT");
								olclastdateofneg = Resultobj.getValue("OLCA_LAST_DATE_OF_NEG");
								olclatestdateofshpmnt = Resultobj.getValue("OLCA_LATEST_DATE_OF_SHPMNT");
								olcrejby = Resultobj.getValue("OLCA_REJ_BY");
								// Changes P.Subramani-Chn-28/04/2008 Beg
								olcdevamt = Resultobj.getValue("OLCA_DEV_AMT");
								// Changes P.Subramani-Chn-28/04/2008 End
								// ADDED BY PRASHANTH ON 08 AUGUST 2019
								olcAmdFinalTotalAmt = Resultobj.getValue("OLCA_TOT_LIAB_LC_CURR");
								olcAmdConvRate = Resultobj.getValue("OLCA_CONV_RATE_BASE_CURR");
								// ADDED BY PRASHANTH ON 08 AUGUST 2019
								//ADDED BY PRASHANTH ON 23 AUGUST 2019
     	    	        		olcAmdFinalConvAmt= Resultobj.getValue("OLCA_TOT_LIAB_BASE_CURR");
     	    	        		olcContraAmt= Resultobj.getValue("OLCA_CONTRA_AMT");
     	    	        		//ADDED BY PRASHANTH ON 23 AUGUST 2019
							}
						}
					}
				}
				// Changes P.Subramani-Chn-22/04/2008 Beg
				if (DateUtility.DateGreaterThan(olclcdate, billdate)) {
					Resultobj.setValue(ErrorKey, "LC Date Should be lessthan or equal to Bill Date ");
					return Resultobj.copyofDTO();
				}
				// Changes P.Subramani-Chn-22/04/2008 Beg

				// N.Saravanan 24/09/08 Beg
				if (Check_Result_Status()) {
					// S.Suresh Babu Changes 15-10-2009
					_QueryStr = "SELECT IBILL_AUTH_BY FROM IBILL WHERE IBILL_BRN_CODE=? and IBILL_OLC_TYPE=? AND IBILL_OLC_YEAR=? AND IBILL_OLC_SL=? AND IBILL_AUTH_BY IS null";
					Set_preparedStatement(_QueryStr);
					_pstmt.setInt(1, _brnCode);
					_pstmt.setString(2, _olcType);
					_pstmt.setInt(3, _olcYear);
					_pstmt.setInt(4, _olcSl);
					ResultSet rs1 = _pstmt.executeQuery();
					if (Check_Result_Status()) {
						if (rs1.next()) {
							// if(rs1.getString("IBILL_AUTH_BY")==null)
							// {
							// N.Saravanan 29/09/08 Beg
							if (_Option.equalsIgnoreCase("A")) {
								Resultobj.setValue(ErrorKey, "Bills are Pending For Authorisation Under this LC ");
								return Resultobj.copyofDTO();
							}
							// N.Saravanan 29/09/08 End
							// }

						}
					}
				}
				// N.Saravanan 24/09/08 Beg

			}

			// ADDED BY PRASHANTH ON 08 AUGUST 2019
		/*	if (!olcAmdFinalTotalAmt.equals("")) {
				if (Check_Result_Status()) {
					TFMValidator tfmVal = new TFMValidator();
					dtobj.clearMap();
					dtobj.setValue("FOR_CURR", olclccurrcode);
					dtobj.setValue("AGAINST_CURR", "INR");
					dtobj.setValue("FOR_AMOUNT", String.valueOf(olcAmdFinalTotalAmt));
					dtobj.setValue("CONVERSION_RATE", olcAmdConvRate);
					Resultobj = tfmVal.getconversionrateAmount(dtobj);
					Resultobj.setValue("CONVERTED_AMOUNT", Resultobj.getValue("CONV_AMNT"));
					olcAmdFinalConvAmt = Resultobj.getValue("CONV_AMNT");
				}
			}

			// ADDED BY PRASHANTH ON 08 AUGUST 2019
*/
			// treasury changes by PRASHANTH chn 07-08-2017
			if (Check_Result_Status()) {
				if (treasuryEnabled.equals("1")) {
					String _Qquery = "";
					_Qquery = "SELECT  TRANCRATES_CONV_RATE FROM  TRANCRATES WHERE TRANCRATES_SL = ?";
					Set_preparedStatement(_Qquery);
					_pstmt.setString(1, trancratesRateSerial);
					Resultobj = Get_Value_From_Main("TRANCRATES");

					if (Check_Result_Status()) {
						if ((Resultobj.getValue(ResultKey).equalsIgnoreCase(RowPresent))) {
							convrate = Double.parseDouble(Resultobj.getValue("TRANCRATES_CONV_RATE"));
						} else {
							Resultobj.setValue(ErrorKey, "Data does not exists in TRANCRATES");
							return Resultobj.copyofDTO();
						}
					}
				}
			}

			// ADDED BY PRASHANTH ON 14 AUGUST 2019
			if (Check_Result_Status()) {
				_QueryStr = "SELECT COUNT(1)COUNT FROM IBILL I WHERE I.IBILL_BRN_CODE=? AND I.IBILL_OLC_TYPE=? AND I.IBILL_OLC_YEAR=? AND I.IBILL_OLC_SL=?  AND I.IBILL_REJ_BY IS NULL";
				if (_Option.equals("M")) {
					_QueryStr = _QueryStr + " AND I.IBILL_BRN_CODE<>? AND I.IBILL_BILL_TYPE<>? AND I.IBILL_BILL_YEAR<>? AND I.IBILL_BILL_SL<>?";
				}
				Set_preparedStatement(_QueryStr);
				_pstmt.setInt(1, _brnCode);
				_pstmt.setString(2, _olcType);
				_pstmt.setInt(3, _olcYear);
				_pstmt.setInt(4, _olcSl);
				if (_Option.equals("M")) {
					_pstmt.setInt(5, _brnCode);
					_pstmt.setString(6, billType);
					_pstmt.setInt(7, billYear);
					_pstmt.setInt(8, billSl);
				}
				Resultobj = Get_Value_From_Main("IBILL");
				if (Check_Result_Status()) {
					if (Integer.parseInt(Resultobj.getValue("COUNT")) > 0) {
						_QueryStr = "SELECT SUM(I.IBILL_AMT_REC_CURR)IBILL_AMT_REC_CURR FROM IBILL I WHERE I.IBILL_BRN_CODE=? AND I.IBILL_OLC_TYPE=? AND I.IBILL_OLC_YEAR=? AND I.IBILL_OLC_SL=?  AND I.IBILL_REJ_BY IS NULL";
						if (_Option.equals("M")) {
							_QueryStr = _QueryStr + " AND I.IBILL_BRN_CODE<>? AND I.IBILL_BILL_TYPE<>? AND I.IBILL_BILL_YEAR<>? AND I.IBILL_BILL_SL<>?";
						}
						Set_preparedStatement(_QueryStr);
						_pstmt.setInt(1, _brnCode);
						_pstmt.setString(2, _olcType);
						_pstmt.setInt(3, _olcYear);
						_pstmt.setInt(4, _olcSl);
						if (_Option.equals("M")) {
							_pstmt.setInt(5, _brnCode);
							_pstmt.setString(6, billType);
							_pstmt.setInt(7, billYear);
							_pstmt.setInt(8, billSl);
						}
						Resultobj = Get_Value_From_Main("IBILL");
						if (Check_Result_Status()) {
							contraAmtSoFar = Resultobj.getValue("IBILL_AMT_REC_CURR");
						}
					}
				}
			}
			// ADDED BY PRASHANTH ON 14 AUGUST 2019

			// treasury changes by PRASHANTH chn 07-08-2017

			Resultobj.setValue("OLC_CONV_RATE_BASE_CURR", olcconvratebasecurr);
			Resultobj.setValue("OLC_CORR_REF_NUM", olccorrrefnum);
			Resultobj.setValue("OLC_LC_DATE", olclcdate);
			Resultobj.setValue("OLC_CUST_NUM", olccustnum);
			Resultobj.setValue("OLC_BENEF_CODE", olcbenefcode);
			Resultobj.setValue("OLC_BENEF_NAME", olcbenefname);
			Resultobj.setValue("OLC_LC_ISS_BK_CODE", olclcissbkcode);
			Resultobj.setValue("OLC_LC_ISS_BRN_CODE", olclcissbrncode);
			Resultobj.setValue("OLC_LC_CURR_CODE", olclccurrcode);
			Resultobj.setValue("OLC_LC_AMOUNT", olclcamount);
			Resultobj.setValue("OLC_LAST_DATE_OF_NEG", olclastdateofneg);
			Resultobj.setValue("OLC_LATEST_DATE_OF_SHPMNT", olclatestdateofshpmnt);
			Resultobj.setValue("OLC_LC_BALANCE", olclcbalance);
			Resultobj.setValue("OLC_CUST_LIAB_ACC", olccustliabaccnum);
			// Changes P.Subramani-Chn-10/04/2008 End
			// Changes P.Subramani-Chn-28/04/2008 Beg
			Resultobj.setValue("OLC_DEV_AMOUNT", olcdevamt);
			// Changes P.Subramani-Chn-28/04/2008 End
			// Changes N.Saravanan-Chn-02/09/2008 Beg
			Resultobj.setValue("OLC_NOF_TENORS", olcnooftenors);
			// Changes N.Saravanan-Chn-02/09/2008 End

			// treasury changes by PRASHANTH chn 07-08-2017
			Resultobj.setValue("CONV_RATE", String.valueOf(convrate));
			// treasury changes by PRASHANTH chn 07-08-2017
			// ADDED BY PRASHANTH ON 29 MARCH 2019 FOR CONTRA WASH OFF
			// ADDED BY PRASHANTH ON 08 AUGUST 2019
			/*if (olcAmdFinalConvAmt.equals("")) {
				Resultobj.setValue("OLC_TOT_LIAB_BASE_CURR", String.valueOf(contrAmount));
			} else {
				Resultobj.setValue("OLC_TOT_LIAB_BASE_CURR", String.valueOf(olcAmdFinalConvAmt));
			}
			*/
			Resultobj.setValue("OLC_TOT_LIAB_BASE_CURR", String.valueOf(olcContraAmt));
			Resultobj.setValue("CONTRA_UTILIZED", String.valueOf(contraAmtSoFar));
			Resultobj.setValue(ErrorKey, "");
			// ADDED BY PRASHANTH ON 08 AUGUST 2019
			// ADDED BY PRASHANTH ON 29 MARCH 2019 FOR CONTRA WASH OFF
			// OLCA_TOT_LIAB_LC_CURR,OLCA_CONV_RATE_BASE_CURR
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in ibillOlcSlkeypress");
		}
		return Resultobj.copyofDTO();

	}

	// *********************************************************************************************************
	// *********************************************************************************************************

	// *********************************************************************************************************
	/*
	 * Input - Key =BILL_TYPE
	 * 
	 * Output : Error Message - Key = ErrorMsg key=TRCHG_HANDLING_CHGCD
	 * key=TRCHG_COURIER_CHGCD key=TRCHG_POSTAL_CHGCD
	 */
	// *********************************************************************************************************
	public DTObject ibillCallCharges(DTObject InputoBj) {
		try {

			String _billtype = "";
			String _baseCurr = "";
			{
				_billtype = InputoBj.getValue("BILL_TYPE").trim().toString();
				_baseCurr = get_base_curr_code();
			}
			Init_ResultObj(InputoBj);
			if (String.valueOf(_billtype).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (Check_Result_Status()) {

				_QueryStr = "Select TRCHG_COMMN_CHGCD, TRCHG_HANDLING_CHGCD, TRCHG_COURIER_CHGCD, TRCHG_POSTAL_CHGCD, TRCHG_SWIFT_CHGCD " + " from TRCHGPARAM  where TRCHG_NOMEN_CODE = ? and  TRCHG_OPT_TYPE = 1 and TRCHG_FACILITY_CURR =?";
				Set_preparedStatement(_QueryStr);
				_pstmt.setString(1, _billtype);
				_pstmt.setString(2, _baseCurr);
				Resultobj = Get_Value_From_Main("TRCHGPARAM");
				if (Check_Result_Status()) {
					if (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowNotPresent)) {
						// NaveenNaidu-Chennai-22/11/2007-beg
						_QueryStr = "Select TRCHG_COMMN_CHGCD,TRCHG_HANDLING_CHGCD, TRCHG_COURIER_CHGCD, TRCHG_POSTAL_CHGCD, TRCHG_SWIFT_CHGCD " + " from TRCHGPARAM  where TRCHG_NOMEN_CODE = ? and  TRCHG_OPT_TYPE = 1 and TRCHG_FACILITY_CURR =?";
						Set_preparedStatement(_QueryStr);
						_pstmt.setString(1, _billtype);
						_pstmt.setString(2, " ");
						Resultobj = Get_Value_From_Main("TRCHGPARAM");
						// NaveenNaidu-Chennai-22/11/2007-beg
						if (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowNotPresent)) {
							Resultobj.setValue(ErrorKey, "Charges Not Exists");
						}
					}

				}
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in ibillCallCharges");
		}
		return Resultobj.copyofDTO();

	}

	// *********************************************************************************************************
	/*
	 * Input - Key =IBILL_CUST_LIAB_ACC Key=IBILL_PRODUCT_CODE
	 * Key=IBILL_BRANCH_CODE
	 * 
	 * Output : Error Message - Key = ErrorMsg key=TRCHG_HANDLING_CHGCD
	 * key=TRCHG_COURIER_CHGCD key=TRCHG_POSTAL_CHGCD
	 */
	// *********************************************************************************************************
	public DTObject ibillCustmerAccountkeypress(DTObject InputoBj) {
		try {

			String _custAcctNum = "0";
			String _productCode = "";
			int _branchCode = 0;
			String _productCode2 = "";
			String _internalAccNum = "";
			String _limitNum = "";
			String _custNum = "";
			String _limitCurr = "";
			String _limitAmt = "";
			String _outStandingAmt = "";
			String _accName = "";
			String _actual_Account_Num = "";
			String _declength = "";
			{
				_custAcctNum = InputoBj.getValue("IBILL_CUST_LIAB_ACC").trim().toString();
				_productCode = InputoBj.getValue("IBILL_PRODUCT_CODE").trim().toString();
				_branchCode = Integer.parseInt(InputoBj.getValue("IBILL_BRANCH_CODE").trim().toString());
				_custNum = InputoBj.getValue("IBILL_CUST_NO").trim().toString();
			}
			Init_ResultObj(InputoBj);
			if (!String.valueOf(_custAcctNum).trim().equalsIgnoreCase("")) {
				if (_custAcctNum.equalsIgnoreCase("0"))
					if ((InputoBj.containsKey("IBILL_CUST_LIAB_ACC") == true) && (InputoBj.getValue("IBILL_CUST_LIAB_ACC").trim().equalsIgnoreCase("")))
						Resultobj.setValue(ErrorKey, BLANK_CHECK);
					else
						Resultobj.setValue(ErrorKey, ZERO_CHECK);
			}

			if (Check_Result_Status()) {

				accval = new AccountValidator();
				dtobj.clearMap();
				dtobj.setValue("BRANCH_CODE", String.valueOf(_branchCode));
				dtobj.setValue("ACCOUNT_NUMBER", String.valueOf(_custAcctNum));
				dtobj.setValue(FetchReq, "true");
				dtobj.setValue("FetchColumns", "ACNTS_PROD_CODE");
				Resultobj = accval.chkacntstatus(dtobj);
				if (Check_Result_Status()) {
					_productCode2 = Resultobj.getValue("ACNTS_PROD_CODE");
					_internalAccNum = Resultobj.getValue("ACNTS_INTERNAL_ACNUM");
					_accName = Resultobj.getValue("ACNTS_AC_NAME1");
					_actual_Account_Num = Resultobj.getValue("ACNTS_ACCOUNT_NUMBER");
					if (_productCode.equalsIgnoreCase(_productCode2)) {
						limval = new LimitValidator();
						dtobj.clearMap();
						dtobj.setValue("ACASLLDTL_INTERNAL_ACNUM", _internalAccNum);
						dtobj.setValue(FetchReq, "true");
						Resultobj = limval.vallimitforacnt(dtobj);
						if (Check_Result_Status()) {
							_limitNum = Resultobj.getValue("ACASLLDTL_LIMIT_LINE_NUM");
							if (_limitNum.equalsIgnoreCase("0")) {
								_limitNum = "0";
								_limitCurr = "";
								_outStandingAmt = "0";
								_limitAmt = "0";
								_declength = "0";
								Resultobj.setValue("LIMIT_LINE_NUM", _limitNum);
								Resultobj.setValue("LMTLINE_SANCTION_CURR", _limitCurr);
								Resultobj.setValue("LMTLINE_SANCTION_AMT", _limitAmt);
								Resultobj.setValue("OUT_STANDING_AMT", _outStandingAmt);
								Resultobj.setValue("DEC_LEN", _declength);
							} else {
								limval = new LimitValidator();
								dtobj.clearMap();
								dtobj.setValue("LMTLINE_CLIENT_CODE", _custNum);
								dtobj.setValue("LMTLINE_NUM", _limitNum);
								dtobj.setValue(FetchReq, "true");
								dtobj.setValue("FetchColumns", "LMTLINE_SANCTION_CURR,LMTLINE_SANCTION_AMT ");
								Resultobj = limval.vallimitline(dtobj);
								if (Check_Result_Status()) {
									_limitCurr = Resultobj.getValue("LMTLINE_SANCTION_CURR");
									_limitAmt = Resultobj.getValue("LMTLINE_SANCTION_AMT");
									limval = new LimitValidator();
									dtobj.clearMap();
									dtobj.setValue("CLIENT_CODE", _custNum);
									dtobj.setValue("LMTLINE_NUM", _limitNum);
									dtobj.setValue(FetchReq, "true");
									Resultobj = limval.valllacntos(dtobj);
									if (Check_Result_Status()) {
										_outStandingAmt = Resultobj.getValue("OUT_STANDING_AMT");
										_declength = String.valueOf(cbsglobal.getcurrdeclength(_limitCurr));
									}
								}
							}
						}
					} else {
						Resultobj.setValue(ErrorKey, "Account Product does not match");
					}
					if (Check_Result_Status()) {
						Resultobj.setValue("ACNTS_ACCOUNT_NUMBER", _actual_Account_Num);
						Resultobj.setValue("INTERNAL_ACCOUNT_NUMBER", _internalAccNum);
						Resultobj.setValue("ACOUNT_NAME", _accName);
						Resultobj.setValue("LIMIT_LINE_NUM", _limitNum);
						Resultobj.setValue("LMTLINE_SANCTION_CURR", _limitCurr);
						Resultobj.setValue("LMTLINE_SANCTION_AMT", _limitAmt);
						Resultobj.setValue("OUT_STANDING_AMT", _outStandingAmt);
						Resultobj.setValue("DEC_LEN", _declength);
					}
				}

			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in ibillCustmerAccountkeypress");
		}
		return Resultobj.copyofDTO();

	}

	// *********************************************************************************************************
	/*
	 * Input - Key =BILL_AMT Key=BILL_CURR Key=CONVER_RATE
	 * 
	 * Output : Error Message - Key = ErrorMsg key=AMT_AGNST_CURR
	 * 
	 */
	// *********************************************************************************************************
	public DTObject ibillBillAgainstAmountCalculation(DTObject InputoBj) {
		try {
			String _billAmount = "";
			String _convrate = "";
			String _billCurr = "";
			String _againstAmt = "";

			{
				_billAmount = InputoBj.getValue("BILL_AMT").trim().toString();
				_convrate = InputoBj.getValue("CONVER_RATE").trim().toString();
				_billCurr = InputoBj.getValue("BILL_CURR").trim().toString();

			}
			Init_ResultObj(InputoBj);

			comnval = new CommonValidator();
			dtobj.clearMap();
			dtobj.setValue("FOR_CURR", _billCurr);
			dtobj.setValue("AGNST_CURR", get_base_curr_code());
			dtobj.setValue("AMT_FOR_CURR", _billAmount);
			dtobj.setValue("CONVER_RATE", _convrate);
			Resultobj = comnval.calAgnstVal(dtobj);
			if (Check_Result_Status()) {
				_againstAmt = Resultobj.getValue("AMT_AGNST_CURR");
				Resultobj.setValue("AMT_AGNST_CURR", _againstAmt);
			}

		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in ibillBillAgainstAmountCalculation");
		}
		return Resultobj.copyofDTO();

	}

	// Changes P.Subramani-Chn-08/04/2008 Beg
	// *********************************************************************************************************
	/*
	 * Input - Key =IRCR_YEAR Key=BRANCH_CODE Key=BILL_TYPE
	 * key=TNOMEN_NUM_CHOICE key=CBD key=OPTION key=TNOMEN_AUTO_NUM
	 * 
	 * Output : Error Message - Key = ErrorMsg
	 */

	public DTObject olcYearkeypress(DTObject InputoBj) {
		try {
			int _ircrYear = 0;
			String _ibill_TNOMEN_NUM_CHOICE = "";
			String _currBusDate = "";
			int _branchCode = 0;
			String _billType = "";

			if (InputoBj.getValue("IRCR_YEAR").trim().equalsIgnoreCase("")) {
				_ircrYear = 0;
			} else {
				_ircrYear = Integer.parseInt(InputoBj.getValue("IRCR_YEAR").trim().toString());
			}
			Init_ResultObj(InputoBj);
			if (String.valueOf(_ircrYear).trim().equalsIgnoreCase("0")) {
				if (_ircrYear == 0)
					if ((InputoBj.containsKey("IRCR_YEAR") == true) && (InputoBj.getValue("IRCR_YEAR").trim().equalsIgnoreCase("")))
						Resultobj.setValue(ErrorKey, BLANK_CHECK);
					else
						Resultobj.setValue(ErrorKey, ZERO_CHECK);
			}
			if (Check_Result_Status()) {
				if (!(_ircrYear >= 1900)) {
					Resultobj.setValue(ErrorKey, "Year should be greater than or equal 1900");
				}
				if (Check_Result_Status()) {

					_ibill_TNOMEN_NUM_CHOICE = InputoBj.getValue("TNOMEN_NUM_CHOICE").trim().toString();
					_currBusDate = InputoBj.getValue("CBD").trim().toString();
					_branchCode = Integer.parseInt(InputoBj.getValue("BRANCH_CODE").trim().toString());
					_billType = InputoBj.getValue("BILL_TYPE").trim().toString();
					if (String.valueOf(_ibill_TNOMEN_NUM_CHOICE).equalsIgnoreCase("C")) {
						if (_ircrYear > Integer.parseInt(_currBusDate.substring(6, 10))) {
							Resultobj.setValue(ErrorKey, "Reference Year Should be less than or equal to Current Year");
						}
					} else {
						if (_ircrYear > Integer.parseInt(getFinYear(_currBusDate))) {
							Resultobj.setValue(ErrorKey, "Reference Year Should be less than or equal to  Financial Year");
						}
					}

				}

			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in ibillYearkeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	// Changes P.Subramani-Chn-08/04/2008 End

	// *********************************************************************************************************
	/*
	 * Input - Key =IBILL_BRN_CODE Key =IBILL_BILL_TYPE key=IBILL_BILL_YEAR
	 * key=IBILL_BILL_SL key=OPTION
	 * 
	 * 
	 * Output : Error Message - Key = ErrorMsg
	 * 
	 * 
	 */

	public DTObject ibillTranSerkeypress1(DTObject InputoBj) {
		try {
			int _ibillSer = 0;
			int _ibill_year = 0;
			String _ibill_type = "";
			int _brn_Code = 0;
			String _Option = "";

			if (InputoBj.getValue("IBILL_BILL_SL").trim().equalsIgnoreCase("")) {
				_ibillSer = 0;
			} else {
				_ibillSer = Integer.parseInt(InputoBj.getValue("IBILL_BILL_SL").trim().toString());
			}
			Init_ResultObj(InputoBj);
			if (!String.valueOf(_ibillSer).trim().equalsIgnoreCase("")) {
				if (_ibillSer == 0)
					if ((InputoBj.containsKey("IBILL_BILL_SL") == true) && (InputoBj.getValue("IBILL_BILL_SL").trim().equalsIgnoreCase("")))
						Resultobj.setValue(ErrorKey, BLANK_CHECK);
					else
						Resultobj.setValue(ErrorKey, ZERO_CHECK);
			}
			if (Check_Result_Status()) {
				_ibill_year = Integer.parseInt(InputoBj.getValue("IBILL_BILL_YEAR").trim().toString());
				_ibill_type = InputoBj.getValue("IBILL_BILL_TYPE").trim().toString();
				_brn_Code = Integer.parseInt(InputoBj.getValue("IBILL_BRN_CODE").trim().toString());
				_Option = InputoBj.getValue("OPTION").trim().toString();
				if ((!String.valueOf(_ibillSer).trim().equalsIgnoreCase("")) && (!String.valueOf(_ibillSer).trim().equalsIgnoreCase(""))) {
					if (_ibillSer == 0)
						if ((InputoBj.containsKey("IBILL_BILL_SL") == true) && (InputoBj.getValue("IBILL_BRN_CODE").trim().equalsIgnoreCase("")))
							Resultobj.setValue(ErrorKey, BLANK_CHECK);
						else
							Resultobj.setValue(ErrorKey, ZERO_CHECK);
				}
				if (String.valueOf(_ibill_type).trim().equalsIgnoreCase("")) {
					Resultobj.setValue(ErrorKey, BLANK_CHECK);
				}
				if (Check_Result_Status()) {
					// Changes P.Subramani-Chn-06/08/2008 Beg
					_QueryStr = "SELECT IBILL_ENTD_BY, IBILL_ENTD_ON FROM IBILL WHERE IBILL_BRN_CODE = ? AND IBILL_BILL_TYPE=? AND IBILL_BILL_YEAR=? AND IBILL_BILL_SL=?";
					Set_preparedStatement(_QueryStr);
					_pstmt.setInt(1, _brn_Code);
					_pstmt.setString(2, _ibill_type);
					_pstmt.setInt(3, _ibill_year);
					_pstmt.setInt(4, _ibillSer);
					Resultobj = Get_Value_From_Main("IBILL");
					if (Check_Result_Status()) {
						if (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowNotPresent)) {
							Resultobj.setValue(ErrorKey, "Record Does Not Exist");
						}

					}
					// Changes P.Subramani-Chn-06/08/2008 End
				}
			}
		}

		catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in ibillTranSerkeypress1");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************

	// *********************************************************************************************************
	/*
	 * Method Name - oremTypekeypress
	 * 
	 * Input - Key =OREM_TYPE Output : Error Message - Key = ErrorMsg Key =
	 * REMCD_REMIT_TYPE Key = REMCD_TRAN_NUM_YEAR_FLG
	 */

	public DTObject oremTypekeypress(DTObject InputoBj) {
		try {
			String _oremType = "";
			String _remcdLocalForeign = "";
			String _remitType = "";
			String _remitNumyearflr = "";
			{
				_oremType = InputoBj.getValue("OREM_TYPE").trim().toString();
			}
			Init_ResultObj(InputoBj);
			if (String.valueOf(_oremType).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (Check_Result_Status()) {
				ddpoval = new DDPOValidator();
				dtobj.clearMap();
				dtobj.setValue("REMCD_REMIT_CODE", _oremType);
				dtobj.setValue(FetchReq, "true");
				dtobj.setValue("FetchColumns", "REMCD_LOCAL_FOREIGN,REMCD_REMIT_TYPE,REMCD_TRAN_NUM_YEAR_FLG");
				Resultobj = ddpoval.valremcd(dtobj);

				if (Check_Result_Status()) {
					_remcdLocalForeign = Resultobj.getValue("REMCD_LOCAL_FOREIGN");
					_remitType = Resultobj.getValue("REMCD_REMIT_TYPE");
					_remitNumyearflr = Resultobj.getValue("REMCD_TRAN_NUM_YEAR_FLG");

					if (_remcdLocalForeign != null) {
						if (_remcdLocalForeign.equalsIgnoreCase("L")) {
							Resultobj.setValue(ErrorKey, "Remittance Code should be of Foreign Remittance");
						}
					}

					if (Check_Result_Status()) {
						if (_remitType != null) {
							if (_remitType.equalsIgnoreCase("TC")) {
								Resultobj.setValue(ErrorKey, "Travelers Cheque Transaction Not Allowed");
							}
						}

					}

				}
			}
			if (Check_Result_Status()) {
				Resultobj.setValue("REMCD_TRAN_NUM_YEAR_FLG", _remitNumyearflr);
				Resultobj.setValue(ErrorKey, "");
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in oremTypekeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************

	// ******************************************************************************************************************
	/*
	 * Input : orem Year - Key = OREM_YEAR
	 * 
	 * 
	 * Output : Error Message - Key = ErrorMsg
	 * 
	 */
	// ******************************************************************************************************************
	public DTObject oremYearkeypress(DTObject InputoBj) {
		try {
			int OremYear = 0;

			if (InputoBj.getValue("OREM_YEAR").trim().equalsIgnoreCase("")) {
				OremYear = 0;
			} else {
				OremYear = Integer.parseInt(InputoBj.getValue("OREM_YEAR").trim().toString());
			}
			Init_ResultObj(InputoBj);
			if (String.valueOf(OremYear).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (!String.valueOf(OremYear).trim().equalsIgnoreCase("")) {
				if (OremYear == 0)
					if ((InputoBj.containsKey("OREM_YEAR") == true) && (InputoBj.getValue("OREM_YEAR").equalsIgnoreCase("")))
						Resultobj.setValue(ErrorKey, BLANK_CHECK);
					else
						Resultobj.setValue(ErrorKey, ZERO_CHECK);
			}
			if (Check_Result_Status()) {
				if (!(OremYear >= 1900)) {
					Resultobj.setValue(ErrorKey, " Year should be greater than or equals to 1900");
				}
			}

		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in oremYearkeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	/*
	 * Method Name - oremSlkeypress
	 * 
	 * Input - Key =OREM_SL Key =OREM_YEAR Key =OREM_BRN Key =OREM_TYPE Output :
	 * Error Message - Key = ErrorMsg
	 */

	public DTObject oremSlkeypress(DTObject InputoBj) {
		try {
			int _oremSl = 0;
			int _orBrnCode = 0;
			int _orYear = 0;
			String _orRemCode = "";
			String date = "";
			String ddno = "";
			String remcurr = "";
			String remamt = "";
			String applcode = "";
			String custcode = "";
			if (InputoBj.getValue("OREM_SL").trim().equalsIgnoreCase("")) {
				_oremSl = 0;
			} else {
				_oremSl = Integer.parseInt(InputoBj.getValue("OREM_SL").trim().toString());
			}
			_orBrnCode = Integer.parseInt(InputoBj.getValue("OREM_BRN").trim().toString());
			_orRemCode = InputoBj.getValue("OREM_TYPE").trim().toString();
			_orYear = Integer.parseInt(InputoBj.getValue("OREM_YEAR").trim().toString());
			custcode = InputoBj.getValue("CUST_CODE").trim().toString();
			Init_ResultObj(InputoBj);
			if (!String.valueOf(_oremSl).trim().equalsIgnoreCase("")) {
				if (_oremSl == 0)
					if ((InputoBj.containsKey("OREM_SL") == true) && (InputoBj.getValue("OREM_SL").trim().equalsIgnoreCase("")))
						Resultobj.setValue(ErrorKey, BLANK_CHECK);
					else
						Resultobj.setValue(ErrorKey, ZERO_CHECK);
			}
			if (Check_Result_Status()) {
				_QueryStr = "SELECT OREM_APPL_CODE,OREM_TRAN_DATE,OREM_INST_NUM,OREM_REMITTANCE_CURR,OREM_REMITTANCE_AMT FROM OUTREM WHERE OREM_BRN = ? AND OREM_TYPE=? AND OREM_YEAR=? AND OREM_SL=? ";
				Set_preparedStatement(_QueryStr);
				_pstmt.setInt(1, _orBrnCode);
				_pstmt.setString(2, _orRemCode);
				_pstmt.setInt(3, _orYear);
				_pstmt.setInt(4, _oremSl);
				Get_Value_From_Main("OUTREM");

				if (Check_Result_Status()) {
					applcode = Resultobj.getValue("OREM_APPL_CODE");
					date = Resultobj.getValue("OREM_TRAN_DATE");
					ddno = Resultobj.getValue("OREM_INST_NUM");
					remcurr = Resultobj.getValue("OREM_REMITTANCE_CURR");
					remamt = Resultobj.getValue("OREM_REMITTANCE_AMT");

					if (!custcode.equalsIgnoreCase(applcode)) {
						Resultobj.setValue(ErrorKey, "Remitter and Customer Should be same");
					}

				}
			}

			if (Check_Result_Status()) {
				Resultobj.setValue("OREM_TRAN_DATE", date);
				Resultobj.setValue("OREM_INST_NUM", ddno);
				Resultobj.setValue("OREM_REMITTANCE_CURR", remcurr);
				Resultobj.setValue("OREM_REMITTANCE_AMT", remamt);
			}

		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in oremSlkeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	// S.Suresh Babu Add 01-10-2009 Beg
	// *********************************************************************************************************
	/*
	 * Method Name - fetchconvrate Input - Key =FOR_CURR Key =BASE_CURR Key
	 * =BILL_AMT Key =TOT_EQU_AMT
	 * 
	 * Output: Error Message - Key = ErrorMsg
	 */
	// *********************************************************************************************************
	public DTObject fetchconvrate(DTObject InputoBj) {
		try {
			String lc_curr = "";
			String base_curr = "";
			String tot_eqv_amt = "";
			String amt_conv = "";

			if (InputoBj.getValue("FOR_CURR").trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (InputoBj.getValue("BASE_CURR").trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (InputoBj.getValue("TOT_EQU_AMT").trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (InputoBj.getValue("BILL_AMT").trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			} else {
				lc_curr = InputoBj.getValue("FOR_CURR").trim().toString();
				base_curr = InputoBj.getValue("BASE_CURR").trim().toString();
				tot_eqv_amt = InputoBj.getValue("TOT_EQU_AMT").trim().toString();
				amt_conv = InputoBj.getValue("BILL_AMT").trim().toString();
			}
			Init_ResultObj(InputoBj);
			if (Check_Result_Status()) {
				CommonValidator cv = new CommonValidator();
				DTObject dtoinput = new DTObject();
				dtoinput.setValue("FOR_CURR", lc_curr);
				dtoinput.setValue("AGNST_CURR", base_curr);
				dtoinput.setValue("AMT_AGNST_CURR", tot_eqv_amt);
				dtoinput.setValue("AMT_FOR_CURR", amt_conv);
				Resultobj = cv.calConvRate(dtoinput);
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in fetchconvrate");
		}
		return Resultobj.copyofDTO();
	}

	// S.Suresh Babu Add 24-09-2009 End
	// *********************************************************************************************************

	// CHN-PRASHANTH-31-08-2017-TRSYCOMP_CHANGES-ENDS

	public DTObject getConvRate(DTObject InputoBj) {
		String rateType = InputoBj.getValue("RATE_TYPE").trim().toString();
		String _crconvenCurrCode1 = InputoBj.getValue("CRCONVEN_CURR_CODE1").trim().toString();
		String _crconvenCurrCode2 = InputoBj.getValue("CRCONVEN_CURR_CODE2").trim().toString();
		String _rateTypeFlag = InputoBj.getValue("RATE_FLAG").trim().toString();
		double w_conv_rate = 0;
		try {
			_QueryStr = "SELECT CRATES_PUR_RATE,CRATES_SEL_RATE,CRATES_MID_RATE FROM CRATES WHERE CRATES_TYPE_CODE=? AND CRATES_FOR_CURR=? AND CRATES_AGNST_CURR=? ";
			Set_preparedStatement(_QueryStr);
			_pstmt.setString(1, rateType);
			_pstmt.setString(2, _crconvenCurrCode1);
			_pstmt.setString(3, _crconvenCurrCode2);
			Get_Value_From_Main("CRATES");
			if (Check_Result_Status() == true) {
				if (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowNotPresent)) {
					Resultobj.setValue(ErrorKey, "Conversion Rate details not specified");
				} else {
					if (_rateTypeFlag.trim().toString().equalsIgnoreCase("P")) {
						w_conv_rate = java.lang.Double.parseDouble(Resultobj.getValue("CRATES_PUR_RATE"));
					}
					if (_rateTypeFlag.trim().toString().equalsIgnoreCase("S")) {
						w_conv_rate = java.lang.Double.parseDouble(Resultobj.getValue("CRATES_SEL_RATE"));
					}
					if (_rateTypeFlag.trim().toString().equalsIgnoreCase("M")) {
						w_conv_rate = java.lang.Double.parseDouble(Resultobj.getValue("CRATES_MID_RATE"));
					}
				}
			}
			if (Check_Result_Status() == true) {
				Resultobj.setValue("CONV_RATES", String.valueOf(w_conv_rate));
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in calculation of Conv Rate");
		}
		return Resultobj.copyofDTO();
	}

	// CHN-PRASHANTH-31-08-2017-TRSYCOMP_CHANGES-ENDS

	public DTObject getOLCConvRate(DTObject InputoBj) {
		String brnCode = InputoBj.getValue("OLC_BRN_CODE").trim().toString();
		String olcType = InputoBj.getValue("OLC_LC_TYPE").trim().toString();
		String olcYear = InputoBj.getValue("OLC_LC_YEAR").trim().toString();
		String olcSerial = InputoBj.getValue("OLC_LC_SL").trim().toString();
		double w_conv_rate = 0;
		try {
			_QueryStr = "SELECT TRANCRATES_CONV_RATE FROM TRANCRATES T,OLC O WHERE T.TRANCRATES_SL=O.TRANCRATES_RATE_SL AND O.OLC_BRN_CODE=? AND O.OLC_LC_TYPE=? AND O.OLC_LC_YEAR=? AND O.OLC_LC_SL=?";

			Set_preparedStatement(_QueryStr);
			_pstmt.setString(1, brnCode);
			_pstmt.setString(2, olcType);
			_pstmt.setString(3, olcYear);
			_pstmt.setString(4, olcSerial);
			Get_Value_From_Main("TRANCRATES");
			if (Check_Result_Status() == true) {
				if (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowNotPresent)) {
					Resultobj.setValue(ErrorKey, "OLC/TRANCRATES details not specified");
				} else {
					w_conv_rate = java.lang.Double.parseDouble(Resultobj.getValue("TRANCRATES_CONV_RATE"));
				}
			}
			if (Check_Result_Status() == true) {
				Resultobj.setValue("TRANCRATES_CONV_RATE", String.valueOf(w_conv_rate));
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in calculation of Conv Rate");
		}
		return Resultobj.copyofDTO();
	}

	// CHANGES IN EIBILL ON 18-MAY-2018 START
	public DTObject ibillForeignBankRefNumber(DTObject InputoBj) {
		try {

			if (InputoBj.getValue("FOREIGN_BANK_REF_NUMBER").trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			} else {
				Resultobj.setValue(ErrorKey, "");
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in ibillForeignBankRefNumber");
		}
		return Resultobj.copyofDTO();
	}

	// CHANGES IN EIBILL ON 18-MAY-2018 END
	// ******************************************************************************************
	// changes in eibill on 11-Jun-2018 start
	public DTObject Applicant_BankType_Keypress(DTObject InputoBj) {
		try {
			Resultobj.clearMap();
			Resultobj = swval.ApplicantBankType(InputoBj);
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in Applicant_BankType_Keypress");
		}
		return Resultobj.copyofDTO();
	}

	// ******************************************************************************************
	public DTObject ApplicantBankBicKeypress(DTObject InputoBj) {
		try {
			Resultobj.clearMap();
			Resultobj = swval.ApplicantBankBic(InputoBj);
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in ApplicantBankBicKeypress");
		}
		return Resultobj.copyofDTO();
	}

	// ******************************************************************************************
	public DTObject ApplicantBankNameKeypress(DTObject InputoBj) {
		try {
			Resultobj.clearMap();
			Resultobj = swval.ApplicantBankName(InputoBj);
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in ApplicantBankNameKeypress");
		}
		return Resultobj.copyofDTO();
	}

	// ******************************************************************************************
	public DTObject ApplicantBankBrachCodeKeypress(DTObject InputoBj) {
		try {
			Resultobj.clearMap();
			Resultobj = swval.ApplicantBankBranch(InputoBj);
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in ApplicantBankBrachCodeKeypress");
		}
		return Resultobj.copyofDTO();
	}

	// ******************************************************************************************
	public DTObject ApplicantBankAddressKeypress(DTObject InputoBj) {
		try {
			Resultobj.clearMap();
			Resultobj = swval.ApplicantBankAddress(InputoBj);
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in ApplicantBankAddressKeypress");
		}
		return Resultobj.copyofDTO();
	}

	// ******************************************************************************************
	public DTObject ApplicantBankCntryCodeKeypress(DTObject InputoBj) {
		try {
			Resultobj.clearMap();
			Resultobj = swval.ApplicantBankCountryCode(InputoBj);
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in ApplicantBankCntryCodeKeypress");
		}
		return Resultobj.copyofDTO();
	}

	// ******************************************************************************************
	public DTObject ApplicantRoutingIdKeypress(DTObject InputoBj) {
		try {
			Resultobj.clearMap();
			Resultobj = swval.ApplicantAccountNumber(InputoBj);
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in ApplicantRoutingIdKeypress");
		}
		return Resultobj.copyofDTO();
	}

	// ******************************************************************************************
	// changes in eibill on 11-Jun-2018 end

	public DTObject exclude_special_char(String inputChar) {
		String outputChar = "";
		try {
			Resultobj.clearMap();
			DTObject dto = new DTObject();
			dto.clearMap();
			dto.setValue("INPUT", inputChar);
			Resultobj = swval.Special_Char_Validation(dto);
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in exclude_special_char");
		}
		return Resultobj.copyofDTO();
	}

	// ******************************************************************************************
	// changes in eibill on 28-Jun-2018
	public DTObject SwiftMessageGenerationRequired(DTObject Inputobj) {
		try {
			Resultobj.clearMap();
			Resultobj = swval.Swift734Generation(Inputobj);
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in SwiftMessageGenerationRequired");
		}
		return Resultobj.copyofDTO();
	}

	// ******************************************************************************************

	// COMMENTTED BY PRASHANTH ON 01 AUGUST 2019
	/*
	 * public DTObject TBMLKeypress(DTObject InputoBj) {
	 * 
	 * try { double payamt = Double.parseDouble(InputoBj.getValue("BILL_AMT"));
	 * BigDecimal payamt1=new BigDecimal(InputoBj.getValue("BILL_AMT")); String
	 * cbd = InputoBj.getValue("CBD"); // ADDED BY PRASHANTH FOR TBML ON 29
	 * AUGUST 2018 String alertMessage = ""; int samepaywithin = 0; String
	 * txnLimit = ""; String roundallowed = ""; String benefcode = ""; String
	 * threshAmt = ""; String error1= ""; //06 dec 2018 by prashanth int
	 * brncode; String billType; int billYear; int billSl=0; String error2= "";
	 * int cutomerNum;
	 * cutomerNum=Integer.parseInt(InputoBj.getValue("CUST_NUM")); String
	 * mode=""; mode=InputoBj.getValue("MODE"); String billCurr = ""; billCurr =
	 * InputoBj.getValue("BILLCCY");
	 * brncode=Integer.parseInt(InputoBj.getValue("BRNCODE"));
	 * billType=InputoBj.getValue("BILLTYPE");
	 * billYear=Integer.parseInt(InputoBj.getValue("BILLYEAR"));
	 * if(!InputoBj.getValue("BILLSL").equals("")){
	 * billSl=Integer.parseInt(InputoBj.getValue("BILLSL")); } //06 dec 2018 by
	 * prashanth if (Check_Result_Status()) { dtobj.clearMap();
	 * dtobj.setValue(FetchReq, "true"); dtobj.setValue("FetchColumns",
	 * "TBMLIB_CHK_FOR_PAY_BEYOND,TBMLIB_RPTD_PAYTO_SAME_EXP_WN,TBMLIB_CHK_SUBPAY_OF_RND_FIG,TBMLIB_TXN_LIM_FOR_FT_IMP_USD");
	 * Resultobj = tbmlval.getTBMLConfigDetailsIBIL(dtobj); }
	 * 
	 * if (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowPresent)) {
	 * samepaywithin =
	 * Integer.parseInt(Resultobj.getValue("TBMLIB_CHK_FOR_PAY_BEYOND"));
	 * txnLimit = Resultobj.getValue("TBMLIB_TXN_LIM_FOR_FT_IMP_USD");
	 * roundallowed = Resultobj.getValue("TBMLIB_CHK_SUBPAY_OF_RND_FIG");
	 * threshAmt = Resultobj.getValue("TBMLIB_TXN_LIM_FOR_FT_IMP_USD");
	 * 
	 * if (Check_Result_Status() && roundallowed.equals("1")) { //payamt =
	 * payamt / 10; // payamt = payamt / 10;
	 * 
	 * //CHANGED 13 DEC 2018
	 * 
	 * BigDecimal x= BigDecimal.valueOf(payamt); BigDecimal y = x.divide(new
	 * BigDecimal("10")); BigDecimal z = y.divide(new BigDecimal("10"));
	 * BigDecimal amt[] =z.divideAndRemainder(new BigDecimal("1")); BigDecimal
	 * amtValue=amt[1];
	 * 
	 *  // payamt = payamt % 1; if (amtValue.compareTo(BigDecimal.ZERO)==0) {
	 * alertMessage = alertMessage.concat("\\n"); alertMessage =
	 * alertMessage.concat("Payment value in round figures"); error1="Payment
	 * value in round figures"; } }
	 * 
	 * //06 dec 2018 by prashanth if(mode.equals("A")){ _QueryStr = "SELECT
	 * COUNT(1)COUNT FROM IBILL O WHERE O.IBILL_CUST_NO=?"; }else{ _QueryStr =
	 * "SELECT COUNT(1)COUNT FROM IBILL O WHERE O.IBILL_CUST_NO<>? AND
	 * O.IBILL_BRN_CODE=? AND O.IBILL_BILL_TYPE=? AND O.IBILL_BILL_YEAR=? AND
	 * O.IBILL_BILL_SL=?"; } Set_preparedStatement(_QueryStr); _pstmt.setInt(1,
	 * cutomerNum); if(mode.equals("M")){ _pstmt.setInt(2, brncode);
	 * _pstmt.setString(3, billType); _pstmt.setInt(4, billYear);
	 * _pstmt.setInt(5, billSl); }
	 * 
	 * Get_Value_From_Main("IBILL"); //ADDED BY PRASHANTH ON 24 JAN 2019 int
	 * count=Integer.parseInt(Resultobj.getValue("COUNT")); //if(count>0 &&
	 * mode.equals("M"))
	 * 
	 * //{ _QueryStr = "SELECT COUNT(1)COUNT FROM IBILL O WHERE
	 * O.IBILL_CUST_NO=?"; Set_preparedStatement(_QueryStr); _pstmt.setInt(1,
	 * cutomerNum); Get_Value_From_Main("IBILL"); int
	 * count2=Integer.parseInt(Resultobj.getValue("COUNT")); // } //ADDED BY
	 * PRASHANTH ON 24 JAN 2019 if(mode.equals("M")) { if(count==1 &&
	 * count2==0){ count=0; count2=0; } else if(count==0&& count2==1){ count=0;
	 * count2=0; } }
	 * 
	 * if (Check_Result_Status() && count==0 && count2==0){
	 * 
	 * String payamtinbasecurrency = ""; String threshAmtEqualentInr = "";
	 * 
	 * 
	 * DTObject outputDTO = new DTObject(); InputoBj.setValue("DEP_CURR_CODE",
	 * billCurr); InputoBj.setValue("BASE_CURRENCY", "INR");
	 * InputoBj.setValue("PBDCONT_AC_DEP_AMT",String.valueOf(threshAmt));
	 * InputoBj.setValue("CURR_BUSS_DATE", cbd);
	 * 
	 * outputDTO = CurrConvertionKeypress(InputoBj); threshAmtEqualentInr =
	 * outputDTO.getValue("PBDCONT_LOCAL_CURRNCY");
	 * 
	 * 
	 * 
	 * 
	 * 
	 * DTObject outputDTO2 = new DTObject(); InputoBj.setValue("DEP_CURR_CODE",
	 * billCurr); InputoBj.setValue("BASE_CURRENCY", "INR");
	 * InputoBj.setValue("PBDCONT_AC_DEP_AMT",String.valueOf(payamt1));
	 * InputoBj.setValue("CURR_BUSS_DATE", cbd);
	 * 
	 * outputDTO2 = CurrConvertionKeypress(InputoBj); payamtinbasecurrency =
	 * outputDTO2.getValue("PBDCONT_LOCAL_CURRNCY");
	 * 
	 * 
	 * 
	 * BigDecimal payamtinbasecurrencyBD= new BigDecimal(payamtinbasecurrency);
	 * BigDecimal threshAmtEqualentInrBD= new BigDecimal(threshAmtEqualentInr);
	 * 
	 * if(payamtinbasecurrencyBD.compareTo(threshAmtEqualentInrBD) == 1) {
	 * alertMessage = alertMessage.concat("\\n"); alertMessage =
	 * alertMessage.concat("First time import exceeds threshold >
	 * "+threshAmt+"USD"); error2="First time import exceeds threshold >
	 * "+threshAmt+"USD"; } } //06 dec 2018 by prashanth
	 * 
	 * 
	 * 
	 * 
	 *  } Resultobj.setValue("ALERT_MESSAGE", alertMessage);
	 * Resultobj.setValue("ERROR_1", error1); Resultobj.setValue("ERROR_2",
	 * error2); // ADDED BY PRASHANTH FOR TBML ON 29 AUGUST 2018 } catch
	 * (Exception e) { Resultobj.setValue(ErrorKey, "Error in
	 * ibillSerialkeypress"); } return Resultobj.copyofDTO(); }
	 * 
	 * //ADDED ON 07 DECEMBER 2018 BY PRASHANTH
	 */
	// COMMENTTED BY PRASHANTH ON 01 AUGUST 2019
	public DTObject CurrConvertionKeypress(DTObject InputoBj) {

		try {
			double bcamt = 0;
			String depcurr = "";
			String basecurr = "";
			double depamount = 0;
			String _cbd = "";
			String _rateType = "";

			depcurr = InputoBj.getValue("DEP_CURR_CODE").trim().toString();
			basecurr = InputoBj.getValue("BASE_CURRENCY").trim().toString();
			depamount = Double.parseDouble(InputoBj.getValue("PBDCONT_AC_DEP_AMT").trim().toString());
			_cbd = InputoBj.getValue("CURR_BUSS_DATE").trim().toString();

			openConnection();
			_pstmt = connDB.prepareStatement("SELECT CMNPM_MID_RATE_TYPE_PUR  FROM CMNPARAM");
			ResultSet _rsp = _pstmt.executeQuery();
			if (_rsp.next()) {
				_rateType = _rsp.getString("CMNPM_MID_RATE_TYPE_PUR");
			} else
				Resultobj.setValue(ErrorKey, "Rate type not defined for currency conversion");

			CallableStatement _cstmt = connDB.prepareCall("CALL SP_CALCAGNAMT(?,?,?,?,TO_DATE(?,'DD-MM-YYYY'),?,?,?,?,?)");
			_cstmt.setString(1, depcurr);
			_cstmt.setString(2, basecurr);
			_cstmt.setBigDecimal(3, new BigDecimal(depamount));
			// _cstmt.setDouble(3, depamount);
			_cstmt.setString(4, "M");
			_cstmt.setString(5, _cbd);
			_cstmt.setString(6, "1");
			_cstmt.setString(7, _rateType);
			_cstmt.setString(8, "");
			_cstmt.registerOutParameter(9, Types.DOUBLE);
			_cstmt.registerOutParameter(10, Types.DOUBLE);
			_cstmt.execute();
			bcamt = _cstmt.getDouble(9);
			closeConnection();
			Resultobj.setValue("PBDCONT_LOCAL_CURRNCY", String.valueOf(FormatDoubleValue(bcamt, BASECURRDECLENGTH)));
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in CurrConvertionKeypress");
		}

		return Resultobj.copyofDTO();
	}
	// ADDED ON 07 DECEMBER 2018 BY PRASHANTH
}
