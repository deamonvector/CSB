package panacea.OLCaction;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import panacea.common.DTObject;
import panacea.common.DateUtility;
import panacea.Validator.BranchValidator;
import panacea.Validator.ClientValidator;
import panacea.Validator.CommonValidator;
import panacea.Validator.TFMValidator;
import panacea.Validator.AccountValidator;
import panacea.Validator.LimitValidator;
import panacea.Validator.OLCValidator;
import panacea.Validator.LoansValidator;
import panacea.Validator.ProductValidator;
import panacea.Validator.cbsglobal;
import panacea.Validator.WebManager;


/*
 * Author     	: R.Muthukumaran
 * Release Date : 23-04-2007
*/

public class eolccanval extends WebManager{ 

// *********************************************************************************************************
    /*
    * Input 	: Branch Code			- 		Key = OLCCN_BRN_CODE 
    * Output	: Branch Name			-		Key = MBRN_NAME
    * 			  Error Message  		- 		Key = ErrorMsg
    */
// *********************************************************************************************************    
  
	
	
	
	public DTObject olccnBrnCodekeypress(DTObject InputoBj)
        {
        try
            {
            	int  _olccnBrnCode = 0;
                    if (InputoBj.getValue("OLCCN_BRN_CODE").trim().equalsIgnoreCase(""))
                {
                    	_olccnBrnCode = 0;
                }
                else
                {
                	_olccnBrnCode = Integer.parseInt(  InputoBj.getValue("OLCCN_BRN_CODE") .trim().toString());
                }
            Init_ResultObj(InputoBj);
                if(String.valueOf(_olccnBrnCode).trim().equalsIgnoreCase(""))
                {
                    Resultobj.setValue(ErrorKey,BLANK_CHECK);
                }
                if(Check_Result_Status())
                {
	                if(!String.valueOf(_olccnBrnCode).trim().equalsIgnoreCase(""))
	                {
	                    if(_olccnBrnCode ==0)
	                    	if(InputoBj.containsKey("OLCCN_BRN_CODE") == true && InputoBj.getValue("OLCCN_BRN_CODE").equalsIgnoreCase(""))
	                    		Resultobj.setValue(ErrorKey,BLANK_CHECK);
	                    	else
	                    		Resultobj.setValue(ErrorKey,ZERO_CHECK);
	                }
                }
                if(Check_Result_Status())
            	{
            		BranchValidator BV = new BranchValidator();
            		DTObject dtoinput = new DTObject();
            		dtoinput.setValue("MBRN_CODE",String.valueOf(_olccnBrnCode));
            		Resultobj = BV.chkBrnValid(dtoinput);
            		System.out.println("branch name="+Resultobj);
            	}
            }
        catch(Exception e)
            {
                Resultobj.setValue(ErrorKey,"Error in olccnBrnCodekeypress" );
            }
        return Resultobj.copyofDTO();
        }
	
	
	
	 // *********************************************************************************************************
    // *********************************************************************************************************
    /*
    * Input 	- 								Key =OLCCN_LC_TYPE
    * 											Key = CBD
    * Output	: Error Message  		- 		Key = ErrorMsg
    * 											Key = TNOMEN_NUM_CHOICE
    * 											Key = TNOMEN_AUTO_NUM
    * 											Key = FIN_YEAR
    * 
    */
    
    public DTObject  olccnTypekeypress(DTObject InputoBj)
        {
        try      
        {
            String  _olccnType = "";
            String finyear="";		
            String _currBusDate="";
            String _coll_prod="";
            String _prodesc="";
            
            {
            	_olccnType =   InputoBj.getValue("OLCCN_LC_TYPE") .trim().toString();
            }
           _currBusDate=InputoBj.getValue("CBD").trim().toString();
            
            Init_ResultObj(InputoBj);
            if(String.valueOf(_olccnType).trim().equalsIgnoreCase(""))
            {
                Resultobj.setValue(ErrorKey,BLANK_CHECK);
            }
            finyear=getFinYear(_currBusDate);
            if(Check_Result_Status())
            {  
            	TFMValidator tfmval = new TFMValidator();
            	DTObject dtoinput = new DTObject();
            	dtoinput.clearMap();
            	dtoinput.setValue("TNOMEN_NOMEN_CODE",_olccnType);
            	dtoinput.setValue(FetchReq,"true");
            	dtoinput.setValue("FetchColumns","TNOMEN_LC_BILL_BG,TNOMEN_IW_OW,TNOMEN_AUTO_NUM,TNOMEN_NUM_CHOICE ");
            	Resultobj=tfmval.valtnomen(dtoinput);
            	String lcBillBg=Resultobj.getValue("TNOMEN_LC_BILL_BG");
            	String lcIwOw=Resultobj.getValue("TNOMEN_IW_OW");
            	String lcautonum=Resultobj.getValue("TNOMEN_AUTO_NUM");
            	String lcnumChoice=Resultobj.getValue("TNOMEN_NUM_CHOICE");
            	
            	if(Check_Result_Status())
                {
	            	if(!lcBillBg.equalsIgnoreCase("L"))
	            	{
	            		 Resultobj.setValue(ErrorKey,"LC Type Should be Marked for Letter of Credit" );
	            	}
	            	if(Check_Result_Status())
	                {
		            	if(!lcIwOw.equalsIgnoreCase("O"))
		            	{
		            		 Resultobj.setValue(ErrorKey,"LC Type Should be Marked for Outward" );
		            	}
	                }
                 }
            	
            	if(Check_Result_Status())
         		 {
   				_QueryStr = "Select TRAC_COLL_PROD FROM TRACPARAM WHERE TRAC_NOMEN_CODE =?" ;
   				Set_preparedStatement(_QueryStr);
                   _pstmt.setString(1, _olccnType);
                   Resultobj=Get_Value_From_Main("TRACPARAM");
                   if(Check_Result_Status())
                   {
                   	 _coll_prod=Resultobj.getValue("TRAC_COLL_PROD");
                       
                   	if(Check_Result_Status())
                       {
                       	ProductValidator pv = new ProductValidator();
                       	DTObject dtoinput1 = new DTObject();
                       	dtoinput1.setValue("PRODUCT_CODE",_coll_prod);
                       	Resultobj = pv.prodValid(dtoinput1);
                       	_prodesc = Resultobj.getValue("PRODUCT_NAME");
                       	
                       }
                   }
         		 }    
            	
                if(Check_Result_Status())
                {
                	Resultobj.setValue("TNOMEN_AUTO_NUM",lcautonum);
            		Resultobj.setValue("TNOMEN_NUM_CHOICE",lcnumChoice);
            		Resultobj.setValue("FIN_YEAR",finyear);
            		Resultobj.setValue(ErrorKey,"" );
                }
             }
            Resultobj.setValue("PRODUCT_CODE",_coll_prod);
    		Resultobj.setValue("PRODUCT_NAME",_prodesc);
        }
            
        
    catch(Exception e)
        {
            Resultobj.setValue(ErrorKey,"Error in olccnTypekeypress" );
        }
    return Resultobj.copyofDTO();
        }
	

    // *********************************************************************************************************
    // *********************************************************************************************************
    /*
    * Input 	- 						        Key =OLCCN_LC_YEAR
    * 											     TNOMEN_NUM_CHOICE
    * 											     CBD
    * 											
    * 			
    * Output	: Error Message  		- 		Key = ErrorMsg
    * 											Key = FIN_YEAR
    */
    
    public DTObject olccnYearkeypress(DTObject InputoBj)
        {
        try
            {
                int  _olccnYear = 0;
                String _tenomen_num_choice="";
                String _currBusDate="";
                String _finYear="";
                
                    if (InputoBj.getValue("OLCCN_LC_YEAR").trim().equalsIgnoreCase(""))
                {
                    	_olccnYear = 0;
                }
                else
                {
                	_olccnYear = Integer.parseInt(  InputoBj.getValue("OLCCN_LC_YEAR") .trim().toString());
                    _tenomen_num_choice=InputoBj.getValue("TNOMEN_NUM_CHOICE") .trim().toString();
                    _currBusDate=InputoBj.getValue("CBD") .trim().toString();
                    
                }
                    _finYear = getFinYear(_currBusDate);      
                    
            Init_ResultObj(InputoBj);
            
            
                if(String.valueOf(_olccnYear).trim().equalsIgnoreCase(""))
                {
                    Resultobj.setValue(ErrorKey,BLANK_CHECK);
                }
                
                if(Check_Result_Status())
                {
                	if((_tenomen_num_choice.equalsIgnoreCase("C"))&&(_olccnYear>Integer.parseInt(_currBusDate.substring(6,10))))
                	 {
                		Resultobj.setValue(ErrorKey,"Reference Year Should be <= Current Year");
                	 }
                	
                	else if((_tenomen_num_choice.equalsIgnoreCase("F"))&&(_olccnYear>Integer.parseInt(getFinYear(_currBusDate))))
                       	 {
                       		Resultobj.setValue(ErrorKey,"Reference Year Should be <= Current Year");
                       	 }
                	 if(Check_Result_Status())
                     {
                     	 Resultobj.setValue(ErrorKey,"" );
                     	Resultobj.setValue("FIN_YEAR",_finYear);
                     }
                	
                }
                if(!String.valueOf(_olccnYear).trim().equalsIgnoreCase(""))
	             {
	                 if(_olccnYear==0)
	                     if ((InputoBj.containsKey("OLCCN_LC_YEAR") == true) && (InputoBj.getValue("OLCCN_LC_YEAR").equalsIgnoreCase("")))
	                         Resultobj.setValue(ErrorKey,BLANK_CHECK);
	                     else
	                     Resultobj.setValue(ErrorKey,ZERO_CHECK);
	             }

                if(Check_Result_Status())
	             {
	             	if(!(_olccnYear >= 1900))
	             	{
	             		Resultobj.setValue(ErrorKey,"For Year should be greater than or equals to 1900");
	             	}
		        } 

            }
        catch(Exception e)
            {
                Resultobj.setValue(ErrorKey,"Error in olccnYearkeypress" );
            }
        return Resultobj.copyofDTO();
        }
    
	  // *********************************************************************************************************
    // *********************************************************************************************************
    /*
    * Input 							
    * 						 	        -   Key = OLCCN_BRN_CODE
    * 			      			        -	Key = OLCCN_LC_TYPE
    * 			  			            -	Key = OLCCN_LC_YEAR
    *										key = OLCCN_LC_SL
    * 										key = USEROPTION
    * 										 
    * Output	: Error Message  		- 	 Key = ErrorMsg
    * 										  
    * 
    */
    
    public DTObject olccnSlkeypress(DTObject InputoBj)
        {
        try
            {
                int  _olcnn_Sl = 0;
                int   _branch_Code = 0;
                String  _olccn_Type = "";
                int  _olccn_Year = 0;
                String _olcSanctionedOnDate="";
                String _olcSanctionedODAySl="";
                String _olcDate="";
                String _olcCustNum="";
                String _olcCustName="";
                String _olcBeniefDesc="";
                String _olcLcposdevallwd="";
                String _olcPriceTerms="";
                String _olcCurrCode="";
                String _olcBnefCode="";
                String _olcLcAmount="";
                String _olcTotLiabBaseCurr="";
                String _olcLatestDateShip="";
                String _olcPerInsValCvd="";
                String _olcBalanceAmount="";
                String useroption="";
                String _lcpscustliabaccnum="";
                String _lcpsprodcode="";
                String  _acntscurrcode="";
                String _max_amdsl="";
//Changes P.Subramani  chn-03/01/2008 Beg    
                double _sumuseintamt=0.0;
                
                String baseCurrency=get_base_curr_code(); 
                double _lctotamt=0.0;
                double _lctotamt1=0.0;
                double _lctotamt2=0.0;
                double _lctotamt3=0.0;
                String _olcconvratetobasecurr="";
                String _olcaconvratetobasecurr="";
                long	_declength=0;
                long	_declength1=0;
                long	_declength2=0;
                double W_cancelled_amount=0.0;
                String _olcaamendedamt="";
                String _olcaamendentydate="";
                String _olcaamendedlastshpmnt="";
                String _olcaamendeddateneg="";
                String _olcaamendeddevalled="";
                //Changes P.Subramani-Chn-31/03/2008 Beg
                String _olcdevamt="";
                String _olcaamendeddevamt="";
                //Changes P.Subramani-Chn-31/03/2008 End
                String _olcRefNum="";
                String _olcLatestDateNegotiation="";
                String _olcbankcode="";
                String _olcbrncode="";
                String _olccncantamt="";
                double _lcliabrevduetocurrval=0.0;
              
                double _againstamt=0.0;
                double _againstamt1=0.0;
                double _againstamt2=0.0;
                
                String  _currencyName="";
                String _olcbankName=""; 
                String _olcbranchkName="";
                String _olccnauth="";
                String _olccnrej="";
                String _intAccNum="";
              //ADDED BY SANJAY ON 08 AUGUST 2019
        		String olcAmdFinalTotalAmt = "";
        		String olcAmdFinalConvAmt="";
        		//ADDED BY SANJAY ON 08 AUGUST 2019
        		
        		String olcContraAmt="";
                
                if (InputoBj.getValue("OLCCN_LC_SL").trim().equalsIgnoreCase(""))
                {
                    	_olcnn_Sl = 0;
                }
                else
                {
                	 _branch_Code =  Integer.parseInt(InputoBj.getValue("OLCCN_BRN_CODE") .trim().toString());
                	 _olccn_Type     =   InputoBj.getValue("OLCCN_LC_TYPE") .trim().toString();
                	 _olccn_Year     =  Integer.parseInt(InputoBj.getValue("OLCCN_LC_YEAR") .trim().toString());
                	 _olcnn_Sl     = Integer.parseInt(  InputoBj.getValue("OLCCN_LC_SL") .trim().toString());
                	 useroption =    InputoBj.getValue("USEROPTION") .trim().toString();
                }  
                    
                    Init_ResultObj(InputoBj);
                    if(!String.valueOf(_branch_Code).trim().equalsIgnoreCase(""))
                    {
                    	if(_branch_Code==0) 
                    		if ((InputoBj.containsKey("OLCCN_BRN_CODE") == true) && (InputoBj.getValue("OLCCN_BRN_CODE").trim().equalsIgnoreCase("")))
                    			Resultobj.setValue(ErrorKey,BLANK_CHECK);
                            else
                            Resultobj.setValue(ErrorKey,ZERO_CHECK);
                    }    
           
                    if(String.valueOf(_olccn_Type).trim().equalsIgnoreCase(""))
                    {
                        Resultobj.setValue(ErrorKey,BLANK_CHECK);
                    }
                if(!String.valueOf(_olccn_Year).trim().equalsIgnoreCase(""))
                {
                	if(_olccn_Year==0) 
                		if ((InputoBj.containsKey("OLCCN_LC_TYPE") == true) && (InputoBj.getValue("OLCCN_LC_TYPE").trim().equalsIgnoreCase("")))
                			Resultobj.setValue(ErrorKey,BLANK_CHECK);
                        else
                        Resultobj.setValue(ErrorKey,ZERO_CHECK);
                }
                if(!String.valueOf(_olcnn_Sl).trim().equalsIgnoreCase(""))
                {
                	if(_olcnn_Sl==0) 
                		if ((InputoBj.containsKey("OLCCN_LC_SL") == true) && (InputoBj.getValue("OLCCN_LC_SL").trim().equalsIgnoreCase("")))
                			Resultobj.setValue(ErrorKey,BLANK_CHECK);
                        else
                        Resultobj.setValue(ErrorKey,ZERO_CHECK);
                }
                if(String.valueOf(useroption).trim().equalsIgnoreCase(""))
                {
                    Resultobj.setValue(ErrorKey,BLANK_CHECK);
                }
                
                
                
                if(Check_Result_Status())
                {
                   DTObject dtoinput = new DTObject();
                   OLCValidator olcval=new OLCValidator();
                   dtoinput.clearMap();
                   dtoinput.setValue("OLC_BRN_CODE",String.valueOf(_branch_Code));
                   dtoinput.setValue("OLC_LC_TYPE",String.valueOf(_olccn_Type));
                   dtoinput.setValue("OLC_LC_YEAR",String.valueOf(_olccn_Year));
                   dtoinput.setValue("OLC_LC_SL",String.valueOf(_olcnn_Sl));
                   dtoinput.setValue("FetchReq","true"); 
                   dtoinput.setValue("FetchColumns","OLC_LC_PRESANC_DATE, OLC_LC_PRESANC_DAY_SL,OLC_CORR_REF_NUM,OLC_LC_DATE," +
                   		"OLC_CUST_NUM,OLC_BENEF_CODE,OLC_BENEF_NAME,OLC_LC_ISS_BK_CODE,OLC_LC_ISS_BRN_CODE," +
                   		"OLC_LC_CURR_CODE,OLC_POS_DEV_ALLWD,OLC_LC_AMOUNT,OLC_DEV_AMOUNT,OLC_LC_BALANCE," +
                   		"OLC_CONV_RATE_BASE_CURR,OLC_LAST_DATE_OF_NEG,OLC_LATEST_DATE_OF_SHPMNT,OLC_TOT_LIAB_BASE_CURR");
                   Resultobj=olcval.valolc(dtoinput);
                   
                   if(Check_Result_Status())
                   { 
                   _olcSanctionedOnDate = Resultobj.getValue("OLC_LC_PRESANC_DATE");
                   _olcSanctionedODAySl=Resultobj.getValue("OLC_LC_PRESANC_DAY_SL");
                   _olcRefNum=Resultobj.getValue("OLC_CORR_REF_NUM");
                   _olcDate = Resultobj.getValue("OLC_LC_DATE");
                   _olcPriceTerms = Resultobj.getValue("OLC_PRICE_TERMS");
                   _olcCurrCode = Resultobj.getValue("OLC_LC_CURR_CODE");
                   _olcCustNum = Resultobj.getValue("OLC_CUST_NUM");
                   _olcBnefCode = Resultobj.getValue("OLC_BENEF_CODE");
                   _olcLcAmount = Resultobj.getValue("OLC_LC_AMOUNT");
                   _olcLcposdevallwd = Resultobj.getValue("OLC_POS_DEV_ALLWD");
                   //Changes P.Subramani-Chn-31/03/2008
                   _olcdevamt = Resultobj.getValue("OLC_DEV_AMOUNT");
                   _olcTotLiabBaseCurr = Resultobj.getValue("OLC_TOT_LIAB_BASE_CURR");   
                   _olcLatestDateShip = Resultobj.getValue("OLC_LATEST_DATE_OF_SHPMNT");
                   _olcLatestDateNegotiation = Resultobj.getValue("OLC_LAST_DATE_OF_NEG");
                   _olcPerInsValCvd = Resultobj.getValue("OLC_PERC_OF_INS_VALUE_CVRD"); 
                   _olcBalanceAmount=Resultobj.getValue("OLC_LC_BALANCE");
                   _olcconvratetobasecurr = Resultobj.getValue("OLC_CONV_RATE_BASE_CURR");
                   _olcbankcode = Resultobj.getValue("OLC_LC_ISS_BK_CODE");
                   _olcbrncode = Resultobj.getValue("OLC_LC_ISS_BRN_CODE");
                   
                  }
                   if(Check_Result_Status())
                   {//Changes P.Subramani-Chn-19/03/2008 Beg
                	   if(_olcbankcode!=null)
	        			{
	        				if(!(_olcbankcode.equalsIgnoreCase("")))
	        				{
	        					CommonValidator comnval	=	new	CommonValidator();    
	        					dtoinput.clearMap();
	        					dtoinput.setValue("BANKCD_CODE",_olcbankcode);
	        					Resultobj=comnval.valbankcd(dtoinput);
	        					_olcbankName=Resultobj.getValue("BANKCD_NAME");
	        				}
	        				
	        				if(Check_Result_Status())
	                        {
	        					if(_olcbrncode!=null)
	    	        			{
	    	        				if(!(_olcbrncode.equalsIgnoreCase("")))
	    	        				{
	    	        					CommonValidator 	comnval	=	new	CommonValidator();
	    	        					dtoinput.clearMap();
	    	        					dtoinput.setValue("MBKBRN_BANK_CODE",_olcbankcode);
	    	        					dtoinput.setValue("MBKBRN_BRN_CODE",_olcbrncode);
	    	        					Resultobj=comnval.valmbkbrn(dtoinput);
	    	        					_olcbranchkName=Resultobj.getValue("MBKBRN_NAME");
	    	        				}
	    	        			}
	                        }
	        			}
                   }
                   
                   if(Check_Result_Status())
	                {	
                	   if(_olcCustNum!=null)
	        			{
	        				if(!(_olcCustNum.equalsIgnoreCase("")))
	        				{
		                	   	ClientValidator 	clieval	=	new ClientValidator();
			    	           	dtoinput.clearMap();
			    	            dtoinput.setValue("CLIENTS_CODE",_olcCustNum);
			    	            dtoinput.setValue(FetchReq,"true");
			    		    	Resultobj=clieval.clientValid(dtoinput);
			    		    	_olcCustName=Resultobj.getValue("CLIENTS_NAME");
	        				}
	        			}
	    	       }
	               
                   if(Check_Result_Status())
	                {
                	   if(_olcBnefCode!=null)
	        			{
	        				if(!(_olcBnefCode.equalsIgnoreCase("")))
	        				{
			            	  TFMValidator   	tfmval	=	new	TFMValidator();
			            	  dtoinput.clearMap();
			            	  dtoinput.setValue("CPARTY_ALPHA_CODE",_olcBnefCode);
			            	  dtoinput.setValue(FetchReq,"true");
			    	    	  Resultobj=tfmval.valcparty(dtoinput);
			    	    	  _olcBeniefDesc=Resultobj.getValue("CPARTY_NAME");
	        				}
	        			}
	    	    	}//Changes P.Subramani-Chn-19/03/2008 End
                   
                   if(Check_Result_Status())
                   {
                	   
                   	  _QueryStr = "select OLCCN_CAN_AMT,OLCCN_AUTH_BY,OLCCN_REJ_BY from OLCCAN  where OLCCN_BRN_CODE=? and  OLCCN_LC_TYPE=? and  OLCCN_LC_YEAR=? and  OLCCN_LC_SL=?";
                         Set_preparedStatement(_QueryStr);
                         _pstmt.setInt(1,_branch_Code);
                         _pstmt.setString(2, _olccn_Type);
                         _pstmt.setInt(3,_olccn_Year);
                         _pstmt.setInt(4, _olcnn_Sl);
                         Resultobj = Get_Value_From_Main("OLCCAN");
                         _olccncantamt = Resultobj.getValue("OLCCN_CAN_AMT");
                         _olccnauth = Resultobj.getValue("OLCCN_AUTH_BY");
                         _olccnrej = Resultobj.getValue("OLCCN_REJ_BY");
                         if(_olccnauth==null)
                         {
                        	 _olccnauth="";
                         }
                         if(_olccnrej==null)
                         {
                        	 _olccnrej="";
                         }
                         if(Check_Result_Status())
                         {
                        	 if((Resultobj.getValue(ResultKey).equalsIgnoreCase(RowPresent))&&(useroption.equalsIgnoreCase("A")))
                      	      {
                      		   Resultobj.setValue(ErrorKey,"Record Already Exists" );
                      		   return Resultobj.copyofDTO();
                      	      }
                      	   
                        	 else if((Resultobj.getValue(ResultKey).equalsIgnoreCase(RowNotPresent))&&(useroption.equalsIgnoreCase("M")))
                          	    {
                      			   Resultobj.setValue(ErrorKey,"Record Does Not Exist to Modify" );
                      			   return Resultobj.copyofDTO();
                      			   
                          	    }
                        	else if((Resultobj.getValue(ResultKey).equalsIgnoreCase(RowPresent))&&(useroption.equalsIgnoreCase("M")))
                      	    {
                        		//Jeyamurugan.T  Chn -06/04/2010-begn
                        		if(!_olccnauth.equalsIgnoreCase(""))	
                        	   {
                        		 	Resultobj.setValue(ErrorKey,"Record Already Authorised Cannot Modify");
                        		 	return Resultobj.copyofDTO();
                  			   }
                        	 if(!_olccnrej.equalsIgnoreCase(""))
                        		{
                        		 	Resultobj.setValue(ErrorKey,"Record Already Rejected Cannot Modify");
                        		 	return Resultobj.copyofDTO();
                        	  }
                        	 //Jeyamurugan.T  Chn -06/04/2010-end
                  		    }  
                           }
                         
                       if(Check_Result_Status())
	    	                {
	    	                	if (Double.parseDouble(_olcBalanceAmount)<=0 )
	    	                	   {//R.Muthukumaran chen 29-mar-2010 added
	    	                    	   Resultobj.setValue(ErrorKey,"LC Balance is Zero.Can't Proceed" );
	    	                       }   	
	    	               } 
                     //Prabu K Changes On 21-04-2011 Beg
                  /*     if(Check_Result_Status())
                       {
                    	   if(!_olcBalanceAmount.equalsIgnoreCase(_olcLcAmount))
                    	   {
                    		   Resultobj.setValue(ErrorKey, "Lc Balance not equal to Lc Amount.Can't Proceed");
                    	   }
                       }*/
                     //Prabu K Changes On 21-04-2011 End
   
                         if(Check_Result_Status())
                         {
                        	 dtoinput.clearMap();
                             dtoinput.setValue("BRANCH_CODE",String.valueOf(_branch_Code));
                             dtoinput.setValue("ENTRY_DATE",String.valueOf(_olcSanctionedOnDate));
                             dtoinput.setValue("DAY_SERIAL",String.valueOf(_olcSanctionedODAySl));
                             dtoinput.setValue("FetchReq","true");
                             dtoinput.setValue("FetchColumns","FACNO(LCPS_CUST_LIAB_ACC_NUM)LCPS_CUST_LIAB_ACC_NUM");//LCPS_PROD_CODE
                             Resultobj=olcval.vallcps(dtoinput);
                             _lcpscustliabaccnum = Resultobj.getValue("LCPS_CUST_LIAB_ACC_NUM");
                             if(Check_Result_Status())
                             {
                            	 AccountValidator av = new AccountValidator();
                            	 dtoinput.clearMap();
                                 dtoinput.setValue("BRANCH_CODE",String.valueOf(_branch_Code));
                                 dtoinput.setValue("ACCOUNT_NUMBER",String.valueOf(_lcpscustliabaccnum));
                                 dtoinput.setValue("FetchReq","true");
                                 dtoinput.setValue("FetchColumns","ACNTS_CURR_CODE");
                                 Resultobj=av.chkacntstatus(dtoinput);
                                 if(Check_Result_Status())
                                 {
                                	 _intAccNum=Resultobj.getValue("ACNTS_INTERNAL_ACNUM");
                                	 _acntscurrcode=Resultobj.getValue("ACNTS_CURR_CODE");
                                	 CommonValidator  comnval2=new	CommonValidator();
                                	 dtoinput.clearMap();
                                	 dtoinput.setValue("CURR_CODE",_acntscurrcode);
                                 	 Resultobj=comnval2.valcurrcd(dtoinput);
                                 	 if(Check_Result_Status())
                                    {
                                 	     _currencyName = Resultobj.getValue("CURR_NAME");
                                 	     _QueryStr = "Select nvl(max(OLCA_AMD_SL),0) MAX_AMDSL from OLCAMD where OLCA_BRN_CODE =? and OLCA_LC_TYPE = ? and OLCA_LC_YEAR =? and OLCA_LC_SL = ?  AND OLCA_REJ_BY IS NULL";
                                 	     Set_preparedStatement(_QueryStr);
	     	    	                    _pstmt.setInt(1, _branch_Code);
	     	    	                    _pstmt.setString(2, _olccn_Type);
	     	    	                    _pstmt.setInt(3, _olccn_Year);
	     	    	                    _pstmt.setInt(4, _olcnn_Sl);
	     	    	                    Resultobj=Get_Value_From_Main("OLCAMD");
	     	    	                   _max_amdsl=Resultobj.getValue("MAX_AMDSL");
	     	    	                   if(Integer.parseInt(_max_amdsl) > 0)
	     	    	                   {  
   	     	    	                       if(Check_Result_Status())
			                                   { 
				     	    	                   if(Integer.parseInt(_max_amdsl) > 0)
				     	    	                   {
				     	    	                	   OLCValidator olcval1=new OLCValidator();
					     	    	                   dtoinput.clearMap();
					     	    	                   dtoinput.setValue("BRANCH_CODE",String.valueOf(_branch_Code));
					     	    	                   dtoinput.setValue("LC_TYPE",String.valueOf(_olccn_Type));
					     	    	                   dtoinput.setValue("LC_YEAR",String.valueOf(_olccn_Year));
					     	    	                   dtoinput.setValue("LC_SERIAL",String.valueOf(_olcnn_Sl));
					     	    	                   dtoinput.setValue("AMENDMENT_SERIAL",String.valueOf(_max_amdsl));
					     	    	                   dtoinput.setValue("FetchReq","true");
					     	    	                   dtoinput.setValue("FetchColumns","OLCA_CONTRA_AMT,OLCA_TOT_LIAB_BASE_CURR,OLCA_ENTRY_DATE, OLCA_LATEST_DATE_OF_SHPMNT, OLCA_LAST_DATE_OF_NEG, OLCA_AMENDED_AMT,OLCA_POS_DEV_ALLWD, OLCA_DEV_AMT, OLCA_CONV_RATE_BASE_CURR,OLCA_TOT_LIAB_LC_CURR");
					     	    	                   Resultobj=olcval1.valolcamd(dtoinput);
					     	    	                   _olcaamendedamt = Resultobj.getValue("OLCA_AMENDED_AMT");
					     	    	                   _olcaconvratetobasecurr = Resultobj.getValue("OLCA_CONV_RATE_BASE_CURR");
					     	    	                   _olcaamendentydate = Resultobj.getValue("OLCA_ENTRY_DATE");
					     	    	                   _olcaamendedlastshpmnt= Resultobj.getValue("OLCA_LATEST_DATE_OF_SHPMNT");
					     	    	                   _olcaamendeddateneg = Resultobj.getValue("OLCA_LAST_DATE_OF_NEG");
					     	    	                  _olcaamendeddevalled = Resultobj.getValue("OLCA_POS_DEV_ALLWD");
					     	    	                  //Changes P.Subramani-Chn-31/03/2008
					     	    	                 _olcaamendeddevamt = Resultobj.getValue("OLCA_DEV_AMT");
					     	    	                 //M.Murali - 10-05-2012 - added - Beg
					     	    	                 //ADDED BY SANJAY ON 08 AUGUST 2019
						     	    	        		olcAmdFinalTotalAmt = Resultobj.getValue("OLCA_TOT_LIAB_LC_CURR");
						     	    	        		//ADDED BY SANJAY ON 08 AUGUST 2019
						     	    	        		//ADDED BY PRASHANTH ON 23 AUGUST 2019
						     	    	        		olcAmdFinalConvAmt= Resultobj.getValue("OLCA_TOT_LIAB_BASE_CURR");
						     	    	        		olcContraAmt= Resultobj.getValue("OLCA_CONTRA_AMT");
						     	    	        		//ADDED BY PRASHANTH ON 23 AUGUST 2019
						     	    	                if(Check_Result_Status())
							    	                       {
							    	                    	   if(!_olcBalanceAmount.equalsIgnoreCase(_olcaamendedamt))
							    	                    	   {
							    	                    		   Resultobj.setValue(ErrorKey, "Lc Balance not equal to Lc Amendment Amount .Can't Proceed");
							    	                           }
							    	                       }
							    	                       
					     	    	                 //M.Murali - 10-05-2012 - added - End
				     	    	                   }
			     	    	                	}
	     	    	                   }// M.Murali - 10-05-2012 - added  
				     	    	                //--VARUN.G--66792--18/02/2012--beg
	     	    	                            //M.Murali - 10-05-2012 - Command - Beg
                                                /* 
				     	    	                if(Check_Result_Status())
					    	                       {
					    	                    	   if(!_olcBalanceAmount.equalsIgnoreCase(_olcaamendedamt))
					    	                    	   {
					    	                    		   Resultobj.setValue(ErrorKey, "Lc Balance not equal to Lc Amendment Amount .Can't Proceed");
					    	                           }
					    	                       }
					    	                   */ //M.Murali - 10-05-2012 - Command - End
				     	    	               //--VARUN.G--66792--18/02/2012--End
				     	    	              if(Check_Result_Status())
			                                  {  
				     	    	                if(Integer.parseInt(_max_amdsl) == 0 || _max_amdsl.equalsIgnoreCase(" "))
					    	                	   {
			//	     	    	                	Changes P.Subramani-Chn-02/04/2008 Beg
				     	    	                	  _QueryStr = "Select OLCT_USANCE_INT_AMT from OLCTENORS where OLCT_BRN_CODE = ? and OLCT_LC_TYPE = ? and OLCT_LC_YEAR = ? and OLCT_LC_SL = ? " ;
					     	             				Set_preparedStatement(_QueryStr);
					     	    	                    _pstmt.setInt(1, _branch_Code);
					     	    	                    _pstmt.setString(2, _olccn_Type);
					     	    	                    _pstmt.setInt(3,_olccn_Year);
					     	    	                   _pstmt.setInt(4,_olcnn_Sl);
					     	    	                    Resultobj=Get_Value_From_Main("OLCTENORS");
					     	    	                    _sumuseintamt = Double.parseDouble(Resultobj.getValue("OLCT_USANCE_INT_AMT"));
			//		     	    	                 Changes P.Subramani-Chn-02/04/2008 End
					     	    	                   if(Check_Result_Status())
					                                   {
					     	    	                	    _lctotamt = ( Double.parseDouble(_olcLcAmount) + Double.parseDouble(_olcdevamt) + _sumuseintamt);
					     	    	                	    CommonValidator cv = new CommonValidator();
						     	    	          			dtoinput.setValue("FOR_CURR",_olcCurrCode);
						     	    	          			dtoinput.setValue("AGNST_CURR",baseCurrency);
						     	    	          			dtoinput.setValue("AMT_FOR_CURR",String.valueOf(_lctotamt));
						     	    	          			dtoinput.setValue("CONVER_RATE",String.valueOf(_olcconvratetobasecurr));
						     	    	          			Resultobj = cv.calAgnstVal(dtoinput);
						     	    	          			_againstamt = Double.parseDouble(Resultobj.getValue("AMT_AGNST_CURR"));
						     	    	          			
						     	    	          		   if(Check_Result_Status())
						                                   {
							     	    	          			Resultobj.setValue(ErrorKey,"");
							     	    	          			_declength =cbsglobal.getcurrdeclength(baseCurrency);
							     	    	          		 
						                                   }
						     	    	          		if(Check_Result_Status())
						                                   {
							     	    	          			Resultobj.setValue(ErrorKey,"");
							     	    	          			_declength1 =cbsglobal.getcurrdeclength(_olcCurrCode);
						                                   }
						     	    	          	   }
					    	                	   
					     	    	                   if(Check_Result_Status())
					                                   {
					     	    	                	   _lctotamt1 = ( Double.parseDouble(_olcLcAmount) - Double.parseDouble(_olcBalanceAmount) );
					     	    	                	   CommonValidator cv1 = new CommonValidator();
						     	    	          			dtoinput.setValue("FOR_CURR",_olcCurrCode);
						     	    	          			dtoinput.setValue("AGNST_CURR",baseCurrency);
						     	    	          			dtoinput.setValue("AMT_FOR_CURR",String.valueOf(_lctotamt1));
						     	    	          			dtoinput.setValue("CONVER_RATE",String.valueOf(_olcconvratetobasecurr));
						     	    	          			Resultobj = cv1.calAgnstVal(dtoinput);
						     	    	          			_againstamt1 = Double.parseDouble(Resultobj.getValue("AMT_AGNST_CURR"));
						     	    	          			
						     	    	          		   
					                                   }
					     	    	                   
					     	    	                  if(Check_Result_Status())
					                                   {
					     	    	                	   if(useroption.equalsIgnoreCase("A"))
					     	    	                	   {
					     	    	                		  W_cancelled_amount = Double.parseDouble(_olcBalanceAmount);
					     	    	                	   }
					     	    	                	   else
					     	    	                	   {
					     	    	                		  //W_cancelled_amount = Double.parseDouble(_olcBalanceAmount) + Double.parseDouble(_olccncantamt);
					     	    	                		  W_cancelled_amount=Double.parseDouble(_olccncantamt);	//Jeyamurugan.T  Chn -06/04/2010-added
					     	    	                	   }
					     	    	                	   
					     	    	                	    CommonValidator cv2 = new CommonValidator();
						     	    	          			dtoinput.setValue("FOR_CURR",_olcCurrCode);
						     	    	          			dtoinput.setValue("AGNST_CURR",baseCurrency);
						     	    	          			dtoinput.setValue("AMT_FOR_CURR",String.valueOf(W_cancelled_amount));
						     	    	          			dtoinput.setValue("CONVER_RATE",String.valueOf(_olcconvratetobasecurr));
						     	    	          			Resultobj = cv2.calAgnstVal(dtoinput);
						     	    	          			_againstamt2 = Double.parseDouble(Resultobj.getValue("AMT_AGNST_CURR"));
						     	    	          			
						     	    	          		   
					     	    	                   }
					    	                	   
					    	                	   }
				     	    	                  
				     	    	                  else if(Integer.parseInt(_max_amdsl) > 0)
				     	    	                   {
				     	    	                	  //Changes P.Subramani-Chn-02/04/2008 Beg 
				     	    	                	  _QueryStr = "Select OLCTA_USANCE_INT_AMT from OLCTENORSAMD where OLCTA_BRN_CODE = ? and OLCTA_LC_TYPE = ? and OLCTA_LC_YEAR = ? and OLCTA_LC_SL = ? and OLCTA_AMD_SL=?" ;
					     	             				Set_preparedStatement(_QueryStr);
					     	    	                    _pstmt.setInt(1, _branch_Code);
					     	    	                    _pstmt.setString(2, _olccn_Type);
					     	    	                    _pstmt.setInt(3,_olccn_Year);
					     	    	                   _pstmt.setInt(4,_olcnn_Sl);
					     	    	                  _pstmt.setInt(5,Integer.parseInt(_max_amdsl));
					     	    	                    Resultobj=Get_Value_From_Main("OLCTENORSAMD");
					     	    	                    _sumuseintamt = Double.parseDouble(Resultobj.getValue("OLCTA_USANCE_INT_AMT"));
			//		     	    	                 //Changes P.Subramani-Chn-02/04/2008 End 
					     	    	                    
					     	    	                   if(Check_Result_Status())
					                                   {//Changes P.Subramani-Chn-20/03/2008 
					     	    	                	    _lctotamt = ( Double.parseDouble(_olcaamendedamt) + Double.parseDouble(_olcaamendeddevamt) + _sumuseintamt);
					     	    	                	    CommonValidator cv3 = new CommonValidator();
						     	    	          			dtoinput.setValue("FOR_CURR",_olcCurrCode);
						     	    	          			dtoinput.setValue("AGNST_CURR",baseCurrency);
						     	    	          			dtoinput.setValue("AMT_FOR_CURR",String.valueOf(_lctotamt));
						     	    	          			dtoinput.setValue("CONVER_RATE",String.valueOf(_olcaconvratetobasecurr));
						     	    	          			Resultobj = cv3.calAgnstVal(dtoinput);
						     	    	          			_againstamt = Double.parseDouble(Resultobj.getValue("AMT_AGNST_CURR"));
						     	    	          			
						     	    	          		   if(Check_Result_Status())
						                                   {
							     	    	          			Resultobj.setValue(ErrorKey,"");
							     	    	          			_declength =cbsglobal.getcurrdeclength(baseCurrency);
						                                   }
						     	    	          		   
						     	    	          		if(Check_Result_Status())
						                                   {
							     	    	          			Resultobj.setValue(ErrorKey,"");
							     	    	          			_declength1 =cbsglobal.getcurrdeclength(_olcCurrCode);
						                                   }
						     	    	          	   }
					     	    	                   
					     	    	                  if(Check_Result_Status())
					                                   {
					     	    	                	   _lctotamt1 = ( Double.parseDouble(_olcaamendedamt) - Double.parseDouble(_olcBalanceAmount) );
					     	    	                	   CommonValidator cv4 = new CommonValidator();
						     	    	          			dtoinput.setValue("FOR_CURR",_olcCurrCode);
						     	    	          			dtoinput.setValue("AGNST_CURR",baseCurrency);
						     	    	          			dtoinput.setValue("AMT_FOR_CURR",String.valueOf(_lctotamt1));
						     	    	          			dtoinput.setValue("CONVER_RATE",String.valueOf(_olcaconvratetobasecurr));
						     	    	          			Resultobj = cv4.calAgnstVal(dtoinput);
						     	    	          			_againstamt1 = Double.parseDouble(Resultobj.getValue("AMT_AGNST_CURR"));
						     	    	          			
						     	    	          		   
						                                   
						     	    	          	   }
					     	    	                  
					     	    	                 if(Check_Result_Status())
					                                   {
					     	    	                	   if(useroption.equalsIgnoreCase("A"))
					     	    	                	   {
					     	    	                		  W_cancelled_amount = Double.parseDouble(_olcBalanceAmount);
					     	    	                	   }
					     	    	                	   else
					     	    	                	   {
					     	    	                		  W_cancelled_amount = Double.parseDouble(_olcBalanceAmount) +  Double.parseDouble(_olccncantamt);
					     	    	                	   }
					     	    	                	   
					     	    	                	    CommonValidator cv5 = new CommonValidator();
						     	    	          			dtoinput.setValue("FOR_CURR",_olcCurrCode);
						     	    	          			dtoinput.setValue("AGNST_CURR",baseCurrency);
						     	    	          			dtoinput.setValue("AMT_FOR_CURR",String.valueOf(W_cancelled_amount));
						     	    	          			dtoinput.setValue("CONVER_RATE",String.valueOf(_olcaconvratetobasecurr));
						     	    	          			Resultobj = cv5.calAgnstVal(dtoinput);
						     	    	          			_againstamt2 = Double.parseDouble(Resultobj.getValue("AMT_AGNST_CURR"));
						     	    	          			
						     	    	          		   
					     	    	                   }
					     	    	                
					     	    	                 }
	     	    	                  }
     	    	                  
				     	    	      //M.Murali - 10-05-2012 - Commanded }}//--VARUN.G--66792--18/02/2012
     	    	             		else
     	    	             		{
     	    	             		  if(Check_Result_Status())
     	    	                       {
     	    	                    	   if(!_olcBalanceAmount.equalsIgnoreCase(_olcLcAmount))
     	    	                    	   {
     	    	                    		   Resultobj.setValue(ErrorKey, "Lc Balance not equal to Lc Amount.Can't Proceed");
     	    	                    	   }
     	    	                       }
     	    	             			
     	    	             		}
     	    	                  //--VARUN.G--66792--18/02/2012
     	    	                  
                                   }
                                 }	
                             }
                         }
                    }
                   //ADDED BY SANJAY ON 08 AUGUST 2019
             		/*if (!olcAmdFinalTotalAmt.equals(""))
             		{
             		if (Check_Result_Status()) {
             		TFMValidator tfmVal=new TFMValidator();
             		dtoinput.clearMap();
             		dtoinput.setValue("FOR_CURR", _olcCurrCode);
             		dtoinput.setValue("AGAINST_CURR", "INR");
             		dtoinput.setValue("FOR_AMOUNT", String.valueOf(olcAmdFinalTotalAmt));
             		dtoinput.setValue("CONVERSION_RATE", _olcaconvratetobasecurr);
             		Resultobj = tfmVal.getconversionrateAmount(dtoinput);
             		Resultobj.setValue("CONVERTED_AMOUNT", Resultobj.getValue("CONV_AMNT"));
             		olcAmdFinalConvAmt= Resultobj.getValue("CONV_AMNT");
             		}
             		}
             		*/
             		Resultobj.setValue(ErrorKey,"");
             	//ADDED BY SANJAY ON 08 AUGUST 2019
                   Resultobj.setValue("OLC_CORR_REF_NUM",_olcRefNum);
                   Resultobj.setValue("OLC_LC_DATE",_olcDate);
                   Resultobj.setValue("OLC_CUST_NUM",_olcCustNum);
                   Resultobj.setValue("CLIENTS_NAME",_olcCustName);
                   Resultobj.setValue("OLC_BENEF_CODE",_olcBnefCode);
                   Resultobj.setValue("CPARTY_NAME",_olcBeniefDesc);
                   Resultobj.setValue("LCPS_PROD_CODE",_lcpsprodcode);
                   Resultobj.setValue("ACNTS_CURR_CODE",_acntscurrcode);
                   Resultobj.setValue("PRESANC_DATE",_olcSanctionedOnDate);
                   Resultobj.setValue("OLC_LC_PRESANC_DAY_SL",_olcSanctionedODAySl);
                   Resultobj.setValue("OLC_LC_ISS_BK_CODE",_olcbankcode);
                   Resultobj.setValue("BANKCD_NAME",_olcbankName);
                   Resultobj.setValue("OLC_LC_ISS_BRN_CODE",_olcbrncode);
                   Resultobj.setValue("MBKBRN_NAME",_olcbranchkName);
                   Resultobj.setValue("OLC_PRICE_TERMS",_olcPriceTerms);
                   Resultobj.setValue("OLC_LC_CURR_CODE",_olcCurrCode);
                   Resultobj.setValue("CURR_NAME",_currencyName);
                   Resultobj.setValue("OLC_LC_AMOUNT",_olcLcAmount);
                   Resultobj.setValue("OLC_POS_DEV_ALLWD",_olcLcposdevallwd);
                   //Resultobj.setValue("OLC_TOT_LIAB_BASE_CURR",_olcTotLiabBaseCurr);   
                   Resultobj.setValue("OLC_LATEST_DATE_OF_SHPMNT",_olcLatestDateShip); 
                   Resultobj.setValue("OLC_LAST_DATE_OF_NEG",_olcLatestDateNegotiation);
                   Resultobj.setValue("OLC_PERC_OF_INS_VALUE_CVRD",_olcPerInsValCvd); 
                   Resultobj.setValue("OLC_LC_BALANCE",_olcBalanceAmount);
                   Resultobj.setValue("OLC_CONV_RATE_BASE_CURR",_olcconvratetobasecurr);
                   
                   Resultobj.setValue("OLCCN_CAN_AMT",_olccncantamt);
                   Resultobj.setValue("MAX_AMND_SL",_max_amdsl); 
                   
                   Resultobj.setValue("OLCA_AMENDED_AMT",_olcaamendedamt);
                   Resultobj.setValue("OLCA_CONV_RATE_BASE_CURR",_olcaconvratetobasecurr);
                   Resultobj.setValue("OLCA_ENTRY_DATE",_olcaamendentydate);
                   Resultobj.setValue("OLCA_LATEST_DATE_OF_SHPMNT",_olcaamendedlastshpmnt);
                   Resultobj.setValue("OLCA_LAST_DATE_OF_NEG",_olcaamendeddateneg);
                   Resultobj.setValue("OLCA_POS_DEV_ALLWD",_olcaamendeddevalled);
                  
                   //Changes P.Subramani-Chn-20/03/2008 Beg
                   // Yasodha.D 03.08.2011 Changed Begin
                   /*
                   Resultobj.setValue("USANCE_INTEREST",String.valueOf(_sumuseintamt));
                   Resultobj.setValue("TOT_LC_LIAB",String.valueOf(_lctotamt));
                   Resultobj.setValue("LC_LIAB_REV_SOFAR",String.valueOf(_lctotamt1));
                   Resultobj.setValue("LC_LIAB_REV_DUETO_CURR_CANCEL",String.valueOf(W_cancelled_amount));
                   */
                   if(_olcCurrCode.equalsIgnoreCase(baseCurrency))
                   {
                	   Resultobj.setValue("USANCE_INTEREST",RoundOffunc(_olcDate,String.valueOf(_sumuseintamt),"N"));
                       Resultobj.setValue("TOT_LC_LIAB",RoundOffunc(_olcDate,String.valueOf(_lctotamt),"N"));
                       Resultobj.setValue("LC_LIAB_REV_SOFAR",RoundOffunc(_olcDate,String.valueOf(_lctotamt1),"N"));
                       Resultobj.setValue("LC_LIAB_REV_DUETO_CURR_CANCEL",RoundOffunc(_olcDate,String.valueOf(W_cancelled_amount),"N"));
                   }
                   else
                   {
                	   Resultobj.setValue("USANCE_INTEREST",String.valueOf(FormatDoubleValue(_sumuseintamt)));
                       Resultobj.setValue("TOT_LC_LIAB",String.valueOf(FormatDoubleValue(_lctotamt)));
                       Resultobj.setValue("LC_LIAB_REV_SOFAR",String.valueOf(FormatDoubleValue(_lctotamt1)));
                       Resultobj.setValue("LC_LIAB_REV_DUETO_CURR_CANCEL",String.valueOf(FormatDoubleValue(W_cancelled_amount)));
                   }
                   
                   // Resultobj.setValue("BASE_EQU_TOT_LC_LIAB_AMT",String.valueOf(_againstamt));
                   Resultobj.setValue("BASE_EQU_TOT_LC_LIAB_AMT",RoundOffunc(_olcDate,String.valueOf(_againstamt),"N"));
                   // Resultobj.setValue("BASE_EQU_LC_LIAB_REV_AMT",String.valueOf(_againstamt1));
                   Resultobj.setValue("BASE_EQU_LC_LIAB_REV_AMT",RoundOffunc(_olcDate,String.valueOf(_againstamt1),"N"));
                   // Resultobj.setValue("BASE_EQ_LC_LIAB_BE_REV_CURR_CANCEL_AMT",String.valueOf(_againstamt2));
                   Resultobj.setValue("BASE_EQ_LC_LIAB_BE_REV_CURR_CANCEL_AMT",RoundOffunc(_olcDate,String.valueOf(_againstamt2),"N"));
                   // Yasodha.D 03.08.2011 Changed End
                   //Changes P.Subramani-Chn-20/03/2008 End 
                   
                   //Changes P.Subramani-Chn-31/03/2008 Beg
                   Resultobj.setValue("OLC_DEV_AMT",_olcdevamt);
                   Resultobj.setValue("OLCA_DEV_AMT",_olcaamendeddevamt);
                   //Changes P.Subramani-Chn-31/03/2008 End
                   
                   Resultobj.setValue("BASE_CURR_LENGTH",String.valueOf(_declength));
                   Resultobj.setValue("LC_CURR_LENGTH",String.valueOf(_declength1));
                   Resultobj.setValue("INT_ACC_NUM",_intAccNum);
                /* //ADDED BY SANJAY ON 08 AUGUST 2019
              		if(olcAmdFinalConvAmt.equals("")){
              		Resultobj.setValue("OLC_TOT_LIAB_BASE_CURR", String.valueOf(_olcTotLiabBaseCurr));
              		}
              		else{
              		Resultobj.setValue("OLC_TOT_LIAB_BASE_CURR", String.valueOf(olcAmdFinalConvAmt));
              		}
              		//ADDED BY SANJAY ON 08 AUGUST 2019
              		 */
                   
             		Resultobj.setValue("OLC_TOT_LIAB_BASE_CURR", String.valueOf(olcContraAmt));

                   
//Changes P.Subramani  chn-03/01/2008 End              	
                }
              }
       catch(Exception e)
            {
                Resultobj.setValue(ErrorKey,"Error in olcLcSlkeypress" );
            }
        return Resultobj.copyofDTO();
        }
    
    
    
    
//  *********************************************************************************************************
    // *********************************************************************************************************
    /*
    * Input 	- 						    Key  =OLC_CANCEL_DATE
    * 										Key  =CBD	
    * 										key  =OLC_ENTRY_DATE
    * 										Key=NUM_AMEND_SL
    * 										Key=NUM_AMEND_DATE			
    * Output	: Error Message  		- 		Key = ErrorMsg
    */
    
    
    public DTObject olccancelationDatekeypress(DTObject InputoBj)
    {
    try
        {
            String  _olccancelDate = "";
            String _currBusDate="";
            String _lcentryDate="";
            String _amendDate="";
            int _amendSL;
            {
            	_olccancelDate =   InputoBj.getValue("OLC_CANCEL_DATE") .trim().toString();
            }
            
        Init_ResultObj(InputoBj);
        _currBusDate=InputoBj.getValue("CBD").trim().toString();
        _lcentryDate=InputoBj.getValue("OLC_ENTRY_DATE").trim().toString();
        _amendSL=Integer.parseInt(InputoBj.getValue("NUM_AMEND_SL").trim().toString());
        _amendDate=InputoBj.getValue("NUM_AMEND_DATE").trim().toString();
            if(String.valueOf(_olccancelDate).trim().equalsIgnoreCase(""))
            {
                Resultobj.setValue(ErrorKey,BLANK_CHECK);
            }
            if(!_olccancelDate.equalsIgnoreCase(""))
            {
            if(Check_Result_Status())
                {
            	 CheckDate(_olccancelDate);	
            	 if(Check_Result_Status())
                 {
                 	if (!(DateUtility.DateLessThanOrEqual(_olccancelDate,_currBusDate)))
                 	{
                 		Resultobj.setValue(ErrorKey,"It cannot be greaterthanequal CBD");
                 	}
                 	if(Check_Result_Status())
                    {	
                 	
                 	if(!DateUtility.DateGreaterThanOrEqual(_olccancelDate,_lcentryDate))
                 	{
                 		Resultobj.setValue(ErrorKey,"Cancellation Date Should Be greaterthan or Equal to LC Entry Date ");
                 	}
                 	
                 	if((_amendSL>0))
                 	{
                 		if(!DateUtility.DateGreaterThanOrEqual(_olccancelDate,_amendDate))
                     	{
                     		Resultobj.setValue(ErrorKey,"Cancellation Date Should Be Greater Than or Equal To Amend Entry Date ");
                     	}
                     	
                 			
                 	}		
                   }
                 	
                 }
             }
            }
            
            
            
        }
    catch(Exception e)
        {
            Resultobj.setValue(ErrorKey,"Error in olccancelationDatekeypress" );
        }
    return Resultobj.copyofDTO();
    }
//  *********************************************************************************************************
    /*
    * Input 	: 			- 		Key = OLCCN_CUST_LETER_NUM 
    * Output	: 
    * 			      Error Message 	Key = ErrorMsg
    */
// *********************************************************************************************************    
  
    
	public DTObject olccCustLeterNumkeypress(DTObject InputoBj)
    {
    try
        {
        	String  _olccustletnum ="";
        	{
        		_olccustletnum =   InputoBj.getValue("OLCCN_CUST_LETER_NUM") .trim().toString();
            }
                Init_ResultObj(InputoBj);
                if(String.valueOf(_olccustletnum).trim().equalsIgnoreCase(""))
                {
                    Resultobj.setValue(ErrorKey,BLANK_CHECK);
                }
        }
    catch(Exception e)
        {
            Resultobj.setValue(ErrorKey,"Error in olccCustLeterNumkeypress" );
        }
    return Resultobj.copyofDTO();
    }
    // *********************************************************************************************************
    /*
    * Input 	- 						    Key  =CUSTLET_NUM_DATE
    * 											
    * 										key  =OLC_ENTRY_DATE
    * 										Key=NUM_AMEND_SL
    * 										Key=NUM_AMEND_DATE			
    * Output	: Error Message  		- 		Key = ErrorMsg
    */
    
    
    public DTObject olcCustLeterNumDatekeypress(DTObject InputoBj)
    {
    try
        {
            String  _olccustletDate = "";
            String _lcentryDate="";
            String _amendDate="";
            int _amendSL;
            {
            	_olccustletDate =   InputoBj.getValue("CUSTLET_NUM_DATE") .trim().toString();
            }
            
        Init_ResultObj(InputoBj);
        _lcentryDate=InputoBj.getValue("OLC_ENTRY_DATE").trim().toString();
        _amendSL=Integer.parseInt(InputoBj.getValue("NUM_AMEND_SL").trim().toString());
        _amendDate=InputoBj.getValue("NUM_AMEND_DATE").trim().toString();
            if(String.valueOf(_olccustletDate).trim().equalsIgnoreCase(""))
            {
                Resultobj.setValue(ErrorKey,BLANK_CHECK);
            }
            if(!_olccustletDate.equalsIgnoreCase(""))
            {
            if(Check_Result_Status())
                {
            	 CheckDate(_olccustletDate);	
            	 if(Check_Result_Status())
                 {
                 	
                 	if(Check_Result_Status())
                    {	
                 	
                 	if(!DateUtility.DateGreaterThanOrEqual(_olccustletDate,_lcentryDate))
                 	{
                 		Resultobj.setValue(ErrorKey,"Customer Letter Dated Should Be  Greater Than or Equal To LC Entry Date ");
                 	}
                 	
                 	if((_amendSL>0))
                 	{
                 		if(!DateUtility.DateGreaterThanOrEqual(_olccustletDate,_amendDate))
                     	{
                     		Resultobj.setValue(ErrorKey,"Customer Letter Dated Should Be  Greater Than or Equal To Amend Entry Date ");
                     	}
                     	
                 			
                 	}		
                   }
                 	
                 }
             }
            }
            
            
            
        }
    catch(Exception e)
        {
            Resultobj.setValue(ErrorKey,"Error in olcCustLeterNumDatekeypress" );
        }
    return Resultobj.copyofDTO();
    }
//  *********************************************************************************************************
    /*
    * Input 	: 			- 		Key = OLCCN_CON_REF_NUM 
    * Output	: 
    * 			      Error Message 	Key = ErrorMsg
    */
// *********************************************************************************************************    
  	
	
	public DTObject olccConsentRefNumkeypress(DTObject InputoBj)
    {
    try
        {
        	String  _olcConstRefnum ="";
        	{
        		_olcConstRefnum =   InputoBj.getValue("OLCCN_CON_REF_NUM") .trim().toString();
            }
                Init_ResultObj(InputoBj);
                if(String.valueOf(_olcConstRefnum).trim().equalsIgnoreCase(""))
                {
                    Resultobj.setValue(ErrorKey,BLANK_CHECK);
                }
        }
    catch(Exception e)
        {
            Resultobj.setValue(ErrorKey,"Error in olccConsentRefNumkeypress" );
        }
    return Resultobj.copyofDTO();
    }
  
    // *********************************************************************************************************
    /*
    * Input 	- 						    Key  =CONSENT_DATE
    * 										key  =OLC_CANCEL_DATE
    * 										key  =CUSTLET_NUM_DATE
    * 													
    * Output	: Error Message  		- 		Key = ErrorMsg
    */
    
    
    public DTObject olcConsentrefdatekeypress(DTObject InputoBj)
    {
    try
        {
            String  _olcconsentDate = "";
            String _olccancelDate="";
            String _olccustletDate="";
            {
            	_olcconsentDate =   InputoBj.getValue("CONSENT_DATE") .trim().toString();
            }
            
        Init_ResultObj(InputoBj);
        _olccancelDate=InputoBj.getValue("OLC_CANCEL_DATE").trim().toString();
        _olccustletDate=InputoBj.getValue("CUSTLET_NUM_DATE").trim().toString();
            if(String.valueOf(_olcconsentDate).trim().equalsIgnoreCase(""))
            {
                Resultobj.setValue(ErrorKey,BLANK_CHECK);
            }
            if(!_olcconsentDate.equalsIgnoreCase(""))
            {
            if(Check_Result_Status())
                {
            	 CheckDate(_olcconsentDate);	
            	 if(Check_Result_Status())
                 {
                 	
                 	if(Check_Result_Status())
                    {	
                 	//Changes P.Subramani-Chn-27/03/2008 Beg
                 	if(DateUtility.DateGreaterThan(_olcconsentDate,_olccancelDate))
                 	{
                 		Resultobj.setValue(ErrorKey,"Consent Ref Dated Should Be Less Than or Equal To Cancellation Date ");
                 	}
             		if(DateUtility.DateLessThan(_olcconsentDate,_olccustletDate))
                 	{
                 		Resultobj.setValue(ErrorKey,"Consent Ref Dated Should Be  Greater Than or Equal To Customer Letter Dated");
                 	}
             		//Changes P.Subramani-Chn-27/03/2008 End
                 			
                   }
                 	
                 }
             }
            }
            
            
            
        }
    catch(Exception e)
        {
            Resultobj.setValue(ErrorKey,"Error in olcConsentrefdatekeypress" );
        }
    return Resultobj.copyofDTO();
    }
	
	
	
//  *********************************************************************************************************
    /*
    * Input 	: 			- 		Key = OLCCN_ADVISING_REF_NUM 
    * Output	: 
    * 			      Error Message 	Key = ErrorMsg
    */
// *********************************************************************************************************    
  	
   
	public DTObject olccAdvisingRefNumkeypress(DTObject InputoBj)
    {
    try
        {
        	String  _olcAdvisingRefnum ="";
        	{
        		_olcAdvisingRefnum =   InputoBj.getValue("OLCCN_ADVISING_REF_NUM") .trim().toString();
            }
                Init_ResultObj(InputoBj);
                if(String.valueOf(_olcAdvisingRefnum).trim().equalsIgnoreCase(""))
                {
                    Resultobj.setValue(ErrorKey,BLANK_CHECK);
                }
        }
    catch(Exception e)
        {
            Resultobj.setValue(ErrorKey,"Error in olccAdvisingRefNumkeypress" );
        }
    return Resultobj.copyofDTO();
    }
	  // *********************************************************************************************************
    /*
    * Input 	- 						    Key  =ADVISING_DATE
    * 										key  =OLC_CANCEL_DATE
    * 										key  =CUSTLET_NUM_DATE
    * 													
    * Output	: Error Message  		- 		Key = ErrorMsg
    */
    
    
    public DTObject olcadvisingdatekeypress(DTObject InputoBj)
    {
    try
        {
            String  _olcadvisingDate = "";
            String _olccancelDate="";
            String _olccustletDate="";
            {
            	_olcadvisingDate =   InputoBj.getValue("ADVISING_DATE") .trim().toString();
            }
            
        Init_ResultObj(InputoBj);
        _olccancelDate=InputoBj.getValue("OLC_CANCEL_DATE").trim().toString();
        _olccustletDate=InputoBj.getValue("CUSTLET_NUM_DATE").trim().toString();
            if(String.valueOf(_olcadvisingDate).trim().equalsIgnoreCase(""))
            {
                Resultobj.setValue(ErrorKey,BLANK_CHECK);
            }
            if(!_olcadvisingDate.equalsIgnoreCase(""))
            {
            if(Check_Result_Status())
                {
            	 CheckDate(_olcadvisingDate);	
            	 if(Check_Result_Status())
                 {
                 	if(Check_Result_Status())
                    {	
                 	//Changes P.Subramani-Chn-27/03/2008 Beg
                 	if(DateUtility.DateGreaterThan(_olcadvisingDate,_olccancelDate))
                 	{
                 		Resultobj.setValue(ErrorKey,"Advising Bank Reference Dated Should Be Less Than or Equal To Cancellation Date ");
                 	}
             		if(DateUtility.DateLessThan(_olcadvisingDate,_olccustletDate))
                 	{
                 		Resultobj.setValue(ErrorKey,"Advising Bank Reference Dated Should Be Greater Than or Equal To Customer Letter Dated");
                 	}
                 	//Changes P.Subramani-Chn-27/03/2008 End
                    }
                 	
                 }
             }
            }
            
            
            
        }
    catch(Exception e)
        {
            Resultobj.setValue(ErrorKey,"Error in olcadvisingdatekeypress" );
        }
    return Resultobj.copyofDTO();
    }
	
	
//  *********************************************************************************************************
    /*
    * Input 	: 			- 		Key = OLCCR_CANCELATION_REASON 
    * Output	: 
    * 			      Error Message 	Key = ErrorMsg
    */
// *********************************************************************************************************    
  	
   
	public DTObject olccanelreasonkeypress(DTObject InputoBj)
    {
    try
        {
        	String  _olccancelreason ="";
        	String lc_type="";
        	String lc_curr="";
        	String opt_type="2";
        	String result="";
        		{
	        		_olccancelreason =   InputoBj.getValue("OLCCR_CANCELATION_REASON") .trim().toString();
	        		 lc_type =    InputoBj.getValue("LC_TYPE") .trim().toString();        
	        		 lc_curr =    InputoBj.getValue("LC_CURRENCY") .trim().toString();        
        		}
                Init_ResultObj(InputoBj);
                if(String.valueOf(_olccancelreason).trim().equalsIgnoreCase(""))
                {
                    Resultobj.setValue(ErrorKey,BLANK_CHECK);
                }
                if(Check_Result_Status())
                {
                	       _QueryStr = "SELECT TRCHG_COMMN_CHGCD,TRCHG_COURIER_CHGCD,TRCHG_POSTAL_CHGCD  FROM TRCHGPARAM  WHERE TRCHG_NOMEN_CODE = ? AND TRCHG_OPT_TYPE = ? AND TRCHG_FACILITY_CURR = ?";
             				Set_preparedStatement(_QueryStr);
    	                    _pstmt.setString(1,lc_type);
    	                    _pstmt.setString(2,opt_type);
    	                    _pstmt.setString(3,lc_curr);
    	                    ResultSet  rs = _pstmt.executeQuery();
                    		result="";
                    		if(rs.next())
                    		{
                    			if(rs.getString(1)!=null)
                    				result = result+rs.getString(1)+"|";
                    			if(rs.getString(2)!=null)
                    				result = result+rs.getString(2)+"|";
                    			if(rs.getString(3)!=null)
                    				result = result+rs.getString(3)+"|";
                    		}
                    		rs.close();
                    		closeConnection();                         	
                    		if(result.length()>0)
    				    	{
    				    		Resultobj.setValue(ResultKey,RowPresent);
    				    		Resultobj.setValue("ResultGrid",result.substring(0,result.length()-1));
    				    	}
    						if(result.length()==0)
    				    	{
    				    		Resultobj.setValue(ResultKey,RowNotPresent);
    				    	}        
    	                   
    	               }
        }
    catch(Exception e)
        {
            Resultobj.setValue(ErrorKey,"Error in olccanelreasonkeypress" );
        }
    return Resultobj.copyofDTO();
    }
    //Changes P.Subramani-Chn-15/10/2008 BEg
    // *********************************************************************************************************
    /*
    * Input 							
    * 						 	        -   Key = OLCCN_BRN_CODE
    * 			      			        -	Key = OLCCN_LC_TYPE
    * 			  			            -	Key = OLCCN_LC_YEAR
    *										key = OLCCN_LC_SL
    * 										key = USEROPTION
    * 										 
    * Output	: Error Message  		- 	 Key = ErrorMsg
    * 										  
    * 
    */
    // *********************************************************************************************************
	
    public DTObject olccnSlkeypress1(DTObject InputoBj)
    {
        try
           {
                int  _olcnn_Sl = 0;
                int   _branch_Code = 0;
                String  _olccn_Type = "";
                int  _olccn_Year = 0;
                String _olcSanctionedOnDate="";
                String _olcSanctionedODAySl="";
                String _olcDate="";
                String _olcCustNum="";
                String _olcCustName="";
                String _olcBeniefDesc="";
                String _olcLcposdevallwd="";
                String _olcPriceTerms="";
                String _olcCurrCode="";
                String _olcBnefCode="";
                String _olcLcAmount="";
                String _olcTotLiabBaseCurr="";
                String _olcLatestDateShip="";
                String _olcPerInsValCvd="";
                String _olcBalanceAmount="";
                String useroption="";
                String _lcpscustliabaccnum="";
                String _lcpsprodcode="";
                String  _acntscurrcode="";
                String _max_amdsl="";
                double _sumuseintamt=0.0;
                String baseCurrency=get_base_curr_code(); 
                double _lctotamt=0.0;
                double _lctotamt1=0.0;
                double _lctotamt2=0.0;
                double _lctotamt3=0.0;
                String _olcconvratetobasecurr="";
                String _olcaconvratetobasecurr="";
                long	_declength=0;
                long	_declength1=0;
                long	_declength2=0;
                double W_cancelled_amount=0.0;
                String _olcaamendedamt="";
                String _olcaamendentydate="";
                String _olcaamendedlastshpmnt="";
                String _olcaamendeddateneg="";
                String _olcaamendeddevalled="";
                String _olcdevamt="";
                String _olcaamendeddevamt="";
                String _olcRefNum="";
                String _olcLatestDateNegotiation="";
                String _olcbankcode="";
                String _olcbrncode="";
                String _olccncantamt="";
                double _lcliabrevduetocurrval=0.0;
                double _againstamt=0.0;
                double _againstamt1=0.0;
                double _againstamt2=0.0;
                String  _currencyName="";
                String _olcbankName=""; 
                String _olcbranchkName="";
                String _olccnauth="";
                String _olccnrej="";
                String _intAccNum="";
                if (InputoBj.getValue("OLCCN_LC_SL").trim().equalsIgnoreCase(""))
                {
                   	_olcnn_Sl = 0;
                }
                else
                {
                 _branch_Code =  Integer.parseInt(InputoBj.getValue("OLCCN_BRN_CODE") .trim().toString());
                 _olccn_Type     =   InputoBj.getValue("OLCCN_LC_TYPE") .trim().toString();
                 _olccn_Year     =  Integer.parseInt(InputoBj.getValue("OLCCN_LC_YEAR") .trim().toString());
                 _olcnn_Sl     = Integer.parseInt(  InputoBj.getValue("OLCCN_LC_SL") .trim().toString());
                 useroption =    InputoBj.getValue("USEROPTION") .trim().toString();
                }  
                Init_ResultObj(InputoBj);
                if(!String.valueOf(_branch_Code).trim().equalsIgnoreCase(""))
                {
                	if(_branch_Code==0) 
                		if ((InputoBj.containsKey("OLCCN_BRN_CODE") == true) && (InputoBj.getValue("OLCCN_BRN_CODE").trim().equalsIgnoreCase("")))
                			Resultobj.setValue(ErrorKey,BLANK_CHECK);
                        else
                        Resultobj.setValue(ErrorKey,ZERO_CHECK);
                }    
                if(String.valueOf(_olccn_Type).trim().equalsIgnoreCase(""))
                {
                    Resultobj.setValue(ErrorKey,BLANK_CHECK);
                }
                if(!String.valueOf(_olccn_Year).trim().equalsIgnoreCase(""))
                {
                	if(_olccn_Year==0) 
                		if ((InputoBj.containsKey("OLCCN_LC_TYPE") == true) && (InputoBj.getValue("OLCCN_LC_TYPE").trim().equalsIgnoreCase("")))
                			Resultobj.setValue(ErrorKey,BLANK_CHECK);
                        else
                        Resultobj.setValue(ErrorKey,ZERO_CHECK);
                }
                if(!String.valueOf(_olcnn_Sl).trim().equalsIgnoreCase(""))
                {
                	if(_olcnn_Sl==0) 
                		if ((InputoBj.containsKey("OLCCN_LC_SL") == true) && (InputoBj.getValue("OLCCN_LC_SL").trim().equalsIgnoreCase("")))
                			Resultobj.setValue(ErrorKey,BLANK_CHECK);
                        else
                        Resultobj.setValue(ErrorKey,ZERO_CHECK);
                }
                if(String.valueOf(useroption).trim().equalsIgnoreCase(""))
                {
                    Resultobj.setValue(ErrorKey,BLANK_CHECK);
                }
                if(Check_Result_Status())
                {
                   DTObject dtoinput = new DTObject();
                   OLCValidator olcval=new OLCValidator();
                   dtoinput.clearMap();
                   dtoinput.setValue("OLC_BRN_CODE",String.valueOf(_branch_Code));
                   dtoinput.setValue("OLC_LC_TYPE",String.valueOf(_olccn_Type));
                   dtoinput.setValue("OLC_LC_YEAR",String.valueOf(_olccn_Year));
                   dtoinput.setValue("OLC_LC_SL",String.valueOf(_olcnn_Sl));
                   dtoinput.setValue("FetchReq","true");
                   dtoinput.setValue("FetchColumns","OLC_LC_PRESANC_DATE, OLC_LC_PRESANC_DAY_SL,OLC_CORR_REF_NUM,OLC_LC_DATE,OLC_CUST_NUM,OLC_BENEF_CODE,OLC_BENEF_NAME,OLC_LC_ISS_BK_CODE,OLC_LC_ISS_BRN_CODE,OLC_LC_CURR_CODE,OLC_POS_DEV_ALLWD,OLC_LC_AMOUNT,OLC_DEV_AMOUNT,OLC_LC_BALANCE,OLC_CONV_RATE_BASE_CURR,OLC_LAST_DATE_OF_NEG,OLC_LATEST_DATE_OF_SHPMNT");
                   Resultobj=olcval.valolc(dtoinput);
                   
                   if(Check_Result_Status())
                   { 
	                   _olcSanctionedOnDate = Resultobj.getValue("OLC_LC_PRESANC_DATE");
	                   _olcSanctionedODAySl=Resultobj.getValue("OLC_LC_PRESANC_DAY_SL");
	                   _olcRefNum=Resultobj.getValue("OLC_CORR_REF_NUM");
	                   _olcDate = Resultobj.getValue("OLC_LC_DATE");
	                   _olcPriceTerms = Resultobj.getValue("OLC_PRICE_TERMS");
	                   _olcCurrCode = Resultobj.getValue("OLC_LC_CURR_CODE");
	                   _olcCustNum = Resultobj.getValue("OLC_CUST_NUM");
	                   _olcBnefCode = Resultobj.getValue("OLC_BENEF_CODE");
	                   _olcLcAmount = Resultobj.getValue("OLC_LC_AMOUNT");
	                   _olcLcposdevallwd = Resultobj.getValue("OLC_POS_DEV_ALLWD");
	                   _olcdevamt = Resultobj.getValue("OLC_DEV_AMOUNT");
	                   _olcTotLiabBaseCurr = Resultobj.getValue("OLC_TOT_LIAB_BASE_CURR");   
	                   _olcLatestDateShip = Resultobj.getValue("OLC_LATEST_DATE_OF_SHPMNT");
	                   _olcLatestDateNegotiation = Resultobj.getValue("OLC_LAST_DATE_OF_NEG");
	                   _olcPerInsValCvd = Resultobj.getValue("OLC_PERC_OF_INS_VALUE_CVRD"); 
	                   _olcBalanceAmount=Resultobj.getValue("OLC_LC_BALANCE");
	                   _olcconvratetobasecurr = Resultobj.getValue("OLC_CONV_RATE_BASE_CURR");
	                   _olcbankcode = Resultobj.getValue("OLC_LC_ISS_BK_CODE");
	                   _olcbrncode = Resultobj.getValue("OLC_LC_ISS_BRN_CODE");
                  }
                  if(Check_Result_Status())
                  {
                	  if(_olcbankcode!=null)
                	  {     	
                		  if(!(_olcbankcode.equalsIgnoreCase("")))
	        			  {
                			  CommonValidator comnval	=	new	CommonValidator();    
	        				  dtoinput.clearMap();
	        				  dtoinput.setValue("BANKCD_CODE",_olcbankcode);
	        				  Resultobj=comnval.valbankcd(dtoinput);
	        				  _olcbankName=Resultobj.getValue("BANKCD_NAME");
	        			  }
        				  if(Check_Result_Status())
                          {
        					  if(_olcbrncode!=null)
    	        			  {
        						  if(!(_olcbrncode.equalsIgnoreCase("")))
    	        				  {
        							  CommonValidator 	comnval	=	new	CommonValidator();
    	        					  dtoinput.clearMap();
    	        					  dtoinput.setValue("MBKBRN_BANK_CODE",_olcbankcode);
    	        					  dtoinput.setValue("MBKBRN_BRN_CODE",_olcbrncode);
    	        					  Resultobj=comnval.valmbkbrn(dtoinput);
    	        					  _olcbranchkName=Resultobj.getValue("MBKBRN_NAME");
    	        				  }
    	        			  }
                          }
	        		  }
                  }
                  if(Check_Result_Status())
	              {	
                	  if(_olcCustNum!=null)
	        		  {
                		  if(!(_olcCustNum.equalsIgnoreCase("")))
	        			  {
                			  ClientValidator 	clieval	=	new ClientValidator();
			    	          dtoinput.clearMap();
			    	          dtoinput.setValue("CLIENTS_CODE",_olcCustNum);
			    	          dtoinput.setValue(FetchReq,"true");
			    		      Resultobj=clieval.clientValid(dtoinput);
			    		      _olcCustName=Resultobj.getValue("CLIENTS_NAME");
	        			  }
	        		  }
	    	      }
	              if(Check_Result_Status())
	              {
	            	  if(_olcBnefCode!=null)
	        		  {
	            		  if(!(_olcBnefCode.equalsIgnoreCase("")))
	        			  {
	            			  TFMValidator   	tfmval	=	new	TFMValidator();
			            	  dtoinput.clearMap();
			            	  dtoinput.setValue("CPARTY_ALPHA_CODE",_olcBnefCode);
			            	  dtoinput.setValue(FetchReq,"true");
			    	    	  Resultobj=tfmval.valcparty(dtoinput);
			    	    	  _olcBeniefDesc=Resultobj.getValue("CPARTY_NAME");
	        			  }
	        		   }
	              }
                   
                  if(Check_Result_Status())
                  {
                	  _QueryStr = "select OLCCN_CAN_AMT,OLCCN_AUTH_BY,OLCCN_REJ_BY from OLCCAN  where OLCCN_BRN_CODE=? and  OLCCN_LC_TYPE=? and  OLCCN_LC_YEAR=? and  OLCCN_LC_SL=?";
                      Set_preparedStatement(_QueryStr);
                      _pstmt.setInt(1,_branch_Code);
                      _pstmt.setString(2, _olccn_Type);
                      _pstmt.setInt(3,_olccn_Year);
                      _pstmt.setInt(4, _olcnn_Sl);
                      Resultobj = Get_Value_From_Main("OLCCAN");
                      _olccncantamt = Resultobj.getValue("OLCCN_CAN_AMT");
                      _olccnauth = Resultobj.getValue("OLCCN_AUTH_BY");
                      _olccnrej = Resultobj.getValue("OLCCN_REJ_BY");
                      if(_olccnauth==null)
                      {
                    	  _olccnauth="";
                      }
                      if(_olccnrej==null)
                      {
                    	  _olccnrej="";
                      }
                      if(Check_Result_Status())
                      {
                    	  if((Resultobj.getValue(ResultKey).equalsIgnoreCase(RowNotPresent))&&(useroption.equalsIgnoreCase("M")))
                          {
                    		  Resultobj.setValue(ErrorKey,"Record Does Not Exist" );
                      		  return Resultobj.copyofDTO();
                          }
                    	  
                      }  
                  }
                 if(Check_Result_Status())
                 {
                	 dtoinput.clearMap();
                     dtoinput.setValue("BRANCH_CODE",String.valueOf(_branch_Code));
                     dtoinput.setValue("ENTRY_DATE",String.valueOf(_olcSanctionedOnDate));
                     dtoinput.setValue("DAY_SERIAL",String.valueOf(_olcSanctionedODAySl));
                     dtoinput.setValue("FetchReq","true");
                     dtoinput.setValue("FetchColumns","FACNO(LCPS_CUST_LIAB_ACC_NUM)LCPS_CUST_LIAB_ACC_NUM");//LCPS_PROD_CODE
                     Resultobj=olcval.vallcps(dtoinput);
                     _lcpscustliabaccnum = Resultobj.getValue("LCPS_CUST_LIAB_ACC_NUM");
                     if(Check_Result_Status())
                     {
                    	 AccountValidator av = new AccountValidator();
                    	 dtoinput.clearMap();
                         dtoinput.setValue("BRANCH_CODE",String.valueOf(_branch_Code));
                         dtoinput.setValue("ACCOUNT_NUMBER",String.valueOf(_lcpscustliabaccnum));
                         dtoinput.setValue("FetchReq","true");
                         dtoinput.setValue("FetchColumns","ACNTS_CURR_CODE");
                         Resultobj=av.chkacntstatus(dtoinput);
                         if(Check_Result_Status())
                         {
                        	 _intAccNum=Resultobj.getValue("ACNTS_INTERNAL_ACNUM");
                        	 _acntscurrcode=Resultobj.getValue("ACNTS_CURR_CODE");
                        	 CommonValidator  comnval2=new	CommonValidator();
                        	 dtoinput.clearMap();
                        	 dtoinput.setValue("CURR_CODE",_acntscurrcode);
                         	 Resultobj=comnval2.valcurrcd(dtoinput);
                         	 if(Check_Result_Status())
                             {
	                         	 _currencyName = Resultobj.getValue("CURR_NAME");
	                             _QueryStr = "Select nvl(max(OLCA_AMD_SL),0) MAX_AMDSL from OLCAMD where OLCA_BRN_CODE =? and OLCA_LC_TYPE = ? and OLCA_LC_YEAR =? and OLCA_LC_SL = ? ";
	                        	 Set_preparedStatement(_QueryStr);
	    	                     _pstmt.setInt(1, _branch_Code);
	    	                     _pstmt.setString(2, _olccn_Type);
	    	                     _pstmt.setInt(3, _olccn_Year);
	    	                     _pstmt.setInt(4, _olcnn_Sl);
	    	                     Resultobj=Get_Value_From_Main("OLCAMD");
	    	                     _max_amdsl=Resultobj.getValue("MAX_AMDSL");
                         
	    	                     if(Check_Result_Status())
	    	                     { 
	    	                    	 if(Integer.parseInt(_max_amdsl) > 0)
	    	                    	 {
	 	    	                	   OLCValidator olcval1=new OLCValidator();
	     	    	                   dtoinput.clearMap();
	     	    	                   dtoinput.setValue("BRANCH_CODE",String.valueOf(_branch_Code));
	     	    	                   dtoinput.setValue("LC_TYPE",String.valueOf(_olccn_Type));
	     	    	                   dtoinput.setValue("LC_YEAR",String.valueOf(_olccn_Year));
	     	    	                   dtoinput.setValue("LC_SERIAL",String.valueOf(_olcnn_Sl));
	     	    	                   dtoinput.setValue("AMENDMENT_SERIAL",String.valueOf(_max_amdsl));
	     	    	                   dtoinput.setValue("FetchReq","true");
	     	    	                   dtoinput.setValue("FetchColumns","OLCA_ENTRY_DATE, OLCA_LATEST_DATE_OF_SHPMNT, OLCA_LAST_DATE_OF_NEG, OLCA_AMENDED_AMT,OLCA_POS_DEV_ALLWD, OLCA_DEV_AMT, OLCA_CONV_RATE_BASE_CURR");
	     	    	                   Resultobj=olcval1.valolcamd(dtoinput);
	     	    	                   _olcaamendedamt = Resultobj.getValue("OLCA_AMENDED_AMT");
	     	    	                   _olcaconvratetobasecurr = Resultobj.getValue("OLCA_CONV_RATE_BASE_CURR");
	     	    	                   _olcaamendentydate = Resultobj.getValue("OLCA_ENTRY_DATE");
	     	    	                   _olcaamendedlastshpmnt= Resultobj.getValue("OLCA_LATEST_DATE_OF_SHPMNT");
	     	    	                   _olcaamendeddateneg = Resultobj.getValue("OLCA_LAST_DATE_OF_NEG");
	     	    	                  _olcaamendeddevalled = Resultobj.getValue("OLCA_POS_DEV_ALLWD");
	     	    	                  _olcaamendeddevamt = Resultobj.getValue("OLCA_DEV_AMT");
	    	                    	 }
	    	                     }
    	                  
	    	                     if(Check_Result_Status())
	    	                     {  
	    	                    	 if(Integer.parseInt(_max_amdsl) == 0 || _max_amdsl.equalsIgnoreCase(" "))
	    	                    	 {
	 	    	                	     _QueryStr = "Select OLCT_USANCE_INT_AMT from OLCTENORS where OLCT_BRN_CODE = ? and OLCT_LC_TYPE = ? and OLCT_LC_YEAR = ? and OLCT_LC_SL = ? " ;
	     	             				 Set_preparedStatement(_QueryStr);
	     	    	                     _pstmt.setInt(1, _branch_Code);
	     	    	                     _pstmt.setString(2, _olccn_Type);
	     	    	                     _pstmt.setInt(3,_olccn_Year);
	     	    	                     _pstmt.setInt(4,_olcnn_Sl);
	     	    	                     Resultobj=Get_Value_From_Main("OLCTENORS");
	     	    	                     _sumuseintamt = Double.parseDouble(Resultobj.getValue("OLCT_USANCE_INT_AMT"));
	     	    	                     if(Check_Result_Status())
	     	    	                     {
	     	    	                	     _lctotamt = ( Double.parseDouble(_olcLcAmount) + Double.parseDouble(_olcdevamt) + _sumuseintamt);
	     	    	                	     CommonValidator cv = new CommonValidator();
		     	    	          			 dtoinput.setValue("FOR_CURR",_olcCurrCode);
		     	    	          			 dtoinput.setValue("AGNST_CURR",baseCurrency);
		     	    	          			 dtoinput.setValue("AMT_FOR_CURR",String.valueOf(_lctotamt));
		     	    	          			 dtoinput.setValue("CONVER_RATE",String.valueOf(_olcconvratetobasecurr));
		     	    	          			 Resultobj = cv.calAgnstVal(dtoinput);
		     	    	          			 _againstamt = Double.parseDouble(Resultobj.getValue("AMT_AGNST_CURR"));
		     	    	          			 if(Check_Result_Status())
		     	    	          			 {
		     	    	          				 Resultobj.setValue(ErrorKey,"");
		     	    	          				 _declength =cbsglobal.getcurrdeclength(baseCurrency);
		     	    	          			 }
		     	    	          			 if(Check_Result_Status())
		     	    	          			 {
		     	    	          				 Resultobj.setValue(ErrorKey,"");
		     	    	          				 _declength1 =cbsglobal.getcurrdeclength(_olcCurrCode);
		     	    	          			 }
	     	    	                     }
			     	    	             if(Check_Result_Status())
		                                 {
			     	    	            	 _lctotamt1 = ( Double.parseDouble(_olcLcAmount) - Double.parseDouble(_olcBalanceAmount) );
		     	    	                	 CommonValidator cv1 = new CommonValidator();
			     	    	          		 dtoinput.setValue("FOR_CURR",_olcCurrCode);
			     	    	          		 dtoinput.setValue("AGNST_CURR",baseCurrency);
			     	    	          		 dtoinput.setValue("AMT_FOR_CURR",String.valueOf(_lctotamt1));
			     	    	          		 dtoinput.setValue("CONVER_RATE",String.valueOf(_olcconvratetobasecurr));
			     	    	          		 Resultobj = cv1.calAgnstVal(dtoinput);
			     	    	          		 _againstamt1 = Double.parseDouble(Resultobj.getValue("AMT_AGNST_CURR"));
			     	    	          	 }
			     	    	             if(Check_Result_Status())
			     	    	             {
			     	    	            	W_cancelled_amount = Double.parseDouble(_olcBalanceAmount) + Double.parseDouble(_olccncantamt);
	     	    	                	    CommonValidator cv2 = new CommonValidator();
		     	    	          			dtoinput.setValue("FOR_CURR",_olcCurrCode);
		     	    	          			dtoinput.setValue("AGNST_CURR",baseCurrency);
		     	    	          			dtoinput.setValue("AMT_FOR_CURR",String.valueOf(W_cancelled_amount));
		     	    	          			dtoinput.setValue("CONVER_RATE",String.valueOf(_olcconvratetobasecurr));
		     	    	          			Resultobj = cv2.calAgnstVal(dtoinput);
		     	    	          			_againstamt2 = Double.parseDouble(Resultobj.getValue("AMT_AGNST_CURR"));
	     	    	          	         }
	    	                    	 }
	    	                    	 else if(Integer.parseInt(_max_amdsl) > 0)
	    	                    	 {
	 	    	                	     _QueryStr = "Select OLCTA_USANCE_INT_AMT from OLCTENORSAMD where OLCTA_BRN_CODE = ? and OLCTA_LC_TYPE = ? and OLCTA_LC_YEAR = ? and OLCTA_LC_SL = ? and OLCTA_AMD_SL=?" ;
	     	             				 Set_preparedStatement(_QueryStr);
	     	    	                     _pstmt.setInt(1, _branch_Code);
	     	    	                     _pstmt.setString(2, _olccn_Type);
	     	    	                     _pstmt.setInt(3,_olccn_Year);
	     	    	                     _pstmt.setInt(4,_olcnn_Sl);
	     	    	                     _pstmt.setInt(5,Integer.parseInt(_max_amdsl));
	     	    	                     Resultobj=Get_Value_From_Main("OLCTENORSAMD");
	     	    	                     _sumuseintamt = Double.parseDouble(Resultobj.getValue("OLCTA_USANCE_INT_AMT"));
	     	    	                    
     	    	                   if(Check_Result_Status())
                                   { 
     	    	                	    _lctotamt = ( Double.parseDouble(_olcaamendedamt) + Double.parseDouble(_olcaamendeddevamt) + _sumuseintamt);
     	    	                	    CommonValidator cv3 = new CommonValidator();
	     	    	          			dtoinput.setValue("FOR_CURR",_olcCurrCode);
	     	    	          			dtoinput.setValue("AGNST_CURR",baseCurrency);
	     	    	          			dtoinput.setValue("AMT_FOR_CURR",String.valueOf(_lctotamt));
	     	    	          			dtoinput.setValue("CONVER_RATE",String.valueOf(_olcaconvratetobasecurr));
	     	    	          			Resultobj = cv3.calAgnstVal(dtoinput);
	     	    	          			_againstamt = Double.parseDouble(Resultobj.getValue("AMT_AGNST_CURR"));
	     	    	          			
	     	    	          		   if(Check_Result_Status())
	                                   {
		     	    	          			Resultobj.setValue(ErrorKey,"");
		     	    	          			_declength =cbsglobal.getcurrdeclength(baseCurrency);
	                                   }
	     	    	          		   
	     	    	          		if(Check_Result_Status())
	                                   {
		     	    	          			Resultobj.setValue(ErrorKey,"");
		     	    	          			_declength1 =cbsglobal.getcurrdeclength(_olcCurrCode);
	                                   }
	     	    	          	   }
     	    	                   
     	    	                  if(Check_Result_Status())
                                   {
     	    	                	   _lctotamt1 = ( Double.parseDouble(_olcaamendedamt) - Double.parseDouble(_olcBalanceAmount) );
     	    	                	   CommonValidator cv4 = new CommonValidator();
	     	    	          			dtoinput.setValue("FOR_CURR",_olcCurrCode);
	     	    	          			dtoinput.setValue("AGNST_CURR",baseCurrency);
	     	    	          			dtoinput.setValue("AMT_FOR_CURR",String.valueOf(_lctotamt1));
	     	    	          			dtoinput.setValue("CONVER_RATE",String.valueOf(_olcaconvratetobasecurr));
	     	    	          			Resultobj = cv4.calAgnstVal(dtoinput);
	     	    	          			_againstamt1 = Double.parseDouble(Resultobj.getValue("AMT_AGNST_CURR"));
	     	    	          	   }
     	    	                  
     	    	                 if(Check_Result_Status())
                                   {
     	    	                	   W_cancelled_amount = Double.parseDouble(_olcBalanceAmount) +  Double.parseDouble(_olccncantamt);
     	    	                	    CommonValidator cv5 = new CommonValidator();
	     	    	          			dtoinput.setValue("FOR_CURR",_olcCurrCode);
	     	    	          			dtoinput.setValue("AGNST_CURR",baseCurrency);
	     	    	          			dtoinput.setValue("AMT_FOR_CURR",String.valueOf(W_cancelled_amount));
	     	    	          			dtoinput.setValue("CONVER_RATE",String.valueOf(_olcaconvratetobasecurr));
	     	    	          			Resultobj = cv5.calAgnstVal(dtoinput);
	     	    	          			_againstamt2 = Double.parseDouble(Resultobj.getValue("AMT_AGNST_CURR"));
	     	    	          	   }
     	    	               }
 	    	              }
                             }
                         }	
                     }
                 }
                   }
                   Resultobj.setValue("OLC_CORR_REF_NUM",_olcRefNum);
                   Resultobj.setValue("OLC_LC_DATE",_olcDate);
                   Resultobj.setValue("OLC_CUST_NUM",_olcCustNum);
                   Resultobj.setValue("CLIENTS_NAME",_olcCustName);
                   Resultobj.setValue("OLC_BENEF_CODE",_olcBnefCode);
                   Resultobj.setValue("CPARTY_NAME",_olcBeniefDesc);
                   Resultobj.setValue("LCPS_PROD_CODE",_lcpsprodcode);
                   Resultobj.setValue("ACNTS_CURR_CODE",_acntscurrcode);
                   Resultobj.setValue("PRESANC_DATE",_olcSanctionedOnDate);
                   Resultobj.setValue("OLC_LC_PRESANC_DAY_SL",_olcSanctionedODAySl);
                   Resultobj.setValue("OLC_LC_ISS_BK_CODE",_olcbankcode);
                   Resultobj.setValue("BANKCD_NAME",_olcbankName);
                   Resultobj.setValue("OLC_LC_ISS_BRN_CODE",_olcbrncode);
                   Resultobj.setValue("MBKBRN_NAME",_olcbranchkName);
                   Resultobj.setValue("OLC_PRICE_TERMS",_olcPriceTerms);
                   Resultobj.setValue("OLC_LC_CURR_CODE",_olcCurrCode);
                   Resultobj.setValue("CURR_NAME",_currencyName);
                   Resultobj.setValue("OLC_LC_AMOUNT",_olcLcAmount);
                   Resultobj.setValue("OLC_POS_DEV_ALLWD",_olcLcposdevallwd);
                   Resultobj.setValue("OLC_TOT_LIAB_BASE_CURR",_olcTotLiabBaseCurr);   
                   Resultobj.setValue("OLC_LATEST_DATE_OF_SHPMNT",_olcLatestDateShip); 
                   Resultobj.setValue("OLC_LAST_DATE_OF_NEG",_olcLatestDateNegotiation);
                   Resultobj.setValue("OLC_PERC_OF_INS_VALUE_CVRD",_olcPerInsValCvd); 
                   Resultobj.setValue("OLC_LC_BALANCE",_olcBalanceAmount);
                   Resultobj.setValue("OLC_CONV_RATE_BASE_CURR",_olcconvratetobasecurr);
                   Resultobj.setValue("OLCCN_CAN_AMT",_olccncantamt);
                   Resultobj.setValue("MAX_AMND_SL",_max_amdsl); 
                   Resultobj.setValue("OLCA_AMENDED_AMT",_olcaamendedamt);
                   Resultobj.setValue("OLCA_CONV_RATE_BASE_CURR",_olcaconvratetobasecurr);
                   Resultobj.setValue("OLCA_ENTRY_DATE",_olcaamendentydate);
                   Resultobj.setValue("OLCA_LATEST_DATE_OF_SHPMNT",_olcaamendedlastshpmnt);
                   Resultobj.setValue("OLCA_LAST_DATE_OF_NEG",_olcaamendeddateneg);
                   Resultobj.setValue("OLCA_POS_DEV_ALLWD",_olcaamendeddevalled);
                   // Yasodha.D 03.08.2011 Changed Begin
                   /*
                   Resultobj.setValue("USANCE_INTEREST",String.valueOf(_sumuseintamt));
                   Resultobj.setValue("TOT_LC_LIAB",String.valueOf(_lctotamt));
                   Resultobj.setValue("LC_LIAB_REV_SOFAR",String.valueOf(_lctotamt1));
                   Resultobj.setValue("LC_LIAB_REV_DUETO_CURR_CANCEL",String.valueOf(W_cancelled_amount));
                   */
                   if(_olcCurrCode.equalsIgnoreCase(baseCurrency))
                   {
                	   Resultobj.setValue("USANCE_INTEREST",RoundOffunc(_olcDate,String.valueOf(_sumuseintamt),"N"));
                       Resultobj.setValue("TOT_LC_LIAB",RoundOffunc(_olcDate,String.valueOf(_lctotamt),"N"));
                       Resultobj.setValue("LC_LIAB_REV_SOFAR",RoundOffunc(_olcDate,String.valueOf(_lctotamt1),"N"));
                       Resultobj.setValue("LC_LIAB_REV_DUETO_CURR_CANCEL",RoundOffunc(_olcDate,String.valueOf(W_cancelled_amount),"N"));
                   }
                   else
                   {
                	   Resultobj.setValue("USANCE_INTEREST",String.valueOf(FormatDoubleValue(_sumuseintamt)));
                       Resultobj.setValue("TOT_LC_LIAB",String.valueOf(FormatDoubleValue(_lctotamt)));
                       Resultobj.setValue("LC_LIAB_REV_SOFAR",String.valueOf(FormatDoubleValue(_lctotamt1)));
                       Resultobj.setValue("LC_LIAB_REV_DUETO_CURR_CANCEL",String.valueOf(FormatDoubleValue(W_cancelled_amount)));
                   }
                   // Resultobj.setValue("BASE_EQU_TOT_LC_LIAB_AMT",String.valueOf(_againstamt));
                   Resultobj.setValue("BASE_EQU_TOT_LC_LIAB_AMT",RoundOffunc(_olcDate,String.valueOf(_againstamt),"N"));
                   // Resultobj.setValue("BASE_EQU_LC_LIAB_REV_AMT",String.valueOf(_againstamt1));
                   Resultobj.setValue("BASE_EQU_LC_LIAB_REV_AMT",RoundOffunc(_olcDate,String.valueOf(_againstamt1),"N"));
                   // Resultobj.setValue("BASE_EQ_LC_LIAB_BE_REV_CURR_CANCEL_AMT",String.valueOf(_againstamt2));
                   Resultobj.setValue("BASE_EQ_LC_LIAB_BE_REV_CURR_CANCEL_AMT",RoundOffunc(_olcDate,String.valueOf(_againstamt2),"N"));
                   // Yasodha.D 03.08.2011 Changed Begin
                   Resultobj.setValue("OLC_DEV_AMT",_olcdevamt);
                   Resultobj.setValue("OLCA_DEV_AMT",_olcaamendeddevamt);
                   Resultobj.setValue("BASE_CURR_LENGTH",String.valueOf(_declength));
                   Resultobj.setValue("LC_CURR_LENGTH",String.valueOf(_declength1));
                   Resultobj.setValue("INT_ACC_NUM",_intAccNum);
              }
       catch(Exception e)
            {
                Resultobj.setValue(ErrorKey,"Error in olcLcSlkeypress" );
            }
        return Resultobj.copyofDTO();
        }
  
    
//  *********************************************************************************************************      
   // Changes P.Subramani-Chn-15/10/2008 End    
 // Yasodha.D 03.08.2011 Added End
	public String RoundOffunc(String candate, String Amt, String type)
	{
		String roundoffamt = "";
		CallableStatement _cstmt=null;
		try
		{
			openConnection();
			_cstmt = connDB.prepareCall("CALL PKG_FX_RND_PARAM.SP_FX_ROUNDOFF(TO_DATE(?,'DD-MM-YYYY'),?,?,?)");
			_cstmt.setString(1,candate);
			_cstmt.setString(2,Amt);
			_cstmt.setString(3,type);
			_cstmt.registerOutParameter(4,Types.INTEGER);
			_cstmt.execute();
			roundoffamt	=  _cstmt.getString(4);
		}
        catch ( SQLException sqlExcep)
        {
    		 Resultobj.setValue(ErrorKey,"Error in Calculating RoundOff");   
        }
        finally{
            try{
                _cstmt.close();
                closeConnection();
            }catch(Exception Excep){}
		}
        return (roundoffamt);
 	}
//  *********************************************************************************************************      
	// Yasodha.D 03.08.2011 Added End
}


