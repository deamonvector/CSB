package panacea.OLCaction;

import java.sql.ResultSet;
import panacea.common.DTObject;
import panacea.common.DateUtility;
import panacea.common.FormatUtils;
import panacea.Validator.AccountValidator;
import panacea.Validator.BranchValidator;
import panacea.Validator.ClientValidator;
import panacea.Validator.CommonValidator;
import panacea.Validator.DDPOValidator;
import panacea.Validator.FCSValidator;
import panacea.Validator.GlValidator;
import panacea.Validator.IRSValidator;
import panacea.Validator.LimitValidator;
import panacea.Validator.LoansValidator;
import panacea.Validator.OLCValidator;
import panacea.Validator.ORSValidator;
import panacea.Validator.ProductValidator;
import panacea.Validator.SwiftValidator;
import panacea.Validator.TFMValidator;
import panacea.Validator.WebManager;
import panacea.Validator.cbsglobal;

import java.io.BufferedReader;
import java.io.Reader;
import java.rmi.RemoteException;
import java.sql.Clob;
import java.sql.SQLException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.sql.CallableStatement;
import java.sql.Types;

public class eolcamdval extends WebManager

{

	BranchValidator brnval = new BranchValidator();
	IRSValidator irsval = new IRSValidator();
	DDPOValidator ddpoval = new DDPOValidator();
	ClientValidator clieval = new ClientValidator();
	OLCValidator olcval = new OLCValidator();
	CommonValidator comnval = new CommonValidator();
	TFMValidator tfmval = new TFMValidator();
	AccountValidator accval = new AccountValidator();
	LimitValidator limval = new LimitValidator();
	ProductValidator pv = new ProductValidator();
	GlValidator glval = new GlValidator();
	LoansValidator loval = new LoansValidator();
	FCSValidator fcsval = new FCSValidator();
	SwiftValidator swval = new SwiftValidator();//Changes in EOLCAMD on 16-Oct-2018
	DTObject dtobj = new DTObject();
	String _limitlineHidden = "";
	String custnoHidden = "";
	DTObject dto_good1 = new DTObject();

	// *********************************************************************************************************
	/*
	 * Input 	- 						Key =OLC_BRN_CODE
	 * Output	: Error Message  		- 		Key = ErrorMsg
	 */

	public DTObject olcBrnCodekeypress(DTObject InputoBj) {
		try {

			int _olcBrnCode = 0;
			if (InputoBj.getValue("OLC_BRN_CODE").trim().equalsIgnoreCase("")) {
				_olcBrnCode = 0;
			} else {
				_olcBrnCode = Integer.parseInt(InputoBj.getValue("OLC_BRN_CODE").trim().toString());
			}
			//CHANGED ADDED ON 25/07/2018 START

			int _brnAuthcount = 0;
			String _userRoleCode = "";
			if (InputoBj.containsKey("USER_ROLE_CODE")) {
				if (InputoBj.getValue("USER_ROLE_CODE").trim().equalsIgnoreCase("")) {
					_userRoleCode = "";
				} else {
					_userRoleCode = InputoBj.getValue("USER_ROLE_CODE").trim().toString();
				}
			} else {
				_userRoleCode = "";
			}

			//CHANGED ADDED ON 25/07/2018 END 

			Init_ResultObj(InputoBj);
			if (String.valueOf(_olcBrnCode).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (Check_Result_Status()) {
				if (!String.valueOf(_olcBrnCode).trim().equalsIgnoreCase("")) {
					if (_olcBrnCode == 0)
						if (InputoBj.containsKey("OLC_BRN_CODE") == true && InputoBj.getValue("OLC_BRN_CODE").equalsIgnoreCase(""))
							Resultobj.setValue(ErrorKey, BLANK_CHECK);
						else
							Resultobj.setValue(ErrorKey, ZERO_CHECK);
				}
			}

			if (Check_Result_Status()) {
				dtobj.clearMap();
				dtobj.setValue("MBRN_CODE", String.valueOf(_olcBrnCode));
				Resultobj = brnval.chkBrnValid(dtobj);

			}

			//CHANGED ADDED ON 25/07/2018 START

			if (Check_Result_Status()) {
				_QueryStr = "SELECT COUNT(*) FROM USERROLES WHERE UROLE_CODE = ? AND UROLE_ACCESS_FOR_BRN_DATA ='3' ";
				Set_preparedStatement(_QueryStr);
				_pstmt.setString(1, _userRoleCode);

				ResultSet rs1 = ExecuteQuery();
				if (rs1.next()) {
					_brnAuthcount = rs1.getInt(1);
					if (_brnAuthcount > 0) {
						Resultobj.setValue("USER_BRN_AUTH", "1");
					} else {
						Resultobj.setValue("USER_BRN_AUTH", "0");
					}
				}
			}

			//CHANGED ADDED ON 25/07/2018 END

		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in olcBrnCodekeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	// *********************************************************************************************************
	/*
	 * Input 	- 						Key =OLC_LC_TYPE
	 * Output	: Error Message  		- 		Key = ErrorMsg
	 */

	public DTObject olcLcTypekeypress(DTObject InputoBj) {
		try {
			String _olcLcType = "";
			String _tnomenLcBill = "";
			String _tnomenIwOw = "";
			String _tnomenNumChoice = "";
			String _coll_prod = "";
			String _prodesc = "";
			String _tenomen_auto_num = "";
			int _rowcount = 0;//CHANGED ADDED ON 25/07/2018
			{
				_olcLcType = InputoBj.getValue("OLC_LC_TYPE").trim().toString();
			}
			Init_ResultObj(InputoBj);
			if (String.valueOf(_olcLcType).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}

			if (Check_Result_Status()) {
				dtobj.clearMap();
				dtobj.setValue("TNOMEN_NOMEN_CODE", _olcLcType);
				dtobj.setValue(FetchReq, "true");
				dtobj.setValue("FetchColumns", "TNOMEN_LC_BILL_BG, TNOMEN_IW_OW, TNOMEN_NUM_CHOICE,TNOMEN_AUTO_NUM");
				Resultobj = tfmval.valtnomen(dtobj);
			}
			if (Check_Result_Status()) {
				_tnomenLcBill = Resultobj.getValue("TNOMEN_LC_BILL_BG");
				_tnomenIwOw = Resultobj.getValue("TNOMEN_IW_OW");
				_tnomenNumChoice = Resultobj.getValue("TNOMEN_NUM_CHOICE");
				_tenomen_auto_num = Resultobj.getValue("TNOMEN_AUTO_NUM");
				if (!_tnomenLcBill.equalsIgnoreCase("L")) {
					Resultobj.setValue(ErrorKey, "LC Type Should be Marked for Letter of Credit");
				}
				if (!_tnomenIwOw.equalsIgnoreCase("O")) {
					Resultobj.setValue(ErrorKey, "LC Type Should be Marked for Outward");
				}
				_QueryStr = "Select TRAC_COLL_PROD FROM TRACPARAM WHERE TRAC_NOMEN_CODE =?";
				Set_preparedStatement(_QueryStr);
				_pstmt.setString(1, _olcLcType);
				Resultobj = Get_Value_From_Main("TRACPARAM");
				if (Check_Result_Status()) {
					_coll_prod = Resultobj.getValue("TRAC_COLL_PROD");
					if (Check_Result_Status()) {
						ProductValidator pv = new ProductValidator();
						DTObject dtoinput1 = new DTObject();
						dtoinput1.setValue("PRODUCT_CODE", _coll_prod);
						Resultobj = pv.prodValid(dtoinput1);
						if (Check_Result_Status()) {
							_prodesc = Resultobj.getValue("PRODUCT_NAME");
							Resultobj.setValue(ErrorKey, "");
							Resultobj.setValue("TNOMEN_NUM_CHOICE", _tnomenNumChoice);
							Resultobj.setValue("TNOMEN_AUTO_NUM", String.valueOf(_tenomen_auto_num));
							Resultobj.setValue("PRODUCT_CODE", _coll_prod);
							Resultobj.setValue("PRODUCT_DESC", _prodesc);
						}
					}
				}
			}

			//CHANGED ADDED ON 25/07/2018 START

			if (Check_Result_Status()) {
				_QueryStr = "SELECT COUNT(*) FROM SWIFTDISPLAY WHERE SWIFTDISPLAY_NOMEN = ? ";
				Set_preparedStatement(_QueryStr);
				_pstmt.setString(1, _olcLcType);

				ResultSet rs1 = ExecuteQuery();
				if (rs1.next()) {
					_rowcount = rs1.getInt(1);
					if (_rowcount > 0) {
						Resultobj.setValue("BRN_AUTH_LCTYPE", "1");
					} else {
						Resultobj.setValue("BRN_AUTH_LCTYPE", "0");
					}
				}
			}

			//CHANGED ADDED ON 25/07/2018 END

		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in olcLcTypekeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	// *********************************************************************************************************
	/*
	 * Input 	- 						Key =OLC_LC_YEAR
	 * 											 TNOMEN_NUM_CHOICE
	 * 											 TNOMEN_AUTO_NUM 
	 * 											  BRANCH_CODE
	 * 											LC_TYPE
	 * 											CBD
	 * 											
	 * 			
	 * Output	: Error Message  		- 		Key = ErrorMsg
	 */

	public DTObject olcLcYearkeypress(DTObject InputoBj) {
		try {
			int _olcLcYear = 0;
			String _tenomen_num_choice = "";
			String _tenomen_auto_num = "";
			int _branch_code = 0;
			String _currBusDate = "";
			String _ic_type = "";

			if (InputoBj.getValue("OLC_LC_YEAR").trim().equalsIgnoreCase("")) {
				_olcLcYear = 0;
			} else {
				_olcLcYear = Integer.parseInt(InputoBj.getValue("OLC_LC_YEAR").trim().toString());
				_tenomen_num_choice = InputoBj.getValue("TNOMEN_NUM_CHOICE").trim().toString();
				_tenomen_auto_num = InputoBj.getValue("TNOMEN_AUTO_NUM").trim().toString();
				_branch_code = Integer.parseInt(InputoBj.getValue("BRANCH_CODE").trim().toString());
				_ic_type = InputoBj.getValue("LC_TYPE").trim().toString();
				_currBusDate = InputoBj.getValue("CBD").trim().toString();

			}
			Init_ResultObj(InputoBj);

			if (String.valueOf(_olcLcYear).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (Check_Result_Status()) {
				if ((_tenomen_num_choice.equalsIgnoreCase("C")) && (_olcLcYear > Integer.parseInt(_currBusDate.substring(6, 10)))) {
					Resultobj.setValue(ErrorKey, "Reference Year Should be <= Current Year");
				}

				else if ((_tenomen_auto_num.equalsIgnoreCase("F")) && (_olcLcYear > Integer.parseInt(getFinYear(_currBusDate)))) {
					Resultobj.setValue(ErrorKey, "Reference Year Should be <= Finacial Year");
				}
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in olcLcYearkeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	// *********************************************************************************************************
	/*
	 * Input 	- 						Key =OLC_LC_SL
	 * 										 BRANCH_CODE
	 * 										 OLC_TYPE
	 * 										 OLC_YEAR
	 * 										 OLCA_AMD_SL
	 * 										 OPTION	
	 * Output	: Error Message  		- 		Key = ErrorMsg
	 * 											Key=AMD_SERIAL
	 */

	public DTObject olcLcSlkeypress(DTObject InputoBj) {
		try {
			int _olcLcSl = 0;
			int _branchCode = 0;
			int _olcYear = 0;
			String _olctype = "";
			String _option = "";
			String _max_SL = "";
			int _amdSl = 0;
			String _custRef = "";
			String _benefCode = "";
			String _benefName = "";
			String _addr1 = "";
			String _addr2 = "";
			String _addr3 = "";
			String _addr4 = "";
			String _addr5 = "";
			String _lcdate = "";
			String _lcissBank = "";
			String _lcissBranch = "";
			String _lcissPlace = "";
			String _lcissCountry = "";
			String _lcAmt = "";
			String _lcBal = "";
			String _lcCurr = "";
			String _custNum = "";
			String _countryCode = "";
			int _lcpsl = 0;
			String _lcpsdate = "";
			String _liabAcc = "";
			String _limitCurr = "";
			String _limitline = "";
			double _totalliabbasecurr = 0;
			String _drawDown = null;
			String _olcDevBal = "";
			String _declength1 = "";
			String _positiveDeviAllowed = "";
			//Changes P.Subramani-Chn-01/04/2008
			// String _lccustletterdate="";
			//String _lccustletternum="";
			//Changes P.Subramani-Chn-04/04/2008 Beg
			String custname = "";
			String bankname = "";
			String branchname = "";
			String countryname = "";
			String custadd1 = "";
			String custadd2 = "";
			String custadd3 = "";
			String custadd4 = "";
			String custadd5 = "";
			int rownum = 0;
			String authby = "";
			String rejby = "";
			//Changes P.Subramani-Chn-04/04/2008 End
			if (InputoBj.getValue("OLC_LC_SL").trim().equalsIgnoreCase("")) {
				_olcLcSl = 0;
			} else {
				_olcLcSl = Integer.parseInt(InputoBj.getValue("OLC_LC_SL").trim().toString());
				_branchCode = Integer.parseInt(InputoBj.getValue("BRANCH_CODE").trim().toString());
				_olcYear = Integer.parseInt(InputoBj.getValue("OLC_YEAR").trim().toString());
				_olctype = InputoBj.getValue("OLC_TYPE").trim().toString();
				_option = InputoBj.getValue("OPTION").trim().toString();

			}
			Init_ResultObj(InputoBj);
			if (!String.valueOf(_olcLcSl).trim().equalsIgnoreCase("")) {
				if (_olcLcSl == 0)
					if ((InputoBj.containsKey("OLC_LC_SL") == true) && (InputoBj.getValue("OLC_LC_SL").trim().equalsIgnoreCase("")))
						Resultobj.setValue(ErrorKey, BLANK_CHECK);
					else
						Resultobj.setValue(ErrorKey, ZERO_CHECK);
			}
			//Changes Sanjay 12 aug 19 Begin
			if (Check_Result_Status()) {
				_QueryStr = "SELECT OLCCN_AUTH_BY,OLCCN_REJ_BY,ROWNUM FROM OLCCAN WHERE OLCCN_BRN_CODE = ? AND OLCCN_LC_TYPE = ? AND OLCCN_LC_YEAR = ? AND OLCCN_LC_SL = ?";
				Set_preparedStatement(_QueryStr);
				_pstmt.setInt(1, _branchCode);
				_pstmt.setString(2, _olctype);
				_pstmt.setInt(3, _olcYear);
				_pstmt.setInt(4, _olcLcSl);
				Resultobj = Get_Value_From_Main("OLCCAN");
				if (Check_Result_Status()) 
				{
					if(Resultobj.getValue("ROWNUM") != null)
					{
						rownum = Integer.parseInt(Resultobj.getValue("ROWNUM"));
						authby = Resultobj.getValue("OLCCN_AUTH_BY");
						rejby = Resultobj.getValue("OLCCN_REJ_BY");
						if(rownum == 1 && authby == null  && rejby == null)
						{
							Resultobj.setValue(ErrorKey, "Unauthorised Cancellation record in Queue. Cannot Proceed!");
						}
						else if(rownum == 1 && authby != null && rejby == null)
						{
							Resultobj.setValue(ErrorKey, "LC is Cancelled. Cannot Proceed!");
						}
						else if(rownum == 1 && authby == null && rejby != null)
						{
							Resultobj.setValue(ErrorKey, "");
						}
					}
				}
			}
			//Changes Sanjay 12 aug 19 End
			if (Check_Result_Status()) {
				dtobj.clearMap();
				dtobj.setValue("OLC_LC_TYPE", _olctype);
				dtobj.setValue("OLC_BRN_CODE", String.valueOf(_branchCode));
				dtobj.setValue("OLC_LC_YEAR", String.valueOf(_olcYear));
				dtobj.setValue("OLC_LC_SL", String.valueOf(_olcLcSl));
				dtobj.setValue(FetchReq, "true");
				dtobj
						.setValue(
								"FetchColumns",
								"OLC_POS_DEV_ALLWD,OLC_DEV_BAL,OLC_LC_PRESANC_DATE, OLC_LC_PRESANC_DAY_SL,OLC_CORR_REF_NUM, OLC_LC_DATE, OLC_CUST_NUM, OLC_BENEF_CODE, OLC_BENEF_NAME, OLC_BENEF_ADDR1, OLC_BENEF_ADDR2, OLC_BENEF_ADDR3, OLC_BENEF_ADDR4, OLC_BENEF_ADDR5, OLC_BENEF_CNTRY_CODE, OLC_LC_ISS_BK_CODE, OLC_LC_ISS_BRN_CODE, OLC_LC_ISS_PLACE, OLC_LC_ISS_CNTRY, OLC_LC_ADV_THRU, OLC_LC_CURR_CODE, OLC_LC_AMOUNT, OLC_LC_BALANCE, OLC_DEV_ALLWD, OLC_POS_DEV_ALLWD, OLC_NEG_DEV_ALLWD, OLC_DEV_AMOUNT, OLC_AMT_QUALFR, OLC_PRICE_TERMS, OLC_LAST_DATE_OF_NEG, OLC_PLACE_OF_EXPIRY, OLC_LATEST_DATE_OF_SHPMNT, OLC_WITHIN_VALIDATE_LC, OLC_LC_UI_BORNE_BY_APPLCNT, OLC_NOF_TENORS, OLC_TOT_LIAB_LC_CURR, OLC_CONV_RATE_BASE_CURR, OLC_TOT_LIAB_BASE_CURR, OLC_CONV_RATE_LIM_CURR, OLC_TOT_LIAB_LIM_CURR,OLC_AUTH_BY,OLC_REJ_BY");
				Resultobj = olcval.valolc(dtobj);
				if (Check_Result_Status() == true) {
					if (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowNotPresent)) {
						Resultobj.setValue(ErrorKey, "No Documentation For This LC");
					} else { //Changes P.Subramani-Chn-11/09/2008 Beg
						if (Resultobj.getValue("OLC_AUTH_BY") == null) {
							Resultobj.setValue(ErrorKey, "LC Not Authorised, Should Not Amend");
						} else if (Resultobj.getValue("OLC_REJ_BY") != null) {
							Resultobj.setValue(ErrorKey, "LC Rejected, Should not Amend");
						}//Changes P.Subramani-Chn-11/09/2008 End
						else {
							_custRef = Resultobj.getValue("OLC_CORR_REF_NUM");
							_addr1 = Resultobj.getValue("OLC_BENEF_ADDR1");
							_addr2 = Resultobj.getValue("OLC_BENEF_ADDR2");
							_addr3 = Resultobj.getValue("OLC_BENEF_ADDR3");
							_addr4 = Resultobj.getValue("OLC_BENEF_ADDR4");
							_addr5 = Resultobj.getValue("OLC_BENEF_ADDR5");
							_benefCode = Resultobj.getValue("OLC_BENEF_CODE");
							_benefName = Resultobj.getValue("OLC_BENEF_NAME");
							_lcAmt = Resultobj.getValue("OLC_LC_AMOUNT");
							_lcBal = Resultobj.getValue("OLC_LC_BALANCE");
							_lcCurr = Resultobj.getValue("OLC_LC_CURR_CODE");
							_lcdate = Resultobj.getValue("OLC_LC_DATE");
							_lcissBank = Resultobj.getValue("OLC_LC_ISS_BK_CODE");
							_lcissBranch = Resultobj.getValue("OLC_LC_ISS_BRN_CODE");
							_lcissCountry = Resultobj.getValue("OLC_LC_ISS_CNTRY");
							_lcissPlace = Resultobj.getValue("OLC_LC_ISS_PLACE");
							_custNum = Resultobj.getValue("OLC_CUST_NUM");
							custnoHidden = _custNum;
							_positiveDeviAllowed = Resultobj.getValue("OLC_POS_DEV_ALLWD");
							_olcDevBal = Resultobj.getValue("OLC_DEV_BAL");
							_countryCode = Resultobj.getValue("OLC_BENEF_CNTRY_CODE");
							_lcpsdate = Resultobj.getValue("OLC_LC_PRESANC_DATE");
							_drawDown = Resultobj.getValue("OLC_NOF_TENORS");
							_lcpsl = Integer.parseInt(Resultobj.getValue("OLC_LC_PRESANC_DAY_SL"));
							_totalliabbasecurr = Double.parseDouble(Resultobj.getValue("OLC_TOT_LIAB_BASE_CURR"));
							//Changes P.Subramani-Chn-04/04/2008 Beg

							if (_custNum != null) {
								if (!_custNum.equalsIgnoreCase("")) {
									ClientValidator clieval = new ClientValidator();
									dtobj.clearMap();
									dtobj.setValue("CLIENTS_CODE", _custNum);
									dtobj.setValue(FetchReq, "true");
									Resultobj = clieval.clientValid(dtobj);
									custname = Resultobj.getValue("CLIENTS_NAME");
									custadd1 = Resultobj.getValue("CLIENTS_ADDR1");
									custadd2 = Resultobj.getValue("CLIENTS_ADDR2");
									custadd3 = Resultobj.getValue("CLIENTS_ADDR3");
									custadd4 = Resultobj.getValue("CLIENTS_ADDR4");
									custadd5 = Resultobj.getValue("CLIENTS_ADDR5");
								}
							}

							if (_lcissBranch != null) {
								if (!_lcissBranch.equalsIgnoreCase("")) {
									BranchValidator BV = new BranchValidator();
									dtobj.clearMap();
									dtobj.setValue("MBRN_CODE", _lcissBranch);
									Resultobj = BV.chkBrnValid(dtobj);
									branchname = Resultobj.getValue("MBRN_NAME");
								}
							}

							if (_lcissBank != null) {
								if (!_lcissBank.equalsIgnoreCase("")) {
									CommonValidator CV = new CommonValidator();
									dtobj.clearMap();
									dtobj.setValue("BANKCD_CODE", _lcissBank);
									Resultobj = CV.valbankcd(dtobj);
									bankname = Resultobj.getValue("BANKCD_NAME");
								}
							}

							if (_lcissCountry != null) {
								if (!_lcissCountry.equalsIgnoreCase("")) {
									CommonValidator CV = new CommonValidator();
									dtobj.clearMap();
									dtobj.setValue("CNTRY_CODE", _lcissCountry);
									Resultobj = CV.valcntrycd(dtobj);
									countryname = Resultobj.getValue("CNTRY_NAME");
								}
							}
							//Changes P.Subramani-Chn-04/04/2008 End
							if (Check_Result_Status()) {
								_QueryStr = "select LCPS_BRN_CODE, facno(LCPS_CUST_LIAB_ACC_NUM)LCPS_CUST_LIAB_ACC_NUM, LCPS_LIMIT_LINE_NUM, LCPS_LIM_CURR from lcps where LCPS_BRN_CODE = ? and LCPS_ENTRY_DATE = ? and LCPS_DAY_SL = ?";
								Set_preparedStatement(_QueryStr);
								_pstmt.setInt(1, _branchCode);
								_pstmt.setTimestamp(2, DateToYYYYMMDD(_lcpsdate));
								_pstmt.setInt(3, _lcpsl);
								Resultobj = Get_Value_From_Main("LCPS");
							}
							if (Check_Result_Status()) {
								_declength1 = String.valueOf(cbsglobal.getcurrdeclength(_lcCurr));
							}
							if (Check_Result_Status()) {
								_liabAcc = Resultobj.getValue("LCPS_CUST_LIAB_ACC_NUM");
								_limitCurr = Resultobj.getValue("LCPS_LIM_CURR");
								_limitline = Resultobj.getValue("LCPS_LIMIT_LINE_NUM");
								_limitlineHidden = _limitline;
								if (Check_Result_Status()) {
									_QueryStr = "Select nvl(max(OLCA_AMD_SL),0) + 1 as max_Amdsl from OLCAMD where OLCA_BRN_CODE = ? and OLCA_LC_TYPE = ? and OLCA_LC_YEAR = ? and OLCA_LC_SL=?";
									Set_preparedStatement(_QueryStr);
									_pstmt.setInt(1, _branchCode);
									_pstmt.setString(2, _olctype);
									_pstmt.setInt(3, _olcYear);
									_pstmt.setInt(4, _olcLcSl);
									Resultobj = Get_Value_From_Main("OLCAMD");
									if (Check_Result_Status()) {
										_amdSl = Integer.parseInt(Resultobj.getValue("MAX_AMDSL"));
										if (_option.equalsIgnoreCase("A")) {
											if (_amdSl > 1) {

												dtobj.clearMap();
												dtobj.setValue("BRANCH_CODE", String.valueOf(_branchCode));
												dtobj.setValue("LC_TYPE", _olctype);
												dtobj.setValue("LC_YEAR", String.valueOf(_olcYear));
												dtobj.setValue("LC_SERIAL", String.valueOf(_olcLcSl));
												dtobj.setValue("AMENDMENT_SERIAL", String.valueOf(_amdSl - 1));
												dtobj.setValue(FetchReq, "true");
												//SUGANYA BEGIN 22-09-2016
												//dtobj.setValue("FetchColumns","OLCA_AUTH_BY");
												dtobj.setValue("FetchColumns", "OLCA_AUTH_BY,OLCA_REJ_BY");

												//SUGANYA END 22-09-2016
												Resultobj = olcval.valolcamd(dtobj);
												if (Check_Result_Status()) {
													String _auth_By = Resultobj.getValue("OLCA_AUTH_BY");
													//SUGANYA BEGIN 22-09-2016
													String _rej_by = Resultobj.getValue("OLCA_REJ_BY");
													//if(_auth_By==null)
													if ((_auth_By == null) && (_rej_by == null))
													//SUGANYA END 22-09-2016
													{
														Resultobj.setValue(ErrorKey, "Previous Amendment not Authorised");
													}

												}
											}
											//		                        	 else
											//	                            	 {
											//	                            		 _amdSl=_amdSl-1;
											//	                            	 }

										} else {
											if (_amdSl > 1) {
												_amdSl = _amdSl - 1;
											}
											dtobj.clearMap();
											dtobj.setValue("BRANCH_CODE", String.valueOf(_branchCode));
											dtobj.setValue("LC_TYPE", _olctype);
											dtobj.setValue("LC_YEAR", String.valueOf(_olcYear));
											dtobj.setValue("LC_SERIAL", String.valueOf(_olcLcSl));
											dtobj.setValue("AMENDMENT_SERIAL", String.valueOf(_amdSl));
											dtobj.setValue(FetchReq, "true");
											dtobj.setValue("FetchColumns", "OLCA_ENTRY_DATE, OLCA_CUST_LETTER_NUM, OLCA_CUST_LTR_DATE,OLCA_BENEF_CODE, OLCA_BENEF_NAME, OLCA_BENEF_ADDR1, OLCA_BENEF_ADDR2, OLCA_BENEF_ADDR3, OLCA_BENEF_ADDR4, OLCA_BENEF_ADDR5, OLCA_BENEF_CNTRY_CODE, OLCA_AMENDED_AMT, OLCA_POS_DEV_ALLWD, OLCA_NEG_DEV_ALLWD, OLCA_DEV_AMT, OLCA_PRICE_TERMS, OLCA_LAST_DATE_OF_NEG, OLCA_PLACE_OF_EXPIRY, OLCA_LATEST_DATE_OF_SHPMNT, OLCA_WITHIN_VALIDATE_LC, OLCA_NOF_TENORS, OLCA_ADD_LIAB_LC_CURR, OLCA_ADD_LIAB_BASE_CURR, OLCA_CONV_RATE_LIM_CURR,OLCA_BRN_CODE, OLCA_AUTH_BY, OLCA_REJ_BY");
											Resultobj = olcval.valolcamd(dtobj);
											if (Check_Result_Status()) {
												if (_option.equalsIgnoreCase("M")) {
													if (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowNotPresent)) {
														Resultobj.setValue(ErrorKey, "Record Does Not Exist to Modify");
													} else {
														if (Resultobj.getValue("OLCA_AUTH_BY") != null) {
															Resultobj.setValue(ErrorKey, "Record Already Authorised Cannot Modify");
														}
														//Changes P.Subramani-Chn-11/09/2008 Beg                             				
														if (Resultobj.getValue("OLCA_REJ_BY") != null) {
															Resultobj.setValue(ErrorKey, "Record Already Rejected Cannot Modify");
														}
														//Changes P.Subramani-Chn-11/09/2008 End                             				
														//Changes P.Subramani-Chn-01/04/2008 Beg
														/*else
														{
															_addr1=Resultobj.getValue("OLCA_BENEF_ADDR1");
														_addr2=Resultobj.getValue("OLCA_BENEF_ADDR2");
														_addr3=Resultobj.getValue("OLCA_BENEF_ADDR3");
														_addr4=Resultobj.getValue("OLCA_BENEF_ADDR4");
														_addr5=Resultobj.getValue("OLCA_BENEF_ADDR5");
														_benefCode=Resultobj.getValue("OLCA_BENEF_CODE");
														_benefName=Resultobj.getValue("OLCA_BENEF_NAME");
														_lcAmt=Resultobj.getValue("OLCA_AMENDED_AMT");
														_lcCurr=Resultobj.getValue("OLCA_LC_CURR_CODE");
														_lcdate=Resultobj.getValue("OLCA_ENTRY_DATE");
														_lccustletternum=Resultobj.getValue("OLCA_CUST_LETTER_NUM");
														_lccustletterdate=Resultobj.getValue("OLCA_CUST_LTR_DATE");
														 _positiveDeviAllowed=Resultobj.getValue("OLCA_POS_DEV_ALLWD");
														 _olcDevBal=Resultobj.getValue("OLC_DEV_BAL");
														_countryCode=Resultobj.getValue("OLC_BENEF_CNTRY_CODE");
														_lcpsdate=Resultobj.getValue("OLC_LC_PRESANC_DATE");
														_drawDown=Resultobj.getValue("OLC_NOF_TENORS");
														_lcpsl=Integer.parseInt(Resultobj.getValue("OLC_LC_PRESANC_DAY_SL"));
														 _totalliabbasecurr=Double.parseDouble(Resultobj.getValue("OLC_TOT_LIAB_BASE_CURR"));
														}*/
														//Changes P.Subramani-Chn-01/04/2008 Beg
													}
												}
											}
										}
									}
								}
							}
							if (Check_Result_Status()) {
								Resultobj.setValue(ErrorKey, "");
								Resultobj.setValue("AMD_SERIAL", String.valueOf(_amdSl));
								Resultobj.setValue("OLC_CORR_REF_NUM", _custRef);
								Resultobj.setValue("OLC_LC_DATE", _lcdate);
								Resultobj.setValue("OLC_CUST_NUM", _custNum);
								Resultobj.setValue("OLC_BENEF_CODE", _benefCode);
								Resultobj.setValue("OLC_BENEF_NAME", _benefName);
								Resultobj.setValue("OLC_BENEF_ADDR1", _addr1);
								Resultobj.setValue("OLC_BENEF_ADDR2", _addr2);
								Resultobj.setValue("OLC_BENEF_ADDR3", _addr3);
								Resultobj.setValue("OLC_BENEF_ADDR4", _addr4);
								Resultobj.setValue("OLC_BENEF_ADDR5", _addr5);
								Resultobj.setValue("OLC_BENEF_CNTRY_CODE", _countryCode);
								Resultobj.setValue("OLC_LC_ISS_BK_CODE", _lcissBank);
								Resultobj.setValue("OLC_LC_ISS_BRN_CODE", _lcissBranch);
								Resultobj.setValue("OLC_LC_ISS_PLACE", _lcissPlace);
								Resultobj.setValue("OLC_LC_ISS_CNTRY", _lcissCountry);
								Resultobj.setValue("OLC_LC_CURR_CODE", _lcCurr);
								Resultobj.setValue("OLC_LC_AMOUNT", _lcAmt);
								Resultobj.setValue("OLC_LC_BALANCE", _lcBal);
								Resultobj.setValue("OLC_NOF_TENORS", _drawDown);
								Resultobj.setValue("LCPS_CUST_LIAB_ACC_NUM", _liabAcc);
								Resultobj.setValue("LCPS_LIM_CURR", _limitCurr);
								Resultobj.setValue("LCPS_LIMIT_LINE_NUM", _limitline);
								Resultobj.setValue("OLC_TOT_LIAB_BASE_CURR", String.valueOf(_totalliabbasecurr));
								Resultobj.setValue("OLC_DEV_BAL", _olcDevBal);
								Resultobj.setValue("DEC_LEN", _declength1);
								Resultobj.setValue("OLC_POS_DEV_ALLWD", _positiveDeviAllowed);
								//Changes P.Subramani-Chn-04/04/2008 Beg
								Resultobj.setValue("CLIENTS_NAME", custname);
								Resultobj.setValue("CLIENTS_ADDR1", custadd1);
								Resultobj.setValue("CLIENTS_ADDR2", custadd2);
								Resultobj.setValue("CLIENTS_ADDR3", custadd3);
								Resultobj.setValue("CLIENTS_ADDR4", custadd4);
								Resultobj.setValue("CLIENTS_ADDR5", custadd5);
								Resultobj.setValue("MBRN_NAME", branchname);
								Resultobj.setValue("BANKCD_NAME", bankname);
								Resultobj.setValue("CNTRY_NAME", countryname);
								//Changes P.Subramani-Chn-04/04/2008 End
							}
						}
					}
				}

			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in olcLcSlkeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************

	// *********************************************************************************************************
	// *********************************************************************************************************
	/*
	 * Input 	- 						Key =AMENDMENT_ENTRY_DATE
	 * \									kEY=CBD
	 * 									Key=LC_DATE
	 * Output	: Error Message  		- 		Key = ErrorMsg
	 */

	public DTObject ircrTranDatekeypress(DTObject InputoBj) {
		try {
			String _ircrTranDate = "";
			String _currBusDate = "";
			String _lcDate = "";
			{
				_ircrTranDate = InputoBj.getValue("AMENDMENT_ENTRY_DATE").trim().toString();
				_currBusDate = InputoBj.getValue("CBD").trim().toString();
				_lcDate = InputoBj.getValue("LC_DATE").trim().toString();
			}
			Init_ResultObj(InputoBj);
			if (String.valueOf(_ircrTranDate).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (!_ircrTranDate.equalsIgnoreCase(""))
				if (Check_Result_Status()) {
					CheckDate(_ircrTranDate);
					if (Check_Result_Status()) {
						if (!(DateUtility.DateGreaterThanOrEqual(_currBusDate, _ircrTranDate))) {
							Resultobj.setValue(ErrorKey, "Amendment Entry Date Should be less than Current Business Date");
						}
						if (!(DateUtility.DateGreaterThanOrEqual(_ircrTranDate, _lcDate))) {
							Resultobj.setValue(ErrorKey, "Amendment Entry Date Should be Greater or Equal to LC Entry Date");
						}

					}

				}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in ircrTranDatekeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************

	// *********************************************************************************************************
	/*
	 * Input 	- 						Key =BENEF_CODE
	 * Output	: Error Message  		- 		Key = ErrorMsg
	 */

	public DTObject olcBenefCodekeypress(DTObject InputoBj) {
		try {
			String _benefCode = "";
			String _countryCode = "";
			String _benefname = "";
			String _addr1 = "";
			String _addr2 = "";
			String _addr3 = "";
			String _addr4 = "";
			String _addr5 = "";
			//Changes in EOLCAMD on 16-Oct-2018 start
			String _fldno = "";
			String _chkbox = "";
			String type = "";
			//Changes in EOLCAMD on 16-Oct-2018 end

			if (InputoBj.getValue("BENEF_CODE").trim().equalsIgnoreCase("")) {
				_benefCode = "";
			} else {
				_benefCode = InputoBj.getValue("BENEF_CODE").trim().toString();
			}

			if (InputoBj.getValue("OLC_LC_TYPE").trim().equalsIgnoreCase("")) {
				type = "";
			} else {
				type = InputoBj.getValue("OLC_LC_TYPE").trim().toString();
			}

			//Changes in EOLCAMD on 16-Oct-2018 start
			_fldno = InputoBj.getValue("AMEND_FIELDNO").trim().toString();
			_chkbox = InputoBj.getValue("AMEND_CHKBOX").trim().toString();

			Init_ResultObj(InputoBj);
			if (type.trim().equalsIgnoreCase("OLC")) {
				if (String.valueOf(_benefCode).trim().equalsIgnoreCase("") && _fldno.trim().toString().equals("6") && _chkbox.trim().toString().equals("1")) {
					Resultobj.setValue(ErrorKey, BLANK_CHECK);
				}
				if (!String.valueOf(_benefCode).trim().equalsIgnoreCase("") && _fldno.trim().toString().equals("6") && _chkbox.trim().toString().equals("0")) {
					Resultobj.setValue(ErrorKey, "Checkbox Should be Checked");
				}
			}

			//Changes in EOLCAMD on 16-Oct-2018 end
			if (Check_Result_Status()) {
				dtobj.clearMap();
				dtobj.setValue("CPARTY_ALPHA_CODE", _benefCode);
				dtobj.setValue(FetchReq, "true");
				dtobj.setValue("FetchColumns", "CPARTY_ADDR1, CPARTY_ADDR2,CPARTY_ADDR3, CPARTY_ADDR4, CPARTY_ADDR5, CPARTY_CNTRY_CODE");
				Resultobj = tfmval.valcparty(dtobj);
			}
			if (Check_Result_Status()) {
				_countryCode = Resultobj.getValue("CPARTY_CNTRY_CODE");
				_benefname = Resultobj.getValue("CPARTY_NAME");
				_addr1 = Resultobj.getValue("CPARTY_ADDR1");
				_addr2 = Resultobj.getValue("CPARTY_ADDR2");
				_addr3 = Resultobj.getValue("CPARTY_ADDR3");
				_addr4 = Resultobj.getValue("CPARTY_ADDR4");
				_addr5 = Resultobj.getValue("CPARTY_ADDR5");
				dtobj.clearMap();
				dtobj.setValue("CNTRY_CODE", _countryCode);
				Resultobj = comnval.valcntrycd(dtobj);
			}
			if (Check_Result_Status()) {
				Resultobj.setValue("CPARTY_NAME", _benefname);
				Resultobj.setValue("CPARTY_ADDR1", _addr1);
				Resultobj.setValue("CPARTY_ADDR2", _addr2);
				Resultobj.setValue("CPARTY_ADDR3", _addr3);
				Resultobj.setValue("CPARTY_ADDR4", _addr4);
				Resultobj.setValue("CPARTY_ADDR5", _addr5);
				Resultobj.setValue("CNTRY_CODE", _countryCode);
				Resultobj.setValue(ErrorKey, "");
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in olcPercOfInsValueCvrdkeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	// *********************************************************************************************************
	/*
	 * Input 	- 						Key =OLC_COUNTRY_CODE
	 * Output	: Error Message  		- 		Key = ErrorMsg
	 * 											Key=CNTRY_NAME
	 */

	public DTObject olcBenefCountryCodekeypress(DTObject InputoBj) {
		try {
			String _olcCountryCode = "";
			String fldno = "";
			String chkbox = "";
			{
				_olcCountryCode = InputoBj.getValue("OLC_COUNTRY_CODE").trim().toString();

			}
			Init_ResultObj(InputoBj);
			/*if(String.valueOf(_olcCountryCode).trim().equalsIgnoreCase(""))
			{
			    Resultobj.setValue(ErrorKey,BLANK_CHECK);
			}*/
			//Changes in EOLCAMD on 16-Oct-2018 start
			if ((InputoBj.containsKey("AMEND_FIELDNO") == true) && (!InputoBj.getValue("AMEND_FIELDNO").trim().equalsIgnoreCase("")))
				fldno = InputoBj.getValue("AMEND_FIELDNO").trim().toString();
			else
				fldno = "0";

			if ((InputoBj.containsKey("AMEND_CHKBOX") == true) && (!InputoBj.getValue("AMEND_CHKBOX").trim().equalsIgnoreCase("")))
				chkbox = InputoBj.getValue("AMEND_CHKBOX").trim().toString();
			else
				chkbox = "0";

			Resultobj = swval.Amendment_Beneficiary_CountryCode(InputoBj);
			//Changes in EOLCAMD on 16-Oct-2018 end

			if (Check_Result_Status()) {
				dtobj.clearMap();
				dtobj.setValue("CNTRY_CODE", _olcCountryCode);
				Resultobj = comnval.valcntrycd(dtobj);
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in olcBenefCountryCodekeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	// *********************************************************************************************************
	/*
	 * Input 	- 						Key =POST_DEVI
	 * 										 
	 * Output	: Error Message  		- 		Key = ErrorMsg
	 */

	public DTObject olcPositiveDeviationkeypress(DTObject InputoBj) {
		try {
			double _olcPosDev = 0;
			//Changes in EOLCAMD on 16-Oct-2018 start
			String _fldno = "";
			String _chkbox = "";
			//Changes in EOLCAMD on 16-Oct-2018 end

			if (InputoBj.getValue("POST_DEVI").trim().equalsIgnoreCase("")) {
				_olcPosDev = 0;
			} else {
				_olcPosDev = Double.parseDouble(InputoBj.getValue("POST_DEVI").trim().toString());
			}
			Init_ResultObj(InputoBj);
			/* if(String.valueOf(_olcPosDev).trim().equalsIgnoreCase(""))
			 {
			     Resultobj.setValue(ErrorKey,BLANK_CHECK);
			 } Commented on 16-OCT-2018 start*/
			//Changes in EOLCAMD on 16-Oct-2018 start
			_fldno = InputoBj.getValue("AMEND_FIELDNO").trim().toString();
			_chkbox = InputoBj.getValue("AMEND_CHKBOX").trim().toString();

			Init_ResultObj(InputoBj);
			if ((String.valueOf(_olcPosDev).trim().equalsIgnoreCase("")) && _fldno.trim().toString().equals("3") && _chkbox.trim().toString().equals("1")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			} else if ((!(String.valueOf(_olcPosDev).trim().equalsIgnoreCase(""))) && _fldno.trim().toString().equals("3") && _chkbox.trim().toString().equals("0")) {
				Resultobj.setValue(ErrorKey, "Checkbox Should be Checked");
			}
			//Changes in EOLCAMD on 16-Oct-2018 end
			if (Check_Result_Status()) {
				if (!String.valueOf(_olcPosDev).trim().equalsIgnoreCase("")) {
					if (_olcPosDev == 0)
						if (InputoBj.containsKey("POST_DEVI") == true && InputoBj.getValue("POST_DEVI").equalsIgnoreCase(""))
							Resultobj.setValue(ErrorKey, BLANK_CHECK);
						else
							Resultobj.setValue(ErrorKey, ZERO_CHECK);
				}
			}

			if (Check_Result_Status()) {
				if (_olcPosDev > 100) {
					Resultobj.setValue(ErrorKey, "Deviation Allowed  should be <= 100");
				}

			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in olcInsDatekeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	// *********************************************************************************************************
	/*
	 * Input 	- 						Key =TERMS_OF_PRICE
	 * 										 
	 * Output	: Error Message  		- 		Key = ErrorMsg
	 * 											      TERMS_DESCN
	 */

	public DTObject olcTermsOfPricekeypress(DTObject InputoBj) {
		try {
			String _olcTermsPrice = "";
			{
				_olcTermsPrice = InputoBj.getValue("TERMS_OF_PRICE").trim().toString();

			}
			Init_ResultObj(InputoBj);
			if (String.valueOf(_olcTermsPrice).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (Check_Result_Status()) {
				dtobj.clearMap();
				dtobj.setValue("TERMS_CODE", _olcTermsPrice);
				Resultobj = tfmval.valterms(dtobj);
			}

		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in olcInsCurrkeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	// *********************************************************************************************************
	/*
	 * Input 	- 						Key =LAST_DATE_NEGOCIATION
	 * 										 AMD_DATE
	 * Output	: Error Message  		- 		Key = ErrorMsg
	 */

	public DTObject olclastDatekeypress(DTObject InputoBj) {
		try {
			String _lastDate = "";
			String _amdDate = "";
			//Changes in EOLCAMD on 16-Oct-2018 start
			String _olcfieldno = "";
			String _olc_chkbox = "";
			//Changes in EOLCAMD on 16-Oct-2018 end
			{
				_lastDate = InputoBj.getValue("LAST_DATE_NEGOCIATION").trim().toString();
				_amdDate = InputoBj.getValue("AMD_DATE").trim().toString();
				//Changes in EOLCAMD on 16-Oct-2018 start
				_olcfieldno = InputoBj.getValue("AMEND_FIELDNO").trim().toString();
				_olc_chkbox = InputoBj.getValue("AMEND_CHKBOX").trim().toString();
				//Changes in EOLCAMD on 16-Oct-2018 end
			}
			Init_ResultObj(InputoBj);
			/*if(String.valueOf(_lastDate).trim().equalsIgnoreCase(""))
			{
			    Resultobj.setValue(ErrorKey,BLANK_CHECK);
			}Commented on 16-Oct-2018*/
			//Changes in EOLCAMD on 16-Oct-2018 start
			if (_olcfieldno.trim().equals("1") && _olc_chkbox.trim().equals("1") && String.valueOf(_lastDate).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			} else if (_olcfieldno.trim().equals("1") && _olc_chkbox.trim().equals("0") && !(String.valueOf(_lastDate).trim().equalsIgnoreCase(""))) {
				Resultobj.setValue(ErrorKey, "Checkbox Should be Checked");
			}
			//Changes in EOLCAMD on 16-Oct-2018 end
			if (!_lastDate.equalsIgnoreCase(""))
				if (Check_Result_Status()) {
					CheckDate(_lastDate);
					if (Check_Result_Status()) {
						if (!(DateUtility.DateGreaterThan(_lastDate, _amdDate))) {
							Resultobj.setValue(ErrorKey, "Last Date of Negotiation Should be > Amendment Date");
						}

					}

				}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in olcInsAmtkeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	// *********************************************************************************************************
	/*
	 * Input 	- 						Key =LC_AMT
	 * 									Key=TENOR_AMT
	 * 									Key=TOTAL_TENOR_AMT
	 * 									Key=DRAW_DOWNS
	 * 									Key=NO_OF_ROWS
	 * 									
	 * Output	: Error Message  		- 		Key = ErrorMsg
	 * 												
	 * 													
	 */

	public DTObject olcTenorAmtkeypress(DTObject InputoBj) {
		try {
			double _lcAmt = 0;
			double _tenorAmt = 0;
			double total_tenor_amt = 0;
			int _drawDown = 0;
			int _noRows = 0;
			String _lcCurr = "";
			String _tenorlength = "";
			if (InputoBj.getValue("LC_AMT").trim().equalsIgnoreCase("") && InputoBj.getValue("TENOR_AMT").trim().equalsIgnoreCase("") && InputoBj.getValue("TOTAL_TENOR_AMT").trim().equalsIgnoreCase("") && InputoBj.getValue("DRAW_DOWNS").trim().equalsIgnoreCase("")) {
				_lcAmt = 0;
				_tenorAmt = 0;
				total_tenor_amt = 0;
				_drawDown = 0;
				_noRows = 0;
			} else {
				_lcAmt = Double.parseDouble(InputoBj.getValue("LC_AMT").trim().toString());
				_tenorAmt = Double.parseDouble(InputoBj.getValue("TENOR_AMT").trim().toString());
				total_tenor_amt = Double.parseDouble(InputoBj.getValue("TOTAL_TENOR_AMT").trim().toString());
				_drawDown = Integer.parseInt(InputoBj.getValue("DRAW_DOWNS").trim().toString());
				_noRows = Integer.parseInt(InputoBj.getValue("NO_OF_ROWS").trim().toString());
				//_lcCurr=InputoBj.getValue("LC_CURR") .trim().toString();

			}
			Init_ResultObj(InputoBj);
			if (String.valueOf(_lcAmt).trim().equalsIgnoreCase("") && String.valueOf(_tenorAmt).trim().equalsIgnoreCase("") && String.valueOf(total_tenor_amt).trim().equalsIgnoreCase("") && String.valueOf(_drawDown).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (Check_Result_Status()) {
				if (!String.valueOf(_lcAmt).trim().equalsIgnoreCase("") && !String.valueOf(_tenorAmt).trim().equalsIgnoreCase("") && !String.valueOf(total_tenor_amt).trim().equalsIgnoreCase("") && !String.valueOf(_drawDown).trim().equalsIgnoreCase("")) {
					if (_lcAmt == 0)
						if (InputoBj.containsKey("LC_AMT") == true && InputoBj.getValue("LC_AMT").equalsIgnoreCase(""))
							Resultobj.setValue(ErrorKey, BLANK_CHECK);
						else
							Resultobj.setValue(ErrorKey, ZERO_CHECK);
					if (_tenorAmt == 0)
						if (InputoBj.containsKey("TENOR_AMT") == true && InputoBj.getValue("TENOR_AMT").equalsIgnoreCase(""))
							Resultobj.setValue(ErrorKey, BLANK_CHECK);
						else
							Resultobj.setValue(ErrorKey, ZERO_CHECK);
					if (total_tenor_amt == 0)
						if (InputoBj.containsKey("TOTAL_TENOR_AMT") == true && InputoBj.getValue("TOTAL_TENOR_AMT").equalsIgnoreCase(""))
							Resultobj.setValue(ErrorKey, BLANK_CHECK);
						else
							Resultobj.setValue(ErrorKey, ZERO_CHECK);
					if (_drawDown == 0)
						if (InputoBj.containsKey("DRAW_DOWNS") == true && InputoBj.getValue("DRAW_DOWNS").equalsIgnoreCase(""))
							Resultobj.setValue(ErrorKey, BLANK_CHECK);
						else
							Resultobj.setValue(ErrorKey, ZERO_CHECK);
				}
			}
			if (Check_Result_Status()) {
				if (_tenorAmt > _lcAmt) {
					Resultobj.setValue(ErrorKey, "Tenor Amount Does Not Tally");
				}
				if ((_tenorAmt != _lcAmt) && _drawDown == 1) {
					Resultobj.setValue(ErrorKey, "Tenor Amount Does Not Tally");
				}
				if ((total_tenor_amt != _lcAmt) && _drawDown == _noRows) {
					Resultobj.setValue(ErrorKey, "Tenor Amount Does Not Tally");
				}

			}

		}
		//Changes P.Subramani-Chn-29/02/2008
		catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in olcTenorAmtkeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	// *********************************************************************************************************
	/*
	 * Input 	- 						Key =LC_CURR
	 * 									Key=BASE_CURR
	 * 									Key=ADD_LC_LIAB_AMT
	 * 									Key=CONV_RATE
	 * Output	: Error Message  		- 		Key = ErrorMsg
	 * 											Key=DEC_LEN
	 * 											Key=AMT_AGNST_CURR
	 */

	public DTObject olcConvToLimitCurrkeypress(DTObject InputoBj) {
		try {
			String _lcCurr = "";
			String _baseCurr = "";
			double add_lc_liab_amt = 0;
			double _convRate = 0;
			double _agnstValue = 0;
			String _declength = "";
			{
				_lcCurr = InputoBj.getValue("LC_CURR").trim().toString();
				_baseCurr = InputoBj.getValue("BASE_CURR").trim().toString();
			}
			Init_ResultObj(InputoBj);
			if (String.valueOf(_lcCurr).trim().equalsIgnoreCase("") && String.valueOf(_baseCurr).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}

			if (InputoBj.getValue("ADD_LC_LIAB_AMT").trim().equalsIgnoreCase("") && InputoBj.getValue("CONV_RATE").trim().equalsIgnoreCase("")) {
				add_lc_liab_amt = 0;
				_convRate = 0;
			} else {
				add_lc_liab_amt = Double.parseDouble(InputoBj.getValue("ADD_LC_LIAB_AMT").trim().toString());
				_convRate = Double.parseDouble(InputoBj.getValue("CONV_RATE").trim().toString());
			}
			Init_ResultObj(InputoBj);
			if (String.valueOf(add_lc_liab_amt).trim().equalsIgnoreCase("") && String.valueOf(_convRate).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (Check_Result_Status()) {
				if (!String.valueOf(add_lc_liab_amt).trim().equalsIgnoreCase("") && !String.valueOf(_convRate).trim().equalsIgnoreCase("")) {
					if (add_lc_liab_amt == 0)
						if (InputoBj.containsKey("ADD_LC_LIAB_AMT") == true && InputoBj.getValue("ADD_LC_LIAB_AMT").equalsIgnoreCase(""))
							Resultobj.setValue(ErrorKey, BLANK_CHECK);
						else
							Resultobj.setValue(ErrorKey, ZERO_CHECK);
					if (_convRate == 0)
						if (InputoBj.containsKey("CONV_RATE") == true && InputoBj.getValue("CONV_RATE").equalsIgnoreCase(""))
							Resultobj.setValue(ErrorKey, BLANK_CHECK);
						else
							Resultobj.setValue(ErrorKey, ZERO_CHECK);
				}
			}
			if (Check_Result_Status()) {
				dtobj.clearMap();
				dtobj.setValue("FOR_CURR", _lcCurr);
				dtobj.setValue("AGNST_CURR", _baseCurr);
				dtobj.setValue("AMT_FOR_CURR", String.valueOf(add_lc_liab_amt));
				dtobj.setValue("CONVER_RATE", String.valueOf(_convRate));
				Resultobj = comnval.calAgnstVal(dtobj);
			}
			if (Check_Result_Status()) {
				_agnstValue = Double.parseDouble(Resultobj.getValue("AMT_AGNST_CURR"));
				_declength = String.valueOf(cbsglobal.getcurrdeclength(_baseCurr));
			}
			if (Check_Result_Status()) {
				Resultobj.setValue("AMT_AGNST_CURR", String.valueOf(_agnstValue));
				Resultobj.setValue("DEC_LEN", String.valueOf(_declength));
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in olcInsCompanykeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	// *********************************************************************************************************
	/*
	 * Input 	- 						Key =LATEST_DATE_OF_SHIPMENT
	 * 									Key=ENTRY_DATE
	 * 									Key=NEGOCIATION_DATE
	 * Output	: Error Message  		- 		Key = ErrorMsg
	 * 												 INSUCMP_NAME
	 */

	public DTObject olcLatestdateofShipmentkeypress(DTObject InputoBj) {
		try {
			String _olclatestDate = "";
			String _olcentryDate = "";
			String _olcnegociationdate = "";
			//Changes in EOLCAMD on 16-Oct-2018 start
			String _olcfieldno = "";
			String _olc_chkbox = "";
			String shipmnt_prd = "";
			//Changes in EOLCAMD on 16-Oct-2018 end
			{
				_olclatestDate = InputoBj.getValue("LATEST_DATE_OF_SHIPMENT").trim().toString();
				_olcentryDate = InputoBj.getValue("ENTRY_DATE").trim().toString();
				_olcnegociationdate = InputoBj.getValue("NEGOCIATION_DATE").trim().toString();
				//Changes in EOLCAMD on 16-Oct-2018 start
				_olcfieldno = InputoBj.getValue("AMEND_FIELDNO").trim().toString();
				_olc_chkbox = InputoBj.getValue("AMEND_CHKBOX").trim().toString();
				shipmnt_prd = InputoBj.getValue("LC_SHPMNT_PERIOD").trim().toString();
				//Changes in EOLCAMD on 16-Oct-2018 end
			}
			Init_ResultObj(InputoBj);

			//Changes in EOLCAMD on 16-Oct-2018 start
			if (_olcfieldno.trim().equals("5") && _olc_chkbox.trim().equals("1") && String.valueOf(_olclatestDate).trim().equalsIgnoreCase("") && String.valueOf(shipmnt_prd).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			} else if (_olcfieldno.trim().equals("5") && _olc_chkbox.trim().equals("0") && (!(String.valueOf(_olclatestDate).trim().equalsIgnoreCase("")) || !(String.valueOf(shipmnt_prd).trim().equalsIgnoreCase("")))) {
				Resultobj.setValue(ErrorKey, "Checkbox Should be Checked");
			}
			//Changes in EOLCAMD on 16-Oct-2018 end
			if ((String.valueOf(_olclatestDate).trim().equalsIgnoreCase("") || String.valueOf(shipmnt_prd).trim().equalsIgnoreCase("")) && String.valueOf(_olcentryDate).trim().equalsIgnoreCase("") && String.valueOf(_olcnegociationdate).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (Check_Result_Status()) {
				if (!_olclatestDate.equalsIgnoreCase(""))
					if (Check_Result_Status()) {
						CheckDate(_olclatestDate);
						if (Check_Result_Status()) {
							//Changes P.Subramani-Chn-25/02/2008
							if (!(DateUtility.DateGreaterThan(_olclatestDate, _olcentryDate))) {
								Resultobj.setValue(ErrorKey, "Lastest Date of Shipment Should be > Amendment Entry Date");
							}
							if (!(DateUtility.DateLessThanOrEqual(_olclatestDate, _olcnegociationdate))) {
								Resultobj.setValue(ErrorKey, "Lastest Date of Shipment Should be <= Last Date for Negotiation");
							}

						}

					}
			}
			if (Check_Result_Status()) {

			}

		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in olcInsCompanyNamekeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	// *********************************************************************************************************
	/*
	 * Input 	- 						Key =TRCHG_NOMEN_CODE
	 * 									
	 * 									Key=TRCHG_FACILITY_CURR
	 * Output	: Error Message  		- 	
	 * 									Key=TRCHG_COMMN_CHGCD
	 *  									Key=TRCHG_COURIER_CHGCD
	 *  									Key=TRCHG_POSTAL_CHGCD
	 */

	public DTObject OlcChargeComp(DTObject InputoBj) {
		try {
			String _olcTRCHG_NOMEN_CODE = "";
			String _olcTRCHG_OPT_TYPE = "";
			String _olcTRCHG_FACILITY_CURR = "";
			//Changes P.Subramani-Chn-23/06/2008 Beg
			String TRCHG_COMMN_CHGCD = "";
			String TRCHG_COURIER_CHGCD = "";
			String TRCHG_POSTAL_CHGCD = "";
			String TRCHG_HANDLING_CHGCD = "";
			String TRCHG_SWIFT_CHGCD = "";
			String TRCHG_USANCE_CHGCD = "";
			String TRCHG_COMMITMNT_CHGCD = "";

			{
				_olcTRCHG_NOMEN_CODE = InputoBj.getValue("TRCHG_NOMEN_CODE").trim().toString();
				_olcTRCHG_OPT_TYPE = "8";
				_olcTRCHG_FACILITY_CURR = InputoBj.getValue("TRCHG_FACILITY_CURR").trim().toString();
			}
			Init_ResultObj(InputoBj);
			if (String.valueOf(_olcTRCHG_NOMEN_CODE).trim().equalsIgnoreCase("") && String.valueOf(_olcTRCHG_OPT_TYPE).trim().equalsIgnoreCase("") && String.valueOf(_olcTRCHG_FACILITY_CURR).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (Check_Result_Status()) {
				_QueryStr = "SELECT TRCHG_COMMN_CHGCD,TRCHG_HANDLING_CHGCD, TRCHG_COURIER_CHGCD, TRCHG_POSTAL_CHGCD,TRCHG_SWIFT_CHGCD,TRCHG_COMMITMNT_CHGCD,TRCHG_USANCE_CHGCD FROM TRCHGPARAM  WHERE TRCHG_NOMEN_CODE = ?  AND TRCHG_OPT_TYPE = ?  AND TRCHG_FACILITY_CURR = ?";
				Set_preparedStatement(_QueryStr);
				_pstmt.setString(1, _olcTRCHG_NOMEN_CODE);
				_pstmt.setString(2, _olcTRCHG_OPT_TYPE);
				_pstmt.setString(3, _olcTRCHG_FACILITY_CURR);
				Resultobj = Get_Value_From_Main("TRCHGPARAM");
				TRCHG_COMMITMNT_CHGCD = Resultobj.getValue("TRCHG_COMMITMNT_CHGCD");
				TRCHG_USANCE_CHGCD = Resultobj.getValue("TRCHG_USANCE_CHGCD");
				if (Check_Result_Status()) {
					if (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowNotPresent)) {

						_QueryStr = "SELECT TRCHG_COMMN_CHGCD,TRCHG_HANDLING_CHGCD, TRCHG_COURIER_CHGCD, TRCHG_POSTAL_CHGCD,TRCHG_SWIFT_CHGCD,TRCHG_COMMITMNT_CHGCD,TRCHG_USANCE_CHGCD FROM TRCHGPARAM  WHERE TRCHG_NOMEN_CODE = ?  AND TRCHG_OPT_TYPE = ?  AND TRCHG_FACILITY_CURR = ?";
						Set_preparedStatement(_QueryStr);
						_pstmt.setString(1, _olcTRCHG_NOMEN_CODE);
						_pstmt.setString(2, _olcTRCHG_OPT_TYPE);
						_pstmt.setString(3, " ");
						Resultobj = Get_Value_From_Main("TRCHGPARAM");
						TRCHG_COMMITMNT_CHGCD = Resultobj.getValue("TRCHG_COMMITMNT_CHGCD");
						TRCHG_USANCE_CHGCD = Resultobj.getValue("TRCHG_USANCE_CHGCD");
						if (Check_Result_Status() == true) {
							if (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowNotPresent)) {
								Resultobj.setValue(ErrorKey, "Charges Not Exists");
							}
							//Changes P.Subramani-Chn-23-06-2008 Beg 
							else if (TRCHG_COMMITMNT_CHGCD == null) {
								Resultobj.setValue(ErrorKey, "Commitment Charges Parameter Not Exists");
							} else if (TRCHG_USANCE_CHGCD == null) {
								Resultobj.setValue(ErrorKey, "Usance Charges Parameter Not Exists");
							}
							//Changes P.Subramani-Chn-23-06-2008 End
						}
					}

					//Changes P.Subramani-Chn-23-06-2008 Beg 
					else if (TRCHG_COMMITMNT_CHGCD == null) {
						Resultobj.setValue(ErrorKey, "Commitment Charges Parameter Not Exists");
					} else if (TRCHG_USANCE_CHGCD == null) {
						Resultobj.setValue(ErrorKey, "Usance Charges Parameter Not Exists");
					}
					//Changes P.Subramani-Chn-23-06-2008 End

				}
			}

			TRCHG_COMMN_CHGCD = Resultobj.getValue("TRCHG_COMMN_CHGCD");
			TRCHG_COURIER_CHGCD = Resultobj.getValue("TRCHG_COURIER_CHGCD");
			TRCHG_POSTAL_CHGCD = Resultobj.getValue("TRCHG_POSTAL_CHGCD");
			TRCHG_HANDLING_CHGCD = Resultobj.getValue("TRCHG_HANDLING_CHGCD");
			TRCHG_SWIFT_CHGCD = Resultobj.getValue("TRCHG_SWIFT_CHGCD");
			TRCHG_COMMITMNT_CHGCD = Resultobj.getValue("TRCHG_COMMITMNT_CHGCD");
			TRCHG_USANCE_CHGCD = Resultobj.getValue("TRCHG_USANCE_CHGCD");

			if (Check_Result_Status()) {
				Resultobj.setValue(ErrorKey, "");
				Resultobj.setValue("TRCHG_COMMN_CHGCD", TRCHG_COMMN_CHGCD);
				Resultobj.setValue("TRCHG_COURIER_CHGCD", TRCHG_COURIER_CHGCD);
				Resultobj.setValue("TRCHG_POSTAL_CHGCD", TRCHG_POSTAL_CHGCD);
				Resultobj.setValue("TRCHG_HANDLING_CHGCD", TRCHG_HANDLING_CHGCD);
				Resultobj.setValue("TRCHG_SWIFT_CHGCD", TRCHG_SWIFT_CHGCD);
				Resultobj.setValue("TRCHG_COMMITMNT_CHGCD", TRCHG_COMMITMNT_CHGCD);
				Resultobj.setValue("TRCHG_USANCE_CHGCD", TRCHG_USANCE_CHGCD);
				//Changes P.Subramani-Chn-23-06-2008 End
			}

		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in OlcChargeComp");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	// *********************************************************************************************************
	/*
	 * Input 	- 						Key =  LMTLINE_NUM
	 * 									Key = LMTLINE_CLIENT_CODE 
	 * Output	: Error Message  		- 		Key = ErrorMsg
	 * 												 DEC_LEN
	 */

	public DTObject olchiddenValuekeypress(DTObject InputoBj) {
		try {
			String _lmtlinedesc = "";
			String _sanccurr = "";
			String _sancamt = "";
			String _sub_Units = "";
			if (!_limitlineHidden.equalsIgnoreCase("0")) {
				LimitValidator LV1 = new LimitValidator();
				DTObject dtoinput = new DTObject();
				dtoinput.setValue("LMTLINE_NUM", String.valueOf(_limitlineHidden));
				dtoinput.setValue("LMTLINE_CLIENT_CODE", String.valueOf(custnoHidden));
				dtoinput.setValue("FetchReq", "true");
				dtoinput.setValue("FetchColumns", "LMTLINE_SANCTION_CURR,LMTLINE_SANCTION_AMT");
				Resultobj = limval.vallimitline(dtoinput);
				_lmtlinedesc = Resultobj.getValue("LMTLINE_FACILITY_DESCN");
				_sanccurr = Resultobj.getValue("LMTLINE_SANCTION_CURR");
				_sancamt = Resultobj.getValue("LMTLINE_SANCTION_AMT");

			}
			if (Check_Result_Status()) {
				dtobj.clearMap();
				dtobj.setValue("CURR_CODE", String.valueOf(_sanccurr));
				Resultobj = comnval.valcurrcd(dtobj);
			}
			if (Check_Result_Status()) {
				_sub_Units = InputoBj.getValue("CURR_NOOF_SUB_UNITS").trim().toString();
				dtobj.clearMap();
				dtobj.setValue("CURR_UNIT", String.valueOf(_sub_Units));
				Resultobj = comnval.Currdecimal(dtobj);
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in olchiddenValuekeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************

	//  *********************************************************************************************************
	/*
	 * Input 	: Branch Code					-		Key = LCPS_BRN_CODE
	 * 			  Customer Liab Account Number	- 		Key = LCPS_CUST_LIAB_ACC_NUM
	 * 			  Customer Number				-		Key = LCPS_CUST_NUM
	 * 			  LC Currency					-		Key = LCPS_LC_CURR
	 * 			  LC Amount						-		Key = LCPS_LC_AMT
	 * 			  Product Code					-		Key = PRODUCT_CODE
	 * 			  Base Currency					-		Key = 	
	 * 													key=LIMIT_CURR		  
	 * 
	 * Output	: Actual Account Number			-		Key = ACTUAL_ACNT_NUM
	 * 			  Internal Account Number		-		Key = INTERNAL_ACNT_NUM
	 * 			  Account Name					-		Key = ACNT_NAME
	 * 			  Limit Line Number				-		Key = LMTLINE_NUM
	 * 			  Liit Line Description			-		Key = LMTLINE_DESCN
	 * 			  Limit Line Sanction Currency  -		Key = SANC_CURR
	 * 			  Limit Line Sanction Amount    -		Key = SANC_AMT
	 * 			  Outstanding Amount			-		Key = OUTSTD_AMT
	 * 			  Currency Code					-		Key = CURR_CODE
	 * 			  Currency Description 			-		Key = CURR_NAME
	 * 			  Effective Balance				-		Key = EFF_BAL
	 * 			  Error Message  				- 		Key = ErrorMsg
	 */
	// *********************************************************************************************************
	public DTObject olcsCustLiabAccNumkeypress(DTObject InputoBj) {
		try {
			String spaces = " ";
			String _totliablimcurr = "";
			String _currcode = "";
			String _currname = "";
			String _basecurrname = "";
			int _limline = 0;
			String _lmtlinedesc = "";
			String _acntnum = "";
			long _intacntnum = 0;
			String _acntname = "";
			String _effbal = "";
			String _outstdamt = "";
			String _sanccurr = "";
			String _sancamt = "";
			String _declength = "";
			String _limit_CURR = "";
			String baseCurrency = get_base_curr_code();
			int _lcpsBrnCode;
			_lcpsBrnCode = Integer.parseInt(InputoBj.getValue("LCPS_BRN_CODE").trim().toString());
			int _custnum;
			_custnum = Integer.parseInt(InputoBj.getValue("LCPS_CUST_NUM").trim().toString());
			String _contcurr;
			_contcurr = InputoBj.getValue("LCPS_LC_CURR").trim().toString();
			double _contamt;
			_contamt = Double.parseDouble(InputoBj.getValue("LCPS_LC_AMT").trim().toString());
			String _lcpsCustLiabAccNum = "";
			{
				_lcpsCustLiabAccNum = InputoBj.getValue("LCPS_CUST_LIAB_ACC_NUM").trim().toString();
				_limit_CURR = InputoBj.getValue("LIMIT_CURR").trim().toString();
			}
			Init_ResultObj(InputoBj);
			if (String.valueOf(_lcpsCustLiabAccNum).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (Check_Result_Status()) {
				AccountValidator AV = new AccountValidator();
				DTObject dtoinput = new DTObject();
				dtoinput.setValue("BRANCH_CODE", String.valueOf(_lcpsBrnCode));
				dtoinput.setValue("ACCOUNT_NUMBER", String.valueOf(_lcpsCustLiabAccNum));
				dtoinput.setValue("FetchReq", "true");
				dtoinput.setValue("FetchColumns", "ACNTS_CURR_CODE");
				Resultobj = AV.chkacntstatus(dtoinput);

				if (Check_Result_Status()) {
					_currcode = Resultobj.getValue("ACNTS_CURR_CODE");
					_acntnum = Resultobj.getValue("ACNTS_ACCOUNT_NUMBER");
					_intacntnum = Long.parseLong(Resultobj.getValue("ACNTS_INTERNAL_ACNUM"));
					_acntname = Resultobj.getValue("ACNTS_AC_NAME1");
					_effbal = Resultobj.getValue("EFF_BALANCE");

					LimitValidator LV = new LimitValidator();
					DTObject dtoinput1 = new DTObject();
					dtoinput1.setValue("ACASLLDTL_INTERNAL_ACNUM", String.valueOf(_intacntnum));
					Resultobj = LV.vallimitforacnt(dtoinput1);

					if (Check_Result_Status()) {
						_limline = Integer.parseInt(Resultobj.getValue("ACASLLDTL_LIMIT_LINE_NUM"));

						if (_limline != 0) {
							LimitValidator LV1 = new LimitValidator();
							dtoinput.setValue("LMTLINE_NUM", String.valueOf(_limline));
							dtoinput.setValue("LMTLINE_CLIENT_CODE", String.valueOf(_custnum));
							dtoinput.setValue("FetchReq", "true");
							dtoinput.setValue("FetchColumns", "LMTLINE_SANCTION_CURR,LMTLINE_SANCTION_AMT");
							Resultobj = LV1.vallimitline(dtoinput);

							if (Check_Result_Status()) {
								_lmtlinedesc = Resultobj.getValue("LMTLINE_FACILITY_DESCN");
								_sanccurr = Resultobj.getValue("LMTLINE_SANCTION_CURR");
								_sancamt = Resultobj.getValue("LMTLINE_SANCTION_AMT");
								CommonValidator curr = new CommonValidator();
								dtoinput.setValue("CURR_CODE", _sanccurr);
								Resultobj = curr.valcurrcd(dtoinput);
							}

							if (Check_Result_Status()) {
								_currname = Resultobj.getValue("CURR_NAME");
								LimitValidator LV2 = new LimitValidator();
								dtoinput.setValue("LMTLINE_NUM", String.valueOf(_limline));
								dtoinput.setValue("CLIENT_CODE", String.valueOf(_custnum));
								Resultobj = LV2.valllacntos(dtoinput);
							}

						}

					}

					if (Check_Result_Status()) {
						_outstdamt = Resultobj.getValue("OUT_STANDING_AMT");
						CommonValidator curr1 = new CommonValidator();
						dtoinput.setValue("CURR_CODE", baseCurrency);
						Resultobj = curr1.valcurrcd(dtoinput);

					}

				}

				if (Check_Result_Status()) {
					_declength = String.valueOf(cbsglobal.getcurrdeclength(_limit_CURR));
					_basecurrname = Resultobj.getValue("BASE_CURR_NAME");
					_QueryStr = "Select SUM(LCPS_TOT_LIAB_LIM_CURR) AS  LCPS_TOT_LIAB_LIM_CURR from LCPS where LCPS_BRN_CODE=? and LCPS_CUST_LIAB_ACC_NUM=? and LCPS_APPROVAL_REFUSAL= ?  ";
					Set_preparedStatement(_QueryStr);
					_pstmt.setInt(1, _lcpsBrnCode);
					_pstmt.setLong(2, _intacntnum);
					_pstmt.setString(3, spaces);
					Resultobj = Get_Value_From_Main("LCPS");
					if (Check_Result_Status()) {
						_totliablimcurr = Resultobj.getValue("LCPS_TOT_LIAB_LIM_CURR");
					}
				}
			}
			Resultobj.setValue("ACTUAL_ACNT_NUM", _acntnum);
			Resultobj.setValue("INTERNAL_ACNT_NUM", String.valueOf(_intacntnum));
			Resultobj.setValue("ACNT_NAME", _acntname);
			Resultobj.setValue("EFF_BAL", _effbal);
			Resultobj.setValue("CURR_CODE", _currcode);
			Resultobj.setValue("CURR_NAME", _currname);
			Resultobj.setValue("BASE_CURR_NAME", _basecurrname);
			Resultobj.setValue("LMTLINE_NUM", String.valueOf(_limline));
			Resultobj.setValue("LMTLINE_DESCN", _lmtlinedesc);
			Resultobj.setValue("SANC_CURR", _sanccurr);
			Resultobj.setValue("SANC_AMT", _sancamt);
			Resultobj.setValue("OUTSTD_AMT", _outstdamt);
			Resultobj.setValue("TOT_LIAB_LIM_CURR", _totliablimcurr);
			Resultobj.setValue("DEC_LEN", _sanccurr);
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in lcpsCustLiabAccNumkeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	/*    InputKey=CBD
	 *    outputKey=FINANCIAL_YEAR
	 */
	//   ************************************************************************************************************    
	public DTObject getFinancialYear(DTObject InputoBj) {
		try {

			String _currBusDate = InputoBj.getValue("CBD");

			Resultobj.setValue("FINANCIAL_YEAR", getFinYear(_currBusDate));
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in getFinancialYear");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************
	// *********************************************************************************************************

	public DTObject CaseOne(DTObject InputoBj) {
		try {
			//
			int _irttBrnCode = 0;
			String _irttType = "";
			int _irttYear = 0;
			int _irttTranSer = 0;
			String _termsCode = "";
			_irttBrnCode = Integer.parseInt(InputoBj.getValue("OLC_BRN_CODE").trim().toString());
			_irttType = InputoBj.getValue("OLC_LC_TYPE").trim().toString();
			_irttYear = Integer.parseInt(InputoBj.getValue("OLC_LC_YEAR").trim().toString());
			_irttTranSer = Integer.parseInt(InputoBj.getValue("OLC_LC_SL").trim().toString());
			//Changes P.Subramani-Chn-12/04/2008 Beg
			//Changes P.Subramani-Chn-19/08/2008 BEg //ADDED ON 16/10/2018
			_QueryStr = "SELECT OLC_BENEF_CODE, OLC_BENEF_NAME, OLC_BENEF_ADDR1, OLC_BENEF_ADDR2, OLC_BENEF_ADDR3, OLC_BENEF_ADDR4, OLC_BENEF_ADDR5, OLC_BENEF_CNTRY_CODE, " + "OLC_LC_AMOUNT,OLC_LC_CURR_CODE,OLC_BRN_CODE, OLC_DEV_ALLWD, OLC_POS_DEV_ALLWD, OLC_NEG_DEV_ALLWD, OLC_DEV_AMOUNT,OLC_AMT_QUALFR,OLC_PRICE_TERMS, " + "OLC_LAST_DATE_OF_NEG, OLC_LATEST_DATE_OF_SHPMNT, OLC_WITHIN_VALIDATE_LC ,OLC_BRN_CODE, OLC_LC_UI_BORNE_BY_APPLCNT, OLC_NOF_TENORS, "
					+ "OLC_TOT_LIAB_LC_CURR,OLC_TOT_LIAB_BASE_CURR,OLC_NOF_TENORS,OLC_PLACE_OF_EXPIRY,OLC_CONV_RATE_BASE_CURR,OLC_TOT_LIAB_BASE_CURR,OLC_CONV_RATE_LIM_CURR,OLC_DEV_AMOUNT,OLC_NEG_DEV_ALLWD,OLC_POS_DEV_ALLWD,OLC_LC_AMOUNT,OLC_BENEF_CNTRY_CODE,OLC_USN_CHG_TAKEN_DAYS,OLC_COMMIT_CHG_TAKEN_DAYS,OLC_CORR_REF_NUM,TO_CHAR(OLC_LC_PRESANC_DATE,'DD-MM-YYYY') AS  OLC_LC_PRESANC_DATE FROM OLC WHERE OLC_BRN_CODE = ?  AND OLC_LC_TYPE = ?  AND OLC_LC_YEAR = ?  AND OLC_LC_SL = ?";
			//Changes P.Subramani-Chn-19/08/2008 End
			//Changes P.Subramani-Chn-12/04/2008 End
			Set_preparedStatement(_QueryStr);
			_pstmt.setInt(1, _irttBrnCode);
			_pstmt.setString(2, _irttType);
			_pstmt.setInt(3, _irttYear);
			_pstmt.setInt(4, _irttTranSer);
			Resultobj = Get_Value_From_Main("OLC");
			if (Check_Result_Status() == true) {
				if (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowNotPresent)) {
					Resultobj.setValue(ErrorKey, "Row Not Present in olc");
				} else {
					Resultobj.setValue(ErrorKey, "");
				}
			}

		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in CASE_ONE");
		}
		return Resultobj.copyofDTO();
	}

	//***********************************************************************************************************************
	public DTObject SwiftDetails(DTObject InputoBj) {
		try {

			int _irttBrnCode = 0;
			String _irttType = "";
			int _irttYear = 0;
			int _irttTranSer = 0;
			String _termsCode = "";
			_irttBrnCode = Integer.parseInt(InputoBj.getValue("OLC_BRN_CODE").trim().toString());
			_irttType = InputoBj.getValue("OLC_LC_TYPE").trim().toString();
			_irttYear = Integer.parseInt(InputoBj.getValue("OLC_LC_YEAR").trim().toString());
			_irttTranSer = Integer.parseInt(InputoBj.getValue("OLC_LC_SL").trim().toString());

			_QueryStr = "SELECT LC_REC_BIC_CODE, LC_PLACE_OF_TAKING_IN_CHARGE,LC_PORT_OF_LOADING,LC_PORT_OF_DISCHARGE,LC_PLACE_OF_FINAL_DEST FROM LC_DETAILS WHERE LC_BRN_CODE = ?  AND LC_LC_TYPE = ?  AND LC_LC_YEAR = ?  AND LC_LC_SL = ?";

			Set_preparedStatement(_QueryStr);
			_pstmt.setInt(1, _irttBrnCode);
			_pstmt.setString(2, _irttType);
			_pstmt.setInt(3, _irttYear);
			_pstmt.setInt(4, _irttTranSer);
			Resultobj = Get_Value_From_Main("LC_DETAILS");
			if (Check_Result_Status() == true) {
				if (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowNotPresent)) {
					Resultobj.setValue(ErrorKey, "Row Not Present in lc_details");
				} else {
					Resultobj.setValue(ErrorKey, "");
				}
			}

		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in SwiftDetails");
		}
		return Resultobj.copyofDTO();
	}

	//*********************************************************************************************************************** 
	public DTObject CaseOneGrid(DTObject InputoBj) {
		try {
			//
			int _irttBrnCode = 0;
			String _irttType = "";
			int _irttYear = 0;
			int _irttTranSer = 0;
			_irttBrnCode = Integer.parseInt(InputoBj.getValue("OLC_BRN_CODE").trim().toString());
			_irttType = InputoBj.getValue("OLC_LC_TYPE").trim().toString();
			_irttYear = Integer.parseInt(InputoBj.getValue("OLC_LC_YEAR").trim().toString());
			_irttTranSer = Integer.parseInt(InputoBj.getValue("OLC_LC_SL").trim().toString());

			_QueryStr = "select OLCT_TENOR_SL, OLCT_TENOR_TYPE, OLCT_USANCE_PERD, OLCT_USANCE_FROM, OLCT_OTHER_DATE_DESC, OLCT_OTHER_DATE_START_FROM, OLCT_TENOR_AMT, OLCT_USANCE_INT_RATE, OLCT_USANCE_INT_AMT, OLCT_BAL_TENOR_AMT, OLCT_BAL_USANCE_INT_AMT, OLCT_BAL_DIFF_AMT_UTIL, OLCT_TOT_TENOR_LIAB, OLCT_DOC_DELIVERY from OLCTENORS where OLCT_BRN_CODE=? and OLCT_LC_TYPE=? and OLCT_LC_YEAR=? and OLCT_LC_SL=?";
			Set_preparedStatement(_QueryStr);
			_pstmt.setInt(1, _irttBrnCode);
			_pstmt.setString(2, _irttType);
			_pstmt.setInt(3, _irttYear);
			_pstmt.setInt(4, _irttTranSer);
			Resultobj = Get_Value_From_Main("OLCTENORS");
			if (Check_Result_Status() == true) {
				if (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowNotPresent)) {
					Resultobj.setValue(ErrorKey, "Row Not Present in OLCTENORS");
				}
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in CASE_ONE_GRID");
		}
		return Resultobj.copyofDTO();
	}

	//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------  
	public DTObject CaseTwo(DTObject InputoBj) {
		try {
			//
			int _irttBrnCode = 0;
			String _irttType = "";
			int _irttYear = 0;
			int _irttTranSer = 0;
			int _amdSl = 0;
			_irttBrnCode = Integer.parseInt(InputoBj.getValue("OLCA_BRN_CODE").trim().toString());
			_irttType = InputoBj.getValue("OLCA_LC_TYPE").trim().toString();
			_irttYear = Integer.parseInt(InputoBj.getValue("OLCA_LC_YEAR").trim().toString());
			_irttTranSer = Integer.parseInt(InputoBj.getValue("OLCA_LC_SL").trim().toString());
			_amdSl = Integer.parseInt(InputoBj.getValue("OLCA_AMD_SL").trim().toString());
			_amdSl = _amdSl - 1;
			_QueryStr = "select OLCA_ENHANCEMNT_REDUCN, OLCA_LC_CURR_CODE, OLCA_AMENDED_AMT, OLCA_POS_DEV_ALLWD, OLCA_NEG_DEV_ALLWD, OLCA_DEV_AMT, OLCA_AMT_QUALFR, OLCA_PRICE_TERMS, OLCA_LAST_DATE_OF_NEG, OLCA_PLACE_OF_EXPIRY, OLCA_LATEST_DATE_OF_SHPMNT, OLCA_WITHIN_VALIDATE_LC, OLCA_LC_UI_BORNE_BY_APPLCNT, OLCA_NOF_TENORS, OLCA_ADD_LIAB_LC_CURR, OLCA_CONV_RATE_BASE_CURR, OLCA_ADD_LIAB_BASE_CURR,OLCA_CONV_RATE_LIM_CURR,OLCA_CONV_RATE_BASE_CURR,OLCA_ADD_LIAB_LC_CURR,OLCA_POS_DEV_ALLWD,OLCA_LC_UI_BORNE_BY_APPLCNT,OLCA_WITHIN_VALIDATE_LC,OLCA_LATEST_DATE_OF_SHPMNT,OLCA_PLACE_OF_EXPIRY,OLCA_PRICE_TERMS,OLCA_AMT_QUALFR,OLCA_DEV_AMT,OLCA_NEG_DEV_ALLWD,OLCA_POS_DEV_ALLWD,OLCA_AMENDED_AMT from OLCAMD where OLCA_BRN_CODE=? and OLCA_LC_TYPE=? and OLCA_LC_YEAR=? and OLCA_LC_SL=? and OLCA_AMD_SL=?";
			Set_preparedStatement(_QueryStr);
			_pstmt.setInt(1, _irttBrnCode);
			_pstmt.setString(2, _irttType);
			_pstmt.setInt(3, _irttYear);
			_pstmt.setInt(4, _irttTranSer);
			_pstmt.setInt(5, _amdSl);
			Resultobj = Get_Value_From_Main("OLCAMD");
			if (Check_Result_Status() == true) {
				if (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowNotPresent)) {
					Resultobj.setValue(ErrorKey, "Row Not Present in OLCAMD");
				}
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in CASE_TWO");
		}
		return Resultobj.copyofDTO();
	}

	public DTObject CaseTwoGrid(DTObject InputoBj) {
		try {
			//
			int _irttBrnCode = 0;
			String _irttType = "";
			int _irttYear = 0;
			int _irttTranSer = 0;
			int _amdSl = 0;
			_irttBrnCode = Integer.parseInt(InputoBj.getValue("OLCA_BRN_CODE").trim().toString());
			_irttType = InputoBj.getValue("OLCA_LC_TYPE").trim().toString();
			_irttYear = Integer.parseInt(InputoBj.getValue("OLCA_LC_YEAR").trim().toString());
			_irttTranSer = Integer.parseInt(InputoBj.getValue("OLCA_LC_SL").trim().toString());
			_amdSl = Integer.parseInt(InputoBj.getValue("OLCA_AMD_SL").trim().toString());
			_amdSl = _amdSl - 1;
			_QueryStr = "SELECT OLCTA_TENOR_SL, OLCTA_TENOR_TYPE, OLCTA_USANCE_PERD, OLCTA_USANCE_FROM, OLCTA_OTHER_DATE_DESC, OLCTA_OTHER_DATE_START_FROM, OLCTA_DEF_PAYMENT, OLCTA_TENOR_AMT, OLCTA_USANCE_INT_RATE, OLCTA_USANCE_INT_AMT, OLCTA_DOC_DELIVERY, OLCTA_USN_CHRG_TAKEN_DAYS, OLCTA_PREV_AMT_FOR_COMM FROM OLCTENORSAMD " + "WHERE OLCTA_BRN_CODE=? AND OLCTA_LC_TYPE=? AND OLCTA_LC_YEAR=? AND OLCTA_LC_SL=? AND OLCTA_AMD_SL=?";
			Set_preparedStatement(_QueryStr);
			_pstmt.setInt(1, _irttBrnCode);
			_pstmt.setString(2, _irttType);
			_pstmt.setInt(3, _irttYear);
			_pstmt.setInt(4, _irttTranSer);
			_pstmt.setInt(5, _amdSl);
			Resultobj = Get_Value_From_Main("OLCTENORSAMD");
			if (Check_Result_Status() == true) {
				if (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowNotPresent)) {
					Resultobj.setValue(ErrorKey, "Row Not Present in OLCTENORSAMD");
				}
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in CASE_TWO_GRID");
		}
		return Resultobj.copyofDTO();
	}

	//Conversion Rates
	public DTObject olcConvToBaseCurrkeypress(DTObject InputoBj) {
		try {
			String _lcCurr = "";
			String _baseCurr = "";
			double add_lc_liab_amt = 0;
			double red_lc_liab_amt = 0; // M.Murali - Added - 16-05-2012 
			double _convRate = 0;
			double _agnstValue1 = 0;
			double _agnstValue2 = 0;
			String _declength = "";
			String _enc_red = "";
			double _totalAftAmd = 0;
			_lcCurr = InputoBj.getValue("LC_CURR").trim().toString();
			_baseCurr = InputoBj.getValue("BASE_CURR").trim().toString();
			_enc_red = InputoBj.getValue("ENC_RED").trim().toString();
			Init_ResultObj(InputoBj);

			if (String.valueOf(_lcCurr).trim().equalsIgnoreCase("") && String.valueOf(_baseCurr).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}

			if (Check_Result_Status()) {
				if (_enc_red.equalsIgnoreCase("E")) {
					add_lc_liab_amt = Double.parseDouble(InputoBj.getValue("ADD_LC_LIAB_AMT").trim().toString());
					_convRate = Double.parseDouble(InputoBj.getValue("CONV_RATE").trim().toString());
					_totalAftAmd = Double.parseDouble(InputoBj.getValue("TOTAL_AFT_AMD").trim().toString());
					if (Check_Result_Status()) {
						dtobj.clearMap();
						dtobj.setValue("FOR_CURR", _lcCurr);
						dtobj.setValue("AGNST_CURR", _baseCurr);
						dtobj.setValue("AMT_FOR_CURR", String.valueOf(add_lc_liab_amt));
						dtobj.setValue("CONVER_RATE", String.valueOf(_convRate));
						Resultobj = comnval.calAgnstVal(dtobj);
					}
					if (Check_Result_Status()) {
						_agnstValue1 = Double.parseDouble(Resultobj.getValue("AMT_AGNST_CURR"));
						_declength = String.valueOf(cbsglobal.getcurrdeclength(_baseCurr));
					}
				} else {
					red_lc_liab_amt = Double.parseDouble(InputoBj.getValue("RED_LC_LIAB_AMT").trim().toString());
					_convRate = Double.parseDouble(InputoBj.getValue("CONV_RATE").trim().toString());
					_totalAftAmd = Double.parseDouble(InputoBj.getValue("TOTAL_AFT_AMD").trim().toString());
					if (Check_Result_Status()) {
						dtobj.clearMap();
						dtobj.setValue("FOR_CURR", _lcCurr);
						dtobj.setValue("AGNST_CURR", _baseCurr);
						dtobj.setValue("AMT_FOR_CURR", String.valueOf(red_lc_liab_amt));
						dtobj.setValue("CONVER_RATE", String.valueOf(_convRate));
						Resultobj = comnval.calAgnstVal(dtobj);
					}
					if (Check_Result_Status()) {
						_agnstValue1 = Double.parseDouble(Resultobj.getValue("AMT_AGNST_CURR"));
						_declength = String.valueOf(cbsglobal.getcurrdeclength(_baseCurr));
					}

				}

			}
			// M.Murali - Added - 16-05-2012 - End
			Init_ResultObj(InputoBj);
			if (Check_Result_Status()) {
				dtobj.clearMap();
				dtobj.setValue("FOR_CURR", _lcCurr);
				dtobj.setValue("AGNST_CURR", _baseCurr);
				dtobj.setValue("AMT_FOR_CURR", String.valueOf(_totalAftAmd));
				dtobj.setValue("CONVER_RATE", String.valueOf(_convRate));
				Resultobj = comnval.calAgnstVal(dtobj);
			}
			if (Check_Result_Status()) {
				_agnstValue2 = Double.parseDouble(Resultobj.getValue("AMT_AGNST_CURR"));
			}

			if (Check_Result_Status()) {
				Resultobj.setValue("AMT_AGNST_CURR1", String.valueOf(_agnstValue1));
				Resultobj.setValue("AMT_AGNST_CURR2", String.valueOf(_agnstValue2));
				Resultobj.setValue("DEC_LEN", String.valueOf(_declength));
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in olcInsCompanykeypress");
		}
		return Resultobj.copyofDTO();
	}

	// Changes P.Subramani-12/04/2008 Beg   
	// *********************************************************************************************************
	/*Method Name -						olcChargeskeypress
	 * Input 	- 						Key =TENOR_TYPE                                         
	
	 * Output:   	    			 	Key = CHGCD_CHG_CURR_OPTION
	 */

	public DTObject olctenortypechgcodecurroptionkeypress(DTObject InputoBj) {
		try {
			String tenortype = "";
			String Chgcodecurropt = "";
			if (InputoBj.getValue("TENOR_TYPE").trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			} else {
				tenortype = InputoBj.getValue("TENOR_TYPE").trim().toString();

			}
			Init_ResultObj(InputoBj);

			if (Check_Result_Status()) {
				_QueryStr = "select CHGCD_CHG_CURR_OPTION from CHGCD where CHGCD_CHARGE_CODE=?";
				Set_preparedStatement(_QueryStr);
				_pstmt.setString(1, tenortype);
				Resultobj = Get_Value_From_Main("CHGCD");
				Chgcodecurropt = Resultobj.getValue("CHGCD_CHG_CURR_OPTION");
			}
			Resultobj.setValue("CHGCD_CHG_CURR_OPTION", Chgcodecurropt);
			Resultobj.setValue(ErrorKey, "");
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in olcChargeskeypress");
		}
		return Resultobj.copyofDTO();
	}

	//*****************************************************************************************************************    
	public DTObject olcusanceforamountkeypress(DTObject InputoBj) {
		try {
			//Changes P.Subramani-Chn-22/04/2008 Beg
			double usancechgs = 0.0;

			Connection _conn = null;
			CallableStatement _cstmt = null;
			_conn = openConnection();
			_cstmt = _conn.prepareCall("CALL AMD_USANCE_CHG_FOR_AMOUNT(?,?,?,?,?,?,?,?,?,?)");
			_cstmt.setString(1, InputoBj.getValue("OLC_PROD_CODE"));
			_cstmt.setString(2, InputoBj.getValue("OLC_LC_TYPE"));
			_cstmt.setInt(3, Integer.parseInt(InputoBj.getValue("OLC_CUST_NUM")));
			_cstmt.setDouble(4, Double.parseDouble(InputoBj.getValue("OLC_PREV_LC_AMT")));
			_cstmt.setDouble(5, Double.parseDouble(InputoBj.getValue("OLC_LC_AMT")));
			_cstmt.setInt(6, Integer.parseInt(InputoBj.getValue("OLC_LC_DAYS")));
			_cstmt.setString(7, InputoBj.getValue("OLC_TENOR_TYPE"));
			_cstmt.setString(8, InputoBj.getValue("OLC_AMD_TYPE"));
			_cstmt.registerOutParameter(9, Types.VARCHAR);
			_cstmt.registerOutParameter(10, Types.DOUBLE);
			_cstmt.execute();

			usancechgs = _cstmt.getDouble(10);

			if (Check_Result_Status()) {
				Resultobj.setValue("USANCE_CHGS", String.valueOf(usancechgs));
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in olcusanceforamountkeypress");
		}
		return Resultobj.copyofDTO();
	}

	//  *****************************************************************************************************************    
	public DTObject olcusanceforperiodkeypress(DTObject InputoBj) {
		try {
			double usancechgs = 0.0;
			int usancechgstakendays = 0;

			Connection _conn = null;
			CallableStatement _cstmt = null;
			_conn = openConnection();
			_cstmt = _conn.prepareCall("CALL AMD_USANCE_CHG_FOR_PERIOD(?,?,?,?,?,?,?,?,?,?,?)");
			_cstmt.setString(1, InputoBj.getValue("OLC_PROD_CODE"));
			_cstmt.setString(2, InputoBj.getValue("OLC_LC_TYPE"));
			_cstmt.setInt(3, Integer.parseInt(InputoBj.getValue("OLC_CUST_NUM")));
			_cstmt.setDouble(4, Double.parseDouble(InputoBj.getValue("OLC_LC_AMT")));
			_cstmt.setInt(5, Integer.parseInt(InputoBj.getValue("OLC_LC_DAYS")));
			_cstmt.setString(6, InputoBj.getValue("OLC_TENOR_TYPE"));
			_cstmt.setString(7, InputoBj.getValue("OLC_AMD_TYPE"));
			_cstmt.setInt(8, Integer.parseInt(InputoBj.getValue("OLC_PREV_USANCE_DAYS")));

			_cstmt.registerOutParameter(9, Types.INTEGER);
			_cstmt.registerOutParameter(10, Types.VARCHAR);
			_cstmt.registerOutParameter(11, Types.DOUBLE);
			_cstmt.execute();

			usancechgstakendays = _cstmt.getInt(9);
			usancechgs = _cstmt.getDouble(11);

			if (Check_Result_Status()) {
				Resultobj.setValue("USANCE_CHGS", String.valueOf(usancechgs));
				Resultobj.setValue("USANCE_CHGS_TAKEN_DAYS", String.valueOf(usancechgstakendays));
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in olcusanceforperiodkeypress");
		}
		return Resultobj.copyofDTO();
	}

	//*****************************************************************************************************************    
	public DTObject olccommforamountkeypress(DTObject InputoBj) {
		try {
			double commchgs = 0.0;

			Connection _conn = null;
			CallableStatement _cstmt = null;
			_conn = openConnection();
			_cstmt = _conn.prepareCall("CALL AMD_COMMITMENT_CHG_FOR_AMOUNT(?,?,?,?,?,?,?)");
			_cstmt.setString(1, InputoBj.getValue("OLC_PROD_CODE"));
			_cstmt.setString(2, InputoBj.getValue("OLC_LC_TYPE"));
			_cstmt.setInt(3, Integer.parseInt(InputoBj.getValue("OLC_CUST_NUM")));
			_cstmt.setDouble(4, Double.parseDouble(InputoBj.getValue("OLC_PREV_LC_AMT")));
			_cstmt.setDouble(5, Double.parseDouble(InputoBj.getValue("OLC_LC_AMT")));
			_cstmt.setInt(6, Integer.parseInt(InputoBj.getValue("OLC_LC_DAYS")));
			_cstmt.registerOutParameter(7, Types.DOUBLE);
			_cstmt.execute();

			commchgs = _cstmt.getDouble(7);

			if (Check_Result_Status()) {
				Resultobj.setValue("COMM_CHGS", String.valueOf(commchgs));
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in olccommforamountkeypress");
		}
		return Resultobj.copyofDTO();
	}

	//  *****************************************************************************************************************    
	public DTObject olccommforperiodkeypress(DTObject InputoBj) {
		try {
			double commchgs = 0.0;
			int commchgstakendays = 0;

			Connection _conn = null;
			CallableStatement _cstmt = null;
			_conn = openConnection();
			_cstmt = _conn.prepareCall("CALL AMD_COMMITMENT_CHG_FOR_PERIOD(?,?,?,?,?,?,?,?)");
			_cstmt.setString(1, InputoBj.getValue("OLC_PROD_CODE"));
			_cstmt.setString(2, InputoBj.getValue("OLC_LC_TYPE"));
			_cstmt.setInt(3, Integer.parseInt(InputoBj.getValue("OLC_CUST_NUM")));
			_cstmt.setDouble(4, Double.parseDouble(InputoBj.getValue("OLC_LC_AMT")));
			_cstmt.setInt(5, Integer.parseInt(InputoBj.getValue("OLC_LC_DAYS")));
			_cstmt.setInt(6, Integer.parseInt(InputoBj.getValue("OLC_PREV_COMM_DAYS")));
			_cstmt.registerOutParameter(7, Types.INTEGER);
			_cstmt.registerOutParameter(8, Types.DOUBLE);
			_cstmt.execute();

			commchgstakendays = _cstmt.getInt(7);
			commchgs = _cstmt.getDouble(8);

			if (Check_Result_Status()) {
				Resultobj.setValue("COMM_CHGS", String.valueOf(commchgs));
				Resultobj.setValue("COMM_CHGS_TAKEN_DAYS", String.valueOf(commchgstakendays));
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in olccommforperiodkeypress");
		}
		return Resultobj.copyofDTO();
	}

	//Changes P.Subramani-12/04/2008 End
	//********************************************************************************************************************   

	//  Changes P.Subramani-28/04/2008 Beg   
	//  *********************************************************************************************************
	/*Method Name -						olccustnumkeypress
	 * Input 	- 						Key =OLC_PROD_CODE                                         
										Key =OLC_LC_TYPE
										Key =OLC_CUST_NUM
										
	 * Output:   	    			 	Key = CUSTOMER_NUMBER
	 */

	public DTObject olccustnumkeypress(DTObject InputoBj) {
		try {
			String prodcode = "";
			String lctype = "";
			String custnum = "";
			prodcode = InputoBj.getValue("OLC_PROD_CODE").trim().toString();
			lctype = InputoBj.getValue("OLC_LC_TYPE").trim().toString();
			custnum = InputoBj.getValue("OLC_CUST_NUM").trim().toString();
			Init_ResultObj(InputoBj);
			if (Check_Result_Status()) {
				_QueryStr = "SELECT LCC_CUSTOMERWISE_CHGS_REQD,LCC_CUST_NUM FROM LCCOMM WHERE LCC_PROD_CODE=? AND LCC_LC_TYPE=? AND LCC_CUST_NUM=?";
				Set_preparedStatement(_QueryStr);
				_pstmt.setInt(1, Integer.parseInt(prodcode));
				_pstmt.setString(2, lctype);
				_pstmt.setInt(3, Integer.parseInt(custnum));
				Resultobj = Get_Value_From_Main("LCCOMM");

				if (Check_Result_Status()) {
					if (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowPresent)) {
						if (Resultobj.getValue("LCC_CUSTOMERWISE_CHGS_REQD").equalsIgnoreCase("0")) {
							custnum = "0";
						} else {
							custnum = Resultobj.getValue("LCC_CUST_NUM");
						}
					} else if (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowNotPresent)) {
						custnum = "0";
					}
				}
			}
			Resultobj.setValue("CUSTOMER_NUMBER", String.valueOf(custnum));
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in olccustnumkeypress");
		}
		return Resultobj.copyofDTO();
	}

	//   Changes P.Subramani-28/04/2008 End    
	// *****************************************************************************************************************

	//   *********************************************************************************************************
	/*
	 * Input 	- 						Key =OLC_LC_SL
	 * 										 BRANCH_CODE
	 * 										 OLC_TYPE
	 * 										 OLC_YEAR
	 * 										 OLCA_AMD_SL
	 * 										 OPTION	
	 * Output	: Error Message  		- 		Key = ErrorMsg
	 * 											Key=AMD_SERIAL
	 */

	public DTObject olcLcSlkeypress1(DTObject InputoBj) {
		try {
			int _olcLcSl = 0;
			int _branchCode = 0;
			int _olcYear = 0;
			String _olctype = "";
			String _option = "";
			String _max_SL = "";
			int _amdSl = 0;
			String _custRef = "";
			String _benefCode = "";
			String _benefName = "";
			String _addr1 = "";
			String _addr2 = "";
			String _addr3 = "";
			String _addr4 = "";
			String _addr5 = "";
			String _lcdate = "";
			String _lcissBank = "";
			String _lcissBranch = "";
			String _lcissPlace = "";
			String _lcissCountry = "";
			String _lcAmt = "";
			String _lcBal = "";
			String _lcCurr = "";
			String _custNum = "";
			String _countryCode = "";
			int _lcpsl = 0;
			String _lcpsdate = "";
			String _liabAcc = "";
			String _limitCurr = "";
			String _limitline = "";
			double _totalliabbasecurr = 0;
			String _drawDown = null;
			String _olcDevBal = "";
			String _declength1 = "";
			String _positiveDeviAllowed = "";
			String custname = "";
			String bankname = "";
			String branchname = "";
			String countryname = "";
			String custadd1 = "";
			String custadd2 = "";
			String custadd3 = "";
			String custadd4 = "";
			String custadd5 = "";
			if (InputoBj.getValue("OLC_LC_SL").trim().equalsIgnoreCase("")) {
				_olcLcSl = 0;
			} else {
				_olcLcSl = Integer.parseInt(InputoBj.getValue("OLC_LC_SL").trim().toString());
				_branchCode = Integer.parseInt(InputoBj.getValue("BRANCH_CODE").trim().toString());
				_olcYear = Integer.parseInt(InputoBj.getValue("OLC_YEAR").trim().toString());
				_olctype = InputoBj.getValue("OLC_TYPE").trim().toString();
				_option = InputoBj.getValue("OPTION").trim().toString();

			}
			Init_ResultObj(InputoBj);
			if (!String.valueOf(_olcLcSl).trim().equalsIgnoreCase("")) {
				if (_olcLcSl == 0)
					if ((InputoBj.containsKey("OLC_LC_SL") == true) && (InputoBj.getValue("OLC_LC_SL").trim().equalsIgnoreCase("")))
						Resultobj.setValue(ErrorKey, BLANK_CHECK);
					else
						Resultobj.setValue(ErrorKey, ZERO_CHECK);
			}
			if (Check_Result_Status()) {
				dtobj.clearMap();
				dtobj.setValue("OLC_LC_TYPE", _olctype);
				dtobj.setValue("OLC_BRN_CODE", String.valueOf(_branchCode));
				dtobj.setValue("OLC_LC_YEAR", String.valueOf(_olcYear));
				dtobj.setValue("OLC_LC_SL", String.valueOf(_olcLcSl));
				dtobj.setValue(FetchReq, "true");
				dtobj
						.setValue(
								"FetchColumns",
								"OLC_POS_DEV_ALLWD,OLC_DEV_BAL,OLC_LC_PRESANC_DATE, OLC_LC_PRESANC_DAY_SL,OLC_CORR_REF_NUM, OLC_LC_DATE, OLC_CUST_NUM, OLC_BENEF_CODE, OLC_BENEF_NAME, OLC_BENEF_ADDR1, OLC_BENEF_ADDR2, OLC_BENEF_ADDR3, OLC_BENEF_ADDR4, OLC_BENEF_ADDR5, OLC_BENEF_CNTRY_CODE, OLC_LC_ISS_BK_CODE, OLC_LC_ISS_BRN_CODE, OLC_LC_ISS_PLACE, OLC_LC_ISS_CNTRY, OLC_LC_ADV_THRU, OLC_LC_CURR_CODE, OLC_LC_AMOUNT, OLC_LC_BALANCE, OLC_DEV_ALLWD, OLC_POS_DEV_ALLWD, OLC_NEG_DEV_ALLWD, OLC_DEV_AMOUNT, OLC_AMT_QUALFR, OLC_PRICE_TERMS, OLC_LAST_DATE_OF_NEG, OLC_PLACE_OF_EXPIRY, OLC_LATEST_DATE_OF_SHPMNT, OLC_WITHIN_VALIDATE_LC, OLC_LC_UI_BORNE_BY_APPLCNT, OLC_NOF_TENORS, OLC_TOT_LIAB_LC_CURR, OLC_CONV_RATE_BASE_CURR, OLC_TOT_LIAB_BASE_CURR, OLC_CONV_RATE_LIM_CURR, OLC_TOT_LIAB_LIM_CURR,OLC_AUTH_BY,OLC_REJ_BY");
				Resultobj = olcval.valolc(dtobj);
				if (Check_Result_Status() == true) {
					if (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowNotPresent)) {
						Resultobj.setValue(ErrorKey, "No Documentation For This LC");
					} else {
						_custRef = Resultobj.getValue("OLC_CORR_REF_NUM");
						_addr1 = Resultobj.getValue("OLC_BENEF_ADDR1");
						_addr2 = Resultobj.getValue("OLC_BENEF_ADDR2");
						_addr3 = Resultobj.getValue("OLC_BENEF_ADDR3");
						_addr4 = Resultobj.getValue("OLC_BENEF_ADDR4");
						_addr5 = Resultobj.getValue("OLC_BENEF_ADDR5");
						_benefCode = Resultobj.getValue("OLC_BENEF_CODE");
						_benefName = Resultobj.getValue("OLC_BENEF_NAME");
						_lcAmt = Resultobj.getValue("OLC_LC_AMOUNT");
						_lcBal = Resultobj.getValue("OLC_LC_BALANCE");
						_lcCurr = Resultobj.getValue("OLC_LC_CURR_CODE");
						_lcdate = Resultobj.getValue("OLC_LC_DATE");
						_lcissBank = Resultobj.getValue("OLC_LC_ISS_BK_CODE");
						_lcissBranch = Resultobj.getValue("OLC_LC_ISS_BRN_CODE");
						_lcissCountry = Resultobj.getValue("OLC_LC_ISS_CNTRY");
						_lcissPlace = Resultobj.getValue("OLC_LC_ISS_PLACE");
						_custNum = Resultobj.getValue("OLC_CUST_NUM");
						custnoHidden = _custNum;
						_positiveDeviAllowed = Resultobj.getValue("OLC_POS_DEV_ALLWD");
						_olcDevBal = Resultobj.getValue("OLC_DEV_BAL");
						_countryCode = Resultobj.getValue("OLC_BENEF_CNTRY_CODE");
						_lcpsdate = Resultobj.getValue("OLC_LC_PRESANC_DATE");
						_drawDown = Resultobj.getValue("OLC_NOF_TENORS");
						_lcpsl = Integer.parseInt(Resultobj.getValue("OLC_LC_PRESANC_DAY_SL"));
						_totalliabbasecurr = Double.parseDouble(Resultobj.getValue("OLC_TOT_LIAB_BASE_CURR"));
						if (_custNum != null) {
							if (!_custNum.equalsIgnoreCase("")) {
								ClientValidator clieval = new ClientValidator();
								dtobj.clearMap();
								dtobj.setValue("CLIENTS_CODE", _custNum);
								dtobj.setValue(FetchReq, "true");
								Resultobj = clieval.clientValid(dtobj);
								custname = Resultobj.getValue("CLIENTS_NAME");
								custadd1 = Resultobj.getValue("CLIENTS_ADDR1");
								custadd2 = Resultobj.getValue("CLIENTS_ADDR2");
								custadd3 = Resultobj.getValue("CLIENTS_ADDR3");
								custadd4 = Resultobj.getValue("CLIENTS_ADDR4");
								custadd5 = Resultobj.getValue("CLIENTS_ADDR5");
							}
						}

						if (_lcissBranch != null) {
							if (!_lcissBranch.equalsIgnoreCase("")) {
								BranchValidator BV = new BranchValidator();
								dtobj.clearMap();
								dtobj.setValue("MBRN_CODE", _lcissBranch);
								Resultobj = BV.chkBrnValid(dtobj);
								branchname = Resultobj.getValue("MBRN_NAME");
							}
						}

						if (_lcissBank != null) {
							if (!_lcissBank.equalsIgnoreCase("")) {
								CommonValidator CV = new CommonValidator();
								dtobj.clearMap();
								dtobj.setValue("BANKCD_CODE", _lcissBank);
								Resultobj = CV.valbankcd(dtobj);
								bankname = Resultobj.getValue("BANKCD_NAME");
							}
						}

						if (_lcissCountry != null) {
							if (!_lcissCountry.equalsIgnoreCase("")) {
								CommonValidator CV = new CommonValidator();
								dtobj.clearMap();
								dtobj.setValue("CNTRY_CODE", _lcissCountry);
								Resultobj = CV.valcntrycd(dtobj);
								countryname = Resultobj.getValue("CNTRY_NAME");
							}
						}
						if (Check_Result_Status()) {
							_QueryStr = "select LCPS_BRN_CODE, facno(LCPS_CUST_LIAB_ACC_NUM)LCPS_CUST_LIAB_ACC_NUM, LCPS_LIMIT_LINE_NUM, LCPS_LIM_CURR from lcps where LCPS_BRN_CODE = ? and LCPS_ENTRY_DATE = ? and LCPS_DAY_SL = ?";
							Set_preparedStatement(_QueryStr);
							_pstmt.setInt(1, _branchCode);
							_pstmt.setTimestamp(2, DateToYYYYMMDD(_lcpsdate));
							_pstmt.setInt(3, _lcpsl);
							Resultobj = Get_Value_From_Main("LCPS");
						}
						if (Check_Result_Status()) {
							_declength1 = String.valueOf(cbsglobal.getcurrdeclength(_lcCurr));
						}
						if (Check_Result_Status()) {
							_liabAcc = Resultobj.getValue("LCPS_CUST_LIAB_ACC_NUM");
							_limitCurr = Resultobj.getValue("LCPS_LIM_CURR");
							_limitline = Resultobj.getValue("LCPS_LIMIT_LINE_NUM");
							_limitlineHidden = _limitline;
							if (Check_Result_Status()) {
								_QueryStr = "Select nvl(max(OLCA_AMD_SL),0) + 1 as max_Amdsl from OLCAMD where OLCA_BRN_CODE = ? and OLCA_LC_TYPE = ? and OLCA_LC_YEAR = ? and OLCA_LC_SL=?";
								Set_preparedStatement(_QueryStr);
								_pstmt.setInt(1, _branchCode);
								_pstmt.setString(2, _olctype);
								_pstmt.setInt(3, _olcYear);
								_pstmt.setInt(4, _olcLcSl);
								Resultobj = Get_Value_From_Main("OLCAMD");
								if (Check_Result_Status()) {
									_amdSl = Integer.parseInt(Resultobj.getValue("MAX_AMDSL"));
									if (_amdSl > 1) {
										_amdSl = _amdSl - 1;
									}
									dtobj.clearMap();
									dtobj.setValue("BRANCH_CODE", String.valueOf(_branchCode));
									dtobj.setValue("LC_TYPE", _olctype);
									dtobj.setValue("LC_YEAR", String.valueOf(_olcYear));
									dtobj.setValue("LC_SERIAL", String.valueOf(_olcLcSl));
									dtobj.setValue("AMENDMENT_SERIAL", String.valueOf(_amdSl));
									dtobj.setValue(FetchReq, "true");
									dtobj.setValue("FetchColumns", "OLCA_ENTRY_DATE, OLCA_CUST_LETTER_NUM, OLCA_CUST_LTR_DATE,OLCA_BENEF_CODE, OLCA_BENEF_NAME, OLCA_BENEF_ADDR1, OLCA_BENEF_ADDR2, OLCA_BENEF_ADDR3, OLCA_BENEF_ADDR4, OLCA_BENEF_ADDR5, OLCA_BENEF_CNTRY_CODE, OLCA_AMENDED_AMT, OLCA_POS_DEV_ALLWD, OLCA_NEG_DEV_ALLWD, OLCA_DEV_AMT, OLCA_PRICE_TERMS, OLCA_LAST_DATE_OF_NEG, OLCA_PLACE_OF_EXPIRY, OLCA_LATEST_DATE_OF_SHPMNT, OLCA_WITHIN_VALIDATE_LC, OLCA_NOF_TENORS, OLCA_ADD_LIAB_LC_CURR, OLCA_ADD_LIAB_BASE_CURR, OLCA_CONV_RATE_LIM_CURR,OLCA_BRN_CODE, OLCA_AUTH_BY, OLCA_REJ_BY");
									Resultobj = olcval.valolcamd(dtobj);
									if (Check_Result_Status()) {
										if (_option.equalsIgnoreCase("M")) {
											if (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowNotPresent)) {
												Resultobj.setValue(ErrorKey, "Record Does Not Exist");
											}
										}
									}
								}
							}
						}
						if (Check_Result_Status()) {
							Resultobj.setValue(ErrorKey, "");
							Resultobj.setValue("AMD_SERIAL", String.valueOf(_amdSl));
							Resultobj.setValue("OLC_CORR_REF_NUM", _custRef);
							Resultobj.setValue("OLC_LC_DATE", _lcdate);
							Resultobj.setValue("OLC_CUST_NUM", _custNum);
							Resultobj.setValue("OLC_BENEF_CODE", _benefCode);
							Resultobj.setValue("OLC_BENEF_NAME", _benefName);
							Resultobj.setValue("OLC_BENEF_ADDR1", _addr1);
							Resultobj.setValue("OLC_BENEF_ADDR2", _addr2);
							Resultobj.setValue("OLC_BENEF_ADDR3", _addr3);
							Resultobj.setValue("OLC_BENEF_ADDR4", _addr4);
							Resultobj.setValue("OLC_BENEF_ADDR5", _addr5);
							Resultobj.setValue("OLC_BENEF_CNTRY_CODE", _countryCode);
							Resultobj.setValue("OLC_LC_ISS_BK_CODE", _lcissBank);
							Resultobj.setValue("OLC_LC_ISS_BRN_CODE", _lcissBranch);
							Resultobj.setValue("OLC_LC_ISS_PLACE", _lcissPlace);
							Resultobj.setValue("OLC_LC_ISS_CNTRY", _lcissCountry);
							Resultobj.setValue("OLC_LC_CURR_CODE", _lcCurr);
							Resultobj.setValue("OLC_LC_AMOUNT", _lcAmt);
							Resultobj.setValue("OLC_LC_BALANCE", _lcBal);
							Resultobj.setValue("OLC_NOF_TENORS", _drawDown);
							Resultobj.setValue("LCPS_CUST_LIAB_ACC_NUM", _liabAcc);
							Resultobj.setValue("LCPS_LIM_CURR", _limitCurr);
							Resultobj.setValue("LCPS_LIMIT_LINE_NUM", _limitline);
							Resultobj.setValue("OLC_TOT_LIAB_BASE_CURR", String.valueOf(_totalliabbasecurr));
							Resultobj.setValue("OLC_DEV_BAL", _olcDevBal);
							Resultobj.setValue("DEC_LEN", _declength1);
							Resultobj.setValue("OLC_POS_DEV_ALLWD", _positiveDeviAllowed);
							Resultobj.setValue("CLIENTS_NAME", custname);
							Resultobj.setValue("CLIENTS_ADDR1", custadd1);
							Resultobj.setValue("CLIENTS_ADDR2", custadd2);
							Resultobj.setValue("CLIENTS_ADDR3", custadd3);
							Resultobj.setValue("CLIENTS_ADDR4", custadd4);
							Resultobj.setValue("CLIENTS_ADDR5", custadd5);
							Resultobj.setValue("MBRN_NAME", branchname);
							Resultobj.setValue("BANKCD_NAME", bankname);
							Resultobj.setValue("CNTRY_NAME", countryname);
						}
					}
				}

			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in olcLcSlkeypress1");
		}
		return Resultobj.copyofDTO();
	}

	// ********************************************************************************************************* 
	//Changes P.Subramani-Chn-20/10/2008 Beg   
	//   *********************************************************************************************************
	/*Method Name     - 						olcLcCurrkeypress
	 * Input 	- 							    Key =OLC_LC_CURR
	 * 											
	 * Output	: Error Message  		- 		Key = ErrorMsg
	 * 											Key	= REM_DEC_LEN
	 * 											
	 * 											key=REM_CURR_NAME
	 * 
	 */

	public DTObject olcLcCurrkeypress(DTObject InputoBj) {
		try {
			String _olcLcCurr = "";
			String _declength = "";
			String _currencyName = "";
			{
				_olcLcCurr = InputoBj.getValue("OLC_LC_CURR").trim().toString();
			}
			Init_ResultObj(InputoBj);
			if (String.valueOf(_olcLcCurr).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}

			if (Check_Result_Status()) {
				comnval = new CommonValidator();
				dtobj.clearMap();
				dtobj.setValue("CURR_CODE", _olcLcCurr);
				Resultobj = comnval.valcurrcd(dtobj);
				_currencyName = Resultobj.getValue("CURR_NAME");

				if (Check_Result_Status()) {

					_declength = String.valueOf(cbsglobal.getcurrdeclength(_olcLcCurr));
				}

				Resultobj.setValue("REM_CURR_NAME", _currencyName);
				Resultobj.setValue("REM_DEC_LEN", _declength);
			}

		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in olcLcCurrkeypress");
		}

		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************

	// *********************************************************************************************************
	/*
	 * Input 	- 						Key= BRANCH_CODE
	 * 										 OLC_TYPE
	 * 										 OLC_YEAR
	 * 										 OLC_LC_SL
	 * Output	: Error Message  		- 	 ErrorMsg
	 * 			  		 				Key= OLC_MARGIN_AMT, 
	 * 										 OLC_MARGIN_BAL, 
	 * 										 OLC_CASH_MAR_BAL, 
	 * 										 OLC_CASH_MAR_AMT
	 */

	public DTObject olcmarginkeypress(DTObject InputoBj) {
		try {
			int _olcLcSl = 0;
			int _branchCode = 0;
			int _olcYear = 0;
			String _olctype = "";
			String olcmarginamt = "";
			String olcmarginbal = "";
			String olccashmarbal = "";
			String olccashmaramt = "";

			if (InputoBj.getValue("OLC_LC_SL").trim().equalsIgnoreCase("")) {
				_olcLcSl = 0;
			} else {
				_olcLcSl = Integer.parseInt(InputoBj.getValue("OLC_LC_SL").trim().toString());
				_branchCode = Integer.parseInt(InputoBj.getValue("BRANCH_CODE").trim().toString());
				_olcYear = Integer.parseInt(InputoBj.getValue("OLC_YEAR").trim().toString());
				_olctype = InputoBj.getValue("OLC_TYPE").trim().toString();
			}
			Init_ResultObj(InputoBj);
			if (!String.valueOf(_olcLcSl).trim().equalsIgnoreCase("")) {
				if (_olcLcSl == 0)
					if ((InputoBj.containsKey("OLC_LC_SL") == true) && (InputoBj.getValue("OLC_LC_SL").trim().equalsIgnoreCase("")))
						Resultobj.setValue(ErrorKey, BLANK_CHECK);
					else
						Resultobj.setValue(ErrorKey, ZERO_CHECK);
			}
			if (Check_Result_Status()) {
				dtobj.clearMap();
				dtobj.setValue("OLC_LC_TYPE", _olctype);
				dtobj.setValue("OLC_BRN_CODE", String.valueOf(_branchCode));
				dtobj.setValue("OLC_LC_YEAR", String.valueOf(_olcYear));
				dtobj.setValue("OLC_LC_SL", String.valueOf(_olcLcSl));
				dtobj.setValue(FetchReq, "true");
				dtobj.setValue("FetchColumns", "OLC_MARGIN_AMT, OLC_MARGIN_BAL, OLC_CASH_MAR_BAL, OLC_CASH_MAR_AMT");
				Resultobj = olcval.valolc(dtobj);
				if (Check_Result_Status()) {
					olcmarginamt = Resultobj.getValue("OLC_MARGIN_AMT");
					olcmarginbal = Resultobj.getValue("OLC_MARGIN_BAL");
					olccashmarbal = Resultobj.getValue("OLC_CASH_MAR_BAL");
					olccashmaramt = Resultobj.getValue("OLC_CASH_MAR_AMT");
				}
			}
			if (Check_Result_Status()) {
				Resultobj.setValue("OLC_MARGIN_AMT", olcmarginamt);
				Resultobj.setValue("OLC_MARGIN_BAL", olcmarginbal);
				Resultobj.setValue("OLC_CASH_MAR_BAL", olccashmarbal);
				Resultobj.setValue("OLC_CASH_MAR_AMT", olccashmaramt);
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in olcmarginkeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************

	//   *********************************************************************************************************
	/*
	 * Input 	- 						Key= OLCM_BRN_CODE
	 * 										 OLCM_LC_TYPE
	 * 										 OLCM_LC_YEAR
	 * 										 OLCM_LC_SL
	 * Output	: Error Message  		- 	 ErrorMsg
	 * 			  		 				Key= OLCM_MARGIN_CURR,
	 * 										 OLCM_MARGIN_PERC,
	 * 										 OLCM_EX_OVER_LIMIT_MARGIN_PERC,
	 * 										 OLCM_MARGIN_AMT,
	 * 										 OLCM_EX_OVER_LIMIT_MARGIN_AMT,
	 * 										 OLCM_CASH_MARGIN_AMT,
	 * 										 OLCM_EOL_CASH_MARGIN_AMT,
	 * 										 OLCM_MARGIN_TYPE
	 */

	public DTObject olcmarkeypress(DTObject InputoBj) {
		try {
			int _olcLcSl = 0;
			int _branchCode = 0;
			int _olcYear = 0;
			String _olctype = "";
			String option = "";
			String amdsl = "";
			String maxtxnsl = "";
			String margincurr = "";
			String marginper = "";
			String excmarginper = "";
			String marginamt = "";
			String excmarginamt = "";
			String cashmarginamt = "";
			String exccashmarginamt = "";
			String margintype = "";
			int lodsl = 1;
			String _pgmid = "";//Prabu K Changes 21-07-2010
			if (InputoBj.getValue("OLCM_LC_SL").trim().equalsIgnoreCase("")) {
				_olcLcSl = 0;
			} else {
				_olcLcSl = Integer.parseInt(InputoBj.getValue("OLCM_LC_SL").trim().toString());
				_branchCode = Integer.parseInt(InputoBj.getValue("OLCM_BRN_CODE").trim().toString());
				_olcYear = Integer.parseInt(InputoBj.getValue("OLCM_LC_YEAR").trim().toString());
				_olctype = InputoBj.getValue("OLCM_LC_TYPE").trim().toString();
				option = InputoBj.getValue("OPTION").trim().toString();
				amdsl = InputoBj.getValue("OLCM_AMD_SL").trim().toString();
				//Prabu K Changes 21-07-2010 Beg
				if (InputoBj.containsKey("PROGRAM_ID")) {
					_pgmid = InputoBj.getValue("PROGRAM_ID").toString();
				}
				//Prabu K Changes 21-07-2010 End
			}
			Init_ResultObj(InputoBj);
			if (!String.valueOf(_olcLcSl).trim().equalsIgnoreCase("")) {
				if (_olcLcSl == 0)
					if ((InputoBj.containsKey("OLCM_LC_SL") == true) && (InputoBj.getValue("OLCM_LC_SL").trim().equalsIgnoreCase("")))
						Resultobj.setValue(ErrorKey, BLANK_CHECK);
					else
						Resultobj.setValue(ErrorKey, ZERO_CHECK);
			}
			if (Check_Result_Status()) { //Changes P.Subramani-Chn-07/11/08 Beg
				if (option.equalsIgnoreCase("A")) {
					if (Integer.parseInt(amdsl) == 1) {
						_QueryStr = "SELECT OLCM_MARGIN_CURR,OLCM_MARGIN_PERC,OLCM_EX_OVER_LIMIT_MARGIN_PERC,OLCM_MARGIN_AMT,OLCM_EX_OVER_LIMIT_MARGIN_AMT,OLCM_CASH_MARGIN_AMT,OLCM_EOL_CASH_MARGIN_AMT,OLCM_MARGIN_TYPE FROM OLCMAR WHERE OLCM_BRN_CODE=? AND OLCM_LC_TYPE=? AND OLCM_LC_YEAR=? AND OLCM_LC_SL=? AND OLCM_TXN_TYPE=? AND OLCM_TXN_SL=? ";
						Set_preparedStatement(_QueryStr);
						_pstmt.setInt(1, _branchCode);
						_pstmt.setString(2, _olctype);
						_pstmt.setInt(3, _olcYear);
						_pstmt.setInt(4, _olcLcSl);
						_pstmt.setString(5, "L");
						_pstmt.setInt(6, lodsl);
						Resultobj = Get_Value_From_Main("OLCMAR");

						if (Check_Result_Status()) {
							margincurr = Resultobj.getValue("OLCM_MARGIN_CURR");
							marginper = Resultobj.getValue("OLCM_MARGIN_PERC");
							excmarginper = Resultobj.getValue("OLCM_EX_OVER_LIMIT_MARGIN_PERC");
							marginamt = Resultobj.getValue("OLCM_MARGIN_AMT");
							excmarginamt = Resultobj.getValue("OLCM_EX_OVER_LIMIT_MARGIN_AMT");
							cashmarginamt = Resultobj.getValue("OLCM_CASH_MARGIN_AMT");
							exccashmarginamt = Resultobj.getValue("OLCM_EOL_CASH_MARGIN_AMT");
							margintype = Resultobj.getValue("OLCM_MARGIN_TYPE");
						}
					}

					else if (Integer.parseInt(amdsl) > 1) {
						_QueryStr = "Select max(OLCM_TXN_SL)OLCM_TXN_SL from OLCMAR where OLCM_BRN_CODE=? AND OLCM_LC_TYPE=? AND OLCM_LC_YEAR=? AND OLCM_LC_SL=? AND OLCM_TXN_TYPE=? ";
						Set_preparedStatement(_QueryStr);
						_pstmt.setInt(1, _branchCode);
						_pstmt.setString(2, _olctype);
						_pstmt.setInt(3, _olcYear);
						_pstmt.setInt(4, _olcLcSl);
						_pstmt.setString(5, "A");
						Resultobj = Get_Value_From_Main("OLCMAR");

						if (Check_Result_Status()) {
							if (!_pgmid.equalsIgnoreCase("Q"))//Prabu K Changes 21-07-2010
							{
								maxtxnsl = Resultobj.getValue("OLCM_TXN_SL");
							}

						}

						if (Check_Result_Status()) {
							_QueryStr = "SELECT OLCM_MARGIN_CURR,OLCM_MARGIN_PERC,OLCM_EX_OVER_LIMIT_MARGIN_PERC,OLCM_MARGIN_AMT,OLCM_EX_OVER_LIMIT_MARGIN_AMT,OLCM_CASH_MARGIN_AMT,OLCM_EOL_CASH_MARGIN_AMT,OLCM_MARGIN_TYPE FROM OLCMAR WHERE OLCM_BRN_CODE=? AND OLCM_LC_TYPE=? AND OLCM_LC_YEAR=? AND OLCM_LC_SL=? AND OLCM_TXN_TYPE=? AND OLCM_TXN_SL=? ";
							Set_preparedStatement(_QueryStr);
							_pstmt.setInt(1, _branchCode);
							_pstmt.setString(2, _olctype);
							_pstmt.setInt(3, _olcYear);
							_pstmt.setInt(4, _olcLcSl);
							_pstmt.setString(5, "A");
							if (!_pgmid.equalsIgnoreCase("Q")) //Prabu K Changes 21-07-2010
							{
								_pstmt.setInt(6, Integer.parseInt(maxtxnsl));
							} else
								_pstmt.setInt(6, Integer.parseInt(amdsl)); // Prabu K Changes 21-07-2010
							Resultobj = Get_Value_From_Main("OLCMAR");

							if (Check_Result_Status()) {
								margincurr = Resultobj.getValue("OLCM_MARGIN_CURR");
								marginper = Resultobj.getValue("OLCM_MARGIN_PERC");
								excmarginper = Resultobj.getValue("OLCM_EX_OVER_LIMIT_MARGIN_PERC");
								marginamt = Resultobj.getValue("OLCM_MARGIN_AMT");
								excmarginamt = Resultobj.getValue("OLCM_EX_OVER_LIMIT_MARGIN_AMT");
								cashmarginamt = Resultobj.getValue("OLCM_CASH_MARGIN_AMT");
								exccashmarginamt = Resultobj.getValue("OLCM_EOL_CASH_MARGIN_AMT");
								margintype = Resultobj.getValue("OLCM_MARGIN_TYPE");
							}
						}
					}

				} else if (option.equalsIgnoreCase("M")) {
					if (Check_Result_Status()) {
						_QueryStr = "Select max(OLCM_TXN_SL)OLCM_TXN_SL from OLCMAR where OLCM_BRN_CODE=? AND OLCM_LC_TYPE=? AND OLCM_LC_YEAR=? AND OLCM_LC_SL=? AND OLCM_TXN_TYPE=? ";
						Set_preparedStatement(_QueryStr);
						_pstmt.setInt(1, _branchCode);
						_pstmt.setString(2, _olctype);
						_pstmt.setInt(3, _olcYear);
						_pstmt.setInt(4, _olcLcSl);
						_pstmt.setString(5, "A");
						Resultobj = Get_Value_From_Main("OLCMAR");
					}
					if (Check_Result_Status()) {
						if (!_pgmid.equalsIgnoreCase("Q")) //Prabu K Changes 21-07-2010
						{
							maxtxnsl = Resultobj.getValue("OLCM_TXN_SL");

						}
					}
					if (Check_Result_Status()) {
						_QueryStr = "SELECT OLCM_MARGIN_CURR,OLCM_MARGIN_PERC,OLCM_EX_OVER_LIMIT_MARGIN_PERC,OLCM_MARGIN_AMT,OLCM_EX_OVER_LIMIT_MARGIN_AMT,OLCM_CASH_MARGIN_AMT,OLCM_EOL_CASH_MARGIN_AMT,OLCM_MARGIN_TYPE FROM OLCMAR WHERE OLCM_BRN_CODE=? AND OLCM_LC_TYPE=? AND OLCM_LC_YEAR=? AND OLCM_LC_SL=? AND OLCM_TXN_TYPE=? AND OLCM_TXN_SL=? ";
						Set_preparedStatement(_QueryStr);
						_pstmt.setInt(1, _branchCode);
						_pstmt.setString(2, _olctype);
						_pstmt.setInt(3, _olcYear);
						_pstmt.setInt(4, _olcLcSl);
						_pstmt.setString(5, "A");
						if (!_pgmid.equalsIgnoreCase("Q")) //Prabu K Changes 21-07-2010
						{
							_pstmt.setInt(6, Integer.parseInt(maxtxnsl));
						} else
							_pstmt.setInt(6, Integer.parseInt(amdsl)); //Prabu K Changes 21-07-2010 
						Resultobj = Get_Value_From_Main("OLCMAR");
					}
					if (Check_Result_Status()) {
						margincurr = Resultobj.getValue("OLCM_MARGIN_CURR");
						marginper = Resultobj.getValue("OLCM_MARGIN_PERC");
						excmarginper = Resultobj.getValue("OLCM_EX_OVER_LIMIT_MARGIN_PERC");
						marginamt = Resultobj.getValue("OLCM_MARGIN_AMT");
						excmarginamt = Resultobj.getValue("OLCM_EX_OVER_LIMIT_MARGIN_AMT");
						cashmarginamt = Resultobj.getValue("OLCM_CASH_MARGIN_AMT");
						exccashmarginamt = Resultobj.getValue("OLCM_EOL_CASH_MARGIN_AMT");
						margintype = Resultobj.getValue("OLCM_MARGIN_TYPE");
					}
				}
			}//Changes P.Subramani-Chn-07/11/08 End
			if (Check_Result_Status()) {
				Resultobj.setValue("OLCM_MARGIN_CURR", margincurr);
				Resultobj.setValue("OLCM_MARGIN_PERC", marginper);
				Resultobj.setValue("OLCM_EX_OVER_LIMIT_MARGIN_PERC", excmarginper);
				Resultobj.setValue("OLCM_MARGIN_AMT", marginamt);
				Resultobj.setValue("OLCM_EX_OVER_LIMIT_MARGIN_AMT", excmarginamt);
				Resultobj.setValue("OLCM_CASH_MARGIN_AMT", cashmarginamt);
				Resultobj.setValue("OLCM_EOL_CASH_MARGIN_AMT", exccashmarginamt);
				Resultobj.setValue("OLCM_MARGIN_TYPE", margintype);
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in olcmarginkeypress");
		}
		return Resultobj.copyofDTO();
	}

	// *********************************************************************************************************

	//Changes P.Subramani-Chn-21/10/2008 End

	//Prabu K Changes 21-07-2010 Beg
	/*
	 * Input 	- 						Key =    OLC_LC_SL
	 * 										 BRANCH_CODE
	 * 										 OLC_TYPE
	 * 										 OLC_YEAR
	 * 										 OLCA_AMD_SL
	 * 										 OPTION	
	 * Output	: Error Message  		- 		Key = ErrorMsg
	 * 											
	 */

	public DTObject olcAmendSlkeypress1(DTObject InputoBj) {
		try {

			int _olcLcSl = 0;
			int _branchCode = 0;
			int _olcYear = 0;
			String _olctype = "";
			String _option = "";
			String _max_SL = "";
			int _amdSl = 0;
			String _custRef = "";
			String _benefCode = "";
			String _benefName = "";
			String _addr1 = "";
			String _addr2 = "";
			String _addr3 = "";
			String _addr4 = "";
			String _addr5 = "";
			String _lcdate = "";
			String _lcissBank = "";
			String _lcissBranch = "";
			String _lcissPlace = "";
			String _lcissCountry = "";
			String _lcAmt = "";
			String _lcBal = "";
			String _lcCurr = "";
			String _custNum = "";
			String _countryCode = "";
			int _lcpsl = 0;
			String _lcpsdate = "";
			String _liabAcc = "";
			String _limitCurr = "";
			String _limitline = "";
			double _totalliabbasecurr = 0;
			String _drawDown = null;
			String _olcDevBal = "";
			String _declength1 = "";
			String _positiveDeviAllowed = "";
			String custname = "";
			String bankname = "";
			String branchname = "";
			String countryname = "";
			String custadd1 = "";
			String custadd2 = "";
			String custadd3 = "";
			String custadd4 = "";
			String custadd5 = "";

			String _pgmid = "";
			if (InputoBj.getValue("OLCA_AMD_SL").trim().equalsIgnoreCase("")) {
				_amdSl = 0;
			} else {
				_amdSl = Integer.parseInt(InputoBj.getValue("OLCA_AMD_SL").trim().toString());
				_olcLcSl = Integer.parseInt(InputoBj.getValue("OLC_LC_SL").trim().toString());
				_branchCode = Integer.parseInt(InputoBj.getValue("BRANCH_CODE").trim().toString());
				_olcYear = Integer.parseInt(InputoBj.getValue("OLC_YEAR").trim().toString());
				_olctype = InputoBj.getValue("OLC_TYPE").trim().toString();
				_option = InputoBj.getValue("OPTION").trim().toString();
				if (InputoBj.containsKey("PROGRAM_ID")) {
					_pgmid = InputoBj.getValue("PROGRAM_ID").toString();
				}

			}
			Init_ResultObj(InputoBj);
			if (!String.valueOf(_olcLcSl).trim().equalsIgnoreCase("")) {
				if (_olcLcSl == 0)
					if ((InputoBj.containsKey("OLCA_AMD_SL") == true) && (InputoBj.getValue("OLCA_AMD_SL").trim().equalsIgnoreCase("")))
						Resultobj.setValue(ErrorKey, BLANK_CHECK);
					else
						Resultobj.setValue(ErrorKey, ZERO_CHECK);
			}
			if (Check_Result_Status()) {
				dtobj.clearMap();
				dtobj.setValue("OLC_LC_TYPE", _olctype);
				dtobj.setValue("OLC_BRN_CODE", String.valueOf(_branchCode));
				dtobj.setValue("OLC_LC_YEAR", String.valueOf(_olcYear));
				dtobj.setValue("OLC_LC_SL", String.valueOf(_olcLcSl));
				dtobj.setValue(FetchReq, "true");
				dtobj
						.setValue(
								"FetchColumns",
								"OLC_POS_DEV_ALLWD,OLC_DEV_BAL,OLC_LC_PRESANC_DATE, OLC_LC_PRESANC_DAY_SL,OLC_CORR_REF_NUM, OLC_LC_DATE, OLC_CUST_NUM, OLC_BENEF_CODE, OLC_BENEF_NAME, OLC_BENEF_ADDR1, OLC_BENEF_ADDR2, OLC_BENEF_ADDR3, OLC_BENEF_ADDR4, OLC_BENEF_ADDR5, OLC_BENEF_CNTRY_CODE, OLC_LC_ISS_BK_CODE, OLC_LC_ISS_BRN_CODE, OLC_LC_ISS_PLACE, OLC_LC_ISS_CNTRY, OLC_LC_ADV_THRU, OLC_LC_CURR_CODE, OLC_LC_AMOUNT, OLC_LC_BALANCE, OLC_DEV_ALLWD, OLC_POS_DEV_ALLWD, OLC_NEG_DEV_ALLWD, OLC_DEV_AMOUNT, OLC_AMT_QUALFR, OLC_PRICE_TERMS, OLC_LAST_DATE_OF_NEG, OLC_PLACE_OF_EXPIRY, OLC_LATEST_DATE_OF_SHPMNT, OLC_WITHIN_VALIDATE_LC, OLC_LC_UI_BORNE_BY_APPLCNT, OLC_NOF_TENORS, OLC_TOT_LIAB_LC_CURR, OLC_CONV_RATE_BASE_CURR, OLC_TOT_LIAB_BASE_CURR, OLC_CONV_RATE_LIM_CURR, OLC_TOT_LIAB_LIM_CURR,OLC_AUTH_BY,OLC_REJ_BY");
				Resultobj = olcval.valolc(dtobj);
				if (Check_Result_Status() == true) {
					if (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowNotPresent)) {
						Resultobj.setValue(ErrorKey, "No Documentation For This LC");
					} else {
						_custRef = Resultobj.getValue("OLC_CORR_REF_NUM");
						_addr1 = Resultobj.getValue("OLC_BENEF_ADDR1");
						_addr2 = Resultobj.getValue("OLC_BENEF_ADDR2");
						_addr3 = Resultobj.getValue("OLC_BENEF_ADDR3");
						_addr4 = Resultobj.getValue("OLC_BENEF_ADDR4");
						_addr5 = Resultobj.getValue("OLC_BENEF_ADDR5");
						_benefCode = Resultobj.getValue("OLC_BENEF_CODE");
						_benefName = Resultobj.getValue("OLC_BENEF_NAME");
						_lcAmt = Resultobj.getValue("OLC_LC_AMOUNT");
						_lcBal = Resultobj.getValue("OLC_LC_BALANCE");
						_lcCurr = Resultobj.getValue("OLC_LC_CURR_CODE");
						_lcdate = Resultobj.getValue("OLC_LC_DATE");
						_lcissBank = Resultobj.getValue("OLC_LC_ISS_BK_CODE");
						_lcissBranch = Resultobj.getValue("OLC_LC_ISS_BRN_CODE");
						_lcissCountry = Resultobj.getValue("OLC_LC_ISS_CNTRY");
						_lcissPlace = Resultobj.getValue("OLC_LC_ISS_PLACE");
						_custNum = Resultobj.getValue("OLC_CUST_NUM");
						custnoHidden = _custNum;
						_positiveDeviAllowed = Resultobj.getValue("OLC_POS_DEV_ALLWD");
						_olcDevBal = Resultobj.getValue("OLC_DEV_BAL");
						_countryCode = Resultobj.getValue("OLC_BENEF_CNTRY_CODE");
						_lcpsdate = Resultobj.getValue("OLC_LC_PRESANC_DATE");
						_drawDown = Resultobj.getValue("OLC_NOF_TENORS");
						_lcpsl = Integer.parseInt(Resultobj.getValue("OLC_LC_PRESANC_DAY_SL"));
						_totalliabbasecurr = Double.parseDouble(Resultobj.getValue("OLC_TOT_LIAB_BASE_CURR"));
						if (_custNum != null) {
							if (!_custNum.equalsIgnoreCase("")) {
								ClientValidator clieval = new ClientValidator();
								dtobj.clearMap();
								dtobj.setValue("CLIENTS_CODE", _custNum);
								dtobj.setValue(FetchReq, "true");
								Resultobj = clieval.clientValid(dtobj);
								custname = Resultobj.getValue("CLIENTS_NAME");
								custadd1 = Resultobj.getValue("CLIENTS_ADDR1");
								custadd2 = Resultobj.getValue("CLIENTS_ADDR2");
								custadd3 = Resultobj.getValue("CLIENTS_ADDR3");
								custadd4 = Resultobj.getValue("CLIENTS_ADDR4");
								custadd5 = Resultobj.getValue("CLIENTS_ADDR5");
							}
						}

						if (_lcissBranch != null) {
							if (!_lcissBranch.equalsIgnoreCase("")) {
								BranchValidator BV = new BranchValidator();
								dtobj.clearMap();
								dtobj.setValue("MBRN_CODE", _lcissBranch);
								Resultobj = BV.chkBrnValid(dtobj);
								branchname = Resultobj.getValue("MBRN_NAME");
							}
						}

						if (_lcissBank != null) {
							if (!_lcissBank.equalsIgnoreCase("")) {
								CommonValidator CV = new CommonValidator();
								dtobj.clearMap();
								dtobj.setValue("BANKCD_CODE", _lcissBank);
								Resultobj = CV.valbankcd(dtobj);
								bankname = Resultobj.getValue("BANKCD_NAME");
							}
						}

						if (_lcissCountry != null) {
							if (!_lcissCountry.equalsIgnoreCase("")) {
								CommonValidator CV = new CommonValidator();
								dtobj.clearMap();
								dtobj.setValue("CNTRY_CODE", _lcissCountry);
								Resultobj = CV.valcntrycd(dtobj);
								countryname = Resultobj.getValue("CNTRY_NAME");
							}
						}
						if (Check_Result_Status()) {
							_QueryStr = "select LCPS_BRN_CODE, facno(LCPS_CUST_LIAB_ACC_NUM)LCPS_CUST_LIAB_ACC_NUM, LCPS_LIMIT_LINE_NUM, LCPS_LIM_CURR from lcps where LCPS_BRN_CODE = ? and LCPS_ENTRY_DATE = ? and LCPS_DAY_SL = ?";
							Set_preparedStatement(_QueryStr);
							_pstmt.setInt(1, _branchCode);
							_pstmt.setTimestamp(2, DateToYYYYMMDD(_lcpsdate));
							_pstmt.setInt(3, _lcpsl);
							Resultobj = Get_Value_From_Main("LCPS");
						}
						if (Check_Result_Status()) {
							_declength1 = String.valueOf(cbsglobal.getcurrdeclength(_lcCurr));
						}
						if (Check_Result_Status()) {
							_liabAcc = Resultobj.getValue("LCPS_CUST_LIAB_ACC_NUM");
							_limitCurr = Resultobj.getValue("LCPS_LIM_CURR");
							_limitline = Resultobj.getValue("LCPS_LIMIT_LINE_NUM");
							_limitlineHidden = _limitline;
							if (Check_Result_Status()) {
								_QueryStr = "Select nvl(max(OLCA_AMD_SL),0) + 1 as max_Amdsl from OLCAMD where OLCA_BRN_CODE = ? and OLCA_LC_TYPE = ? and OLCA_LC_YEAR = ? and OLCA_LC_SL=?";
								Set_preparedStatement(_QueryStr);
								_pstmt.setInt(1, _branchCode);
								_pstmt.setString(2, _olctype);
								_pstmt.setInt(3, _olcYear);
								_pstmt.setInt(4, _olcLcSl);
								Resultobj = Get_Value_From_Main("OLCAMD");
								if (Check_Result_Status()) {
									if (!_pgmid.equalsIgnoreCase("Q")) {
										_amdSl = Integer.parseInt(Resultobj.getValue("MAX_AMDSL"));
										if (_amdSl > 1) {
											_amdSl = _amdSl - 1;
										}
									}
									dtobj.clearMap();
									dtobj.setValue("BRANCH_CODE", String.valueOf(_branchCode));
									dtobj.setValue("LC_TYPE", _olctype);
									dtobj.setValue("LC_YEAR", String.valueOf(_olcYear));
									dtobj.setValue("LC_SERIAL", String.valueOf(_olcLcSl));
									dtobj.setValue("AMENDMENT_SERIAL", String.valueOf(_amdSl));
									dtobj.setValue(FetchReq, "true");
									dtobj.setValue("FetchColumns", "OLCA_ENTRY_DATE, OLCA_CUST_LETTER_NUM, OLCA_CUST_LTR_DATE,OLCA_BENEF_CODE, OLCA_BENEF_NAME, OLCA_BENEF_ADDR1, OLCA_BENEF_ADDR2, OLCA_BENEF_ADDR3, OLCA_BENEF_ADDR4, OLCA_BENEF_ADDR5, OLCA_BENEF_CNTRY_CODE, OLCA_AMENDED_AMT, OLCA_POS_DEV_ALLWD, OLCA_NEG_DEV_ALLWD, OLCA_DEV_AMT, OLCA_PRICE_TERMS, OLCA_LAST_DATE_OF_NEG, OLCA_PLACE_OF_EXPIRY, OLCA_LATEST_DATE_OF_SHPMNT, OLCA_WITHIN_VALIDATE_LC, OLCA_NOF_TENORS, OLCA_ADD_LIAB_LC_CURR, OLCA_ADD_LIAB_BASE_CURR, OLCA_CONV_RATE_LIM_CURR,OLCA_BRN_CODE, OLCA_AUTH_BY, OLCA_REJ_BY");
									Resultobj = olcval.valolcamd(dtobj);
									if (Check_Result_Status()) {
										if (_option.equalsIgnoreCase("M")) {
											if (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowNotPresent)) {
												Resultobj.setValue(ErrorKey, "Record Does Not Exist");
											}
										}
									}
								}
							}
						}
						if (Check_Result_Status()) {
							Resultobj.setValue(ErrorKey, "");
							Resultobj.setValue("AMD_SERIAL", String.valueOf(_amdSl));
							Resultobj.setValue("OLC_CORR_REF_NUM", _custRef);
							Resultobj.setValue("OLC_LC_DATE", _lcdate);
							Resultobj.setValue("OLC_CUST_NUM", _custNum);
							Resultobj.setValue("OLC_BENEF_CODE", _benefCode);
							Resultobj.setValue("OLC_BENEF_NAME", _benefName);
							Resultobj.setValue("OLC_BENEF_ADDR1", _addr1);
							Resultobj.setValue("OLC_BENEF_ADDR2", _addr2);
							Resultobj.setValue("OLC_BENEF_ADDR3", _addr3);
							Resultobj.setValue("OLC_BENEF_ADDR4", _addr4);
							Resultobj.setValue("OLC_BENEF_ADDR5", _addr5);
							Resultobj.setValue("OLC_BENEF_CNTRY_CODE", _countryCode);
							Resultobj.setValue("OLC_LC_ISS_BK_CODE", _lcissBank);
							Resultobj.setValue("OLC_LC_ISS_BRN_CODE", _lcissBranch);
							Resultobj.setValue("OLC_LC_ISS_PLACE", _lcissPlace);
							Resultobj.setValue("OLC_LC_ISS_CNTRY", _lcissCountry);
							Resultobj.setValue("OLC_LC_CURR_CODE", _lcCurr);
							Resultobj.setValue("OLC_LC_AMOUNT", _lcAmt);
							Resultobj.setValue("OLC_LC_BALANCE", _lcBal);
							Resultobj.setValue("OLC_NOF_TENORS", _drawDown);
							Resultobj.setValue("LCPS_CUST_LIAB_ACC_NUM", _liabAcc);
							Resultobj.setValue("LCPS_LIM_CURR", _limitCurr);
							Resultobj.setValue("LCPS_LIMIT_LINE_NUM", _limitline);
							Resultobj.setValue("OLC_TOT_LIAB_BASE_CURR", String.valueOf(_totalliabbasecurr));
							Resultobj.setValue("OLC_DEV_BAL", _olcDevBal);
							Resultobj.setValue("DEC_LEN", _declength1);
							Resultobj.setValue("OLC_POS_DEV_ALLWD", _positiveDeviAllowed);
							Resultobj.setValue("CLIENTS_NAME", custname);
							Resultobj.setValue("CLIENTS_ADDR1", custadd1);
							Resultobj.setValue("CLIENTS_ADDR2", custadd2);
							Resultobj.setValue("CLIENTS_ADDR3", custadd3);
							Resultobj.setValue("CLIENTS_ADDR4", custadd4);
							Resultobj.setValue("CLIENTS_ADDR5", custadd5);
							Resultobj.setValue("MBRN_NAME", branchname);
							Resultobj.setValue("BANKCD_NAME", bankname);
							Resultobj.setValue("CNTRY_NAME", countryname);
						}
					}
				}

			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in olcBrnCodekeypress");
		}
		return Resultobj.copyofDTO();
	}

	//M.Jayakumaran Changes on 1-Jun-2011 Beg For Rounding Off Value

	public DTObject roundofkeypress(DTObject Resultobj) {
		try {
			String _BCurrCode = Resultobj.getValue("baseCurr");
			if (Check_Result_Status()) {
				if (_BCurrCode.equalsIgnoreCase(get_base_curr_code())) {
					String _trandate = Resultobj.getValue("CBD").trim().toString();
					String _type = Resultobj.getValue("TYPE").trim().toString();
					String _amtbasecurr = "";
					String AgainstAmt = Resultobj.getValue("TOTAL_AMT");
					if (Check_Result_Status()) {
						CallableStatement _cstmt = null;
						openConnection();
						_cstmt = connDB.prepareCall("CALL PKG_FX_RND_PARAM.SP_FX_ROUNDOFF(TO_DATE(?,'DD-MM-YYYY'),?,?,?)");
						_cstmt.setString(1, _trandate);
						_cstmt.setString(2, AgainstAmt);
						_cstmt.setString(3, _type);
						_cstmt.registerOutParameter(4, Types.INTEGER);
						_cstmt.execute();
						_amtbasecurr = _cstmt.getString(4);
						closeConnection();
						Resultobj.setValue("ROUNDOFF_AMT", _amtbasecurr);
					}
				}
			}

		}

		catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in intratekeypress");
		}
		return Resultobj.copyofDTO();
	}

	//M.Jayakumaran Changes on 19-Jan-2011 End For Rounding Off Value  
	//Prabu K Changes 21-07-2010 end

	//Changes in EOLCAMD for Swift on 16-Oct-2018 start
	//****************************************************************************************** 
	public DTObject Reciever_ReferenceKeyPress(DTObject InputoBj) {
		try {
			Resultobj.clearMap();
			//ADDED BY PRASHANTH ON 06 FEB 2019
			String Bic_Code = "";
			Bic_Code = InputoBj.getValue("LC_REC_BIC_CODE").trim().toString();
			if (Bic_Code.trim().equals("")) {
				Resultobj.setValue(ErrorKey, "Cannot be Blank");
			} else {
				Resultobj.setValue(ErrorKey, "");
			}
			//ADDED BY PRASHANTH ON 06 FEB 2019
			//	Resultobj=swval.RecieverBICCode(InputoBj);//COMMENTTED BY PRASHANTH ON 06 FEB 2019
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in Reciever_ReferenceKeyPress");
		}
		return Resultobj.copyofDTO();
	}

	//****************************************************************************************** 
	public DTObject Doc_Credit_NumberKeyPress(DTObject InputoBj) {
		try {
			Resultobj.clearMap();
			Resultobj = swval.DocumentaryCreditNumber(InputoBj);
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in Doc_Credit_NumberKeyPress");
		}
		return Resultobj.copyofDTO();
	}

	//****************************************************************************************** 
	public DTObject IssuingBankTypeKeyPress(DTObject InputoBj) {
		try {
			Resultobj.clearMap();
			Resultobj = swval.ApplicantBankType(InputoBj);
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in IssuingBankTypeKeyPress");
		}
		return Resultobj.copyofDTO();
	}

	//****************************************************************************************** 
	public DTObject IssuingBankNameKeypress(DTObject InputoBj) {
		try {
			Resultobj.clearMap();
			Resultobj = swval.ApplicantBankName(InputoBj);
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in IssuingBankNameKeypress");
		}
		return Resultobj.copyofDTO();
	}

	//****************************************************************************************** 
	public DTObject IssuingBankBicKeypress(DTObject InputoBj) {
		try {
			Resultobj.clearMap();
			Resultobj = swval.ApplicantBankBic(InputoBj);
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in IssuingBankBicKeypress");
		}
		return Resultobj.copyofDTO();
	}

	//****************************************************************************************** 
	public DTObject IssuingBankBranchCodeKeypress(DTObject InputoBj) {
		try {
			Resultobj.clearMap();
			Resultobj = swval.ApplicantBankBranch(InputoBj);
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in IssuingBankBranchCodeKeypress");
		}
		return Resultobj.copyofDTO();
	}

	//****************************************************************************************** 
	public DTObject IssuingBankAddressKeypress(DTObject InputoBj) {
		try {
			Resultobj.clearMap();
			Resultobj = swval.ApplicantBankAddress(InputoBj);
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in IssuingBankAddressKeypress");
		}
		return Resultobj.copyofDTO();
	}

	//****************************************************************************************** 
	public DTObject IssuingBankCntryCodeKeypress(DTObject InputoBj) {
		try {
			Resultobj.clearMap();
			Resultobj = swval.ApplicantBankCountryCode(InputoBj);
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in IssuingBankCntryCodeKeypress");
		}
		return Resultobj.copyofDTO();
	}

	//******************************************************************************************
	public DTObject IssuingBankAccountNumberKeypress(DTObject InputoBj) {
		try {
			Resultobj.clearMap();
			Resultobj = swval.ApplicantAccountNumber(InputoBj);
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in IssuingBankAccountNumberKeypress");
		}
		return Resultobj.copyofDTO();
	}

	//****************************************************************************************** 
	public DTObject Date_Of_Issue_KeyPress(DTObject InputoBj) {
		try {
			Resultobj.clearMap();
			Resultobj = swval.Date_Of_Issue(InputoBj);
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in Date_Of_Issue_KeyPress");
		}
		return Resultobj.copyofDTO();
	}

	//****************************************************************************************** 
	public DTObject Shipment_Period_KeyPress(DTObject InputoBj) {
		try {
			Resultobj.clearMap();
			Resultobj = swval.Shipment_Period(InputoBj);
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in Shipment_Period_KeyPress");
		}
		return Resultobj.copyofDTO();
	}

	//****************************************************************************************** 
	public DTObject Place_Of_Charge_KeyPress(DTObject InputoBj) {
		try {
			Resultobj.clearMap();
			Resultobj = swval.Place_Of_Charge(InputoBj);
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in Place_Of_Charge_KeyPress");
		}
		return Resultobj.copyofDTO();
	}

	//****************************************************************************************** 
	public DTObject Beneficiary_Name_KeyPress(DTObject InputoBj) {
		try {
			Resultobj.clearMap();
			Resultobj = swval.Amendment_Beneficiary_Name(InputoBj);
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in Beneficiary_Name_KeyPress");
		}
		return Resultobj.copyofDTO();
	}

	//****************************************************************************************** 
	public DTObject Beneficiary_Address_KeyPress(DTObject InputoBj) {
		try {
			Resultobj.clearMap();
			Resultobj = swval.Amendment_Beneficiary_Address(InputoBj);
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in Beneficiary_Address_KeyPress");
		}
		return Resultobj.copyofDTO();
	}

	//****************************************************************************************** 
	public DTObject Max_Credit_Amount_KeyPress(DTObject InputoBj) {
		try {
			Resultobj.clearMap();
			Resultobj = swval.Amendment_Max_Credit_amount(InputoBj);
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in Max_Credit_Amount_KeyPress");
		}
		return Resultobj.copyofDTO();
	}

	//****************************************************************************************** 
	public DTObject Amend_Narrative_KeyPress(DTObject InputoBj) {
		try {
			Resultobj.clearMap();
			Resultobj = swval.Amendment_Narrative(InputoBj);
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in Amend_Narrative_KeyPress");
		}
		return Resultobj.copyofDTO();
	}

	//Changes in EOLCAMD for Swift on 16-Oct-2018 end 

	//ADDED BY PRASHANTH ON 07 FEB 2019
	public DTObject getOLCGoodsDescn(DTObject InputoBj) {
		try {
			int _olcBrnCode = 0;
			if (InputoBj.getValue("OLC_BRN_CODE").trim().equalsIgnoreCase("")) {
				_olcBrnCode = 0;
			} else {
				_olcBrnCode = Integer.parseInt(InputoBj.getValue("OLC_BRN_CODE").trim().toString());
			}
			String olcType = "";
			olcType = InputoBj.getValue("OLC_TYPE").trim().toString();
			int _olcYear = 0;
			if (InputoBj.getValue("OLC_YEAR").trim().equalsIgnoreCase("")) {
				_olcYear = 0;
			} else {
				_olcYear = Integer.parseInt(InputoBj.getValue("OLC_YEAR").trim().toString());
			}
			int _olcsl = 0;
			if (InputoBj.getValue("OLC_SL").trim().equalsIgnoreCase("")) {
				_olcsl = 0;
			} else {
				_olcsl = Integer.parseInt(InputoBj.getValue("OLC_SL").trim().toString());
			}

			Init_ResultObj(InputoBj);
			if (String.valueOf(_olcBrnCode).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (Check_Result_Status()) {
				if (!String.valueOf(_olcBrnCode).trim().equalsIgnoreCase("")) {
					if (_olcBrnCode == 0)
						if (InputoBj.containsKey("OLC_BRN_CODE") == true && InputoBj.getValue("OLC_BRN_CODE").equalsIgnoreCase(""))
							Resultobj.setValue(ErrorKey, BLANK_CHECK);
						else
							Resultobj.setValue(ErrorKey, ZERO_CHECK);
				}
			}

			Init_ResultObj(InputoBj);
			if (String.valueOf(_olcYear).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (Check_Result_Status()) {
				if (!String.valueOf(_olcYear).trim().equalsIgnoreCase("")) {
					if (_olcYear == 0)
						if (InputoBj.containsKey("OLC_YEAR") == true && InputoBj.getValue("OLC_YEAR").equalsIgnoreCase(""))
							Resultobj.setValue(ErrorKey, BLANK_CHECK);
						else
							Resultobj.setValue(ErrorKey, ZERO_CHECK);
				}
			}

			Init_ResultObj(InputoBj);
			if (String.valueOf(_olcsl).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (Check_Result_Status()) {
				if (!String.valueOf(_olcsl).trim().equalsIgnoreCase("")) {
					if (_olcsl == 0)
						if (InputoBj.containsKey("OLC_SL") == true && InputoBj.getValue("OLC_SL").equalsIgnoreCase(""))
							Resultobj.setValue(ErrorKey, BLANK_CHECK);
						else
							Resultobj.setValue(ErrorKey, ZERO_CHECK);
				}
			}

			if (Check_Result_Status()) {
				_QueryStr = "SELECT TO_CLOB(LC_DESC_GOODS_SER1)LC_DESC_GOODS_SER1,TO_CLOB(LC_DESC_GOODS_SER2)LC_DESC_GOODS_SER2,TO_CLOB(LC_DESC_GOODS_SER3)LC_DESC_GOODS_SER3 FROM LC_DETAILS WHERE LC_BRN_CODE = ? AND LC_LC_TYPE =? AND LC_LC_YEAR=? AND LC_LC_SL=?";
				Set_preparedStatement(_QueryStr);
				_pstmt.setInt(1, _olcBrnCode);
				_pstmt.setString(2, olcType);
				_pstmt.setInt(3, _olcYear);
				_pstmt.setInt(4, _olcsl);
				ResultSet rs1 = ExecuteQuery();
				if (rs1.next()) {
					dto_good1.clearMap();
					dto_good1 = FetchClobData(_olcBrnCode, olcType, _olcYear, _olcsl, rs1.getClob("LC_DESC_GOODS_SER1"), "LC_DESC_GOODS_SER1");
					Resultobj.setValue("LC_DESC_GOODS_SER1", dto_good1.getValue("LC_DESC_GOODS_SER1"));

					dto_good1.clearMap();
					dto_good1 = FetchClobData(_olcBrnCode, olcType, _olcYear, _olcsl, rs1.getClob("LC_DESC_GOODS_SER2"), "LC_DESC_GOODS_SER2");
					Resultobj.setValue("LC_DESC_GOODS_SER2", dto_good1.getValue("LC_DESC_GOODS_SER2"));

					dto_good1.clearMap();
					dto_good1 = FetchClobData(_olcBrnCode, olcType, _olcYear, _olcsl, rs1.getClob("LC_DESC_GOODS_SER3"), "LC_DESC_GOODS_SER3");
					Resultobj.setValue("LC_DESC_GOODS_SER3", dto_good1.getValue("LC_DESC_GOODS_SER3"));
				}
			}

		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in getOLCGoodsDescn");
		}
		return Resultobj.copyofDTO();
	}

	public DTObject getOLCDocsDescn(DTObject InputoBj) {
		try {

			int _olcBrnCode = 0;
			if (InputoBj.getValue("OLC_BRN_CODE").trim().equalsIgnoreCase("")) {
				_olcBrnCode = 0;
			} else {
				_olcBrnCode = Integer.parseInt(InputoBj.getValue("OLC_BRN_CODE").trim().toString());
			}
			String olcType = "";
			olcType = InputoBj.getValue("OLC_TYPE").trim().toString();
			int _olcYear = 0;
			if (InputoBj.getValue("OLC_YEAR").trim().equalsIgnoreCase("")) {
				_olcYear = 0;
			} else {
				_olcYear = Integer.parseInt(InputoBj.getValue("OLC_YEAR").trim().toString());
			}
			int _olcsl = 0;
			if (InputoBj.getValue("OLC_SL").trim().equalsIgnoreCase("")) {
				_olcsl = 0;
			} else {
				_olcsl = Integer.parseInt(InputoBj.getValue("OLC_SL").trim().toString());
			}

			Init_ResultObj(InputoBj);
			if (String.valueOf(_olcBrnCode).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (Check_Result_Status()) {
				if (!String.valueOf(_olcBrnCode).trim().equalsIgnoreCase("")) {
					if (_olcBrnCode == 0)
						if (InputoBj.containsKey("OLC_BRN_CODE") == true && InputoBj.getValue("OLC_BRN_CODE").equalsIgnoreCase(""))
							Resultobj.setValue(ErrorKey, BLANK_CHECK);
						else
							Resultobj.setValue(ErrorKey, ZERO_CHECK);
				}
			}

			Init_ResultObj(InputoBj);
			if (String.valueOf(_olcYear).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (Check_Result_Status()) {
				if (!String.valueOf(_olcYear).trim().equalsIgnoreCase("")) {
					if (_olcYear == 0)
						if (InputoBj.containsKey("OLC_YEAR") == true && InputoBj.getValue("OLC_YEAR").equalsIgnoreCase(""))
							Resultobj.setValue(ErrorKey, BLANK_CHECK);
						else
							Resultobj.setValue(ErrorKey, ZERO_CHECK);
				}
			}

			Init_ResultObj(InputoBj);
			if (String.valueOf(_olcsl).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (Check_Result_Status()) {
				if (!String.valueOf(_olcsl).trim().equalsIgnoreCase("")) {
					if (_olcsl == 0)
						if (InputoBj.containsKey("OLC_SL") == true && InputoBj.getValue("OLC_SL").equalsIgnoreCase(""))
							Resultobj.setValue(ErrorKey, BLANK_CHECK);
						else
							Resultobj.setValue(ErrorKey, ZERO_CHECK);
				}
			}

			if (Check_Result_Status()) {
				_QueryStr = "SELECT TO_CLOB(LC_DOC_REQ1)LC_DOC_REQ1,TO_CLOB(LC_DOC_REQ2)LC_DOC_REQ2,TO_CLOB(LC_DOC_REQ3)LC_DOC_REQ3 FROM LC_DETAILS WHERE LC_BRN_CODE = ? AND LC_LC_TYPE =? AND LC_LC_YEAR=? AND LC_LC_SL=?";
				Set_preparedStatement(_QueryStr);
				_pstmt.setInt(1, _olcBrnCode);
				_pstmt.setString(2, olcType);
				_pstmt.setInt(3, _olcYear);
				_pstmt.setInt(4, _olcsl);
				ResultSet rs1 = ExecuteQuery();
				if (rs1.next()) {

					dto_good1.clearMap();
					dto_good1 = FetchClobData(_olcBrnCode, olcType, _olcYear, _olcsl, rs1.getClob("LC_DOC_REQ1"), "LC_DOC_REQ1");
					Resultobj.setValue("LC_DOC_REQ1", dto_good1.getValue("LC_DOC_REQ1"));

					dto_good1.clearMap();
					dto_good1 = FetchClobData(_olcBrnCode, olcType, _olcYear, _olcsl, rs1.getClob("LC_DOC_REQ2"), "LC_DOC_REQ2");
					Resultobj.setValue("LC_DOC_REQ2", dto_good1.getValue("LC_DOC_REQ2"));

					dto_good1.clearMap();
					dto_good1 = FetchClobData(_olcBrnCode, olcType, _olcYear, _olcsl, rs1.getClob("LC_DOC_REQ3"), "LC_DOC_REQ3");
					Resultobj.setValue("LC_DOC_REQ3", dto_good1.getValue("LC_DOC_REQ3"));

				}
			}

		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in getOLCDocsDescn");
		}
		return Resultobj.copyofDTO();
	}

	public DTObject getOLCAddlDescn(DTObject InputoBj) {
		try {

			int _olcBrnCode = 0;
			if (InputoBj.getValue("OLC_BRN_CODE").trim().equalsIgnoreCase("")) {
				_olcBrnCode = 0;
			} else {
				_olcBrnCode = Integer.parseInt(InputoBj.getValue("OLC_BRN_CODE").trim().toString());
			}
			String olcType = "";
			olcType = InputoBj.getValue("OLC_TYPE").trim().toString();
			int _olcYear = 0;
			if (InputoBj.getValue("OLC_YEAR").trim().equalsIgnoreCase("")) {
				_olcYear = 0;
			} else {
				_olcYear = Integer.parseInt(InputoBj.getValue("OLC_YEAR").trim().toString());
			}
			int _olcsl = 0;
			if (InputoBj.getValue("OLC_SL").trim().equalsIgnoreCase("")) {
				_olcsl = 0;
			} else {
				_olcsl = Integer.parseInt(InputoBj.getValue("OLC_SL").trim().toString());
			}

			Init_ResultObj(InputoBj);
			if (String.valueOf(_olcBrnCode).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (Check_Result_Status()) {
				if (!String.valueOf(_olcBrnCode).trim().equalsIgnoreCase("")) {
					if (_olcBrnCode == 0)
						if (InputoBj.containsKey("OLC_BRN_CODE") == true && InputoBj.getValue("OLC_BRN_CODE").equalsIgnoreCase(""))
							Resultobj.setValue(ErrorKey, BLANK_CHECK);
						else
							Resultobj.setValue(ErrorKey, ZERO_CHECK);
				}
			}

			Init_ResultObj(InputoBj);
			if (String.valueOf(_olcYear).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (Check_Result_Status()) {
				if (!String.valueOf(_olcYear).trim().equalsIgnoreCase("")) {
					if (_olcYear == 0)
						if (InputoBj.containsKey("OLC_YEAR") == true && InputoBj.getValue("OLC_YEAR").equalsIgnoreCase(""))
							Resultobj.setValue(ErrorKey, BLANK_CHECK);
						else
							Resultobj.setValue(ErrorKey, ZERO_CHECK);
				}
			}

			Init_ResultObj(InputoBj);
			if (String.valueOf(_olcsl).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
			if (Check_Result_Status()) {
				if (!String.valueOf(_olcsl).trim().equalsIgnoreCase("")) {
					if (_olcsl == 0)
						if (InputoBj.containsKey("OLC_SL") == true && InputoBj.getValue("OLC_SL").equalsIgnoreCase(""))
							Resultobj.setValue(ErrorKey, BLANK_CHECK);
						else
							Resultobj.setValue(ErrorKey, ZERO_CHECK);
				}
			}

			if (Check_Result_Status()) {
				_QueryStr = "SELECT TO_CLOB(LC_ADD_CONDITION1)LC_ADD_CONDITION1,TO_CLOB(LC_ADD_CONDITION2)LC_ADD_CONDITION2,TO_CLOB(LC_ADD_CONDITION3)LC_ADD_CONDITION3 FROM LC_DETAILS WHERE LC_BRN_CODE = ? AND LC_LC_TYPE =? AND LC_LC_YEAR=? AND LC_LC_SL=?";
				Set_preparedStatement(_QueryStr);
				_pstmt.setInt(1, _olcBrnCode);
				_pstmt.setString(2, olcType);
				_pstmt.setInt(3, _olcYear);
				_pstmt.setInt(4, _olcsl);
				ResultSet rs1 = ExecuteQuery();
				if (rs1.next()) {
					dto_good1.clearMap();
					dto_good1 = FetchClobData(_olcBrnCode, olcType, _olcYear, _olcsl, rs1.getClob("LC_ADD_CONDITION1"), "LC_ADD_CONDITION1");
					Resultobj.setValue("LC_ADD_CONDITION1", dto_good1.getValue("LC_ADD_CONDITION1"));

					dto_good1.clearMap();
					dto_good1 = FetchClobData(_olcBrnCode, olcType, _olcYear, _olcsl, rs1.getClob("LC_ADD_CONDITION2"), "LC_ADD_CONDITION2");
					Resultobj.setValue("LC_ADD_CONDITION2", dto_good1.getValue("LC_ADD_CONDITION2"));

					dto_good1.clearMap();
					dto_good1 = FetchClobData(_olcBrnCode, olcType, _olcYear, _olcsl, rs1.getClob("LC_ADD_CONDITION3"), "LC_ADD_CONDITION3");
					Resultobj.setValue("LC_ADD_CONDITION3", dto_good1.getValue("LC_ADD_CONDITION3"));
				}
			}

		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in getOLCAddlDescn");
		}
		return Resultobj.copyofDTO();
	}

	public DTObject Split_clob_Data(DTObject InputoBj) {
		try {

			int lc_brn = 0;
			String lc_type = "";
			int lc_year = 0;
			int lc_serial = 0;
			int amend_serial = 0;
			Clob good1 = null;
			Clob good2 = null;
			Clob good3 = null;
			Clob doc_req1 = null;
			Clob doc_req2 = null;
			Clob doc_req3 = null;
			Clob add1 = null;
			Clob add2 = null;
			Clob add3 = null;

			DTObject dto_good1 = new DTObject();
			DTObject dto_good2 = new DTObject();
			DTObject dto_good3 = new DTObject();
			DTObject dto_doc_req1 = new DTObject();
			DTObject dto_doc_req2 = new DTObject();
			DTObject dto_doc_req3 = new DTObject();
			DTObject dto_add1 = new DTObject();
			DTObject dto_add2 = new DTObject();
			DTObject dto_add3 = new DTObject();
			DTObject Resultobj1 = new DTObject();

			Connection _conn = null;
			_conn = openConnection();

			if (!InputoBj.getValue("OLC_YEAR").trim().equals("")) {
				lc_year = Integer.parseInt(InputoBj.getValue("OLC_YEAR").trim().toString());
			} else {
				lc_year = 0;
			}
			if (!InputoBj.getValue("OLC_SL").trim().equals("")) {
				lc_serial = Integer.parseInt(InputoBj.getValue("OLC_SL").trim().toString());
			} else {
				lc_serial = 0;
			}
			if (!InputoBj.getValue("OLC_BRN_CODE").trim().equals("")) {
				lc_brn = Integer.parseInt(InputoBj.getValue("OLC_BRN_CODE").trim().toString());
			} else {
				lc_brn = 0;
			}
			if (!InputoBj.getValue("OLC_TYPE").trim().equals("")) {
				lc_type = InputoBj.getValue("OLC_TYPE").trim().toString();
			} else {
				lc_type = "";
			}
			if (!InputoBj.getValue("AMEND_SL").trim().equals("")) {
				amend_serial = Integer.parseInt(InputoBj.getValue("AMEND_SL").trim().toString());
			} else {
				amend_serial = 0;
			}

			Resultobj.clearMap();
			good1 = GetClobData(lc_brn, lc_type, lc_year, lc_serial, "AMEND_DESC_GODD_SER1", amend_serial);
			good2 = GetClobData(lc_brn, lc_type, lc_year, lc_serial, "AMEND_DESC_GODD_SER2", amend_serial);
			good3 = GetClobData(lc_brn, lc_type, lc_year, lc_serial, "AMEND_DESC_GODD_SER3", amend_serial);
			doc_req1 = GetClobData(lc_brn, lc_type, lc_year, lc_serial, "AMEND_DOC_REQ1", amend_serial);
			doc_req2 = GetClobData(lc_brn, lc_type, lc_year, lc_serial, "AMEND_DOC_REQ2", amend_serial);
			doc_req3 = GetClobData(lc_brn, lc_type, lc_year, lc_serial, "AMEND_DOC_REQ3", amend_serial);
			add1 = GetClobData(lc_brn, lc_type, lc_year, lc_serial, "AMEND_ADD_CONDITION1", amend_serial);
			add2 = GetClobData(lc_brn, lc_type, lc_year, lc_serial, "AMEND_ADD_CONDITION2", amend_serial);
			add3 = GetClobData(lc_brn, lc_type, lc_year, lc_serial, "AMEND_ADD_CONDITION3", amend_serial);

			//Resultobj.clearMap();	
			Resultobj1 = Resultobj.copyofDTO();
			if (good1 != null && good1.length() > 0) {
				dto_good1 = FetchClobData(lc_brn, lc_type, lc_year, lc_serial, good1, "LC_DESC_GOODS_SER1");
				Resultobj.setValue("LC_DESC_GOODS_SER1", dto_good1.getValue("LC_DESC_GOODS_SER1"));
			}

			if (good2 != null && good2.length() > 0) {
				dto_good2 = FetchClobData(lc_brn, lc_type, lc_year, lc_serial, good2, "LC_DESC_GOODS_SER2");
				Resultobj.setValue("LC_DESC_GOODS_SER2", dto_good2.getValue("LC_DESC_GOODS_SER2"));
			}

			if (good3 != null && good3.length() > 0) {
				dto_good3 = FetchClobData(lc_brn, lc_type, lc_year, lc_serial, good3, "LC_DESC_GOODS_SER3");
				Resultobj.setValue("LC_DESC_GOODS_SER3", dto_good3.getValue("LC_DESC_GOODS_SER3"));
			}

			if (doc_req1 != null && doc_req1.length() > 0) {
				dto_doc_req1 = FetchClobData(lc_brn, lc_type, lc_year, lc_serial, doc_req1, "LC_DOC_REQ1");
				Resultobj.setValue("LC_DOC_REQ1", dto_doc_req1.getValue("LC_DOC_REQ1"));
			}

			if (doc_req2 != null && doc_req2.length() > 0) {
				dto_doc_req2 = FetchClobData(lc_brn, lc_type, lc_year, lc_serial, doc_req2, "LC_DOC_REQ2");
				Resultobj.setValue("LC_DOC_REQ2", dto_doc_req2.getValue("LC_DOC_REQ2"));
			}

			if (doc_req3 != null && doc_req3.length() > 0) {
				dto_doc_req3 = FetchClobData(lc_brn, lc_type, lc_year, lc_serial, doc_req3, "LC_DOC_REQ3");
				Resultobj.setValue("LC_DOC_REQ3", dto_doc_req3.getValue("LC_DOC_REQ3"));
			}

			if (add1 != null && add1.length() > 0) {
				dto_add1 = FetchClobData(lc_brn, lc_type, lc_year, lc_serial, add1, "LC_ADD_CONDITION1");
				Resultobj.setValue("LC_ADD_CONDITION1", dto_add1.getValue("LC_ADD_CONDITION1"));
			}

			if (add2 != null && add2.length() > 0) {
				dto_add2 = FetchClobData(lc_brn, lc_type, lc_year, lc_serial, add2, "LC_ADD_CONDITION2");
				Resultobj.setValue("LC_ADD_CONDITION2", dto_add2.getValue("LC_ADD_CONDITION2"));
			}

			if (add3 != null && add3.length() > 0) {
				dto_add3 = FetchClobData(lc_brn, lc_type, lc_year, lc_serial, add3, "LC_ADD_CONDITION3");
				Resultobj.setValue("LC_ADD_CONDITION3", dto_add3.getValue("LC_ADD_CONDITION3"));
			}
			Resultobj1.setMap(Resultobj.copyofDTO().getMap());
			Resultobj = Resultobj1;

			_conn.close();
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in Split_clob_Data");
		}
		return Resultobj.copyofDTO();
	}

	public Clob GetClobData(int lc_brn, String lc_type, int lc_year, int lc_serial, String column_name, int amend_serial) throws SQLException {
		Clob clob_value = null;
		Connection _conn = null;
		_conn = openConnection();

		try {
			if (Check_Result_Status()) {

				String qstr2 = "SELECT " + column_name + " AS CDATA FROM  AMEND_DETAILS WHERE AMEND_LC_BRN_CODE=? AND AMEND_LC_TYPE=? AND AMEND_LC_YEAR=? AND AMEND_LC_SERIAL=? AND AMEND_LC_AMD_SL=?";
				PreparedStatement _pstmt2 = _conn.prepareStatement(qstr2);
				_pstmt2.setInt(1, lc_brn);
				_pstmt2.setString(2, lc_type);
				_pstmt2.setInt(3, lc_year);
				_pstmt2.setInt(4, lc_serial);
				_pstmt2.setInt(5, amend_serial);
				ResultSet rs2 = _pstmt2.executeQuery();
				if (rs2.next()) {
					clob_value = rs2.getClob("CDATA");
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return clob_value;
	}

	public DTObject FetchClobData(int lc_brn, String lc_type, int lc_year, int lc_serial, Clob clob_data, String column_name) throws SQLException {

		Connection _conn = null;
		String result_data = "";
		String result_data1 = "";
		_conn = openConnection();
		// Resultobj.clearMap();

		try {
			if (Check_Result_Status()) {
				String qstr = "SELECT dbms_lob.substr(?,4000,1) AS CLOB_DATA FROM  LC_DETAILS WHERE LC_BRN_CODE=? AND LC_LC_TYPE=? AND LC_LC_YEAR=? AND LC_LC_SL=?";
				PreparedStatement _pstmt = _conn.prepareStatement(qstr);
				_pstmt.setClob(1, clob_data);
				_pstmt.setInt(2, lc_brn);
				_pstmt.setString(3, lc_type);
				_pstmt.setInt(4, lc_year);
				_pstmt.setInt(5, lc_serial);
				ResultSet rs = _pstmt.executeQuery();
				if (rs.next()) {
					result_data = rs.getString("CLOB_DATA");
				}

				String qstr1 = "SELECT dbms_lob.substr(?,4000,4001) AS CLOB_DATA1 FROM  LC_DETAILS WHERE LC_BRN_CODE=? AND LC_LC_TYPE=? AND LC_LC_YEAR=? AND LC_LC_SL=?";
				PreparedStatement _pstmt1 = _conn.prepareStatement(qstr1);
				_pstmt1.setClob(1, clob_data);
				_pstmt1.setInt(2, lc_brn);
				_pstmt1.setString(3, lc_type);
				_pstmt1.setInt(4, lc_year);
				_pstmt1.setInt(5, lc_serial);
				ResultSet rs1 = _pstmt1.executeQuery();
				if (rs1.next()) {
					result_data1 = rs1.getString("CLOB_DATA1");
				}

				if (result_data == null) {
					result_data = "";
				}
				if (result_data1 == null) {
					result_data1 = "";
				}

				Resultobj.setValue(column_name, result_data + result_data1);
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in fetching clob details");
		}

		return Resultobj.copyofDTO();
	}

	public DTObject Special_Char_Validation(DTObject InputoBj) {
		Clob _result = null;
		String temp1 = "";
		String temp3 = "";
		int _olcSlno = 0;
		int _olcBranCode = 0;
		int _olcYear = 0;
		int _olcSl = 0;
		String _olcType = "";
		String spChar = "";
		int _olc_day_serial = 0;
		String _olc_entry_date = "";
		String _lcps_cust_no = "";
		String olc_column_name = "";
		//String olc_sl="";

		try

		{

			_olcBranCode = Integer.parseInt(InputoBj.getValue("OLC_BRANCH_CODE").trim().toString());
			_olcType = InputoBj.getValue("OLC_TYPE").trim().toString();
			_olcYear = Integer.parseInt(InputoBj.getValue("OLC_YEAR").trim().toString());
			_olc_day_serial = Integer.parseInt(InputoBj.getValue("OLC_DAY_SER").trim().toString());
			_olc_entry_date = FormatUtils.formatToDDMonYear(InputoBj.getValue("OLC_ENTRY_DATE").trim().toString());
			_lcps_cust_no = InputoBj.getValue("OLC_CUST_NO").trim().toString();
			olc_column_name = InputoBj.getValue("OLC_COLUMNNAME").trim().toString();

			if (!InputoBj.getValue("OLC_CLOB").trim().equalsIgnoreCase("")) {
				spChar = InputoBj.getValue("OLC_CLOB").trim().toString();
			} else {
				spChar = "";
			}

			Connection con = null;
			con = openConnection();

			/*_QueryStr = "select MAX(OLC_LC_SL) OLC_LC_SL FROM OLC WHERE OLC_BRN_CODE=? AND OLC_LC_TYPE='OLC' AND OLC_LC_YEAR=? ";
			Set_preparedStatement(_QueryStr);
			_pstmt.setInt(1, _olcBranCode);
			_pstmt.setInt(2, _olcYear);
			Get_Value_From_Main("OLC");
			if(Check_Result_Status() == true)
			{
			if (Resultobj.getValue(ResultKey).equalsIgnoreCase(RowNotPresent))
			 {
			 Resultobj.setValue(ErrorKey,"No Row");
			 }
			else
			{
				olc_sl=Resultobj.getValue("OLC_LC_SL");
			}
			}*/

			con.setAutoCommit(false);
			_QueryStr = "delete from tempolc where TEMPOLC_BRN=" + _olcBranCode + " and TEMPOLC_TYP ='" + _olcType + "' and TEMPOLC_YEAR=" + _olcYear + " and TEMPOLC_ENTRY_DATE= '" + _olc_entry_date + "' and TEMPOLC_PRES_SL=" + _olc_day_serial + "  and TEMPOLC_COLUMNNAME='" + olc_column_name + "'";
			PreparedStatement pstmt1 = con.prepareStatement(_QueryStr);
			pstmt1.executeUpdate();
			pstmt1.close();

			_QueryStr = "insert into tempolc values(" + _olcBranCode + ",'" + _olcType + "'," + _olcYear + ",'" + _olc_entry_date + "'," + _olc_day_serial + ",'" + olc_column_name + "'," + "empty_clob()) ";
			Statement stmt = con.createStatement();
			ResultSet rs11 = stmt.executeQuery(_QueryStr);
			String sqll = "select TEMPOLC_CLOBDATA from tempolc  where TEMPOLC_BRN=" + _olcBranCode + " and TEMPOLC_TYP ='" + _olcType + "' and TEMPOLC_YEAR=" + _olcYear + " and TEMPOLC_ENTRY_DATE= '" + _olc_entry_date + "' and TEMPOLC_PRES_SL=" + _olc_day_serial + "  and TEMPOLC_COLUMNNAME='" + olc_column_name + "' for update";
			ResultSet rss = stmt.executeQuery(sqll);
			if (rss.next()) {
				//CLOB clob = ((OracleResultSet)rss).getCLOB(1);
				oracle.sql.CLOB clob = (oracle.sql.CLOB) rss.getClob("TEMPOLC_CLOBDATA");
				clob.putString(1, spChar);
				_QueryStr = "update tempolc set TEMPOLC_CLOBDATA=? where TEMPOLC_BRN=" + _olcBranCode + " and TEMPOLC_TYP ='" + _olcType + "' and TEMPOLC_YEAR=" + _olcYear + " and TEMPOLC_ENTRY_DATE= '" + _olc_entry_date + "' and TEMPOLC_PRES_SL=" + _olc_day_serial + "  and TEMPOLC_COLUMNNAME='" + olc_column_name + "'";
				PreparedStatement pstmt = con.prepareStatement(_QueryStr);
				pstmt.setClob(1, clob);
				pstmt.executeUpdate();
				pstmt.close();
			}
			con.commit();

			Clob aclob1;
			Reader allClob1;
			BufferedReader br1;

			CallableStatement _cstmt = null;
			Connection _conn = null;
			_conn = openConnection();
			String newline = System.getProperty("line.separator");
			String line = "";
			if (Check_Result_Status()) {
				String qstr = "SELECT PKG_CSB_SWIFT.EXSPCHARVAL(?,?,?,?,?,?,?) AS LEN_VAL FROM DUAL";
				PreparedStatement _pstmt = _conn.prepareStatement(qstr);
				_pstmt.setInt(1, _olcBranCode);
				_pstmt.setString(2, _olcType);
				_pstmt.setInt(3, _olcYear);
				_pstmt.setString(4, _olc_entry_date);
				_pstmt.setInt(5, _olc_day_serial);
				_pstmt.setString(6, _lcps_cust_no);
				_pstmt.setString(7, olc_column_name);
				ResultSet rs = _pstmt.executeQuery();
				if (rs.next()) {

					aclob1 = rs.getClob(1);
					allClob1 = aclob1.getCharacterStream();
					br1 = new BufferedReader(allClob1);
					long ii = 0;
					while ((line = br1.readLine()) != null) {

						if (ii == 0) {
							temp3 = line;
						} else {
							temp3 = temp3 + newline + line;
						}
						ii++;

					}
				}

				System.out.println("test " + temp3);

				aclob1 = null;

				br1 = null;

				allClob1 = null;

				Resultobj.setValue("TEMP", temp3);
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in Special_Char_Validation");
		}
		return Resultobj.copyofDTO();
	}

	//ADDED BY PRASHANTH ON 07 FEB 2019

	//NEW TABS ADDED BY PRASHANTH ON 19 FEB 2019
	public DTObject Olc_Doc_CreditKeypress(DTObject InputoBj) {
		try {
			Resultobj.clearMap();
			Resultobj = swval.Form_of_Documentary_Credit(InputoBj);
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in Olc_Doc_CreditKeypress");
		}
		return Resultobj.copyofDTO();
	}

	public DTObject Olc_AvailableWithKeypress(DTObject InputoBj) {
		try {
			Resultobj.clearMap();
			Resultobj = swval.AvailableWith_Bank(InputoBj);
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in Olc_AvailableWithKeypress");
		}
		return Resultobj.copyofDTO();
	}

	public DTObject Olc_ApplicantBicKeypress(DTObject InputoBj) {
		try {
			Resultobj.clearMap();
			Resultobj = swval.ApplicantBankBic(InputoBj);
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in Olc_ApplicantBicKeypress");
		}
		return Resultobj.copyofDTO();
	}

	public DTObject Olc_ApplicantBankBrachCodeKeypress(DTObject InputoBj) {
		try {
			Resultobj.clearMap();
			Resultobj = swval.ApplicantBankBranch(InputoBj);
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in Olc_ApplicantBankBrachCodeKeypress");
		}
		return Resultobj.copyofDTO();
	}

	public DTObject Olc_ApplicantBankNameKeypress(DTObject InputoBj) {
		try {
			Resultobj.clearMap();
			Resultobj = swval.ApplicantBankName(InputoBj);
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in Olc_ApplicantBankNameKeypress");
		}
		return Resultobj.copyofDTO();
	}

	public DTObject Olc_ApplicantBankAddressKeypress(DTObject InputoBj) {
		try {
			Resultobj.clearMap();
			Resultobj = swval.ApplicantBankAddress(InputoBj);
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in Olc_ApplicantBankAddressKeypress");
		}
		return Resultobj.copyofDTO();
	}

	public DTObject Olc_ApplicantBankCntryCodeKeypress(DTObject InputoBj) {
		try {
			Resultobj.clearMap();
			Resultobj = swval.ApplicantBankCountryCode(InputoBj);
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in Olc_ApplicantBankCntryCodeKeypress");
		}
		return Resultobj.copyofDTO();
	}

	public DTObject Olc_ApplicantAccountNumberKeypress(DTObject InputoBj) {
		try {
			Resultobj.clearMap();
			Resultobj = swval.ApplicantAccountNumber(InputoBj);
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in Olc_ApplicantAccountNumberKeypress");
		}
		return Resultobj.copyofDTO();
	}

	public DTObject Olc_ApplicantBankTypeKeypress(DTObject InputoBj) {
		try {
			Resultobj.clearMap();
			Resultobj = swval.ApplicantBankType(InputoBj);
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in Olc_ApplicantBankTypeKeypress");
		}
		return Resultobj.copyofDTO();
	}

	public DTObject olcAdvBranchCodekeypress(DTObject InputoBj) {
		try {
			String olcAdvBrnchCode = "";
			String olcAdvBnkCode = "";
			olcAdvBrnchCode = InputoBj.getValue("OLC_ADV_BRNCH_CODE").trim().toString();
			olcAdvBnkCode = InputoBj.getValue("OLC_ADV_BANK_CODE").trim().toString();
			if (Check_Result_Status()) {
				CommonValidator comnval = new CommonValidator();
				DTObject dtobj = new DTObject();
				dtobj.clearMap();
				dtobj.setValue("MBKBRN_BANK_CODE", olcAdvBnkCode);
				dtobj.setValue("MBKBRN_BRN_CODE", olcAdvBrnchCode);
				Resultobj = comnval.valmbkbrn(dtobj);
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in olcAdvBankCodekeypress");
		}
		return Resultobj.copyofDTO();
	}

	public DTObject olcBranchNamekeypress(DTObject InputoBj) {
		try {
			String olcBrnchName = "";
			{
				olcBrnchName = InputoBj.getValue("OLC_BRNCH_NAME").trim().toString();
			}
			Init_ResultObj(InputoBj);
			if (String.valueOf(olcBrnchName).trim().equalsIgnoreCase("")) {
				Resultobj.setValue(ErrorKey, BLANK_CHECK);
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in olcAdvBranchNamekeypress");
		}
		return Resultobj.copyofDTO();
	}

	public DTObject olcAdvBankCodekeypress(DTObject InputoBj) {
		try {
			String olcAdvBnkCode = "";
			olcAdvBnkCode = InputoBj.getValue("OLC_ADV_BANK_CODE").trim().toString();
			if (Check_Result_Status()) {
				CommonValidator comnval = new CommonValidator();
				DTObject dtobj = new DTObject();
				dtobj.clearMap();
				dtobj.setValue("BANKCD_CODE", olcAdvBnkCode);
				Resultobj = comnval.valbankcd(dtobj);
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in olcAdvBankCodekeypress");
		}
		return Resultobj.copyofDTO();
	}

	public DTObject Olc_Confirmation_InstKeyPress(DTObject InputoBj) {
		try {
			Resultobj.clearMap();
			Resultobj = swval.ConfirmationInstruction(InputoBj);
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in Olc_Confirmation_InstKeyPress");
		}
		return Resultobj.copyofDTO();
	}

	//NEW TABS ADDED BY PRASHANTH ON 19 FEB 2019

	//added by prashanth

	public DTObject loadAmdChoiceMod(DTObject InputoBj) {
		try {

			int lcsl = 0;
			int _branchCode = 0;
			int lcyear = 0;
			String lctype = "";
			int amdSl = 0;
			String amdFor = "";
			String mod = "";
			mod = InputoBj.getValue("MODE").trim().toString();

			lcsl = Integer.parseInt(InputoBj.getValue("OLC_LC_SL").trim().toString());
			_branchCode = Integer.parseInt(InputoBj.getValue("OLC_BRN_CODE").trim().toString());
			lcyear = Integer.parseInt(InputoBj.getValue("OLC_YEAR").trim().toString());
			lctype = InputoBj.getValue("OLC_TYPE").trim().toString();
			amdSl = Integer.parseInt(InputoBj.getValue("OLC_AMD_SL").trim().toString());
			amdFor = InputoBj.getValue("AMDFOR").trim().toString();

			if (Check_Result_Status()) {
				_QueryStr = "SELECT LISTAGG(O.OLCAC_CHOICE_SL ,'/')WITHIN GROUP(ORDER BY O.OLCAC_BRN_CODE,O.OLCAC_LC_TYPE,O.OLCAC_LC_YEAR,O.OLCAC_LC_SL,O.OLCAC_AMD_SL,O.OLCAC_FIELD_TYPE,O.OLCAC_CHOICE_SL)  OLCAC_CHOICE_SL,LISTAGG(O.OLCAC_AMD_CHOICE ,'/')WITHIN GROUP(ORDER BY O.OLCAC_BRN_CODE,O.OLCAC_LC_TYPE,O.OLCAC_LC_YEAR,O.OLCAC_LC_SL,O.OLCAC_AMD_SL,O.OLCAC_FIELD_TYPE,O.OLCAC_CHOICE_SL)  OLCAC_AMD_CHOICE,LISTAGG(O.OLCAC_AMD_RANGE_FROM ,'/')WITHIN GROUP(ORDER BY O.OLCAC_BRN_CODE,O.OLCAC_LC_TYPE,O.OLCAC_LC_YEAR,O.OLCAC_LC_SL,O.OLCAC_AMD_SL,O.OLCAC_FIELD_TYPE,O.OLCAC_CHOICE_SL)  OLCAC_AMD_RANGE_FROM,LISTAGG(O.OLCAC_AMD_RANGE_UPTO ,'/')WITHIN GROUP(ORDER BY O.OLCAC_BRN_CODE,O.OLCAC_LC_TYPE,O.OLCAC_LC_YEAR,O.OLCAC_LC_SL,O.OLCAC_AMD_SL,O.OLCAC_FIELD_TYPE,O.OLCAC_CHOICE_SL,O.OLCAC_CHOICE_SL)  OLCAC_AMD_RANGE_UPTO FROM OLCAMDCHOICE O  WHERE O.OLCAC_BRN_CODE=? AND O.OLCAC_LC_TYPE=? AND O.OLCAC_LC_YEAR=? AND O.OLCAC_LC_SL=? AND O.OLCAC_AMD_SL=? AND O.OLCAC_FIELD_TYPE=?";
				Set_preparedStatement(_QueryStr);
				_pstmt.setInt(1, _branchCode);
				_pstmt.setString(2, lctype);
				_pstmt.setInt(3, lcyear);
				_pstmt.setInt(4, lcsl);
				if (mod.equals("M")) {
					_pstmt.setInt(5, amdSl);
				} else {
					if (amdSl > 1) {
						amdSl = amdSl - 1;
					}
					_pstmt.setInt(5, amdSl);
				}
				_pstmt.setString(6, amdFor);

				ResultSet rs1 = ExecuteQuery();
				if (rs1.next()) {
					Resultobj.setValue("OLCAC_CHOICE_SL", rs1.getString("OLCAC_CHOICE_SL"));
					Resultobj.setValue("OLCAC_AMD_CHOICE", rs1.getString("OLCAC_AMD_CHOICE"));
					Resultobj.setValue("OLCAC_AMD_RANGE_FROM", rs1.getString("OLCAC_AMD_RANGE_FROM"));
					Resultobj.setValue("OLCAC_AMD_RANGE_UPTO", rs1.getString("OLCAC_AMD_RANGE_UPTO"));
					Resultobj.setValue(ResultKey, RowPresent);
				} else {
					Resultobj.setValue(ResultKey, RowNotPresent);
				}
			}
		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in loadAmdChoiceModInModify");
		}
		return Resultobj.copyofDTO();
	}

	public DTObject loadLogMod(DTObject InputoBj) {

		try {

		int lcsl = 0;
		int _branchCode = 0;
		int lcyear = 0;
		String lctype = "";
		int amdSl = 0;
		String amdFor = "";

		lcsl = Integer.parseInt(InputoBj.getValue("OLC_LC_SL").trim().toString());
		_branchCode = Integer.parseInt(InputoBj.getValue("OLC_BRN_CODE").trim().toString());
		lcyear = Integer.parseInt(InputoBj.getValue("OLC_YEAR").trim().toString());
		lctype = InputoBj.getValue("OLC_TYPE").trim().toString();
		amdSl = Integer.parseInt(InputoBj.getValue("OLC_AMD_SL").trim().toString());
		amdFor = InputoBj.getValue("AMDFOR").trim().toString();
		String mod = "";
		mod = InputoBj.getValue("MODE").trim().toString();

		if (Check_Result_Status()) {
		_QueryStr = "SELECT LISTAGG(O.OLCATL_TEXT ,'/')WITHIN GROUP(ORDER BY O.OLCATL_BRN_CODE,O.OLCATL_LC_TYPE,O.OLCATL_LC_YEAR,O.OLCATL_LC_SL,O.OLCATL_AMD_SL,O.OLCATL_FIELD_TYPE,OLCATL_CHOICE_SL,OLCATL_LOG_SL)OLCATL_TEXT,LISTAGG(O.OLCATL_CHOICE_SL ,'/')WITHIN GROUP(ORDER BY O.OLCATL_BRN_CODE,O.OLCATL_LC_TYPE,O.OLCATL_LC_YEAR,O.OLCATL_LC_SL,O.OLCATL_AMD_SL,O.OLCATL_FIELD_TYPE,O.OLCATL_LOG_SL)OLCATL_CHOICE_SL FROM OLCAMDTEXTLOG O WHERE O.OLCATL_BRN_CODE=? AND O.OLCATL_LC_TYPE=? AND O.OLCATL_LC_YEAR=? AND O.OLCATL_LC_SL=? AND O.OLCATL_AMD_SL=? AND O.OLCATL_FIELD_TYPE=?";
		Set_preparedStatement(_QueryStr);
		_pstmt.setInt(1, _branchCode);
		_pstmt.setString(2, lctype);
		_pstmt.setInt(3, lcyear);
		_pstmt.setInt(4, lcsl);
		if (mod.equals("M")) {
		_pstmt.setInt(5, amdSl);
		} else {
		if (amdSl > 1) {
		amdSl = amdSl - 1;
		}
		_pstmt.setInt(5, amdSl);
		}
		_pstmt.setString(6, amdFor);

		ResultSet rs1 = ExecuteQuery();
		if (rs1.next()) {
		Resultobj.setValue("OLCATL_TEXT", rs1.getString("OLCATL_TEXT"));
		Resultobj.setValue("OLCATL_CHOICE_SL", rs1.getString("OLCATL_CHOICE_SL"));
		Resultobj.setValue(ResultKey, RowPresent);
		} else {
		Resultobj.setValue(ResultKey, RowNotPresent);
		}
		}
		} catch (Exception e) {
		Resultobj.setValue(ErrorKey, "Error in loadGoodsInModify");
		}
		return Resultobj.copyofDTO();
		}

	public DTObject LoadComplMod(DTObject InputoBj) {
		try {

		int lcsl = 0;
		int _branchCode = 0;
		int lcyear = 0;
		String lctype = "";
		int amdSl = 0;
		String amdFor = "";

		lcsl = Integer.parseInt(InputoBj.getValue("OLC_LC_SL").trim().toString());
		_branchCode = Integer.parseInt(InputoBj.getValue("OLC_BRN_CODE").trim().toString());
		lcyear = Integer.parseInt(InputoBj.getValue("OLC_YEAR").trim().toString());
		lctype = InputoBj.getValue("OLC_TYPE").trim().toString();
		amdSl = Integer.parseInt(InputoBj.getValue("OLC_AMD_SL").trim().toString());
		amdFor = InputoBj.getValue("AMDFOR").trim().toString();
		String mod = "";
		mod = InputoBj.getValue("MODE").trim().toString();
		String oldtext = "";
		int rcount=0;
		String newtext="";
		if (Check_Result_Status()) {
		// _QueryStr = "SELECT LISTAGG(O.OLCAT_TEXT ,'/')WITHIN GROUP(ORDER BY O.OLCAT_BRN_CODE,O.OLCAT_LC_TYPE,O.OLCAT_LC_YEA,O.OLCAT_LC_SL,O.OLCAT_AMD_SL,O.OLCAT_FIELD_TYPE,O.OLCAT_TEXT_SL) OLCAT_TEXT FROM OLCAMDTEXT O WHERE O.OLCAT_BRN_CODE=? AND O.OLCAT_LC_TYPE=? AND O.OLCAT_LC_YEA=? AND O.OLCAT_LC_SL=? AND O.OLCAT_AMD_SL=? AND O.OLCAT_FIELD_TYPE=?";
		_QueryStr = "SELECT O.OLCAT_TEXT AS VALUE FROM OLCAMDTEXT O WHERE O.OLCAT_BRN_CODE=? AND O.OLCAT_LC_TYPE=? AND O.OLCAT_LC_YEA=? AND O.OLCAT_LC_SL=? AND O.OLCAT_AMD_SL=? AND O.OLCAT_FIELD_TYPE=? AND TRIM(O.OLCAT_TEXT) IS NOT NULL ORDER BY O.OLCAT_BRN_CODE,O.OLCAT_LC_TYPE,O.OLCAT_LC_YEA,O.OLCAT_LC_SL,O.OLCAT_AMD_SL,O.OLCAT_FIELD_TYPE,O.OLCAT_TEXT_SL";

		Set_preparedStatement(_QueryStr);
		_pstmt.setInt(1, _branchCode);
		_pstmt.setString(2, lctype);
		_pstmt.setInt(3, lcyear);
		_pstmt.setInt(4, lcsl);
		if (mod.equals("M")) {
		_pstmt.setInt(5, amdSl);
		} else if (mod.equals("A")) {
		if (amdSl > 1) {
		amdSl = amdSl - 1;
		}
		_pstmt.setInt(5, amdSl);
		}
		_pstmt.setString(6, amdFor);
		ResultSet rs1 = ExecuteQuery();
		while (rs1.next()) {
		rcount=rcount+1;
		if(rcount==0){
		newtext=rs1.getString("VALUE");

		}
		else{
		newtext=oldtext+"/"+rs1.getString("VALUE");
		}
		Resultobj.setValue(ResultKey, RowPresent);
		oldtext = newtext;
		}
		}

		Resultobj.setValue("OLCAT_TEXT",newtext);

		//CHANGED ADDED ON 25/07/2018 END

		} catch (Exception e) {
		Resultobj.setValue(ErrorKey, "Error in loadSpl1LogInModify");
		}
		return Resultobj.copyofDTO();
		}

	public DTObject LoadClientDetails(DTObject InputoBj) {
		try {

			int clientNum = 0;
			String custname = "";
			String bankname = "";
			String branchname = "";
			String countryname = "";
			String custadd1 = "";
			String custadd2 = "";
			String custadd3 = "";
			String custadd4 = "";
			String custadd5 = "";
			clientNum = Integer.parseInt(InputoBj.getValue("CLIENT_NUM").trim().toString());

			if (Check_Result_Status()) {
				ClientValidator clieval = new ClientValidator();
				dtobj.clearMap();
				dtobj.setValue("CLIENTS_CODE", String.valueOf(clientNum));
				dtobj.setValue(FetchReq, "true");
				Resultobj = clieval.clientValid(dtobj);
				custname = Resultobj.getValue("CLIENTS_NAME");
				custadd1 = Resultobj.getValue("CLIENTS_ADDR1");
				custadd2 = Resultobj.getValue("CLIENTS_ADDR2");
				custadd3 = Resultobj.getValue("CLIENTS_ADDR3");
				custadd4 = Resultobj.getValue("CLIENTS_ADDR4");
				custadd5 = Resultobj.getValue("CLIENTS_ADDR5");
			}

		} catch (Exception e) {
			Resultobj.setValue(ErrorKey, "Error in LoadClientDetails");
		}
		return Resultobj.copyofDTO();
	}

	//added by prashanth

}

//*********************************************************************************************************

