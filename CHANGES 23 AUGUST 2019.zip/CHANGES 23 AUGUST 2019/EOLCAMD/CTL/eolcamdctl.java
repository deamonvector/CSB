package panaceaOLCweb.OLCCtlbean;

import panacea.com.component.TFMChargesDetails;
import panacea.com.component.TranStlmntPostDetails;
import panacea.common.DTObject;
import panacea.common.DateUtility;
import panacea.common.GetGridDisplay;
import panacea.common.JNDINames;
import panacea.common.PanaceaException;
import panaceaweb.utility.gridXML;
import panacea.delegate.CommonDelegate;
import panaceaweb.utility.Common;
import panaceaweb.utility.QueryManager;
import panacea.OLCaction.*;
import sun.security.action.GetBooleanAction;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet; //import java.util.Scanner;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.sql.CallableStatement;

public class eolcamdctl extends Common

{

	// ADDED BY PRASHANTH ON 06 FEB 2019

	private String txtAmdLogHidden = "";

	String[] applicant_add = null;
	String[] availbl_with_add = null;
	String[] drawee_add = null;
	String[] reimb_add = null;
	String[] instr_paying = null;

	private String amdlogtemp1 = "";
	private String amdlogtemp2 = "";
	private String amdlogtemp3 = "";
	private String amdlogtemp4 = "";
	private String amdlogtemp5 = "";

	private String amdGoodsValue = "";
	private String amdDocsValue = "";
	private String amdAddlValue = "";
	private String amdSpl1Value = "";
	private String amdSpl2Value = "";

	private String txtChoiceSl = "";
	private String txtfrmRange = "";
	private String uptoRange = "";
	private String txtApplInsOrRepl = "";
	private String txtAmdLog = "";
	private String txtcompAmdDetails = "";

	private String txtChoiceSlDoc = "";
	private String txtfrmRangeDoc = "";
	private String uptoRangeDoc = "";
	private String txtApplInsOrReplDoc = "";
	private String txtAmdLogDoc = "";
	private String txtcompAmdDetailsDoc = "";

	private String txtChoiceSlAddl = "";
	private String txtfrmRangeAddl = "";
	private String uptoRangeAddl = "";
	private String txtApplInsOrReplAddl = "";
	private String txtAmdLogAddl = "";
	private String txtcompAmdDetailsAddl = "";

	private String txtChoiceSlSplBene = "";
	private String txtfrmRangeSplBene = "";
	private String uptoRangeSplBene = "";
	private String txtApplInsOrReplSplBene = "";
	private String txtAmdLogSplBene = "";
	private String txtcompAmdDetailsSplBene = "";

	private String txtChoiceSlSplRecev = "";
	private String txtfrmRangeSplRecev = "";
	private String uptoRangeSplRecev = "";
	private String txtApplInsOrReplSplRecev = "";
	private String txtAmdLogSplRecev = "";
	private String txtcompAmdDetailsSplRecev = "";

	String[] bank_addr = null;
	String[] drafts = null;
	String[] def_pay_details = null;
	String[] mixed_pay_details = null;
	String[] second_adv_add = null;

	private boolean chkReqForCancel = false;
	private boolean chkChgAppl = false;
	private String LC_FORM_OF_DOC_CREDIT = "";
	private String txtApplCode = "";
	private String txtApplName = "";
	private String txtApplAddress = "";
	private String LC_APPLICABLE_RULES = "";

	private boolean chkChgAvlWith = false;
	private boolean chkCgDrawee = false;
	private boolean chkChgPresDays = false;
	private boolean chkChgReimbus = false;
	private boolean chkCgAdvBk = false;

	private boolean chkChgFormDc = false;
	private boolean chkChgApplRules = false;

	private String LC_AVAILABLE_WITH_CODETYP = "";
	private String LC_AVAILABLE_WITH_TYPE = "";
	private String LC_AVAILABLE_WITH_BIC_CODE = "";
	private String LC_AVAILABLE_WITH_BRN_CODE = "";
	private String LC_AVAILABLE_WITH_ROUTID = "";
	private String LC_AVAILABLE_WITH_BNK_CODE = "";
	private String LC_AVAILABLE_WITH_ADDRESS = "";
	private String LC_AVAILABLE_WITH_CNTRY = "";
	private String LC_DRAFTS_AT = "";

	private boolean LC_DRAWEE_REQ = false;

	private String LC_DRAWEE_TYPE = "";
	private String LC_DRAWEE_BIC_CODE = "";
	private String LC_DRAWEE_BRN_CODE = "";
	private String LC_DRAWEE_ROUTID = "";
	private String LC_DRAWEE_BNK_CODE = "";
	private String LC_DRAWEE_ADDRESS = "";
	private String LC_DRAWEE_CNTRY_CODE = "";
	private String LC_MIXED_PAY_DETAILS = "";
	private String LC_DEFERRED_PAY_DETAILS = "";
	private String LC_PARTIAL_SHIPMENTS = "";
	private String LC_TRANSHIPMENT = "";

	private String LC_CONFIRMATION_INST = "";
	//Changes Sanjay1 18-07-2019 Begin
	//private String olcLcToBeCnfrmdByBk = "";
	//private String olcLcToBeCnfrmdByBrn = "";
	//private String olcLcToBeCnfrmdByBrnName = "";
	String[] reimb_cfm_add = null;
	private String LC_REIMB_CFM_TYPE = "";
	private String LC_REIMB_CFM_BIC_CODE = "";
	private String LC_REIMB_CFM_BRN_CODE = "";
	private String LC_CFM_REIMB_ROUTID = "";
	private String LC_CFM_REIMB_BNK_CODE = "";
	private String LC_CFM_REIMB_ADDRESS = "";
	private String LC_CFM_REIMB_CNTRY_CODE = "";
	private String changeinapplicablerules = "";
	private String changeinavailablewith = "";
	private String changeindrawee = "";
	private String changeinreimbursement = "";
	private String changeinadvisingbank = "";
	//Changes Sanjay1 18-07-2019 End
	private boolean LC_REIMB_REQ = false;
	private String LC_REIMB_TYPE = "";
	private String LC_REIMB_BIC_CODE = "";
	private String LC_REIMB_BRN_CODE = "";
	private String LC_REIMB_ROUTID = "";
	private String LC_REIMB_BNK_CODE = "";
	private String LC_REIMB_ADDRESS = "";
	private String LC_REIMB_CNTRY_CODE = "";
	private String LC_INST_PAYING = "";

	private boolean LC_SECOND_ADV_REQ = false;
	private String LC_SECOND_ADV_TYPE = "";
	private String LC_SECOND_ADV_BIC_CODE = "";
	private String LC_SECOND_ADV_BRN_CODE = "";
	private String LC_SECOND_ADV_ROUTID = "";
	private String LC_SECOND_ADV_BNK_CODE = "";
	private String LC_SECOND_ADV_ADDRESS = "";
	private String LC_SECOND_ADV_CNTRYCODE = "";
	private String LC_SNDR_REC_INFO = "";
	private String LC_REC_BIC_CODE = "";

	private String olcamdchgspayby = "";
	private String txtperiodOfPres = "";

	private boolean chkChgDesc = false;
	private boolean chkChgDoc = false;
	private boolean chkChgAddCond = false;
	//Changes Sanjay 02-07-2019 Begin
	private String oldchkChgDesc = "";
	private String oldchkChgDoc = "";
	private String oldchkChgAddCond = "";
	//Changes Sanjay 02-07-2019 End
	private String txtCustomerNumber = "";

	private String LC_DESC_GOODS_SER1 = "";
	private String LC_DESC_GOODS_SER2 = "";
	private String LC_DESC_GOODS_SER3 = "";

	private String LC_DOC_REQ1 = "";
	private String LC_DOC_REQ2 = "";
	private String LC_DOC_REQ3 = "";

	private String LC_ADD_CONDITION1 = "";
	private String LC_ADD_CONDITION2 = "";
	private String LC_ADD_CONDITION3 = "";

	// ADDED BY PRASHANTH ON 06 FEB 2019
	private String museroption = null;
	private String mbranchcode = null;
	private String mrefertype = null;
	private String mreferyear = null;
	private String mrefersl = null;
	private String mamdsl = null;
	private String mamdentrydate = null;
	private String mcustletternum = null;
	private String mcustletterdate = null;
	// private String mreasonforamd = null;
	private boolean mchangeofbenef = false;
	private String mbenefcode = null;
	private String mbenefname = null;
	private String mbenefaddr = null;
	private String mbenefcountrycode = null;
	private String menanchementreduction = null;
	private String menanchementreductionAmt = null;
	private String mlccurr = null;
	private String lcAmt = null;
	private String mamdamt = null;
	private String mpostdevi = null;
	private String mnegdevi = null;
	private String mdeviamt = null;
	private String mamtqualifier = null;
	private String mtermsofprice = null;
	private String mlasetdateofneg = null;
	private String mplaceofexpiry = null;
	private String mlatestdateforship = null;
	private String mshipperiodschedule = null;
	private String mpresentationdetails = null;
	private boolean mwithinvalidityoflc = false;
	private boolean musanceintborne = false;
	private String mdrawdowns = null;
	private String mtotaltenorcurr = null;
	private String mtotaltenoramt = null;
	private String maddliablccurr = null;
	private String mconvratebasecurr = null;
	private String maddliabbasecurr = null;
	private String mconvratelimcurr = null;
	private String mtotliablimcurr = null;
	private String mtranchgschgssl = null;
	private String mtranstlmntinvnum = null;
	private String mtxnstatus = "";
	private String merrmsg = "";
	private String maddamtcovered = null;
	private String mlcdate = null;
	private String mlimitcurr = null;
	private String mchangeinlcliabinbasecurrfield = null;
	private String mchangeinlcliabinbasecurr = null;
	private String mreductioninlcliabinbasecurr = null;
	private String mxmlstring = null;
	private String mlcamount = null;
	private String merrxmlstr1 = null;

	private String mbaltenoramt = null;
	private String mbalusanceintamt = null;

	private String mtotalbefamd = null;
	private String mtotalaftamd = null;

	private String mtotalliabbasecurr = null;

	private TFMChargesDetails tfmchargesdetail;
	private TranStlmntPostDetails translmnt;

	// Local Variables
	private String _tnomenNumChoice = null;
	private String _tenomen_auto_num = null;
	private String molcaentrydate = null;
	private String _olca_entry_date = null;// get this in Mod mode and use this
	// for the updation of OLCLED
	private int val = 0;
	private int val2 = 0;
	private String mdeviationbal;
	// Procedure Local Variables
	private String mprevenhancereductionchk;
	private String mprevenhancereductionamt;
	private String mprevgridtenoramt;
	private String mtotalgridliabamt;
	private String xml_str;
	String xmlstr = "";
	String[] prev_tenor_amt = null;
	String[] total_Liab_amt = null;
	String[] test = null;

	// ADD CONDITION

	DTObject revalDTO = new DTObject();

	private String maddtranchgs = "";
	private String maddtranstlmntinvnum = "";
	private DTObject DTOResult;
	gridXML revallcpsGrid1 = new gridXML();
	private DTObject inputDTO = new DTObject();
	private DTObject outputDTO = new DTObject();
	QueryManager QueryManagerInstance = new QueryManager();
	eolcamdval eolcamdvalinstance = new eolcamdval();
	// vouchers value
	private String postbrn;
	private String postdate;
	private String postbatchnum;
	private String mcurrrefnum = null;
	private String baseCurr;
	private String minternalaccnum;
	private String mtotalamt = null;
	private String batchnum = "";

	// Changes P.Subramani-Chn-12/04/2008 Beg
	private String olcusnchgs = "";
	private String olcusnchgstakendays = "";
	private String olccommchgs = "";
	private String olccommchgstakendays = "";
	// Changes P.Subramani-Chn-12/04/2008 End

	// Changes P.Subramani-Chn-23-06-2008 Beg
	private String usancechgcode = "";
	private String commchgcode = "";
	// Changes P.Subramani-Chn-23-06-2008 End

	// Changes P.Subramani-Chn-19-08-2008 Beg
	private String olcatotalliablccurrency = "";
	private String olcatotalliabbasecurrency = "";
	// Changes P.Subramani-Chn-19-08-2008 End

	// Changes P.Subramani-Chn-26-08-2008 Beg
	private String prevdevamt = "";
	// Changes P.Subramani-Chn-26-08-2008 End

	// Changes P.Subramani-Chn-21/10/2008 Beg
	private String olcMarginCurr = "";
	private String olcmarginamt = "";
	private String olcmarginbal = "";
	private String olccashmaramt = "";
	private String olccashmarbal = "";
	private String totalmarginamt = "";
	private String totalcashmarginamt = "";
	private double olcmarginamt1 = 0;
	private double olccashmarginamt1 = 0;
	private double olccashmarbal1 = 0;
	private double marginbal = 0;
	private double olcmarginbal1 = 0;
	// Changes P.Subramani-Chn-21/10/2008 End

	// Changes P.Subramani-Chn-22/10/2008 Beg
	private String marginper = "";
	private String eolmarginper = "";
	private String marginamt = "";
	private String eolmarginamt = "";
	private String cashmarginamt = "";
	private String eolcashmarginamt = "";
	private String margintype = "";
	private String excessoverlimitcurrtran = "";
	private String prevmarginamt = "";
	private String prevexcmarginamt = "";
	private String prevcashmarginamt = "";
	private String prevexccashmarginamt = "";
	private double prevtotalmarginamt = 0;
	private double prevtotalcashmarginamt = 0;
	private double prevmarginbal = 0;
	private double prevcashmarbal = 0;
	// Changes P.Subramani-Chn-22/10/2008 End
	// M.Murali - Added - 16-05-2012 - Beg
	private String mredliabbasecurr = null;
	// M.Murali - Added - 16-05-2012 - End

	// Changes P.Subramani-Chn-26/03/2009
	private String zeroval = "0";
	private String _brnAuth = "";// CHANGED ADDED ON 25/07/2018
	private String _lcTypeAuth = "";// CHANGED ADDED ON 25/07/2018
	// Changes in EOLCAMD on 16-Oct-2018 start

	private String AMEND_SNDR_REF = "";
	private String AMEND_RCVR_REF = "";
	private String AMEND_DOC_CR_NUM = "";
	private boolean AMEND_ISSUING_BNK_REQ = false;
	private String AMEND_ISSUING_TYPE = "";
	private String AMEND_ISSUING_BRN_CODE = "";
	private String AMEND_ISSUING_BIC_CODE = "";
	private String AMEND_ISSUING_ROUTID = "";
	private String AMEND_ISSUING_BNK_CODE = "";
	private String AMEND_ISSUING_ADDR = "";
	private String AMEND_ISSUING_CNTRY = "";
	private String AMEND_NON_BNK_ISSUR = "";
	private String AMEND_DATE_OF_ISSUE = "";
	private String AMEND_DATE_OF_AMENDMENT = "";
	private String AMEND_PURPOSE_OF_MSG = "";
	private String AMEND_CANCEL_REQUEST = "";
	private boolean AMEND_ADVISING_BNK_REQ = false;
	private String AMEND_ADVISING_BNK_TYPE = "";
	private String AMEND_ADVISING_BRN_CODE = "";
	private String AMEND_ADVISING_BIC_CODE = "";
	private String AMEND_ADVISING_BNK_CODE = "";
	private String AMEND_ADVISING_ROUTID = "";
	private String AMEND_ADVISING_ADDR = "";
	private boolean AMEND_SECOND_ADV_REQ = false;
	private String AMEND_SECOND_ADV_TYPE = "";
	private String AMEND_SECOND_ADV_BRN_CODE = "";
	private String AMEND_SECOND_ADV_BIC_CODE = "";
	private String AMEND_SECOND_ADV_ROUTID = "";
	private String AMEND_SECOND_ADV_BNK_CODE = "";
	private String AMEND_SECOND_ADV_ADDR = "";
	private String AMEND_NEW_BENEFICIARY = "";
	private String AMEND_NEW_DATE_OF_EXPIRY = "";
	private String AMEND_INCR_DOC_CR_AMT = "";
	private String AMEND_DECR_DOC_CR_AMT = "";
	private String AMEND_NEW_ADDNL_AMT = "";
	private String AMEND_PLACE_TAKIN_IN_CHRG = "";
	private String AMEND_PORT_OF_LOADING = "";
	private String AMEND_PORT_OF_DISCHARGE = "";
	private String AMEND_PLACE_OF_FINAL_DEST = "";
	private String AMEND_DATE_OF_SHIPMENT = "";
	private String AMEND_DESC_GODD_SER1 = "";
	private String AMEND_DOC_REQ1 = "";
	private String AMEND_ADD_CONDITION1 = "";
	private String AMEND_CHRG_PAYABLE = "";
	private String AMEND_NEW_PRD_PRESNT_DAY = "";
	private String AMEND_NEW_CONFIRM_INSTR = "";
	private String AMEND_SPL_PAY_BENFICIARY = "";
	private String AMEND_SPL_PAY_REC_BNK = "";
	private String AMEND_INSTR_TOPAYING = "";
	private String AMEND_SNDR_REC_INFO = "";
	//Changes Sanjay1 18-07-2019 Begin
	//private String AMEND_NARRATIVE = "";
	//Changes Sanjay1 18-07-2019 End
	private String AMEND_CHKBOX = "";
	private boolean AMEND_ENQUIRY_REQ = false;
	private boolean AMEND_DC_REQ = false;
	private boolean AMEND_TOLERANCE_REQ = false;
	private boolean AMEND_PLACE_REQ = false;
	private boolean AMEND_SHIPMNT_REQ = false;
	private String AMEND_ISSUE_REF = "";
	private String temp_str = "";

	String[] send_to_rec = null;
	String[] issuing_bank = null;
	String[] _desp = null;
	String[] chgs = null;
	String a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12;
	int shipmnt_chkbx = 0;
	int place_chkbx = 0;
	int enquiry_chkbox = 0;
	int dc_chkbox = 0;
	int tolerance_chkbox = 0;
	int chkbox1 = 0;
	int chkbox2 = 0;
	int chkbox3 = 0;
	int chkbox4 = 0;
	int chkbox5 = 0;
	int chkbox6 = 0;
	String olcrefnum = "";
	String receiver_bic = "";
	String place_tkn_chrg = "";
	String port_of_loading = "";
	String port_of_dischrg = "";
	String place_finl_detination = "";

	// Changes in EOLCAMD on 16-Oct-2018 end

	// 1.0 Optimization Changes 08-Feb-2008 - Beg
	public void setreturnvalue() {
		// Changes P.Subramani-19/08/2008 Beg
		sethiddenidValues("mxmlstr1#errxmlstr1#txttotalliabbasecurr#PrevGridTenorAmt#TotalGridLiabAmt#chkPrevEnhanceReduction#txtPrevEnhaceeReductionAmt#txtBalTenorAmt#txtBalUsanceAmt#txtDeviationBalance#txtaddtranchgs#txtaddtranstlmntinvnum#txtolcaentrydate#txtlcamounthidden#txtInternalAccountNum#totalAmount1#txtusnchgstakendays#txtcommchgstakendays#totalliablccurrency#totalliabbasecurrency#txtprevDeviationAmount#prevmarginamt#prevexcmarginamt#prevcashmarginamt#prevexccashmarginamt", getMxmlstring() + "#" + getMerrxmlstr1() + "#" + getMtotalliabbasecurr() + "#" + getMprevgridtenoramt() + "#" + getMtotalgridliabamt() + "#" + getMprevenhancereductionchk() + "#" + getMprevenhancereductionamt() + "#" + getMbaltenoramt() + "#" + getMbalusanceintamt() + "#"
				+ getMdeviationbal() + "#" + getMaddtranchgs() + "#" + getMaddtranstlmntinvnum() + "#" + getMolcaentrydate() + "#" + getMlcamount() + "#" + getMinternalaccnum() + "#" + getMtotalamt() + "#" + getOlcusnchgstakendays() + "#" + getOlccommchgstakendays() + "#" + getOlcatotalliablccurrency() + "#" + getOlcatotalliabbasecurrency() + "#" + getPrevdevamt() + "#" + getPrevmarginamt() + "#" + getPrevexcmarginamt() + "#" + getPrevcashmarginamt() + "#" + getPrevexccashmarginamt());
		// Changes P.Subramani-19/08/2008 End
		setV_view_component_Id("txnstatus#errmsg#txtbatchnum");
		setcommonvalues(getMtxnstatus(), getMerrmsg(), getBatchnum());
	}

	// 1.0 Optimization Changes 08-Feb-2008 - End

	public String PersistData() {
		String[] Remarks = null;
		String[] AddAmtCov = null;
		String[] SH = null;
		String[] PD = null;
		// Procedure

		if (Revalidate() == true) {
			System.out.println("inner PersistData1");
			CommonDelegate CDelagate = null;
			DTObject currDTO = new DTObject();
			currDTO.clearMap();

			// ADDED BY PRASHANTH
			currDTO.setValue("CUST_CODE", txtCustomerNumber);

			if (chkChgDesc == true) {
				currDTO.setValue("OLCA_CHG_IN_DESC_GOODS", "1");
			} else {
				currDTO.setValue("OLCA_CHG_IN_DESC_GOODS", "0");
			}
			if (chkChgDoc == true) {
				currDTO.setValue("OLCA_CHG_IN_DOC", "1");
			} else {
				currDTO.setValue("OLCA_CHG_IN_DOC", "0");
			}
			if (chkChgAddCond == true) {
				currDTO.setValue("OLCA_CHG_IN_ADDL_COND", "1");
			} else {
				currDTO.setValue("OLCA_CHG_IN_ADDL_COND", "0");
			}

			currDTO.setValue("OLCA_BRN_CODE", mbranchcode);
			currDTO.setValue("OLCA_LC_TYPE", mrefertype);
			currDTO.setValue("OLCA_LC_YEAR", mreferyear);
			currDTO.setValue("OLCA_LC_SL", mrefersl);
			currDTO.setValue("OLCA_AMD_SL", mamdsl);
			currDTO.setValue("OLCA_ENTRY_DATE", mamdentrydate);
			currDTO.setValue("OLCA_CUST_LETTER_NUM", mcustletternum);
			if (mcustletterdate.equalsIgnoreCase("")) {
				currDTO.setValue("OLCA_CUST_LTR_DATE", null);
			} else {
				currDTO.setValue("OLCA_CUST_LTR_DATE", mcustletterdate);
			}

			currDTO.setValue("OLCA_RSN_FOR_AMD", "");// Changes in EOLCAMD on
			// 17-Oct-2018
			if (mchangeofbenef == true) {
				currDTO.setValue("OLCA_CHANGE_OF_BENEF", String.valueOf("1"));
			} else {
				currDTO.setValue("OLCA_CHANGE_OF_BENEF", String.valueOf("0"));
			}
			currDTO.setValue("OLCA_BENEF_CODE", mbenefcode);
			currDTO.setValue("OLCA_BENEF_NAME", mbenefname);
			Remarks = mbenefaddr.split("\n");
			currDTO.setValue("OLCA_BENEF_ADDR1", Remarks[0].trim());
			currDTO.setValue("OLCA_BENEF_ADDR2", ((Remarks.length > 1) ? Remarks[1].trim() : " "));
			currDTO.setValue("OLCA_BENEF_ADDR3", ((Remarks.length > 2) ? Remarks[2].trim() : " "));
			currDTO.setValue("OLCA_BENEF_ADDR4", ((Remarks.length > 3) ? Remarks[3].trim() : " "));
			currDTO.setValue("OLCA_BENEF_ADDR5", ((Remarks.length > 4) ? Remarks[4].trim() : " "));
			currDTO.setValue("OLCA_BENEF_CNTRY_CODE", mbenefcountrycode);
			currDTO.setValue("OLCA_ENHANCEMNT_REDUCN", menanchementreduction);
			currDTO.setValue("OLCA_LC_CURR_CODE", mlccurr);
			currDTO.setValue("OLCA_AMENDED_AMT", mamdamt);
			currDTO.setValue("OLCA_POS_DEV_ALLWD", mpostdevi);
			currDTO.setValue("OLCA_NEG_DEV_ALLWD", mnegdevi);
			currDTO.setValue("OLCA_DEV_AMT", mdeviamt);
			currDTO.setValue("OLCA_AMT_QUALFR", mamtqualifier);
			// currDTO.setValue("CUSTOMERNUMBER",maddamtcovered);
			currDTO.setValue("OLCA_PRICE_TERMS", mtermsofprice);
			currDTO.setValue("OLCA_LAST_DATE_OF_NEG", mlasetdateofneg);
			currDTO.setValue("OLCA_PLACE_OF_EXPIRY", mplaceofexpiry);
			if (mlatestdateforship.equalsIgnoreCase("")) {
				currDTO.setValue("OLCA_LATEST_DATE_OF_SHPMNT", null);
			} else {
				currDTO.setValue("OLCA_LATEST_DATE_OF_SHPMNT", mlatestdateforship);
			}
			if (mwithinvalidityoflc == true) {
				currDTO.setValue("OLCA_WITHIN_VALIDATE_LC", String.valueOf("1"));
			} else {
				currDTO.setValue("OLCA_WITHIN_VALIDATE_LC", String.valueOf("0"));
			}
			if (musanceintborne == true) {
				currDTO.setValue("OLCA_LC_UI_BORNE_BY_APPLCNT", String.valueOf("1"));
			} else {
				currDTO.setValue("OLCA_LC_UI_BORNE_BY_APPLCNT", String.valueOf("0"));
			}
			currDTO.setValue("OLCA_NOF_TENORS", mdrawdowns);
			currDTO.setValue("OLCA_ADD_LIAB_LC_CURR", maddliablccurr);
			currDTO.setValue("OLCA_CONV_RATE_BASE_CURR", mconvratebasecurr);

			// Changes P.Subramani-Chn-02/04/2008 Beg
			if (maddliabbasecurr.equalsIgnoreCase("0.00")) {
				currDTO.setValue("OLCA_ADD_LIAB_BASE_CURR", "0");
			} else {
				currDTO.setValue("OLCA_ADD_LIAB_BASE_CURR", maddliabbasecurr);
			}
			currDTO.setValue("OLCA_CONV_RATE_LIM_CURR", mconvratelimcurr);
			if (mconvratelimcurr.equalsIgnoreCase("0.000")) {
				currDTO.setValue("OLCA_TOT_LIAB_LIM_CURR", "0");
			} else {
				currDTO.setValue("OLCA_TOT_LIAB_LIM_CURR", mtotliablimcurr);
			}
			if (mreductioninlcliabinbasecurr.equalsIgnoreCase("0.00")) {
				currDTO.setValue("RED_LCLIAB_BASE_AMT", "0");
			} else {
				currDTO.setValue("RED_LCLIAB_BASE_AMT", mreductioninlcliabinbasecurr);
			}
			// Changes P.Subramani-Chn-02/04/2008 End

			// currDTO.setValue("IRCR_VOSTRO_ACC_NUM",mtranstlmntinvnum);//settlement
			// comp

			// Changes P.Subramani-Chn-12/04/2008 Beg
			if (olcusnchgs.equalsIgnoreCase("")) {
				currDTO.setValue("USANCE_CHARGES", "0");
			} else {
				currDTO.setValue("USANCE_CHARGES", olcusnchgs);
			}
			if (olcusnchgstakendays.equalsIgnoreCase("")) {
				currDTO.setValue("OLCA_USN_CHG_TAKEN_DAYS", "0");
			} else {
				currDTO.setValue("OLCA_USN_CHG_TAKEN_DAYS", olcusnchgstakendays);
			}
			if (olccommchgs.equalsIgnoreCase("")) {
				currDTO.setValue("COMMITMENT_CHARGES", "0");
			} else {
				currDTO.setValue("COMMITMENT_CHARGES", olccommchgs);
			}
			if (olccommchgstakendays.equalsIgnoreCase("")) {
				currDTO.setValue("OLCA_COMMIT_CHG_TAKEN_DAYS", "0");
			} else {
				currDTO.setValue("OLCA_COMMIT_CHG_TAKEN_DAYS", olccommchgstakendays);
			}

			//Changes Sanjay 02-07-2019 Begin
			currDTO.setValue("OLCA_AMD_CHG_PAY_BY", olcamdchgspayby);
			currDTO.setValue("OLCA_PER_OF_PRES_DAYS", txtperiodOfPres);
			//Changes Sanjay 02-07-2019 End
			
			
			// Changes P.Subramani-Chn-12/04/2008 End

			// Changes P.Subramani-Chn-23-06-2008 Beg
			currDTO.setValue("TRCHG_USANCE_CHGCD", usancechgcode);
			currDTO.setValue("TRCHG_COMMITMNT_CHGCD", commchgcode);
			// Changes P.Subramani-Chn-23-06-2008 End

			// Changes P.Subramani-Chn-19-08-2008 Beg
			// SUGANYA BEGIN 20-SEP-2016
			if ((olcatotalliablccurrency.equalsIgnoreCase("0.00")) || (olcatotalliablccurrency.equalsIgnoreCase(""))) {
				currDTO.setValue("OLCA_TOT_LIAB_LC_CURR", "0");
			} else {
				currDTO.setValue("OLCA_TOT_LIAB_LC_CURR", olcatotalliablccurrency);
			}

			if ((olcatotalliabbasecurrency.equalsIgnoreCase("0.00")) || (olcatotalliabbasecurrency.equalsIgnoreCase(""))) {
				currDTO.setValue("OLCA_TOT_LIAB_BASE_CURR", "0");
			} else {
				currDTO.setValue("OLCA_TOT_LIAB_BASE_CURR", olcatotalliabbasecurrency);
			}

			// SUGANYA END 20-SEP-2016
			// Changes P.Subramani-Chn-19-08-2008 End

			// Changes P.Subramani-Chn-26-08-2008 Beg
			currDTO.setValue("PREV_DEV_AMT", prevdevamt);
			// Changes P.Subramani-Chn-26-08-2008 End

			// Components-Starts
			if (museroption.equalsIgnoreCase("A")) {
				if (mamdsl.equalsIgnoreCase("1")) {
					mtranchgschgssl = "0";
					currDTO.setValue("TRANCHGS_CHGS_SL", mtranchgschgssl);
				} else {
					currDTO.setValue("TRANCHGS_CHGS_SL", mtranchgschgssl);
				}
			} else {
				currDTO.setValue("TRANCHGS_CHGS_SL", mtranchgschgssl);
			}
			if (museroption.equalsIgnoreCase("A")) {
				if (mamdsl.equalsIgnoreCase("1")) {
					mtranstlmntinvnum = "0";
					currDTO.setValue("TRANSTLMNT_INV_NUM", mtranstlmntinvnum);
				} else {
					currDTO.setValue("TRANSTLMNT_INV_NUM", mtranstlmntinvnum);
				}
			} else {
				currDTO.setValue("TRANSTLMNT_INV_NUM", mtranstlmntinvnum);
			}
			if (tfmchargesdetail != null) {
				currDTO = tfmchargesdetail.getDTObject(currDTO);
			}
			// M.Murali - Changes - 18-05-2012 - Beg
			// if(!(tfmchargesdetail.getTRANCHGS_TOTAL_CHGS().equalsIgnoreCase("0.00"))
			// ||
			// !(tfmchargesdetail.getTRANCHGS_TOTAL_CHGS().equalsIgnoreCase("0")))
			if (!(tfmchargesdetail.getTRANCHGS_TOTAL_CHGS().equalsIgnoreCase("0.00")) || !(tfmchargesdetail.getTRANCHGS_TOTAL_CHGS().equalsIgnoreCase("0")) || !(olcusnchgs.equalsIgnoreCase("0")) || !(olccommchgs.equalsIgnoreCase("0")))
			// M.Murali - Changes - 18-05-2012 - End
			{
				if (translmnt != null) {
					currDTO = translmnt.getDTObject(currDTO);
				}
			}
			// Components Ends
			// OLCAMD-Ends
			// OLCTENORSAMD-starts

			// Grid Values Start--
			try {
				// Changes P.Subramani-Chn-22/08/2008 BEg
				currDTO.addColumn("valeolcamdOLCTENORS", 0, "OLCTA_TENOR_TYPE");
				currDTO.addColumn("valeolcamdOLCTENORS", 1, "OLCTA_PREV_TENOR_AMT");
				currDTO.addColumn("valeolcamdOLCTENORS", 2, "OLCTA_TENOR_AMT");
				currDTO.addColumn("valeolcamdOLCTENORS", 3, "OLCTA_USANCE_PERD");
				currDTO.addColumn("valeolcamdOLCTENORS", 4, "OLCTA_USANCE_FROM");
				currDTO.addColumn("valeolcamdOLCTENORS", 5, "OLCTA_OTHER_DATE_DESC");
				currDTO.addColumn("valeolcamdOLCTENORS", 6, "OLCTA_OTHER_DATE_START_FROM");
				currDTO.addColumn("valeolcamdOLCTENORS", 7, "OLCTA_USANCE_INT_RATE");
				currDTO.addColumn("valeolcamdOLCTENORS", 8, "OLCTA_PREV_USANCE_INT");
				currDTO.addColumn("valeolcamdOLCTENORS", 9, "OLCTA_USANCE_INT_AMT");
				currDTO.addColumn("valeolcamdOLCTENORS", 10, "OLCTA_DOC_DELIVERY");
				currDTO.addColumn("valeolcamdOLCTENORS", 11, "PREV_ENHANC_REDUCT_AMT");
				// Changes P.Subramani-Chn25/08/2008 BEg
				currDTO.addColumn("valeolcamdOLCTENORS", 12, "OLCTA_USN_CHRG_TAKEN_DAYS");
				// Changes P.Subramani-Chn25/08/2008 End
				currDTO.setXMLDTDObject("valeolcamdOLCTENORS", mxmlstring);
				// Changes P.Subramani-Chn-22/08/2008 End
			}

			catch (Exception e1) {
				e1.printStackTrace();
			}

			// Grid Values Ends
			// OLCTENORSAMD-ends

			// OLCOTEXT - Starts
			AddAmtCov = maddamtcovered.split("\n");
			currDTO.setValue("OLCOTX_TXN_TYPE", "A");
			currDTO.setValue("OLCOTX_TXN_SL", mamdsl);
			currDTO.setValue("OLCOTX_ADDTNL_AMT_CVRD1", AddAmtCov[0].trim());
			currDTO.setValue("OLCOTX_ADDTNL_AMT_CVRD2", ((AddAmtCov.length > 1) ? AddAmtCov[1].trim() : " "));
			currDTO.setValue("OLCOTX_ADDTNL_AMT_CVRD3", ((AddAmtCov.length > 2) ? AddAmtCov[2].trim() : " "));
			currDTO.setValue("OLCOTX_ADDTNL_AMT_CVRD4", ((AddAmtCov.length > 3) ? AddAmtCov[3].trim() : " "));

			// OLCOTEXT - Ends

			// OLCSHIPTEXT- Starts-Part-1
			SH = mshipperiodschedule.split("\n");
			currDTO.setValue("OLCST_TEXT11", SH[0].trim());
			currDTO.setValue("OLCST_TEXT21", ((SH.length > 1) ? SH[1].trim() : " "));
			currDTO.setValue("OLCST_TEXT31", ((SH.length > 2) ? SH[2].trim() : " "));
			currDTO.setValue("OLCST_TEXT41", ((SH.length > 3) ? SH[3].trim() : " "));

			// OLCSHIPTEXT-Ends

			// OLCSHIPTEXT- Starts-Part-2
			PD = mpresentationdetails.split("\n");
			currDTO.setValue("OLCST_TEXT12", PD[0].trim());
			currDTO.setValue("OLCST_TEXT22", ((PD.length > 1) ? PD[1].trim() : " "));
			currDTO.setValue("OLCST_TEXT32", ((PD.length > 2) ? PD[2].trim() : " "));
			currDTO.setValue("OLCST_TEXT42", ((PD.length > 3) ? PD[3].trim() : " "));

			// OLCSHIPTEXT-Ends

			// OLCLED - Starts part-1
			currDTO.setValue("OLCA_ENTRY_DATE_SQL", _olca_entry_date);
			currDTO.setValue("OLCLD_TXN_DATE", mamdentrydate);
			currDTO.setValue("OLCLD_RED_ENH", menanchementreduction);
			currDTO.setValue("OLCLD_TXN_AMT", menanchementreductionAmt);

			// OLCLED - Ends

			// OLCLED - Starts part-2

			if ((museroption.equalsIgnoreCase("M")) && (!(DateUtility.DateEqual(_olca_entry_date, mamdentrydate))))

			{
				currDTO.setValue("OLCLD_TXN_DATE", _olca_entry_date);
				currDTO.setValue("OLCLD_TXN_AMT", menanchementreductionAmt);
			}

			// OLCLED - Ends

			// Procedures Variables - Starts
			if (museroption.equalsIgnoreCase("M")) {
				currDTO.setValue("PREV_RED_FLAG", mprevenhancereductionchk);
				currDTO.setValue("PREV_RED_AMT", mprevenhancereductionamt);
			}
			currDTO.setValue("PREV_GRID_TENOR_AMT", mprevgridtenoramt);
			currDTO.setValue("PREV_GRID_LIAB_AMT", mtotalgridliabamt);

			currDTO.setValue("OLCT_BAL_TENOR_AMT", mbaltenoramt);
			currDTO.setValue("OLCT_BAL_USANCE_INT_AMT", mbalusanceintamt);
			currDTO.setValue("OLC_DEV_BAL", mdeviationbal);
			currDTO.setValue("OLC_LC_AMOUNT", mlcamount.trim());
			test = mprevgridtenoramt.split("&");
			for (int i = 0; i < test.length; i++) {
				System.out.print("Arr " + test[i]);
			}

			// Procedures Variables - Ends

			// Voucher Values
			if (museroption.equalsIgnoreCase("M")) {
				currDTO.setValue("POST_TRAN_BRN", postbrn);
				currDTO.setValue("POST_TRAN_DATE", postdate);
				currDTO.setValue("POST_TRAN_BATCH_NUM", postbatchnum);
			}

			// Changes P.Subramani-Chn-17/10/2008 Beg

			// Changes P.Subramani-Chn-26/03/09 Beg
			if (museroption.equalsIgnoreCase("M")) {
				prevtotalmarginamt = Double.parseDouble(prevmarginamt) + Double.parseDouble(prevexcmarginamt);
				prevtotalcashmarginamt = Double.parseDouble(prevcashmarginamt) + Double.parseDouble(prevexccashmarginamt);
				prevmarginbal = prevtotalmarginamt - prevtotalcashmarginamt;
				prevcashmarbal = prevtotalcashmarginamt;
			} else {
				prevtotalmarginamt = Double.parseDouble(zeroval);
				prevtotalcashmarginamt = Double.parseDouble(zeroval);
				prevmarginbal = Double.parseDouble(zeroval);
				prevcashmarbal = Double.parseDouble(zeroval);
			}
			// Changes P.Subramani-Chn-26/03/09 End

			olcmarginamt1 = Double.parseDouble(olcmarginamt) - prevtotalmarginamt + Double.parseDouble(totalmarginamt);
			olccashmarginamt1 = Double.parseDouble(olccashmaramt) - prevtotalcashmarginamt + Double.parseDouble(totalcashmarginamt);
			marginbal = Double.parseDouble(totalmarginamt) - Double.parseDouble(totalcashmarginamt);
			olcmarginbal1 = Double.parseDouble(olcmarginbal) - prevmarginbal + marginbal;
			olccashmarbal1 = Double.parseDouble(olccashmarbal) - prevcashmarbal + Double.parseDouble(totalcashmarginamt);
			currDTO.setValue("OLC_MARGIN_AMT", String.valueOf(olcmarginamt1));
			currDTO.setValue("OLC_CASH_MAR_AMT", String.valueOf(olccashmarginamt1));
			currDTO.setValue("OLC_MARGIN_BAL", String.valueOf(olcmarginbal1));
			currDTO.setValue("OLC_CASH_MAR_BAL", String.valueOf(olccashmarbal1));
			// Changes P.Subramani-Chn-17/10/2008 End

			// Changes P.Subramani-Chn-22/10/2008 Beg
			currDTO.setValue("MARGIN_CURR", olcMarginCurr);
			if (marginper.equalsIgnoreCase("")) {
				currDTO.setValue("MARGIN_PER", "0");
			} else {
				currDTO.setValue("MARGIN_PER", marginper);
			}
			if (eolmarginper.equalsIgnoreCase("")) {
				currDTO.setValue("EOL_MARGIN_PER", "0");
			} else {
				currDTO.setValue("EOL_MARGIN_PER", eolmarginper);
			}
			if (marginamt.equalsIgnoreCase("")) {
				currDTO.setValue("MARGIN_AMT", "0");
			} else {
				currDTO.setValue("MARGIN_AMT", marginamt);
			}
			if (eolmarginamt.equalsIgnoreCase("")) {
				currDTO.setValue("EOL_MARGIN_AMT", "0");
			} else {
				currDTO.setValue("EOL_MARGIN_AMT", eolmarginamt);
			}
			if (cashmarginamt.equalsIgnoreCase("")) {
				currDTO.setValue("CASH_MARGIN", "0");
			} else {
				currDTO.setValue("CASH_MARGIN", cashmarginamt);
			}
			if (eolcashmarginamt.equalsIgnoreCase("")) {
				currDTO.setValue("EOL_CASH_MARGIN", "0");
			} else {
				currDTO.setValue("EOL_CASH_MARGIN", eolcashmarginamt);
			}
			currDTO.setValue("MARGIN_TYPE", margintype);
			if (excessoverlimitcurrtran.equalsIgnoreCase("")) {
				currDTO.setValue("EXCESS_LIMIT", "0");
			} else {
				currDTO.setValue("EXCESS_LIMIT", excessoverlimitcurrtran);
			}
			// Changes P.Subramani-Chn-22/10/2008 End

			// CHANGED ADDED ON 25/07/2018 START
			currDTO.setValue("USER_BRNAUTH", _brnAuth);
			currDTO.setValue("BRN_AUTH_LCTYPE", _lcTypeAuth);

			// CHANGED ADDED ON 25/07/2018 END

			// Changes in EOLCAMD on 16-Oct-2018 start
			// if(mrefertype.trim().equals("OLC"))
			// {

			if (AMEND_DATE_OF_ISSUE.equalsIgnoreCase("")) {
				currDTO.setValue("AMEND_DATE_OF_ISSUE", null);
			} else {
				currDTO.setValue("AMEND_DATE_OF_ISSUE", AMEND_DATE_OF_ISSUE);
			}
			currDTO.setValue("AMEND_ISSUING_BNK_REQ", (AMEND_ISSUING_BNK_REQ == true) ? "1" : "0");
			if (AMEND_ISSUING_TYPE.trim().equals(""))
				currDTO.setValue("AMEND_ISSUING_TYPE", "0");
			else
				currDTO.setValue("AMEND_ISSUING_TYPE", AMEND_ISSUING_TYPE);

			if (AMEND_ISSUING_TYPE.trim().equals("1")) {
				currDTO.setValue("AMEND_ISSUING_BIC_CODE", AMEND_ISSUING_BIC_CODE);
				currDTO.setValue("AMEND_ISSUING_BRN_CODE", AMEND_ISSUING_BRN_CODE);
			} else {
				currDTO.setValue("AMEND_ISSUING_BIC_CODE", "");
				currDTO.setValue("AMEND_ISSUING_BRN_CODE", "");
			}

			if (AMEND_ISSUING_TYPE.trim().equals("2")) {
				currDTO.setValue("AMEND_ISSUING_BNK_CODE", AMEND_ISSUING_BNK_CODE);
				currDTO.setValue("AMEND_ISSUING_ROUTID", AMEND_ISSUING_ROUTID);

				if (!AMEND_ISSUING_ADDR.equals("")) {
					issuing_bank = AMEND_ISSUING_ADDR.split("\n");
					currDTO.setValue("AMEND_ISSUING_ADDR1", issuing_bank[0].trim());
					currDTO.setValue("AMEND_ISSUING_ADDR2", ((issuing_bank.length > 1) ? issuing_bank[1].trim() : " "));
					currDTO.setValue("AMEND_ISSUING_ADDR3", ((issuing_bank.length > 2) ? issuing_bank[2].trim() : " "));
					currDTO.setValue("AMEND_ISSUING_ADDR4", ((issuing_bank.length > 3) ? issuing_bank[3].trim() : " "));
					currDTO.setValue("AMEND_ISSUING_ADDR5", ((issuing_bank.length > 4) ? issuing_bank[4].trim() : " "));
				} else {
					currDTO.setValue("AMEND_ISSUING_ADDR1", " ");
					currDTO.setValue("AMEND_ISSUING_ADDR2", " ");
					currDTO.setValue("AMEND_ISSUING_ADDR3", " ");
					currDTO.setValue("AMEND_ISSUING_ADDR4", " ");
					currDTO.setValue("AMEND_ISSUING_ADDR5", " ");
				}
				currDTO.setValue("AMEND_ISSUING_CNTRY", AMEND_ISSUING_CNTRY);
			} else {
				currDTO.setValue("AMEND_ISSUING_BNK_CODE", "");
				currDTO.setValue("AMEND_ISSUING_ROUTID", "");
				currDTO.setValue("AMEND_ISSUING_ADDR1", "");
				currDTO.setValue("AMEND_ISSUING_ADDR2", "");
				currDTO.setValue("AMEND_ISSUING_ADDR3", "");
				currDTO.setValue("AMEND_ISSUING_ADDR4", "");
				currDTO.setValue("AMEND_ISSUING_ADDR5", "");
				currDTO.setValue("AMEND_ISSUING_CNTRY", "");
			}

			// Place of Charge
			if (AMEND_PLACE_TAKIN_IN_CHRG.trim().equals(""))
				currDTO.setValue("AMEND_PLACE_TAKIN_IN_CHRG", "");
			else
				currDTO.setValue("AMEND_PLACE_TAKIN_IN_CHRG", AMEND_PLACE_TAKIN_IN_CHRG);
			// Port of loading
			if (AMEND_PORT_OF_LOADING.trim().equals(""))
				currDTO.setValue("AMEND_PORT_OF_LOADING", "");
			else
				currDTO.setValue("AMEND_PORT_OF_LOADING", AMEND_PORT_OF_LOADING);
			// Port of discharge
			if (AMEND_PORT_OF_DISCHARGE.trim().equals(""))
				currDTO.setValue("AMEND_PORT_OF_DISCHARGE", "");
			else
				currDTO.setValue("AMEND_PORT_OF_DISCHARGE", AMEND_PORT_OF_DISCHARGE);
			// Place of Final Destination
			if (AMEND_PLACE_OF_FINAL_DEST.trim().equals(""))
				currDTO.setValue("AMEND_PLACE_OF_FINAL_DEST", "");
			else
				currDTO.setValue("AMEND_PLACE_OF_FINAL_DEST", AMEND_PLACE_OF_FINAL_DEST);

			// Sender to Receiver
			if (!AMEND_SNDR_REC_INFO.equals("")) {
				send_to_rec = AMEND_SNDR_REC_INFO.split("\n");
				currDTO.setValue("AMEND_SNDR_REC_INFO1", send_to_rec[0].trim());
				currDTO.setValue("AMEND_SNDR_REC_INFO2", ((send_to_rec.length > 1) ? send_to_rec[1].trim() : " "));
				currDTO.setValue("AMEND_SNDR_REC_INFO3", ((send_to_rec.length > 2) ? send_to_rec[2].trim() : " "));
				currDTO.setValue("AMEND_SNDR_REC_INFO4", ((send_to_rec.length > 3) ? send_to_rec[3].trim() : " "));
				currDTO.setValue("AMEND_SNDR_REC_INFO5", ((send_to_rec.length > 4) ? send_to_rec[4].trim() : " "));
				currDTO.setValue("AMEND_SNDR_REC_INFO6", ((send_to_rec.length > 5) ? send_to_rec[5].trim() : " "));
			} else {
				currDTO.setValue("AMEND_SNDR_REC_INFO1", " ");
				currDTO.setValue("AMEND_SNDR_REC_INFO2", " ");
				currDTO.setValue("AMEND_SNDR_REC_INFO3", " ");
				currDTO.setValue("AMEND_SNDR_REC_INFO4", " ");
				currDTO.setValue("AMEND_SNDR_REC_INFO5", " ");
				currDTO.setValue("AMEND_SNDR_REC_INFO6", " ");
			}
			//Changes Sanjay1 18-07-2019 Begin
			/*if (AMEND_NARRATIVE.trim().equals(""))
				currDTO.setValue("AMEND_NARRATIVE", "");
			else
				currDTO.setValue("AMEND_NARRATIVE", AMEND_NARRATIVE);*/
			//Changes Sanjay1 18-07-2019 End
			if (AMEND_ENQUIRY_REQ == true)
				chkbox1 = 1;
			else
				chkbox1 = 0;

			if (AMEND_DC_REQ == true)
				chkbox2 = 2;
			else
				chkbox2 = 0;

			if (AMEND_TOLERANCE_REQ == true)
				chkbox3 = 3;
			else
				chkbox3 = 0;

			if (AMEND_PLACE_REQ == true)
				chkbox4 = 4;
			else
				chkbox4 = 0;

			if (AMEND_SHIPMNT_REQ == true)
				chkbox5 = 5;
			else
				chkbox5 = 0;

			if (mchangeofbenef == true)
				chkbox6 = 6;
			else
				chkbox6 = 0;

			AMEND_CHKBOX = String.valueOf(chkbox1 + "|" + chkbox2 + "|" + chkbox3 + "|" + chkbox4 + "|" + chkbox5 + "|" + chkbox6);

			if (AMEND_CHKBOX.trim().equals(""))
				currDTO.setValue("AMEND_CHKBOX", "");
			else
				currDTO.setValue("AMEND_CHKBOX", AMEND_CHKBOX);
			AMEND_ISSUE_REF = mcurrrefnum;// mbranchcode+mrefertype+mreferyear.trim().substring(3,2).toString()+mrefersl;
			// --testing
			currDTO.setValue("AMEND_ISSUE_REF", AMEND_ISSUE_REF);

			// columns not included by CTPC
			currDTO.setValue("AMEND_SNDR_REF", olcrefnum);
			currDTO.setValue("AMEND_RCVR_REF", AMEND_RCVR_REF);
			currDTO.setValue("AMEND_DOC_CR_NUM", AMEND_DOC_CR_NUM);
			currDTO.setValue("AMEND_NON_BNK_ISSUR", "");
			currDTO.setValue("AMEND_DATE_OF_AMENDMENT", mamdentrydate);
			currDTO.setValue("AMEND_PURPOSE_OF_MSG", "I");
			currDTO.setValue("AMEND_CANCEL_REQUEST", "");
			currDTO.setValue("AMEND_ADVISING_BNK_REQ", "0");
			currDTO.setValue("AMEND_ADVISING_BNK_TYPE", "");
			currDTO.setValue("AMEND_ADVISING_BRN_CODE", "");
			currDTO.setValue("AMEND_ADVISING_BIC_CODE", "");
			currDTO.setValue("AMEND_ADVISING_ROUTID", "");
			currDTO.setValue("AMEND_ADVISING_BNK_CODE", "");
			currDTO.setValue("AMEND_ADVISING_ADDR1", "");
			currDTO.setValue("AMEND_ADVISING_ADDR2", "");
			currDTO.setValue("AMEND_ADVISING_ADDR3", "");
			currDTO.setValue("AMEND_ADVISING_ADDR4", "");
			currDTO.setValue("AMEND_ADVISING_ADDR5", "");
			currDTO.setValue("AMEND_SECOND_ADV_REQ", "0");
			currDTO.setValue("AMEND_SECOND_ADV_TYPE", "");
			currDTO.setValue("AMEND_SECOND_ADV_BRN_CODE", "");
			currDTO.setValue("AMEND_SECOND_ADV_BIC_CODE", "");
			currDTO.setValue("AMEND_SECOND_ADV_ROUTID", "");
			currDTO.setValue("AMEND_SECOND_ADV_BNK_CODE", "");
			currDTO.setValue("AMEND_SECOND_ADV_ADDR1", "");
			currDTO.setValue("AMEND_SECOND_ADV_ADDR2", "");
			currDTO.setValue("AMEND_SECOND_ADV_ADDR3", "");
			currDTO.setValue("AMEND_SECOND_ADV_ADDR4", "");
			currDTO.setValue("AMEND_SECOND_ADV_ADDR5", "");
			currDTO.setValue("AMEND_NEW_BENEFICIARY", mbenefcode);
			currDTO.setValue("AMEND_NEW_DATE_OF_EXPIRY", mlasetdateofneg);
			if (menanchementreduction.trim().equals("E")) {
				currDTO.setValue("AMEND_INCR_DOC_CR_AMT", menanchementreductionAmt);
				currDTO.setValue("AMEND_DECR_DOC_CR_AMT", "0");
			} else if (menanchementreduction.trim().equals("R")) {
				currDTO.setValue("AMEND_INCR_DOC_CR_AMT", "0");
				currDTO.setValue("AMEND_DECR_DOC_CR_AMT", menanchementreductionAmt);
			} else {
				currDTO.setValue("AMEND_INCR_DOC_CR_AMT", "0");
				currDTO.setValue("AMEND_DECR_DOC_CR_AMT", "0");
			}

			if (mlatestdateforship.equalsIgnoreCase("")) {
				currDTO.setValue("AMEND_DATE_OF_SHIPMENT", null);
			} else {
				currDTO.setValue("AMEND_DATE_OF_SHIPMENT", mlatestdateforship);
			}

			currDTO.setValue("AMEND_NEW_ADDNL_AMT", "0");

			// //CHANGED BY PRASHANTH ON 08 FEB 2019
			// currDTO.setValue("AMEND_DESC_GODD_SER1", "");
			// currDTO.setValue("AMEND_DOC_REQ1", "");
			// currDTO.setValue("AMEND_ADD_CONDITION1", "");
			// //CHANGED BY PRASHANTH ON 08 FEB 2019

			// ADDED BY PRASHANTH ON 08 FEB 2019
			// currDTO.setValue("AMEND_DESC_GODD_SER2", "");
			// currDTO.setValue("AMEND_DOC_REQ2", "");
			// currDTO.setValue("AMEND_ADD_CONDITION2", "");
			// currDTO.setValue("AMEND_DESC_GODD_SER3", "");
			// currDTO.setValue("AMEND_DOC_REQ3", "");
			// currDTO.setValue("AMEND_ADD_CONDITION3", "");
			//                    
			//                    

			if (LC_DESC_GOODS_SER1.trim().equals(""))
				currDTO.setValue("AMEND_DESC_GODD_SER1", "");
			else
				currDTO.setValue("AMEND_DESC_GODD_SER1", LC_DESC_GOODS_SER1);
			if (LC_DESC_GOODS_SER2.trim().equals(""))
				currDTO.setValue("AMEND_DESC_GODD_SER2", "");
			else
				currDTO.setValue("AMEND_DESC_GODD_SER2", LC_DESC_GOODS_SER2.trim().toString());
			if (LC_DESC_GOODS_SER3.trim().equals(""))
				currDTO.setValue("AMEND_DESC_GODD_SER3", "");
			else
				currDTO.setValue("AMEND_DESC_GODD_SER3", LC_DESC_GOODS_SER3.trim().toString());

			// Document Required
			if (LC_DOC_REQ1.trim().equals(""))
				currDTO.setValue("AMEND_DOC_REQ1", "");
			else
				currDTO.setValue("AMEND_DOC_REQ1", LC_DOC_REQ1.trim().toString());
			if (LC_DOC_REQ2.trim().equals(""))
				currDTO.setValue("AMEND_DOC_REQ2", "");
			else
				currDTO.setValue("AMEND_DOC_REQ2", LC_DOC_REQ2.trim().toString());
			if (LC_DOC_REQ3.trim().equals(""))
				currDTO.setValue("AMEND_DOC_REQ3", "");
			else
				currDTO.setValue("AMEND_DOC_REQ3", LC_DOC_REQ3.trim().toString());
			// Additional Condition

			if (LC_ADD_CONDITION1.trim().equals(""))
				currDTO.setValue("AMEND_ADD_CONDITION1", "");
			else
				currDTO.setValue("AMEND_ADD_CONDITION1", LC_ADD_CONDITION1.trim().toString());
			if (LC_ADD_CONDITION2.trim().equals(""))
				currDTO.setValue("AMEND_ADD_CONDITION2", "");
			else
				currDTO.setValue("AMEND_ADD_CONDITION2", LC_ADD_CONDITION2.trim().toString());
			if (LC_ADD_CONDITION3.trim().equals(""))
				currDTO.setValue("AMEND_ADD_CONDITION3", "");
			else
				currDTO.setValue("AMEND_ADD_CONDITION3", LC_ADD_CONDITION3.trim().toString());
			// ADDED BY PRASHANTH ON 08 FEB 2019

			// ADDED BY NAVYA ON 27/06/19 BEGIN
			if (!AMEND_CHRG_PAYABLE.equals("")) {
				chgs = AMEND_CHRG_PAYABLE.split("\n");
				currDTO.setValue("AMEND_CHRG_PAYABLE1", chgs[0].trim());
				currDTO.setValue("AMEND_CHRG_PAYABLE2", ((chgs.length > 1) ? chgs[1].trim() : " "));
				currDTO.setValue("AMEND_CHRG_PAYABLE3", ((chgs.length > 2) ? chgs[2].trim() : " "));
				currDTO.setValue("AMEND_CHRG_PAYABLE4", ((chgs.length > 3) ? chgs[3].trim() : " "));
				currDTO.setValue("AMEND_CHRG_PAYABLE5", ((chgs.length > 4) ? chgs[4].trim() : " "));
				currDTO.setValue("AMEND_CHRG_PAYABLE6", ((chgs.length > 5) ? chgs[5].trim() : " "));
			}
			// END 
			/*currDTO.setValue("AMEND_NEW_PRD_PRESNT_DAY", "");
			currDTO.setValue("AMEND_NEW_CONFIRM_INSTR", "");
			currDTO.setValue("AMEND_SPL_PAY_BENFICIARY", "");
			currDTO.setValue("AMEND_SPL_PAY_REC_BNK", "");
			currDTO.setValue("AMEND_INSTR_TOPAYING1", "");
			currDTO.setValue("AMEND_INSTR_TOPAYING2", "");
			currDTO.setValue("AMEND_INSTR_TOPAYING3", "");
			currDTO.setValue("AMEND_INSTR_TOPAYING4", "");
			currDTO.setValue("AMEND_INSTR_TOPAYING5", "");
			currDTO.setValue("AMEND_INSTR_TOPAYING6", "");
			currDTO.setValue("AMEND_INSTR_TOPAYING7", "");
			currDTO.setValue("AMEND_INSTR_TOPAYING8", "");
			currDTO.setValue("AMEND_INSTR_TOPAYING9", "");
			currDTO.setValue("AMEND_INSTR_TOPAYING10", "");
			currDTO.setValue("AMEND_INSTR_TOPAYING11", "");
			currDTO.setValue("AMEND_INSTR_TOPAYING12", "");
			*/
			currDTO.setValue("AMEND_ADVISING_CNTRY", "");
			currDTO.setValue("AMEND_SECOND_ADV_CNTRY", "");

			// }

			// Changes in EOLCAMD on 16-Oct-2018 end

			// NEW FIELDS ADDED BY PRASHANTH ON 21 FEB 2019
			if (chkReqForCancel == true) {
				currDTO.setValue("OLCA_REQ_FOR_CANCEL", "1");
			} else {
				currDTO.setValue("OLCA_REQ_FOR_CANCEL", "0");
			}
			if (chkChgAppl == true) {
				currDTO.setValue("OLCA_CHG_OF_APPL", "1");
			} else {
				currDTO.setValue("OLCA_CHG_OF_APPL", "0");
			}
			if (chkChgAvlWith == true) {
				currDTO.setValue("OLCA_CHG_IN_AVL_WITH", "1");
			} else {
				currDTO.setValue("OLCA_CHG_IN_AVL_WITH", "0");
			}
			if (chkCgDrawee == true) {
				currDTO.setValue("OLCA_CHG_IN_DRAWEE_PAY", "1");
			} else {
				currDTO.setValue("OLCA_CHG_IN_DRAWEE_PAY", "0");
			}
			/*
			 * REMOVE if (chkChgAddCond == true) {
			 * currDTO.setValue("OLCA_CHG_IN_PRES_DAYS", "1"); } else {
			 * currDTO.setValue("OLCA_CHG_IN_PRES_DAYS", "0"); }
			 */

			if (chkChgFormDc == true) {
				currDTO.setValue("OLCA_CHG_IN_FORM_OF_DC", "1");
			} else {
				currDTO.setValue("OLCA_CHG_IN_FORM_OF_DC", "0");
			}

			if (chkChgApplRules == true) {
				currDTO.setValue("OLCA_CHG_IN_APPL_RULES", "1");
			} else {
				currDTO.setValue("OLCA_CHG_IN_APPL_RULES", "0");
			}

			if (chkChgReimbus == true) {
				currDTO.setValue("OLCA_CHG_IN_REIMB", "1");
			} else {
				currDTO.setValue("OLCA_CHG_IN_REIMB", "0");
			}
			if (chkCgAdvBk == true) {
				currDTO.setValue("OLCA_CHG_IN_ADV_BK", "1");
			} else {
				currDTO.setValue("OLCA_CHG_IN_ADV_BK", "0");
			}

			// OLC DETAILS TAB

			if (LC_FORM_OF_DOC_CREDIT.trim().equalsIgnoreCase(""))
				currDTO.setValue("AMEND_FORM_OF_DOC_CREDIT", "0");
			else
				currDTO.setValue("AMEND_FORM_OF_DOC_CREDIT", LC_FORM_OF_DOC_CREDIT);

			if (LC_APPLICABLE_RULES.trim().equalsIgnoreCase(""))
				currDTO.setValue("AMEND_LC_APPLICABLE_RULES", "0");
			else
				currDTO.setValue("AMEND_LC_APPLICABLE_RULES", LC_APPLICABLE_RULES);

			currDTO.setValue("AMEND_LC_APPLICANT_REQ", (chkChgAppl == true) ? "1" : "0");
			currDTO.setValue("AMEND_LC_APPLICANT_NAME", txtApplCode);

			if (!txtApplAddress.equals("")) {
				applicant_add = txtApplAddress.split("\n");
				currDTO.setValue("AMEND_LC_APPLICANT_ADDR1", applicant_add[0].trim());
				currDTO.setValue("AMEND_LC_APPLICANT_ADDR2", ((applicant_add.length > 1) ? applicant_add[1].trim() : " "));
				currDTO.setValue("AMEND_LC_APPLICANT_ADDR3", ((applicant_add.length > 2) ? applicant_add[2].trim() : " "));
				currDTO.setValue("AMEND_LC_APPLICANT_ADDR4", ((applicant_add.length > 3) ? applicant_add[3].trim() : " "));
				currDTO.setValue("AMEND_LC_APPLICANT_ADDR5", ((applicant_add.length > 4) ? applicant_add[4].trim() : " "));
			} else {
				currDTO.setValue("AMEND_LC_APPLICANT_ADDR1", " ");
				currDTO.setValue("AMEND_LC_APPLICANT_ADDR2", " ");
				currDTO.setValue("AMEND_LC_APPLICANT_ADDR3", " ");
				currDTO.setValue("AMEND_LC_APPLICANT_ADDR4", " ");
				currDTO.setValue("AMEND_LC_APPLICANT_ADDR5", " ");
			}
			//Changes Sanjay1 18-07-2019 Begin
//			if (LC_APPLICABLE_RULES.trim().equalsIgnoreCase(""))
//				currDTO.setValue("AMEND_FORM_OF_DOC_CREDIT", "0");
//			else
//				currDTO.setValue("AMEND_FORM_OF_DOC_CREDIT", LC_APPLICABLE_RULES);
			//Changes Sanjay1 18-07-2019 End
			// OLC DETAILS TAB

			// AVL WITH TAB
			
			if (LC_AVAILABLE_WITH_CODETYP.trim().equals(""))
				currDTO.setValue("AMEND_LC_AVL_WITH_CODETYP", "0");
			else
				currDTO.setValue("AMEND_LC_AVL_WITH_CODETYP", LC_AVAILABLE_WITH_CODETYP);

			
			if (LC_AVAILABLE_WITH_TYPE.trim().equals(""))
				currDTO.setValue("AMEND_LC_AVL_WITH_TYPE", "0");
			else
				currDTO.setValue("AMEND_LC_AVL_WITH_TYPE", LC_AVAILABLE_WITH_TYPE);

			if (LC_AVAILABLE_WITH_TYPE.trim().equals("1")) {
				currDTO.setValue("AMEND_LC_AVL_WITH_BRN_CODE", LC_AVAILABLE_WITH_BRN_CODE);
				currDTO.setValue("AMEND_LC_AVL_WITH_BIC_CODE", LC_AVAILABLE_WITH_BIC_CODE);
			} else {
				currDTO.setValue("AMEND_LC_AVL_WITH_BRN_CODE", "");
				currDTO.setValue("AMEND_LC_AVL_WITH_BIC_CODE", "");
			}

			 if (LC_AVAILABLE_WITH_TYPE.trim().equals("2")) {
				currDTO.setValue("AMEND_LC_AVL_WITH_BNK_CODE", LC_AVAILABLE_WITH_BNK_CODE);
				currDTO.setValue("AMEND_LC_LC_AVL_WITH_ROUTID", LC_AVAILABLE_WITH_ROUTID);

				if (!LC_AVAILABLE_WITH_ADDRESS.equals("")) {
					availbl_with_add = LC_AVAILABLE_WITH_ADDRESS.split("\n");
					currDTO.setValue("AMEND_LC_AVL_WITH_ADDR1", availbl_with_add[0].trim());
					currDTO.setValue("AMEND_LC_AVL_WITH_ADDR2", ((availbl_with_add.length > 1) ? availbl_with_add[1].trim() : " "));
					currDTO.setValue("AMEND_LC_AVL_WITH_ADDR3", ((availbl_with_add.length > 2) ? availbl_with_add[2].trim() : " "));
					currDTO.setValue("AMEND_LC_AVL_WITH_ADDR4", ((availbl_with_add.length > 3) ? availbl_with_add[3].trim() : " "));
					currDTO.setValue("AMEND_LC_AVL_WITH_ADDR5", ((availbl_with_add.length > 4) ? availbl_with_add[4].trim() : " "));
				} else {
					currDTO.setValue("AMEND_LC_AVL_WITH_ADDR1", " ");
					currDTO.setValue("AMEND_LC_AVL_WITH_ADDR2", " ");
					currDTO.setValue("AMEND_LC_AVL_WITH_ADDR3", " ");
					currDTO.setValue("AMEND_LC_AVL_WITH_ADDR4", " ");
					currDTO.setValue("AMEND_LC_AVL_WITH_ADDR5", " ");
				}
				currDTO.setValue("AMEND_LC_AVL_WITH_CNTRY", LC_AVAILABLE_WITH_CNTRY);// MISSING
				// TO
				// ADD
			} else {
				currDTO.setValue("AMEND_LC_AVL_WITH_BNK_CODE", "");
				currDTO.setValue("AMEND_LC_LC_AVL_WITH_ROUTID", "");
				currDTO.setValue("AMEND_LC_AVL_WITH_ADDR1", "");
				currDTO.setValue("AMEND_LC_AVL_WITH_ADDR2", "");
				currDTO.setValue("AMEND_LC_AVL_WITH_ADDR3", "");
				currDTO.setValue("AMEND_LC_AVL_WITH_ADDR4", "");
				currDTO.setValue("AMEND_LC_AVL_WITH_ADDR5", "");
				currDTO.setValue("AMEND_LC_AVL_WITH_CNTRY", "");
			}

			// Drafts At...
			if (!LC_DRAFTS_AT.equals("")) {
				drafts = LC_DRAFTS_AT.split("\n");
				currDTO.setValue("AMEND_LC_DRAFTS_AT1", drafts[0].trim());
				currDTO.setValue("AMEND_LC_DRAFTS_AT2", ((drafts.length > 1) ? drafts[1].trim() : " "));
				currDTO.setValue("AMEND_LC_DRAFTS_AT3", ((drafts.length > 2) ? drafts[2].trim() : " "));
			} else {
				currDTO.setValue("AMEND_LC_DRAFTS_AT1", " ");
				currDTO.setValue("AMEND_LC_DRAFTS_AT2", " ");
				currDTO.setValue("AMEND_LC_DRAFTS_AT3", " ");
			}

			// AVL WITH TAB

			// DRAWEE TAB
			currDTO.setValue("AMEND_LC_DRAWEE_REQ", (LC_DRAWEE_REQ == true) ? "1" : "0");

			if (LC_DRAWEE_TYPE.trim().equals(""))
				currDTO.setValue("AMEND_LC_DRAWEE_TYPE", "0");
			else
				currDTO.setValue("AMEND_LC_DRAWEE_TYPE", LC_DRAWEE_TYPE);
			if (LC_DRAWEE_TYPE.trim().equals("1")) {
				currDTO.setValue("AMEND_LC_DRAWEE_BRN_CODE", LC_DRAWEE_BRN_CODE);
				currDTO.setValue("AMEND_LC_DRAWEE_BIC_CODE", LC_DRAWEE_BIC_CODE);
			} else {
				currDTO.setValue("AMEND_LC_DRAWEE_BRN_CODE", "");
				currDTO.setValue("AMEND_LC_DRAWEE_BIC_CODE", "");
			}

			if (LC_DRAWEE_TYPE.trim().equals("2")) {
				currDTO.setValue("AMEND_LC_DRAWEE_BNK_CODE", LC_DRAWEE_BNK_CODE);
				currDTO.setValue("AMEND_LC_DRAWEE_ROUTID", LC_DRAWEE_ROUTID);

				if (!LC_DRAWEE_ADDRESS.equals("")) {
					drawee_add = LC_DRAWEE_ADDRESS.split("\n");
					currDTO.setValue("AMEND_LC_DRAWEE_ADDR1", drawee_add[0].trim());
					currDTO.setValue("AMEND_LC_DRAWEE_ADDR2", ((drawee_add.length > 1) ? drawee_add[1].trim() : " "));
					currDTO.setValue("AMEND_LC_DRAWEE_ADDR3", ((drawee_add.length > 2) ? drawee_add[2].trim() : " "));
					currDTO.setValue("AMEND_LC_DRAWEE_ADDR4", ((drawee_add.length > 3) ? drawee_add[3].trim() : " "));
					currDTO.setValue("AMEND_LC_DRAWEE_ADDR5", ((drawee_add.length > 4) ? drawee_add[4].trim() : " "));
				} else {
					currDTO.setValue("AMEND_LC_DRAWEE_ADDR1", " ");
					currDTO.setValue("AMEND_LC_DRAWEE_ADDR2", " ");
					currDTO.setValue("AMEND_LC_DRAWEE_ADDR3", " ");
					currDTO.setValue("AMEND_LC_DRAWEE_ADDR4", " ");
					currDTO.setValue("AMEND_LC_DRAWEE_ADDR5", " ");
				}
				currDTO.setValue("AMEND_DRAWEE_CNTRY_CODE", LC_DRAWEE_CNTRY_CODE);/*
				 * MISSING
				 * FIELD
				 * SHOULD
				 * ADD
				 */
			} else {
				currDTO.setValue("AMEND_LC_DRAWEE_BNK_CODE", "");
				currDTO.setValue("AMEND_LC_DRAWEE_ROUTID", "");
				currDTO.setValue("AMEND_LC_DRAWEE_ADDR1", "");
				currDTO.setValue("AMEND_LC_DRAWEE_ADDR2", "");
				currDTO.setValue("AMEND_LC_DRAWEE_ADDR3", "");
				currDTO.setValue("AMEND_LC_DRAWEE_ADDR4", "");
				currDTO.setValue("AMEND_LC_DRAWEE_ADDR5", "");
				currDTO.setValue("AMEND_DRAWEE_CNTRY_CODE", "");/*
				 * MISSING FIELD
				 * SHOULD ADD
				 */
			}

			// Deferred Payment
			if (LC_AVAILABLE_WITH_CODETYP.trim().equals("2")) {
				if (!LC_DEFERRED_PAY_DETAILS.equals("")) {
					def_pay_details = LC_DEFERRED_PAY_DETAILS.split("\n");
					currDTO.setValue("AMEND_LC_DEFERRED_PAY_DETAILS1", def_pay_details[0].trim());
					currDTO.setValue("AMEND_LC_DEFERRED_PAY_DETAILS2", ((def_pay_details.length > 1) ? def_pay_details[1].trim() : " "));
					currDTO.setValue("AMEND_LC_DEFERRED_PAY_DETAILS3", ((def_pay_details.length > 2) ? def_pay_details[2].trim() : " "));
					currDTO.setValue("AMEND_LC_DEFERRED_PAY_DETAILS4", ((def_pay_details.length > 3) ? def_pay_details[3].trim() : " "));
				} else {
					currDTO.setValue("AMEND_LC_DEFERRED_PAY_DETAILS1", " ");
					currDTO.setValue("AMEND_LC_DEFERRED_PAY_DETAILS2", " ");
					currDTO.setValue("AMEND_LC_DEFERRED_PAY_DETAILS3", " ");
					currDTO.setValue("AMEND_LC_DEFERRED_PAY_DETAILS4", " ");
				}
			}
			// Mixed Payment
			else if (LC_AVAILABLE_WITH_CODETYP.trim().equals("3")) {
				if (!LC_MIXED_PAY_DETAILS.equals("")) {
					mixed_pay_details = LC_MIXED_PAY_DETAILS.split("\n");
					currDTO.setValue("AMEND_LC_MIXED_PAY_DETAILS1", mixed_pay_details[0].trim());
					currDTO.setValue("AMEND_LC_MIXED_PAY_DETAILS2", ((mixed_pay_details.length > 1) ? mixed_pay_details[1].trim() : " "));
					currDTO.setValue("AMEND_LC_MIXED_PAY_DETAILS3", ((mixed_pay_details.length > 2) ? mixed_pay_details[2].trim() : " "));
					currDTO.setValue("AMEND_LC_MIXED_PAY_DETAILS4", ((mixed_pay_details.length > 3) ? mixed_pay_details[3].trim() : " "));
				} else {
					currDTO.setValue("AMEND_LC_MIXED_PAY_DETAILS1", " ");
					currDTO.setValue("AMEND_LC_MIXED_PAY_DETAILS2", " ");
					currDTO.setValue("AMEND_LC_MIXED_PAY_DETAILS3", " ");
					currDTO.setValue("AMEND_LC_MIXED_PAY_DETAILS4", " ");
				}
			}

			if (LC_PARTIAL_SHIPMENTS.trim().equalsIgnoreCase("1")) {
				currDTO.setValue("AMEND_LC_PARTIAL_SHIPMENTS", "1");
			} else if (LC_PARTIAL_SHIPMENTS.trim().equalsIgnoreCase("2")) {
				currDTO.setValue("AMEND_LC_PARTIAL_SHIPMENTS", "0");
			} else if (LC_PARTIAL_SHIPMENTS.trim().equalsIgnoreCase("3")) {
				currDTO.setValue("AMEND_LC_PARTIAL_SHIPMENTS", "0");
			} else {
				currDTO.setValue("AMEND_LC_PARTIAL_SHIPMENTS", "0");
			}

			if (LC_TRANSHIPMENT.trim().equalsIgnoreCase("1")) {
				currDTO.setValue("AMEND_LC_TRANSHIPMENT", "1");
			} else if (LC_TRANSHIPMENT.trim().equalsIgnoreCase("2")) {
				currDTO.setValue("AMEND_LC_TRANSHIPMENT", "0");
			} else if (LC_TRANSHIPMENT.trim().equalsIgnoreCase("3")) {
				currDTO.setValue("AMEND_LC_TRANSHIPMENT", "0");
			} else {
				currDTO.setValue("AMEND_LC_TRANSHIPMENT", "0");
			}

			// DRAWEE TAB

			// reimb tab

			
			//Changes Sanjay1 18-07-2019 Begin
			if (!LC_CONFIRMATION_INST.equals("")) {
				currDTO.setValue("AMEND_LC_CONFIRMATION_INST", LC_CONFIRMATION_INST);
				if(!LC_CONFIRMATION_INST.equals("3"))
				{
					if (LC_REIMB_CFM_TYPE.trim().equals(""))
						currDTO.setValue("AMEND_LC_CNF_ADV_TYPE", "");
					else
						currDTO.setValue("AMEND_LC_CNF_ADV_TYPE", LC_REIMB_CFM_TYPE);
					if (LC_REIMB_CFM_TYPE.trim().equals("1")) {
						currDTO.setValue("AMEND_LC_CNF_ADV_BRN_CODE", LC_REIMB_CFM_BRN_CODE);
						currDTO.setValue("AMEND_LC_CNF_ADV_BIC_CODE", LC_REIMB_CFM_BIC_CODE);
					} else {
						currDTO.setValue("AMEND_LC_CNF_ADV_BRN_CODE", "");
						currDTO.setValue("AMEND_LC_CNF_ADV_BIC_CODE", "");
					}

					if (LC_REIMB_CFM_TYPE.trim().equals("2")) {
						currDTO.setValue("AMEND_LC_CNF_ADV_BNK_CODE", LC_CFM_REIMB_BNK_CODE);
						currDTO.setValue("AMEND_LC_CNF_ADV_ROUTID", LC_CFM_REIMB_ROUTID);

						if (!LC_CFM_REIMB_ADDRESS.equals("")) {
							reimb_cfm_add = LC_CFM_REIMB_ADDRESS.split("\n");
							currDTO.setValue("AMEND_LC_CNF_ADV_ADDR1", reimb_cfm_add[0].trim());
							currDTO.setValue("AMEND_LC_CNF_ADV_ADDR2", ((reimb_cfm_add.length > 1) ? reimb_cfm_add[1].trim() : " "));
							currDTO.setValue("AMEND_LC_CNF_ADV_ADDR3", ((reimb_cfm_add.length > 2) ? reimb_cfm_add[2].trim() : " "));
							currDTO.setValue("AMEND_LC_CNF_ADV_ADDR4", ((reimb_cfm_add.length > 3) ? reimb_cfm_add[3].trim() : " "));
							currDTO.setValue("AMEND_LC_CNF_ADV_ADDR5", ((reimb_cfm_add.length > 4) ? reimb_cfm_add[4].trim() : " "));
						} else {
							currDTO.setValue("AMEND_LC_CNF_ADV_ADDR1", " ");
							currDTO.setValue("AMEND_LC_CNF_ADV_ADDR2", " ");
							currDTO.setValue("AMEND_LC_CNF_ADV_ADDR3", " ");
							currDTO.setValue("AMEND_LC_CNF_ADV_ADDR4", " ");
							currDTO.setValue("AMEND_LC_CNF_ADV_ADDR5", " ");
						}
						currDTO.setValue("AMEND_LC_CNF_ADV_CNTRYCODE", LC_CFM_REIMB_CNTRY_CODE);// should
						// add
					} else {
						currDTO.setValue("AMEND_LC_CNF_ADV_BNK_CODE", "");
						currDTO.setValue("AMEND_LC_CNF_ADV_ROUTID", "");
						currDTO.setValue("AMEND_LC_CNF_ADV_ADDR1", "");
						currDTO.setValue("AMEND_LC_CNF_ADV_ADDR2", "");
						currDTO.setValue("AMEND_LC_CNF_ADV_ADDR3", "");
						currDTO.setValue("AMEND_LC_CNF_ADV_ADDR4", "");
						currDTO.setValue("AMEND_LC_CNF_ADV_ADDR5", "");
						currDTO.setValue("AMEND_LC_CNF_ADV_CNTRYCODE", "");// should add
					}
				}
			} else {
				currDTO.setValue("AMEND_LC_CONFIRMATION_INST", "0");
			}
			/*currDTO.setValue("AMEND_LC_CNF_BY_BANK", olcLcToBeCnfrmdByBk);
			if (olcLcToBeCnfrmdByBrn.equals("")) {
				currDTO.setValue("AMEND_LC_CNF_BY_BRN", "0");
			} else
				currDTO.setValue("AMEND_LC_CNF_BY_BRN", olcLcToBeCnfrmdByBrn);*/
			

			//Changes Sanjay1 18-07-2019 End
			currDTO.setValue("AMEND_LC_REIMB_REQ", (LC_REIMB_REQ == true) ? "1" : "0");

			if (LC_REIMB_TYPE.trim().equals(""))
				currDTO.setValue("AMEND_LC_REIMB_TYPE", "");
			else
				currDTO.setValue("AMEND_LC_REIMB_TYPE", LC_REIMB_TYPE);
			if (LC_REIMB_TYPE.trim().equals("1")) {
				currDTO.setValue("AMEND_LC_REIMB_BRN_CODE", LC_REIMB_BRN_CODE);
				currDTO.setValue("AMEND_LC_REIMB_BIC_CODE", LC_REIMB_BIC_CODE);
			} else {
				currDTO.setValue("AMEND_LC_REIMB_BRN_CODE", "");
				currDTO.setValue("AMEND_LC_REIMB_BIC_CODE", "");
			}

			if (LC_REIMB_TYPE.trim().equals("2")) {
				currDTO.setValue("AMEND_LC_REIMB_BNK_CODE", LC_REIMB_BNK_CODE);
				currDTO.setValue("AMEND_LC_REIMB_ROUTID", LC_REIMB_ROUTID);

				if (!LC_REIMB_ADDRESS.equals("")) {
					reimb_add = LC_REIMB_ADDRESS.split("\n");
					currDTO.setValue("AMEND_LC_REIMB_ADDR1", reimb_add[0].trim());
					currDTO.setValue("AMEND_LC_REIMB_ADDR2", ((reimb_add.length > 1) ? reimb_add[1].trim() : " "));
					currDTO.setValue("AMEND_LC_REIMB_ADDR3", ((reimb_add.length > 2) ? reimb_add[2].trim() : " "));
					currDTO.setValue("AMEND_LC_REIMB_ADDR4", ((reimb_add.length > 3) ? reimb_add[3].trim() : " "));
					currDTO.setValue("AMEND_LC_REIMB_ADDR5", ((reimb_add.length > 4) ? reimb_add[4].trim() : " "));
				} else {
					currDTO.setValue("AMEND_LC_REIMB_ADDR1", " ");
					currDTO.setValue("AMEND_LC_REIMB_ADDR2", " ");
					currDTO.setValue("AMEND_LC_REIMB_ADDR3", " ");
					currDTO.setValue("AMEND_LC_REIMB_ADDR4", " ");
					currDTO.setValue("AMEND_LC_REIMB_ADDR5", " ");
				}
				currDTO.setValue("AMEND_LC_REIMB_CNTRY_CODE", LC_REIMB_CNTRY_CODE);// should
				// add
			} else {
				currDTO.setValue("AMEND_LC_REIMB_BNK_CODE", "");
				currDTO.setValue("AMEND_LC_REIMB_ROUTID", "");
				currDTO.setValue("AMEND_LC_REIMB_ADDR1", "");
				currDTO.setValue("AMEND_LC_REIMB_ADDR2", "");
				currDTO.setValue("AMEND_LC_REIMB_ADDR3", "");
				currDTO.setValue("AMEND_LC_REIMB_ADDR4", "");
				currDTO.setValue("AMEND_LC_REIMB_ADDR5", "");
				currDTO.setValue("LC_REIMB_CNTRY_CODE", "");// should add
			}

			// Instructions to Paying
			if (!LC_INST_PAYING.equals("")) {
				instr_paying = LC_INST_PAYING.split("\n");
				currDTO.setValue("AMEND_LC_INST_PAYING1", instr_paying[0].trim());
				currDTO.setValue("AMEND_LC_INST_PAYING2", ((instr_paying.length > 1) ? instr_paying[1].trim() : " "));
				currDTO.setValue("AMEND_LC_INST_PAYING3", ((instr_paying.length > 2) ? instr_paying[2].trim() : " "));
				currDTO.setValue("AMEND_LC_INST_PAYING4", ((instr_paying.length > 3) ? instr_paying[3].trim() : " "));
				currDTO.setValue("AMEND_LC_INST_PAYING5", ((instr_paying.length > 4) ? instr_paying[4].trim() : " "));
				currDTO.setValue("AMEND_LC_INST_PAYING6", ((instr_paying.length > 5) ? instr_paying[5].trim() : " "));
				currDTO.setValue("AMEND_LC_INST_PAYING7", ((instr_paying.length > 6) ? instr_paying[6].trim() : " "));
				currDTO.setValue("AMEND_LC_INST_PAYING8", ((instr_paying.length > 7) ? instr_paying[7].trim() : " "));
				currDTO.setValue("AMEND_LC_INST_PAYING9", ((instr_paying.length > 8) ? instr_paying[8].trim() : " "));
				currDTO.setValue("AMEND_LC_INST_PAYING10", ((instr_paying.length > 9) ? instr_paying[9].trim() : " "));
				currDTO.setValue("AMEND_LC_INST_PAYING11", ((instr_paying.length > 10) ? instr_paying[10].trim() : " "));
				currDTO.setValue("AMEND_LC_INST_PAYING12", ((instr_paying.length > 11) ? instr_paying[11].trim() : " "));
			} else {
				currDTO.setValue("AMEND_LC_INST_PAYING1", " ");
				currDTO.setValue("AMEND_LC_INST_PAYING2", " ");
				currDTO.setValue("AMEND_LC_INST_PAYING3", " ");
				currDTO.setValue("AMEND_LC_INST_PAYING4", " ");
				currDTO.setValue("AMEND_LC_INST_PAYING5", " ");
				currDTO.setValue("AMEND_LC_INST_PAYING6", " ");
				currDTO.setValue("AMEND_LC_INST_PAYING7", " ");
				currDTO.setValue("AMEND_LC_INST_PAYING8", " ");
				currDTO.setValue("AMEND_LC_INST_PAYING9", " ");
				currDTO.setValue("AMEND_LC_INST_PAYING10", " ");
				currDTO.setValue("AMEND_LC_INST_PAYING11", " ");
				currDTO.setValue("AMEND_LC_INST_PAYING12", " ");
			}
			// reimb tab

			// Advising Bank
			currDTO.setValue("AMEND_LC_SECOND_ADV_REQ", (LC_SECOND_ADV_REQ == true) ? "1" : "0");
			if (LC_SECOND_ADV_TYPE.trim().equals(""))
				currDTO.setValue("AMEND_LC_SECOND_ADV_TYPE", "");
			else
				currDTO.setValue("AMEND_LC_SECOND_ADV_TYPE", LC_SECOND_ADV_TYPE);
			if (LC_SECOND_ADV_TYPE.trim().equals("1")) {
				currDTO.setValue("AMEND_LC_SECOND_ADV_BRN_CODE", LC_SECOND_ADV_BRN_CODE);
				currDTO.setValue("AMEND_LC_SECOND_ADV_BIC_CODE", LC_SECOND_ADV_BIC_CODE);
			} else {
				currDTO.setValue("AMEND_LC_SECOND_ADV_BRN_CODE", "");
				currDTO.setValue("AMEND_LC_SECOND_ADV_BIC_CODE", "");
			}

			if (LC_SECOND_ADV_TYPE.trim().equals("2")) {
				currDTO.setValue("AMEND_LC_SECOND_ADV_BNK_CODE", LC_SECOND_ADV_BNK_CODE);
				currDTO.setValue("AMEND_LC_SECOND_ADV_ROUTID", LC_SECOND_ADV_ROUTID);

				if (!LC_SECOND_ADV_ADDRESS.equals("")) {
					second_adv_add = LC_SECOND_ADV_ADDRESS.split("\n");
					currDTO.setValue("AMEND_LC_SECOND_ADV_ADDR1", second_adv_add[0].trim());
					currDTO.setValue("AMEND_LC_SECOND_ADV_ADDR2", ((second_adv_add.length > 1) ? second_adv_add[1].trim() : " "));
					currDTO.setValue("AMEND_LC_SECOND_ADV_ADDR3", ((second_adv_add.length > 2) ? second_adv_add[2].trim() : " "));
					currDTO.setValue("AMEND_LC_SECOND_ADV_ADDR4", ((second_adv_add.length > 3) ? second_adv_add[3].trim() : " "));
					currDTO.setValue("AMEND_LC_SECOND_ADV_ADDR5", ((second_adv_add.length > 4) ? second_adv_add[4].trim() : " "));
				} else {
					currDTO.setValue("AMEND_LC_SECOND_ADV_ADDR1", " ");
					currDTO.setValue("AMEND_LC_SECOND_ADV_ADDR2", " ");
					currDTO.setValue("AMEND_LC_SECOND_ADV_ADDR3", " ");
					currDTO.setValue("AMEND_LC_SECOND_ADV_ADDR4", " ");
					currDTO.setValue("AMEND_LC_SECOND_ADV_ADDR5", " ");
				}
				currDTO.setValue("AMEND_LC_SECOND_ADV_CNTRYCODE", LC_SECOND_ADV_CNTRYCODE);// missing
				// should
				// add
			} else {
				currDTO.setValue("AMEND_LC_SECOND_ADV_BNK_CODE", "");
				currDTO.setValue("AMEND_LC_SECOND_ADV_ROUTID", "");
				currDTO.setValue("AMEND_LC_SECOND_ADV_ADDR1", "");
				currDTO.setValue("AMEND_LC_SECOND_ADV_ADDR2", "");
				currDTO.setValue("AMEND_LC_SECOND_ADV_ADDR3", "");
				currDTO.setValue("AMEND_LC_SECOND_ADV_ADDR4", "");
				currDTO.setValue("AMEND_LC_SECOND_ADV_ADDR5", "");
				currDTO.setValue("AMEND_LC_SECOND_ADV_CNTRYCODE", "");// missing
				// should
				// add
			}

			currDTO.setValue("OLCAMDGOODSCHOICE", amdGoodsValue);
			currDTO.setValue("OLCAMDDOCSCHOICE", amdDocsValue);
			currDTO.setValue("OLCAMDADDLCHOICE", amdAddlValue);
			currDTO.setValue("OLCAMDSPLCOND1CHOICE", amdSpl1Value);
			currDTO.setValue("OLCAMDSPLCOND2CHOICE", amdSpl2Value);

			/*	currDTO.setValue("AMENDLOGGOODS", txtAmdLog);
				currDTO.setValue("AMENDLOGDOCS", txtAmdLogDoc);
				currDTO.setValue("AMENDLOGADDL", txtAmdLogAddl);
				
			 */
			amdlogtemp1=amdlogtemp1.replaceAll("\\r\\n\\r\\n","\r\n");
			amdlogtemp2=amdlogtemp2.replaceAll("\\r\\n\\r\\n","\r\n");
			amdlogtemp3=amdlogtemp3.replaceAll("\\r\\n\\r\\n","\r\n");
			amdlogtemp4=amdlogtemp4.replaceAll("\\r\\n\\r\\n","\r\n");
			amdlogtemp5=amdlogtemp5.replaceAll("\\r\\n\\r\\n","\r\n");

			currDTO.setValue("AMENDLOGGOODS", amdlogtemp1);
			currDTO.setValue("AMENDLOGDOCS", amdlogtemp2);
			currDTO.setValue("AMENDLOGADDL", amdlogtemp3);

			/*	currDTO.setValue("AMENDLOGSPL1", txtAmdLogSplBene);
				currDTO.setValue("AMENDLOGSPL2", txtAmdLogSplRecev);
			 */

			currDTO.setValue("AMENDLOGSPL1", amdlogtemp4);
			currDTO.setValue("AMENDLOGSPL2", amdlogtemp5);

			currDTO.setValue("COMPLAMENDGOODS", txtcompAmdDetails);
			currDTO.setValue("COMPLAMENDDOCS", txtcompAmdDetailsDoc);
			currDTO.setValue("COMPLAMENDADDL", txtcompAmdDetailsAddl);
			currDTO.setValue("COMPLAMENDSPL1", txtcompAmdDetailsSplBene);
			currDTO.setValue("COMPLAMENDSPL2", txtcompAmdDetailsSplRecev);

			// NEW FIELDS ADDED BY PRASHANTH ON 21 FEB 2019

			currDTO.setValue("INTERNAL_ACC_NUM", minternalaccnum);
			currDTO.setValue("Class", JNDINames.EOLCAMDBO_EJBHOME);
			currDTO.setValue("USERID", getM_Userid());
			currDTO.setValue("USRBRNCODE", getM_BranchCode());
			currDTO.setValue("IPADDRESS", get_IPaddress());
			currDTO.setValue("UserOption", museroption);
			currDTO.setValue("CORR_REF_NUM", mcurrrefnum);
			currDTO.setValue("CBD", getM_CurrBusDate());
			currDTO.setValue("BASE_CURR", getM_BCurrCode());
			currDTO.setValue("TOTAL_CHARGE_AMT", mtotalamt);

			try {
				CDelagate = new CommonDelegate();
				DTOResult = CDelagate.setInfo(currDTO);
				System.out.println(DTOResult.getValue("Result"));
			} catch (Exception e) {
				System.out.println(e.getMessage());
			} finally {
				if ("SUCCESS".equals(DTOResult.getValue("Result"))) {
					mtxnstatus = "0";
					merrmsg = "";
					// M.Jayakumaran add 17-06-2011 begin
					if (DTOResult.containsKey("SERIAL"))
						mamdsl = DTOResult.getValue("SERIAL");
					// M.Jayakumaran add 17-06-2011 end
					batchnum = DTOResult.getValue("BatchNumber");
					if (!batchnum.trim().equalsIgnoreCase("")) {
						// setBatchnum(batchnum);
						setBatchnum(mamdsl + "\n" + batchnum);// sreeKumari T
						// ADD

					}
				} else {
					mtxnstatus = "1";
					merrmsg = "";
					if (DTOResult.containsKey("Errmsg"))
						;
					{
						merrmsg = DTOResult.getValue("Errmsg");
					}
				}
			}
			{
				setreturnvalue();
				return "success";
			}
		} else {
			{
				setreturnvalue();
				return "failure";
			}
		}

	}

	public String getMaddliabbasecurr() {
		return maddliabbasecurr;
	}

	public void setMaddliabbasecurr(String maddliabbasecurr) {
		this.maddliabbasecurr = maddliabbasecurr;
	}

	public String getMaddliablccurr() {
		return maddliablccurr;
	}

	public void setMaddliablccurr(String maddliablccurr) {
		this.maddliablccurr = maddliablccurr;
	}

	public String getMamdamt() {
		return mamdamt;
	}

	public void setMamdamt(String mamdamt) {
		this.mamdamt = mamdamt;
	}

	public String getMamdentrydate() {
		return mamdentrydate;
	}

	public void setMamdentrydate(String mamdentrydate) {
		this.mamdentrydate = mamdentrydate;
	}

	public String getMamdsl() {
		return mamdsl;
	}

	public void setMamdsl(String mamdsl) {
		this.mamdsl = mamdsl;
	}

	public String getMamtqualifier() {
		return mamtqualifier;
	}

	public void setMamtqualifier(String mamtqualifier) {
		this.mamtqualifier = mamtqualifier;
	}

	public String getMbenefaddr() {
		return mbenefaddr;
	}

	public void setMbenefaddr(String mbenefaddr) {
		this.mbenefaddr = mbenefaddr;
	}

	public String getMbenefcode() {
		return mbenefcode;
	}

	public void setMbenefcode(String mbenefcode) {
		this.mbenefcode = mbenefcode;
	}

	public String getMbenefcountrycode() {
		return mbenefcountrycode;
	}

	public void setMbenefcountrycode(String mbenefcountrycode) {
		this.mbenefcountrycode = mbenefcountrycode;
	}

	public String getMbenefname() {
		return mbenefname;
	}

	public void setMbenefname(String mbenefname) {
		this.mbenefname = mbenefname;
	}

	public String getMbranchcode() {
		return mbranchcode;
	}

	public void setMbranchcode(String mbranchcode) {
		this.mbranchcode = mbranchcode;
	}

	public boolean isMchangeofbenef() {
		return mchangeofbenef;
	}

	public void setMchangeofbenef(boolean mchangeofbenef) {
		this.mchangeofbenef = mchangeofbenef;
	}

	public String getMconvratebasecurr() {
		return mconvratebasecurr;
	}

	public void setMconvratebasecurr(String mconvratebasecurr) {
		this.mconvratebasecurr = mconvratebasecurr;
	}

	public String getMconvratelimcurr() {
		return mconvratelimcurr;
	}

	public void setMconvratelimcurr(String mconvratelimcurr) {
		this.mconvratelimcurr = mconvratelimcurr;
	}

	public String getMcustletterdate() {
		return mcustletterdate;
	}

	public void setMcustletterdate(String mcustletterdate) {
		this.mcustletterdate = mcustletterdate;
	}

	public String getMcustletternum() {
		return mcustletternum;
	}

	public void setMcustletternum(String mcustletternum) {
		this.mcustletternum = mcustletternum;
	}

	public String getMdeviamt() {
		return mdeviamt;
	}

	public void setMdeviamt(String mdeviamt) {
		this.mdeviamt = mdeviamt;
	}

	public String getMdrawdowns() {
		return mdrawdowns;
	}

	public void setMdrawdowns(String mdrawdowns) {
		this.mdrawdowns = mdrawdowns;
	}

	public String getMerrmsg() {
		return merrmsg;
	}

	public void setMerrmsg(String merrmsg) {
		this.merrmsg = merrmsg;
	}

	public String getMlasetdateofneg() {
		return mlasetdateofneg;
	}

	public void setMlasetdateofneg(String mlasetdateofneg) {
		this.mlasetdateofneg = mlasetdateofneg;
	}

	public String getMlatestdateforship() {
		return mlatestdateforship;
	}

	public void setMlatestdateforship(String mlatestdateforship) {
		this.mlatestdateforship = mlatestdateforship;
	}

	public String getMlccurr() {
		return mlccurr;
	}

	public void setMlccurr(String mlccurr) {
		this.mlccurr = mlccurr;
	}

	public String getMnegdevi() {
		return mnegdevi;
	}

	public void setMnegdevi(String mnegdevi) {
		this.mnegdevi = mnegdevi;
	}

	public String getMplaceofexpiry() {
		return mplaceofexpiry;
	}

	public void setMplaceofexpiry(String mplaceofexpiry) {
		this.mplaceofexpiry = mplaceofexpiry;
	}

	public String getMpostdevi() {
		return mpostdevi;
	}

	public void setMpostdevi(String mpostdevi) {
		this.mpostdevi = mpostdevi;
	}

	public String getMpresentationdetails() {
		return mpresentationdetails;
	}

	public void setMpresentationdetails(String mpresentationdetails) {
		this.mpresentationdetails = mpresentationdetails;
	}

	/*
	 * public String getMreasonforamd() { return mreasonforamd; }
	 * 
	 * 
	 * 
	 * 
	 * public void setMreasonforamd(String mreasonforamd) { this.mreasonforamd =
	 * mreasonforamd; }
	 */

	public String getMrefersl() {
		return mrefersl;
	}

	public void setMrefersl(String mrefersl) {
		this.mrefersl = mrefersl;
	}

	public String getMreferyear() {
		return mreferyear;
	}

	public void setMreferyear(String mreferyear) {
		this.mreferyear = mreferyear;
	}

	public String getMshipperiodschedule() {
		return mshipperiodschedule;
	}

	public void setMshipperiodschedule(String mshipperiodschedule) {
		this.mshipperiodschedule = mshipperiodschedule;
	}

	public String getMtermsofprice() {
		return mtermsofprice;
	}

	public void setMtermsofprice(String mtermsofprice) {
		this.mtermsofprice = mtermsofprice;
	}

	public String getMtotaltenoramt() {
		return mtotaltenoramt;
	}

	public void setMtotaltenoramt(String mtotaltenoramt) {
		this.mtotaltenoramt = mtotaltenoramt;
	}

	public String getMtotaltenorcurr() {
		return mtotaltenorcurr;
	}

	public void setMtotaltenorcurr(String mtotaltenorcurr) {
		this.mtotaltenorcurr = mtotaltenorcurr;
	}

	public String getMtotliablimcurr() {
		return mtotliablimcurr;
	}

	public void setMtotliablimcurr(String mtotliablimcurr) {
		this.mtotliablimcurr = mtotliablimcurr;
	}

	/*
	 * public String getMtranchgschgssl() { return mtranchgschgssl; }
	 * 
	 * 
	 * 
	 * 
	 * public void setMtranchgschgssl(String mtranchgschgssl) {
	 * this.mtranchgschgssl = mtranchgschgssl; }
	 */

	public String getMtranstlmntinvnum() {
		return mtranstlmntinvnum;
	}

	public void setMtranstlmntinvnum(String mtranstlmntinvnum) {
		this.mtranstlmntinvnum = mtranstlmntinvnum;
	}

	public String getMtxnstatus() {
		return mtxnstatus;
	}

	public void setMtxnstatus(String mtxnstatus) {
		this.mtxnstatus = mtxnstatus;
	}

	public boolean isMusanceintborne() {
		return musanceintborne;
	}

	public void setMusanceintborne(boolean musanceintborne) {
		this.musanceintborne = musanceintborne;
	}

	public String getMuseroption() {
		return museroption;
	}

	public void setMuseroption(String museroption) {
		this.museroption = museroption;
	}

	public boolean isMwithinvalidityoflc() {
		return mwithinvalidityoflc;
	}

	public void setMwithinvalidityoflc(boolean mwithinvalidityoflc) {
		this.mwithinvalidityoflc = mwithinvalidityoflc;
	}

	public TFMChargesDetails getTfmchargesdetail() {
		return tfmchargesdetail;
	}

	public void setTfmchargesdetail(TFMChargesDetails tfmchargesdetail) {
		this.tfmchargesdetail = tfmchargesdetail;
	}

	public String getMrefertype() {
		return mrefertype;
	}

	public void setMrefertype(String mrefertype) {
		this.mrefertype = mrefertype;
	}

	public String getMaddamtcovered() {
		return maddamtcovered;
	}

	public void setMaddamtcovered(String maddamtcovered) {
		this.maddamtcovered = maddamtcovered;
	}

	public TranStlmntPostDetails getTranslmnt() {
		return translmnt;
	}

	public void setTranslmnt(TranStlmntPostDetails translmnt) {
		this.translmnt = translmnt;
	}

	public String getMlcdate() {
		return mlcdate;
	}

	public void setMlcdate(String mlcdate) {
		this.mlcdate = mlcdate;
	}

	public String getMenanchementreductionAmt() {
		return menanchementreductionAmt;
	}

	public void setMenanchementreductionAmt(String menanchementreductionAmt) {
		this.menanchementreductionAmt = menanchementreductionAmt;
	}

	public String getMenanchementreduction() {
		return menanchementreduction;
	}

	public void setMenanchementreduction(String menanchementreduction) {
		this.menanchementreduction = menanchementreduction;
	}

	public String getMchangeinlcliabinbasecurr() {
		return mchangeinlcliabinbasecurr;
	}

	public void setMchangeinlcliabinbasecurr(String mchangeinlcliabinbasecurr) {
		this.mchangeinlcliabinbasecurr = mchangeinlcliabinbasecurr;
	}

	public String getMlimitcurr() {
		return mlimitcurr;
	}

	public void setMlimitcurr(String mlimitcurr) {
		this.mlimitcurr = mlimitcurr;
	}

	public String getMxmlstring() {
		return mxmlstring;
	}

	public void setMxmlstring(String mxmlstring) {
		this.mxmlstring = mxmlstring;
	}

	public String getMlcamount() {
		return mlcamount;
	}

	public void setMlcamount(String mlcamount) {
		this.mlcamount = mlcamount;
	}

	private boolean Revalidate() {
		if (!revalidateOption()) {
			return false;
		}
		if (!revalidateBranchCode()) {
			return false;
		}
		if (!revalidateReferenceCode()) {
			return false;
		}
		if (!revalidateReferenceyear()) {
			return false;
		}
		if (!revalidateReferenceSl()) {
			return false;
		}
		if (!revalidateAmendnmentEntryDate()) {
			return false;
		}
		// added by navya on 27/06/19
		// Charges
		if (!revalSwiftCharges()) {
			return false;
		}
	// end
		/*
		 * if(!revalidateReasonForAmd()) { return false; }
		 */// commented on 17-Oct-2018
		if (mchangeofbenef == true) {
			if (!mbenefcode.equalsIgnoreCase("")) {
				if (!revalidateBenefCode(6, 1)) {
					return false;
				}
			} else {
				if (!revalidateBenefName(6, 1)) {
					return false;
				}
				if (!revalidateBenefAddr(6, 1)) {
					return false;
				}
				if (!revalidateBenefCountryCode(6, 1)) {
					return false;
				}
			}
		}

		// Changes in EOLCAMD on 16-Oct-2018 start

		if (AMEND_DC_REQ == true)
			dc_chkbox = 1;
		else
			dc_chkbox = 0;
		if (!menanchementreduction.equalsIgnoreCase("")) {

			if (!revalidateEncancementReductionAmount(2, dc_chkbox)) {
				return false;
			}
		}

		if (!revalidateEncancementReduction(2, dc_chkbox)) {
			return false;
		}

		if (AMEND_TOLERANCE_REQ == true)
			tolerance_chkbox = 1;
		else
			tolerance_chkbox = 0;

		if ((!mpostdevi.equalsIgnoreCase("")) && (!mpostdevi.equalsIgnoreCase("0.00"))) {
			if (!revalidatepositiveAmt(3, tolerance_chkbox)) {
				return false;
			}
		}
		if ((!mnegdevi.equalsIgnoreCase("")) && (!mnegdevi.equalsIgnoreCase("0.00"))) {
			if (!revalidatenegativeAmt(3, tolerance_chkbox)) {
				return false;
			}
		}

		if (!revalMaxCreditAmount(3, tolerance_chkbox)) {
			return false;
		}

		// Changes in EOLCAMD on 16-Oct-2018 end

		/*
		 * if(!revalidateAmtQual()) { return false; }
		 */

		if (!revalidateTermsOfPrice()) {
			return false;
		}

		// Changes in EOLCAMD on 16-Oct-2018 start

		if ((AMEND_ENQUIRY_REQ == true))
			enquiry_chkbox = 1;
		else
			enquiry_chkbox = 0;

		if (!revalidateLastDateOfNegociation(1, enquiry_chkbox)) {
			return false;
		}
		// if(!mlasetdateofneg.equalsIgnoreCase(""))
		// {
		if ((AMEND_SHIPMNT_REQ == true))
			shipmnt_chkbx = 1;
		else
			shipmnt_chkbx = 0;

		if (!revalidateLatestateOfShipment(5, shipmnt_chkbx)) {
			return false;
		}
		// } //commented on 17-Oct-2018

		if (!revalidateShipmentPeriod(5, shipmnt_chkbx)) {
			return false;
		}
		// Changes in EOLCAMD on 16-Oct-2018 end

		if (!revallcpsGrid1()) {
			return false;
		}

		if (Double.parseDouble(mtotalaftamd) > Double.parseDouble(mtotalbefamd)) {
			if (!revalidateConvRateToBaseCurr()) {
				return false;
			}
		}
		if (Double.parseDouble(mtotalbefamd) > Double.parseDouble(mtotalaftamd)) {
			if (!revalidateConvRateToLimitCurr()) {
				return false;
			}
		}

		// Changes P.Subramani-Chn21/10/2008 Beg
		if (!olcMarginCurr.equalsIgnoreCase("")) {
			if (!revalolcMaginCurr()) {
				return false;
			}
		}
		if (!revalidateolc()) {
			return false;
		}
		// Changes P.Subramani-Chn21/10/2008 End

		// Changes P.Subramani-Chn-23-06-20008 Beg
		if (!revalchargecode()) {
			return false;
		}
		// Changes P.Subramani-Chn-23-06-20008 End

		// Changes P.Subramani-Chn-27/02/2008
		// M.Murali - Changes - 18-05-2012 - Beg
		// if(!(tfmchargesdetail.getTRANCHGS_TOTAL_CHGS().equalsIgnoreCase("0.00"))
		// || (tfmchargesdetail.getTRANCHGS_TOTAL_CHGS().equalsIgnoreCase("0")))
		if (!(tfmchargesdetail.getTRANCHGS_TOTAL_CHGS().equalsIgnoreCase("0.00")) || !(tfmchargesdetail.getTRANCHGS_TOTAL_CHGS().equalsIgnoreCase("0")) || !(olcusnchgs.equalsIgnoreCase("0")) || !(olccommchgs.equalsIgnoreCase("0")))
		// M.Murali - Changes - 18-05-2012 - End
		{
			if (!revalcomp()) {
				return false;
			}
		}
		
		//ADDED BY PRASHANTH ON 13 MARCH 2019
		if (!revalGoodsTab()) {
			return false;
		}
		
		if (!revalDocsTab()) {
			return false;
		}
		
		
		if (!revalAddlTab()) {
			return false;
		}
		//ADDED BY PRASHANTH ON 13 MARCH 2019

		// Changes in EOLCAMD on 16-Oct-2018 start
		if (mrefertype.trim().equals("OLC"))

		{
			if ((AMEND_PLACE_REQ == true))
				place_chkbx = 1;
			else
				place_chkbx = 0;

			if (!revalSwiftPlaceOfTakingCharge(4, place_chkbx)) {
				return false;
			}

			if (!revalSwiftPortOfLoading(4, place_chkbx)) {
				return false;
			}

			if (!revalSwiftPortOfDischarge(4, place_chkbx)) {
				return false;
			}

			if (!revalSwift44(place_chkbx)) {
				return false;
			}

			if (!revalSwiftPortOfFinalDestination(4, place_chkbx)) {
				return false;
			}

			if (!revalSwiftSendToRecInfo()) {
				return false;
			}

			if (!revaldateofissue()) {
				return false;
			}
			//Changes Sanjay1 18-07-2019 Begin
//			if (!revalSwiftNarrative()) {
//				return false;
//			}
			//Changes Sanjay1 18-07-2019 End
			if (!revalReceiverbic()) {
				return false;
			}
			FetchOlcDetails();
			FetchSwiftDetails();

			// Changes in EOLCAMD on 16-Oct-2018 end
			// ADDED BY PRASHANTH ON 09 FEB 2019
			// Description of Goods and Services
			/*
			 * if (!revalSwiftDescriptionOfGoodsAndServices1()) { return false; }
			 * if (!revalSwiftDescriptionOfGoodsAndServices2()) { return false; }
			 * if (!revalSwiftDescriptionOfGoodsAndServices3()) { return false; }
			 *  // Documnets Required if (!revalSwiftDocumentsRequired1()) {
			 * return false; } if (!revalSwiftDocumentsRequired2()) { return
			 * false; } if (!revalSwiftDocumentsRequired3()) { return false; }
			 *  // Additional Conditions if (!revalSwiftAdditionalCondition1()) {
			 * return false; } if (!revalSwiftAdditionalCondition2()) { return
			 * false; } if (!revalSwiftAdditionalCondition3()) { return false; }
			 */
			// NEW TAB ADDED BY PRASHANTH ON 19 FEB 2019
			if (mrefertype.trim().equals("OLC") && !LC_FORM_OF_DOC_CREDIT.trim().equals("")) {
				if (!revalformOfCredit()) {
					return false;
				}
			}
			if (!revalApplName()) {
				return false;
			}
			if (!revalApplAddress()) {
				return false;
			}
			if (!revalApplRules()) {
				return false;
			}

			// Available..With..By

			//28 FEB 2019
			if (!revalAvlWithTab()) {
				return false;
			}
			//28 FEB 2019	

			if (!revalAvailableWithBankType()) {
				return false;
			}
			if (!LC_AVAILABLE_WITH_CODETYP.trim().equals("")) {
				if (!revalBankType(1, LC_AVAILABLE_WITH_TYPE, 2)) {
					return false;
				}
				if (!revalSwiftBankBic(1, LC_AVAILABLE_WITH_TYPE, LC_AVAILABLE_WITH_BIC_CODE, 2)) {
					return false;
				}

				if (!revalSwiftBranchCode(1, LC_AVAILABLE_WITH_TYPE, LC_AVAILABLE_WITH_BRN_CODE, 2)) {
					return false;
				}

				if (!revalSwiftBankName(1, LC_AVAILABLE_WITH_TYPE, LC_AVAILABLE_WITH_BNK_CODE, 2)) {
					return false;
				}

				if (!revalSwiftBankAddress(1, LC_AVAILABLE_WITH_TYPE, LC_AVAILABLE_WITH_ADDRESS, 2)) {
					return false;
				}

				if (!revalSwiftCountryCode(1, LC_AVAILABLE_WITH_TYPE, LC_AVAILABLE_WITH_CNTRY, 2)) {
					return false;
				}

				if (!revalSwiftRoutingId(1, LC_AVAILABLE_WITH_TYPE, LC_AVAILABLE_WITH_ROUTID, 2)) {
					return false;
				}
			}
			// Drafts At..
			if (!revalSwiftDraftsAt()) {
				return false;
			}

			// Available..With..By

			// Drawee
			//if (!revalDraweeReq()) {
			//		return false;
			// }
			
			
			//28 FEB 2019
			if (!revalDraweePaymentTab()) {
				return false;
			}
			//28 FEB 2019	

			if (LC_DRAWEE_REQ == true) {
				if (!revalBankType(1, LC_DRAWEE_TYPE, 3)) {
					return false;
				}
				if (!revalSwiftBankBic(1, LC_DRAWEE_TYPE, LC_DRAWEE_BIC_CODE, 3)) {
					return false;
				}

				if (!revalSwiftBranchCode(1, LC_DRAWEE_TYPE, LC_DRAWEE_BRN_CODE, 3)) {
					return false;
				}

				if (!revalSwiftBankName(1, LC_DRAWEE_TYPE, LC_DRAWEE_BNK_CODE, 3)) {
					return false;
				}

				if (!revalSwiftBankAddress(1, LC_DRAWEE_TYPE, LC_DRAWEE_ADDRESS, 3)) {
					return false;
				}

				if (!revalSwiftCountryCode(1, LC_DRAWEE_TYPE, LC_DRAWEE_CNTRY_CODE, 3)) {
					return false;
				}

				if (!revalSwiftRoutingId(1, LC_DRAWEE_TYPE, LC_DRAWEE_ROUTID, 3)) {
					return false;
				}
			}

			// Mixed Payment
			if (!revalSwiftMixedPaymentDetails()) {
				return false;
			}

			// Deferred Paymnet
			if (!revalSwiftDeferredPaymentDetails()) {
				return false;
			}

			// Reimbursing Bank
			
			//28 FEB 2019
			if (!revalReimbursementTab()) {
				return false;
			}
			//28 FEB 2019	
			
			
			if (!revalSwiftConfirmationInstruction()) {
				return false;
			}

			//Changes Sanjay1 18-07-2019 Begin
			/*if (!revalolcAdvThruBk()) {
				return false;
			}
			if (!revalolcAdvThruBrn()) {
				return false;
			}
			if (!revalolcAdvBrnName()) {
				return false;
			}*/
			
			if ((LC_CONFIRMATION_INST.equals("1")) || (LC_CONFIRMATION_INST.equals("2"))) {
				if (!revalBankType(1, LC_REIMB_CFM_TYPE, 6)) {
					return false;
				}
				if (!revalSwiftBankBic(1, LC_REIMB_CFM_TYPE, LC_REIMB_CFM_BIC_CODE, 6)) {
					return false;
				}

				if (!revalSwiftBranchCode(1, LC_REIMB_CFM_TYPE, LC_REIMB_CFM_BRN_CODE, 6)) {
					return false;
				}

				if (!revalSwiftBankName(1, LC_REIMB_CFM_TYPE, LC_CFM_REIMB_BNK_CODE, 6)) {
					return false;
				}

				if (!revalSwiftBankAddress(1, LC_REIMB_CFM_TYPE, LC_CFM_REIMB_ADDRESS, 6)) {
					return false;
				}

				if (!revalSwiftCountryCode(1, LC_REIMB_CFM_TYPE, LC_CFM_REIMB_CNTRY_CODE, 6)) {
					return false;
				}

				if (!revalSwiftRoutingId(1, LC_REIMB_CFM_TYPE, LC_CFM_REIMB_ROUTID, 6)) {
					return false;
				}
			}
			
			//Changes Sanjay1 18-07-2019 End
			if (LC_REIMB_REQ == true) {
				if (!revalBankType(1, LC_REIMB_TYPE, 4)) {
					return false;
				}
				if (!revalSwiftBankBic(1, LC_REIMB_TYPE, LC_REIMB_BIC_CODE, 4)) {
					return false;
				}

				if (!revalSwiftBranchCode(1, LC_REIMB_TYPE, LC_REIMB_BRN_CODE, 4)) {
					return false;
				}

				if (!revalSwiftBankName(1, LC_REIMB_TYPE, LC_REIMB_BNK_CODE, 4)) {
					return false;
				}

				if (!revalSwiftBankAddress(1, LC_REIMB_TYPE, LC_REIMB_ADDRESS, 4)) {
					return false;
				}

				if (!revalSwiftCountryCode(1, LC_REIMB_TYPE, LC_REIMB_CNTRY_CODE, 4)) {
					return false;
				}

				if (!revalSwiftRoutingId(1, LC_REIMB_TYPE, LC_REIMB_ROUTID, 4)) {
					return false;
				}
			}
			
			
			
			// reimbur bank tab

			// Advice Bank Tab

			if (!revalAdvReqd()) {
				return false;
			}

			if (LC_SECOND_ADV_REQ == true) {
				if (!revalBankType(1, LC_SECOND_ADV_TYPE, 5)) {
					return false;
				}
				if (!revalSwiftBankBic(1, LC_SECOND_ADV_TYPE, LC_SECOND_ADV_BIC_CODE, 5)) {
					return false;
				}

				if (!revalSwiftBranchCode(1, LC_SECOND_ADV_TYPE, LC_SECOND_ADV_BRN_CODE, 5)) {
					return false;
				}

				if (!revalSwiftBankName(1, LC_SECOND_ADV_TYPE, LC_SECOND_ADV_BNK_CODE, 5)) {
					return false;
				}

				if (!revalSwiftBankAddress(1, LC_SECOND_ADV_TYPE, LC_SECOND_ADV_ADDRESS, 5)) {
					return false;
				}

				if (!revalSwiftCountryCode(1, LC_SECOND_ADV_TYPE, LC_SECOND_ADV_CNTRYCODE, 5)) {
					return false;
				}

				if (!revalSwiftRoutingId(1, LC_SECOND_ADV_TYPE, LC_SECOND_ADV_ROUTID, 5)) {
					return false;
				}
			}
			// Advice Bank Tab

			// NEW TAB ADDED BY PRASHANTH ON 19 FEB 2019

		}

		// ADDED BY PRASHANTH ON 09 FEB 2019

		merrmsg = "";
		return true;
	}

	private boolean revalidateOption() {
		if (museroption.equalsIgnoreCase("")) {
			merrmsg = "MF:seluseroption|" + "Select Option";
			return false;
		}
		return true;
	}

	private boolean revalidateBranchCode() {
		inputDTO.clearMap();
		outputDTO.clearMap();
		inputDTO.setValue("OLC_BRN_CODE", mbranchcode);
		inputDTO.setValue("USER_ROLE_CODE", getM_UserRoleCode());// ADDED ON
		// 25/07/2018
		outputDTO = eolcamdvalinstance.olcBrnCodekeypress(inputDTO);
		if (!outputDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtBranchCode|" + outputDTO.getValue(ErrorKey).toString();
			return false;
		}

		_brnAuth = outputDTO.getValue("USER_BRN_AUTH");// ADDED ON 25/07/2018

		return true;
	}

	private boolean revalidateReferenceCode() {
		inputDTO.clearMap();
		outputDTO.clearMap();
		inputDTO.setValue("OLC_LC_TYPE", mrefertype);
		outputDTO = eolcamdvalinstance.olcLcTypekeypress(inputDTO);
		if (!outputDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtReferenceType|" + outputDTO.getValue(ErrorKey).toString();
			return false;
		}
		_tnomenNumChoice = outputDTO.getValue("TNOMEN_NUM_CHOICE");
		_tenomen_auto_num = outputDTO.getValue("TNOMEN_AUTO_NUM");
		_lcTypeAuth = outputDTO.getValue("BRN_AUTH_LCTYPE");// ADDED ON
		// 25/07/2018
		return true;
	}

	private boolean revalidateReferenceyear() {
		inputDTO.clearMap();
		outputDTO.clearMap();
		inputDTO.setValue("OLC_LC_YEAR", mreferyear);
		inputDTO.setValue("TNOMEN_NUM_CHOICE", _tnomenNumChoice);
		inputDTO.setValue("TNOMEN_AUTO_NUM", _tenomen_auto_num);
		inputDTO.setValue("BRANCH_CODE", mbranchcode);
		inputDTO.setValue("LC_TYPE", mrefertype);
		inputDTO.setValue("CBD", getM_CurrBusDate());
		outputDTO = eolcamdvalinstance.olcLcYearkeypress(inputDTO);
		if (!outputDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtReferenceYear|" + outputDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalidateReferenceSl() {
		inputDTO.clearMap();
		outputDTO.clearMap();
		inputDTO.setValue("OLC_LC_SL", mrefersl);
		inputDTO.setValue("BRANCH_CODE", mbranchcode);
		inputDTO.setValue("OLC_TYPE", mrefertype);
		inputDTO.setValue("OLC_YEAR", mreferyear);
		inputDTO.setValue("OLCA_AMD_SL", mamdsl);
		inputDTO.setValue("OPTION", museroption);
		outputDTO = eolcamdvalinstance.olcLcSlkeypress(inputDTO);
		if (!outputDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtReferenceSl|" + outputDTO.getValue(ErrorKey).toString();
			return false;
		}

		inputDTO.clearMap();
		outputDTO.clearMap();
		inputDTO.setValue("SQLToken", "valeolcamd4");
		String Args = mbranchcode + "|" + mrefertype + "|" + mreferyear + "|" + mrefersl + "|" + mamdsl;
		inputDTO.setValue("Args", Args);
		inputDTO.setValue("DataTypes", "N|S|N|N|N");
		outputDTO = QueryManagerInstance.getInfo(inputDTO);
		if (outputDTO.getValue("Result").equalsIgnoreCase("RowPresent")) {
			museroption = "M";
			mtranstlmntinvnum = outputDTO.getValue("TRANSTLMNT_INV_NUM");
			mtranchgschgssl = outputDTO.getValue("TRANCHGS_CHGS_SL");
			_olca_entry_date = molcaentrydate;
			postbrn = outputDTO.getValue("POST_TRAN_BRN");
			postdate = outputDTO.getValue("POST_TRAN_DATE");
			postbatchnum = outputDTO.getValue("POST_TRAN_BATCH_NUM");

		} else if (outputDTO.getValue("Result").equalsIgnoreCase("RowNotPresent")) {
			museroption = "A";
			if (mamdsl.equalsIgnoreCase("1")) {
				mtranchgschgssl = "0";
				mtranstlmntinvnum = "0";
			} else {
				mtranchgschgssl = maddtranchgs;
				mtranstlmntinvnum = maddtranstlmntinvnum;
			}
		}

		return true;
	}

	private boolean revalidateAmendnmentEntryDate() {
		inputDTO.clearMap();
		outputDTO.clearMap();
		inputDTO.setValue("AMENDMENT_ENTRY_DATE", mamdentrydate);
		inputDTO.setValue("CBD", getM_CurrBusDate());
		inputDTO.setValue("LC_DATE", mlcdate);
		outputDTO = eolcamdvalinstance.ircrTranDatekeypress(inputDTO);
		if (!outputDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtAmendmentEntryDate|" + outputDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	/*
	 * private boolean revalidateReasonForAmd() { inputDTO.clearMap();
	 * outputDTO.clearMap(); if(mreasonforamd.equalsIgnoreCase("")) {
	 * merrmsg="MF:txtReasonForAmendment|"+"Select Option"; return false; }
	 * return true; }
	 */// commented on 17-Oct-2018
	private boolean revalidateBenefCode(int fieldno, int chkbox) {
		inputDTO.clearMap();
		outputDTO.clearMap();
		inputDTO.setValue("BENEF_CODE", mbenefcode);
		// Changes in EOLCAMD on 16-Oct-2018 start
		inputDTO.setValue("AMEND_FIELDNO", String.valueOf(fieldno));
		inputDTO.setValue("AMEND_CHKBOX", String.valueOf(chkbox));
		inputDTO.setValue("OLC_LC_TYPE", mrefertype);
		// Changes in EOLCAMD on 16-Oct-2018 end
		outputDTO = eolcamdvalinstance.olcBenefCodekeypress(inputDTO);
		if (!outputDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtBeneficiaryCode|" + outputDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalidateBenefName(int fieldno, int chkbox) {
		// Changes in EOLCAMD on 16-Oct-2018 start
		inputDTO.clearMap();
		outputDTO.clearMap();
		inputDTO.setValue("LC_BENF_NAME", mbenefname);
		inputDTO.setValue("AMEND_FIELDNO", String.valueOf(fieldno));
		inputDTO.setValue("AMEND_CHKBOX", String.valueOf(chkbox));
		outputDTO = eolcamdvalinstance.Beneficiary_Name_KeyPress(inputDTO);
		if (!outputDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtBeneficiaryName|" + outputDTO.getValue(ErrorKey).toString();
			return false;
		}
		// Changes in EOLCAMD on 16-Oct-2018 end
		/*
		 * if(mbenefname.equalsIgnoreCase("")) {
		 * merrmsg="MF:txtBeneficiaryName|"+"Should not be blank"; return false; }
		 * commented on 17-Oct-2018
		 */
		return true;
	}

	private boolean revalidateBenefAddr(int fieldno, int chkbox) {
		// Changes in EOLCAMD on 16-Oct-2018 start
		inputDTO.clearMap();
		outputDTO.clearMap();
		inputDTO.setValue("LC_BENF_ADDRESS", mbenefaddr);
		inputDTO.setValue("AMEND_FIELDNO", String.valueOf(fieldno));
		inputDTO.setValue("AMEND_CHKBOX", String.valueOf(chkbox));
		outputDTO = eolcamdvalinstance.Beneficiary_Address_KeyPress(inputDTO);
		if (!outputDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtAddress1|" + outputDTO.getValue(ErrorKey).toString();
			return false;
		}
		// Changes in EOLCAMD on 16-Oct-2018 end
		String[] count = null;
		String a1, a2, a3, a4, a5;

		/*
		 * if(mbenefaddr.equalsIgnoreCase("")) { merrmsg ="MF:txtAddress1|Should
		 * not be blank"; return false ; }commented on 17-Oct-2018
		 */

		if (!(mbenefaddr.equalsIgnoreCase(""))) {
			count = mbenefaddr.split("\n");
			a1 = count[0].trim();
			a2 = ((count.length > 1) ? count[1].trim() : " ");
			a3 = ((count.length > 2) ? count[2].trim() : " ");
			a4 = ((count.length > 3) ? count[3].trim() : " ");
			a5 = ((count.length > 4) ? count[4].trim() : " ");

			if ((a1.length() > 35) || (a2.length() > 35) || (a3.length() > 35) || (a4.length() > 35) || (a5.length() > 35)) {

				merrmsg = "MF:txtAddress1|Only 35 Characters Allowed In A Line";
				return false;
			}
		}
		return true;

	}

	private boolean revalidateBenefCountryCode(int fieldno, int chkbox) {
		inputDTO.clearMap();
		outputDTO.clearMap();
		inputDTO.setValue("OLC_COUNTRY_CODE", mbenefcountrycode);
		// Changes in EOLCAMD on 16-Oct-2018 start
		inputDTO.setValue("AMEND_FIELDNO", String.valueOf(fieldno));
		inputDTO.setValue("AMEND_CHKBOX", String.valueOf(chkbox));
		// Changes in EOLCAMD on 16-Oct-2018 end
		outputDTO = eolcamdvalinstance.olcBenefCountryCodekeypress(inputDTO);
		if (!outputDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtBeneficiaryCountryCode|" + outputDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalidateEncancementReductionAmount(int fieldno, int chkbox) {
		if (fieldno == 2 && chkbox == 1 && menanchementreductionAmt.equalsIgnoreCase("") && menanchementreductionAmt.equals("0.00")) {
			merrmsg = "MF:txtEnhancementReductionAmount1|" + "Should not be blank";
			return false;
		} else if (fieldno == 2 && chkbox == 0 && !(menanchementreductionAmt.equalsIgnoreCase("")) && !menanchementreductionAmt.equals("0.00")) {
			if (mrefertype.trim().equals("OLC"))
				merrmsg = "MF:txtEnhancementReductionAmount1|" + "F32B/F32DIncrease/Decrease Of DC checkbox Should be Checked";
			else
				merrmsg = "MF:txtEnhancementReductionAmount1|" + "L/C Enhancement /Reduction / No change checkbox Should be Checked";
			return false;
		}

		// Changes P.Subramani-Chn01/04/2008 Beg
		if (menanchementreduction.equalsIgnoreCase("R")) {
			if (Double.parseDouble(menanchementreductionAmt) >= Double.parseDouble(lcAmt)) {
				merrmsg = "MF:txtEnhancementReductionAmount1|" + "Reduction Amount Should be < LC Amount";
				return false;
			}
		}
		// Changes P.Subramani-Chn01/04/2008 End
		return true;
	}

	private boolean revalidatepositiveAmt(int fieldno, int chkbox) {
		double pos = 0.0;
		String s[] = null;
		inputDTO.clearMap();
		outputDTO.clearMap();
		inputDTO.setValue("POST_DEVI", mpostdevi);
		// Changes in EOLCAMD on 16-Oct-2018 start
		inputDTO.setValue("AMEND_FIELDNO", String.valueOf(fieldno));
		inputDTO.setValue("AMEND_CHKBOX", String.valueOf(chkbox));
		// Changes in EOLCAMD on 16-Oct-2018 end
		outputDTO = eolcamdvalinstance.olcPositiveDeviationkeypress(inputDTO);
		if (!outputDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtDeviationAllowed|" + outputDTO.getValue(ErrorKey).toString();
			return false;
		}
		// ADDED ON 08/11/2018 START

		if (!mpostdevi.trim().equals("")) {
			pos = Double.parseDouble(mpostdevi);
			s = mpostdevi.trim().split("\\.");

			if (!(pos <= 100)) {
				merrmsg = "MF:txtDeviationAllowed|Should be <= 100";
				return false;
			} else if ((pos - (int) pos) != 0) {
				merrmsg = "MF:txtDeviationAllowed|Decimal is not allowed ";
				return false;
			} else if (s[0].length() > 2) {
				merrmsg = "MF:txtDeviationAllowed|Length should two digit ";
				return false;
			}
		}
		// ADDED ON 08/11/2018 END
		return true;
	}

	private boolean revalidatenegativeAmt(int fieldno, int chkbox) {
		double neg;
		String s1[] = null;
		// Changes in EOLCAMD on 16-Oct-2018 start
		if (fieldno == 3 && chkbox == 1 && mnegdevi.equalsIgnoreCase("")/*
		 * &&
		 * mnegdevi.equals("0.00")
		 */) {
			merrmsg = "MF:txtDeviationAllowed1|" + "Should not be blank";
			return false;
		} else if (fieldno == 3 && chkbox == 0 && !(mnegdevi.equalsIgnoreCase("")) /*
		 * &&
		 * !mnegdevi.equals("0.00")
		 */) {
			if (Double.parseDouble(mnegdevi) > 0.0) {
				if (mrefertype.trim().equals("OLC"))
					merrmsg = "MF:txtDeviationAllowed1|" + "F39B Max Credit Amount Checkbox Should be Checked";
				else
					merrmsg = "MF:txtDeviationAllowed1|" + "Deviation Allowed/Amount Checkbox Should be Checked";
			}
			return false;
		}
		// Changes in EOLCAMD on 16-Oct-2018 end
		if ((Double.parseDouble(mnegdevi) > 100)) {
			merrmsg = "MF:txtDeviationAllowed1|should be <= 100";
			return false;
		}

		if (!mnegdevi.trim().equals("")) {
			neg = Double.parseDouble(mnegdevi);
			s1 = mnegdevi.trim().split("\\.");

			if (!(neg <= 100)) {
				merrmsg = "MF:txtDeviationAllowed1|Should be <= 100";
				return false;
			} else if ((neg - (int) neg) != 0) {
				merrmsg = "MF:txtDeviationAllowed1|Decimal is not allowed ";
				return false;
			} else if (s1[0].length() > 2) {
				merrmsg = "MF:txtDeviationAllowed1|Length should two digit ";
				return false;
			}

		}

		return true;
	}

	private boolean revalidateAmtQual() {
		if (mamtqualifier.equalsIgnoreCase("")) {
			merrmsg = "MF:lstAmountQualifier| should not be blank";
			return false;
		}
		return true;
	}

	private boolean revalidateTermsOfPrice() {
		inputDTO.clearMap();
		outputDTO.clearMap();
		inputDTO.setValue("TERMS_OF_PRICE", mtermsofprice);
		outputDTO = eolcamdvalinstance.olcTermsOfPricekeypress(inputDTO);
		if (!outputDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtTermsofPrice|" + outputDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalidateLastDateOfNegociation(int fieldno, int chkbox) {
		inputDTO.clearMap();
		outputDTO.clearMap();
		inputDTO.setValue("LAST_DATE_NEGOCIATION", mlasetdateofneg);
		inputDTO.setValue("AMD_DATE", mamdentrydate);
		// Changes in EOLCAMD on 16-Oct-2018 start
		inputDTO.setValue("AMEND_FIELDNO", String.valueOf(fieldno));
		inputDTO.setValue("AMEND_CHKBOX", String.valueOf(chkbox));
		// Changes in EOLCAMD on 16-Oct-2018 end
		outputDTO = eolcamdvalinstance.olclastDatekeypress(inputDTO);
		if (!outputDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtLastDateforNegotiation|" + outputDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalidateLatestateOfShipment(int fieldno, int chkbox) {
		inputDTO.clearMap();
		outputDTO.clearMap();
		inputDTO.setValue("LATEST_DATE_OF_SHIPMENT", mlatestdateforship);
		inputDTO.setValue("ENTRY_DATE", mamdentrydate);
		inputDTO.setValue("NEGOCIATION_DATE", mlasetdateofneg);
		// Changes in EOLCAMD on 16-Oct-2018 start
		inputDTO.setValue("AMEND_FIELDNO", String.valueOf(fieldno));
		inputDTO.setValue("AMEND_CHKBOX", String.valueOf(chkbox));
		inputDTO.setValue("LC_SHPMNT_PERIOD", mshipperiodschedule);
		// Changes in EOLCAMD on 16-Oct-2018 end
		outputDTO = eolcamdvalinstance.olcLatestdateofShipmentkeypress(inputDTO);
		if (!outputDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtLatestDateofShipment|" + outputDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalidateConvRateToBaseCurr() {
		inputDTO.clearMap();
		outputDTO.clearMap();
		inputDTO.setValue("LC_CURR", mlccurr);
		inputDTO.setValue("BASE_CURR", getM_BCurrCode());
		inputDTO.setValue("ADD_LC_LIAB_AMT", maddliabbasecurr);
		// M.Murali - Added - 16-05-2012 - Beg
		inputDTO.setValue("ENC_RED", menanchementreduction);
		inputDTO.setValue("RED_LC_LIAB_AMT", mreductioninlcliabinbasecurr);
		// M.Murali - Added - 16-05-2012 - End
		inputDTO.setValue("CONV_RATE", mconvratebasecurr);
		inputDTO.setValue("TOTAL_AFT_AMD", mtotalaftamd);
		// Vinoth S Changes on 24-Dec-2010 Beg
		inputDTO.setValue("TRAN_DATE", molcaentrydate);
		inputDTO.setValue("TYPE", "N");
		// Vinoth S Changes on 24-Dec-2010 End
		outputDTO = eolcamdvalinstance.olcConvToBaseCurrkeypress(inputDTO);
		if (!outputDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtConvRatetobasecurr|" + outputDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalidateConvRateToLimitCurr() {
		inputDTO.clearMap();
		outputDTO.clearMap();
		inputDTO.setValue("LC_CURR", mlccurr);
		inputDTO.setValue("BASE_CURR", mchangeinlcliabinbasecurrfield);
		inputDTO.setValue("ADD_LC_LIAB_AMT", mchangeinlcliabinbasecurr);
		inputDTO.setValue("CONV_RATE", mconvratelimcurr);
		// Vinoth S Changes on 24-Dec-2010 Beg
		inputDTO.setValue("TRAN_DATE", molcaentrydate);
		inputDTO.setValue("TYPE", "N");
		// Vinoth S Changes on 24-Dec-2010 End
		outputDTO = eolcamdvalinstance.olcConvToLimitCurrkeypress(inputDTO);
		if (!outputDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtConvRateToLimitCurrency|" + outputDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	// -------------------------------Grid
	// Re-Validation------------------------------------------------------------------------------------------------------
	private boolean revallcpsGrid1() {
		int row = 0;
		String slabserial = "";
		String tenortype = "";
		String tenoramt = "";
		String usancedays = "";
		String usanceperiod = "";
		String otherdate = "";
		String othdateforup = "";
		String interestrate = "";
		String prevusanceamt = "";
		String usanceamt = "";
		String docdel = "";
		String prevtenortype = null;

		if (mxmlstring.equalsIgnoreCase("")) {
			merrmsg = "MF:gridEolcamd|Please Press F12 And Then Save|" + 1 + "|ttype";
			return false;
		}
		try {
			revallcpsGrid1.setXMLFormat("valeolcamdOLCTENORS", "panacea.common", mxmlstring);
		}

		catch (Exception e) {
			e.printStackTrace();
		}

		if ((revallcpsGrid1.getRowcount()) < 1) {
			merrmsg = "MF:gridEolcamd|Atleast One Row Should Be Present In The Grid|" + 1 + "|ttype";
			return false;

		}

		for (row = 0; row < revallcpsGrid1.getRowcount(); row++) {
			slabserial = String.valueOf(row + 1);
			tenortype = revallcpsGrid1.GetValue(row, "OLCTA_TENOR_TYPE");
			tenoramt = revallcpsGrid1.GetValue(row, "OLCTA_TENOR_AMT");
			usancedays = revallcpsGrid1.GetValue(row, "OLCTA_USANCE_PERD");
			usanceperiod = revallcpsGrid1.GetValue(row, "OLCTA_USANCE_FROM");
			otherdate = revallcpsGrid1.GetValue(row, "OLCTA_OTHER_DATE_DESC");
			othdateforup = revallcpsGrid1.GetValue(row, "OLCTA_OTHER_DATE_START_FROM");
			interestrate = revallcpsGrid1.GetValue(row, "OLCTA_USANCE_INT_RATE");
			prevusanceamt = revallcpsGrid1.GetValue(row, "OLCTA_PREV_AMT_FOR_COMM");
			usanceamt = revallcpsGrid1.GetValue(row, "OLCTA_USANCE_INT_AMT");
			docdel = revallcpsGrid1.GetValue(row, "OLCTA_DOC_DELIVERY");

			if (Integer.parseInt(slabserial) > 1) {
				prevtenortype = revallcpsGrid1.GetValue(row - 1, "OLCT_TENOR_TYPE");
			}

			if (revallcpsGrid1.GetValue(row, "OLCT_TENOR_TYPE").equalsIgnoreCase("")) {
				merrmsg = "MF:gridEolcamd|Select Option|" + (row + 1) + "|ttype";
				merrxmlstr1 = "MF:gridEolcamd|Select Option|" + (row + 1) + "|ttype";
				return false;
			}

			if (tenortype.equalsIgnoreCase("S")) {
				// if(!(usancedays.equalsIgnoreCase("0")))
				// {
				// merrmsg = "MF:gridEolcamd|Usance Days Should Be Zero|"+ (row
				// + 1) + "|udays";
				// merrxmlstr1= "MF:gridEolcamd|Usance Days Should Be Zero|"+
				// (row + 1) + "|udays";
				// return false;
				// }
				// Changes P.Subramani-Chn-11/09/2008 Beg
				if (!(usanceamt.equalsIgnoreCase("0.00"))) {
					merrmsg = "MF:gridEolcamd|Usance Interest Amount Should Be Zero|" + (row + 1) + "|usanceintamt,";
					merrxmlstr1 = "MF:gridEolcamd|Usance Interest Amount Should Be Zero|" + (row + 1) + "|usanceintamt,";
					return false;
				}
				// Changes P.Subramani-Chn-11/09/2008 End
				else if (!(docdel.equalsIgnoreCase("2"))) {
					merrmsg = "MF:gridEolcamd|Document Delivery Should Be DP|" + (row + 1) + "|docdelivery";
					merrxmlstr1 = "MF:gridEolcamd|Document Delivery Should Be DP|" + (row + 1) + "|docdelivery";
					return false;
				}
				// Changes P.Subramani-Chn18/08/2008 BEg
				if (Integer.parseInt(slabserial) > 1) {
					if (prevtenortype.equalsIgnoreCase("S")) {
						merrmsg = "MF:gridEolcamd|Sight Should not be Duplicated|" + (row + 1) + "|ttype";
						merrxmlstr1 = "MF:gridEolcamd|Sight Should not be Duplicated|" + (row + 1) + "|ttype";
						return false;
					}
				}
				// Changes P.Subramani-Chn18/08/2008 End
			}

			// Changes P.Subramani-Chn-29/02/2008
			double totamdamt = Double.parseDouble(mamdamt);// /Changes
			// P.Subramani-Chn18/08/2008//+
			// Double.parseDouble(mdeviamt);

			if (!tenoramt.equalsIgnoreCase(""))

			{
				outputDTO.clearMap();
				inputDTO.clearMap();
				inputDTO.setValue("TENOR_AMT", tenoramt);
				inputDTO.setValue("LC_AMT", String.valueOf(totamdamt));
				inputDTO.setValue("DRAW_DOWNS", mdrawdowns);
				inputDTO.setValue("TOTAL_TENOR_AMT", mtotaltenoramt);
				inputDTO.setValue("NO_OF_ROWS", slabserial);
				outputDTO = eolcamdvalinstance.olcTenorAmtkeypress(inputDTO);
				if (!outputDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
					merrmsg = "MF:gridEolcamd|" + outputDTO.getValue(ErrorKey).toString();
					merrxmlstr1 = "MF:gridEolcamd|" + outputDTO.getValue(ErrorKey).toString();
					return false;
				}
			}

			if (tenortype.equalsIgnoreCase("U")) {
				if (revallcpsGrid1.GetValue(row, "OLCT_USANCE_PERD").equalsIgnoreCase("")) {
					merrmsg = "MF:gridEolcamd|Should not be blank|" + (row + 1) + "|udays";
					merrxmlstr1 = "MF:gridEolcamd|Should not be blank|" + (row + 1) + "|udays";
					return false;
				} else if (revallcpsGrid1.GetValue(row, "OLCT_USANCE_FROM").equalsIgnoreCase("0")) {
					merrmsg = "MF:gridEolcamd|Should not be zero|" + (row + 1) + "|udays";
					merrxmlstr1 = "MF:gridEolcamd|Should not be zero|" + (row + 1) + "|udays";
					return false;
				}
			}

			if (revallcpsGrid1.GetValue(row, "OLCT_DOC_DELIVERY").equalsIgnoreCase("")) {
				merrmsg = "MF:gridEolcamd|Should not be blank|" + (row + 1) + "|docdelivery";
				merrxmlstr1 = "MF:gridEolcamd|Should not be blank|" + (row + 1) + "|docdelivery";
				return false;
			}

		}
		return true;
	}

	// Changes P.Subramani-Chn21/10/2008 Beg
	private boolean revalolcMaginCurr() {
		inputDTO.clearMap();
		outputDTO.clearMap();
		inputDTO.setValue("OLC_LC_CURR", olcMarginCurr);
		outputDTO = eolcamdvalinstance.olcLcCurrkeypress(inputDTO);
		if (!outputDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtmargincurr|" + outputDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	// Changes P.Subramani-Chn21/10/2008 End

	// Changes P.Subramani-Chn-19-06-2008 Beg
	private boolean revalchargecode() {
		inputDTO.clearMap();
		outputDTO.clearMap();
		inputDTO.setValue("TRCHG_FACILITY_CURR", mlccurr);
		inputDTO.setValue("TRCHG_NOMEN_CODE", mrefertype);
		outputDTO = eolcamdvalinstance.OlcChargeComp(inputDTO);
		if (!outputDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtusnchgsamt1|" + outputDTO.getValue(ErrorKey).toString();
			return false;
		}
		usancechgcode = outputDTO.getValue("TRCHG_USANCE_CHGCD");
		commchgcode = outputDTO.getValue("TRCHG_COMMITMNT_CHGCD");
		return true;
	}

	// Changes P.Subramani-Chn-19-06-2008 End

	private boolean revalcomp() {
		if (translmnt != null) {
			if (!translmnt.isValid()) {
				merrmsg = translmnt.getErrMsg();
				return false;
			} else
				return true;
		} else
			return true;
	}
	//ADDED BY PRASHANTH ON 13 MARCH 2019

	
	private boolean revalGoodsTab(){
		if(!(oldchkChgDesc.equals(String.valueOf(chkChgDesc))))
		{
			if (chkChgDesc && txtAmdLog.trim().equals(""))
			{
				merrmsg = "MF:txtApplInsOrRepl|" + "Goods Should be changed when Change in Description of Goods and / or Services is checked";
				return false;
			}
		}
		return true;
	}
	
	private boolean revalDocsTab(){
		if(!(oldchkChgDoc.equals(String.valueOf(chkChgDoc))))
		{
			if (chkChgDoc && txtAmdLogDoc.trim().equals(""))
			{
				merrmsg = "MF:txtApplInsOrReplDoc|" + "Documents  Should be changed when Change in Documents is checked";
				return false;
			}
		}
		return true;
	}


	private boolean revalAddlTab(){
		if(!(oldchkChgAddCond.equals(String.valueOf(chkChgAddCond))))
		{
			if (chkChgAddCond && txtAmdLogAddl.trim().equals(""))
			{
				merrmsg = "MF:txtApplInsOrReplAddl|" + "Additional Conditions  Should be changed when Change in Additional Conditions is checked";
				return false;
			}
		}
		return true;
	}
	//ADDED BY PRASHANTH ON 13 MARCH 2019

	

	// Changes P.Subramani-Chn-21/10/2008 Beg
	private boolean revalidateolc() {
		inputDTO.clearMap();
		outputDTO.clearMap();
		inputDTO.setValue("BRANCH_CODE", mbranchcode);
		inputDTO.setValue("OLC_TYPE", mrefertype);
		inputDTO.setValue("OLC_YEAR", mreferyear);
		inputDTO.setValue("OLC_LC_SL", mrefersl);
		outputDTO = eolcamdvalinstance.olcmarginkeypress(inputDTO);
		if (!outputDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtReferenceSl|" + outputDTO.getValue(ErrorKey).toString();
			return false;
		}
		olcmarginamt = outputDTO.getValue("OLC_MARGIN_AMT");
		olcmarginbal = outputDTO.getValue("OLC_MARGIN_BAL");
		// Changes P.Subramani-Chn-26/03/2009
		olccashmaramt = outputDTO.getValue("OLC_CASH_MAR_AMT");
		olccashmarbal = outputDTO.getValue("OLC_CASH_MAR_BAL");
		return true;
	}

	// Changes P.Subramani-Chn-21/10/2008 End

	// Changes in EOLCAMD on 16-Oct-2018 start
	private boolean revalSwiftPlaceOfTakingCharge(int fieldno, int chkbox) {
		inputDTO.clearMap();
		outputDTO.clearMap();
		inputDTO.setValue("AMEND_FIELDNO", String.valueOf(fieldno));
		inputDTO.setValue("AMEND_CHKBOX", String.valueOf(chkbox));
		inputDTO.setValue("LC_PLACE_CHARGE", AMEND_PLACE_TAKIN_IN_CHRG);
		outputDTO = eolcamdvalinstance.Place_Of_Charge_KeyPress(inputDTO);
		if (!outputDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtTakCharge|" + outputDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalSwiftPortOfLoading(int fieldno, int chkbox) {

		inputDTO.clearMap();
		outputDTO.clearMap();
		inputDTO.setValue("AMEND_FIELDNO", String.valueOf(fieldno));
		inputDTO.setValue("AMEND_CHKBOX", String.valueOf(chkbox));
		inputDTO.setValue("LC_PLACE_CHARGE", AMEND_PORT_OF_LOADING);
		outputDTO = eolcamdvalinstance.Place_Of_Charge_KeyPress(inputDTO);
		if (!outputDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtPortLoad|" + outputDTO.getValue(ErrorKey).toString();
			return false;
		}

		return true;
	}

	private boolean revalSwiftPortOfDischarge(int fieldno, int chkbox) {
		inputDTO.clearMap();
		outputDTO.clearMap();
		inputDTO.setValue("AMEND_FIELDNO", String.valueOf(fieldno));
		inputDTO.setValue("AMEND_CHKBOX", String.valueOf(chkbox));
		inputDTO.setValue("LC_PLACE_CHARGE", AMEND_PORT_OF_DISCHARGE);
		outputDTO = eolcamdvalinstance.Place_Of_Charge_KeyPress(inputDTO);
		if (!outputDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtPortDis|" + outputDTO.getValue(ErrorKey).toString();
			return false;
		}

		return true;
	}

	private boolean revalSwiftPortOfFinalDestination(int fieldno, int chkbox) {

		inputDTO.clearMap();
		outputDTO.clearMap();
		inputDTO.setValue("AMEND_FIELDNO", String.valueOf(fieldno));
		inputDTO.setValue("AMEND_CHKBOX", String.valueOf(chkbox));
		inputDTO.setValue("LC_PLACE_CHARGE", AMEND_PLACE_OF_FINAL_DEST);
		outputDTO = eolcamdvalinstance.Place_Of_Charge_KeyPress(inputDTO);
		if (!outputDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtPortDest|" + outputDTO.getValue(ErrorKey).toString();
			return false;
		}

		return true;
	}

	private boolean revalSwift44(int chkbox) {
		if (chkbox == 1) {
			int ii = 0;
			if (!AMEND_PLACE_OF_FINAL_DEST.trim().equals(""))
				ii++;
			if (!AMEND_PORT_OF_DISCHARGE.trim().equals(""))
				ii++;
			if (!AMEND_PORT_OF_LOADING.trim().equals(""))
				ii++;
			if (!AMEND_PLACE_TAKIN_IN_CHRG.trim().equals(""))
				ii++;

			if (ii < 2) {
				merrmsg = "MF:txtPortDest|" + "Atleast two textbox from F44A to F44F should be added";
				return false;
			}

		}

		return true;
	}

	private boolean revalSwiftSendToRecInfo() {
		send_to_rec = null;
		if (!(AMEND_SNDR_REC_INFO.trim().equals(""))) {
			send_to_rec = AMEND_SNDR_REC_INFO.split("\n");
			a1 = send_to_rec[0].trim();
			a2 = ((send_to_rec.length > 1) ? send_to_rec[1].trim() : " ");
			a3 = ((send_to_rec.length > 2) ? send_to_rec[2].trim() : " ");
			a4 = ((send_to_rec.length > 3) ? send_to_rec[3].trim() : " ");
			a5 = ((send_to_rec.length > 4) ? send_to_rec[4].trim() : " ");
			a6 = ((send_to_rec.length > 5) ? send_to_rec[5].trim() : " ");
			if ((a1.length() > 35) || (a2.length() > 35) || (a3.length() > 35) || (a4.length() > 35) || (a5.length() > 35) || (a6.length() > 35)) {
				merrmsg = "MF:txtSendInfo|Only 35 Characters Allowed In A Line";
				return false;
			}
		} 
		//Changes Sanjay1 18-07-2019 Begin
		/*else {
			if (mrefertype.trim().equalsIgnoreCase("OLC")) {
				merrmsg = "MF:txtSendInfo|Should not be Blank";
				return false;
			}

		}*/
		//Changes Sanjay1 18-07-2019 End
		return true;
	}

	private boolean revaldateofissue() {
		inputDTO.clearMap();
		outputDTO.clearMap();
		inputDTO.setValue("OLC_BRN_CODE", mbranchcode);
		inputDTO.setValue("OLC_TYPE", mrefertype);
		inputDTO.setValue("OLC_YEAR", mreferyear);
		inputDTO.setValue("OLC_SERIAL", mrefersl);
		inputDTO.setValue("LC_DATE_OF_ISSUE", AMEND_DATE_OF_ISSUE);

		outputDTO = eolcamdvalinstance.Date_Of_Issue_KeyPress(inputDTO);
		if (!outputDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtDateOfIssue|" + outputDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalidateShipmentPeriod(int fieldno, int chkbox) {
		inputDTO.clearMap();
		outputDTO.clearMap();
		inputDTO.setValue("AMEND_FIELDNO", String.valueOf(fieldno));
		inputDTO.setValue("AMEND_CHKBOX", String.valueOf(chkbox));
		inputDTO.setValue("LC_SHPMNT_PERIOD", mshipperiodschedule);
		inputDTO.setValue("OLC_TYPE", mrefertype);// ADDED ON 05/10/2018
		inputDTO.setValue("LATEST_DATE_OF_SHIPMENT", mlatestdateforship);// ADDED
		// ON
		// 05/10/2018
		outputDTO = eolcamdvalinstance.Shipment_Period_KeyPress(inputDTO);
		if (!outputDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtShipmentPeriodSchedule|" + outputDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalidateEncancementReduction(int fieldno, int chkbox) {
		if (fieldno == 2 && chkbox == 1 && menanchementreduction.equalsIgnoreCase("")) {
			merrmsg = "MF:txtLCEnhancementReductionNochange|" + "Should not be blank";
			return false;
		} else if (fieldno == 2 && chkbox == 0 && !(menanchementreduction.equalsIgnoreCase(""))) {
			if (mrefertype.trim().equals("OLC"))
				merrmsg = "MF:txtLCEnhancementReductionNochange|" + "F32B/F32DIncrease/Decrease Of DC checkbox Should be Checked";
			else
				merrmsg = "MF:txtLCEnhancementReductionNochange|" + "L/C Enhancement /Reduction / No change checkbox Should be Checked";
			return false;
		}

		return true;
	}

	private boolean FetchOlcDetails() {
		inputDTO.clearMap();
		outputDTO.clearMap();
		inputDTO.setValue("OLC_BRN_CODE", mbranchcode);
		inputDTO.setValue("OLC_LC_TYPE", mrefertype);
		inputDTO.setValue("OLC_LC_YEAR", mreferyear);
		inputDTO.setValue("OLC_LC_SL", mrefersl);
		outputDTO = eolcamdvalinstance.CaseOne(inputDTO);
		olcrefnum = outputDTO.getValue("OLC_CORR_REF_NUM");
		if (!outputDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtReferenceSl|" + outputDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean FetchSwiftDetails() {
		inputDTO.clearMap();
		outputDTO.clearMap();
		inputDTO.setValue("OLC_BRN_CODE", mbranchcode);
		inputDTO.setValue("OLC_LC_TYPE", mrefertype);
		inputDTO.setValue("OLC_LC_YEAR", mreferyear);
		inputDTO.setValue("OLC_LC_SL", mrefersl);

		outputDTO = eolcamdvalinstance.SwiftDetails(inputDTO);
		receiver_bic = outputDTO.getValue("LC_REC_BIC_CODE");
		place_tkn_chrg = outputDTO.getValue("LC_PLACE_OF_TAKING_IN_CHARGE");
		port_of_loading = outputDTO.getValue("LC_PORT_OF_LOADING");
		port_of_dischrg = outputDTO.getValue("LC_PORT_OF_DISCHARGE");
		place_finl_detination = outputDTO.getValue("LC_PLACE_OF_FINAL_DEST");
		if (!outputDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtReferenceSl|" + outputDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalMaxCreditAmount(int fieldno, int chkbox) {
		inputDTO.clearMap();
		outputDTO.clearMap();
		inputDTO.setValue("AMEND_FIELDNO", String.valueOf(fieldno));
		inputDTO.setValue("AMEND_CHKBOX", String.valueOf(chkbox));
		inputDTO.setValue("MAX_CREDIT_AMOUUNT", mamtqualifier);
		outputDTO = eolcamdvalinstance.Max_Credit_Amount_KeyPress(inputDTO);
		if (!outputDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:lstAmountQualifier|" + outputDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalReceiverbic() {
		inputDTO.clearMap();
		outputDTO.clearMap();
		inputDTO.setValue("LC_REC_BIC_CODE", AMEND_RCVR_REF);
		outputDTO = eolcamdvalinstance.Reciever_ReferenceKeyPress(inputDTO);
		if (!outputDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:txtReceRef|" + outputDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	//Changes Sanjay1 18-07-2019 Begin
	/*private boolean revalSwiftNarrative() {

		if (AMEND_NARRATIVE.length() > 1750) {
			merrmsg = "MF:txtNarrative|Maximum 1750 characters. Entered " + AMEND_NARRATIVE.length() + " characters";
			return false;
		}
		if (!AMEND_NARRATIVE.trim().equalsIgnoreCase("")) {
			boolean result1 = lineNumberValidation(AMEND_NARRATIVE);
			if (result1) {
				inputDTO.clearMap();
				inputDTO.setValue("OLC_BRN_CODE", mbranchcode);
				inputDTO.setValue("OLC_LC_TYPE", mrefertype);
				inputDTO.setValue("OLC_LC_YEAR", mreferyear);
				inputDTO.setValue("OLC_LC_SL", mrefersl);
				inputDTO.setValue("AMEND_NARRATIVE", AMEND_NARRATIVE);
				outputDTO = eolcamdvalinstance.Amend_Narrative_KeyPress(inputDTO);
				if (!outputDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
					merrmsg = "MF:txtNarrative|" + outputDTO.getValue(ErrorKey).toString();
					return false;
				} else
					return true;
			} else
				return false;
		}
		return true;
	}*/
	//Changes Sanjay1 18-07-2019 End
	
	private boolean lineNumberValidation(String input) {
		if (!input.trim().equals("")) {
			int startindex = input.lastIndexOf("\n");
			System.out.println("startindex:" + startindex);
			if (startindex != -1 && startindex != input.length()) {
				String ip1 = input.substring(startindex + 1);
				System.out.println("ip1:" + ip1);
				if (ip1.indexOf(" ") > 0 || ip1.indexOf(" ") == -1) {
					String str_input = input.trim();
					System.out.println(str_input);
					input = str_input;
				}
			}
			_desp = input.split("\n");
			int _lineNumber = 1;

			if (_desp.length > 35) {
				merrmsg = "MF:txtNarrative|Only 35 Rows Allowed. Entered Row: " + _desp.length;
				return false;
			} else {
				for (int i = 0; i < _desp.length; i++) {
					if (_desp.length > i) {
						if (_desp[i].length() > 50) {
							_lineNumber += i;
							merrmsg = "MF:txtNarrative|Only 50 Characters Allowed.Error in Line Number: " + _lineNumber;
							return false;
						}
					}
				}
			}

		}
		return true;
	}

	// Changes in EOLCAMD on 16-Oct-2018 end

	// ADDED BY PRASHANTH ON 09 FEB 2019
	private boolean revalSwiftDescriptionOfGoodsAndServices1() {

		if (chkChgDesc && LC_DESC_GOODS_SER1.equals("")) {
			merrmsg = "MF:txtDesGood1|Description of Goods/or Service Should  not be blank When Change in Description of Goods and / or Services is Checked";
			return false;
		}
		if (!chkChgDesc && !LC_DESC_GOODS_SER1.equals("")) {
			merrmsg = "MF:txtDesGood1|Description of Goods/or Service Should be blank When Change in Description of Goods and / or Services is not Checked";
			return false;
		}

		if (LC_DESC_GOODS_SER1.length() == 0 && LC_DESC_GOODS_SER2.length() > 0) {
			merrmsg = "MF:txtDesGood1|Should  not be blank";
			return false;
		} else if (LC_DESC_GOODS_SER1.length() == 0 && LC_DESC_GOODS_SER3.length() > 0) {
			merrmsg = "MF:txtDesGood1|Should  not be blank";
			return false;
		}
		if (LC_DESC_GOODS_SER1.length() > 6500) {
			merrmsg = "MF:txtDesGood1|Maximum 6500 characters. Entered " + LC_DESC_GOODS_SER1.length() + " characters";
			return false;
		}
		if (!LC_DESC_GOODS_SER1.trim().equalsIgnoreCase("")) {
			boolean result1 = lineNumberValidation(LC_DESC_GOODS_SER1, 1);
			if (result1) {

				inputDTO.clearMap();
				inputDTO.setValue("OLC_TYPE", mrefertype);
				inputDTO.setValue("OLC_YEAR", mreferyear);
				inputDTO.setValue("OLC_DAY_SER", mamdsl);
				inputDTO.setValue("OLC_BRANCH_CODE", mbranchcode);
				inputDTO.setValue("OLC_ENTRY_DATE", mlcdate);
				inputDTO.setValue("OLC_CLOB", LC_DESC_GOODS_SER1);
				inputDTO.setValue("OLC_CUST_NO", txtCustomerNumber);
				inputDTO.setValue("OLC_COLUMNNAME", "LC_DESC_GOODS_SER1");

				if (excludespecialChar(inputDTO, 1))
					LC_DESC_GOODS_SER1 = temp_str;
				else
					return false;
			} else
				return false;
		}
		return true;
	}

	private boolean revalSwiftDescriptionOfGoodsAndServices2() {
		int _good1 = LC_DESC_GOODS_SER1.split("\n").length;
		if (LC_DESC_GOODS_SER1.length() > 0) {
			if (LC_DESC_GOODS_SER1.length() < 6500 && LC_DESC_GOODS_SER2.length() > 0 && _good1 > 100) {
				merrmsg = "MF:txtDesGood1|Maximum 6500 characters. Entered " + LC_DESC_GOODS_SER1.length() + " characters";
				return false;
			}
			if (LC_DESC_GOODS_SER2.length() == 0 && LC_DESC_GOODS_SER3.length() > 0) {
				merrmsg = "MF:txtDesGood2|Should  not be blank";
				return false;
			}

			if (LC_DESC_GOODS_SER2.length() > 6500) {
				merrmsg = "MF:txtDesGood2|Maximum 6500 characters. Entered " + LC_DESC_GOODS_SER2.length() + " characters";
				return false;
			}
		}
		if (!LC_DESC_GOODS_SER2.trim().equalsIgnoreCase("")) {
			boolean result1 = lineNumberValidation(LC_DESC_GOODS_SER2, 2);
			if (result1) {

				inputDTO.clearMap();
				inputDTO.setValue("OLC_TYPE", mrefertype);
				inputDTO.setValue("OLC_YEAR", mreferyear);
				inputDTO.setValue("OLC_DAY_SER", mamdsl);
				inputDTO.setValue("OLC_BRANCH_CODE", mbranchcode);
				inputDTO.setValue("OLC_ENTRY_DATE", mlcdate);
				inputDTO.setValue("OLC_CLOB", LC_DESC_GOODS_SER2);
				inputDTO.setValue("OLC_CUST_NO", txtCustomerNumber);
				inputDTO.setValue("OLC_COLUMNNAME", "LC_DESC_GOODS_SER2");

				if (excludespecialChar(inputDTO, 2))
					LC_DESC_GOODS_SER2 = temp_str;
				else
					return false;
			} else
				return false;
		}

		return true;
	}

	private boolean revalSwiftDescriptionOfGoodsAndServices3() {
		int _good2 = LC_DESC_GOODS_SER2.split("\n").length;
		if (LC_DESC_GOODS_SER2.length() > 0) {
			if (LC_DESC_GOODS_SER2.length() < 6500 && LC_DESC_GOODS_SER3.length() > 0 && _good2 > 100) {
				merrmsg = "MF:txtDesGood2|Maximum 6500 characters. Entered " + LC_DESC_GOODS_SER2.length() + " characters";
				return false;
			}

			if (LC_DESC_GOODS_SER3.length() > 6500) {
				merrmsg = "MF:txtDesGood3|Maximum 6500 characters. Entered " + LC_DESC_GOODS_SER3.length() + " characters";
				return false;
			}
		}
		if (!LC_DESC_GOODS_SER3.trim().equalsIgnoreCase("")) {
			boolean result1 = lineNumberValidation(LC_DESC_GOODS_SER3, 3);
			if (result1) {

				inputDTO.clearMap();
				inputDTO.setValue("OLC_TYPE", mrefertype);
				inputDTO.setValue("OLC_YEAR", mreferyear);
				inputDTO.setValue("OLC_DAY_SER", mamdsl);
				inputDTO.setValue("OLC_BRANCH_CODE", mbranchcode);
				inputDTO.setValue("OLC_ENTRY_DATE", mlcdate);
				inputDTO.setValue("OLC_CLOB", LC_DESC_GOODS_SER3);
				inputDTO.setValue("OLC_CUST_NO", txtCustomerNumber);
				inputDTO.setValue("OLC_COLUMNNAME", "LC_DESC_GOODS_SER3");

				if (excludespecialChar(inputDTO, 3))
					LC_DESC_GOODS_SER3 = temp_str;
				else
					return false;
			} else
				return false;
		}

		return true;
	}

	private boolean revalSwiftDocumentsRequired1() {
		if (chkChgDoc && LC_DOC_REQ1.equals("")) {
			merrmsg = "MF:txtDocRequired1|Document Required Should  not be blank When Change in Documents is Checked";
			return false;
		}
		if (!chkChgDoc && !LC_DESC_GOODS_SER1.equals("")) {
			merrmsg = "MF:txtDocRequired1|Document Required Should be blank When Change in Documents is not Checked";
			return false;
		}

		if (LC_DOC_REQ1.length() == 0 && LC_DOC_REQ2.length() > 0) {
			merrmsg = "MF:txtDocRequired1|Should  not be blank";
			return false;
		} else if (LC_DOC_REQ1.length() == 0 && LC_DOC_REQ3.length() > 0) {
			merrmsg = "MF:txtDocRequired1|Should  not be blank";
			return false;
		}
		if (LC_DOC_REQ1.length() > 6500) {
			merrmsg = "MF:txtDocRequired1|Maximum 6500 characters. Entered " + LC_DOC_REQ1.length() + " characters";
			return false;
		}
		if (!LC_DOC_REQ1.trim().equalsIgnoreCase("")) {
			boolean result1 = lineNumberValidation(LC_DOC_REQ1, 4);
			if (result1) {

				inputDTO.clearMap();
				inputDTO.setValue("OLC_TYPE", mrefertype);
				inputDTO.setValue("OLC_YEAR", mreferyear);
				inputDTO.setValue("OLC_DAY_SER", mamdsl);
				inputDTO.setValue("OLC_BRANCH_CODE", mbranchcode);
				inputDTO.setValue("OLC_ENTRY_DATE", mlcdate);
				inputDTO.setValue("OLC_CLOB", LC_DOC_REQ1);
				inputDTO.setValue("OLC_CUST_NO", txtCustomerNumber);
				inputDTO.setValue("OLC_COLUMNNAME", "LC_DOC_REQ1");

				if (excludespecialChar(inputDTO, 4))
					LC_DOC_REQ1 = temp_str;
				else
					return false;
			} else
				return false;
		}

		return true;
	}

	private boolean revalSwiftDocumentsRequired2() {
		int doc1 = LC_DOC_REQ1.split("\n").length;
		if (LC_DOC_REQ1.length() > 0) {
			if (LC_DOC_REQ1.length() < 6500 && LC_DOC_REQ2.length() > 0 && doc1 > 100) {
				merrmsg = "MF:txtDocRequired1|Maximum 6500 characters. Entered " + LC_DOC_REQ1.length() + " characters";
				return false;
			}

			if (LC_DOC_REQ2.length() == 0 && LC_DOC_REQ3.length() > 0) {
				merrmsg = "MF:txtDocRequired2|Should  not be blank";
				return false;
			}
			if (LC_DOC_REQ2.length() > 6500) {
				merrmsg = "MF:txtDocRequired2|Maximum 6500 characters. Entered " + LC_DOC_REQ2.length() + " characters";
				return false;
			}
		}
		if (!LC_DOC_REQ2.trim().equalsIgnoreCase("")) {
			boolean result1 = lineNumberValidation(LC_DOC_REQ2, 5);
			if (result1) {

				inputDTO.clearMap();
				inputDTO.setValue("OLC_TYPE", mrefertype);
				inputDTO.setValue("OLC_YEAR", mreferyear);
				inputDTO.setValue("OLC_DAY_SER", mamdsl);
				inputDTO.setValue("OLC_BRANCH_CODE", mbranchcode);
				inputDTO.setValue("OLC_ENTRY_DATE", mlcdate);
				inputDTO.setValue("OLC_CLOB", LC_DOC_REQ2);
				inputDTO.setValue("OLC_CUST_NO", txtCustomerNumber);
				inputDTO.setValue("OLC_COLUMNNAME", "LC_DOC_REQ2");

				if (excludespecialChar(inputDTO, 5))
					LC_DOC_REQ2 = temp_str;
				else
					return false;
			} else
				return false;
		}

		return true;
	}

	private boolean revalSwiftDocumentsRequired3() {
		int doc2 = LC_DOC_REQ2.split("\n").length;
		if (LC_DOC_REQ2.length() > 0) {
			if (LC_DOC_REQ2.length() < 6500 && LC_DOC_REQ3.length() > 0 && doc2 > 100) {
				merrmsg = "MF:txtDocRequired2|Maximum 6500 characters. Entered " + LC_DOC_REQ2.length() + " characters";
				return false;
			}

			if (LC_DOC_REQ3.length() > 6500) {
				merrmsg = "MF:txtDocRequired3|Maximum 6500 characters. Entered " + LC_DOC_REQ3.length() + " characters";
				return false;
			}
		}
		if (!LC_DOC_REQ3.trim().equalsIgnoreCase("")) {
			boolean result1 = lineNumberValidation(LC_DOC_REQ3, 6);
			if (result1) {

				inputDTO.clearMap();
				inputDTO.setValue("OLC_TYPE", mrefertype);
				inputDTO.setValue("OLC_YEAR", mreferyear);
				inputDTO.setValue("OLC_DAY_SER", mamdsl);
				inputDTO.setValue("OLC_BRANCH_CODE", mbranchcode);
				inputDTO.setValue("OLC_ENTRY_DATE", mlcdate);
				inputDTO.setValue("OLC_CLOB", LC_DOC_REQ3);
				inputDTO.setValue("OLC_CUST_NO", txtCustomerNumber);
				inputDTO.setValue("OLC_COLUMNNAME", "LC_DOC_REQ3");

				if (excludespecialChar(inputDTO, 6))
					LC_DOC_REQ3 = temp_str;
				else
					return false;
			} else
				return false;
		}

		return true;
	}

	private boolean revalSwiftAdditionalCondition1() {

		if (chkChgAddCond && LC_ADD_CONDITION1.equals("")) {
			merrmsg = "MF:txtAddCond1|Additional condition Should  not be blank When Change in Additional Conditions is Checked";
			return false;
		}
		if (!chkChgAddCond && !LC_ADD_CONDITION1.equals("")) {
			merrmsg = "MF:txtAddCond1|Additional condition Should be blank When Change in Additional Conditions is not Checked";
			return false;
		}

		if (LC_ADD_CONDITION1.length() == 0 && LC_ADD_CONDITION2.length() > 0) {
			merrmsg = "MF:txtAddCond1|Should  not be blank";
			return false;
		} else if (LC_ADD_CONDITION1.length() == 0 && LC_ADD_CONDITION3.length() > 0) {
			merrmsg = "MF:txtAddCond1|Should  not be blank";
			return false;
		}
		if (LC_ADD_CONDITION1.length() > 6500) {
			merrmsg = "MF:txtAddCond1|Maximum 6500 characters. Entered " + LC_ADD_CONDITION1.length() + " characters";
			return false;
		}
		if (!LC_ADD_CONDITION1.trim().equalsIgnoreCase("")) {
			boolean result1 = lineNumberValidation(LC_ADD_CONDITION1, 7);
			if (result1) {

				inputDTO.clearMap();
				inputDTO.setValue("OLC_TYPE", mrefertype);
				inputDTO.setValue("OLC_YEAR", mreferyear);
				inputDTO.setValue("OLC_DAY_SER", mamdsl);
				inputDTO.setValue("OLC_BRANCH_CODE", mbranchcode);
				inputDTO.setValue("OLC_ENTRY_DATE", mlcdate);
				inputDTO.setValue("OLC_CLOB", LC_ADD_CONDITION1);
				inputDTO.setValue("OLC_CUST_NO", txtCustomerNumber);
				inputDTO.setValue("OLC_COLUMNNAME", "LC_ADD_CONDITION1");

				if (excludespecialChar(inputDTO, 7))
					LC_ADD_CONDITION1 = temp_str;
				else
					return false;
			} else
				return false;
		}

		return true;
	}

	private boolean revalSwiftAdditionalCondition2() {
		int addcon1 = LC_ADD_CONDITION1.split("\n").length;
		if (LC_ADD_CONDITION1.length() > 0) {
			if (LC_ADD_CONDITION1.length() < 6500 && LC_ADD_CONDITION2.length() > 0 && addcon1 > 100) {
				merrmsg = "MF:txtAddCond1|Maximum 6500 characters. Entered " + LC_ADD_CONDITION1.length() + " characters";
				return false;
			}
			if (LC_ADD_CONDITION2.length() == 0 && LC_ADD_CONDITION3.length() > 0) {
				merrmsg = "MF:txtAddCond2|Should  not be blank";
				return false;
			}
			if (LC_ADD_CONDITION2.length() > 6500) {
				merrmsg = "MF:txtAddCond2|Maximum 6500 characters. Entered " + LC_ADD_CONDITION2.length() + " characters";
				return false;
			}
		}
		if (!LC_ADD_CONDITION2.trim().equalsIgnoreCase("")) {
			boolean result1 = lineNumberValidation(LC_ADD_CONDITION2, 8);
			if (result1) {

				inputDTO.clearMap();
				inputDTO.setValue("OLC_TYPE", mrefertype);
				inputDTO.setValue("OLC_YEAR", mreferyear);
				inputDTO.setValue("OLC_DAY_SER", mamdsl);
				inputDTO.setValue("OLC_BRANCH_CODE", mbranchcode);
				inputDTO.setValue("OLC_ENTRY_DATE", mlcdate);
				inputDTO.setValue("OLC_CLOB", LC_ADD_CONDITION2);
				inputDTO.setValue("OLC_CUST_NO", txtCustomerNumber);
				inputDTO.setValue("OLC_COLUMNNAME", "LC_ADD_CONDITION2");

				if (excludespecialChar(inputDTO, 8))
					LC_ADD_CONDITION2 = temp_str;
				else
					return false;
			} else
				return false;
		}

		return true;
	}

	private boolean revalSwiftAdditionalCondition3() {
		int addcon2 = LC_ADD_CONDITION2.split("\n").length;
		if (LC_ADD_CONDITION2.length() > 0) {
			if (LC_ADD_CONDITION2.length() < 6500 && LC_ADD_CONDITION3.length() > 0 && addcon2 > 100) {
				merrmsg = "MF:txtAddCond2|Maximum 6500 characters. Entered " + LC_ADD_CONDITION2.length() + " characters";
				return false;
			}

			if (LC_ADD_CONDITION3.length() > 6500) {
				merrmsg = "MF:txtAddCond3|Maximum 6500 characters. Entered " + LC_ADD_CONDITION3.length() + " characters";
				return false;
			}
		}
		if (!LC_ADD_CONDITION3.trim().equalsIgnoreCase("")) {
			boolean result1 = lineNumberValidation(LC_ADD_CONDITION3, 9);
			if (result1) {

				inputDTO.clearMap();
				inputDTO.setValue("OLC_TYPE", mrefertype);
				inputDTO.setValue("OLC_YEAR", mreferyear);
				inputDTO.setValue("OLC_DAY_SER", mamdsl);
				inputDTO.setValue("OLC_BRANCH_CODE", mbranchcode);
				inputDTO.setValue("OLC_ENTRY_DATE", mlcdate);
				inputDTO.setValue("OLC_CLOB", LC_ADD_CONDITION3);
				inputDTO.setValue("OLC_CUST_NO", txtCustomerNumber);
				inputDTO.setValue("OLC_COLUMNNAME", "LC_ADD_CONDITION3");

				if (excludespecialChar(inputDTO, 9))
					LC_ADD_CONDITION3 = temp_str;
				else
					return false;
			} else
				return false;
		}

		return true;
	}

	private boolean excludespecialChar(DTObject input, int fieldno) {
		revalDTO.clearMap();
		revalDTO = eolcamdvalinstance.Special_Char_Validation(input);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			if (fieldno == 1)
				merrmsg = "MF:txtDesGood1|Special Character not Allowed";
			if (fieldno == 2)
				merrmsg = "MF:txtDesGood2|Special Character not Allowed";
			if (fieldno == 3)
				merrmsg = "MF:txtDesGood3|Special Character not Allowed";
			if (fieldno == 4)
				merrmsg = "MF:txtDocRequired1|Special Character not Allowed";
			if (fieldno == 5)
				merrmsg = "MF:txtDocRequired2|Special Character not Allowed";
			if (fieldno == 6)
				merrmsg = "MF:txtDocRequired3|Special Character not Allowed";
			if (fieldno == 7)
				merrmsg = "MF:txtAddCond1|Special Character not Allowed";
			if (fieldno == 8)
				merrmsg = "MF:txtAddCond2|Special Character not Allowed";
			if (fieldno == 9)
				merrmsg = "MF:txtAddCond3|Special Character not Allowed";
			return false;
		}
		temp_str = "";
		temp_str = revalDTO.getValue("TEMP");
		return true;
	}

	private boolean lineNumberValidation(String input, int fieldno) {
		if (!input.trim().equals("")) {
			int startindex = input.lastIndexOf("\n");
			System.out.println("startindex:" + startindex);
			if (startindex != -1 && startindex != input.length()) {
				String ip1 = input.substring(startindex + 1);
				System.out.println("ip1:" + ip1);
				if (ip1.indexOf(" ") > 0 || ip1.indexOf(" ") == -1) {
					String str_input = input.trim();
					System.out.println(str_input);
					input = str_input;
				}

			}
			// String str=StringUtils.chomp(input);

			_desp = input.split("\n");
			int _lineNumber = 1;
			// changes in EOLC on 01-Oct-2018 start
			if (_desp.length > 100) {
				if (fieldno == 1)
					merrmsg = "MF:txtDesGood1|Only 100 Rows Allowed. Entered Row: " + _desp.length;
				if (fieldno == 2)
					merrmsg = "MF:txtDesGood2|Only 100 Rows Allowed. Entered Row: " + _desp.length;
				if (fieldno == 3)
					merrmsg = "MF:txtDesGood3|Only 100 Rows Allowed. Entered Row: " + _desp.length;
				if (fieldno == 4)
					merrmsg = "MF:txtDocRequired1|Only 100 Rows Allowed. Entered Row: " + _desp.length;
				if (fieldno == 5)
					merrmsg = "MF:txtDocRequired2|Only 100 Rows Allowed. Entered Row: " + _desp.length;
				if (fieldno == 6)
					merrmsg = "MF:txtDocRequired3|Only 100 Rows Allowed. Entered Row: " + _desp.length;
				if (fieldno == 7)
					merrmsg = "MF:txtAddCond1|Only 100 Rows Allowed. Entered Row: " + _desp.length;
				if (fieldno == 8)
					merrmsg = "MF:txtAddCond2|Only 100 Rows Allowed. Entered Row: " + _desp.length;
				if (fieldno == 9)
					merrmsg = "MF:txtAddCond3|Only 100 Rows Allowed. Entered Row: " + _desp.length;
				return false;
			} else // changes in EOLC on 01-Oct-2018 end
			{
				for (int i = 0; i < _desp.length; i++) {
					if (_desp.length > i) {
						if (_desp[i].length() > 65) {
							_lineNumber += i;
							if (fieldno == 1)
								merrmsg = "MF:txtDesGood1|Only 65 Characters Allowed.Error in Line Number:" + _lineNumber;
							if (fieldno == 2)
								merrmsg = "MF:txtDesGood2|Only 65 Characters Allowed.Error in Line Number:" + _lineNumber;
							if (fieldno == 3)
								merrmsg = "MF:txtDesGood3|Only 65 Characters Allowed.Error in Line Number: " + _lineNumber;
							if (fieldno == 4)
								merrmsg = "MF:txtDocRequired1|Only 65 Characters Allowed.Error in Line Number:" + _lineNumber;
							if (fieldno == 5)
								merrmsg = "MF:txtDocRequired2|Only 65 Characters Allowed.Error in Line Number: " + _lineNumber;
							if (fieldno == 6)
								merrmsg = "MF:txtDocRequired3|Only 65 Characters Allowed.Error in Line Number: " + _lineNumber;
							if (fieldno == 7)
								merrmsg = "MF:txtAddCond1|Only 65 Characters Allowed.Error in Line Number: " + _lineNumber;
							if (fieldno == 8)
								merrmsg = "MF:txtAddCond2|Only 65 Characters Allowed.Error in Line Number: " + _lineNumber;
							if (fieldno == 9)
								merrmsg = "MF:txtAddCond3|Only 65 Characters Allowed.Error in Line Number: " + _lineNumber;
							return false;
						}
					}
				}
			}

		}
		return true;
	}

	// NEW TABS ADDED BY PRASHANTH ON 19 FEB 2019

	private boolean revalformOfCredit() {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("LC_DOC_CREDIT", LC_FORM_OF_DOC_CREDIT);
		revalDTO = eolcamdvalinstance.Olc_Doc_CreditKeypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			merrmsg = "MF:lstcredit|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalApplName() {

		if (txtApplName.trim().equals("") && chkChgAppl == true) {
			merrmsg = "MF:txtApplName|" + "Applicant Name Cannot Be Blank When Change of Applicant is Checked";
			return false;
		} else if ((!txtApplName.trim().equals("")) && chkChgAppl == false) {
			merrmsg = "MF:txtApplName|" + "Applicant Name Should Be Blank When Change of Applicant is not Checked";
			return false;
		}
		return true;
	}

	private boolean revalApplAddress() {

		if (txtApplAddress.trim().equals("") && chkChgAppl == true) {
			merrmsg = "MF:txtApplAddress|" + "Applicant Address Cannot Be Blank When Change of Applicant is Checked";
			return false;
		} else if ((!txtApplAddress.trim().equals("")) && chkChgAppl == false) {
			merrmsg = "MF:txtApplAddress|" + "Applicant Address  Should Be Blank When Change of Applicant is not Checked";
			return false;
		}
		return true;
	}

	private boolean revalApplRules() {

		if (LC_APPLICABLE_RULES.trim().equals("") && chkChgApplRules == true) {
			merrmsg = "MF:lstAppRule|" + "Applicant Rules Cannot Be Blank When Change of Applicable Rules is Checked";
			return false;
		} else if ((!LC_APPLICABLE_RULES.trim().equals("")) && chkChgApplRules == false) {
			if(!changeinapplicablerules.equals("0"))
			{
				merrmsg = "MF:lstAppRule|" + "Applicant Rules  Should Be Blank When Change of Applicable Rules is not Checked";
				return false;
			}
		}
		return true;
	}

	private boolean revalAvailableWithBankType() {
		if (!LC_AVAILABLE_WITH_CODETYP.equals("")) {
			inputDTO.clearMap();
			revalDTO.clearMap();
			inputDTO.setValue("LC_AVL_WITH", LC_AVAILABLE_WITH_CODETYP);
			revalDTO = eolcamdvalinstance.Olc_AvailableWithKeypress(inputDTO);
			if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
				merrmsg = "MF:lstAvl|" + revalDTO.getValue(ErrorKey).toString();
				return false;
			}
		}
		return true;
	}

	private boolean revalBankType(int chkbox, String type, int fieldno) {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("LC_FIELD_NO", String.valueOf(fieldno));
		inputDTO.setValue("LC_CHKBOX_REQ", String.valueOf(chkbox));
		inputDTO.setValue("LC_DROPDWN_TYPE", type);
		revalDTO = eolcamdvalinstance.Olc_ApplicantBankTypeKeypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			if (fieldno == 1)
				merrmsg = "MF:lstBICdtl|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 2)
				merrmsg = "MF:lstAvlBICdtl|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 3)
				merrmsg = "MF:lstDrwBICdtl|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 4)
				merrmsg = "MF:lstReimbBank|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 5)
				merrmsg = "MF:lstAdviseBank|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 6)
				merrmsg = "MF:lstReimbcfmBank|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalSwiftBankBic(int chkbox, String type, String bankbic, int fieldno) {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("LC_CHKBOX_REQ", String.valueOf(chkbox));
		inputDTO.setValue("LC_DROPDWN_TYPE", type);
		inputDTO.setValue("LC_BIC_CODE", bankbic);
		revalDTO = eolcamdvalinstance.Olc_ApplicantBicKeypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			if (fieldno == 1)
				merrmsg = "MF:txtAppBicCode|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 2)
				merrmsg = "MF:txtAvlBicCode|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 3)
				merrmsg = "MF:txtDrwBicCode|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 4)
				merrmsg = "MF:txtReimBicCode|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 5)
				merrmsg = "MF:txtAdviseBicCode|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 6)
				merrmsg = "MF:txtReimcfmBicCode|" + revalDTO.getValue(ErrorKey).toString();

			return false;
		}
		return true;
	}
	
	
	// ADDED BY NAVYA ON 27/06/19 BEGIN
	private boolean revalSwiftCharges() {
		chgs = null;
		if (!(AMEND_CHRG_PAYABLE.equalsIgnoreCase(""))) {
			chgs = AMEND_CHRG_PAYABLE.split("\n");
			a1 = chgs[0].trim();
			a2 = ((chgs.length > 1) ? chgs[1].trim() : " ");
			a3 = ((chgs.length > 2) ? chgs[2].trim() : " ");
			a4 = ((chgs.length > 3) ? chgs[3].trim() : " ");
			a5 = ((chgs.length > 4) ? chgs[4].trim() : " ");
			a6 = ((chgs.length > 5) ? chgs[5].trim() : " ");
			if ((a1.length() > 35) || (a2.length() > 35) || (a3.length() > 35) || (a4.length() > 35) || (a5.length() > 35) || (a6.length() > 35)) {
				merrmsg = "MF:txtCharge|Only 35 Characters Allowed In A Line";
				return false;
			}
		}

		return true;
	}
// END

	private boolean revalSwiftBranchCode(int chkbox, String type, String bankbrn, int fieldno) {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("LC_CHKBOX_REQ", String.valueOf(chkbox));
		inputDTO.setValue("LC_DROPDWN_TYPE", type);
		inputDTO.setValue("LC_BRANCH_CODE", bankbrn);
		revalDTO = eolcamdvalinstance.Olc_ApplicantBankBrachCodeKeypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			if (fieldno == 1)
				merrmsg = "MF:txtAppBicBrn|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 2)
				merrmsg = "MF:txtAvlBicBrn|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 3)
				merrmsg = "MF:txtDrwBicBrn|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 4)
				merrmsg = "MF:txtReimBicBrn|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 5)
				merrmsg = "MF:txtAdviseBicBrn|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 6)
				merrmsg = "MF:txtReimcfmBicBrn|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalSwiftBankName(int chkbox, String type, String bnkName, int fieldno) {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("LC_CHKBOX_REQ", String.valueOf(chkbox));
		inputDTO.setValue("LC_DROPDWN_TYPE", type);
		inputDTO.setValue("LC_BANK_NAME", bnkName);
		revalDTO = eolcamdvalinstance.Olc_ApplicantBankNameKeypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			if (fieldno == 1)
				merrmsg = "MF:txtAppBankName|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 2)
				merrmsg = "MF:txtAvlBankName|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 3)
				merrmsg = "MF:txtDrwBankName|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 4)
				merrmsg = "MF:txtReimBankName|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 5)
				merrmsg = "MF:txtAdviseBankName|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 6)
				merrmsg = "MF:txtcfmReimBankName|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalSwiftBankAddress(int chkbox, String type, String bankadrres, int fieldno) {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("LC_CHKBOX_REQ", String.valueOf(chkbox));
		inputDTO.setValue("LC_DROPDWN_TYPE", type);
		inputDTO.setValue("LC_BANK_ADDRESS", bankadrres);
		revalDTO = eolcamdvalinstance.Olc_ApplicantBankAddressKeypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			if (fieldno == 1)
				merrmsg = "MF:txtAppAddress|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 2)
				merrmsg = "MF:txtAvlAddress|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 3)
				merrmsg = "MF:txtDrwAddress|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 4)
				merrmsg = "MF:txtReimAddress|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 5)
				merrmsg = "MF:txtAdviseAddress|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 6)
				merrmsg = "MF:txtcfmReimAddress|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}
		if (!(bankadrres.equalsIgnoreCase(""))) {
			bank_addr = bankadrres.split("\n");
			a1 = bank_addr[0].trim();
			a2 = ((bank_addr.length > 1) ? bank_addr[1].trim() : " ");
			a3 = ((bank_addr.length > 2) ? bank_addr[2].trim() : " ");
			a4 = ((bank_addr.length > 3) ? bank_addr[3].trim() : " ");
			a5 = ((bank_addr.length > 4) ? bank_addr[4].trim() : " ");
			if ((a1.length() > 35) || (a2.length() > 35) || (a3.length() > 35) || (a4.length() > 35) || (a5.length() > 35)) {
				if (fieldno == 1)
					merrmsg = "MF:txtAppAddress|Only 35 Characters Allowed In A Line";
				if (fieldno == 2)
					merrmsg = "MF:txtAvlAddress|Only 35 Characters Allowed In A Line";
				if (fieldno == 3)
					merrmsg = "MF:txtDrwAddress|Only 35 Characters Allowed In A Line";
				if (fieldno == 4)
					merrmsg = "MF:txtReimAddress|Only 35 Characters Allowed In A Line";
				if (fieldno == 5)
					merrmsg = "MF:txtAdviseAddress|Only 35 Characters Allowed In A Line";
				if (fieldno == 6)
					merrmsg = "MF:txtcfmReimAddress|Only 35 Characters Allowed In A Line";
				return false;
			}
		}
		return true;
	}

	private boolean revalSwiftCountryCode(int chkbox, String type, String cntrycode, int fieldno) {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("LC_CHKBOX_REQ", String.valueOf(chkbox));
		inputDTO.setValue("LC_DROPDWN_TYPE", type);
		inputDTO.setValue("LC_BANK_COUNTRY_CODE", cntrycode);
		inputDTO.setValue("LC_TYPE", mrefertype);
		revalDTO = eolcamdvalinstance.Olc_ApplicantBankCntryCodeKeypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			if (fieldno == 1)
				merrmsg = "MF:txtAppCntry|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 2)
				merrmsg = "MF:txtAvlCntry|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 3)
				merrmsg = "MF:txtDrwCntry|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 4)
				merrmsg = "MF:txtReimCntry|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 5)
				merrmsg = "MF:txtAdviseCntry|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 6)
				merrmsg = "MF:txtcfmReimCntry|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalSwiftRoutingId(int chkbox, String type, String Rout_Id, int fieldno) {
		inputDTO.clearMap();
		revalDTO.clearMap();
		inputDTO.setValue("LC_CHKBOX_REQ", String.valueOf(chkbox));
		inputDTO.setValue("LC_DROPDWN_TYPE", type);
		inputDTO.setValue("LC_ROUNTING_ID", Rout_Id);
		revalDTO = eolcamdvalinstance.Olc_ApplicantAccountNumberKeypress(inputDTO);
		if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
			if (fieldno == 1)
				merrmsg = "MF:txtAppAcnt|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 2)
				merrmsg = "MF:txtAvlAcnt|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 3)
				merrmsg = "MF:txtDrwAcnt|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 4)
				merrmsg = "MF:txtReimAcnt|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 5)
				merrmsg = "MF:txtAdviseAcnt|" + revalDTO.getValue(ErrorKey).toString();
			if (fieldno == 6)
				merrmsg = "MF:txtcfmReimAcnt|" + revalDTO.getValue(ErrorKey).toString();
			return false;
		}
		return true;
	}

	private boolean revalSwiftMixedPaymentDetails() {
		mixed_pay_details = null;
		if (LC_AVAILABLE_WITH_TYPE.trim().equals("3")) {
			if (!(LC_MIXED_PAY_DETAILS.equalsIgnoreCase(""))) {
				mixed_pay_details = LC_MIXED_PAY_DETAILS.split("\n");
				a1 = mixed_pay_details[0].trim();
				a2 = ((mixed_pay_details.length > 1) ? mixed_pay_details[1].trim() : " ");
				a3 = ((mixed_pay_details.length > 2) ? mixed_pay_details[2].trim() : " ");
				a4 = ((mixed_pay_details.length > 3) ? mixed_pay_details[3].trim() : " ");
				if ((a1.length() > 35) || (a2.length() > 35) || (a3.length() > 35) || (a4.length() > 35)) {
					merrmsg = "MF:txtMixedPaydtl|Only 35 Characters Allowed In A Line";
					return false;
				}
			}
		}

		return true;
	}

	private boolean revalSwiftDeferredPaymentDetails() {
		/*if (LC_DRAWEE_REQ == false && LC_DEFERRED_PAY_DETAILS.equals("")) {
			merrmsg = "MF:txtDeferPaydtl|" + "Differred Payment Details Should be Entered When Change in Drawee / Payment: is Checked";
			return false;
		} else if (LC_DRAWEE_REQ == false && !LC_DEFERRED_PAY_DETAILS.equals("")) {
			merrmsg = "MF:txtDeferPaydtl|" + "Differred Payment Details Should not be Entered When Change in Drawee / Payment: is Not Checked";
			return false;
		}
		 */

		def_pay_details = null;
		if (LC_AVAILABLE_WITH_TYPE.trim().equals("2")) {
			if (!(LC_DEFERRED_PAY_DETAILS.equalsIgnoreCase(""))) {
				def_pay_details = LC_DEFERRED_PAY_DETAILS.split("\n");
				a1 = def_pay_details[0].trim();
				a2 = ((def_pay_details.length > 1) ? def_pay_details[1].trim() : " ");
				a3 = ((def_pay_details.length > 2) ? def_pay_details[2].trim() : " ");
				a4 = ((def_pay_details.length > 3) ? def_pay_details[3].trim() : " ");
				if ((a1.length() > 35) || (a2.length() > 35) || (a3.length() > 35) || (a4.length() > 35)) {
					merrmsg = "MF:txtDeferPaydtl|Only 35 Characters Allowed In A Line";
					return false;
				}
			}
		}

		return true;
	}

	private boolean revalSwiftDraftsAt() {
		drafts = null;
		if (!(LC_DRAFTS_AT.equalsIgnoreCase(""))) {
			drafts = LC_DRAFTS_AT.split("\n");
			a1 = drafts[0].trim();
			a2 = ((drafts.length > 1) ? drafts[1].trim() : " ");
			a3 = ((drafts.length > 2) ? drafts[2].trim() : " ");
			if ((a1.length() > 35) || (a2.length() > 35) || (a3.length() > 35)) {
				merrmsg = "MF:txtDraft|Only 35 Characters Allowed In A Line";
				return false;
			}
		}
		return true;
	}

	private boolean revalAvlWithTab() {
		if (chkChgAvlWith == true) {
			if (LC_AVAILABLE_WITH_CODETYP.trim().equals("") && LC_AVAILABLE_WITH_CODETYP.trim().equals("") && LC_AVAILABLE_WITH_TYPE.trim().equals("") && LC_AVAILABLE_WITH_BIC_CODE.trim().equals("") && LC_AVAILABLE_WITH_BRN_CODE.trim().equals("") && LC_AVAILABLE_WITH_ROUTID.trim().equals("") && LC_AVAILABLE_WITH_BNK_CODE.trim().equals("") && LC_AVAILABLE_WITH_ADDRESS.trim().equals("") && LC_AVAILABLE_WITH_CNTRY.trim().equals("") && LC_DRAFTS_AT.trim().equals("")) {
				merrmsg = "MF:txtDraft|" + "Atleast One Of The Details In Available With Tab Should Be Given When Change in Available With Flag Is Checked";
				return false;
			}
		} else {
			if (!LC_AVAILABLE_WITH_CODETYP.trim().equals("") || !LC_AVAILABLE_WITH_CODETYP.trim().equals("") || !LC_AVAILABLE_WITH_TYPE.trim().equals("") || !LC_AVAILABLE_WITH_BIC_CODE.trim().equals("") || !LC_AVAILABLE_WITH_BRN_CODE.trim().equals("") || !LC_AVAILABLE_WITH_ROUTID.trim().equals("") || !LC_AVAILABLE_WITH_BNK_CODE.trim().equals("") || !LC_AVAILABLE_WITH_ADDRESS.trim().equals("") || !LC_AVAILABLE_WITH_CNTRY.trim().equals("") || !LC_DRAFTS_AT.trim().equals("")) {
				if(!changeinavailablewith.equals("0"))
				{
				merrmsg = "MF:txtDraft|" + "Details In Available With Tab Should Not Be Given When Change in Available With Flag Is Not Checked";
				return false;
				}
			}
		}
		return true;
	}
	
	
	
	
	
	private boolean revalDraweePaymentTab() {
		if (chkCgDrawee == true) {
			if (LC_DRAWEE_TYPE.trim().equals("") && LC_DRAWEE_BIC_CODE.trim().equals("") && LC_DRAWEE_BRN_CODE.trim().equals("") && LC_DRAWEE_ROUTID.trim().equals("") && LC_DRAWEE_BNK_CODE.trim().equals("") && LC_DRAWEE_ADDRESS.trim().equals("") && LC_DRAWEE_CNTRY_CODE.trim().equals("") && LC_MIXED_PAY_DETAILS.trim().equals("") && LC_DEFERRED_PAY_DETAILS.trim().equals("")) {
				merrmsg = "MF:txtDeferPaydtl|" + "Atleast One Of The Details In Drawee/Payment Details Should Be Given When Change in Drawee / Payment Flag Is Checked";
				return false;
			}
		} else {
			if (!LC_DRAWEE_TYPE.trim().equals("") || !LC_DRAWEE_BIC_CODE.trim().equals("") || !LC_DRAWEE_BRN_CODE.trim().equals("") || !LC_DRAWEE_ROUTID.trim().equals("") || !LC_DRAWEE_BNK_CODE.trim().equals("") || !LC_DRAWEE_ADDRESS.trim().equals("") || !LC_DRAWEE_CNTRY_CODE.trim().equals("") || !LC_MIXED_PAY_DETAILS.trim().equals("") || !LC_DEFERRED_PAY_DETAILS.trim().equals("")) {
				if(!changeindrawee.equals("0"))
				{
				merrmsg = "MF:txtDeferPaydtl|" + "Details In Drawee/Payment Tab Details Should Not Be Given When Change in Drawee / Payment Flag Is Not Checked";
				return false;
				}
			}
		}
		return true;
	}

	
	private boolean revalReimbursementTab() {
		if (chkChgReimbus == true) {
			if (LC_CONFIRMATION_INST.trim().equals("") && LC_REIMB_TYPE.trim().equals("") && LC_REIMB_BIC_CODE.trim().equals("") && LC_REIMB_ROUTID.trim().equals("") && LC_REIMB_BNK_CODE.trim().equals("") && LC_REIMB_ADDRESS.trim().equals("") && LC_REIMB_CNTRY_CODE.trim().equals("")  && LC_INST_PAYING.trim().equals("")) {
				merrmsg = "MF:txtInstPay|" + "Atleast One Of The Details In Reimbursement Details Tab Should Be Given When Change in Reimbursement Flag Is Checked";
				return false;
			}
		} else {
			if (!LC_CONFIRMATION_INST.trim().equals("")  || !LC_REIMB_TYPE.trim().equals("") || !LC_REIMB_BIC_CODE.trim().equals("") || !LC_REIMB_ROUTID.trim().equals("") || !LC_REIMB_BNK_CODE.trim().equals("") || !LC_REIMB_ADDRESS.trim().equals("") || !LC_REIMB_CNTRY_CODE.trim().equals("")|| !LC_INST_PAYING.trim().equals("")) {
				if(!changeinreimbursement.equals("0"))
				{
				merrmsg = "MF:txtInstPay|" + "Details In Reimbursement Details Tab Tab Should Not Be Given When Change in Reimbursement Flag Is Not Checked";
				return false;
				}
			}
		}
		return true;
	}
	/*	private boolean revalDraweeReq() {
	 return true;
	 }

	 */
	private boolean revalAdvReqd() {
		if (LC_SECOND_ADV_REQ == false && chkCgAdvBk == true) {
			merrmsg = "MF:chkAdvise|" + "Advise Through Bank Bank Required Should be Checked When Change in Advising Bank  is Checked";
			return false;
		} else if (LC_SECOND_ADV_REQ == false && chkCgAdvBk == true) {
			if(!changeinadvisingbank.equals("0"))
			{
			merrmsg = "MF:chkAdvise|" + "Advise Through Bank Bank Required Should be Checked When Change in Advising Bank is Not Checked";
			return false;
			}
		}
		return true;
	}

	// ADDED BY PRASHANTH ON 29 JANUARY 2018

	private boolean revalSwiftConfirmationInstruction() {
		if (!LC_CONFIRMATION_INST.equals("")) {
			inputDTO.clearMap();
			revalDTO.clearMap();
			inputDTO.setValue("LC_CONFIRM_INSTRUCT", LC_CONFIRMATION_INST);
			revalDTO = eolcamdvalinstance.Olc_Confirmation_InstKeyPress(inputDTO);
			if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
				merrmsg = "MF:lstConfInst|" + revalDTO.getValue(ErrorKey).toString();
				return false;
			}
		}
		return true;
	}

	//Changes Sanjay1 18-07-2019 Begin
/*	private boolean revalolcAdvThruBk() {
		if (LC_CONFIRMATION_INST.equals("1")) {
			if (olcLcToBeCnfrmdByBk.trim().equals("")) {
				merrmsg = "MF:txtConfirmedByBank|" + "Field Should Be Not Be Blank";
				return false;
			}

			inputDTO.clearMap();
			inputDTO.setValue("OLC_ADV_BANK_CODE", olcLcToBeCnfrmdByBk);
			revalDTO = eolcamdvalinstance.olcAdvBankCodekeypress(inputDTO);
			if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
				merrmsg = "MF:txtConfirmedByBank|" + revalDTO.getValue(ErrorKey).toString();
				return false;
			}
		} else {
			if (!olcLcToBeCnfrmdByBk.trim().equals("")) {
				merrmsg = "MF:txtConfirmedByBank|" + "Field Should Be Blank For the selected Option";
				return false;
			}
		}
		return true;
	}

	private boolean revalolcAdvThruBrn() {
		if (LC_CONFIRMATION_INST.equals("1")) {
			if (olcLcToBeCnfrmdByBrn.trim().equals("")) {
				merrmsg = "MF:txtConfirmedBYBranch|" + "Field Should Be Not Be Blank";
				return false;
			}
			inputDTO.clearMap();
			inputDTO.setValue("OLC_ADV_BRNCH_CODE", olcLcToBeCnfrmdByBrn);
			inputDTO.setValue("OLC_ADV_BANK_CODE", olcLcToBeCnfrmdByBk);
			revalDTO = eolcamdvalinstance.olcAdvBranchCodekeypress(inputDTO);
			if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
				merrmsg = "MF:txtConfirmedBYBranch|" + revalDTO.getValue(ErrorKey).toString();
				return false;
			}
		} else {
			if (!olcLcToBeCnfrmdByBrn.trim().equals("")) {
				merrmsg = "MF:txtConfirmedBYBranch|" + "Field Should Be Blank For the selected Option";
				return false;
			}

		}
		return true;
	}

	private boolean revalolcAdvBrnName() {
		if (LC_CONFIRMATION_INST.equals("1")) {
			if (olcLcToBeCnfrmdByBrnName.trim().equals("")) {
				merrmsg = "MF:txtConfirmedBYBranchname|" + "Field Should Be Not Be Blank";
				return false;
			}

			inputDTO.clearMap();
			inputDTO.setValue("OLC_BRNCH_NAME", olcLcToBeCnfrmdByBrnName);
			revalDTO = eolcamdvalinstance.olcBranchNamekeypress(inputDTO);
			if (!revalDTO.getValue(ErrorKey).equalsIgnoreCase("")) {
				merrmsg = "MF:txtConfirmedBYBranch|" + revalDTO.getValue(ErrorKey).toString();
				return false;
			}
		} else {
			if (!olcLcToBeCnfrmdByBrnName.trim().equals("")) {
				merrmsg = "MF:txtConfirmedBYBranchname|" + "Field Should Be Blank For the selected Option";
				return false;
			}

		}
		return true;
	}*/
	//Changes Sanjay1 18-07-2019 End

	// ADDED BY PRASHANTH ON 09 FEB 2019

	public String getMchangeinlcliabinbasecurrfield() {
		return mchangeinlcliabinbasecurrfield;
	}

	public void setMchangeinlcliabinbasecurrfield(String mchangeinlcliabinbasecurrfield) {
		this.mchangeinlcliabinbasecurrfield = mchangeinlcliabinbasecurrfield;
	}

	public String getMerrxmlstr1() {
		return merrxmlstr1;
	}

	public void setMerrxmlstr1(String merrxmlstr1) {
		this.merrxmlstr1 = merrxmlstr1;
	}

	public String getMprevenhancereductionamt() {
		return mprevenhancereductionamt;
	}

	public void setMprevenhancereductionamt(String mprevenhancereductionamt) {
		this.mprevenhancereductionamt = mprevenhancereductionamt;
	}

	public String getMprevenhancereductionchk() {
		return mprevenhancereductionchk;
	}

	public void setMprevenhancereductionchk(String mprevenhancereductionchk) {
		this.mprevenhancereductionchk = mprevenhancereductionchk;
	}

	public String getMprevgridtenoramt() {
		return mprevgridtenoramt;
	}

	public void setMprevgridtenoramt(String mprevgridtenoramt) {
		this.mprevgridtenoramt = mprevgridtenoramt;
	}

	public String getMtotalgridliabamt() {
		return mtotalgridliabamt;
	}

	public void setMtotalgridliabamt(String mtotalgridliabamt) {
		this.mtotalgridliabamt = mtotalgridliabamt;
	}

	// Converting into XML
	private String getXML(String KeyName, int count) {
		String xml_str = "";
		xml_str += "<Data>";

		if (KeyName.equalsIgnoreCase("OLCTENORS")) {
			for (int p = 0; p < count; p++) {
				if (!prev_tenor_amt[p].equalsIgnoreCase("_-")) {
					xml_str += "<Record>";
					xml_str += "<Cell>";
					xml_str += prev_tenor_amt[p];
					xml_str += "</Cell>";
					xml_str += "<Cell>";
					xml_str += total_Liab_amt[p];
					xml_str += "</Cell>";
				}
			}
			xml_str += "</Record>";
		}

		xml_str += "</Data>";
		return xml_str;
	}

	public String getMbaltenoramt() {
		return mbaltenoramt;
	}

	public void setMbaltenoramt(String mbaltenoramt) {
		this.mbaltenoramt = mbaltenoramt;
	}

	public String getMbalusanceintamt() {
		return mbalusanceintamt;
	}

	public void setMbalusanceintamt(String mbalusanceintamt) {
		this.mbalusanceintamt = mbalusanceintamt;
	}

	public String getMdeviationbal() {
		return mdeviationbal;
	}

	public void setMdeviationbal(String mdeviationbal) {
		this.mdeviationbal = mdeviationbal;
	}

	public String getMaddtranchgs() {
		return maddtranchgs;
	}

	public void setMaddtranchgs(String maddtranchgs) {
		this.maddtranchgs = maddtranchgs;
	}

	public String getMaddtranstlmntinvnum() {
		return maddtranstlmntinvnum;
	}

	public void setMaddtranstlmntinvnum(String maddtranstlmntinvnum) {
		this.maddtranstlmntinvnum = maddtranstlmntinvnum;
	}

	public String getMolcaentrydate() {
		return molcaentrydate;
	}

	public void setMolcaentrydate(String molcaentrydate) {
		this.molcaentrydate = molcaentrydate;
	}

	public String getMreductioninlcliabinbasecurr() {
		return mreductioninlcliabinbasecurr;
	}

	public void setMreductioninlcliabinbasecurr(String mreductioninlcliabinbasecurr) {
		this.mreductioninlcliabinbasecurr = mreductioninlcliabinbasecurr;
	}

	public String getMtotalaftamd() {
		return mtotalaftamd;
	}

	public void setMtotalaftamd(String mtotalaftamd) {
		this.mtotalaftamd = mtotalaftamd;
	}

	public String getMtotalbefamd() {
		return mtotalbefamd;
	}

	public void setMtotalbefamd(String mtotalbefamd) {
		this.mtotalbefamd = mtotalbefamd;
	}

	public String getMtotalliabbasecurr() {
		return mtotalliabbasecurr;
	}

	public void setMtotalliabbasecurr(String mtotalliabbasecurr) {
		this.mtotalliabbasecurr = mtotalliabbasecurr;
	}

	public String getMcurrrefnum() {
		return mcurrrefnum;
	}

	public void setMcurrrefnum(String mcurrrefnum) {
		this.mcurrrefnum = mcurrrefnum;
	}

	public String getMinternalaccnum() {
		return minternalaccnum;
	}

	public void setMinternalaccnum(String minternalaccnum) {
		this.minternalaccnum = minternalaccnum;
	}

	public String getMtotalamt() {
		return mtotalamt;
	}

	public void setMtotalamt(String mtotalamt) {
		this.mtotalamt = mtotalamt;
	}

	public String getBatchnum() {
		return batchnum;
	}

	public void setBatchnum(String batchnum) {
		this.batchnum = batchnum;
	}

	public String getLcAmt() {
		return lcAmt;
	}

	public void setLcAmt(String lcAmt) {
		this.lcAmt = lcAmt;
	}

	// Changes P.Subramani-Chn-12/04/2008 Beg
	public String getOlccommchgs() {
		return olccommchgs;
	}

	public void setOlccommchgs(String olccommchgs) {
		this.olccommchgs = olccommchgs;
	}

	public String getOlcusnchgs() {
		return olcusnchgs;
	}

	public void setOlcusnchgs(String olcusnchgs) {
		this.olcusnchgs = olcusnchgs;
	}

	public String getOlccommchgstakendays() {
		return olccommchgstakendays;
	}

	public void setOlccommchgstakendays(String olccommchgstakendays) {
		this.olccommchgstakendays = olccommchgstakendays;
	}

	public String getOlcusnchgstakendays() {
		return olcusnchgstakendays;
	}

	public void setOlcusnchgstakendays(String olcusnchgstakendays) {
		this.olcusnchgstakendays = olcusnchgstakendays;
	}

	// Changes P.Subramani-Chn-12/04/2008 End
	public String getCommchgcode() {
		return commchgcode;
	}

	public void setCommchgcode(String commchgcode) {
		this.commchgcode = commchgcode;
	}

	public String getUsancechgcode() {
		return usancechgcode;
	}

	public void setUsancechgcode(String usancechgcode) {
		this.usancechgcode = usancechgcode;
	}

	public String getOlcatotalliabbasecurrency() {
		return olcatotalliabbasecurrency;
	}

	public void setOlcatotalliabbasecurrency(String olcatotalliabbasecurrency) {
		this.olcatotalliabbasecurrency = olcatotalliabbasecurrency;
	}

	public String getOlcatotalliablccurrency() {
		return olcatotalliablccurrency;
	}

	public void setOlcatotalliablccurrency(String olcatotalliablccurrency) {
		this.olcatotalliablccurrency = olcatotalliablccurrency;
	}

	public String getPrevdevamt() {
		return prevdevamt;
	}

	public void setPrevdevamt(String prevdevamt) {
		this.prevdevamt = prevdevamt;
	}

	public String getOlcMarginCurr() {
		return olcMarginCurr;
	}

	public void setOlcMarginCurr(String olcMarginCurr) {
		this.olcMarginCurr = olcMarginCurr;
	}

	public String getTotalcashmarginamt() {
		return totalcashmarginamt;
	}

	public void setTotalcashmarginamt(String totalcashmarginamt) {
		if (totalcashmarginamt.equalsIgnoreCase(""))
			this.totalcashmarginamt = "0";
		else
			this.totalcashmarginamt = totalcashmarginamt;
	}

	public String getTotalmarginamt() {
		return totalmarginamt;
	}

	public void setTotalmarginamt(String totalmarginamt) {
		if (totalmarginamt.equalsIgnoreCase(""))
			this.totalmarginamt = "0";
		else
			this.totalmarginamt = totalmarginamt;
	}

	public String getCashmarginamt() {
		return cashmarginamt;
	}

	public void setCashmarginamt(String cashmarginamt) {
		if (cashmarginamt.equalsIgnoreCase(""))
			this.cashmarginamt = "0";
		else
			this.cashmarginamt = cashmarginamt;
	}

	public String getEolmarginamt() {
		return eolmarginamt;
	}

	public void setEolmarginamt(String eolmarginamt) {
		if (eolmarginamt.equalsIgnoreCase(""))
			this.eolmarginamt = "0";
		else
			this.eolmarginamt = eolmarginamt;
	}

	public String getEolmarginper() {
		return eolmarginper;
	}

	public void setEolmarginper(String eolmarginper) {
		this.eolmarginper = eolmarginper;
	}

	public String getMarginamt() {
		return marginamt;
	}

	public void setMarginamt(String marginamt) {
		if (marginamt.equalsIgnoreCase(""))
			this.marginamt = "0";
		else
			this.marginamt = marginamt;
	}

	public String getMarginper() {
		return marginper;
	}

	public void setMarginper(String marginper) {
		this.marginper = marginper;
	}

	public String getEolcashmarginamt() {
		return eolcashmarginamt;
	}

	public void setEolcashmarginamt(String eolcashmarginamt) {
		if (eolcashmarginamt.equalsIgnoreCase(""))
			this.eolcashmarginamt = "0";
		else
			this.eolcashmarginamt = eolcashmarginamt;
	}

	public String getMargintype() {
		return margintype;
	}

	public void setMargintype(String margintype) {
		this.margintype = margintype;
	}

	public String getExcessoverlimitcurrtran() {
		return excessoverlimitcurrtran;
	}

	public void setExcessoverlimitcurrtran(String excessoverlimitcurrtran) {
		this.excessoverlimitcurrtran = excessoverlimitcurrtran;
	}

	public String getPrevcashmarginamt() {
		return prevcashmarginamt;
	}

	public void setPrevcashmarginamt(String prevcashmarginamt) {
		if (prevcashmarginamt.equalsIgnoreCase(""))
			this.prevcashmarginamt = "0";
		else
			this.prevcashmarginamt = prevcashmarginamt;
	}

	public String getPrevexccashmarginamt() {
		return prevexccashmarginamt;
	}

	public void setPrevexccashmarginamt(String prevexccashmarginamt) {
		if (prevexccashmarginamt.equalsIgnoreCase(""))
			this.prevexccashmarginamt = "0";
		else
			this.prevexccashmarginamt = prevexccashmarginamt;
	}

	public String getPrevexcmarginamt() {
		return prevexcmarginamt;
	}

	public void setPrevexcmarginamt(String prevexcmarginamt) {
		if (prevexcmarginamt.equalsIgnoreCase(""))
			this.prevexcmarginamt = "0";
		else
			this.prevexcmarginamt = prevexcmarginamt;
	}

	public String getPrevmarginamt() {
		return prevmarginamt;
	}

	public void setPrevmarginamt(String prevmarginamt) {
		if (prevmarginamt.equalsIgnoreCase(""))
			this.prevmarginamt = "0";
		else
			this.prevmarginamt = prevmarginamt;
	}

	public String getAMEND_RCVR_REF() {
		return AMEND_RCVR_REF;
	}

	public void setAMEND_RCVR_REF(String amend_rcvr_ref) {
		AMEND_RCVR_REF = amend_rcvr_ref;
	}

	public String getAMEND_DOC_CR_NUM() {
		return AMEND_DOC_CR_NUM;
	}

	public void setAMEND_DOC_CR_NUM(String amend_doc_cr_num) {
		AMEND_DOC_CR_NUM = amend_doc_cr_num;
	}

	public boolean isAMEND_ISSUING_BNK_REQ() {
		return AMEND_ISSUING_BNK_REQ;
	}

	public void setAMEND_ISSUING_BNK_REQ(boolean amend_issuing_bnk_req) {
		AMEND_ISSUING_BNK_REQ = amend_issuing_bnk_req;
	}

	public String getAMEND_ISSUING_TYPE() {
		return AMEND_ISSUING_TYPE;
	}

	public void setAMEND_ISSUING_TYPE(String amend_issuing_type) {
		AMEND_ISSUING_TYPE = amend_issuing_type;
	}

	public String getAMEND_ISSUING_BRN_CODE() {
		return AMEND_ISSUING_BRN_CODE;
	}

	public void setAMEND_ISSUING_BRN_CODE(String amend_issuing_brn_code) {
		AMEND_ISSUING_BRN_CODE = amend_issuing_brn_code;
	}

	public String getAMEND_ISSUING_BIC_CODE() {
		return AMEND_ISSUING_BIC_CODE;
	}

	public void setAMEND_ISSUING_BIC_CODE(String amend_issuing_bic_code) {
		AMEND_ISSUING_BIC_CODE = amend_issuing_bic_code;
	}

	public String getAMEND_ISSUING_ROUTID() {
		return AMEND_ISSUING_ROUTID;
	}

	public void setAMEND_ISSUING_ROUTID(String amend_issuing_routid) {
		AMEND_ISSUING_ROUTID = amend_issuing_routid;
	}

	public String getAMEND_ISSUING_BNK_CODE() {
		return AMEND_ISSUING_BNK_CODE;
	}

	public void setAMEND_ISSUING_BNK_CODE(String amend_issuing_bnk_code) {
		AMEND_ISSUING_BNK_CODE = amend_issuing_bnk_code;
	}

	public String getAMEND_ISSUING_ADDR() {
		return AMEND_ISSUING_ADDR;
	}

	public void setAMEND_ISSUING_ADDR(String amend_issuing_addr) {
		AMEND_ISSUING_ADDR = amend_issuing_addr;
	}

	public String getAMEND_NON_BNK_ISSUR() {
		return AMEND_NON_BNK_ISSUR;
	}

	public void setAMEND_NON_BNK_ISSUR(String amend_non_bnk_issur) {
		AMEND_NON_BNK_ISSUR = amend_non_bnk_issur;
	}

	public String getAMEND_DATE_OF_ISSUE() {
		return AMEND_DATE_OF_ISSUE;
	}

	public void setAMEND_DATE_OF_ISSUE(String amend_date_of_issue) {
		AMEND_DATE_OF_ISSUE = amend_date_of_issue;
	}

	public String getAMEND_DATE_OF_AMENDMENT() {
		return AMEND_DATE_OF_AMENDMENT;
	}

	public void setAMEND_DATE_OF_AMENDMENT(String amend_date_of_amendment) {
		AMEND_DATE_OF_AMENDMENT = amend_date_of_amendment;
	}

	public String getAMEND_PURPOSE_OF_MSG() {
		return AMEND_PURPOSE_OF_MSG;
	}

	public void setAMEND_PURPOSE_OF_MSG(String amend_purpose_of_msg) {
		AMEND_PURPOSE_OF_MSG = amend_purpose_of_msg;
	}

	public String getAMEND_CANCEL_REQUEST() {
		return AMEND_CANCEL_REQUEST;
	}

	public void setAMEND_CANCEL_REQUEST(String amend_cancel_request) {
		AMEND_CANCEL_REQUEST = amend_cancel_request;
	}

	public boolean isAMEND_ADVISING_BNK_REQ() {
		return AMEND_ADVISING_BNK_REQ;
	}

	public void setAMEND_ADVISING_BNK_REQ(boolean amend_advising_bnk_req) {
		AMEND_ADVISING_BNK_REQ = amend_advising_bnk_req;
	}

	public String getAMEND_ADVISING_BNK_TYPE() {
		return AMEND_ADVISING_BNK_TYPE;
	}

	public void setAMEND_ADVISING_BNK_TYPE(String amend_advising_bnk_type) {
		AMEND_ADVISING_BNK_TYPE = amend_advising_bnk_type;
	}

	public String getAMEND_ADVISING_BRN_CODE() {
		return AMEND_ADVISING_BRN_CODE;
	}

	public void setAMEND_ADVISING_BRN_CODE(String amend_advising_brn_code) {
		AMEND_ADVISING_BRN_CODE = amend_advising_brn_code;
	}

	public String getAMEND_ADVISING_BIC_CODE() {
		return AMEND_ADVISING_BIC_CODE;
	}

	public void setAMEND_ADVISING_BIC_CODE(String amend_advising_bic_code) {
		AMEND_ADVISING_BIC_CODE = amend_advising_bic_code;
	}

	public String getAMEND_ADVISING_BNK_CODE() {
		return AMEND_ADVISING_BNK_CODE;
	}

	public void setAMEND_ADVISING_BNK_CODE(String amend_advising_bnk_code) {
		AMEND_ADVISING_BNK_CODE = amend_advising_bnk_code;
	}

	public String getAMEND_ADVISING_ROUTID() {
		return AMEND_ADVISING_ROUTID;
	}

	public void setAMEND_ADVISING_ROUTID(String amend_advising_routid) {
		AMEND_ADVISING_ROUTID = amend_advising_routid;
	}

	public String getAMEND_ADVISING_ADDR() {
		return AMEND_ADVISING_ADDR;
	}

	public void setAMEND_ADVISING_ADDR(String amend_advising_addr) {
		AMEND_ADVISING_ADDR = amend_advising_addr;
	}

	public boolean isAMEND_SECOND_ADV_REQ() {
		return AMEND_SECOND_ADV_REQ;
	}

	public void setAMEND_SECOND_ADV_REQ(boolean amend_second_adv_req) {
		AMEND_SECOND_ADV_REQ = amend_second_adv_req;
	}

	public String getAMEND_SECOND_ADV_TYPE() {
		return AMEND_SECOND_ADV_TYPE;
	}

	public void setAMEND_SECOND_ADV_TYPE(String amend_second_adv_type) {
		AMEND_SECOND_ADV_TYPE = amend_second_adv_type;
	}

	public String getAMEND_SECOND_ADV_BRN_CODE() {
		return AMEND_SECOND_ADV_BRN_CODE;
	}

	public void setAMEND_SECOND_ADV_BRN_CODE(String amend_second_adv_brn_code) {
		AMEND_SECOND_ADV_BRN_CODE = amend_second_adv_brn_code;
	}

	public String getAMEND_SECOND_ADV_BIC_CODE() {
		return AMEND_SECOND_ADV_BIC_CODE;
	}

	public void setAMEND_SECOND_ADV_BIC_CODE(String amend_second_adv_bic_code) {
		AMEND_SECOND_ADV_BIC_CODE = amend_second_adv_bic_code;
	}

	public String getAMEND_SECOND_ADV_ROUTID() {
		return AMEND_SECOND_ADV_ROUTID;
	}

	public void setAMEND_SECOND_ADV_ROUTID(String amend_second_adv_routid) {
		AMEND_SECOND_ADV_ROUTID = amend_second_adv_routid;
	}

	public String getAMEND_SECOND_ADV_BNK_CODE() {
		return AMEND_SECOND_ADV_BNK_CODE;
	}

	public void setAMEND_SECOND_ADV_BNK_CODE(String amend_second_adv_bnk_code) {
		AMEND_SECOND_ADV_BNK_CODE = amend_second_adv_bnk_code;
	}

	public String getAMEND_SECOND_ADV_ADDR() {
		return AMEND_SECOND_ADV_ADDR;
	}

	public void setAMEND_SECOND_ADV_ADDR(String amend_second_adv_addr) {
		AMEND_SECOND_ADV_ADDR = amend_second_adv_addr;
	}

	public String getAMEND_NEW_BENEFICIARY() {
		return AMEND_NEW_BENEFICIARY;
	}

	public void setAMEND_NEW_BENEFICIARY(String amend_new_beneficiary) {
		AMEND_NEW_BENEFICIARY = amend_new_beneficiary;
	}

	public String getAMEND_NEW_DATE_OF_EXPIRY() {
		return AMEND_NEW_DATE_OF_EXPIRY;
	}

	public void setAMEND_NEW_DATE_OF_EXPIRY(String amend_new_date_of_expiry) {
		AMEND_NEW_DATE_OF_EXPIRY = amend_new_date_of_expiry;
	}

	public String getAMEND_INCR_DOC_CR_AMT() {
		return AMEND_INCR_DOC_CR_AMT;
	}

	public void setAMEND_INCR_DOC_CR_AMT(String amend_incr_doc_cr_amt) {
		AMEND_INCR_DOC_CR_AMT = amend_incr_doc_cr_amt;
	}

	public String getAMEND_DECR_DOC_CR_AMT() {
		return AMEND_DECR_DOC_CR_AMT;
	}

	public void setAMEND_DECR_DOC_CR_AMT(String amend_decr_doc_cr_amt) {
		AMEND_DECR_DOC_CR_AMT = amend_decr_doc_cr_amt;
	}

	public String getAMEND_NEW_ADDNL_AMT() {
		return AMEND_NEW_ADDNL_AMT;
	}

	public void setAMEND_NEW_ADDNL_AMT(String amend_new_addnl_amt) {
		AMEND_NEW_ADDNL_AMT = amend_new_addnl_amt;
	}

	public String getAMEND_PLACE_TAKIN_IN_CHRG() {
		return AMEND_PLACE_TAKIN_IN_CHRG;
	}

	public void setAMEND_PLACE_TAKIN_IN_CHRG(String amend_place_takin_in_chrg) {
		AMEND_PLACE_TAKIN_IN_CHRG = amend_place_takin_in_chrg;
	}

	public String getAMEND_PORT_OF_LOADING() {
		return AMEND_PORT_OF_LOADING;
	}

	public void setAMEND_PORT_OF_LOADING(String amend_port_of_loading) {
		AMEND_PORT_OF_LOADING = amend_port_of_loading;
	}

	public String getAMEND_PORT_OF_DISCHARGE() {
		return AMEND_PORT_OF_DISCHARGE;
	}

	public void setAMEND_PORT_OF_DISCHARGE(String amend_port_of_discharge) {
		AMEND_PORT_OF_DISCHARGE = amend_port_of_discharge;
	}

	public String getAMEND_PLACE_OF_FINAL_DEST() {
		return AMEND_PLACE_OF_FINAL_DEST;
	}

	public void setAMEND_PLACE_OF_FINAL_DEST(String amend_place_of_final_dest) {
		AMEND_PLACE_OF_FINAL_DEST = amend_place_of_final_dest;
	}

	public String getAMEND_DATE_OF_SHIPMENT() {
		return AMEND_DATE_OF_SHIPMENT;
	}

	public void setAMEND_DATE_OF_SHIPMENT(String amend_date_of_shipment) {
		AMEND_DATE_OF_SHIPMENT = amend_date_of_shipment;
	}

	public String getAMEND_DESC_GODD_SER1() {
		return AMEND_DESC_GODD_SER1;
	}

	public void setAMEND_DESC_GODD_SER1(String amend_desc_godd_ser1) {
		AMEND_DESC_GODD_SER1 = amend_desc_godd_ser1;
	}

	public String getAMEND_DOC_REQ1() {
		return AMEND_DOC_REQ1;
	}

	public void setAMEND_DOC_REQ1(String amend_doc_req1) {
		AMEND_DOC_REQ1 = amend_doc_req1;
	}

	public String getAMEND_ADD_CONDITION1() {
		return AMEND_ADD_CONDITION1;
	}

	public void setAMEND_ADD_CONDITION1(String amend_add_condition1) {
		AMEND_ADD_CONDITION1 = amend_add_condition1;
	}

	public String getAMEND_CHRG_PAYABLE() {
		return AMEND_CHRG_PAYABLE;
	}

	public void setAMEND_CHRG_PAYABLE(String amend_chrg_payable) {
		AMEND_CHRG_PAYABLE = amend_chrg_payable;
	}

	public String getAMEND_NEW_PRD_PRESNT_DAY() {
		return AMEND_NEW_PRD_PRESNT_DAY;
	}

	public void setAMEND_NEW_PRD_PRESNT_DAY(String amend_new_prd_presnt_day) {
		AMEND_NEW_PRD_PRESNT_DAY = amend_new_prd_presnt_day;
	}

	public String getAMEND_NEW_CONFIRM_INSTR() {
		return AMEND_NEW_CONFIRM_INSTR;
	}

	public void setAMEND_NEW_CONFIRM_INSTR(String amend_new_confirm_instr) {
		AMEND_NEW_CONFIRM_INSTR = amend_new_confirm_instr;
	}

	public String getAMEND_SPL_PAY_BENFICIARY() {
		return AMEND_SPL_PAY_BENFICIARY;
	}

	public void setAMEND_SPL_PAY_BENFICIARY(String amend_spl_pay_benficiary) {
		AMEND_SPL_PAY_BENFICIARY = amend_spl_pay_benficiary;
	}

	public String getAMEND_SPL_PAY_REC_BNK() {
		return AMEND_SPL_PAY_REC_BNK;
	}

	public void setAMEND_SPL_PAY_REC_BNK(String amend_spl_pay_rec_bnk) {
		AMEND_SPL_PAY_REC_BNK = amend_spl_pay_rec_bnk;
	}

	public String getAMEND_INSTR_TOPAYING() {
		return AMEND_INSTR_TOPAYING;
	}

	public void setAMEND_INSTR_TOPAYING(String amend_instr_topaying) {
		AMEND_INSTR_TOPAYING = amend_instr_topaying;
	}

	public String getAMEND_SNDR_REC_INFO() {
		return AMEND_SNDR_REC_INFO;
	}

	public void setAMEND_SNDR_REC_INFO(String amend_sndr_rec_info) {
		AMEND_SNDR_REC_INFO = amend_sndr_rec_info;
	}

	public boolean isAMEND_ENQUIRY_REQ() {
		return AMEND_ENQUIRY_REQ;
	}

	public void setAMEND_ENQUIRY_REQ(boolean amend_enquiry_req) {
		AMEND_ENQUIRY_REQ = amend_enquiry_req;
	}

	public boolean isAMEND_DC_REQ() {
		return AMEND_DC_REQ;
	}

	public void setAMEND_DC_REQ(boolean amend_dc_req) {
		AMEND_DC_REQ = amend_dc_req;
	}

	public boolean isAMEND_TOLERANCE_REQ() {
		return AMEND_TOLERANCE_REQ;
	}

	public void setAMEND_TOLERANCE_REQ(boolean amend_tolerance_req) {
		AMEND_TOLERANCE_REQ = amend_tolerance_req;
	}

	public boolean isAMEND_PLACE_REQ() {
		return AMEND_PLACE_REQ;
	}

	public void setAMEND_PLACE_REQ(boolean amend_place_req) {
		AMEND_PLACE_REQ = amend_place_req;
	}

	public boolean isAMEND_SHIPMNT_REQ() {
		return AMEND_SHIPMNT_REQ;
	}

	public void setAMEND_SHIPMNT_REQ(boolean amend_shipmnt_req) {
		AMEND_SHIPMNT_REQ = amend_shipmnt_req;
	}

	public String getAMEND_ISSUING_CNTRY() {
		return AMEND_ISSUING_CNTRY;
	}

	public void setAMEND_ISSUING_CNTRY(String amend_issuing_cntry) {
		AMEND_ISSUING_CNTRY = amend_issuing_cntry;
	}

	public String getAMEND_CHKBOX() {
		return AMEND_CHKBOX;
	}

	public void setAMEND_CHKBOX(String amend_chkbox) {
		AMEND_CHKBOX = amend_chkbox;
	}

	public String getAMEND_SNDR_REF() {
		return AMEND_SNDR_REF;
	}

	public void setAMEND_SNDR_REF(String amend_sndr_ref) {
		AMEND_SNDR_REF = amend_sndr_ref;
	}

	public String getAMEND_ISSUE_REF() {
		return AMEND_ISSUE_REF;
	}

	public void setAMEND_ISSUE_REF(String amend_issue_ref) {
		AMEND_ISSUE_REF = amend_issue_ref;
	}

	public boolean isChkChgDesc() {
		return chkChgDesc;
	}

	public void setChkChgDesc(boolean chkChgDesc) {
		this.chkChgDesc = chkChgDesc;
	}

	public boolean isChkChgDoc() {
		return chkChgDoc;
	}

	public void setChkChgDoc(boolean chkChgDoc) {
		this.chkChgDoc = chkChgDoc;
	}

	public boolean isChkChgAddCond() {
		return chkChgAddCond;
	}

	public void setChkChgAddCond(boolean chkChgAddCond) {
		this.chkChgAddCond = chkChgAddCond;
	}

	public String getLC_DESC_GOODS_SER1() {
		return LC_DESC_GOODS_SER1;
	}

	public void setLC_DESC_GOODS_SER1(String lc_desc_goods_ser1) {
		LC_DESC_GOODS_SER1 = lc_desc_goods_ser1;
	}

	public String getLC_DESC_GOODS_SER2() {
		return LC_DESC_GOODS_SER2;
	}

	public void setLC_DESC_GOODS_SER2(String lc_desc_goods_ser2) {
		LC_DESC_GOODS_SER2 = lc_desc_goods_ser2;
	}

	public String getLC_DESC_GOODS_SER3() {
		return LC_DESC_GOODS_SER3;
	}

	public void setLC_DESC_GOODS_SER3(String lc_desc_goods_ser3) {
		LC_DESC_GOODS_SER3 = lc_desc_goods_ser3;
	}

	public String getLC_DOC_REQ1() {
		return LC_DOC_REQ1;
	}

	public void setLC_DOC_REQ1(String lc_doc_req1) {
		LC_DOC_REQ1 = lc_doc_req1;
	}

	public String getLC_DOC_REQ2() {
		return LC_DOC_REQ2;
	}

	public void setLC_DOC_REQ2(String lc_doc_req2) {
		LC_DOC_REQ2 = lc_doc_req2;
	}

	public String getLC_DOC_REQ3() {
		return LC_DOC_REQ3;
	}

	public void setLC_DOC_REQ3(String lc_doc_req3) {
		LC_DOC_REQ3 = lc_doc_req3;
	}

	public String getLC_ADD_CONDITION1() {
		return LC_ADD_CONDITION1;
	}

	public void setLC_ADD_CONDITION1(String lc_add_condition1) {
		LC_ADD_CONDITION1 = lc_add_condition1;
	}

	public String getLC_ADD_CONDITION2() {
		return LC_ADD_CONDITION2;
	}

	public void setLC_ADD_CONDITION2(String lc_add_condition2) {
		LC_ADD_CONDITION2 = lc_add_condition2;
	}

	public String getLC_ADD_CONDITION3() {
		return LC_ADD_CONDITION3;
	}

	public void setLC_ADD_CONDITION3(String lc_add_condition3) {
		LC_ADD_CONDITION3 = lc_add_condition3;
	}

	public String getTxtCustomerNumber() {
		return txtCustomerNumber;
	}

	public void setTxtCustomerNumber(String txtCustomerNumber) {
		this.txtCustomerNumber = txtCustomerNumber;
	}

	public boolean isChkReqForCancel() {
		return chkReqForCancel;
	}

	public void setChkReqForCancel(boolean chkReqForCancel) {
		this.chkReqForCancel = chkReqForCancel;
	}

	public boolean isChkChgAppl() {
		return chkChgAppl;
	}

	public void setChkChgAppl(boolean chkChgAppl) {
		this.chkChgAppl = chkChgAppl;
	}

	public String getLC_FORM_OF_DOC_CREDIT() {
		return LC_FORM_OF_DOC_CREDIT;
	}

	public void setLC_FORM_OF_DOC_CREDIT(String lc_form_of_doc_credit) {
		LC_FORM_OF_DOC_CREDIT = lc_form_of_doc_credit;
	}

	public String getTxtApplCode() {
		return txtApplCode;
	}

	public void setTxtApplCode(String txtApplCode) {
		this.txtApplCode = txtApplCode;
	}

	public String getTxtApplName() {
		return txtApplName;
	}

	public void setTxtApplName(String txtApplName) {
		this.txtApplName = txtApplName;
	}

	public String getTxtApplAddress() {
		return txtApplAddress;
	}

	public void setTxtApplAddress(String txtApplAddress) {
		this.txtApplAddress = txtApplAddress;
	}

	public String getLC_APPLICABLE_RULES() {
		return LC_APPLICABLE_RULES;
	}

	public void setLC_APPLICABLE_RULES(String lc_applicable_rules) {
		LC_APPLICABLE_RULES = lc_applicable_rules;
	}

	public boolean isChkChgAvlWith() {
		return chkChgAvlWith;
	}

	public void setChkChgAvlWith(boolean chkChgAvlWith) {
		this.chkChgAvlWith = chkChgAvlWith;
	}

	public boolean isChkCgDrawee() {
		return chkCgDrawee;
	}

	public void setChkCgDrawee(boolean chkCgDrawee) {
		this.chkCgDrawee = chkCgDrawee;
	}

	public boolean isChkChgPresDays() {
		return chkChgPresDays;
	}

	public void setChkChgPresDays(boolean chkChgPresDays) {
		this.chkChgPresDays = chkChgPresDays;
	}

	public boolean isChkChgReimbus() {
		return chkChgReimbus;
	}

	public void setChkChgReimbus(boolean chkChgReimbus) {
		this.chkChgReimbus = chkChgReimbus;
	}

	public boolean isChkCgAdvBk() {
		return chkCgAdvBk;
	}

	public void setChkCgAdvBk(boolean chkCgAdvBk) {
		this.chkCgAdvBk = chkCgAdvBk;
	}

	public String getLC_AVAILABLE_WITH_CODETYP() {
		return LC_AVAILABLE_WITH_CODETYP;
	}

	public void setLC_AVAILABLE_WITH_CODETYP(String lc_available_with_codetyp) {
		LC_AVAILABLE_WITH_CODETYP = lc_available_with_codetyp;
	}

	public String getLC_AVAILABLE_WITH_TYPE() {
		return LC_AVAILABLE_WITH_TYPE;
	}

	public void setLC_AVAILABLE_WITH_TYPE(String lc_available_with_type) {
		LC_AVAILABLE_WITH_TYPE = lc_available_with_type;
	}

	public String getLC_AVAILABLE_WITH_BIC_CODE() {
		return LC_AVAILABLE_WITH_BIC_CODE;
	}

	public void setLC_AVAILABLE_WITH_BIC_CODE(String lc_available_with_bic_code) {
		LC_AVAILABLE_WITH_BIC_CODE = lc_available_with_bic_code;
	}

	public String getLC_AVAILABLE_WITH_BRN_CODE() {
		return LC_AVAILABLE_WITH_BRN_CODE;
	}

	public void setLC_AVAILABLE_WITH_BRN_CODE(String lc_available_with_brn_code) {
		LC_AVAILABLE_WITH_BRN_CODE = lc_available_with_brn_code;
	}

	public String getLC_AVAILABLE_WITH_ROUTID() {
		return LC_AVAILABLE_WITH_ROUTID;
	}

	public void setLC_AVAILABLE_WITH_ROUTID(String lc_available_with_routid) {
		LC_AVAILABLE_WITH_ROUTID = lc_available_with_routid;
	}

	public String getLC_AVAILABLE_WITH_BNK_CODE() {
		return LC_AVAILABLE_WITH_BNK_CODE;
	}

	public void setLC_AVAILABLE_WITH_BNK_CODE(String lc_available_with_bnk_code) {
		LC_AVAILABLE_WITH_BNK_CODE = lc_available_with_bnk_code;
	}

	public String getLC_AVAILABLE_WITH_ADDRESS() {
		return LC_AVAILABLE_WITH_ADDRESS;
	}

	public void setLC_AVAILABLE_WITH_ADDRESS(String lc_available_with_address) {
		LC_AVAILABLE_WITH_ADDRESS = lc_available_with_address;
	}

	public String getLC_AVAILABLE_WITH_CNTRY() {
		return LC_AVAILABLE_WITH_CNTRY;
	}

	public void setLC_AVAILABLE_WITH_CNTRY(String lc_available_with_cntry) {
		LC_AVAILABLE_WITH_CNTRY = lc_available_with_cntry;
	}

	public String getLC_DRAFTS_AT() {
		return LC_DRAFTS_AT;
	}

	public void setLC_DRAFTS_AT(String lc_drafts_at) {
		LC_DRAFTS_AT = lc_drafts_at;
	}

	public String getLC_DRAWEE_TYPE() {
		return LC_DRAWEE_TYPE;
	}

	public void setLC_DRAWEE_TYPE(String lc_drawee_type) {
		LC_DRAWEE_TYPE = lc_drawee_type;
	}

	public String getLC_DRAWEE_BIC_CODE() {
		return LC_DRAWEE_BIC_CODE;
	}

	public void setLC_DRAWEE_BIC_CODE(String lc_drawee_bic_code) {
		LC_DRAWEE_BIC_CODE = lc_drawee_bic_code;
	}

	public String getLC_DRAWEE_BRN_CODE() {
		return LC_DRAWEE_BRN_CODE;
	}

	public void setLC_DRAWEE_BRN_CODE(String lc_drawee_brn_code) {
		LC_DRAWEE_BRN_CODE = lc_drawee_brn_code;
	}

	public String getLC_DRAWEE_ROUTID() {
		return LC_DRAWEE_ROUTID;
	}

	public void setLC_DRAWEE_ROUTID(String lc_drawee_routid) {
		LC_DRAWEE_ROUTID = lc_drawee_routid;
	}

	public String getLC_DRAWEE_BNK_CODE() {
		return LC_DRAWEE_BNK_CODE;
	}

	public void setLC_DRAWEE_BNK_CODE(String lc_drawee_bnk_code) {
		LC_DRAWEE_BNK_CODE = lc_drawee_bnk_code;
	}

	public String getLC_DRAWEE_ADDRESS() {
		return LC_DRAWEE_ADDRESS;
	}

	public void setLC_DRAWEE_ADDRESS(String lc_drawee_address) {
		LC_DRAWEE_ADDRESS = lc_drawee_address;
	}

	public String getLC_DRAWEE_CNTRY_CODE() {
		return LC_DRAWEE_CNTRY_CODE;
	}

	public void setLC_DRAWEE_CNTRY_CODE(String lc_drawee_cntry_code) {
		LC_DRAWEE_CNTRY_CODE = lc_drawee_cntry_code;
	}

	public String getLC_MIXED_PAY_DETAILS() {
		return LC_MIXED_PAY_DETAILS;
	}

	public void setLC_MIXED_PAY_DETAILS(String lc_mixed_pay_details) {
		LC_MIXED_PAY_DETAILS = lc_mixed_pay_details;
	}

	public String getLC_DEFERRED_PAY_DETAILS() {
		return LC_DEFERRED_PAY_DETAILS;
	}

	public void setLC_DEFERRED_PAY_DETAILS(String lc_deferred_pay_details) {
		LC_DEFERRED_PAY_DETAILS = lc_deferred_pay_details;
	}

	public String getLC_PARTIAL_SHIPMENTS() {
		return LC_PARTIAL_SHIPMENTS;
	}

	public void setLC_PARTIAL_SHIPMENTS(String lc_partial_shipments) {
		LC_PARTIAL_SHIPMENTS = lc_partial_shipments;
	}

	public String getLC_TRANSHIPMENT() {
		return LC_TRANSHIPMENT;
	}

	public void setLC_TRANSHIPMENT(String lc_transhipment) {
		LC_TRANSHIPMENT = lc_transhipment;
	}

	public String getLC_CONFIRMATION_INST() {
		return LC_CONFIRMATION_INST;
	}

	public void setLC_CONFIRMATION_INST(String lc_confirmation_inst) {
		LC_CONFIRMATION_INST = lc_confirmation_inst;
	}

	public String getLC_REIMB_TYPE() {
		return LC_REIMB_TYPE;
	}

	public void setLC_REIMB_TYPE(String lc_reimb_type) {
		LC_REIMB_TYPE = lc_reimb_type;
	}

	public String getLC_REIMB_BIC_CODE() {
		return LC_REIMB_BIC_CODE;
	}

	public void setLC_REIMB_BIC_CODE(String lc_reimb_bic_code) {
		LC_REIMB_BIC_CODE = lc_reimb_bic_code;
	}

	public String getLC_REIMB_BRN_CODE() {
		return LC_REIMB_BRN_CODE;
	}

	public void setLC_REIMB_BRN_CODE(String lc_reimb_brn_code) {
		LC_REIMB_BRN_CODE = lc_reimb_brn_code;
	}

	public String getLC_REIMB_ROUTID() {
		return LC_REIMB_ROUTID;
	}

	public void setLC_REIMB_ROUTID(String lc_reimb_routid) {
		LC_REIMB_ROUTID = lc_reimb_routid;
	}

	public String getLC_REIMB_BNK_CODE() {
		return LC_REIMB_BNK_CODE;
	}

	public void setLC_REIMB_BNK_CODE(String lc_reimb_bnk_code) {
		LC_REIMB_BNK_CODE = lc_reimb_bnk_code;
	}

	public String getLC_REIMB_ADDRESS() {
		return LC_REIMB_ADDRESS;
	}

	public void setLC_REIMB_ADDRESS(String lc_reimb_address) {
		LC_REIMB_ADDRESS = lc_reimb_address;
	}

	public String getLC_REIMB_CNTRY_CODE() {
		return LC_REIMB_CNTRY_CODE;
	}

	public void setLC_REIMB_CNTRY_CODE(String lc_reimb_cntry_code) {
		LC_REIMB_CNTRY_CODE = lc_reimb_cntry_code;
	}

	public String getLC_INST_PAYING() {
		return LC_INST_PAYING;
	}

	public void setLC_INST_PAYING(String lc_inst_paying) {
		LC_INST_PAYING = lc_inst_paying;
	}
	//Changes Sanjay1 18-07-2019 Begin
	/*public String getOlcLcToBeCnfrmdByBk() {
		return olcLcToBeCnfrmdByBk;
	}

	public void setOlcLcToBeCnfrmdByBk(String olcLcToBeCnfrmdByBk) {
		this.olcLcToBeCnfrmdByBk = olcLcToBeCnfrmdByBk;
	}

	public String getOlcLcToBeCnfrmdByBrn() {
		return olcLcToBeCnfrmdByBrn;
	}

	public void setOlcLcToBeCnfrmdByBrn(String olcLcToBeCnfrmdByBrn) {
		this.olcLcToBeCnfrmdByBrn = olcLcToBeCnfrmdByBrn;
	}

	public String getOlcLcToBeCnfrmdByBrnName() {
		return olcLcToBeCnfrmdByBrnName;
	}

	public void setOlcLcToBeCnfrmdByBrnName(String olcLcToBeCnfrmdByBrnName) {
		this.olcLcToBeCnfrmdByBrnName = olcLcToBeCnfrmdByBrnName;
	}*/
	//Changes Sanjay1 18-07-2019 Begin
	public String getLC_SECOND_ADV_TYPE() {
		return LC_SECOND_ADV_TYPE;
	}

	public void setLC_SECOND_ADV_TYPE(String lc_second_adv_type) {
		LC_SECOND_ADV_TYPE = lc_second_adv_type;
	}

	public String getLC_SECOND_ADV_BIC_CODE() {
		return LC_SECOND_ADV_BIC_CODE;
	}

	public void setLC_SECOND_ADV_BIC_CODE(String lc_second_adv_bic_code) {
		LC_SECOND_ADV_BIC_CODE = lc_second_adv_bic_code;
	}

	public String getLC_SECOND_ADV_BRN_CODE() {
		return LC_SECOND_ADV_BRN_CODE;
	}

	public void setLC_SECOND_ADV_BRN_CODE(String lc_second_adv_brn_code) {
		LC_SECOND_ADV_BRN_CODE = lc_second_adv_brn_code;
	}

	public String getLC_SECOND_ADV_ROUTID() {
		return LC_SECOND_ADV_ROUTID;
	}

	public void setLC_SECOND_ADV_ROUTID(String lc_second_adv_routid) {
		LC_SECOND_ADV_ROUTID = lc_second_adv_routid;
	}

	public String getLC_SECOND_ADV_BNK_CODE() {
		return LC_SECOND_ADV_BNK_CODE;
	}

	public void setLC_SECOND_ADV_BNK_CODE(String lc_second_adv_bnk_code) {
		LC_SECOND_ADV_BNK_CODE = lc_second_adv_bnk_code;
	}

	public String getLC_SECOND_ADV_ADDRESS() {
		return LC_SECOND_ADV_ADDRESS;
	}

	public void setLC_SECOND_ADV_ADDRESS(String lc_second_adv_address) {
		LC_SECOND_ADV_ADDRESS = lc_second_adv_address;
	}

	public String getLC_SECOND_ADV_CNTRYCODE() {
		return LC_SECOND_ADV_CNTRYCODE;
	}

	public void setLC_SECOND_ADV_CNTRYCODE(String lc_second_adv_cntrycode) {
		LC_SECOND_ADV_CNTRYCODE = lc_second_adv_cntrycode;
	}

	public String getLC_SNDR_REC_INFO() {
		return LC_SNDR_REC_INFO;
	}

	public void setLC_SNDR_REC_INFO(String lc_sndr_rec_info) {
		LC_SNDR_REC_INFO = lc_sndr_rec_info;
	}

	public String getLC_REC_BIC_CODE() {
		return LC_REC_BIC_CODE;
	}

	public void setLC_REC_BIC_CODE(String lc_rec_bic_code) {
		LC_REC_BIC_CODE = lc_rec_bic_code;
	}

	public String getOlcamdchgspayby() {
		return olcamdchgspayby;
	}

	public void setOlcamdchgspayby(String olcamdchgspayby) {
		this.olcamdchgspayby = olcamdchgspayby;
	}

	public String getTxtperiodOfPres() {
		return txtperiodOfPres;
	}

	public void setTxtperiodOfPres(String txtperiodOfPres) {
		this.txtperiodOfPres = txtperiodOfPres;
	}

	public boolean isLC_DRAWEE_REQ() {
		return LC_DRAWEE_REQ;
	}

	public void setLC_DRAWEE_REQ(boolean lc_drawee_req) {
		LC_DRAWEE_REQ = lc_drawee_req;
	}

	public boolean isLC_REIMB_REQ() {
		return LC_REIMB_REQ;
	}

	public void setLC_REIMB_REQ(boolean lc_reimb_req) {
		LC_REIMB_REQ = lc_reimb_req;
	}

	public boolean isLC_SECOND_ADV_REQ() {
		return LC_SECOND_ADV_REQ;
	}

	public void setLC_SECOND_ADV_REQ(boolean lc_second_adv_req) {
		LC_SECOND_ADV_REQ = lc_second_adv_req;
	}

	public boolean isChkChgFormDc() {
		return chkChgFormDc;
	}

	public void setChkChgFormDc(boolean chkChgFormDc) {
		this.chkChgFormDc = chkChgFormDc;
	}

	public boolean isChkChgApplRules() {
		return chkChgApplRules;
	}

	public void setChkChgApplRules(boolean chkChgApplRules) {
		this.chkChgApplRules = chkChgApplRules;
	}

	public String getTxtChoiceSl() {
		return txtChoiceSl;
	}

	public void setTxtChoiceSl(String txtChoiceSl) {
		this.txtChoiceSl = txtChoiceSl;
	}

	public String getTxtfrmRange() {
		return txtfrmRange;
	}

	public void setTxtfrmRange(String txtfrmRange) {
		this.txtfrmRange = txtfrmRange;
	}

	public String getUptoRange() {
		return uptoRange;
	}

	public void setUptoRange(String uptoRange) {
		this.uptoRange = uptoRange;
	}

	public String getTxtApplInsOrRepl() {
		return txtApplInsOrRepl;
	}

	public void setTxtApplInsOrRepl(String txtApplInsOrRepl) {
		this.txtApplInsOrRepl = txtApplInsOrRepl;
	}

	public String getTxtAmdLog() {
		return txtAmdLog;
	}

	public void setTxtAmdLog(String txtAmdLog) {
		this.txtAmdLog = txtAmdLog;
	}

	public String getTxtcompAmdDetails() {
		return txtcompAmdDetails;
	}

	public void setTxtcompAmdDetails(String txtcompAmdDetails) {
		this.txtcompAmdDetails = txtcompAmdDetails;
	}

	public String getTxtChoiceSlDoc() {
		return txtChoiceSlDoc;
	}

	public void setTxtChoiceSlDoc(String txtChoiceSlDoc) {
		this.txtChoiceSlDoc = txtChoiceSlDoc;
	}

	public String getTxtfrmRangeDoc() {
		return txtfrmRangeDoc;
	}

	public void setTxtfrmRangeDoc(String txtfrmRangeDoc) {
		this.txtfrmRangeDoc = txtfrmRangeDoc;
	}

	public String getUptoRangeDoc() {
		return uptoRangeDoc;
	}

	public void setUptoRangeDoc(String uptoRangeDoc) {
		this.uptoRangeDoc = uptoRangeDoc;
	}

	public String getTxtApplInsOrReplDoc() {
		return txtApplInsOrReplDoc;
	}

	public void setTxtApplInsOrReplDoc(String txtApplInsOrReplDoc) {
		this.txtApplInsOrReplDoc = txtApplInsOrReplDoc;
	}

	public String getTxtAmdLogDoc() {
		return txtAmdLogDoc;
	}

	public void setTxtAmdLogDoc(String txtAmdLogDoc) {
		this.txtAmdLogDoc = txtAmdLogDoc;
	}

	public String getTxtcompAmdDetailsDoc() {
		return txtcompAmdDetailsDoc;
	}

	public void setTxtcompAmdDetailsDoc(String txtcompAmdDetailsDoc) {
		this.txtcompAmdDetailsDoc = txtcompAmdDetailsDoc;
	}

	public String getTxtChoiceSlAddl() {
		return txtChoiceSlAddl;
	}

	public void setTxtChoiceSlAddl(String txtChoiceSlAddl) {
		this.txtChoiceSlAddl = txtChoiceSlAddl;
	}

	public String getTxtfrmRangeAddl() {
		return txtfrmRangeAddl;
	}

	public void setTxtfrmRangeAddl(String txtfrmRangeAddl) {
		this.txtfrmRangeAddl = txtfrmRangeAddl;
	}

	public String getUptoRangeAddl() {
		return uptoRangeAddl;
	}

	public void setUptoRangeAddl(String uptoRangeAddl) {
		this.uptoRangeAddl = uptoRangeAddl;
	}

	public String getTxtApplInsOrReplAddl() {
		return txtApplInsOrReplAddl;
	}

	public void setTxtApplInsOrReplAddl(String txtApplInsOrReplAddl) {
		this.txtApplInsOrReplAddl = txtApplInsOrReplAddl;
	}

	public String getTxtAmdLogAddl() {
		return txtAmdLogAddl;
	}

	public void setTxtAmdLogAddl(String txtAmdLogAddl) {
		this.txtAmdLogAddl = txtAmdLogAddl;
	}

	public String getTxtcompAmdDetailsAddl() {
		return txtcompAmdDetailsAddl;
	}

	public void setTxtcompAmdDetailsAddl(String txtcompAmdDetailsAddl) {
		this.txtcompAmdDetailsAddl = txtcompAmdDetailsAddl;
	}

	public String getTxtChoiceSlSplBene() {
		return txtChoiceSlSplBene;
	}

	public void setTxtChoiceSlSplBene(String txtChoiceSlSplBene) {
		this.txtChoiceSlSplBene = txtChoiceSlSplBene;
	}

	public String getTxtfrmRangeSplBene() {
		return txtfrmRangeSplBene;
	}

	public void setTxtfrmRangeSplBene(String txtfrmRangeSplBene) {
		this.txtfrmRangeSplBene = txtfrmRangeSplBene;
	}

	public String getUptoRangeSplBene() {
		return uptoRangeSplBene;
	}

	public void setUptoRangeSplBene(String uptoRangeSplBene) {
		this.uptoRangeSplBene = uptoRangeSplBene;
	}

	public String getTxtApplInsOrReplSplBene() {
		return txtApplInsOrReplSplBene;
	}

	public void setTxtApplInsOrReplSplBene(String txtApplInsOrReplSplBene) {
		this.txtApplInsOrReplSplBene = txtApplInsOrReplSplBene;
	}

	public String getTxtAmdLogSplBene() {
		return txtAmdLogSplBene;
	}

	public void setTxtAmdLogSplBene(String txtAmdLogSplBene) {
		this.txtAmdLogSplBene = txtAmdLogSplBene;
	}

	public String getTxtcompAmdDetailsSplBene() {
		return txtcompAmdDetailsSplBene;
	}

	public void setTxtcompAmdDetailsSplBene(String txtcompAmdDetailsSplBene) {
		this.txtcompAmdDetailsSplBene = txtcompAmdDetailsSplBene;
	}

	public String getTxtChoiceSlSplRecev() {
		return txtChoiceSlSplRecev;
	}

	public void setTxtChoiceSlSplRecev(String txtChoiceSlSplRecev) {
		this.txtChoiceSlSplRecev = txtChoiceSlSplRecev;
	}

	public String getTxtfrmRangeSplRecev() {
		return txtfrmRangeSplRecev;
	}

	public void setTxtfrmRangeSplRecev(String txtfrmRangeSplRecev) {
		this.txtfrmRangeSplRecev = txtfrmRangeSplRecev;
	}

	public String getUptoRangeSplRecev() {
		return uptoRangeSplRecev;
	}

	public void setUptoRangeSplRecev(String uptoRangeSplRecev) {
		this.uptoRangeSplRecev = uptoRangeSplRecev;
	}

	public String getTxtApplInsOrReplSplRecev() {
		return txtApplInsOrReplSplRecev;
	}

	public void setTxtApplInsOrReplSplRecev(String txtApplInsOrReplSplRecev) {
		this.txtApplInsOrReplSplRecev = txtApplInsOrReplSplRecev;
	}

	public String getTxtAmdLogSplRecev() {
		return txtAmdLogSplRecev;
	}

	public void setTxtAmdLogSplRecev(String txtAmdLogSplRecev) {
		this.txtAmdLogSplRecev = txtAmdLogSplRecev;
	}

	public String getTxtcompAmdDetailsSplRecev() {
		return txtcompAmdDetailsSplRecev;
	}

	public void setTxtcompAmdDetailsSplRecev(String txtcompAmdDetailsSplRecev) {
		this.txtcompAmdDetailsSplRecev = txtcompAmdDetailsSplRecev;
	}

	public String[] getApplicant_add() {
		return applicant_add;
	}

	public void setApplicant_add(String[] applicant_add) {
		this.applicant_add = applicant_add;
	}

	public String[] getAvailbl_with_add() {
		return availbl_with_add;
	}

	public void setAvailbl_with_add(String[] availbl_with_add) {
		this.availbl_with_add = availbl_with_add;
	}

	public String[] getDrawee_add() {
		return drawee_add;
	}

	public void setDrawee_add(String[] drawee_add) {
		this.drawee_add = drawee_add;
	}

	public String[] getReimb_add() {
		return reimb_add;
	}

	public void setReimb_add(String[] reimb_add) {
		this.reimb_add = reimb_add;
	}

	public String[] getInstr_paying() {
		return instr_paying;
	}

	public void setInstr_paying(String[] instr_paying) {
		this.instr_paying = instr_paying;
	}

	public String[] getBank_addr() {
		return bank_addr;
	}

	public void setBank_addr(String[] bank_addr) {
		this.bank_addr = bank_addr;
	}

	public String[] getDrafts() {
		return drafts;
	}

	public void setDrafts(String[] drafts) {
		this.drafts = drafts;
	}

	public String[] getDef_pay_details() {
		return def_pay_details;
	}

	public void setDef_pay_details(String[] def_pay_details) {
		this.def_pay_details = def_pay_details;
	}

	public String[] getMixed_pay_details() {
		return mixed_pay_details;
	}

	public void setMixed_pay_details(String[] mixed_pay_details) {
		this.mixed_pay_details = mixed_pay_details;
	}

	public String[] getSecond_adv_add() {
		return second_adv_add;
	}

	public void setSecond_adv_add(String[] second_adv_add) {
		this.second_adv_add = second_adv_add;
	}

	public String getMtranchgschgssl() {
		return mtranchgschgssl;
	}

	public void setMtranchgschgssl(String mtranchgschgssl) {
		this.mtranchgschgssl = mtranchgschgssl;
	}

	public String get_tnomenNumChoice() {
		return _tnomenNumChoice;
	}

	public void set_tnomenNumChoice(String numChoice) {
		_tnomenNumChoice = numChoice;
	}

	public String get_tenomen_auto_num() {
		return _tenomen_auto_num;
	}

	public void set_tenomen_auto_num(String _tenomen_auto_num) {
		this._tenomen_auto_num = _tenomen_auto_num;
	}

	public String get_olca_entry_date() {
		return _olca_entry_date;
	}

	public void set_olca_entry_date(String _olca_entry_date) {
		this._olca_entry_date = _olca_entry_date;
	}

	public int getVal() {
		return val;
	}

	public void setVal(int val) {
		this.val = val;
	}

	public int getVal2() {
		return val2;
	}

	public void setVal2(int val2) {
		this.val2 = val2;
	}

	public String getXml_str() {
		return xml_str;
	}

	public void setXml_str(String xml_str) {
		this.xml_str = xml_str;
	}

	public String getXmlstr() {
		return xmlstr;
	}

	public void setXmlstr(String xmlstr) {
		this.xmlstr = xmlstr;
	}

	public String[] getPrev_tenor_amt() {
		return prev_tenor_amt;
	}

	public void setPrev_tenor_amt(String[] prev_tenor_amt) {
		this.prev_tenor_amt = prev_tenor_amt;
	}

	public String[] getTotal_Liab_amt() {
		return total_Liab_amt;
	}

	public void setTotal_Liab_amt(String[] total_Liab_amt) {
		this.total_Liab_amt = total_Liab_amt;
	}

	public String[] getTest() {
		return test;
	}

	public void setTest(String[] test) {
		this.test = test;
	}

	public DTObject getRevalDTO() {
		return revalDTO;
	}

	public void setRevalDTO(DTObject revalDTO) {
		this.revalDTO = revalDTO;
	}

	public DTObject getDTOResult() {
		return DTOResult;
	}

	public void setDTOResult(DTObject result) {
		DTOResult = result;
	}

	public gridXML getRevallcpsGrid1() {
		return revallcpsGrid1;
	}

	public void setRevallcpsGrid1(gridXML revallcpsGrid1) {
		this.revallcpsGrid1 = revallcpsGrid1;
	}

	public DTObject getInputDTO() {
		return inputDTO;
	}

	public void setInputDTO(DTObject inputDTO) {
		this.inputDTO = inputDTO;
	}

	public DTObject getOutputDTO() {
		return outputDTO;
	}

	public void setOutputDTO(DTObject outputDTO) {
		this.outputDTO = outputDTO;
	}

	public QueryManager getQueryManagerInstance() {
		return QueryManagerInstance;
	}

	public void setQueryManagerInstance(QueryManager queryManagerInstance) {
		QueryManagerInstance = queryManagerInstance;
	}

	public eolcamdval getEolcamdvalinstance() {
		return eolcamdvalinstance;
	}

	public void setEolcamdvalinstance(eolcamdval eolcamdvalinstance) {
		this.eolcamdvalinstance = eolcamdvalinstance;
	}

	public String getPostbrn() {
		return postbrn;
	}

	public void setPostbrn(String postbrn) {
		this.postbrn = postbrn;
	}

	public String getPostdate() {
		return postdate;
	}

	public void setPostdate(String postdate) {
		this.postdate = postdate;
	}

	public String getPostbatchnum() {
		return postbatchnum;
	}

	public void setPostbatchnum(String postbatchnum) {
		this.postbatchnum = postbatchnum;
	}

	public String getBaseCurr() {
		return baseCurr;
	}

	public void setBaseCurr(String baseCurr) {
		this.baseCurr = baseCurr;
	}

	public String getOlcmarginamt() {
		return olcmarginamt;
	}

	public void setOlcmarginamt(String olcmarginamt) {
		this.olcmarginamt = olcmarginamt;
	}

	public String getOlcmarginbal() {
		return olcmarginbal;
	}

	public void setOlcmarginbal(String olcmarginbal) {
		this.olcmarginbal = olcmarginbal;
	}

	public String getOlccashmaramt() {
		return olccashmaramt;
	}

	public void setOlccashmaramt(String olccashmaramt) {
		this.olccashmaramt = olccashmaramt;
	}

	public String getOlccashmarbal() {
		return olccashmarbal;
	}

	public void setOlccashmarbal(String olccashmarbal) {
		this.olccashmarbal = olccashmarbal;
	}

	public double getOlcmarginamt1() {
		return olcmarginamt1;
	}

	public void setOlcmarginamt1(double olcmarginamt1) {
		this.olcmarginamt1 = olcmarginamt1;
	}

	public double getOlccashmarginamt1() {
		return olccashmarginamt1;
	}

	public void setOlccashmarginamt1(double olccashmarginamt1) {
		this.olccashmarginamt1 = olccashmarginamt1;
	}

	public double getOlccashmarbal1() {
		return olccashmarbal1;
	}

	public void setOlccashmarbal1(double olccashmarbal1) {
		this.olccashmarbal1 = olccashmarbal1;
	}

	public double getMarginbal() {
		return marginbal;
	}

	public void setMarginbal(double marginbal) {
		this.marginbal = marginbal;
	}

	public double getOlcmarginbal1() {
		return olcmarginbal1;
	}

	public void setOlcmarginbal1(double olcmarginbal1) {
		this.olcmarginbal1 = olcmarginbal1;
	}

	public double getPrevtotalmarginamt() {
		return prevtotalmarginamt;
	}

	public void setPrevtotalmarginamt(double prevtotalmarginamt) {
		this.prevtotalmarginamt = prevtotalmarginamt;
	}

	public double getPrevtotalcashmarginamt() {
		return prevtotalcashmarginamt;
	}

	public void setPrevtotalcashmarginamt(double prevtotalcashmarginamt) {
		this.prevtotalcashmarginamt = prevtotalcashmarginamt;
	}

	public double getPrevmarginbal() {
		return prevmarginbal;
	}

	public void setPrevmarginbal(double prevmarginbal) {
		this.prevmarginbal = prevmarginbal;
	}

	public double getPrevcashmarbal() {
		return prevcashmarbal;
	}

	public void setPrevcashmarbal(double prevcashmarbal) {
		this.prevcashmarbal = prevcashmarbal;
	}

	public String getMredliabbasecurr() {
		return mredliabbasecurr;
	}

	public void setMredliabbasecurr(String mredliabbasecurr) {
		this.mredliabbasecurr = mredliabbasecurr;
	}

	public String getZeroval() {
		return zeroval;
	}

	public void setZeroval(String zeroval) {
		this.zeroval = zeroval;
	}

	public String get_brnAuth() {
		return _brnAuth;
	}

	public void set_brnAuth(String auth) {
		_brnAuth = auth;
	}

	public String get_lcTypeAuth() {
		return _lcTypeAuth;
	}

	public void set_lcTypeAuth(String typeAuth) {
		_lcTypeAuth = typeAuth;
	}

	public String getTemp_str() {
		return temp_str;
	}

	public void setTemp_str(String temp_str) {
		this.temp_str = temp_str;
	}

	public String[] getSend_to_rec() {
		return send_to_rec;
	}

	public void setSend_to_rec(String[] send_to_rec) {
		this.send_to_rec = send_to_rec;
	}

	public String[] getIssuing_bank() {
		return issuing_bank;
	}

	public void setIssuing_bank(String[] issuing_bank) {
		this.issuing_bank = issuing_bank;
	}

	public String[] get_desp() {
		return _desp;
	}

	public void set_desp(String[] _desp) {
		this._desp = _desp;
	}

	public int getShipmnt_chkbx() {
		return shipmnt_chkbx;
	}

	public void setShipmnt_chkbx(int shipmnt_chkbx) {
		this.shipmnt_chkbx = shipmnt_chkbx;
	}

	public int getPlace_chkbx() {
		return place_chkbx;
	}

	public void setPlace_chkbx(int place_chkbx) {
		this.place_chkbx = place_chkbx;
	}

	public int getEnquiry_chkbox() {
		return enquiry_chkbox;
	}

	public void setEnquiry_chkbox(int enquiry_chkbox) {
		this.enquiry_chkbox = enquiry_chkbox;
	}

	public int getDc_chkbox() {
		return dc_chkbox;
	}

	public void setDc_chkbox(int dc_chkbox) {
		this.dc_chkbox = dc_chkbox;
	}

	public int getTolerance_chkbox() {
		return tolerance_chkbox;
	}

	public void setTolerance_chkbox(int tolerance_chkbox) {
		this.tolerance_chkbox = tolerance_chkbox;
	}

	public int getChkbox1() {
		return chkbox1;
	}

	public void setChkbox1(int chkbox1) {
		this.chkbox1 = chkbox1;
	}

	public int getChkbox2() {
		return chkbox2;
	}

	public void setChkbox2(int chkbox2) {
		this.chkbox2 = chkbox2;
	}

	public int getChkbox3() {
		return chkbox3;
	}

	public void setChkbox3(int chkbox3) {
		this.chkbox3 = chkbox3;
	}

	public int getChkbox4() {
		return chkbox4;
	}

	public void setChkbox4(int chkbox4) {
		this.chkbox4 = chkbox4;
	}

	public int getChkbox5() {
		return chkbox5;
	}

	public void setChkbox5(int chkbox5) {
		this.chkbox5 = chkbox5;
	}

	public int getChkbox6() {
		return chkbox6;
	}

	public void setChkbox6(int chkbox6) {
		this.chkbox6 = chkbox6;
	}

	public String getOlcrefnum() {
		return olcrefnum;
	}

	public void setOlcrefnum(String olcrefnum) {
		this.olcrefnum = olcrefnum;
	}

	public String getReceiver_bic() {
		return receiver_bic;
	}

	public void setReceiver_bic(String receiver_bic) {
		this.receiver_bic = receiver_bic;
	}

	public String getPlace_tkn_chrg() {
		return place_tkn_chrg;
	}

	public void setPlace_tkn_chrg(String place_tkn_chrg) {
		this.place_tkn_chrg = place_tkn_chrg;
	}

	public String getPort_of_loading() {
		return port_of_loading;
	}

	public void setPort_of_loading(String port_of_loading) {
		this.port_of_loading = port_of_loading;
	}

	public String getPort_of_dischrg() {
		return port_of_dischrg;
	}

	public void setPort_of_dischrg(String port_of_dischrg) {
		this.port_of_dischrg = port_of_dischrg;
	}

	public String getPlace_finl_detination() {
		return place_finl_detination;
	}

	public void setPlace_finl_detination(String place_finl_detination) {
		this.place_finl_detination = place_finl_detination;
	}

	public String getAmdGoodsValue() {
		return amdGoodsValue;
	}

	public void setAmdGoodsValue(String amdGoodsValue) {
		this.amdGoodsValue = amdGoodsValue;
	}

	public String getAmdDocsValue() {
		return amdDocsValue;
	}

	public void setAmdDocsValue(String amdDocsValue) {
		this.amdDocsValue = amdDocsValue;
	}

	public String getAmdAddlValue() {
		return amdAddlValue;
	}

	public void setAmdAddlValue(String amdAddlValue) {
		this.amdAddlValue = amdAddlValue;
	}

	public String getAmdSpl1Value() {
		return amdSpl1Value;
	}

	public void setAmdSpl1Value(String amdSpl1Value) {
		this.amdSpl1Value = amdSpl1Value;
	}

	public String getAmdSpl2Value() {
		return amdSpl2Value;
	}

	public void setAmdSpl2Value(String amdSpl2Value) {
		this.amdSpl2Value = amdSpl2Value;
	}

	public String getTxtAmdLogHidden() {
		return txtAmdLogHidden;
	}

	public void setTxtAmdLogHidden(String txtAmdLogHidden) {
		this.txtAmdLogHidden = txtAmdLogHidden;
	}

	public String getAmdlogtemp1() {
		return amdlogtemp1;
	}

	public void setAmdlogtemp1(String amdlogtemp1) {
		this.amdlogtemp1 = amdlogtemp1;
	}

	public String getAmdlogtemp2() {
		return amdlogtemp2;
	}

	public void setAmdlogtemp2(String amdlogtemp2) {
		this.amdlogtemp2 = amdlogtemp2;
	}

	public String getAmdlogtemp3() {
		return amdlogtemp3;
	}

	public void setAmdlogtemp3(String amdlogtemp3) {
		this.amdlogtemp3 = amdlogtemp3;
	}

	public String getAmdlogtemp4() {
		return amdlogtemp4;
	}

	public void setAmdlogtemp4(String amdlogtemp4) {
		this.amdlogtemp4 = amdlogtemp4;
	}

	public String getAmdlogtemp5() {
		return amdlogtemp5;
	}

	public void setAmdlogtemp5(String amdlogtemp5) {
		this.amdlogtemp5 = amdlogtemp5;
	}

	public String getOldchkChgDesc() {
		return oldchkChgDesc;
	}

	public void setOldchkChgDesc(String oldchkChgDesc) {
		this.oldchkChgDesc = oldchkChgDesc;
	}

	public String getOldchkChgDoc() {
		return oldchkChgDoc;
	}

	public void setOldchkChgDoc(String oldchkChgDoc) {
		this.oldchkChgDoc = oldchkChgDoc;
	}

	public String getOldchkChgAddCond() {
		return oldchkChgAddCond;
	}

	public void setOldchkChgAddCond(String oldchkChgAddCond) {
		this.oldchkChgAddCond = oldchkChgAddCond;
	}

	public String getLC_REIMB_CFM_TYPE() {
		return LC_REIMB_CFM_TYPE;
	}

	public void setLC_REIMB_CFM_TYPE(String lc_reimb_cfm_type) {
		LC_REIMB_CFM_TYPE = lc_reimb_cfm_type;
	}

	public String getLC_REIMB_CFM_BRN_CODE() {
		return LC_REIMB_CFM_BRN_CODE;
	}

	public void setLC_REIMB_CFM_BRN_CODE(String lc_reimb_cfm_brn_code) {
		LC_REIMB_CFM_BRN_CODE = lc_reimb_cfm_brn_code;
	}

	public String getLC_REIMB_CFM_BIC_CODE() {
		return LC_REIMB_CFM_BIC_CODE;
	}

	public void setLC_REIMB_CFM_BIC_CODE(String lc_reimb_cfm_bic_code) {
		LC_REIMB_CFM_BIC_CODE = lc_reimb_cfm_bic_code;
	}

	public String getLC_CFM_REIMB_ROUTID() {
		return LC_CFM_REIMB_ROUTID;
	}

	public void setLC_CFM_REIMB_ROUTID(String lc_cfm_reimb_routid) {
		LC_CFM_REIMB_ROUTID = lc_cfm_reimb_routid;
	}

	public String getLC_CFM_REIMB_BNK_CODE() {
		return LC_CFM_REIMB_BNK_CODE;
	}

	public void setLC_CFM_REIMB_BNK_CODE(String lc_cfm_reimb_bnk_code) {
		LC_CFM_REIMB_BNK_CODE = lc_cfm_reimb_bnk_code;
	}

	public String getLC_CFM_REIMB_ADDRESS() {
		return LC_CFM_REIMB_ADDRESS;
	}

	public void setLC_CFM_REIMB_ADDRESS(String lc_cfm_reimb_address) {
		LC_CFM_REIMB_ADDRESS = lc_cfm_reimb_address;
	}

	public String getLC_CFM_REIMB_CNTRY_CODE() {
		return LC_CFM_REIMB_CNTRY_CODE;
	}

	public void setLC_CFM_REIMB_CNTRY_CODE(String lc_cfm_reimb_cntry_code) {
		LC_CFM_REIMB_CNTRY_CODE = lc_cfm_reimb_cntry_code;
	}

	public String getChangeinapplicablerules() {
		return changeinapplicablerules;
	}

	public void setChangeinapplicablerules(String changeinapplicablerules) {
		this.changeinapplicablerules = changeinapplicablerules;
	}

	public String getChangeinavailablewith() {
		return changeinavailablewith;
	}

	public void setChangeinavailablewith(String changeinavailablewith) {
		this.changeinavailablewith = changeinavailablewith;
	}

	public String getChangeindrawee() {
		return changeindrawee;
	}

	public void setChangeindrawee(String changeindrawee) {
		this.changeindrawee = changeindrawee;
	}

	public String getChangeinreimbursement() {
		return changeinreimbursement;
	}

	public void setChangeinreimbursement(String changeinreimbursement) {
		this.changeinreimbursement = changeinreimbursement;
	}

	public String getChangeinadvisingbank() {
		return changeinadvisingbank;
	}

	public void setChangeinadvisingbank(String changeinadvisingbank) {
		this.changeinadvisingbank = changeinadvisingbank;
	}
}
