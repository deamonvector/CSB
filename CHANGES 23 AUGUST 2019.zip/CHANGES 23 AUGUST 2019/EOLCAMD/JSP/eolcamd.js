        //ADDED BY PRASHANTH
        var oldValueExpiryDate="";
        var oldValueIncDecDC="";
        var oldDevAmt1="";
        var oldDevAmt2="";
        var oldMaxCredAmt="";
        var oldLateDateShip="";
        var shipPer="";
        //Changes Sanjay 02-07-2019 Begin
        var oldchkChangeofBeneficiary="";
        var oldchkExpiryDate="";
        var oldchkIncDec="";
        var oldchkPerTolr="";
        var oldchkShipPeriod="";
        var oldchkChgAppl="";
        var oldchkChgFormDc="";
        var oldchkChgApplRules="";
        var oldchkChgDesc="";
        var oldchkChgDoc="";
        var oldchkChgAddCond="";
        var oldchkChgAvlWith="";
	    var oldchkCgDrawee="";
	    var oldchkChgReimbus="";
	    var oldchkCgAdvBk="";
        var lstcredit_backup="";
        var lstAppRule_backup="";
        var lstAvl_backup="";
        var lstAvlBICdtl_backup="";
        var txtAvlBicCode_backup="";
        var txtAvlBicBrn_backup="";
        var txtAvlBankName_backup="";
        var txtAvlAcnt_backup="";
        var txtAvlAddress_backup="";
        var txtAvlCntry_backup="";
        var txtDraft_backup="";
        var chkDrawee_backup="";
        var lstDrwBICdtl_backup="";
        var txtDrwBicCode_backup="";
        var txtDrwBicBrn_backup="";
        var txtDrwBankName_backup="";
        var txtDrwAcnt_backup="";
        var txtDrwAddress_backup="";
        var txtDrwCntry_backup="";
        var txtMixedPaydtl_backup="";
        var txtDeferPaydtl_backup="";
        var lstparShip_backup="";
        var lsttranShip_backup="";
        var lstConfInst_backup="";
        var lstReimbcfmBank_backup="";
        var txtReimcfmBicCode_backup="";
        var txtReimcfmBicBrn_backup="";
        var txtcfmReimBankName_backup="";
        var txtcfmReimAcnt_backup="";
        var txtcfmReimAddress_backup="";
        var txtcfmReimCntry_backup="";
        var chkReimb_backup="";
        var lstReimbBank_backup="";
        var txtReimBicCode_backup="";
        var txtReimBicBrn_backup="";
        var txtReimBankName_backup="";
        var txtReimAcnt_backup="";
        var txtReimAddress_backup="";
        var txtReimCntry_backup="";
        var txtInstPay_backup="";
        var chkAdvise_backup="";
        var lstAdviseBank_backup="";
        var txtAdviseBicCode_backup="";
        var txtAdviseBicBrn_backup="";
        var txtAdviseBankName_backup="";
        var txtAdviseAcnt_backup="";
        var txtAdviseAddress_backup="";
        var txtAdviseCntry_backup="";
        var res="";
        //Changes Sanjay 02-07-2019 End
        var oldBenCode="";
        var oldBenName="";
        var oldBenAddress="";
        var oldBenCountry="";
        
        
        
        var oldApplCode="";
        var oldApplName="";
        var oldApplAddress="";
        
        var oldFormOfDC="";
        
        
        
        
         var goodsMod="";
         var DocsMod="";
         var AddlMod="";
         var Spcl1Mod="";
         var Spcl2Mod="";
         
         
         var oldAmdLogValueGoods="";
         var oldAmdLogValueDocs="";
         var oldAmdLogValueAddl="";
         
         
         var aMap = {};
         var aMap2 = {};
         var aMap3 = {};
         var aMap4 = {};
         var aMap5 = {};
         
        var choiceSlforGrid1=1;
        var choiceSlforGrid2=1;
        var choiceSlforGrid3=1;
        var choiceSlforGrid4=1;
        var choiceSlforGrid5=1;
        
        var grid1SelectedValue="";
        var grid1SelectedIndex="";
         var grid2SelectedValue="";
         var grid2SelectedIndex="";
         var grid3SelectedValue="";
         var grid3SelectedIndex="";
         var grid4SelectedValue="";
         var grid4SelectedIndex="";
         var grid5SelectedValue="";
         var grid5SelectedIndex="";
        //ADDED BY PRASHANTH
		var decLength=6;
		var declength2;	
		var productCode;
		var productDesc;
		var lastEntdFld ;
		var fldobj ;
		var Args ;
		var currbusDate; 
		var baseCurrency; 
		var userID; 
		var userBranchCode;
		var userRoleCode;  
		var recoverycurr;
		var totalamount;
		var tranchgs_sl;
		var totalservicetax;
		var calendar = new CalendarPopup('caldiv');
		var combo;
		var combo1;
		var combo2;
		var _tenomen_num_choice;
		var _tenomen_auto_num;
		var decilength;
		var decilength1;
		var _total_liab_base_curr=0;
		var tottenoramt;
		var row;
		var col;
		var invoiceNumber;
		var PrevTenorAmt="";
		var TotalLiabAmt="";
		var Separator="&";
		var baltenoramt="";
		var balusanceintamt="";
		var olcPositivDeviationAllow;
		var PTAMT = new Array();
		var TenorLength="";
		//Changes P.Subramani-Chn-27/02/2008
		var focusflag;
		//Changes P.Subramani-Chn-07/04/2008
		var prevamdsl="";
		//Changes P.Subramani-Chn-12/04/2008 Beg
		var olcusancedays;
		var olcusancemonth;
		var olccommmonth;
		var prevolcdays;
		var prevusancemonth;
		var prevcommmonth;
		var prevlastdatefornegotiation;
		var usnchgamt1;
		var usnchgamt2;
		var commchgsamt1;
		var commchgsamt2;
		var usancecharges;
		var commitcharges;
		var usancechgstakendays;
		var commchgstakendays;
		var amdsl;
		var Diff1;
		//Changes P.Subramani-Chn-12/04/2008 End
		//Changes P.Subramani-Chn-28/04/2008
		var custno;
		
		
		//changes P.Subramani-Chn-25/08/2008
		var prevdevallwd;
		var prevconvrate;
		var Diff;
		//Changes P.Subramani-Chn-27/08/2008 
		var prevposdevallwd;
		var prev_olc_days;
		var TenorSerial; 
		var Prev_enhanc_reduct_amt;
		objXMLAppletGrid=new xmlHTTPValidator();
		var instructions = new Array();
		var inst = new Array();
		
		//Changes P.Subramani-Chn-20/10/2008 End
		var flag1;
		var mardecilen;
	    var w_eolm_pc=0;
	    var w_totliabm=0;
		var w_eolm=0;
		var w_amt=0;
		var marginper=0;
		var eolmarginper=0;
		var marginamt=0;
		var eolmarginamt=0;
		var eolcashmarginamt=0;
		var decilength2;
		//Changes P.Subramani-Chn-20/10/2008 End
		var cashmarginamt=0;// M.Jayakumaran 01/06/2011 Added
		objXMLApplet=new xmlHTTPValidator();//TEST
		
		//ADDED ON 16/10/2018 START
		
		var banklst = "";
		var txtlst ="";
		var bankBic="";
		var lstchk="";
		var bankBrn="";
		var bankName ="";
		var bankAddr="";
		var bankCntry="";
		var bankRout="";
		var objXMLApplet3 = new xmlHTTPValidator();
		var newbenef ="1";
		var placeTake ="";
		var placeload ="";
		var placeDis ="";
		var placeFinal ="";
		var shipSch="";
		var sendInfo="";
		
		//ADDED ON 16/10/2018 END
		
		
//-----------------------------------------------------------------------------------------------------------------------------				
	//Init-Para
     function InitJSvar()
     {objXMLAppletGrid=new xmlHTTPValidator();
     
     objXMLApplet=new xmlHTTPValidator();//TEST
     objXMLApplet3 = new xmlHTTPValidator();//ADDED ON 16/10/2018
        TenorLength="";
        PTAMT = new Array();
        balusanceintamt="";
        baltenoramt="";
        Separator="&";
        TotalLiabAmt="";
        PrevTenorAmt="";
        calendar = new CalendarPopup('caldiv');
        decLength=6;
        //Changes P.Subramani-Chn-27/02/2008
        focusflag=false;
        //Changes P.Subramani-Chn-07/04/2008
        prevamdsl="";
        //Changes P.Subramani-Chn-12/04/2008 Beg
	        olcusancedays="";
        prevolcdays="";
	    prevusancemonth="";
	    prevcommmonth="";
	    prevlastdatefornegotiation="";
	    usnchgamt1="";
	    usnchgamt2="";
		commchgsamt1="";
		commchgsamt2="";
		usancecharges="";
		commitcharges="";
		usancechgstakendays="";
        commchgstakendays="";
        amdsl="";
        Diff1="";
	    //Changes P.Subramani-Chn-12/04/2008 End
	    //Changes P.Subramani-Chn-28/04/2008
	    custno="";
		//changes P.Subramani-Chn-25/08/2008
		prevdevallwd=""; 
	    prevconvrate="";
	    Diff="";
	    //Changes P.Subramani-Chn-27/08/2008 
		prevposdevallwd=0;
		prev_olc_days=0;
		TenorSerial=0; 
		Prev_enhanc_reduct_amt=0;
		
		//Changes P.Subramani-Chn-20/10/2008
		marginper=0;
		decilength2=2;
		gridEolcamd.setxmlcolumn("0,1,0,0,0,1,1,1,1,1,0,1,0,1,0,1,1,1,1,1");
        init_grid_values(gridEolcamd);
        objTFMCharges.init_sess_variables();
   		try {com_init_values();}catch(e){}
	}
//-----------------------------------------------------------------------------------------------------------------------------				
	function InitPara()
	{
		InitJSvar();
		PGM_VERSION="1";
		//currbusDate="<%=session.getAttribute("CBD")%>";
		//baseCurrency="<%= session.getAttribute("BCurrCode")%>";
		//userID="<%= session.getAttribute("LoggedUser")%>";
		//userBranchCode="<%= session.getAttribute("BranchCode")%>";
		//userRoleCode="<%= session.getAttribute("UserRoleCode")%>";
		setTabfocus("maintab","tcontent1");
		if(gid("MF:errmsg").value!="")
		{
			gridEolcamd.clearAll();	
		    gridEolcamd.setxmlcolumn("0,1,0,1,0,1,1,1,1,1,0,1,0,1,0,1,1,0,0,0,1");
		    gridEolcamd.loadXMLString(gid("MF:mxmlstr1").value);	
		    var val=gid('MF:PrevGridTenorAmt').value;
		    PTAMT= val.split("&");
		    for(var i=1;i<=gridEolcamd.getRowsNum();i++)
		    {
		      gridEolcamd.cells(i,3).setValue(PTAMT[i-1]);  
		    }
		}
		if(gid('MF:seluseroption').value=="A")
		{
			DISPLAY_STATUS("MF:seluseroption","MF:txnstatus","MF:errmsg","MF:txtbatchnum"); 
		}
		else
		{
			DISPLAY_STATUS("MF:seluseroption","MF:txnstatus","MF:errmsg"); 
		} 
	    //Changes P.Subramani-Chn-19/08/2008
		gid('MF:totallcamtinbaseafteramd').style.visibility="hidden";
		//ADDED ON 26/05/2018 START
		if(gid('MF:errmsg').value =="")
        	{
          		InitializeTab();
          	}
        //ADDED ON 26/05/2018 END
	}//InitPara Ends
//-----------------------------------------------------------------------------------------------------------------------------	
//ADDED ON 16/10/2018 START
function InitializeTab()
	{
	
		avlBicList();
		draweeBicList();
		reimbBiclist();
		//Changes Sanjay1 18-07-2019 Begin
		reimbcfmBiclist();
		checkcfmReimb();
		//Changes Sanjay1 18-07-2019 End
		AvlThrBiclist();
		checkDrawee();
		checkAdvise();
		checkReimb();
		
		
		IssueBicList();
		//checkIssueBank();
		
		banklst = "";
		txtlst ="";
		bankBic="";
		lstchk="";
		bankBrn="";
		bankName="";
		bankAddr="";
		bankCntry="";
		bankRout="";
		placeTake ="";
		placeload ="";
		placeDis ="";
		placeFinal ="";
		shipSch="";
		sendInfo="";
		
		checkExpiryDate();
		checkIncrDecr();
		checkPerTolr();
		checkPlacePort();
		checkShipPeriod();	
		chkbenficiary();
		
	
}
	//ADDED ON 16/10/2018 END
//-----------------------------------------------------------------------------------------------------------------------------				
	//SetFocus
	function setFocus(fldobj)
	{	
		if(trim(fldobj).indexOf("MF:translmt:") == 0)
		{
		 	setTabfocus("maintab","tcontent8");
		  	gid(fldobj).focus();
		}       			
	    switch (trim(fldobj)) 
	    {
			case "MF:seluseroption" 					:  gid('MF:seluseroption').focus() ;break;
			case "MF:txtBranchCode" 		    	    :  gid('MF:txtBranchCode').focus() ;break;
			case "MF:txtReferenceType" 		    		:  gid('MF:txtReferenceType').focus() ;break;
			case "MF:txtReferenceYear" 		    		:  gid('MF:txtReferenceYear').focus() ;break;
			case "MF:txtReferenceSl" 					:  gid('MF:txtReferenceSl').focus() ;break;
			case "MF:txtAmendmentSerial" 				:  gid('MF:txtAmendmentSerial').focus() ;break;
			case "MF:txtCorrespondentRefNumber" 		:  gid('MF:txtCorrespondentRefNumber').focus() ;break;
	      				
			case "MF:txtLCDate" 						:  setTabfocus("maintab","tcontent1");gid('MF:txtLCDate').focus() ;break;
			case "MF:txtCustomerNumber" 				:  setTabfocus("maintab","tcontent1");gid('MF:txtCustomerNumber').focus() ;break;
			case "MF:txtAddress" 						:  setTabfocus("maintab","tcontent1");gid('MF:txtAddress').focus() ;break;	
			case "MF:txtLCIssuedThruBank" 		  		:  setTabfocus("maintab","tcontent1");gid('MF:txtLCIssuedThruBank').focus() ;break;
			case "MF:txtLCIssuedThruBranch" 			:  setTabfocus("maintab","tcontent1");gid('MF:txtLCIssuedThruBranch').focus() ;break;
			case "MF:txtLCIssuedPlace" 					:  setTabfocus("maintab","tcontent1");gid('MF:txtLCIssuedPlace').focus() ;break;	
			case "MF:txtLCIssuedCountry" 				:  setTabfocus("maintab","tcontent1");gid('MF:txtLCIssuedCountry').focus() ;break;
			case "MF:txtLCAmount" 						:  setTabfocus("maintab","tcontent1");gid('MF:txtLCAmount').focus() ;break;
			case "MF:txtLCAmount1" 						:  setTabfocus("maintab","tcontent1");gid('MF:txtLCAmount1').focus() ;break;
			case "MF:txtLCBalance" 						:  setTabfocus("maintab","tcontent1");gid('MF:txtLCBalance').focus() ;break;
			case "MF:txtLCBalance1" 					:  setTabfocus("maintab","tcontent1");gid('MF:txtLCBalance1').focus() ;break;
	      				
			case "MF:txtAmendmentEntryDate" 			: setTabfocus("maintab","tcontent2");gid('MF:txtAmendmentEntryDate').focus() ;break;
			case "MF:txtCustomerletterNumber" 			: setTabfocus("maintab","tcontent2");gid('MF:txtCustomerletterNumber').focus() ;break;
			case "MF:txtCustomerletterDate" 			: setTabfocus("maintab","tcontent2");gid('MF:txtCustomerletterDate').focus() ;break;
			//case "MF:txtReasonForAmendment" 			: setTabfocus("maintab","tcontent2");gid('MF:txtReasonForAmendment').focus() ;break;//COMMENTED ON 16/10/2018
			//ADDED ON 16/10/2018 START
			case "MF:chkExpiryDate" 					: setTabfocus("maintab","tcontent2");gid('MF:chkIssueBank').focus() ;break;
			case "MF:chkIncDec" 						: setTabfocus("maintab","tcontent2");gid('MF:chkIssueBank').focus() ;break;
			case "MF:chkPerTolr" 						: setTabfocus("maintab","tcontent2");gid('MF:chkIssueBank').focus() ;break;
			case "MF:chkPlacePort" 						: setTabfocus("maintab","tcontent2");gid('MF:chkIssueBank').focus() ;break;
			case "MF:chkShipPeriod" 					: setTabfocus("maintab","tcontent2");gid('MF:chkIssueBank').focus() ;break;
			//ADDED ON 16/10/2018 END
			case "MF:chkChangeofBeneficiary" 			: setTabfocus("maintab","tcontent2");gid('MF:chkChangeofBeneficiary').focus() ;break;
			case "MF:txtNewBeneficiaryDetails" 			: setTabfocus("maintab","tcontent2");gid('MF:txtNewBeneficiaryDetails').focus() ;break;
			case "MF:txtBeneficiaryCode" 				: setTabfocus("maintab","tcontent2");gid('MF:txtBeneficiaryCode').focus() ;break;
			case "MF:txtBeneficiaryName" 				: setTabfocus("maintab","tcontent2");gid('MF:txtBeneficiaryName').focus() ;break;
			case "MF:txtAddress1" 						: setTabfocus("maintab","tcontent2");focusTextArea('MF:txtAddress1');break;
			case "MF:txtBeneficiaryCountryCode" 		: setTabfocus("maintab","tcontent2");gid('MF:txtBeneficiaryCountryCode').focus() ;break;
			
			
			case "MF:txtLCEnhancementReductionNochange" 	: setTabfocus("maintab","tcontent3");gid('MF:txtLCEnhancementReductionNochange').focus() ;break;
			case "MF:txtLCAmount2" 							: setTabfocus("maintab","tcontent3");gid('MF:txtLCAmount2').focus() ;break;
			case "MF:txtLCAmount21" 						: setTabfocus("maintab","tcontent3");gid('MF:txtLCAmount21').focus() ;break;
			case "MF:txtEnhancementReductionAmount" 		: setTabfocus("maintab","tcontent3");gid('MF:txtEnhancementReductionAmount').focus() ;break;
			case "MF:txtEnhancementReductionAmount1" 		: setTabfocus("maintab","tcontent3");gid('MF:txtEnhancementReductionAmount1').focus() ;break;
			case "MF:txtAmendedLCAmount" 					: setTabfocus("maintab","tcontent3");gid('MF:txtAmendedLCAmount').focus() ;break;
			case "MF:txtAmendedLCAmount1" 					: setTabfocus("maintab","tcontent3");gid('MF:txtAmendedLCAmount1').focus() ;break;
			case "MF:txtDeviationAllowed"					: setTabfocus("maintab","tcontent3");gid('MF:txtDeviationAllowed').focus() ;break;
			case "MF:txtDeviationAllowed1"					: setTabfocus("maintab","tcontent3");gid('MF:txtDeviationAllowed1').focus() ;break;
			case "MF:txtDeviationAmount"					: setTabfocus("maintab","tcontent3");gid('MF:txtDeviationAmount').focus() ;break;
			case "MF:lstAmountQualifier" 					: setTabfocus("maintab","tcontent3");gid('MF:lstAmountQualifier').focus() ;break;
			case "MF:txtAdditionalAmountsCovered" 			: setTabfocus("maintab","tcontent9");focusTextArea('MF:txtAdditionalAmountsCovered');break;
			case "MF:txtTermsofPrice" 						: setTabfocus("maintab","tcontent9");gid('MF:txtTermsofPrice').focus() ;break;
			case "MF:txtLastDateforNegotiation" 			: setTabfocus("maintab","tcontent9");gid('MF:txtLastDateforNegotiation').focus() ;break;
			case "MF:txtPlaceofExpiry" 						: setTabfocus("maintab","tcontent9");gid('MF:txtPlaceofExpiry').focus() ;break;
			case "MF:txtLatestDateofShipment" 				: setTabfocus("maintab","tcontent9");gid('MF:txtLatestDateofShipment').focus() ;break;
			case "MF:txtShipmentPeriodSchedule" 			: setTabfocus("maintab","tcontent9");gid('MF:txtShipmentPeriodSchedule').focus() ;break;
			case "MF:txtPresentationDetails" 				: setTabfocus("maintab","tcontent9");gid('MF:txtPresentationDetails').focus() ;break;
			case "MF:chkWithinValidityofLC" 				: setTabfocus("maintab","tcontent9");gid('MF:chkWithinValidityofLC').focus() ;break;
			
			case "MF:chkUsanceInterestToBeBorneByApplicant" 	: setTabfocus("maintab","tcontent4");gid('MF:chkUsanceInterestToBeBorneByApplicant').focus() ;break;
			case "MF:txtDrawDowns" 								: setTabfocus("maintab","tcontent4");gid('MF:txtDrawDowns').focus() ;break;
			case "MF:txtTotalTenorAmount" 						: setTabfocus("maintab","tcontent4");gid('MF:txtTotalTenorAmount').focus() ;break;
			case "MF:txtTotalTenorCurr" 						: setTabfocus("maintab","tcontent4");gid('MF:txtTotalTenorCurr').focus() ;break;	      				
			//Liab1
			case "MF:txtLCAmountstring" 						: setTabfocus("maintab","tcontent5");gid('MF:txtLCAmountstring').focus() ;break;
			case "MF:txtLCBeforeAmd" 							: setTabfocus("maintab","tcontent5");gid('MF:txtLCBeforeAmd').focus() ;break;
			case "MF:txtLCAfterAmd" 							: setTabfocus("maintab","tcontent5");gid('MF:txtLCAfterAmd').focus() ;break;
			case "MF:txtLCAmount21" 							: setTabfocus("maintab","tcontent5");gid('MF:txtLCAmount21').focus() ;break;
			case "MF:txtPositiveDeviation" 						: setTabfocus("maintab","tcontent5");gid('MF:txtPositiveDeviation').focus() ;break;
			case "MF:txtPositiveBeforeAmd" 						: setTabfocus("maintab","tcontent5");gid('MF:txtPositiveBeforeAmd').focus() ;break;
			case "MF:txtPositiveAfterAmd" 						: setTabfocus("maintab","tcontent5");gid('MF:txtPositiveAfterAmd').focus() ;break;
			case "MF:txtUsanceInterest"							: setTabfocus("maintab","tcontent5");gid('MF:txtUsanceInterest').focus() ;break;
			case "MF:txtUsanceBeforeAmd"						: setTabfocus("maintab","tcontent5");gid('MF:txtUsanceBeforeAmd').focus() ;break;
			case "MF:txtUsanceAfterAmd"							: setTabfocus("maintab","tcontent5");gid('MF:txtUsanceAfterAmd').focus() ;break;
			case "MF:txtTotal" 									: setTabfocus("maintab","tcontent5");gid('MF:txtTotal').focus() ;break;
			case "MF:txtTotalBeforeAmd" 						: setTabfocus("maintab","tcontent5");gid('MF:txtTotalBeforeAmd').focus() ;break;
			case "MF:txtTotalAfterAmd" 							: setTabfocus("maintab","tcontent5");gid('MF:txtTotalAfterAmd').focus() ;break;
			case "MF:txtAdditionalLCliabAmount" 				: setTabfocus("maintab","tcontent5");gid('MF:txtAdditionalLCliabAmount').focus() ;break;
			case "MF:txtAdditionalLCliabAmount1" 				: setTabfocus("maintab","tcontent5");gid('MF:txtAdditionalLCliabAmount1').focus() ;break;
			// M.Murali - Added - Reduction L/C Liab Amount Field - 15-05-2012 - Beg			
			case "MF:txtReductionLCliabAmount" 					: setTabfocus("maintab","tcontent5");gid('MF:txtReductionLCliabAmount').focus() ;break;
			case "MF:txtReductionLCliabAmount1" 				: setTabfocus("maintab","tcontent5");gid('MF:txtReductionLCliabAmount1').focus() ;break;			
			// M.Murali - Added - Reduction L/C Liab Amount Field - 15-05-2012 - End
			case "MF:txtConvRatetobasecurr" 					: setTabfocus("maintab","tcontent5");gid('MF:txtConvRatetobasecurr').focus() ;break;
			case "MF:txtAdditionallcamtinBasecurr" 				: setTabfocus("maintab","tcontent5");gid('MF:txtAdditionallcamtinBasecurr').focus() ;break;
			case "MF:txtAdditionallcamtinBasecurr1" 			: setTabfocus("maintab","tcontent5");gid('MF:txtAdditionallcamtinBasecurr1').focus() ;break;
			case "MF:txtTotalLcAmtinbaseCurrafteramendment" 	: setTabfocus("maintab","tcontent5");gid('MF:txtTotalLcAmtinbaseCurrafteramendment').focus() ;break;
			case "MF:txtTotalLcAmtinbaseCurrafteramendment1" 	: setTabfocus("maintab","tcontent5");gid('MF:txtTotalLcAmtinbaseCurrafteramendment1').focus() ;break;
			case "MF:txtReductioninLCliabinBasecurr" 			: setTabfocus("maintab","tcontent5");gid('MF:txtReductioninLCliabinBasecurr').focus() ;break;
			case "MF:txtReductioninLCliabinBasecurr1" 			: setTabfocus("maintab","tcontent5");gid('MF:txtReductioninLCliabinBasecurr1').focus() ;break;	      				
			//liab2
			case "MF:txtProductCode" 							: setTabfocus("maintab","tcontent6");gid('MF:txtProductCode').focus() ;break;
			case "MF:txtCustomerLCLiabilityAccount" 			: setTabfocus("maintab","tcontent6");gid('MF:txtCustomerLCLiabilityAccount').focus() ;break;
			case "MF:txtLimitLineNumber" 						: setTabfocus("maintab","tcontent6");gid('MF:txtLimitLineNumber').focus() ;break;
			case "MF:txtLimitCurrency" 							: setTabfocus("maintab","tcontent6");gid('MF:txtLimitCurrency').focus() ;break;
			case "MF:txtChangeinLCliabinBasecurrency" 			: setTabfocus("maintab","tcontent6");gid('MF:txtChangeinLCliabinBasecurrency').focus() ;break;
			case "MF:txtConvRateToLimitCurrency" 				: setTabfocus("maintab","tcontent6");gid('MF:txtConvRateToLimitCurrency').focus() ;break;
			case "MF:txtChangeinLCLiabAmountInLimitCurrency" 	: setTabfocus("maintab","tcontent6");gid('MF:txtChangeinLCLiabAmountInLimitCurrency').focus() ;break;
			case "MF:txtChangeinLCLiabAmountInLimitCurrency1"	: setTabfocus("maintab","tcontent6");gid('MF:txtChangeinLCLiabAmountInLimitCurrency1').focus() ;break;
			case "MF:txtFacilityLimit"							: setTabfocus("maintab","tcontent6");gid('MF:txtFacilityLimit').focus() ;break;
			case "MF:txtFacilityLimit1"							: setTabfocus("maintab","tcontent6");gid('MF:txtFacilityLimit1').focus() ;break;
			case "MF:txtOsbeforethisamendment" 					: setTabfocus("maintab","tcontent6");gid('MF:txtOsbeforethisamendment').focus() ;break;
			case "MF:txtOsbeforethisamendment1" 				: setTabfocus("maintab","tcontent6");gid('MF:txtOsbeforethisamendment1').focus() ;break;
			case "MF:txtLCPendingToBeSanctioned" 				: setTabfocus("maintab","tcontent6");gid('MF:txtLCPendingToBeSanctioned').focus() ;break;
			case "MF:txtLCPendingToBeSanctioned1" 				: setTabfocus("maintab","tcontent6");gid('MF:txtLCPendingToBeSanctioned1').focus() ;break;
			case "MF:txtLCliabafterthisamendment" 				: setTabfocus("maintab","tcontent6");gid('MF:txtLCliabafterthisamendment').focus() ;break;
			case "MF:txtLCliabafterthisamendment1" 				: setTabfocus("maintab","tcontent6");gid('MF:txtLCliabafterthisamendment1').focus() ;break;
			case "MF:txtExcessOverLimit" 						: setTabfocus("maintab","tcontent6");gid('MF:txtExcessOverLimit').focus() ;break;
			case "MF:txtExcessOverLimit1" 						: setTabfocus("maintab","tcontent6");gid('MF:txtExcessOverLimit1').focus() ;break;
			
			//Changes P.Subramani-Chn-27/02/2008
			case "MF:txtExcOverlimitDueCurrTrancurr" 			: setTabfocus("maintab","tcontent6");gid('MF:txtExcOverlimitDueCurrTrancurr').focus() ;break;
			case "MF:txtExcOverlimitDueCurrTrancurrAmt" 		: setTabfocus("maintab","tcontent6");gid('MF:txtExcOverlimitDueCurrTrancurrAmt').focus() ;break;
			
			//----------------------------------6a th tab-------------------------------------------------------------------------------------------------------------
			case "MF:txtmargincurr" 				: setTabfocus("maintab","tcontent6a"); gid('MF:txtmargincurr').focus() ;break;
			case "MF:txtmarginpercentage" 			: setTabfocus("maintab","tcontent6a"); gid('MF:txtmarginpercentage').focus() ;break;
			case "MF:txtmarginpercentage1"			: setTabfocus("maintab","tcontent6a"); gid('MF:txtmarginpercentage1').focus() ;break;
			case "MF:txtmarginamt1"					: setTabfocus("maintab","tcontent6a"); gid('MF:txtmarginamt1').focus() ;break;
			case "MF:txtmarginamt2"					: setTabfocus("maintab","tcontent6a"); gid('MF:txtmarginamt2').focus() ;break;
			case "MF:txtcashmarginamt1"				: setTabfocus("maintab","tcontent6a"); gid('MF:txtcashmarginamt1').focus() ;break;
			case "MF:txtcashmarginamt2"				: setTabfocus("maintab","tcontent6a"); gid('MF:txtcashmarginamt2').focus() ;break;
			case "MF:lstmargintypeforLC"			: setTabfocus("maintab","tcontent6a"); gid('MF:lstmargintypeforLC').focus() ;break;
			case "MF:MarginNext" 								: setTabfocus("maintab","tcontent6a");gid('MF:MarginNext').focus() ;break;
			
			case "MF:LimitNext" 								: setTabfocus("maintab","tcontent7");gid('MF:LimitNext').focus() ;break;
			case "MF:ChargeNext" 								: setTabfocus("maintab","tcontent7");gid('MF:ChargeNext').focus() ;break;
			
			case "MF:gridEolcamd"    			 				: if(gid("MF:errmsg").value != "")
												      				{
												      					SetFocus(gridEolcamd,ErrorRow,ErrorColName);
												      				} 
												      				else
												      				{
													      				SetFocus(gridEolcamd,1,"ttype"); 
													      				SetFocus(gridEolcamd,1,"ttype");
												      				}
														      		break;
	   		case "MF:ConversionNext" 							: setTabfocus("maintab","tcontent5");gid('MF:ConversionNext').focus() ;break;																		      			
	   
	   		//Changes P.Subramani-Chn-12/04/2008 Beg
			//-----------------------------------7 th tab-----------------------------------------------------------------------------------------------
			case "MF:txtusnchgsamt1"	: setTabfocus("maintab","tcontent7"); gid('MF:txtusnchgsamt1').focus() ;break;
			case "MF:txtcommchgsamt1"	: setTabfocus("maintab","tcontent7"); gid('MF:txtcommchgsamt1').focus() ;break;
			//Changes P.Subramani-Chn-12/04/2008 End
			
			//ADDED ON 16/10/2018 START
			//-----------------------------------8 th tab-----------------------------------------------------------------------------------------------
			
			case "MF:txtReceRef" 					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent1"); gid('MF:txtReceRef').focus();break;
			case "MF:txtDocCredit" 					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent1"); gid('MF:txtDocCredit').focus() ;break;
			case "MF:chkIssueBank" 					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent1"); gid('MF:chkIssueBank').focus() ;break;
			case "MF:lstIssueBICdtl"				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent1"); gid('MF:lstIssueBICdtl').focus() ;break;
			case "MF:txtIssueBicCode" 				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent1"); gid('MF:txtIssueBicBank').focus();break;
			case "MF:txtIssueBicBank" 				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent1"); gid('MF:txtIssueBicBank').focus() ;break;
			case "MF:txtIssueBicBrn" 				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent1"); gid('MF:txtIssueBicBrn').focus();break;
			case "MF:txtIssueBankName" 				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent1"); gid('MF:txtIssueBankName').focus();break;
			case "MF:txtIssueAcnt" 					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent1"); gid('MF:txtIssueAcnt').focus();break;
			case "MF:txtIssueAddress" 				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent1"); focusTextArea('MF:txtIssueAddress') ;break;
			case "MF:txtIssueCntry" 				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent1"); gid('MF:txtIssueCntry').focus();break;
			case "MF:txtDateOfIssue"				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent1"); gid('MF:txtDateOfIssue').focus();break;
			
			case "MF:txtTakCharge" 					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent2"); focusTextArea('MF:txtTakCharge');break;
			case "MF:txtPortLoad" 					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent2"); focusTextArea('MF:txtPortLoad') ;break;
			case "MF:txtPortDis" 					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent2"); focusTextArea('MF:txtPortDis') ;break;
			case "MF:txtPortDest"					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent2"); focusTextArea('MF:txtPortDest') ;break;
			//Changes Sanjay1 18-07-2019 Begin
			//case "MF:txtNarrative" 					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent3"); focusTextArea('MF:txtNarrative') ;break;
			//Changes Sanjay1 18-07-2019 End
			case "MF:txtSendInfo"					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent3"); focusTextArea('MF:txtSendInfo') ;break;
			//ADDED ON 16/10/2018 END
			
			
			//new fields added by prashanth
			
			case "MF:lstcredit"					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent7");  gid('MF:lstcredit').focus();break;
			case "MF:lstAppRule"					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent7"); gid('MF:lstAppRule').focus();break;
			case "MF:txtApplName"					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent7"); gid('MF:txtApplName').focus();break;
			case "MF:txtApplAddress"					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent7"); focusTextArea('MF:txtApplAddress');break;
			case "MF:MF:lstAvl"					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent8"); gid('MF:lstAvl').focus();break;
			case "MF:txtAvlAcnt"					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent8");gid('MF:txtAvlAcnt').focus();break;
			case "MF:txtAvlBicBank"					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent8");gid('MF:txtAvlBicBank').focus();break;
			case "MF:txtAvlAddress"					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent8"); focusTextArea('MF:txtAvlAddress');break;
			case "MF:txtAvlCntry"					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent8");gid('MF:txtAvlCntry').focus();break;
			case "MF:txtDraft"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent8");gid('MF:txtDraft').focus();break;

			case "MF:chkDrawee"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent9");gid('MF:chkDrawee').focus();break;
			case "MF:lstDrwBICdtl"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent9");gid('MF:lstDrwBICdtl').focus();break;
			case "MF:txtDrwBicBrn"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent9");gid('MF:txtDrwBicBrn').focus();break;
			case "MF:txtDrwBicCode"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent9");gid('MF:txtDrwBicCode').focus();break;
			case "MF:txtDrwAcnt"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent9");gid('MF:txtDrwAcnt').focus();break;
			case "MF:txtDrwBankName"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent9");gid('MF:txtDrwBankName').focus();break;
			case "MF:txtDrwAddress"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent9");focusTextArea('MF:txtDrwAddress');break;
			case "MF:txtDrwCntry"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent9");gid('MF:txtDrwCntry').focus();break;
			case "MF:txtMixedPaydtl"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent9");gid('MF:txtMixedPaydtl').focus();break;
			case "MF:txtDeferPaydtl"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent9");gid('MF:txtDeferPaydtl').focus();break;
			case "MF:lstparShip"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent9");gid('MF:txtDrwAcnt').focus();break;
			case "MF:lsttranShip"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent9");gid('MF:lsttranShip').focus();break;
			
			case "MF:lstConfInst"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10");gid('MF:lstConfInst').focus();break;
			//Changes Sanjay1 18-07-2019 Begin
			//case "MF:txtConfirmedByBank"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10");gid('MF:txtConfirmedByBank').focus();break;
			//case "MF:txtConfirmedBYBranch"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10");gid('MF:txtConfirmedBYBranch').focus();break;
			case "MF:lstReimbcfmBank"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10");gid('MF:lstReimbcfmBank').focus();break;
			case "MF:txtReimcfmBicCode"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10");gid('MF:txtReimcfmBicCode').focus();break;
			case "MF:txtReimcfmBicBank"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10");gid('MF:txtReimcfmBicBank').focus();break;
			case "MF:txtReimcfmBicBrn"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10");gid('MF:txtReimcfmBicBrn').focus();break;
			case "MF:txtcfmReimAcnt"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10");gid('MF:txtcfmReimAcnt').focus();break;
			case "MF:txtcfmReimBankName"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10");gid('MF:txtcfmReimBankName').focus();break;
			case "MF:txtcfmReimAddress"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10");gid('MF:txtcfmReimAddress').focus();break;
			case "MF:txtcfmReimCntry"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10");gid('MF:txtcfmReimCntry').focus();break;
			//Changes Sanjay1 18-07-2019 End
			case "MF:chkReimb"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10");gid('MF:chkReimb').focus();break;
			case "MF:lstReimbBank"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10");gid('MF:lstReimbBank').focus();break;
			case "MF:txtReimBicBrn"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10");gid('MF:txtReimBicBrn').focus();break;
			case "MF:txtReimBicCode"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10");gid('MF:txtReimBicCode').focus();break;
			case "MF:txtReimAcnt"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10");gid('MF:txtReimAcnt').focus();break;
			case "MF:txtReimBicBank"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10");gid('MF:txtReimBicBank').focus();break;
			case "MF:txtReimAddress"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10");focusTextArea('MF:txtReimAddress');break;
			case "MF:txtInstPay"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10");gid('MF:txtInstPay').focus();break;


			case "MF:chkAdvise"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent11");gid('MF:chkAdvise').focus();break;
			case "MF:lstAdviseBank"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent11");gid('MF:lstAdviseBank').focus();break;
			case "MF:txtAdviseBicBrn"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent11");gid('MF:txtAdviseBicBrn').focus();break;
			case "MF:txtAdviseBicCode"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent11");gid('MF:txtAdviseBicCode').focus();break;
			case "MF:txtAdviseAcnt"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent11");gid('MF:txtAdviseAcnt').focus();break;
			case "MF:txtAdviseBankName"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent11");gid('MF:txtAdviseBankName').focus();break;
			case "MF:txtAdviseAddress"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent11");focusTextArea('MF:txtAdviseAddress');break;
			case "MF:txtAdviseCntry"					    : setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent11");gid('MF:txtAdviseCntry').focus();break;
			//new fields added by prashanth
			
		}
	}
//-----------------------------------------------------------------------------------------------------------------------------							
	function gotFocusEvents(fldobj) 
	{
  		lastEntdFld =fldobj;
	}
//-----------------------------------------------------------------------------------------------------------------------------										
	function clearNonKeyFields() 
    {
    
    	     gid('MF:amdGoodsValue').value="";
    	     gid('MF:amdDocsValue').value="";
    	     gid('MF:amdAddlValue').value="";
    	     gid('MF:amdSpl1Value').value="";
    	     gid('MF:amdSpl2Value').value="";
    	     
    	    
      	     gid('MF:amdlogtemp1').value="";
      	     gid('MF:amdlogtemp2').value="";
      	     gid('MF:amdlogtemp3').value="";
    	     gid('MF:amdlogtemp4').value="";
      	     gid('MF:amdlogtemp5').value="";
      	     
      	     
      	     
      	     
      	     
      	 oldValueExpiryDate="";
         oldValueIncDecDC="";
         oldDevAmt1="";
         oldDevAmt2="";
         oldMaxCredAmt="";
         oldLateDateShip="";
         shipPer="";
         //Changes Sanjay 02-07-2019 Begin
         oldchkChangeofBeneficiary="";
         oldchkExpiryDate="";
         oldchkIncDec="";
         oldchkPerTolr="";
         oldchkShipPeriod="";
         oldchkChgAppl="";
         oldchkChgFormDc="";
         oldchkChgApplRules="";
         oldchkChgDesc="";
         oldchkChgDoc="";
         oldchkChgAddCond="";
         oldchkChgAvlWith="";
	     oldchkCgDrawee="";
	     oldchkChgReimbus="";
	     oldchkCgAdvBk="";
         gid('MF:oldchkChgDesc').value="";
   	     gid('MF:oldchkChgDoc').value="";
     	 gid('MF:oldchkChgAddCond').value="";
     	 lstcredit_backup="";
     	 lstAppRule_backup="";
     	 lstAvl_backup="";
     	 lstAvlBICdtl_backup="";
     	 txtAvlBicCode_backup="";
     	 txtAvlBicBrn_backup="";
     	 txtAvlBankName_backup="";
     	 txtAvlAcnt_backup="";
     	 txtAvlAddress_backup="";
     	 txtAvlCntry_backup="";
     	 txtDraft_backup="";
     	 chkDrawee_backup="";
     	 lstDrwBICdtl_backup="";
     	 txtDrwBicCode_backup="";
     	 txtDrwBicBrn_backup="";
     	 txtDrwBankName_backup="";
     	 txtDrwAcnt_backup="";
     	 txtDrwAddress_backup="";
     	 txtDrwCntry_backup="";
     	 txtMixedPaydtl_backup="";
     	 txtDeferPaydtl_backup="";
     	 lstparShip_backup="";
     	 lsttranShip_backup="";
     	 lstConfInst_backup="";
     	 lstReimbcfmBank_backup="";
     	 txtReimcfmBicCode_backup="";
     	 txtReimcfmBicBrn_backup="";
     	 txtcfmReimBankName_backup="";
     	 txtcfmReimAcnt_backup="";
     	 txtcfmReimAddress_backup="";
     	 txtcfmReimCntry_backup="";
     	 chkReimb_backup="";
     	 lstReimbBank_backup="";
     	 txtReimBicCode_backup="";
     	 txtReimBicBrn_backup="";
     	 txtReimBankName_backup="";
     	 txtReimAcnt_backup="";
     	 txtReimAddress_backup="";
     	 txtReimCntry_backup="";
     	 txtInstPay_backup="";
     	 chkAdvise_backup="";
     	 lstAdviseBank_backup="";
     	 txtAdviseBicCode_backup="";
     	 txtAdviseBicBrn_backup="";
     	 txtAdviseBankName_backup="";
     	 txtAdviseAcnt_backup="";
     	 txtAdviseAddress_backup="";
     	 txtAdviseCntry_backup="";
     	 res="";
         //Changes Sanjay 02-07-2019 End
         oldBenCode="";
         oldBenName="";
         oldBenAddress="";
         oldBenCountry="";
        
        
        
         oldApplCode="";
         oldApplName="";
         oldApplAddress="";
        
         oldFormOfDC="";
      	 
      	 
      	 
      	 oldAmdLogValueGoods="";
      	 oldAmdLogValueDocs="";
      	 oldAmdLogValueAddl="";
        
        
        
        
    	     
    	   //   gid('MF:txtAmdLogHidden').value="";
    	     
    	     
    	     
    	     
    	      choiceSlforGrid1=1;
         choiceSlforGrid2=1;
         choiceSlforGrid3=1;
         choiceSlforGrid4=1;
         choiceSlforGrid5=1;
    
	     gid('MF:txtlcamounthidden').value="";
	     gid('MF:txtAddress').value="";
	     gid('MF:txtLCIssuedThruBank').value="";
	     gid('MF:outputlblLCIssuedThruBank').innerText="";
	     gid('MF:txtLCIssuedThruBranch').value="";
	     gid('MF:outputlblLCIssuedThruBranch').innerText="";
	     gid('MF:txtLCIssuedPlace').value="";	
	     gid('MF:outputlblLCIssuedPlace').innerText="";	
	     gid('MF:txtLCIssuedCountry').value="";
	     gid('MF:outputlblLCIssuedCountry').innerText="";
	     gid('MF:txtLCAmount').value="";
	     gid('MF:txtLCAmount1').value="";	
	     gid('MF:txtLCBalance').value="";
	     gid('MF:txtLCBalance1').value="";
	     gid('MF:txtLCDate').value="";
	     gid('MF:txtCustomerNumber').value="";
	     gid('MF:txtAmendmentEntryDate').value="";
	     gid('MF:txtCustomerletterNumber').value="";
	     gid('MF:txtCustomerletterDate').value=currbusDate;
	     //gid('MF:txtReasonForAmendment').value="";//COMMENTED ON 16/10/2018
	     //ADDED ON 16/10/2018 START
	      gid('MF:chkExpiryDate').checked=false;
	      gid('MF:outlblExpiryDate').innerText="No";
	      gid('MF:chkIncDec').checked=false;
	      gid('MF:outlblIncDec').innerText="No";
	      gid('MF:chkPerTolr').checked=false;
	      gid('MF:outlblPerTolr').innerText="No";
	      gid('MF:chkPlacePort').checked=false;
	      gid('MF:outlblPlacePort').innerText="No";
	      gid('MF:chkShipPeriod').checked=false;
	      gid('MF:outlblShipPeriod').innerText="No";
	      //ADDED ON 16/10/2018 END
	      
	      //ADDED BY PRASHANTH ON 06 FEB 2019
	      gid('MF:chkChgDesc').checked=false;
	      gid('MF:outlblChgDesc').innerText="No";
	      gid('MF:chkChgDoc').checked=false;
	      gid('MF:outlblchkChgDoc').innerText="No";
	      gid('MF:chkChgAddCond').checked=false;
	      gid('MF:outlblChgAddCond').innerText="No";
	      
	      
	      gid('MF:chkReqForCancel').checked=false;
	      gid('MF:outlblchkReqForCancel').innerText="No";
	      gid('MF:chkChgAppl').checked=false;
	      gid('MF:outlblchkChgAppl').innerText="No";
	      
	      
	      gid('MF:chkChgFormDc').checked=false;
	      gid('MF:outlblchkChgFormDc').innerText="No";
	      
	      gid('MF:chkChgApplRules').checked=false;
	      gid('MF:outlblchkChgApplRules').innerText="No";
	      
	      
	      
	      
	      
		 clearOLCDetailsTab();
		  
		  
  		  gid('MF:lstAppRule').value="";
		  
		  
		  gid('MF:chkChgAvlWith').checked=false;
	      gid('MF:outlblchkChgAvlWith').innerText="No";
	      
	      gid('MF:chkCgDrawee').checked=false;
	      gid('MF:outlblchkCgDrawee').innerText="No";
	      
	     // gid('MF:chkChgPresDays').checked=false;
	     // gid('MF:outlblChgPresDays').innerText="No";
	      
	      gid('MF:chkChgReimbus').checked=false;
	      gid('MF:outlblchkChgReimbus').innerText="No";
	      
	      gid('MF:chkCgAdvBk').checked=false;
	      gid('MF:outlblchkCgAdvBk').innerText="No";
	      
	      
		  gid('MF:lstAvl').value="";
		  gid('MF:lstAvlBICdtl').value="";
		  clearAVLBic();
		  clearAVLAddr();
		  gid('MF:txtDraft').value="";
	      
	      gid('MF:lstAmdPayableBy').value="";
    	  gid('MF:txtperiodOfPres').value="";
	      
	      
	      
		  
		  	gid('MF:chkDrawee').checked=false;
    		gid('MF:outlblDrawee').innerText="No";	
    	    gid('MF:lstDrwBICdtl').value="";
    		
    		clearDraweeBic();
		    clearDraweeAddr();
		   	clearReimbBic();
		    clearReimbAddr();
		    clearAdvThrBic();
		    clearAdvThrAddr();
		    
		    gid('MF:lstConfInst').value="";
		    //Changes Sanjay1 18-07-2019 Begin
		    //gid('MF:txtConfirmedByBank').value="";	
			//gid('MF:outlblConfirmedByBank').innerText="";
			//gid('MF:txtConfirmedBYBranch').value="";
			//gid('MF:txtConfirmedBYBranchname').value="";
			gid('MF:lstReimbcfmBank').value="";
			clearReimbCfmBic();
		    clearReimbCfmAddr();
			//Changes Sanjay1 18-07-2019 End
			
			
			gid('MF:chkReimb').checked=false;
    		gid('MF:outlblReimb').innerText="No";	
			gid('MF:lstReimbBank').value="";
    		
    		
	      
	      	gid('MF:txtMixedPaydtl').value="";
			gid('MF:txtDeferPaydtl').value="";
			
			gid('MF:lstparShip').value="";
			gid('MF:lsttranShip').value="";
	      
	  	   gid('MF:txtInstPay').value="";
	       
	      
	      
	      
	      gid('MF:chkAdvise').checked=false;
    	  gid('MF:outlblAdvise').innerText="No";	
    	  gid('MF:lstAdviseBank').value="";
    		
    		
	    //  gid('MF:txtDesGood1').value="";
		 //  gid('MF:txtDesGood2').value="";
		 // gid('MF:txtDesGood3').value="";
		  
		  
		//  gid('MF:txtDocRequired1').value="";
		//  gid('MF:txtDocRequired2').value="";
		 // gid('MF:txtDocRequired3').value="";
		  
		  
		//  gid('MF:txtAddCond1').value="";
		 // gid('MF:txtAddCond2').value="";
		 // gid('MF:txtAddCond3').value="";
		  
		  gridAlloc.clearAll();
		  gridAllocDoc.clearAll();
		  gridAllocAddl.clearAll();
          gridAllocSplBene.clearAll();
          gridAllocSplRecev.clearAll();
		  
         //  onchange_selall('','','','');
          AddRowToGrid(gridAlloc);
		  AddRowToGrid(gridAllocDoc);
		  AddRowToGrid(gridAllocAddl);
		  AddRowToGrid(gridAllocSplBene);
		  AddRowToGrid(gridAllocSplRecev);
		  
		  
		   clearGoodsTab();
		   clearDocumentsTab();
		   clearAdditionalDetailsTab();
		   clearSplBenficieryDetailsTab();
		   clearSplRecvBkDetailsTab();
  	      //ADDED BY PRASHANTH ON 06 FEB 2019
  	      
  	      
	     gid('MF:chkChangeofBeneficiary').checked=false;
	     gid('MF:outlblChangeofBeneficiary').innerText="No";
	     gid('MF:txtBeneficiaryCode').value="";
		 gid('MF:txtBeneficiaryName').value="";
		 gid('MF:txtAddress1').value="";
	     gid('MF:txtBeneficiaryCountryCode').value="";
	     gid('MF:outputlblBeneficiaryCountryCode').innerText="";
	     gid('MF:txtLCEnhancementReductionNochange').value="";
	     gid('MF:txtLCAmount').value="";
	     gid('MF:txtLCAmount1').value="";
	     gid('MF:txtEnhancementReductionAmount').value="";
	     gid('MF:txtEnhancementReductionAmount1').value="";
	     gid('MF:txtAmendedLCAmount').value="";
	     gid('MF:txtAmendedLCAmount1').value="";
	     gid('MF:txtDeviationAllowed').innerText="";
	     gid('MF:txtDeviationAllowed1').value="";
	     gid('MF:txtDeviationAmount').value="";
	     gid('MF:lstAmountQualifier').value="";
	     gid('MF:txtAdditionalAmountsCovered').value="";
	     gid('MF:txtTermsofPrice').value="";
	     gid('MF:outputlblTermsofPrice').innerText="";
	     gid('MF:txtLastDateforNegotiation').value="";
	     gid('MF:txtPlaceofExpiry').value="";
	     gid('MF:txtLatestDateofShipment').value="";
	     gid('MF:txtShipmentPeriodSchedule').value="";
	     gid('MF:chkWithinValidityofLC').checked=false;
	     gid('MF:outlblWithinValidityofLC').innerText="No";
	     gid('MF:chkUsanceInterestToBeBorneByApplicant').checked=false;
	     gid('MF:outlblUsanceInterestToBeBorneByApplicant').innerText="No";
	     gid('MF:txtDrawDowns').value="";
	     gid('MF:txtTotalTenorCurr').value="";
	     gid('MF:txtTotalTenorAmount').value="";
	     gid('MF:txtLCAmountstring').value="";
	     gid('MF:txtLCBeforeAmd').value="";
	     gid('MF:txtLCAfterAmd').value="";
	     gid('MF:txtLCAmount2').value="";
	     gid('MF:txtLCAmount21').value="";
	     gid('MF:txtPositiveDeviation').value="";
	     gid('MF:txtPositiveBeforeAmd').value="";
	     gid('MF:txtPositiveAfterAmd').value="";
	     gid('MF:txtUsanceInterest').value="";
	     gid('MF:txtUsanceBeforeAmd').value="";
	     gid('MF:txtUsanceAfterAmd').value="";
	     gid('MF:txtTotal').value="";
	     gid('MF:txtTotalBeforeAmd').value="";
	     gid('MF:txtTotalAfterAmd').value="";
	     gid('MF:txtAdditionalLCliabAmount').value="";
	     gid('MF:txtAdditionalLCliabAmount1').value="";
	     // M.Murali - Added - Reduction L/C Liab Amount Field - 15-05-2012 - Beg
	     gid('MF:txtReductionLCliabAmount').value="";
	     gid('MF:txtReductionLCliabAmount1').value="";
	     // M.Murali - Added - Reduction L/C Liab Amount Field - 15-05-2012 - End
	     gid('MF:txtConvRatetobasecurr').value="";
	     gid('MF:txtAdditionallcamtinBasecurr').value="";
	     gid('MF:txtAdditionallcamtinBasecurr1').value="";
	     gid('MF:txtTotalLcAmtinbaseCurrafteramendment').value="";
	     gid('MF:txtTotalLcAmtinbaseCurrafteramendment1').value="";
	     gid('MF:txtReductioninLCliabinBasecurr').value="";
	     gid('MF:txtReductioninLCliabinBasecurr1').value="";
	     gid('MF:txtProductCode').value="";
	     gid('MF:outputProductCode').innerText="";
	     gid('MF:txtCustomerLCLiabilityAccount').value="";
	     gid('MF:outputCustomerLCLiabilityAccount').innerText="";
	     gid('MF:txtLimitLineNumber').value="";
	     gid('MF:outputLimitLineNumber').innerText="";
	     gid('MF:txtLimitCurrency').value="";
	     gid('MF:outputFacilityCurrency').innerText="";
	     gid('MF:txtChangeinLCliabinBasecurrency').value="";
	     gid('MF:txtConvRateToLimitCurrency').value="";
	     gid('MF:txtChangeinLCLiabAmountInLimitCurrency').value="";
	     gid('MF:txtChangeinLCLiabAmountInLimitCurrency1').value="";
	     gid('MF:txtFacilityLimit').value="";
	     gid('MF:txtFacilityLimit1').value="";
	     gid('MF:txtOsbeforethisamendment').value="";
	     gid('MF:txtOsbeforethisamendment1').value="";
	     gid('MF:txtLCPendingToBeSanctioned').value="";
	     gid('MF:txtLCPendingToBeSanctioned1').value="";
	     gid('MF:txtLCliabafterthisamendment').value="";
	     gid('MF:txtLCliabafterthisamendment1').value="";
	     gid('MF:txtExcessOverLimit').value="";
	     gid('MF:txtExcessOverLimit1').value="";
	     //Changes P.Subramani-Chn-27/02/2008
	     gid('MF:txtExcOverlimitDueCurrTrancurr').value=""; 
	     gid('MF:txtExcOverlimitDueCurrTrancurrAmt').value=""; 
	     gid('MF:chkPrevEnhanceReduction').value="";
		 gid('MF:txtPrevEnhaceeReductionAmt').value="";
		 gid('MF:txtCorrespondentRefNumber').value="";
		 gid('MF:txtAmendmentSerial').value="";
		 gid('MF:outputlblBeneficiaryCountryCode').innerText="";
		 gid('MF:txtChangeinLCliabinBasecurrency1').value="";
	     //Changes P.Subramani-Chn-12/04/2008 Beg
	     
	     //Changes P.Subramani-Chn-20/10/2008 Beg
	     gid('MF:txtmargincurr').value=""; 
    	 gid('MF:outlblmargincurr').innerText=""; 
    	 gid('MF:txtmarginpercentage').value=""; 
    	 gid('MF:txtmarginpercentage1').value=""; 
    	 gid('MF:txtmarginamtcurr').value=""; 
    	 gid('MF:txtmarginamt1').value=""; 
    	 gid('MF:txtmarginamt2').value=""; 
    	 gid('MF:txtmarginamt3').value=""; 
		 gid('MF:txtcashmargincurr').value=""; 
		 gid('MF:txtcashmarginamt1').value=""; 
		 gid('MF:txtcashmarginamt2').value=""; 
		 gid('MF:txtcashmarginamt3').value=""; 
		 gid('MF:lstmargintypeforLC').value="";
	     //Changes P.Subramani-Chn-20/10/2008 End
	     	     
		 gid('MF:txtusnchgscurr').value="";
		 gid('MF:txtusnchgsamt').value="";
		 gid('MF:txtusnchgscurr1').value="";
		 gid('MF:txtusnchgsamt1').value="";
		 gid('MF:txtcommchgscurr').value="";
		 gid('MF:txtcommchgsamt').value="";
		 gid('MF:txtcommchgscurr1').value="";
		 gid('MF:txtcommchgsamt1').value="";
		 gid("MF:outputlblCustomerNumber").innerText="";
		 //Changes P.Subramani-Chn-12/04/2008 End 	
	     gridEolcamd.clearAll();
	     AddRowToGrid(gridEolcamd);
	     objTFMCharges.clearControl();
	     objTranStmntPost.clearControl();
	     gid('MF:PrevGridTenorAmt').value="";
	     gid('MF:TotalGridLiabAmt').value="";
	     gid('MF:txtaddtranchgs').value="";
	     gid('MF:txtaddtranstlmntinvnum').value="";
	     gid('MF:txtolcaentrydate').value="";
	     //ADDED ON 16/10/2018 START
	     gid('MF:txtReceRef').value="";
	     gid('MF:txtDocCredit').value="";
	     gid('MF:chkIssueBank').checked=false;
	     gid('MF:outlblIssueBank').innerText="No";
	     gid('MF:lstIssueBICdtl').value="";
	     gid('MF:txtIssueBicCode').value="";
	     gid('MF:txtIssueBicBank').value="";
	     gid('MF:txtIssueBicBrn').value="";
	     gid('MF:txtIssueAcnt').value="";
	     gid('MF:txtIssueBankName').value="";
	     gid('MF:txtIssueAddress').value="";
	     gid('MF:txtIssueCntry').value="";
	     gid('MF:txtDateOfIssue').value="";
	     gid('MF:txtTakCharge').value="";
		 gid('MF:txtPortLoad').value="";
		 gid('MF:txtPortDis').value="";
		 gid('MF:txtPortDest').value="";
		 //Changes Sanjay1 18-07-2019 Begin
	     //gid('MF:txtNarrative').value="";
	     //Changes Sanjay1 18-07-2019 END
	     gid('MF:txtSendInfo').value="";
	     clearIssueBic();
	     clearIssueAddr();
	     banklst = "";
		 txtlst ="";
		 bankBic="";
		 lstchk="";
		 bankBrn="";
		 bankName="";
		 bankAddr="";
		 bankCntry="";
		 bankRout="";
		 placeTake ="";
		 placeload ="";
		 placeDis ="";
		 placeFinal ="";
		 shipSch="";
		 sendInfo="";
		
	     //ADDED ON 16/10/2018 END
	     setMsg("");	
  	
    }
//-----------------------------------------------------------------------------------------------------------------------------							       
	
	function clearOLCDetailsTab(){
		  gid('MF:lstcredit').value="";
		  gid('MF:txtApplCode').value="";
		  gid('MF:txtApplName').value="";
		  gid('MF:txtApplAddress').value="";
		  gid('MF:lstAppRule').value="";
	}
	
	
	function clearGoodsTab(){
		  gridAlloc.clearAll();
	 	  gid('MF:txtChoiceSl').value="1";
  		  gid('MF:uptoRange').value="";
  		  gid('MF:txtfrmRange').value="";
   		  gid('MF:txtApplInsOrRepl').value="";
   		  gid('MF:txtAmdLog').value="";
   		  gid('MF:txtcompAmdDetails').value="";
	}
	
	function clearDocumentsTab(){
		  gridAllocDoc.clearAll();
	 	  gid('MF:txtChoiceSlDoc').value="1";
  		  gid('MF:uptoRangeDoc').value="";
  		  gid('MF:txtfrmRangeDoc').value="";
   		  gid('MF:txtApplInsOrReplDoc').value="";
   		  gid('MF:txtAmdLogDoc').value="";
   		  gid('MF:txtcompAmdDetailsDoc').value="";
	}
	
	
	function clearAdditionalDetailsTab(){
		  gridAllocAddl.clearAll();
	 	  gid('MF:txtChoiceSlAddl').value="1";
  		  gid('MF:uptoRangeAddl').value="";
  		  gid('MF:txtfrmRangeAddl').value="";
   		  gid('MF:txtApplInsOrReplAddl').value="";
   		  gid('MF:txtAmdLogAddl').value="";
   		  gid('MF:txtcompAmdDetailsAddl').value="";
	}
	
	function clearSplBenficieryDetailsTab(){
		  gridAllocSplBene.clearAll();
	 	  gid('MF:txtChoiceSlSplBene').value="1";
  		  gid('MF:uptoRangeSplBene').value="";
  		  gid('MF:txtfrmRangeSplBene').value="";
   		  gid('MF:txtApplInsOrReplSplBene').value="";
   		  gid('MF:txtAmdLogSplBene').value="";
   		  gid('MF:txtcompAmdDetailsSplBene').value="";
	}
	
		function clearSplRecvBkDetailsTab(){
		  gridAllocSplRecev.clearAll();
	 	  gid('MF:txtChoiceSlSplRecev').value="1";
  		  gid('MF:uptoRangeSplRecev').value="";
  		  gid('MF:txtfrmRangeSplRecev').value="";
   		  gid('MF:txtApplInsOrReplSplRecev').value="";
   		  gid('MF:txtAmdLogSplRecev').value="";
   		  gid('MF:txtcompAmdDetailsSplRecev').value="";
	}
	
	
	
	function clearAVLBic()
	{
		gid('MF:txtAvlBicCode').value="";
		gid('MF:txtAvlBicBank').value="";
		gid('MF:txtAvlBicBrn').value="";
	}
	
	function clearAVLAddr()
	{
		gid('MF:txtAvlBankName').value="";
		gid('MF:txtAvlAcnt').value="";
		gid('MF:txtAvlAddress').value="";
		gid('MF:txtAvlCntry').value="";
	}
	
	function clearDraweeBic()
	{
		gid('MF:txtDrwBicCode').value="";
		gid('MF:txtDrwBicBank').value="";
		gid('MF:txtDrwBicBrn').value="";
	}
	
	function clearDraweeAddr()
	{
		gid('MF:txtDrwBankName').value="";
		gid('MF:txtDrwAcnt').value="";
		gid('MF:txtDrwAddress').value="";
		gid('MF:txtDrwCntry').value="";
	}
	
	function clearReimbBic()
	{
		gid('MF:txtReimBicCode').value="";
		gid('MF:txtReimBicBank').value="";
		gid('MF:txtReimBicBrn').value="";
	}
	
	function clearReimbAddr()
	{
		gid('MF:txtReimBankName').value="";
		gid('MF:txtReimAcnt').value="";
		gid('MF:txtReimAddress').value="";
		gid('MF:txtReimCntry').value="";
	}
	//Changes Sanjay1 18-07-2019 Begin
	function clearReimbCfmBic()
	{
		gid('MF:txtReimcfmBicCode').value="";
		gid('MF:txtReimcfmBicBank').value="";
		gid('MF:txtReimcfmBicBrn').value="";
	}
	
	function clearReimbCfmAddr()
	{
		gid('MF:txtcfmReimAcnt').value="";
		gid('MF:txtcfmReimBankName').value="";
		gid('MF:txtcfmReimAddress').value="";
		gid('MF:txtcfmReimCntry').value="";
	}
	//Changes Sanjay1 18-07-2019 End
	function clearAdvThrBic()
	{
		gid('MF:txtAdviseBicCode').value="";
		gid('MF:txtAdviseBicBank').value="";
		gid('MF:txtAdviseBicBrn').value="";
	}
	
	function clearAdvThrAddr()
	{
		gid('MF:txtAdviseBankName').value="";
		gid('MF:txtAdviseAddress').value="";
		gid('MF:txtAdviseCntry').value="";
		gid('MF:txtAdviseAcnt').value="";
	}
	
	
	function checkDrawee()
{
	//setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent2");
	if(gid('MF:chkDrawee').checked==true)
		{
			gid('MF:outlblDrawee').innerText="Yes";
			//gid('MF:lstDrwBICdtl').value ="";
			gid('MF:lstDrwBICdtl').disabled=false;
			//gid('MF:lstBICdtl').disabled=false;
			gid('MF:txtDrwBicCode').readOnly=false;
			gid('MF:txtDrwBicBank').readOnly=false;
			gid('MF:txtDrwBicBrn').readOnly=false;
			gid('MF:txtDrwBankName').readOnly=false;
			gid('MF:txtDrwAcnt').readOnly=false;
			gid('MF:txtDrwAddress').readOnly=false;
			gid('MF:txtDrwCntry').readOnly=false;
		}
		else
		{
			gid('MF:outlblDrawee').innerText="No";
			gid('MF:lstDrwBICdtl').value ="";
			gid('MF:lstDrwBICdtl').disabled=true;
			//gid('MF:lstBICdtl').disabled=true;
			gid('MF:txtDrwBicCode').readOnly=true;
			gid('MF:txtDrwBicBank').readOnly=true;
			gid('MF:txtDrwBicBrn').readOnly=true;
			gid('MF:txtDrwBankName').readOnly=true;
			gid('MF:txtDrwAcnt').readOnly=true;
			gid('MF:txtDrwAddress').readOnly=true;
			gid('MF:txtDrwCntry').readOnly=true;
			clearDraweeBic();
			clearDraweeAddr();
		}
		if(gid('MF:seluseroption').value=="A" && (gid('MF:chkDrawee').checked==true) && gid('MF:lstDrwBICdtl').value == "")//CHANGED ADDED ON 11/10/2018
			{
		clearDraweeBic();
		clearDraweeAddr();
		}
}
	function clearFields()
    {
    	//Changes P.Subramani-Chn-28/02/2008
		//gid('MF:seluseroption').value="";
		gid('MF:txtBranchCode').value=userBranchCode;
	 	gid('MF:txtReferenceType').value="";
	 	gid('MF:txtReferenceYear').value="";
	 	gid('MF:txtReferenceSl').value="";	
 		clearNonKeyFields(); 		
    }
//-----------------------------------------------------------------------------------------------------------------------------							     
	function cancelPage() 
	{
		if (confirm(CANCEL_ALERT)== true )
		{
			clearFields();   
			gid('MF:seluseroption').value="";
			gid('MF:seluseroption').focus();
		} 
		else
		{	
			if (lastEntdFld.name == "GRID")
			{
				fldobj = "MF:"+lastEntdFld.gridname;
            }
			else
			{
				fldobj  = lastEntdFld.name;						
				setFocus(fldobj);
	    	}
		}
	}
//-----------------------------------------------------------------------------------------------------------------------------							
	function exitPage() 
	{
		if (confirm (EXIT_ALERT) == true ) 
		{
			window.close();
		}
		else
		{
			lastEntdFld.focus();
		}
	}
//------------------------------------------------Key Down Events-----------------------------------------------------------------------------------------
	function keyDownEvents(fldobj)
	{
       	setMsg("");
		if (window.event.keyCode == KEY_TAB) 
		{
           	if(window.event.shiftKey == false)
			{
				window.event.keyCode = 13;
				keyPressEvents(fldobj);
			}
			else 
			{
				window.event.keyCode =0 ;
				PERFORM_BACKTRACK(fldobj);
				return ;
			}
		}
    	switch (window.event.keyCode) 
		{
			case  KEY_F2 :PERFORM_BACKTRACK(fldobj); break;
			case  KEY_F5 :SHOW_HELP(fldobj); break ; 
		}
	}
//-----------------------------------------------------------------------------------------------------------------------------									
	function PERFORM_BACKTRACK(fldobj)
	{
		switch (fldobj.name) 
		{	 
			case "MF:txtBranchCode" 	       				: gid('MF:seluseroption').focus() ;break;
		    case "MF:txtReferenceType" 	       				: gid('MF:txtBranchCode').focus() ;break;
			case "MF:txtReferenceYear" 	  					: gid('MF:txtReferenceType').focus() ;break;
			case "MF:txtReferenceSl" 	  				    : gid('MF:txtReferenceYear').focus() ;break;
		    //first
		    case "MF:Next" 						        	: gid('MF:txtReferenceSl').focus(); break;
		      		
			case "MF:txtAmendmentEntryDate"					: setTabfocus("maintab","tcontent1"); gid('MF:Next').focus(); break;
			case "MF:txtCustomerletterNumber"				: setTabfocus("maintab","tcontent2"); gid('MF:txtAmendmentEntryDate').focus(); break;
			case "MF:txtCustomerletterDate"					: setTabfocus("maintab","tcontent2"); gid('MF:txtCustomerletterNumber').focus();break;
			//case "MF:txtReasonForAmendment"					: setTabfocus("maintab","tcontent2"); gid('MF:txtCustomerletterDate').focus() ; break;//COMMENTED ON 16/10/2018
			//ADDED ON 16/10/2018 START
			case "MF:chkExpiryDate" 						: setTabfocus("maintab","tcontent2");gid('MF:txtCustomerletterDate').focus() ;break;
			case "MF:chkIncDec" 							: setTabfocus("maintab","tcontent2");gid('MF:chkExpiryDate').focus() ;break;
			case "MF:chkPerTolr" 							: setTabfocus("maintab","tcontent2");gid('MF:chkIncDec').focus() ;break;
			case "MF:chkPlacePort" 							: setTabfocus("maintab","tcontent2");gid('MF:chkPerTolr').focus() ;break;
			case "MF:chkShipPeriod" 						: if(gid('MF:txtReferenceType').value=='LC')
																{
													      		setTabfocus("maintab","tcontent2");gid('MF:chkPerTolr').focus();break;
													      		}
																else
																{
																	setTabfocus("maintab","tcontent2");gid('MF:chkPlacePort').focus();break;
																}
																
											
											
		
		case "MF:chkChgDesc"     : gid('MF:chkChangeofBeneficiary').focus();
															  break;
															  
		
		case "MF:chkChgDoc"     : gid('MF:chkChgDesc').focus();
															  break;
		
		case "MF:chkChgAddCond"     : gid('MF:chkChgDoc').focus();
															  break;													  
															  													  									
																
		case "MF:chkReqForCancel"     : gid('MF:chkChgAddCond').focus();
															  break;
			case "MF:chkChgAppl"     : gid('MF:chkReqForCancel').focus();
															  break;													  	
		
	case "MF:chkChgFormDc"     : gid('MF:chkChgAppl').focus();
															  break;


	case "MF:chkChgApplRules"     : gid('MF:chkChgFormDc').focus();
															  break;
															  
															  															  		
		
		case "MF:chkChgAvlWith"     : gid('MF:chkChgApplRules').focus();
															  break;
															  
		case "MF:chkCgDrawee"     : gid('MF:chkChgAvlWith').focus();
															  break;
		case "MF:chkChgReimbus"     : gid('MF:chkCgDrawee').focus();
															  break;
		case "MF:chkCgAdvBk"     : gid('MF:chkChgReimbus').focus();
															  break;													  
															  													  													  														
																
			//ADDED ON 16/10/2018 END
			case "MF:chkChangeofBeneficiary"	    		: setTabfocus("maintab","tcontent2");gid('MF:chkShipPeriod').focus();break;//ADDED ON 16/10/2018
			case "MF:txtBeneficiaryCode"					: setTabfocus("maintab","tcontent2");gid('MF:chkCgAdvBk').focus();break;
			case "MF:txtBeneficiaryName" 					: setTabfocus("maintab","tcontent2");gid('MF:txtBeneficiaryCode').focus();break;
			case "MF:txtAddress1" 							: setTabfocus("maintab","tcontent2"); gid('MF:txtBeneficiaryName').focus() ;break;
			case "MF:txtBeneficiaryCountryCode" 			: setTabfocus("maintab","tcontent2"); focusTextArea('MF:txtAddress1');break;
			//Second
			
			
			
			
			
			case "MF:txtperiodOfPres"     : gid('MF:lstAmdPayableBy').focus();
															  break;
			
			case "MF:txtLCEnhancementReductionNochange"     : gid('MF:txtperiodOfPres').focus();
															  break;
															  
		
		case "MF:lstAmdPayableBy"     : if(gid('MF:chkChangeofBeneficiary').checked==true)
															  {
															  	if(gid('MF:txtBeneficiaryCode').value!="")
																{
																	setTabfocus("maintab","tcontent2");gid('MF:txtBeneficiaryCode').focus();
																}
																else
																{
																	setTabfocus("maintab","tcontent2");gid('MF:txtBeneficiaryCountryCode').focus();
																}
															  }
															  else
															  {
															  	setTabfocus("maintab","tcontent2");gid('MF:chkCgAdvBk').focus() ;
															  }
															  break;
															  
															  
															  													  
															  
																		
			case "MF:txtEnhancementReductionAmount" 		 : //setTabfocus("maintab","tcontent3");gid('MF:txtLCEnhancementReductionNochange').focus();break;//COMMENTED ON 16/10/2018
																//ADDED ON 16/01/2018 START
																if(gid('MF:txtBeneficiaryCountryCode').disabled == false )
																{
																	setTabfocus("maintab","tcontent2");
																	gid("MF:txtBeneficiaryCountryCode").focus();
																}else
																{
																	gid("MF:chkChangeofBeneficiary").focus();
																}break;
																//ADDED ON 16/01/2018 END
			case "MF:txtEnhancementReductionAmount1" 	     : setTabfocus("maintab","tcontent3");gid('MF:txtLCEnhancementReductionNochange').focus() ; break;
			case "MF:txtDeviationAllowed"					 : if(gid('MF:txtLCEnhancementReductionNochange').value=="")
																{
																 setTabfocus("maintab","tcontent3"); gid('MF:txtLCEnhancementReductionNochange').focus();
																}
																else
																{
																 setTabfocus("maintab","tcontent3");gid('MF:txtEnhancementReductionAmount1').focus();
																}
																  break;
			case "MF:txtDeviationAllowed1"					 : //setTabfocus("maintab","tcontent3");gid('MF:txtDeviationAllowed').focus(); break;//COMMENTED ON 16/10/2018
																//ADDED ON 16/01/2018 START
																setTabfocus("maintab","tcontent3");
																if(gid('MF:txtDeviationAllowed').disabled == false )
																{
																	gid("MF:txtDeviationAllowed").focus();
																}
																else if(gid('MF:txtEnhancementReductionAmount').disabled == false )
																{
																	gid("MF:txtEnhancementReductionAmount").focus();
																}
																else if(gid('MF:txtLCEnhancementReductionNochange').disabled == false )
																{
																	gid("MF:txtLCEnhancementReductionNochange").focus();
																}
																else if(gid('MF:txtBeneficiaryCountryCode').disabled == false )
																{
																	setTabfocus("maintab","tcontent2");
																	gid("MF:txtBeneficiaryCountryCode").focus();
																}break;
																//ADDED ON 16/01/2018 END
			case "MF:txtDeviationAmount"	   				 : //setTabfocus("maintab","tcontent3");gid('MF:txtDeviationAllowed1').focus(); break;//COMMENTED ON 16/10/2018
																//ADDED ON 16/01/2018 START
																setTabfocus("maintab","tcontent3");
																if(gid('MF:txtDeviationAllowed1').disabled == false )
																{
																	gid("MF:txtDeviationAllowed1").focus();
																}
																else if(gid('MF:txtDeviationAllowed').disabled == false )
																{
																	gid("MF:txtDeviationAllowed").focus();
																}
																else if(gid('MF:txtEnhancementReductionAmount').disabled == false )
																{
																	gid("MF:txtEnhancementReductionAmount").focus();
																}
																else if(gid('MF:txtLCEnhancementReductionNochange').disabled == false )
																{
																	gid("MF:txtLCEnhancementReductionNochange").focus();
																}
																else if(gid('MF:txtBeneficiaryCountryCode').disabled == false )
																{
																	setTabfocus("maintab","tcontent2");
																	gid("MF:txtBeneficiaryCountryCode").focus();
																}break;
																//ADDED ON 16/01/2018 END
			case "MF:lstAmountQualifier"		 	         : //setTabfocus("maintab","tcontent3");gid('MF:txtDeviationAmount').focus();//COMMENTED ON 16/10/2018
																//ADDED ON 16/10/2018 START
															 	setTabfocus("maintab","tcontent3");
															  if(gid('MF:txtDeviationAmount').disabled == false )
													   			{
															 		gid("MF:txtDeviationAmount").focus();	
																}
																else if(gid('MF:txtDeviationAllowed1').disabled == false )
																{
																	gid("MF:txtDeviationAllowed1").focus();
																}
																else if(gid('MF:txtDeviationAllowed').disabled == false )
																{
																	gid("MF:txtDeviationAllowed").focus();
																}
																else if(gid('MF:txtEnhancementReductionAmount').readOnly == false )
																{
																	gid("MF:txtEnhancementReductionAmount").focus();
																}
																else if(gid('MF:txtLCEnhancementReductionNochange').disabled == false )
																{
																	gid("MF:txtLCEnhancementReductionNochange").focus();
																}
																else if(gid('MF:txtBeneficiaryCountryCode').disabled == false )
																{
																	setTabfocus("maintab","tcontent2");
																	gid("MF:txtBeneficiaryCountryCode").focus();
																}break;
																//ADDED ON 16/10/2018 END
																
			case "MF:txtAdditionalAmountsCovered"		     : setTabfocus("maintab","tcontent3");gid('MF:lstAmountQualifier').focus(); break;
			case "MF:txtTermsofPrice"			       	     : setTabfocus("maintab","tcontent3");focusTextArea('MF:txtAdditionalAmountsCovered'); break;
			case "MF:txtLastDateforNegotiation"		    	 : setTabfocus("maintab","tcontent9");gid('MF:txtTermsofPrice').focus(); break;
			case "MF:txtPlaceofExpiry"	                     : if(gid('MF:txtLastDateforNegotiation').disabled == false )//ADDED ON 16/10/2018 START
													   			{
															 		setTabfocus("maintab","tcontent9");gid('MF:txtLastDateforNegotiation').focus();
															 	} 
															 	else
															 	{
															 		setTabfocus("maintab","tcontent3");focusTextArea('MF:txtAdditionalAmountsCovered');
															 	} break;//ADDED ON 16/10/2018 END
			case "MF:txtLatestDateofShipment"	   			 : setTabfocus("maintab","tcontent9");gid('MF:txtPlaceofExpiry').focus(); break;
			case "MF:txtShipmentPeriodSchedule"			 	 : setTabfocus("maintab","tcontent9");gid('MF:txtLatestDateofShipment').focus(); break;
			case "MF:txtPresentationDetails"			     : if(gid('MF:txtShipmentPeriodSchedule').disabled == false )//ADDED ON 16/10/2018 START
															   {
																   		if(gid('MF:txtLatestDateofShipment').value!="")
																   		{
																   			setTabfocus("maintab","tcontent9");gid('MF:txtLatestDateofShipment').focus(); 
																   		}
																   		else
																   		{
																   			setTabfocus("maintab","tcontent9");gid('MF:txtShipmentPeriodSchedule').focus();
																   		}
															   }//ADDED ON 16/10/2018 END
															   else
															   {
															   		setTabfocus("maintab","tcontent9");gid('MF:txtPlaceofExpiry').focus();
															   }
															   break; 
			case "MF:chkWithinValidityofLC"	 		     	: setTabfocus("maintab","tcontent9");gid('MF:txtPresentationDetails').focus(); break;
			//Third
			case "MF:chkUsanceInterestToBeBorneByApplicant" : if(gid('MF:txtPresentationDetails').value=="")
																		{
																		 setTabfocus("maintab","tcontent9");gid('MF:chkWithinValidityofLC').focus(); break;
																		}
																		else
																		{
																		setTabfocus("maintab","tcontent9");gid('MF:txtPresentationDetails').focus(); break;
																		}
			case "MF:txtDrawDowns"							 : setTabfocus("maintab","tcontent4");gid('MF:chkUsanceInterestToBeBorneByApplicant').focus(); break;
			//Fourth
			case "MF:txtConvRatetobasecurr"			     	 : LAST_FIELD(); break;
			case "MF:txtConvRateToLimitCurrency"			 : setTabfocus("maintab","tcontent5");gid('MF:txtConvRatetobasecurr').focus(); break;
			
					//Changes P.Subramani-Chn-20/10/2008 Beg
			//----------------------------------6a th tab-------------------------------------------------------------------------------------------------------------
		
			case "MF:txtmargincurr" 	    			:setTabfocus("maintab","tcontent6");gid('MF:LimitNext').focus();break;
			case "MF:txtmarginpercentage" 				:setTabfocus("maintab","tcontent6a");gid('MF:txtmargincurr').focus();break;
			case "MF:txtmarginpercentage1"				:setTabfocus("maintab","tcontent6a");gid('MF:txtmargincurr').focus();break;
			
			case "MF:txtmarginamt1"						:if(flag1==1)
														 {
														 	setTabfocus("maintab","tcontent6a");gid('MF:txtmarginpercentage').focus();
														 }
														 else if(flag1==3)
														 {
															setTabfocus("maintab","tcontent6a");gid('MF:txtmarginpercentage1').focus();
														 }break;	
			case "MF:txtmarginamt2"						:if(flag1==2)
														 {
															setTabfocus("maintab","tcontent6a");gid('MF:txtmarginpercentage1').focus();
														 }
														 else if(flag1==3)
														 {
															setTabfocus("maintab","tcontent6a");gid('MF:txtmarginamt1').focus();
														 }break;	
													
			case "MF:txtcashmarginamt1"					:if(flag1==1)
														 {
														 	setTabfocus("maintab","tcontent6a");gid('MF:txtmarginamt1').focus();
														 }
														 else if(flag1==3)
														 {
															setTabfocus("maintab","tcontent6a");gid('MF:txtmarginamt2').focus();
														 }break;	
													
			case "MF:txtcashmarginamt2"					:if(flag1==2)
														 {
															setTabfocus("maintab","tcontent6a");gid('MF:txtmarginamt2').focus();
														 }
														 else if(flag1==3)
														 {
															setTabfocus("maintab","tcontent6a");gid('MF:txtcashmarginamt1').focus();
														 }break;	
													
			case "MF:lstmargintypeforLC"				:if(flag1==1)
														 {
															setTabfocus("maintab","tcontent6a");gid('MF:txtcashmarginamt1').focus();
														 }
														 else if(flag1==2)
														 {
															setTabfocus("maintab","tcontent6a");gid('MF:txtcashmarginamt2').focus();
														 }
														 else if(flag1==3)
														 {
															setTabfocus("maintab","tcontent6a");gid('MF:txtcashmarginamt2').focus();
														 }break;
														 
		case "MF:MarginNext"				    	: setTabfocus("maintab","tcontent6a");gid('MF:lstmargintypeforLC').focus();break;														 
		//Changes P.Subramani-Chn-20/10/2008 End														 
			
			//Changes P.Subramani-Chn-12/04/2008 Beg										
			case "MF:txtusnchgsamt1"						 : setTabfocus("maintab","tcontent7");objTFMCharges.FocusPrevious();break; 
			case "MF:txtcommchgsamt1"						 : setTabfocus("maintab","tcontent7"); gid('MF:txtusnchgsamt1').focus() ;break;
			case "MF:ChargeNext"							 :setTabfocus("maintab","tcontent7");gid('MF:txtcommchgsamt1').focus() ;break;
			//Changes P.Subramani-Chn-12/04/2008 End
			case "MF:LimitNext"			    				 : setTabfocus("maintab","tcontent5");gid('MF:ConversionNext').focus(); break;
			//Changes P.Subramani-Chn-27/02/2008
			
			//ADDED ON 16/10/2018 START
			case "MF:cmdokbutton"					:
														if(parseFloat(unFormat(document.getElementById('MF:TFMChargesDetails:outtxttotal').value)) > 0)
	    													  {
	    													  		setTabfocus("maintab","tcontent8");document.getElementById('MF:translmt:txtGLAccessCode').focus();	break;											
	    													  }
	    													  else
	    													  {
	    													  		setTabfocus("maintab","tcontent7");objTFMCharges.FocusPrevious();break;
	    												      }
			case "MF:txtReceRef" 					: setTabfocus("maintab","tcontent8");gid('MF:cmdokbutton').focus() ;break;
			case "MF:txtDocCredit" 					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent1"); gid('MF:txtReceRef').focus() ;break;
			case "MF:chkIssueBank" 					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent1"); gid('MF:txtDocCredit').focus() ;break;
			case "MF:lstIssueBICdtl"				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent1"); gid('MF:chkIssueBank').focus() ;break;
			case "MF:txtIssueBicCode" 				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent1"); gid('MF:lstIssueBICdtl').focus();break;
			case "MF:txtIssueBicBank" 				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent1"); gid('MF:txtIssueBicCode').focus() ;break;
			case "MF:txtIssueBicBrn" 				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent1"); gid('MF:txtIssueBicBank').focus();break;
			case "MF:txtIssueAcnt" 					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent1"); gid('MF:lstIssueBICdtl').focus();break;
			case "MF:txtIssueBankName" 				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent1"); gid('MF:txtIssueAcnt').focus();break;
			case "MF:txtIssueAddress" 				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent1"); gid('MF:txtIssueBankName').focus();break;
			case "MF:txtIssueCntry" 				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent1"); focusTextArea('MF:txtIssueAddress') ;break;
			case "MF:txtDateOfIssue"				: if(gid('MF:lstIssueBICdtl').disabled == false )
   													 {
														if(trim(gid('MF:lstIssueBICdtl').value) == "1" || trim(gid('MF:lstIssueBICdtl').value) == "")
	   													 {
	   														setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent1"); gid('MF:txtIssueBicBrn').focus() ;break;
	   													 }
	   													 else
	   													 {
	   														setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent1"); gid('MF:txtIssueCntry').focus() ;break;
	   													 }
   													 }
   													 else
   													 {
   													 	setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent1"); gid('MF:chkIssueBank').focus() ;break;
   													 }
			case "MF:txtTakCharge" 					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent1"); focusTextArea('MF:txtDateOfIssue') ;break;
			case "MF:txtPortLoad" 					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent2"); focusTextArea('MF:txtTakCharge') ;break;
			case "MF:txtPortDis" 					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent2"); focusTextArea('MF:txtPortLoad') ;break;
			case "MF:txtPortDest"					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent2"); focusTextArea('MF:txtPortDis') ;break;
			//Changes Sanjay1 18-07-2019 Begin
			//case "MF:txtNarrative" 				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent2"); focusTextArea('MF:txtPortDest') ;break;
			case "MF:txtSendInfo"					: if(gid('MF:txtPortDest').disabled == true )
														{
															setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent1"); focusTextArea('MF:txtDateOfIssue') ;break;
														}
														else
														{
															setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent2"); focusTextArea('MF:txtPortDest') ;break;
														}
			//Changes Sanjay1 18-07-2019 End
			
			//ADDED ON 16/10/2018 END 
           //ADDED BY PRASHANTH ON 11 FEB 2019
           
         /*  			case "MF:txtDocRequired1" 	    						: setTabfocus("maintab","tcontent10");  
           			                                                                
           			case "MF:txtDocRequired2" 	    						: setTabfocus("maintab","tcontent10"); 
                                                   					  		  focusTextArea('MF:txtDocRequired1');
                                                   					           setTabfocus("subtab","tsubcontent6");
           			case "MF:txtDocRequired3" 	    				     : setTabfocus("maintab","tcontent10"); 
                                                   					  focusTextArea('MF:txtDocRequired2');
                                                   					  
                                                   					  setTabfocus("subtab","tsubcontent6"); 
                                                   					  */
           //ADDED BY PRASHANTH ON 11 FEB 2019
			case "MF:lstamdChoice":gid('MF:uptoRange').focus();    break;
			case "MF:uptoRange":gid('MF:txtfrmRange').focus();    break;
			case "MF:txtfrmRange":     
			                    if(gid('MF:txtChoiceSl').value==1)
			                    {
			                    		setTabfocus("maintab","tcontent10");
			                    		setTabfocus("subtab","tsubcontent3");
			                    		//Changes Sanjay1 18-07-2019 Begin
										//gid('MF:txtNarrative').focus();
										gid('MF:txtSendInfo').focus();
										//Changes Sanjay1 18-07-2019 End
			                    }         
			                    else{
			                   		 	gid('MF:txtChoiceSl').value=gid('MF:txtChoiceSl').value-1;
			                            gid('MF:txtfrmRange').value=aMap[choiceSlforGrid1-1][0][0];
			                             gid('MF:uptoRange').value=aMap[choiceSlforGrid1-1][0][1];
			                              gid('MF:lstamdChoice').value=aMap[choiceSlforGrid1-1][0][2];
			                        gid('MF:lstamdChoice').focus();    
			                    }break;
			                    
			
	   case "MF:txtApplInsOrRepl":gid('MF:lstamdChoice').focus();    break;
			                    
      case "MF:Focus1" 					             :gid('MF:txtApplInsOrRepl').focus();
			                                                  break;     	    
           
        case "MF:txtfrmRangeDoc":					if(gid('MF:txtChoiceSlDoc').value==1)
										                    {
										                    		commonBackTrack("4");break;
										                    }         
										                    else{
										                   		 	gid('MF:txtChoiceSlDoc').value=gid('MF:txtChoiceSlDoc').value-1;
										                            gid('MF:txtfrmRangeDoc').value=aMap2[choiceSlforGrid2-1][0][0];
										                             gid('MF:uptoRangeDoc').value=aMap2[choiceSlforGrid2-1][0][1];
										                              gid('MF:lstamdChoiceDoc').value=aMap2[choiceSlforGrid2-1][0][2];
										                        gid('MF:lstamdChoiceDoc').focus();    
										                    }break;
										                    
										                       
           
           case "MF:uptoRangeDoc" 					  	:gid('MF:txtfrmRangeDoc').focus();
			                                                  break;   
			                                                  
           
            case "MF:lstamdChoiceDoc" 					  :gid('MF:uptoRangeDoc').focus();
			                                                  break;   
			                                                  
          	 case "MF:txtApplInsOrReplDoc" 					  :gid('MF:lstamdChoiceDoc').focus();
			                                                  break;   
			                                                  
           
     		 case "MF:Focus2" 					             :gid('MF:txtApplInsOrReplDoc').focus();
			                                                  break;     
           	   
			                                                    
           	case "MF:txtfrmRangeAddl":					if(gid('MF:txtChoiceSlAddl').value==1)
										                    {
										                    		commonBackTrack("5");break;
										                    }         
										                    else{
										                   		 	gid('MF:txtChoiceSlAddl').value=gid('MF:txtChoiceSlAddl').value-1;
										                            gid('MF:txtfrmRangeAddl').value=aMap3[choiceSlforGrid3-1][0][0];
										                             gid('MF:uptoRangeAddl').value=aMap3[choiceSlforGrid3-1][0][1];
										                              gid('MF:lstamdChoiceAddl').value=aMap3[choiceSlforGrid3-1][0][2];
										                        gid('MF:lstamdChoiceAddl').focus();    
										                    }break;
										                    
										                    
           case "MF:uptoRangeAddl" 							 :gid('MF:txtfrmRangeAddl').focus();
			                                                  break;
		   case "MF:lstamdChoiceAddl" 					      :gid('MF:uptoRangeAddl').focus();
			                                                  break;                                                  
           case "MF:txtApplInsOrReplAddl" 					 :gid('MF:lstamdChoiceAddl').focus();
			                                                  break;
           case "MF:Focus3" 					             :gid('MF:txtApplInsOrReplAddl').focus();
			                                                  break;
           case "MF:lstcredit" 							:commonBackTrack("6");break;
           //added by navya on 27/06/19 begin
           case "MF:txtCharge"							:gid('MF:lstcredit').focus();
			                                                  break;
			//end
           case "MF:txtApplAddress" 					:
           													if(gid('MF:chkChgFormDc').checked==true)
															{
															 setTabfocus("maintab","tcontent10");
															 setTabfocus("subtab","tsubcontent7");
															 gid('MF:lstcredit').focus();
															 return;
															}
															else{
															commonBackTrack("6");
															}	
															 break;
           
           case "MF:lstAppRule" 						:  if(gid('MF:chkChgAppl').checked==true)
															{
															 setTabfocus("maintab","tcontent10");
															 setTabfocus("subtab","tsubcontent7");
															 gid('MF:txtApplAddress').focus();
															 return;
															}
															else if(gid('MF:chkChgFormDc').checked==true)
															{
															 setTabfocus("maintab","tcontent10");
															 setTabfocus("subtab","tsubcontent7");
															 gid('MF:lstcredit').focus();
															 return;
															}
															else{
															commonBackTrack("6");
															}	
															break;
           
           
           case "MF:lstAvl" 						:commonBackTrack("7");
										              break;
													 
			case "MF:lstAvlBICdtl" 					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent8"); gid('MF:lstAvl').focus() ;break;
			case "MF:txtAvlBicCode" 				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent8"); gid('MF:lstAvlBICdtl').focus() ;break;
			
			case "MF:txtAvlBicBank" 				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent8"); gid('MF:txtAvlBicCode').focus() ;break;
			case "MF:txtAvlBicBrn" 					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent8"); gid('MF:txtAvlBicBank').focus() ;break;
			case "MF:txtAvlAcnt" 					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent8"); gid('MF:lstAvlBICdtl').focus() ;break;
			case "MF:txtAvlBankName" 				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent8"); gid('MF:txtAvlAcnt').focus() ;break;
			case "MF:txtAvlAddress" 				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent8"); gid('MF:txtAvlBankName').focus() ;break;
			case "MF:txtAvlCntry" 					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent8"); focusTextArea('MF:txtAvlAddress') ;break;
			case "MF:txtDraft" 						: //Changes Sanjay1 18-07-2019 Begin
													avlBicList();
													//Changes Sanjay1 18-07-2019 End
													if(trim(gid('MF:lstAvlBICdtl').value) == "1" || trim(gid('MF:lstAvlBICdtl').value) == "")
   													 {	
   														setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent8"); gid('MF:txtAvlBicBrn').focus() ;break;
   													 }
   													 else
   													 {
   														setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent8"); gid('MF:txtAvlCntry').focus() ;break;
   													 }
            case "MF:chkDrawee" 					: commonBackTrack("8");
										              break;
			case "MF:lstDrwBICdtl" 					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent9"); gid('MF:chkDrawee').focus() ;break;
			case "MF:txtDrwBicCode" 				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent9"); gid('MF:lstDrwBICdtl').focus() ;break;
			case "MF:txtDrwBicBank" 				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent9"); gid('MF:txtDrwBicCode').focus() ;break;
			case "MF:txtDrwBicBrn" 					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent9"); gid('MF:txtDrwBicBank').focus() ;break;
			case "MF:txtDrwAcnt" 					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent9"); gid('MF:lstDrwBICdtl').focus() ;break;
			case "MF:txtDrwBankName" 				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent9"); gid('MF:txtDrwAcnt').focus() ;break;
			case "MF:txtDrwAddress" 				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent9"); focusTextArea('MF:txtDrwBankName') ;break;
			case "MF:txtDrwCntry" 					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent9"); gid('MF:txtDrwAddress').focus() ;break;
			case "MF:txtMixedPaydtl" 				: 
													if(gid('MF:lstDrwBICdtl').disabled == false )
   													 {
														if(trim(gid('MF:lstDrwBICdtl').value) == "1" || trim(gid('MF:lstDrwBICdtl').value) == "")
	   													 {
	   														setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent9"); gid('MF:txtDrwBicBrn').focus() ;break;
	   													 }
	   													 else
	   													 {
	   														setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent9"); gid('MF:txtDrwCntry').focus() ;break;
	   													 }
   													 }
   													 else
   													 {
   													 	setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent9"); gid('MF:chkDrawee').focus() ;break;
   													 }
			case "MF:txtDeferPaydtl" 				: //Changes Sanjay1 18-07-2019 Begin
													setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent9"); gid('MF:txtMixedPaydtl').focus() ;break;
														/*	if(gid('MF:lstDrwBICdtl').disabled == false )
   													 {
														if(trim(gid('MF:lstDrwBICdtl').value) == "1" || trim(gid('MF:lstDrwBICdtl').value) == "")
	   													 {
	   														setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent9"); gid('MF:txtDrwBicBrn').focus() ;break;
	   													 }
	   													 else
	   													 {
	   														setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent9"); gid('MF:txtDrwCntry').focus() ;break;
	   													 }
   													 }
   													 else
   													 {
   													 	setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent9"); gid('MF:chkDrawee').focus() ;break;
   													 }*/
   													 
   													 //Changes Sanjay1 18-07-2019 End
   													 
           
           	case "MF:lstparShip" 					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent9"); focusTextArea('MF:txtDeferPaydtl') ;break;
			case "MF:lsttranShip" 					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent9"); gid('MF:lstparShip').focus() ;break;
			
           
           
 		    case "MF:lstConfInst" 					: commonBackTrack("9");
										              break;
           
           /*if(gid("MF:lstConfInst").value=="1"){
			    //Changes Sanjay1 18-07-2019 Begin
			    //setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10");gid('MF:txtConfirmedByBank').focus() ;break;
			    setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10");gid('MF:lstReimbcfmBank').focus();break;
			}else{
				setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10"); 
				gid('MF:lstConfInst').focus() ;break;
			
			}*/
            //case "MF:txtConfirmedByBank" 						: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10"); focusTextArea('MF:lstConfInst') ;break;
		    //case "MF:txtConfirmedBYBranch" 						: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10"); focusTextArea('MF:txtConfirmedByBank') ;break;
		    //case "MF:txtConfirmedBYBranchname" 					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10"); focusTextArea('MF:txtConfirmedBYBranch') ;break;
			case "MF:lstReimbcfmBank" 					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10"); gid('MF:lstConfInst').focus() ;break;
			case "MF:txtReimcfmBicCode" 				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10"); gid('MF:lstReimbcfmBank').focus() ;break;
			case "MF:txtReimcfmBicBank" 				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10"); gid('MF:txtReimcfmBicCode').focus() ;break;
			case "MF:txtReimcfmBicBrn" 				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10"); gid('MF:txtReimcfmBicBank').focus() ;break;
			
           
            case "MF:txtcfmReimAcnt" 					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10"); gid('MF:lstReimbcfmBank').focus() ;break;
			case "MF:txtcfmReimBankName" 				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10"); gid('MF:txtcfmReimAcnt').focus() ;break;
			case "MF:txtcfmReimAddress" 				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10"); gid('MF:txtcfmReimBankName').focus() ;break;
			case "MF:txtcfmReimCntry" 					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10"); focusTextArea('MF:txtcfmReimAddress') ;break;
			case "MF:chkReimb" 					:
													if(gid('MF:lstReimbcfmBank').disabled == false )
   													 {
														if(trim(gid('MF:lstReimbcfmBank').value) == "1" || trim(gid('MF:lstReimbcfmBank').value) == "")
	   													 {
	   														setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10"); gid('MF:txtReimcfmBicBrn').focus() ;break;
	   													 }
	   													 else
	   													 {
	   														setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10"); gid('MF:txtcfmReimCntry').focus() ;break;
	   													 }
   													 }
   													 else
   													 {
   													 	setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10"); gid('MF:lstConfInst').focus() ;break;
   													 }
			//Changes Sanjay1 18-07-2019 End
           
            case "MF:lstReimbBank" 					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10"); gid('MF:chkReimb').focus() ;break;
			case "MF:txtReimBicCode" 				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10"); gid('MF:lstReimbBank').focus() ;break;
			case "MF:txtReimBicBank" 				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10"); gid('MF:txtReimBicCode').focus() ;break;
			case "MF:txtReimBicBrn" 				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10"); gid('MF:txtReimBicBank').focus() ;break;
			
           
            case "MF:txtReimAcnt" 					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10"); gid('MF:lstReimbBank').focus() ;break;
			case "MF:txtReimBankName" 				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10"); gid('MF:txtReimAcnt').focus() ;break;
			case "MF:txtReimAddress" 				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10"); gid('MF:txtReimBankName').focus() ;break;
			case "MF:txtReimCntry" 					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10"); focusTextArea('MF:txtReimAddress') ;break;
			case "MF:txtInstPay" 					:
													if(gid('MF:lstReimbBank').disabled == false )
   													 {
														if(trim(gid('MF:lstReimbBank').value) == "1" || trim(gid('MF:lstReimbBank').value) == "")
	   													 {
	   														setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10"); gid('MF:txtReimBicBrn').focus() ;break;
	   													 }
	   													 else
	   													 {
	   														setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10"); gid('MF:txtReimCntry').focus() ;break;
	   													 }
   													 }
   													 else
   													 {
   													 	setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10"); gid('MF:chkReimb').focus() ;break;
   													 }
   													 
   													 
           
            case "MF:chkAdvise" 					: commonBackTrack("10");
										              break;
			case "MF:lstAdviseBank" 				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent11"); gid('MF:chkAdvise').focus() ;break;
			case "MF:txtAdviseBicCode"				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent11"); gid('MF:lstAdviseBank').focus() ;break;
			case "MF:txtAdviseBicBank" 				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent11"); gid('MF:txtAdviseBicCode').focus() ;break;
			case "MF:txtAdviseBicBrn" 				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent11"); gid('MF:txtAdviseBicBank').focus() ;break;
			case "MF:txtAdviseAcnt" 				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent11"); gid('MF:lstAdviseBank').focus() ;break;
			case "MF:txtAdviseBankName" 			: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent11"); gid('MF:txtAdviseAcnt').focus() ;break;
			case "MF:txtAdviseAddress" 				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent11"); gid('MF:txtAdviseBankName').focus() ;break;
			case "MF:txtAdviseCntry" 				: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent11"); focusTextArea('MF:txtAdviseAddress');break;
           
           
           
           
            case "MF:txtfrmRangeSplBene"					:  if(gid('MF:txtChoiceSlSplBene').value==1)
										                    {
																commonBackTrack("11");
										                       break;
										                    }         
										                    else{
										                   		 	gid('MF:txtChoiceSlSplBene').value=gid('MF:txtChoiceSlSplBene').value-1;
										                            gid('MF:txtfrmRangeSplBene').value=aMap4[choiceSlforGrid4-1][0][0];
										                             gid('MF:uptoRangeSplBene').value=aMap4[choiceSlforGrid4-1][0][1];
										                              gid('MF:lstamdChoiceSplBene').value=aMap4[choiceSlforGrid4-1][0][2];
										                       		  gid('MF:lstamdChoiceSplBene').focus();    
										                    }break;
           
           case "MF:uptoRangeSplBene"					: gid('MF:txtfrmRangeSplBene').focus();
			                                              break;
           
           case "MF:txtApplInsOrReplSplBene"					: gid('MF:uptoRangeSplBene').focus();
			                                                	  break;
			                                                  
           case "MF:Focus4"					: setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent12"); 
												focusTextArea('MF:txtApplInsOrReplSplBene');
			                                                  break;
			case "MF:txtfrmRangeSplRecev"					:  if(gid('MF:txtChoiceSlSplRecev').value==1)
										                    {
										                    		setTabfocus("maintab","tcontent10");
										                    		setTabfocus("subtab","tsubcontent12");
																	gid('MF:Focus4').focus();
										                    }         
										                    else{
										                   		 	gid('MF:txtChoiceSlSplRecev').value=gid('MF:txtChoiceSlSplRecev').value-1;
										                            gid('MF:txtfrmRangeSplRecev').value=aMap5[choiceSlforGrid5-1][0][0];
										                             gid('MF:uptoRangeSplRecev').value=aMap5[choiceSlforGrid5-1][0][1];
										                              gid('MF:lstamdChoiceSplRecev').value=aMap5[choiceSlforGrid5-1][0][2];
										                        gid('MF:lstamdChoiceSplRecev').focus();    
										                    }break;
			
			case "MF:uptoRangeSplRecev"					: gid('MF:txtfrmRangeSplRecev').focus();
			                                                  break;
			                                                  
			case "MF:lstamdChoiceSplRecev"					: gid('MF:uptoRangeSplRecev').focus();
			                                                  break;
			
			case "MF:txtApplInsOrReplSplRecev"					: gid('MF:lstamdChoiceSplRecev').focus();
			                                                 	  break;
			
			case "MF:Submit" 	    						: setTabfocus("maintab","tcontent10"); 
			 												  setTabfocus("subtab","tsubcontent13"); 
			                                                 gid('MF:txtApplInsOrReplSplRecev').focus();
			                                                 break;
                                     			             //ADDED BY PRASHANTH ON 11 FEB 2019
			                                                 
			                                                  
															  // focusTextArea('MF:txtSendInfo') ;break;
			
			case "MF:Cancel"			    				: setTabfocus("maintab","tcontent8");objTranStmntPost.FocusPrevious();break;
			case "MF:Exit"				    				: setTabfocus("maintab","tcontent8");objTranStmntPost.FocusPrevious();break;
			//Eight
			case "MF:ConversionNext"				    	: setTabfocus("maintab","tcontent5");gid('MF:txtConvRatetobasecurr').focus();
			
			
			
		}
	}
//-----------------------------------------------------------------------------------------------------------------------------							     		
	//added by prashanth
	
	function commonBackTrack(currTab){
		if(gid('MF:chkCgAdvBk').checked==true && parseInt(currTab)>="11") 
		{
		//Changes Sanjay1 18-07-2019 Begin
		 //setTabfocus("maintab","tcontent10"); setTabfocus("subtab","tsubcontent11"); gid('MF:txtAdviseBicBrn').focus();
		 if(gid('MF:chkCgAdvBk').checked==true)
		 {
		 	AvlThrBiclist();
			if(trim(gid('MF:lstAdviseBank').value) == "1" || trim(gid('MF:lstAdviseBank').value) == "")
			 {	
				setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent11"); gid('MF:txtAdviseBicBrn').focus() ;
			 }
			 else
			 {
				setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent11"); gid('MF:txtAdviseCntry').focus() ;
			 }
		 }
		 else
		 {
			 setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent11"); gid('MF:chkCgAdvBk').focus() ;
		 }
		 return;
		 //Changes Sanjay1 18-07-2019 End
		}
		else if(gid('MF:chkChgReimbus').checked==true && parseInt(currTab)>="10")
		{
		 setTabfocus("maintab","tcontent10");
		 setTabfocus("subtab","tsubcontent10");
		 gid('MF:txtInstPay').focus();
		 return;
		}
		else if(gid('MF:chkCgDrawee').checked==true && parseInt(currTab)>="9")
		{
		 setTabfocus("maintab","tcontent10");
		 setTabfocus("subtab","tsubcontent9");
		 gid('MF:lsttranShip').focus();
		 return;
		}
		else if(gid('MF:chkChgAvlWith').checked==true && parseInt(currTab)>="8")
		{
		 setTabfocus("maintab","tcontent10");
		 setTabfocus("subtab","tsubcontent8");
		 gid('MF:txtDraft').focus();
		 return;
		}
		else if(gid('MF:chkChgApplRules').checked==true && parseInt(currTab)>="7")
		{
		 setTabfocus("maintab","tcontent10");
		 setTabfocus("subtab","tsubcontent7");
		 gid('MF:lstAppRule').focus();
		 return;
		}	
		else if(gid('MF:chkChgAppl').checked==true && parseInt(currTab)>="7")
		{
		 setTabfocus("maintab","tcontent10");
		 setTabfocus("subtab","tsubcontent7");
		 gid('MF:txtApplAddress').focus();
		 return;
		}	
		
		else if(gid('MF:chkChgFormDc').checked==true && parseInt(currTab)>="7")
		{
		 setTabfocus("maintab","tcontent10");
		 setTabfocus("subtab","tsubcontent7");
		 gid('MF:lstcredit').focus();
		 return;
		}
		else if(gid('MF:chkChgAddCond').checked==true && parseInt(currTab)>="6")
		{
		 setTabfocus("maintab","tcontent10");
		 setTabfocus("subtab","tsubcontent6");
		 gid('MF:Focus3').focus();
		 return;
		}	
		else if(gid('MF:chkChgDoc').checked==true && parseInt(currTab)>="5")
		{
		 setTabfocus("maintab","tcontent10");
		 setTabfocus("subtab","tsubcontent5");
		 gid('MF:Focus2').focus();
		 return;
		}
		else if(gid('MF:chkChgDoc').checked==true && parseInt(currTab)>="4")
		{
		 setTabfocus("maintab","tcontent10");
		 setTabfocus("subtab","tsubcontent4");
		 gid('MF:Focus1').focus();
		 return;
		}
		
		else if(gid('MF:chkChgDesc').checked==true && parseInt(currTab)>="3")
		{
		 setTabfocus("maintab","tcontent10");
		 setTabfocus("subtab","tsubcontent4");
		 gid('MF:Focus1').focus();
		 return;
		}	
		
		else{
		setTabfocus("maintab","tcontent10");
		 setTabfocus("subtab","tsubcontent3");
		 gid('MF:txtSendInfo').focus();
		 return;
		}	
	}	
	
	
	
	//added by prashanth
	
	function LAST_FIELD()
	{
	    var no_of_rows1 = gridEolcamd.getRowsNum();
	    setTabfocus("maintab","tcontent4");
	    if(gridEolcamd.cells(no_of_rows1,1).getValue()=="S")
	    {
	    	SetFocus(gridEolcamd,no_of_rows1,"tamt");	
	    }
	    else
	    {
	    	SetFocus(gridEolcamd,no_of_rows1,"docdelivery");	
	    }
	}	
//-----------------------------------------------------------------------------------------------------------------------------							     		
	function SHOW_HELP(fldobj)
	{ 
		switch (fldobj.name)
		{
			case "MF:txtBranchCode": 
							    		helpToken = "Hlpeolcamd1";
										fldArgs = gid('MF:txtBranchCode').value ;
										showHelp(helpToken,fldobj,fldArgs);
										break;
			
			case "MF:txtReferenceType": 
								    	helpToken = "Hlpeolcamd2";
										fldArgs = gid('MF:txtReferenceType').value ;
										showHelp(helpToken,fldobj,fldArgs);
										break;
									
			case "MF:txtReferenceSl"  : 
										//if(window.event.shiftKey)
										{
										if(gid('MF:seluseroption').value=="M")	
											{
				 								helpToken = "Hlpeolcamd12";
				 								//fldArgs = gid('MF:txtReferenceSl').value ;
				 								fldArgs = gid('MF:txtBranchCode').value+"|"+gid('MF:txtReferenceType').value+"|"+gid('MF:txtReferenceYear').value ;
				 								//Changes P.Subramani-Chn-25/02/2008
				 								showHelp(helpToken,fldobj,fldArgs,3);
				 								break;
											}		
										// else
										else if(gid('MF:seluseroption').value=="A") 
											{
												helpToken = "Hlpeolcamd11"
										 		fldArgs = gid('MF:txtBranchCode').value+"|"+gid('MF:txtReferenceType').value+"|"+gid('MF:txtReferenceYear').value ;
									     		//Changes P.Subramani-Chn-25/02/2008
											 	showHelp(helpToken,fldobj,fldArgs,3);
											 	break;
											}
										}
 										break;
							
			case "MF:txtBeneficiaryCode": 
									    	helpToken = "Hlpeolcamd3";
											fldArgs = gid('MF:txtBeneficiaryCode').value ;
											showHelp(helpToken,fldobj,fldArgs);
											break;
										
			case "MF:txtBeneficiaryCountryCode": 
									    	helpToken = "Hlpeolcamd4";
											fldArgs = gid('MF:txtBeneficiaryCountryCode').value ;
											showHelp(helpToken,fldobj,fldArgs);
											break;
			
			case "MF:txtAdvThruBank": 
									    	helpToken = "Hlpeolcamd5";
											fldArgs = gid('MF:txtAdvThruBank').value ;
											showHelp(helpToken,fldobj,fldArgs);
											break;
			
			case "MF:txtAdvThruBranch": 
									    	helpToken = "Hlpeolcamd6";
											fldArgs = gid('MF:txtAdvThruBranch').value ;
											showHelp(helpToken,fldobj,fldArgs);
											break;
											
			case "MF:txtTermsofPrice": 
									    	helpToken = "Hlpeolcamd7";
											fldArgs = gid('MF:txtTermsofPrice').value ;
											showHelp(helpToken,fldobj,fldArgs);
											break;
											
		//ADDED ON 16/10/2018 START
		
		case "MF:txtIssueBicCode": 
									     	helpToken = "HlpswiftBicCode";
									     	fldArgs = gid('MF:txtIssueBicCode').value ;
									     	registerAddInfo("TEXT");
											showHelp(helpToken,fldobj,fldArgs);
											break ; 									
									    	
		case "MF:txtIssueBicBrn": 
											helpToken = "Hlpeoutremswftbrn";
										    fldArgs = gid('MF:txtIssueBicBrn').value ;
											showHelp(helpToken,fldobj,fldArgs);
											break ; 
											
		case "MF:txtIssueCntry": 
										    helpToken = "Hlpeoutrem5";
										    fldArgs = gid('MF:txtAppCntry').value ;
											showHelp(helpToken,fldobj,fldArgs);
											break ; 									
		//ADDED ON 16/10/2018 END								
		
		
		
		
		
		//ADDED BY PRASHANTH ON 29 JANUARY 2018
		//Changes Sanjay1 18-07-2019 Begin
		/*case "MF:txtConfirmedByBank" 	: 
			          									{
			          										 helpToken = "Hlpeolcconditions5";
										        			 fldArgs =gid('MF:txtConfirmedByBank').value;
															 showHelp(helpToken,fldobj,fldArgs);
			          									}break;	
		 case "MF:txtConfirmedBYBranch" 	: 
			          									{
			          										 helpToken = "Hlpeolcconditions6";
										        			 fldArgs =gid('MF:txtConfirmedByBank').value;
															 showHelp(helpToken,fldobj,fldArgs);
			          									}break;	*/
		//Changes Sanjay1 18-07-2019 End
		//ADDED BY PRASHANTH ON 29 JANUARY 2018
							
	   	}
	}
//----------------------------------------------OnChangeEvents----------------------------------------------------------------------------------
	function changeOption()
	{
		if(gid('MF:seluseroption').value=="")
		{
	 		clearFields();
		}
	}
//----------------------------------------------OnChangeEvents----------------------------------------------------------------------------------
	function ChangeEvents(fldobj)
 	{
    	switch (fldobj.name)
		{
				case "MF:txtBranchCode": if(gid('MF:txtBranchCode').value=="")
										 {
										 	if(gid('MF:seluseroption').value !="A")
				  						  	{
				  						    	gid('MF:txtBranchCode').value=userBranchCode;
									     		gid('MF:txtReferenceType').value="";
									     		gid('MF:txtReferenceYear').value="";
									     		gid('MF:txtReferenceSl').value="";	
												clearNonKeyFields();
				  						  	}
										 }
										 break;
					
			case "MF:txtReferenceType": if(gid('MF:txtReferenceType').value=="")
 										{
 										 if(gid('MF:seluseroption').value !="A")
				  						  {
				  						   	clearNonKeyFields();
				  						   	gid('MF:txtReferenceType').value="";
				  						   	gid('MF:txtReferenceSl').value="";
				  						  }
 										}
										break;
										
			case "MF:txtReferenceYear": if(gid('MF:txtReferenceYear').value=="")
 										{
 										 if(gid('MF:seluseroption').value !="A")
				  						  {
				  						   	clearNonKeyFields();
				  						   	gid('MF:txtReferenceSl').value="";
				  						  }
 										}
										break;
										
			case "MF:txtReferenceSl": if(gid('MF:txtReferenceSl').value=="")
									  {
									  	clearNonKeyFields();
			  						  }
									  break;		
			
		   case "MF:txtBeneficiaryCode":if(gid('MF:txtBeneficiaryCode').value=="" && (newbenef == "0") && gid("MF:txtReferenceType").value=="OLC" )//ADDED ON 07/11/2018
 										{
 										 	gid('MF:txtBeneficiaryName').value="";
 										 	gid('MF:txtAddress1').value="";
 										 	gid('MF:txtBeneficiaryCountryCode').value="";
 										 	gid('MF:outputlblBeneficiaryCountryCode').innerText="";
 										}
										break;			
		
			case "MF:txtBeneficiaryCountryCode": if(gid('MF:txtBeneficiaryCountryCode').value=="")
												 {
												  	gid('MF:outputlblBeneficiaryCountryCode').innerText="";
												 }
												 break;
												 			
   		   case "MF:txtTermsofPrice": if(gid('MF:txtTermsofPrice').value=="")
									  {
									  		gid('MF:outputlblTermsofPrice').innerText="";
									  }
											break;																
   		   case "MF:txtConvRatetobasecurr": if(gid('MF:txtConvRatetobasecurr').value=="")
											{
											 gid('MF:txtAdditionallcamtinBasecurr1').value="";
											 gid('MF:txtTotalLcAmtinbaseCurrafteramendment1').value="";
											 gid('MF:txtReductioninLCliabinBasecurr1').value="";
											}
											break;
   		  case "MF:txtConvRateToLimitCurrency": if(gid('MF:txtConvRateToLimitCurrency').value=="")
												{
												 gid('MF:txtChangeinLCLiabAmountInLimitCurrency1').value="";
												 gid('MF:txtFacilityLimit1').value="";
												 gid('MF:txtOsbeforethisamendment1').value="";
												 gid('MF:txtLCPendingToBeSanctioned1').value="";
												 gid('MF:txtLCliabafterthisamendment1').value="";
												 gid('MF:txtExcessOverLimit1').value="";
												 //Changes P.Subramani-Chn-27/02/2008
												 gid('MF:txtExcOverlimitDueCurrTrancurrAmt').value=""; 
												}
												break;	
												
				// ADDED BY PRASHANTH ON 06 FEB 2019
			case "MF:chkChgDesc"								: checkChangeDesc();break;	
			case "MF:chkChgDoc"								    : checkChangeDoc();break;	
			case "MF:chkChgAddCond"								: checkChangeAddCond();break;										
				// ADDED BY PRASHANTH ON 06 FEB 2019
				
				
				//NEW TAB ADDED BY PRASHANTH ON 20 FEB 2018
			case "MF:chkReqForCancel"								:checkChangeReqForCancel();break;	
			case "MF:chkChgAppl"								:checkChangeAppl();break;	
			case "MF:chkChgFormDc"								:checkChangeFormDoc();break;	
			case "MF:chkChgApplRules"								:checkChangeApplRules();break;	
			case "MF:chkChgAvlWith"								:checkChangeAvlWith();break;	
			case "MF:chkCgDrawee"								:checkChangeDrawee();break;	
			case "MF:chkChgReimbus"								:checkChangeReimbus();break;	
			case "MF:chkCgAdvBk"								:checkChangeAdvBk();break;	
			
			case "MF:chkDrawee"					:	validatecheckDrawee();break;	
			case "MF:chkReimb"					:	validatecheckReimb();break;
		    case "MF:chkAdvise"					:	validatecheckAdvise();break;
				
		   //NEW TAB ADDED BY PRASHANTH ON 20 FEB 2018	
		   
		   
		   
		   
		   case "MF:lstamdChoice"					:gid('MF:txtApplInsOrRepl').focus();break;
		   case "MF:txtApplInsOrRepl"				:gid('MF:Focus1').focus();break; 
		   
   		}														
    }
    
    
    
    
    function validatecheckReimb()
{
	checkReimb();
	if(gid('MF:chkReimb').checked==true)
		{
			gid('MF:lstReimbBank').focus();
		}
		else
		{
			focusTextArea('MF:txtInstPay');
		}

}


    function validatecheckDrawee()
{
	checkDrawee();
	if(gid('MF:chkDrawee').checked==true)
		{
			setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent9");
			gid('MF:lstDrwBICdtl').focus();
		}
		else
		{
			if(gid('MF:txtMixedPaydtl').readOnly==false)
			{
				setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent9");
				gid('MF:txtMixedPaydtl').focus();
			}
			else if(gid('MF:txtDeferPaydtl').readOnly==false)
			{
				setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent9");
				gid('MF:txtDeferPaydtl').focus();
			}
			else
			{
				setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent9");
				gid('MF:lstparShip').focus();
			}
		}

}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------		
	function NextPage()
	{
		setTabfocus("maintab","tcontent2");gid('MF:txtAmendmentEntryDate').focus(); 
	}
//----------------------------------------------OnclickEvents---------------------------------------------------------------------------------------------------------------------------------------------------------------
	function onClickEvents(fldobj)	
	{
    	switch (fldobj.name)
		{	
   			case "MF:chkChangeofBeneficiary"					:  /*if(gid("MF:chkChangeofBeneficiary").checked==true)
																   {
																   		gid("MF:outlblChangeofBeneficiary").innerText="Yes"
																   }
																   else
																   {
																   		gid("MF:outlblChangeofBeneficiary").innerText="No"
																   }*///COMMENTED ON 16/02/2018
																  //  chkbenficiary();break;//ADDED ON 16/10/2018  //COMMENTTED BY PRASHANTH
																  //ADDED BY PRASHANTH
																  		gid('MF:chkChgDesc').focus();
																  //ADDED BY PRASHANTH
																				   					   			
   			case "MF:chkWithinValidityofLC"						: if(gid('MF:chkWithinValidityofLC').checked==true)
																  {
																  		gid('MF:outlblWithinValidityofLC').innerText="Yes";
																  }
																  else
																  {
																 		gid('MF:outlblWithinValidityofLC').innerText="No";
																  }break;
																 
   			case "MF:chkUsanceInterestToBeBorneByApplicant"		: if(gid('MF:chkUsanceInterestToBeBorneByApplicant').checked==true)
																  {
																  		gid('MF:outlblUsanceInterestToBeBorneByApplicant').innerText="Yes";
																  }
																  else
																  {
																  		gid('MF:outlblUsanceInterestToBeBorneByApplicant').innerText="No";
																  }break;
																  
			//ADDED ON 16/10/2018 START
			
			case "MF:chkExpiryDate"								: checkExpiryDate();break;
																   
			case "MF:chkIncDec"									: checkIncrDecr();break;
																   
			case "MF:chkPerTolr"								: checkPerTolr();break;
																				   					   			
   			case "MF:chkPlacePort"								: checkPlacePort();break;
																 
   			case "MF:chkShipPeriod"								: checkShipPeriod();break;	
									   
			//ADDED ON 16/10/2018 END		
			
			// ADDED BY PRASHANTH ON 06 FEB 2019
   			case "MF:chkChgDesc"								: checkChangeDesc();break;	
   			case "MF:chkChgDoc"								    : checkChangeDoc();break;	
   			case "MF:chkChgAddCond"								: checkChangeAddCond();break;	
			// ADDED BY PRASHANTH ON 06 FEB 2019
			
			//NEW TAB ADDED BY PRASHANTH ON 20 FEB 2018
			case "MF:chkReqForCancel"								:checkChangeReqForCancel();break;	
			case "MF:chkChgAppl"								:checkChangeAppl();break;	
			case "MF:chkChgFormDc"								:checkChangeFormDoc();break;	
			case "MF:chkChgApplRules"								:checkChangeApplRules();break;	
			case "MF:chkChgAvlWith"								:checkChangeAvlWith();break;	
			case "MF:chkCgDrawee"								:checkChangeDrawee();break;	
			case "MF:chkChgReimbus"								:checkChangeReimbus();break;	
			case "MF:chkCgAdvBk"								:checkChangeAdvBk();break;	
		   //NEW TAB ADDED BY PRASHANTH ON 20 FEB 2018
			
		}
	} 

//----------------------------------------------KeyPressEvents---------------------------------------------------------------------------------------------------------------------------------------------------------------
	function keyPressEvents(fldobj)	
	{
		setMsg("");
		
		if (fldobj.name =="MF:txtAddress1")
		{
		 	validateTextArea("MF:txtAddress1",5,35,"validateAddress1();");
		 	return;
	 	}
		if (fldobj.name =="MF:txtAdditionalAmountsCovered")
		{
			validateTextArea("MF:txtAdditionalAmountsCovered",4,35,"validateAdditionalAmountsCovered();");
			return;
		}
		if (fldobj.name =="MF:txtShipmentPeriodSchedule")
		{
			validateTextArea("MF:txtShipmentPeriodSchedule",4,65,"validateShipmentPeriodSchedule();");
			return;
		}
		if (fldobj.name =="MF:txtPresentationDetails")
		{
			validateTextArea("MF:txtPresentationDetails",4,65,"validatePresentationDetails();");
			return;
		}
		//ADDED ON 16/10/2018 START
		if (fldobj.name =="MF:txtIssueAddress")
		{
			validateTextArea("MF:txtIssueAddress",3,35,"validateIssueAddress1()");
			return;
		}
		if (fldobj.name =="MF:txtTakCharge")
		{
			validateTextArea("MF:txtTakCharge",1,65,"validateTakCharge()");
			return;
		}
		if (fldobj.name =="MF:txtPortLoad")
		{
			validateTextArea("MF:txtPortLoad",1,65,"validatePortLoad()");
			return;
		}
		if (fldobj.name =="MF:txtPortDis")
		{
			validateTextArea("MF:txtPortDis",1,65,"validatePortDis()");
			return;
		}
		if (fldobj.name =="MF:txtPortDest")
		{
			validateTextArea("MF:txtPortDest",1,65,"validatePortDest()");
			return;
		}
		//Changes Sanjay1 18-07-2019 Begin
		/*if (fldobj.name =="MF:txtNarrative")
		{
			validateTextArea("MF:txtNarrative",35,50,"validateNarrative()");
			return;
		}*/
		//Changes Sanjay1 18-07-2019 End
		if (fldobj.name =="MF:txtSendInfo")
		{
			validateTextArea("MF:txtSendInfo",6,35,"validateSendInfo()");
			return;
		}
		//ADDED ON 16/10/2018 END
		
		
		
		//NEW FIELDS ADDED BY PRASHANTH
		
		if (fldobj.name =="MF:txtAppAddress")
		{
			validateTextArea("MF:txtAppAddress",3,35,"validateAppAddr()");
			return;
		}
		if (fldobj.name =="MF:txtAvlAddress")
		{
			validateTextArea("MF:txtAvlAddress",3,35,"validateAvlAddr()");
			return;
		}
		if (fldobj.name =="MF:txtDrwAddress")
		{
			validateTextArea("MF:txtDrwAddress",3,35,"validateDraweeAddr()");
			return;
		}
		if (fldobj.name =="MF:txtReimAddress")
		{
			validateTextArea("MF:txtReimAddress",3,35,"validateReimbAddr()");
			return;
		}
		if (fldobj.name =="MF:txtAdviseAddress")
		{
			validateTextArea("MF:txtAdviseAddress",3,35,"validateAdvAddr()");
			return;
		}
		// added by navya on 27/06/19 begin
		if (fldobj.name =="MF:txtCharge")
		{
			validateTextArea("MF:txtCharge",6,35,"validateCharges()");
			return;
		}
		//Changes Sanjay1 18-07-2019 Begin
		if (fldobj.name =="MF:txtcfmReimAddress")
		{
			validateTextArea("MF:txtcfmReimAddress",3,35,"validateReimbcfmAddr()");
			return;
		}
		//Changes Sanjay1 18-07-2019 End
		//end
		
		//NEW FIELDS ADDED BY PRASHANTH
		
		
		
		
		
		
   		//ADDED BY PRASHANTH ON 07 FEB 2019	
		if (fldobj.name =="MF:txtDesGood1")
		{
			validateTextArea("MF:txtDesGood1",100,65,"validateDesGood1()");
			return;
		}
		if (fldobj.name =="MF:txtDesGood2")
		{
			validateTextArea("MF:txtDesGood2",100,65,"validateDesGood2()");
			return;
		}
		if (fldobj.name =="MF:txtDesGood3")
		{
			validateTextArea("MF:txtDesGood3",100,65,"validateDesGood3()");
			return;
		}
		
		if (fldobj.name =="MF:txtDocRequired1")
		{
			validateTextArea("MF:txtDocRequired1",100,65,"validateDocRequired1()");
			return;
		}
		if (fldobj.name =="MF:txtDocRequired2")
		{
			validateTextArea("MF:txtDocRequired2",100,65,"validateDocRequired2()");
			return;
		}
		if (fldobj.name =="MF:txtDocRequired3")
		{
			validateTextArea("MF:txtDocRequired3",100,65,"validateDocRequired3()");
			return;
		}
		
		if (fldobj.name =="MF:txtAddCond1")
		{
			validateTextArea("MF:txtAddCond1",100,65,"validateAddCond1()");
			return;
		}
		if (fldobj.name =="MF:txtAddCond2")
		{
			validateTextArea("MF:txtAddCond2",100,65,"validateAddCond2()");
			return;
		}
		if (fldobj.name =="MF:txtAddCond3")
		{
			validateTextArea("MF:txtAddCond3",100,65,"validateAddCond3()");
			return;
		}
		
		if (fldobj.name =="MF:txtInstPay")
		{
			validateTextArea("MF:txtInstPay",12,65,"validateInstructPay()");
			return;
		}
		//Changes Sanjay1 18-07-2019 Begin
		if (fldobj.name =="MF:txtDeferPaydtl")
		{
			validateTextArea("MF:txtDeferPaydtl",3,65,"validateDeferPaydtl()");
			return;
		}
	
   		//ADDED BY PRASHANTH ON 07 FEB 2019	
		
		
	     if (fldobj.name == "MF:txtfrmRange")
	    {
		   	if(isNumeric(window.event.keyCode) == false)
		   	{
				setMsg(NUMBER_ALLOWED);
			}
		}
		
		if (window.event.keyCode == KEY_TAB || isEnterKeyPressed())
 		{
			switch (fldobj.name)
	   		{	
	   			case "MF:seluseroption"								: validateoption();break;					   			
	   			case "MF:txtBranchCode"								: validateBranchCode();break;
	   			case "MF:txtReferenceType"							: validateReferenceType();break;
	   			case "MF:txtReferenceYear"							: validateReferenceYear();break;
	   			case "MF:txtReferenceSl"							: validateReferenceSl();break;
	   									   									   			
				case "MF:txtAmendmentEntryDate"						: validateAmendmentEntryDate();break;						   									   									   			
				case "MF:txtCustomerletterNumber"					: validateCustomerletterNumber();break;
				case "MF:txtCustomerletterDate" 					: validateCustomerletterDate();break;
				//case "MF:txtReasonForAmendment"			 			: validateReasonForAmendment();break;//COMMENTED ON 16/10/2018
				//ADDED ON 16/10/2018 START
				case "MF:chkExpiryDate" 							: validatechkExpiryDate();break;
				case "MF:chkIncDec" 								: validatechkIncDec();break;
				case "MF:chkPerTolr" 								: validatechkPerTolr();break;
				case "MF:chkPlacePort" 								: validatechkPlacePort();break;
				case "MF:chkShipPeriod" 							: validatechkShipPeriod();break;
				//ADDED ON 16/10/2018 END
				case "MF:chkChangeofBeneficiary"					: validateChangeofBeneficiary();break;														
				case "MF:txtBeneficiaryCode"						: validateBeneficiaryCode();break;
				case "MF:txtBeneficiaryName"		   				: validateBeneficiaryName();break;
				case "MF:txtAddress1"				   				: validateAddress1();break;
				case "MF:txtBeneficiaryCountryCode"					: validateBeneficiaryCountryCode();break;
									
				case "MF:txtLCEnhancementReductionNochange"			: validateLCEnhancementReductionNochange();break;
				case "MF:txtEnhancementReductionAmount"				: validateEnhancementReductionAmount();break;
				case "MF:txtEnhancementReductionAmount1"			: validateEnhancementReductionAmount1();break;
				case "MF:txtDeviationAllowed"						: validateDeviationAllowed();break;
				case "MF:txtDeviationAllowed1"						: validateDeviationAllowed1();break;
				case "MF:txtDeviationAmount"						: validateDeviationAmount();break;
				case "MF:lstAmountQualifier"						: validateAmountQualifier();break;
				case "MF:txtAdditionalAmountsCovered"				: validateAdditionalAmountsCovered();break;
				case "MF:txtTermsofPrice"							: validateTermsofPrice();break;
				case "MF:txtLastDateforNegotiation"					: validateLastDateforNegotiation();break;
				case "MF:txtPlaceofExpiry"							: validatePlaceofExpiry();break;
				case "MF:txtLatestDateofShipment"					: validateLatestDateofShipment();break;
		        case "MF:txtShipmentPeriodSchedule"					: validateShipmentPeriodSchedule();break;
		        case "MF:txtPresentationDetails"					: validatePresentationDetails
				case "MF:chkWithinValidityofLC"						: validateWithinValidityofLC();break;
				case "MF:chkUsanceInterestToBeBorneByApplicant"		: validateUsanceInterestToBeBorneByApplicant();break;
									
				case "MF:txtDrawDowns"								: validateDrawDowns();break;
				
		        case "MF:txtConvRatetobasecurr"						: validateConvRatetobasecurr();break;
				case "MF:txtConvRateToLimitCurrency"				: validateConvRateToLimitCurrency();break;
		
		       	case "MF:Next"										: validateNext();break;
		       	
		       	//Changes P.Subramani-Chn-20/10/2008 Beg
		       	case "MF:txtmargincurr"				:	validateMarginCurrency();break;
	   			case "MF:txtmarginpercentage"		:	validateMarginPerc();break;
	   			case "MF:txtmarginpercentage1"		:	validateEOLMarginPerc();break;
	   			case "MF:txtmarginamt1"				:	validateMarginAmt();break;
	   			case "MF:txtmarginamt2"				:	validateEOLMarginAmt();break;
	   			case "MF:txtcashmarginamt1"			:	validateCashMargin();break;
	   			case "MF:txtcashmarginamt2"			:	validateEOLCashMargin();break;
	   			case "MF:lstmargintypeforLC"		:	validateMarginType();break;
	   			case "MF:LimitNext"					:  validateLimitNext(); break;
		       	//Changes P.Subramani-Chn-20/10/2008 End		       	

		       	//Changes P.Subramani-Chn-12/04/2008 Beg
	   			case "MF:txtusnchgsamt1"							: validateusnchgs();break;
	   			case "MF:txtcommchgsamt1"							: validatecommchgs();break;
	   			//Changes P.Subramani-Chn-12/04/2008 End
	   			
	   			//ADDED ON 16/10/2018 START
	   			case "MF:txtReceRef"			: validateReceRef();break;
	   			case "MF:txtDocCredit"			: validateDocCredit();break;
	   			case "MF:chkIssueBank"			: validatechkIssueBank();break;
	   			case "MF:lstIssueBICdtl"		: validatelstBicdtl(gid('MF:lstIssueBICdtl').value,"1");break;
	   			case "MF:txtIssueBicCode"		: validateBicCode(gid('MF:chkIssueBank').checked,gid('MF:lstIssueBICdtl').value,gid('MF:txtIssueBicCode').value,"1");break;
	   			case "MF:txtIssueBicBrn"		: validateBrnCode(gid('MF:chkIssueBank').checked,gid('MF:lstIssueBICdtl').value,gid('MF:txtIssueBicBrn').value,"1");break;
	   			case "MF:txtIssueAcnt"			: validateBankRout(gid('MF:chkIssueBank').checked,gid('MF:lstIssueBICdtl').value,gid('MF:txtIssueAcnt').value,"1");break;
	   			case "MF:txtIssueBankName"		: validateBankName(gid('MF:chkIssueBank').checked,gid('MF:lstIssueBICdtl').value,gid('MF:txtIssueBankName').value,"1");break;
	   			case "MF:txtIssueCntry"			: validateBankCntry(gid('MF:chkIssueBank').checked,gid('MF:lstIssueBICdtl').value,gid('MF:txtIssueCntry').value,"1");break;
	   			case "MF:txtDateOfIssue"		: validateDateOfIssue();break;
	   			case "MF:txtTakCharge"			: validateTakCharge();break;
	   			case "MF:txtPortLoad"			: validatetxtPortLoad();break;
	   			case "MF:txtPortDis"			: validatePortDis();break;
	   			case "MF:txtPortDest"			: validatePortDest();break;
	   			//ADDED ON 16/10/2018 END
	   			
	   		//ADDED BY PRASHANTH ON 07 FEB 2019	
	   		
	   		
	   		
			case "MF:chkChgDesc"								: checkChangeDesc();break;	
			case "MF:chkChgDoc"								    : checkChangeDoc();break;	
			case "MF:chkChgAddCond"								: checkChangeAddCond();break;										
	   		//ADDED BY PRASHANTH ON 07 FEB 2019	
	   		//NEW TAB ADDED BY PRASHANTH ON 20 FEB 2018
			case "MF:chkReqForCancel"								:checkChangeReqForCancel();break;	
			case "MF:chkChgAppl"								:checkChangeAppl();break;	
			case "MF:chkChgFormDc"								:checkChangeFormDoc();break;	
			case "MF:chkChgApplRules"								:checkChangeApplRules();break;	
			case "MF:chkChgAvlWith"								:checkChangeAvlWith();break;	
			case "MF:chkCgDrawee"								:checkChangeDrawee();break;	
			case "MF:chkChgReimbus"								:checkChangeReimbus();break;	
			case "MF:chkCgAdvBk"								:checkChangeAdvBk();break;	
			
			
			case "MF:lstAmdPayableBy"								:validateAmdPayBy();break;	
			case "MF:txtperiodOfPres"								:validatePeriod();break;	
			
			
			case "MF:lstcredit"										:validateFormOfDocCredit();break;	
			
		    case "MF:txtApplName"									:validateApplName();break;	
			
			case "MF:txtApplAddress"								:validateApplAddress();break;	
			
			case "MF:lstAppRule"								:validateApplRules();break;	
			case "MF:lstAvl"								   :validateAvlWith();break;	
			
		
				case "MF:lstAvlBICdtl"				:	validatelstBicdtl(gid('MF:lstAvlBICdtl').value,"2");break;
				case "MF:lstDrwBICdtl"				:	validatelstBicdtl(gid('MF:lstDrwBICdtl').value,"3");break;
				case "MF:lstReimbBank"				:	validatelstBicdtl(gid('MF:lstReimbBank').value,"4");break;
				case "MF:lstAdviseBank"				:	validatelstBicdtl(gid('MF:lstAdviseBank').value,"5");break;
				case "MF:lstReimbcfmBank"			:	validatelstBicdtl(gid('MF:lstReimbcfmBank').value,"6");break;		
				
				
					
	   			case "MF:txtAvlBicCode"				:	validateBicCode(true,gid('MF:lstAvlBICdtl').value,gid('MF:txtAvlBicCode').value,"2");break;
	   			case "MF:txtDrwBicCode"				:	validateBicCode(gid('MF:chkDrawee').checked,gid('MF:lstDrwBICdtl').value,gid('MF:txtDrwBicCode').value,"3");break;
	   			case "MF:txtReimBicCode"			:	validateBicCode(gid('MF:chkReimb').checked,gid('MF:lstReimbBank').value,gid('MF:txtReimBicCode').value,"4");break;
	   			case "MF:txtAdviseBicCode"			:	validateBicCode(gid('MF:chkAdvise').checked,gid('MF:lstAdviseBank').value,gid('MF:txtAdviseBicCode').value,"5");break;
	   			case "MF:txtReimcfmBicCode"			:	validateBicCode(true,gid('MF:lstReimbcfmBank').value,gid('MF:txtReimcfmBicCode').value,"6");break;
	   			
	   			case "MF:txtAvlBicBrn"				:	validateBrnCode(true,gid('MF:lstAvlBICdtl').value,gid('MF:txtAvlBicBrn').value,"2");break;
	   			case "MF:txtDrwBicBrn"				:	validateBrnCode(gid('MF:chkDrawee').checked,gid('MF:lstDrwBICdtl').value,gid('MF:txtDrwBicBrn').value,"3");break;
	   			case "MF:txtReimBicBrn"				:	validateBrnCode(gid('MF:chkReimb').checked,gid('MF:lstReimbBank').value,gid('MF:txtReimBicBrn').value,"4");break;
	   			case "MF:txtAdviseBicBrn"			:	validateBrnCode(gid('MF:chkAdvise').checked,gid('MF:lstAdviseBank').value,gid('MF:txtAdviseBicBrn').value,"5");break;
	   			case "MF:txtReimcfmBicBrn"			:	validateBrnCode(true,gid('MF:lstReimbcfmBank').value,gid('MF:txtReimcfmBicBrn').value,"6");break;
	   			
	   			case "MF:txtAvlBankName"			:	validateBankName(true,gid('MF:lstAvlBICdtl').value,gid('MF:txtAvlBankName').value,"2");break;
	   			case "MF:txtDrwBankName"			:	validateBankName(gid('MF:chkDrawee').checked,gid('MF:lstDrwBICdtl').value,gid('MF:txtDrwBankName').value,"3");break;
	   			case "MF:txtReimBankName"			:	validateBankName(gid('MF:chkReimb').checked,gid('MF:lstReimbBank').value,gid('MF:txtReimBankName').value,"4");break;
	   			case "MF:txtAdviseBankName"			:	validateBankName(gid('MF:chkAdvise').checked,gid('MF:lstAdviseBank').value,gid('MF:txtAdviseBankName').value,"5");break;
	   			case "MF:txtcfmReimBankName"		:	validateBankName(true,gid('MF:lstReimbcfmBank').value,gid('MF:txtcfmReimBankName').value,"6");break;
	   			
	   			case "MF:txtAvlCntry"				:	validateBankCntry(true,gid('MF:lstAvlBICdtl').value,gid('MF:txtAvlCntry').value,"2");break;
	   			case "MF:txtDrwCntry"				:	validateBankCntry(gid('MF:chkDrawee').checked,gid('MF:lstDrwBICdtl').value,gid('MF:txtDrwCntry').value,"3");break;
	   			case "MF:txtReimCntry"				:	validateBankCntry(gid('MF:chkReimb').checked,gid('MF:lstReimbBank').value,gid('MF:txtReimCntry').value,"4");break;
	   			case "MF:txtAdviseCntry"			:	validateBankCntry(gid('MF:chkAdvise').checked,gid('MF:lstAdviseBank').value,gid('MF:txtAdviseCntry').value,"6");break;
	   			case "MF:txtcfmReimCntry"			:	validateBankCntry(true,gid('MF:lstReimbcfmBank').value,gid('MF:txtcfmReimCntry').value,"7");break;
	   			
	   			case "MF:txtAvlAcnt"				:	validateBankRout(true,gid('MF:lstAvlBICdtl').value,gid('MF:txtAvlAcnt').value,"2");break;
	   			case "MF:txtDrwAcnt"				:	validateBankRout(gid('MF:chkDrawee').checked,gid('MF:lstDrwBICdtl').value,gid('MF:txtDrwAcnt').value,"3");break;
	   			case "MF:txtReimAcnt"				:	validateBankRout(gid('MF:chkReimb').checked,gid('MF:lstReimbBank').value,gid('MF:txtReimAcnt').value,"4");break;
	   			case "MF:txtAdviseAcnt"				:	validateBankRout(gid('MF:chkAdvise').checked,gid('MF:lstAdviseBank').value,gid('MF:txtAdviseAcnt').value,"6");break;
	   			case "MF:txtcfmReimAcnt"			:	validateBankRout(true,gid('MF:lstReimbcfmBank').value,gid('MF:txtcfmReimAcnt').value,"7");break;
	   			
						
			case "MF:txtfrmRange"	:validateFromRange();break;
			case "MF:uptoRange"		:validateUpToRange();break;
			
			case "MF:txtfrmRangeDoc"	:validateFromRangeDoc();break;
			case "MF:uptoRangeDoc"		:validateUpToRangeDoc();break;
			
			
			case "MF:txtfrmRangeAddl"	:validateFromRangeAddl();break;
			case "MF:uptoRangeAddl"		:validateUpToRangeAddl();break;
			
			
			case "MF:txtfrmRangeSplBene"	:validateFromRangeSplBene();break;
			case "MF:uptoRangeSplBene"		:validateUpToRangeSplBene();break;
			
			
			case "MF:txtfrmRangeSplRecev"	:validateFromRangeSplRecv();break;
			case "MF:uptoRangeSplRecev"		:validateUpToRangeSplRecv();break;
			
			
			
			case "MF:txtDraft" 		:	validateDraft();break;
			case "MF:txtMixedPaydtl" :   focusTextArea('MF:txtDeferPaydtl');break;
			
			//Changes Sanjay1 18-07-2019 End
			case "MF:lstparShip" :gid("MF:lsttranShip").focus();break;
			case "MF:lsttranShip" :if(gid('MF:chkChgReimbus').checked==true)
									{
									setTabfocus("maintab","tcontent10");
									setTabfocus("subtab","tsubcontent10");
									gid('MF:lstConfInst').focus();
												return;
									} 
									else if(gid('MF:chkCgAdvBk').checked==true)
									{
									setTabfocus("maintab","tcontent10");
									setTabfocus("subtab","tsubcontent11");
									gid('MF:chkAdvise').focus();
												return;
									}
									else{
									setTabfocus("maintab","tcontent10");
									setTabfocus("subtab","tsubcontent12");
									gid('MF:txtfrmRangeSplBene').focus();
												return;
									}break;
									
									
				case "MF:lstConfInst"			:	validateConfInst();break;
	   			//Changes Sanjay1 18-07-2019 Begin
	   			//case "MF:txtConfirmedByBank"			:			validateConfirmedByBank();break;	
		   		//case "MF:txtConfirmedBYBranch"		:			validateConfirmedByBranch();break;
		   		//case "MF:txtConfirmedBYBranchname"	:			validateConfirmedByBranchName();break;	
				//Changes Sanjay1 18-07-2019 End
				case "MF:chkDrawee"					:	validatecheckDrawee();break;		
				case "MF:chkReimb"					:	validatecheckReimb();break;
			
				case "MF:chkAdvise"					:	validatecheckAdvise();break;
				
				
				case "MF:txtApplInsOrReplSplBene"   :gid('MF:Focus4').focus();break;
				case "MF:txtApplInsOrReplSplRecev"  :gid('MF:Submit').focus();break;
			
	
				case "MF:lstamdChoice"  :gid('MF:txtApplInsOrRepl').focus();break;
				case "MF:txtApplInsOrReplSplRecev"  :gid('MF:Submit').focus();break;
				case "MF:lstamdChoice"  :gid('MF:txtApplInsOrRepl').focus();break;
				
				case "MF:txtApplInsOrRepl"  :
				 if(gid('MF:txtApplInsOrRepl').value=="")
		 			 {
						gid('MF:Focus1').focus();break;
					 }
					 else{
					 	gid('MF:Push1').focus();break;
					 }
				case "MF:lstamdChoiceDoc"  :gid('MF:txtApplInsOrReplDoc').focus();break;
				case "MF:txtApplInsOrReplDoc"  :
				if(gid('MF:txtApplInsOrReplDoc').value=="")
		 			 {
						gid('MF:Focus2').focus();break;
					 }
					 else{
					 	gid('MF:Push2').focus();break;
					 }
				
				case "MF:lstamdChoiceAddl"  :gid('MF:txtApplInsOrReplAddl').focus();break;
				case "MF:txtApplInsOrReplAddl" : 
				
					if(gid('MF:txtApplInsOrReplAddl').value=="")
		 			 {
						gid('MF:Focus3').focus();break;
					 }
					 else{
					 	gid('MF:Push3').focus();break;
					 }
					 
					 
					case "MF:lstamdChoiceSplBene" : gid('MF:txtApplInsOrReplSplBene').focus();break;
					case "MF:txtApplInsOrReplSplBene" : 
					if(gid('MF:txtApplInsOrReplSplBene').value=="")
		 			 {
						gid('MF:Focus4').focus();break;
					 }
					 else{
					 	gid('MF:Push4').focus();break;
					 }
					case "MF:lstamdChoiceSplRecev" : gid('MF:txtApplInsOrReplSplRecev').focus();break;
					case "MF:txtApplInsOrReplSplRecev" : 
					if(gid('MF:txtApplInsOrReplSplRecev').value=="")
		 			 {
						gid('MF:Focus5').focus();break;
					 }
					 else{
					 	gid('MF:Push5').focus();break;
					 }
					
					 
		   //NEW TAB ADDED BY PRASHANTH ON 20 FEB 2018	
	   			
			}	
     	}
     	
	    else if (fldobj.name == "MF:txtBranchCode")
	    {
		   	if(isNumeric(window.event.keyCode) == false)
		   	{
				setMsg(NUMBER_ALLOWED);
			}
		}
		else if(fldobj.name == "MF:txtReferenceYear")
		{
			if(isNumeric(window.event.keyCode) == false)
		   	{
				setMsg(NUMBER_ALLOWED);
		   	}
		}
		else if(fldobj.name =="MF:txtReferenceSl") 
		{
			if(isNumeric(window.event.keyCode) == false)
		   	{
	 			setMsg(NUMBER_ALLOWED);
		   	}
		}
	    else if(fldobj.name=="MF:txtAmendmentEntryDate")
		{
			seperatorappend(fldobj);
		}
		else if(fldobj.name=="MF:txtCustomerletterDate")
		{
			seperatorappend(fldobj);
		}
		else if(fldobj.name=="MF:txtLastDateforNegotiation")
		{
			seperatorappend(fldobj);
		}
		else if(fldobj.name=="MF:txtLatestDateofShipment")
		{
			seperatorappend(fldobj);
		}
		else if(fldobj.name =="MF:txtDrawDowns") 
		{
			if(isNumeric(window.event.keyCode) == false)
		   	{
				setMsg(NUMBER_ALLOWED);
		   	}
		}
		else if(fldobj.name=="MF:txtAdviceDate")
		{
			seperatorappend(fldobj);
		}					
		else if(fldobj.name=="MF:txtReferenceType"||fldobj.name =="MF:txtTermsofPrice"||fldobj.name =="MF:txtBeneficiaryCountryCode"||fldobj.name =="MF:txtBeneficiaryCode"||fldobj.name=="MF:txtmargincurr")
		{
		 	To_Uppercase(window.event.keyCode);
		}
		//ADDED ON 16/10/2018 START
		else if(fldobj.name=="MF:txtDateOfIssue")
		{
			seperatorappend(fldobj);
		}
		else if(fldobj.name =="MF:txtIssueBankName" || fldobj.name =="MF:txtIssueAddress" || fldobj.name =="MF:txtIssueCntry")   
		{
			To_Uppercase(window.event.keyCode,"true");
		}
		//ADDED ON 16/10/2018 END
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------					
	//common validations
	
	
	function validatecheckAdvise()
{
	checkAdvise();
	if(gid('MF:chkAdvise').checked==true)
		{
			gid('MF:lstAdviseBank').focus();
		}
		else
		{
					setTabfocus("subtab","tsubcontent12"); 
					focusTextArea('MF:txtApplInsOrReplSplBene');
		}

}

	
	
	function validateAppAddr()
	{
	 	validateBankAddr(gid('MF:chkAppBank').checked,gid('MF:lstBICdtl').value,gid('MF:txtAppAddress').value,"1");
	}
	function validateAvlAddr()
	{
	 	validateBankAddr(true,gid('MF:lstAvlBICdtl').value,gid('MF:txtAvlAddress').value,"2");
	}
	function validateDraweeAddr()
	{
	 	validateBankAddr(gid('MF:chkDrawee').checked,gid('MF:lstDrwBICdtl').value,gid('MF:txtDrwAddress').value,"3");
	}
	function validateReimbAddr()
	{
	 	validateBankAddr(gid('MF:chkReimb').checked,gid('MF:lstReimbBank').value,gid('MF:txtReimAddress').value,"4");
	}
	function validateAdvAddr()
	{
	 	validateBankAddr(gid('MF:chkAdvise').checked,gid('MF:lstAdviseBank').value,gid('MF:txtAdviseAddress').value,"5");
	}
	//Changes Sanjay1 18-07-2019 Begin
	function validateReimbcfmAddr()
	{
	 	validateBankAddr(true,gid('MF:lstReimbcfmBank').value,gid('MF:txtcfmReimAddress').value,"6");
	}
	//Changes Sanjay1 18-07-2019 End
	function validateBicCode(lstchk,banklst,bankBic,txtlst)
	{
			var checkBiclist = "0";
			if(lstchk == true)
				checkBiclist="1";
			else
				checkBiclist="0";
			
			objXMLApplet.clearMap();
		    objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
		    objXMLApplet.setValue("ValidateToken","true");
		    objXMLApplet.setValue("Method","Olc_ApplicantBicKeypress");
		    objXMLApplet.setValue("LC_CHKBOX_REQ",trim(checkBiclist));
		    objXMLApplet.setValue("LC_DROPDWN_TYPE",trim(banklst));
		    objXMLApplet.setValue("LC_BIC_CODE",trim(bankBic));
		    objXMLApplet.sendAndReceive();
		    if (objXMLApplet.getValue("ErrorMsg") != "")
			{
				setMsg(objXMLApplet.getValue("ErrorMsg"));
				setTabfocus("maintab","tcontent10");
			   
			   if(trim(txtlst) =="1")	
				{
					setTabfocus("subtab","tsubcontent1");
					gid('MF:txtIssueBicCode').focus();
				}
				
			    if(trim(txtlst) =="2")	
				{
					setTabfocus("subtab","tsubcontent8");
					gid('MF:txtAvlBicCode').focus();
				}
				else if(trim(txtlst) =="3")	
				{
					setTabfocus("subtab","tsubcontent9");
					gid('MF:txtDrwBicCode').focus();
				}
				else if(trim(txtlst) =="4")	
				{
					setTabfocus("subtab","tsubcontent10");
					gid('MF:txtReimBicCode').focus();
				}
				else if(trim(txtlst) =="5")	
				{
					setTabfocus("subtab","tsubcontent11");
					gid('MF:txtAdviseBicCode').focus();
				}			
				//Changes Sanjay1 18-07-2019 Begin
				else if(trim(txtlst) =="6")	
				{
					setTabfocus("subtab","tsubcontent10");
					gid('MF:txtReimcfmBicCode').focus();
				}	
				//Changes Sanjay1 18-07-2019 End
				return; 
				
		}
		else
		{
				setTabfocus("maintab","tcontent10");
				if(trim(txtlst) =="1")	
				{
					gid('MF:txtIssueBicBank').value=objXMLApplet.getValue("SWIFT_BIC_BANKNAME");
					setTabfocus("subtab","tsubcontent1");
					gid('MF:txtIssueBicBrn').focus();
				}
			    if(trim(txtlst) =="2")	
				{
					gid('MF:txtAvlBicBank').value=objXMLApplet.getValue("SWIFT_BIC_BANKNAME");
					
					setTabfocus("subtab","tsubcontent8");
					gid('MF:txtAvlBicBrn').focus();
				}
				else if(trim(txtlst) =="3")	
				{
					gid('MF:txtDrwBicBank').value=objXMLApplet.getValue("SWIFT_BIC_BANKNAME");
					
					setTabfocus("subtab","tsubcontent9");
					gid('MF:txtDrwBicBrn').focus();
				}
				else if(trim(txtlst) =="4")	
				{
					gid('MF:txtReimBicBank').value=objXMLApplet.getValue("SWIFT_BIC_BANKNAME");
					
					setTabfocus("subtab","tsubcontent10");
					gid('MF:txtReimBicBrn').focus();
				}
				else if(trim(txtlst) =="5")	
				{
					gid('MF:txtAdviseBicBank').value=objXMLApplet.getValue("SWIFT_BIC_BANKNAME");
					
					setTabfocus("subtab","tsubcontent11");
					gid('MF:txtAdviseBicBrn').focus();
				}			
				//Changes Sanjay1 18-07-2019 Begin
				else if(trim(txtlst) =="6")	
				{
					gid('MF:txtReimcfmBicBank').value=objXMLApplet.getValue("SWIFT_BIC_BANKNAME");
					
					setTabfocus("subtab","tsubcontent10");
					gid('MF:txtReimcfmBicBrn').focus();
				}	
				//Changes Sanjay1 18-07-2019 End
		}
	
	}
	
	function validateBrnCode(lstchk,banklst,bankBrn,txtlst)
	{
			var checkBiclist = "0";
			if(lstchk == true)
				checkBiclist="1";
			else
				checkBiclist="0";
			
			objXMLApplet.clearMap();
		    objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
		    objXMLApplet.setValue("ValidateToken","true");
		    objXMLApplet.setValue("Method","Olc_ApplicantBankBrachCodeKeypress");
		    objXMLApplet.setValue("LC_CHKBOX_REQ",trim(checkBiclist));
		    objXMLApplet.setValue("LC_DROPDWN_TYPE",trim(banklst));
		    objXMLApplet.setValue("LC_BRANCH_CODE",trim(bankBrn));
		    objXMLApplet.sendAndReceive();
		    if (objXMLApplet.getValue("ErrorMsg") != "")
			{
				setMsg(objXMLApplet.getValue("ErrorMsg"));
				setTabfocus("maintab","tcontent10");
				if(trim(txtlst) =="1")	
				{
					setTabfocus("subtab","tsubcontent1");
					gid('MF:txtIssueBicBrn').focus();
				}
			   if(trim(txtlst) =="2")	
				{
					setTabfocus("subtab","tsubcontent8");
					gid('MF:txtAvlBicBrn').focus();
				}
				else if(trim(txtlst) =="3")	
				{
					setTabfocus("subtab","tsubcontent9");
					gid('MF:txtDrwBicBrn').focus();
				}
				else if(trim(txtlst) =="4")	
				{
					setTabfocus("subtab","tsubcontent10");
					gid('MF:txtReimBicBrn').focus();
				}
				else if(trim(txtlst) =="5")	
				{
					setTabfocus("subtab","tsubcontent11");
					gid('MF:txtAdviseBicBrn').focus();
				}			
				//Changes Sanjay1 18-07-2019 Begin
				else if(trim(txtlst) =="6")	
				{
					setTabfocus("subtab","tsubcontent10");
					gid('MF:txtReimcfmBicBrn').focus();
				}
				//Changes Sanjay1 18-07-2019 End
				return; 
		}
		else
		{
				setTabfocus("maintab","tcontent10");
				
				if(trim(txtlst) =="1")	
				{
					setTabfocus("subtab","tsubcontent1");
					gid('MF:txtDateOfIssue').focus();
				}
			    if(trim(txtlst) =="2")	
				{
					setTabfocus("subtab","tsubcontent8");
					/*if(trim(gid('MF:lstAvl').value) =="2")
					{
						gid('MF:txtMixedPaydtl').readOnly=true;
						gid('MF:txtMixedPaydtl').value ="";
						gid('MF:txtDeferPaydtl').readOnly=false;
						//gid('MF:txtDeferPaydtl').focus();
					}
					else
					{
						gid('MF:txtDeferPaydtl').readOnly=true;
						gid('MF:txtDeferPaydtl').value="";
						gid('MF:txtMixedPaydtl').readOnly=false;
						//gid('MF:txtMixedPaydtl').focus();
					}*/
					focusTextArea('MF:txtDraft');
					
				}
				else if(trim(txtlst) =="3")	
				{
					setTabfocus("subtab","tsubcontent9");
					if(gid('MF:txtMixedPaydtl').readOnly==false)
						gid('MF:txtMixedPaydtl').focus();
					else if(gid('MF:txtDeferPaydtl').readOnly==false)
						gid('MF:txtDeferPaydtl').focus();
					else 
						gid('MF:lstparShip').focus();
				}
				else if(trim(txtlst) =="4")	
				{
					if(!checkOldValueReimbursement())
					{
					  setTabfocus("subtab","tsubcontent10");
						focusTextArea("MF:txtReimBicBrn");
					}
					else
					{
						setTabfocus("subtab","tsubcontent10");
						focusTextArea('MF:txtInstPay');
					}
				}
				else if(trim(txtlst) =="5")	
				{
					if(!checkOldValueAdvise())
					{
	   		      		setTabfocus("subtab","tsubcontent11");
						focusTextArea("MF:txtAdviseBicBrn");
					}
					else
					{
						setTabfocus("subtab","tsubcontent12");
						focusTextArea('MF:txtApplInsOrReplSplBene');
					}
				}			
				//Changes Sanjay1 18-07-2019 Begin
				else if(trim(txtlst) =="6")	
				{
					setTabfocus("subtab","tsubcontent10");
					focusTextArea('MF:chkReimb');
				}
				//Changes Sanjay1 18-07-2019 End
		}
	
	}
	
	
	function validateBankRout(lstchk,banklst,bankRout,txtlst)
	{
		var checkBiclist = "0";
			if(lstchk == true)
				checkBiclist="1";
			else
				checkBiclist="0";
			
			objXMLApplet.clearMap();
		    objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
		    objXMLApplet.setValue("ValidateToken","true");
		    objXMLApplet.setValue("Method","Olc_ApplicantAccountNumberKeypress");
		    objXMLApplet.setValue("LC_CHKBOX_REQ",trim(checkBiclist));
		    objXMLApplet.setValue("LC_DROPDWN_TYPE",trim(banklst));
		    objXMLApplet.setValue("LC_ROUNTING_ID",trim(bankRout));
		    objXMLApplet.sendAndReceive();
		    if (objXMLApplet.getValue("ErrorMsg") != "")
			{
				setMsg(objXMLApplet.getValue("ErrorMsg"));
				setTabfocus("maintab","tcontent10");
				if(trim(txtlst) =="1")	
				{
					setTabfocus("subtab","tsubcontent1");
					gid('MF:txtIssueAcnt').focus();
				}
				
			    if(trim(txtlst) =="2")	
				{
					setTabfocus("subtab","tsubcontent8");
					gid('MF:txtAvlAcnt').focus();
				}
				else if(trim(txtlst) =="3")	
				{
					setTabfocus("subtab","tsubcontent9");
					gid('MF:txtDrwAcnt').focus();
				}
				else if(trim(txtlst) =="4")	
				{
					setTabfocus("subtab","tsubcontent10");
					gid('MF:txtReimAcnt').focus();
				}
				else if(trim(txtlst) =="5")	
				{
					setTabfocus("subtab","tsubcontent13");
					focusTextArea('MF:txtApplInsOrReplSplBene');
				}
				
				else if(trim(txtlst) =="6")	
				{
					setTabfocus("subtab","tsubcontent11");
					focusTextArea('MF:txtAdviseBankName');
				}				
				//Changes Sanjay1 18-07-2019 Begin
				else if(trim(txtlst) =="7")	
				{
					setTabfocus("subtab","tsubcontent10");
					gid('MF:txtcfmReimAcnt').focus();
				}
				//Changes Sanjay1 18-07-2019 End
				return; 
		}
		else
		{
				setTabfocus("maintab","tcontent10");
				if(trim(txtlst) =="1")	
				{
					setTabfocus("subtab","tsubcontent1");
					focusTextArea('MF:txtIssueBankName');
				}
				
				 if(trim(txtlst) =="2")	
				{
					setTabfocus("subtab","tsubcontent8");
					focusTextArea('MF:txtAvlBankName');
				}
				else if(trim(txtlst) =="3")	
				{
					setTabfocus("subtab","tsubcontent9");
					focusTextArea('MF:txtDrwBankName');
				}
				else if(trim(txtlst) =="4")	
				{
					setTabfocus("subtab","tsubcontent10");
					focusTextArea('MF:txtReimBankName');
				}
				else if(trim(txtlst) =="5")	
				{
					setTabfocus("subtab","tsubcontent13");
					focusTextArea('MF:txtApplInsOrReplSplBene');
				}
				
				else if(trim(txtlst) =="6")	
				{
					setTabfocus("subtab","tsubcontent11");
					focusTextArea('MF:txtAdviseBankName');
				}			
				//Changes Sanjay1 18-07-2019 Begin
				else if(trim(txtlst) =="7")	
				{
					setTabfocus("subtab","tsubcontent10");
					focusTextArea('MF:txtcfmReimBankName');
				}
				//Changes Sanjay1 18-07-2019 End
		}
	
	}
	
	
	
	function FocusTab(value){
		if(value=="1")
		{
			if(!checkOldValueGoods()){
			  return false;
			}
			setTabfocus("subtab","tsubcontent5");
			setTabfocus("maintab","tcontent10");
			gid("MF:txtApplInsOrReplDoc").focus();
		}
		if(value=="2")
		{
			if(!checkOldValueDocs()){
			  return false;
			}			
			setTabfocus("maintab","tcontent10");
			setTabfocus("subtab","tsubcontent6");
			gid("MF:txtApplInsOrReplAddl").focus();
		}
		if(value=="3")
		{
		  //  setTabfocus("subtab","tsubcontent6"); //should change
		  //	gid("MF:txtApplInsOrReplAddl").focus();
		  
		  
		  
		  
		  if(!checkOldValueAddl()){
			  return false;
			}
			
		  if(gid('MF:chkChgFormDc').checked==true)
			{
			setTabfocus("maintab","tcontent10");
			setTabfocus("subtab","tsubcontent7");
			gid('MF:lstcredit').focus();
						return;
			}
			
			else if(gid('MF:chkChgAppl').checked==true)
			{
			setTabfocus("maintab","tcontent10");
			setTabfocus("subtab","tsubcontent7");
			gid('MF:txtApplName').focus();
						return;
			}
			
			
			else if(gid('MF:chkChgApplRules').checked==true)
			{
			setTabfocus("maintab","tcontent10");
			setTabfocus("subtab","tsubcontent7");
			gid('MF:lstAppRule').focus();
						return;
			}
			
			else if(gid('MF:chkChgAvlWith').checked==true)
			{
			setTabfocus("maintab","tcontent10");
			setTabfocus("subtab","tsubcontent8");
			gid('MF:lstAvl').focus();
						return;
			}
			
			else if(gid('MF:chkCgDrawee').checked==true)
			{
			setTabfocus("maintab","tcontent10");
			setTabfocus("subtab","tsubcontent9");
			gid('MF:chkDrawee').focus();
						return;
			}
			else if(gid('MF:chkChgReimbus').checked==true)
			{
			setTabfocus("maintab","tcontent10");
			setTabfocus("subtab","tsubcontent10");
			gid('MF:lstConfInst').focus();
						return;
			}
			else if(gid('MF:chkCgAdvBk').checked==true)
			{
			setTabfocus("maintab","tcontent10");
			setTabfocus("subtab","tsubcontent11");
			gid('MF:chkAdvise').focus();
						return;
			}
			else{
			setTabfocus("maintab","tcontent10");
			setTabfocus("subtab","tsubcontent12");
			gid('MF:txtfrmRangeSplBene').focus();
						return;
			}
		}
		if(value=="4")
		{
			setTabfocus("subtab","tsubcontent13");
			gid("MF:txtApplInsOrReplSplRecev").focus();
		}
	}
	
	
	function validateBankName(lstchk,banklst,bankName,txtlst)
	{
		var checkBiclist = "0";
			if(lstchk == true)
				checkBiclist="1";
			else
				checkBiclist="0";
			
			objXMLApplet.clearMap();
		    objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
		    objXMLApplet.setValue("ValidateToken","true");
		    objXMLApplet.setValue("Method","Olc_ApplicantBankNameKeypress");
		    objXMLApplet.setValue("LC_CHKBOX_REQ",trim(checkBiclist));
		    objXMLApplet.setValue("LC_DROPDWN_TYPE",trim(banklst));
		    objXMLApplet.setValue("LC_BANK_NAME",trim(bankName));
		    objXMLApplet.sendAndReceive();
		    if (objXMLApplet.getValue("ErrorMsg") != "")
			{
				setMsg(objXMLApplet.getValue("ErrorMsg"));
				setTabfocus("maintab","tcontent10");
				 if(trim(txtlst) =="2")	
				{
					setTabfocus("subtab","tsubcontent8");
					gid('MF:txtAvlBankName').focus();
				}
				else if(trim(txtlst) =="3")	
				{
					setTabfocus("subtab","tsubcontent9");
					gid('MF:txtDrwBankName').focus();
				}
				else if(trim(txtlst) =="4")	
				{
					setTabfocus("subtab","tsubcontent10");
					gid('MF:txtReimBankName').focus();
				}
				else if(trim(txtlst) =="5")	
				{
					setTabfocus("subtab","tsubcontent11");
					gid('MF:txtAdviseBankName').focus();
				}			
				//Changes Sanjay1 18-07-2019 Begin
				else if(trim(txtlst) =="6")	
				{
					setTabfocus("subtab","tsubcontent10");
					gid('MF:txtcfmReimBankName').focus();
				}
				//Changes Sanjay1 18-07-2019 End
				return; 
		}
		else
		{
				setTabfocus("maintab","tcontent10");
				if(trim(txtlst) =="1")	
				{
					setTabfocus("subtab","tsubcontent1");
					focusTextArea('MF:txtIssueAddress');
				}
				 if(trim(txtlst) =="2")	
				{
					setTabfocus("subtab","tsubcontent8");
					focusTextArea('MF:txtAvlAddress');
				}
				else if(trim(txtlst) =="3")	
				{
					setTabfocus("subtab","tsubcontent9");
					focusTextArea('MF:txtDrwAddress');
				}
				else if(trim(txtlst) =="4")	
				{
					setTabfocus("subtab","tsubcontent10");
					focusTextArea('MF:txtReimAddress');
				}
				else if(trim(txtlst) =="5")	
				{
					setTabfocus("subtab","tsubcontent11");
					focusTextArea('MF:txtAdviseAddress');
				}			
				//Changes Sanjay1 18-07-2019 Begin
				else if(trim(txtlst) =="6")	
				{
					setTabfocus("subtab","tsubcontent10");
					focusTextArea('MF:txtcfmReimAddress');
				}
				//Changes Sanjay1 18-07-2019 End
		}
	
	}
	
	
	function validateBankAddr(lstchk,banklst,bankAddr,txtlst)
	{
		var checkBiclist = "0";
			if(lstchk == true)
				checkBiclist="1";
			else
				checkBiclist="0";
			
			objXMLApplet.clearMap();
		    objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
		    objXMLApplet.setValue("ValidateToken","true");
		    objXMLApplet.setValue("Method","Olc_ApplicantBankAddressKeypress");
		    objXMLApplet.setValue("LC_CHKBOX_REQ",trim(checkBiclist));
		    objXMLApplet.setValue("LC_DROPDWN_TYPE",trim(banklst));
		    objXMLApplet.setValue("LC_BANK_ADDRESS",trim(bankAddr));
		    objXMLApplet.sendAndReceive();
		    if (objXMLApplet.getValue("ErrorMsg") != "")
			{
				setMsg(objXMLApplet.getValue("ErrorMsg"));
				setTabfocus("maintab","tcontent10");
				if(trim(txtlst) =="1")	
				{
					setTabfocus("subtab","tsubcontent1");
					gid('MF:txtIssueCntry').focus();
				}
				 if(trim(txtlst) =="2")	
				{
					setTabfocus("subtab","tsubcontent8");
					focusTextArea('MF:txtAvlAddress');
				}
				else if(trim(txtlst) =="3")	
				{
					setTabfocus("subtab","tsubcontent9");
					focusTextArea('MF:txtDrwAddress');
				}
				else if(trim(txtlst) =="4")	
				{
					setTabfocus("subtab","tsubcontent10");
					focusTextArea('MF:txtReimAddress');
				}
				else if(trim(txtlst) =="5")	
				{
					setTabfocus("subtab","tsubcontent11");
					focusTextArea('MF:txtAdviseAddress');
				}	
				//Changes Sanjay1 18-07-2019 Begin
				else if(trim(txtlst) =="6")	
				{
					setTabfocus("subtab","tsubcontent10");
					focusTextArea('MF:txtcfmReimAddress');
				}		
				//Changes Sanjay1 18-07-2019 End	
				return; 
		}
		else
		{
				setTabfocus("maintab","tcontent10");
				if(trim(txtlst) =="1")	
				{
					setTabfocus("subtab","tsubcontent1");
					gid('MF:txtIssueCntry').focus();
				}
				 if(trim(txtlst) =="2")	
				{
					setTabfocus("subtab","tsubcontent8");
					gid('MF:txtAvlCntry').focus();
				}
				else if(trim(txtlst) =="3")	
				{
					setTabfocus("subtab","tsubcontent9");
					gid('MF:txtDrwCntry').focus();
				}
				else if(trim(txtlst) =="4")	
				{
					setTabfocus("subtab","tsubcontent10");
					gid('MF:txtReimCntry').focus();
				}
				else if(trim(txtlst) =="5")	
				{
					setTabfocus("subtab","tsubcontent11");
					gid('MF:txtAdviseCntry').focus();
				}	
				//Changes Sanjay1 18-07-2019 Begin
				else if(trim(txtlst) =="6")	
				{
					setTabfocus("subtab","tsubcontent10");
					gid('MF:txtcfmReimCntry').focus();
				}			
				//Changes Sanjay1 18-07-2019 End
		}
	
	}
	
	function validateBankCntry(lstchk,banklst,bankCntry,txtlst)
	{
		var checkBiclist = "0";
			if(lstchk == true)
				checkBiclist="1";
			else
				checkBiclist="0";
			
			objXMLApplet.clearMap();
		    objXMLApplet.setValue("Package","panacea.OLCaction.eolcval");
		    objXMLApplet.setValue("ValidateToken","true");
		    objXMLApplet.setValue("Method","Olc_ApplicantBankCntryCodeKeypress");
		    objXMLApplet.setValue("LC_CHKBOX_REQ",trim(checkBiclist)); 
		    objXMLApplet.setValue("LC_DROPDWN_TYPE",trim(banklst));
		    objXMLApplet.setValue("LC_BANK_COUNTRY_CODE",trim(bankCntry));
		    objXMLApplet.setValue("LC_TYPE",trim(gid('MF:txtReferenceType').value));
		    objXMLApplet.sendAndReceive();
		    if (objXMLApplet.getValue("ErrorMsg") != "")
			{
				setMsg(objXMLApplet.getValue("ErrorMsg"));
				setTabfocus("maintab","tcontent10");
				if(trim(txtlst) =="1")	
				{
					setTabfocus("subtab","tsubcontent1");
					gid('MF:txtIssueCntry').focus();
				}
				 if(trim(txtlst) =="2")	
				{
					setTabfocus("subtab","tsubcontent8");
					gid('MF:txtAvlCntry').focus();
				}
				else if(trim(txtlst) =="3")	
				{
					setTabfocus("subtab","tsubcontent9");
					gid('MF:txtDrwCntry').focus();
				}
				else if(trim(txtlst) =="4")	
				{
					setTabfocus("subtab","tsubcontent10");
					gid('MF:txtReimCntry').focus();
				}
				else if(trim(txtlst) =="5")	
				{
					setTabfocus("subtab","tsubcontent11");
					gid('MF:txtAdviseCntry').focus();
				}
				else if(trim(txtlst) =="6")	
				{
					setTabfocus("subtab","tsubcontent11");
					gid('MF:txtAdviseCntry').focus();
				}			
				//Changes Sanjay1 18-07-2019 Begin
				else if(trim(txtlst) =="7")	
				{
					setTabfocus("subtab","tsubcontent10");
					gid('MF:txtcfmReimCntry').focus();
				}
				//Changes Sanjay1 18-07-2019 End
				return; 
		}
		else
		{
				setTabfocus("maintab","tcontent10");
				if(trim(txtlst) =="1")	
				{
					setTabfocus("subtab","tsubcontent1");
					gid('MF:txtDateOfIssue').focus();
				}
				
				 if(trim(txtlst) =="2")	
				{
					setTabfocus("subtab","tsubcontent8");
					/*if(trim(gid('MF:lstAvl').value) =="2")
					{
						gid('MF:txtMixedPaydtl').readOnly=true;
						gid('MF:txtMixedPaydtl').value ="";
						gid('MF:txtDeferPaydtl').readOnly=false;
						//gid('MF:txtDeferPaydtl').focus();
					}
					else
					{
						gid('MF:txtDeferPaydtl').readOnly=true;
						gid('MF:txtDeferPaydtl').value="";
						gid('MF:txtMixedPaydtl').readOnly=false;
						//gid('MF:txtMixedPaydtl').focus();
					}*/
					focusTextArea('MF:txtDraft');
				}
				else if(trim(txtlst) =="3")	
				{
					setTabfocus("subtab","tsubcontent9");
					if(gid('MF:txtMixedPaydtl').readOnly==false)
						gid('MF:txtMixedPaydtl').focus();
					else if(gid('MF:txtDeferPaydtl').readOnly==false)
						gid('MF:txtDeferPaydtl').focus();
					else
						gid('MF:lstparShip').focus();
					
				}
				else if(trim(txtlst) =="4")	
				{
					if(!checkOldValueReimbursement())
					{
			   			setTabfocus("subtab","tsubcontent10");
						focusTextArea("MF:txtReimCntry");
					}
					else
					{
						setTabfocus("subtab","tsubcontent10");
						focusTextArea('MF:txtInstPay');
					}
				}
				else if(trim(txtlst) =="5")	
				{
				
					setTabfocus("subtab","tsubcontent12");
					focusTextArea('MF:txtApplInsOrReplSplBene');
				}
				else if(trim(txtlst) =="6")	
				{
					if(!checkOldValueAdvise())
					{
			   			setTabfocus("subtab","tsubcontent11");
						focusTextArea("MF:txtAdviseCntry");
					}
					else
					{
						setTabfocus("subtab","tsubcontent12");
						focusTextArea('MF:txtApplInsOrReplSplBene');
					}
				}			
				//Changes Sanjay1 18-07-2019 Begin
				else if(trim(txtlst) =="7")	
				{
					setTabfocus("subtab","tsubcontent10");
					focusTextArea('MF:chkReimb');
				}
				//Changes Sanjay1 18-07-2019 End
		}
	
	}
	
	
//----------------------	
	
	function validateoption()
	{
    	if(gid('MF:seluseroption').value == "")
	   	{
	   		setMsg(OPTION_MESSAGE);
	    	gid('MF:seluseroption').focus();
	   	}
	   	else
	   	{	
	   		gid('MF:txtBranchCode').focus();
	   	}
	}		
//-------------------------------------------------------------------------------------------------------------------------------------------------------------		
	function validateBranchCode()
	{
		
    	if(gid("MF:txtBranchCode").value=="")
		{
			setMsg(BLANK_CHECK);
			gid("MF:txtBranchCode").focus();
			return;
		}
		else if(gid("MF:txtBranchCode").value==0)
		{
			setMsg(ZERO_CHECK);
			gid("MF:txtBranchCode").focus();
			return;
		}
		else
		{
			objXMLApplet.clearMap();
			objXMLApplet.setValue("Package","panacea.OLCaction.eolcamdval");
			objXMLApplet.setValue("Method","olcBrnCodekeypress");
            objXMLApplet.setValue("ValidateToken","true");
            objXMLApplet.setValue("OLC_BRN_CODE",trim(gid('MF:txtBranchCode').value));
           	objXMLApplet.sendAndReceive();
           	if(objXMLApplet.getValue("ErrorMsg") != "")
			{
				setMsg(objXMLApplet.getValue("ErrorMsg"));
				gid('MF:txtBranchCode').focus();
				return;  
			}
			else
			{
				gid('MF:txtReferenceType').focus();
			}				
		}
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			
	function validateReferenceType()
	{
    	if(gid("MF:txtReferenceType").value=="")
		{
			setMsg(BLANK_CHECK);
			gid("MF:txtReferenceType").focus();
			return;
		}
		else
		{
			objXMLApplet.clearMap();
			objXMLApplet.setValue("Package","panacea.OLCaction.eolcamdval");
			objXMLApplet.setValue("Method","olcLcTypekeypress");
	        objXMLApplet.setValue("ValidateToken", "true");
	        objXMLApplet.setValue("OLC_LC_TYPE",trim(gid('MF:txtReferenceType').value));
	       	objXMLApplet.sendAndReceive();
			if(objXMLApplet.getValue("ErrorMsg") != "")
			{
				setMsg(objXMLApplet.getValue("ErrorMsg"));
				gid('MF:txtReferenceType').focus();
				return;  
			}
			else
			{
				//ADDED ON 16/10/2018 START
				if(gid('MF:txtReferenceType').value=='LC')
				{
						disableTab("maintab","tcontent10");
						gid('MF:lbleolcamd13').innerText = 'Amendment Entry Date';
						gid('MF:lbleolcamd18').innerText = 'New Beneficiary Details';
						gid('MF:lbleolcamd23').innerText =	'L/C Enhancement /Reduction / No change';
						gid('MF:lbleolcamd26').innerText =	'Amended L/C Amount';
						gid('MF:lbleolcamd27').innerText =	'Deviation Allowed';
						gid('MF:lbleolcamd29').innerText =	'Amount Qualifier';
						gid('MF:lbleolcamd32').innerText =	'Last Date for Negotiation';
						gid('MF:lbleolcamd34').innerText =	'Latest Date of Shipment';
						gid('MF:lbleolcamd35').innerText =	'Shipment Period/Schedule';
						
						
						gid('MF:lbleolcamd137').innerText =	'Last Date for Negotiation';		
						gid('MF:lbleolcamd138').innerText =	'L/C Enhancement /Reduction / No change';
						gid('MF:lbleolcamd139').innerText =	'Deviation Allowed/Amount';
						gid('MF:lbleolcamd140').innerText =	'F44A to F44F';
						gid('MF:lbleolcamd141').innerText =	'Latest Date of Shipment and Period';
						gid('MF:lbleolcamd17').innerText =  'Change of Beneficiary';
						
						//gid('MF:chkExpiryDate').disabled=true;
						//gid('MF:chkIncDec').disabled=true;
						//gid('MF:chkPerTolr').disabled=true;
						
						gid('MF:chkPlacePort').disabled=true;
						//gid('MF:chkShipPeriod').disabled=true;
						//gid('MF:chkChangeofBeneficiary').disabled=false;
						//enableswiftbox();
				}
				else
				{
						enableTab("maintab","tcontent10");
						gid('MF:lbleolcamd13').innerText = 'F30 Amendment Date';
						gid('MF:lbleolcamd18').innerText = 'F59 New Beneficiary Details';
						gid('MF:lbleolcamd23').innerText =	'F32B/F32D Increase/Decrease Of DC';
						gid('MF:lbleolcamd26').innerText =	'F34B New Amount After Amendment';
						gid('MF:lbleolcamd27').innerText =	'F39A Percentage Of Tolerance';
						gid('MF:lbleolcamd29').innerText =	'F39B Max Credit Amount';
						gid('MF:lbleolcamd32').innerText =	'F31E Expiry Date';
						gid('MF:lbleolcamd34').innerText =	'F44C Latest Date of Shipment';
						gid('MF:lbleolcamd35').innerText =	'F44D Shipment Period';
						
						gid('MF:lbleolcamd137').innerText =	'F31E Expiry Date';		
						gid('MF:lbleolcamd138').innerText =	'F32B/F32DIncrease/Decrease Of DC';
						gid('MF:lbleolcamd139').innerText =	'F39A/F39B Percentage Tolerance/Max Credit Amount';
						gid('MF:lbleolcamd140').innerText =	'F44A to F44F';
						gid('MF:lbleolcamd141').innerText =	'F44D,F44C Last Date Of Shipment and Period';
						gid('MF:lbleolcamd17').innerText =  'F59 Change of Beneficiary';
						
						//gid('MF:chkExpiryDate').disabled=false;
						//gid('MF:chkIncDec').disabled=false;
						//gid('MF:chkPerTolr').disabled=false;
						
						gid('MF:chkPlacePort').disabled=false;
						//gid('MF:chkShipPeriod').disabled=false;
						//gid('MF:chkChangeofBeneficiary').disabled=false;
						//disableswiftbox();
				}
				
				//ADDED ON 16/10/2018 END
				
				_tenomen_auto_num=objXMLApplet.getValue("TNOMEN_AUTO_NUM");
				_tenomen_num_choice=objXMLApplet.getValue("TNOMEN_NUM_CHOICE");
				gid("MF:txtProductCode").value=objXMLApplet.getValue("PRODUCT_CODE");
				productCode=objXMLApplet.getValue("PRODUCT_CODE");
				gid("MF:outputProductCode").innerText=objXMLApplet.getValue("PRODUCT_DESC");
				productDesc=objXMLApplet.getValue("PRODUCT_DESC");
				if(_tenomen_num_choice=="C")
		 		{
		  			gid("MF:txtReferenceYear").value=currbusDate.substring(6,10);
		  			gid('MF:txtReferenceYear').focus();
		 		}
				else if(_tenomen_num_choice=="F")
				{
					objXMLApplet.clearMap();
					objXMLApplet.setValue("Package","panacea.OLCaction.eolcamdval");
					objXMLApplet.setValue("Method","getFinancialYear");
		            objXMLApplet.setValue("ValidateToken", "true");
		            objXMLApplet.setValue("CBD",currbusDate);
					objXMLApplet.sendAndReceive();
					gid("MF:txtReferenceYear").value=objXMLApplet.getValue("FINANCIAL_YEAR");
				    gid("MF:txtReferenceYear").focus();
		        }
			}				
		}
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			
	function validateReferenceYear()
	{
    	if(gid("MF:txtReferenceYear").value=="")
		{
			setMsg(BLANK_CHECK);
			gid("MF:txtReferenceYear").focus();
			return;
		}
		else if(gid("MF:txtReferenceYear").value==0)
		{
			setMsg(ZERO_CHECK);
			gid("MF:txtReferenceYear").focus();
			return;
		}
		else
		{ 
			if(validateYear())
			{
			   	objXMLApplet.clearMap();
				objXMLApplet.setValue("Package","panacea.OLCaction.eolcamdval");
				objXMLApplet.setValue("Method","olcLcYearkeypress");
		        objXMLApplet.setValue("ValidateToken", "true");
		        objXMLApplet.setValue("OLC_LC_YEAR",trim(gid('MF:txtReferenceYear').value));
		        objXMLApplet.setValue("TNOMEN_NUM_CHOICE",_tenomen_num_choice);
		        objXMLApplet.setValue("TNOMEN_AUTO_NUM",_tenomen_auto_num);
		        objXMLApplet.setValue("BRANCH_CODE",trim(gid('MF:txtBranchCode').value));
		        objXMLApplet.setValue("LC_TYPE",trim(gid('MF:txtReferenceType').value));
		        objXMLApplet.setValue("CBD",currbusDate);
		       	objXMLApplet.sendAndReceive();
				if(objXMLApplet.getValue("ErrorMsg") != "")
				{
					setMsg(objXMLApplet.getValue("ErrorMsg"));
					gid('MF:txtReferenceYear').focus();
					return;  
				}
				else
				{
					gid('MF:txtReferenceSl').focus();
				}	
			}
			else
			{
				setMsg("For Year should be greater than or equals to 1900");
				gid('MF:txtReferenceYear').focus();
				return;
			}
		}
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------		
	function  validateYear()
	{
		var year=gid("MF:txtReferenceYear").value;
		if(year>=1900)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------					
	function validateReferenceSl()
	{   
	
	//Added by prashanth on 28 march 2019
		 choiceSlforGrid1=1;
         choiceSlforGrid2=1;
         choiceSlforGrid3=1;
         choiceSlforGrid4=1;
         choiceSlforGrid5=1;
         gid('MF:amdlogtemp1').value="";
    	 gid('MF:amdlogtemp2').value="";
    	 gid('MF:amdlogtemp3').value="";
  	     gid('MF:amdlogtemp4').value="";
    	 gid('MF:amdlogtemp5').value="";
  	//Added by prashanth on 28 march 2019
        
    	if(gid("MF:txtReferenceSl").value=="")
		{
			setMsg(BLANK_CHECK);
			gid("MF:txtReferenceSl").focus();
			return;
		}
		else if(gid("MF:txtReferenceSl").value==0)
		{
			setMsg(ZERO_CHECK);
			gid("MF:txtReferenceSl").focus();
			return;
		}
		else
		{
			objXMLApplet.clearMap();
			objXMLApplet.setValue("Package","panacea.OLCaction.eolcamdval");
			objXMLApplet.setValue("Method","olcLcSlkeypress");
	        objXMLApplet.setValue("ValidateToken", "true");
	        objXMLApplet.setValue("BRANCH_CODE",trim(gid('MF:txtBranchCode').value));
	        objXMLApplet.setValue("OLC_LC_SL",trim(gid('MF:txtReferenceSl').value));
	        objXMLApplet.setValue("OLC_TYPE",trim(gid('MF:txtReferenceType').value));
	        objXMLApplet.setValue("OLC_YEAR",trim(gid('MF:txtReferenceYear').value));
	        objXMLApplet.setValue("OPTION",trim(gid('MF:seluseroption').value));
			objXMLApplet.sendAndReceive();
			if(objXMLApplet.getValue("ErrorMsg") != "")
			{
	  			setMsg(objXMLApplet.getValue("ErrorMsg"));
				gid('MF:txtReferenceSl').focus();
				return;  
			}
			else
			{ 
				setTabfocus("maintab","tcontent1");	
				gid("MF:txtAmendmentSerial").value=objXMLApplet.getValue("AMD_SERIAL");
				gid("MF:txtCorrespondentRefNumber").value=objXMLApplet.getValue("OLC_CORR_REF_NUM");
				gid("MF:txtLCDate").value=objXMLApplet.getValue("OLC_LC_DATE");
				gid("MF:txtCustomerNumber").value=objXMLApplet.getValue("OLC_CUST_NUM");
				//Changes P.Subramani-Chn-04/04/2008 Beg
				gid("MF:outputlblCustomerNumber").innerText=objXMLApplet.getValue("CLIENTS_NAME");
				var a=objXMLApplet.getValue("CLIENTS_ADDR1");
				var b=objXMLApplet.getValue("CLIENTS_ADDR2");
				var c=objXMLApplet.getValue("CLIENTS_ADDR3");
				var d=objXMLApplet.getValue("CLIENTS_ADDR4");
				var e=objXMLApplet.getValue("CLIENTS_ADDR5");
				gid("MF:txtAddress").value=a+"\r\n"+"" +b+"\r\n"+"" +c+"\r\n"+"" +d+"\r\n"+"" +e;
				gid("MF:txtLCIssuedThruBank").value=objXMLApplet.getValue("OLC_LC_ISS_BK_CODE");
				gid("MF:outputlblLCIssuedThruBank").innerText=objXMLApplet.getValue("BANKCD_NAME");
				gid("MF:txtLCIssuedThruBranch").value=objXMLApplet.getValue("OLC_LC_ISS_BRN_CODE");
				gid("MF:outputlblLCIssuedThruBranch").innerText=objXMLApplet.getValue("MBRN_NAME");
				gid("MF:txtLCIssuedPlace").value=objXMLApplet.getValue("OLC_LC_ISS_PLACE");
				gid("MF:txtLCIssuedCountry").value=objXMLApplet.getValue("OLC_LC_ISS_CNTRY");
				gid("MF:outputlblLCIssuedCountry").innerText=objXMLApplet.getValue("CNTRY_NAME");
				//Changes P.Subramani-Chn-04/04/2008 End
				gid("MF:txtLCAmount").value=objXMLApplet.getValue("OLC_LC_CURR_CODE");
				declength2="";
				declength2=objXMLApplet.getValue("DEC_LEN");
				gid("MF:txtLCAmount1").value=objXMLApplet.getValue("OLC_LC_AMOUNT");
				gid("MF:txtlcamounthidden").value=unFormat(objXMLApplet.getValue("OLC_LC_AMOUNT"))*1;
				setAmount('MF:txtLCAmount1',gid("MF:txtLCAmount1").value);
				gid("MF:txtLCBalance").value=objXMLApplet.getValue("OLC_LC_CURR_CODE");
				gid("MF:txtLCBalance1").value=objXMLApplet.getValue("OLC_LC_BALANCE");
				setAmount('MF:txtLCBalance1',gid("MF:txtLCBalance1").value);	
			
				if(objXMLApplet.getValue("LCPS_LIMIT_LINE_NUM")=="0")
				{
					gid("MF:txtLimitLineNumber").value=objXMLApplet.getValue("LCPS_LIMIT_LINE_NUM");
					gid("MF:txtLimitCurrency").value=baseCurrency;
					gid("MF:txtChangeinLCLiabAmountInLimitCurrency").value=baseCurrency;
				}
				else
				{
					gid("MF:txtLimitLineNumber").value=objXMLApplet.getValue("LCPS_LIMIT_LINE_NUM");	
					gid("MF:txtLimitCurrency").value=objXMLApplet.getValue("LCPS_LIM_CURR");	
					gid("MF:txtChangeinLCLiabAmountInLimitCurrency").value=objXMLApplet.getValue("LCPS_LIM_CURR");	
				}
				gid("MF:txtCustomerLCLiabilityAccount").value=objXMLApplet.getValue("LCPS_CUST_LIAB_ACC_NUM");	
				gid("MF:txtDeviationBalance").value=objXMLApplet.getValue("OLC_DEV_BAL");
				gid("MF:txtEnhancementReductionAmount").value=gid("MF:txtLCAmount").value;
				gid("MF:txttotalliabbasecurr").value=objXMLApplet.getValue("OLC_TOT_LIAB_BASE_CURR");		
				if(gid("MF:txtAmendmentSerial").value==1)
				{
					_total_liab_base_curr=objXMLApplet.getValue("OLC_TOT_LIAB_BASE_CURR");
				}
				gid("MF:txtLCAmountstring").value=gid("MF:txtLCAmount").value;
				gid("MF:txtPositiveDeviation").value=gid("MF:txtLCAmount").value;
				gid("MF:txtUsanceInterest").value=gid("MF:txtLCAmount").value;
				gid("MF:txtTotal").value=gid("MF:txtLCAmount").value;
				gid('MF:txtTotalTenorCurr').value=gid("MF:txtLCAmount").value;
				olcPositivDeviationAllow=objXMLApplet.getValue("OLC_POS_DEV_ALLWD");
				if(gid("MF:seluseroption").value=="A")
				{
			  		if(gid("MF:txtAmendmentSerial").value==1)
			   		{
			    		fetchfromOLC();
						fetchfromOLCTENORS();
			   		}
			   		else if(gid("MF:txtAmendmentSerial").value>1)
			   		{
			    		fetchfromOLCAMDADD();
						fetchfromOLCTENORSAMDADD();
						fetchfromOLCAMDDETAILS();//ADDED ON 16/10/2018
						
						
						//Added by Prashanth on 15 march 2019
						/*  gid('MF:chkExpiryDate').checked=false;
					      gid('MF:outlblExpiryDate').innerText="No";
					      gid('MF:chkIncDec').checked=false;
					      gid('MF:outlblIncDec').innerText="No";
					      gid('MF:chkPerTolr').checked=false;
					      gid('MF:outlblPerTolr').innerText="No";
					      gid('MF:chkPlacePort').checked=false;
					      gid('MF:outlblPlacePort').innerText="No";
					      gid('MF:chkShipPeriod').checked=false;
					      gid('MF:outlblShipPeriod').innerText="No";
						  gid('MF:chkChangeofBeneficiary').checked=false;
	    				  gid('MF:outlblChangeofBeneficiary').innerText="No";
	    				  gid('MF:chkChgDesc').checked=false;
					      gid('MF:outlblChgDesc').innerText="No";
					      gid('MF:chkChgDoc').checked=false;
					      gid('MF:outlblchkChgDoc').innerText="No";
					      gid('MF:chkChgAddCond').checked=false;
					      gid('MF:outlblChgAddCond').innerText="No";
					      
	      
					      gid('MF:chkReqForCancel').checked=false;
					      gid('MF:outlblchkReqForCancel').innerText="No";
					      gid('MF:chkChgAppl').checked=false;
					      gid('MF:outlblchkChgAppl').innerText="No";
	      
	      
					      gid('MF:chkChgFormDc').checked=false;
					      gid('MF:outlblchkChgFormDc').innerText="No";
	      
					      gid('MF:chkChgApplRules').checked=false;
					      gid('MF:outlblchkChgApplRules').innerText="No";
						
						  gid('MF:chkChgAvlWith').checked=false;
	     				  gid('MF:outlblchkChgAvlWith').innerText="No";
	      
					      gid('MF:chkCgDrawee').checked=false;
					      gid('MF:outlblchkCgDrawee').innerText="No";
					      
					      
					      gid('MF:chkChgReimbus').checked=false;
					      gid('MF:outlblchkChgReimbus').innerText="No";
					      
					      gid('MF:chkCgAdvBk').checked=false;
					      gid('MF:outlblchkCgAdvBk').innerText="No";*/
	      
						
						//Added by Prashanth on 15 march 2019
					}
					//ADDED ON 16/10/2018 START
					if(trim(gid('MF:txtBeneficiaryCode').value) != "" || trim(gid('MF:txtBeneficiaryName').value) != "")
		    		newbenef = "1"; 
					if(gid("MF:txtReferenceType").value=="OLC" && gid("MF:txtAmendmentSerial").value==1)
					{
					FetchlcDetails();
					}
					
					//InitializeTab();
					//ADDED ON 16/10/2018 END
				}
				else
				{
			  		prevamdsl=unFormat(gid("MF:txtAmendmentSerial").value)*1 - 1;
				    //Changes P.Subramani-Chn-07/04/2008 Beg
				  	if(prevamdsl>0)
				  	{
				  		fetchLCAMOUNT();
				  	}
				  	else
				  	{
				  		gid('MF:txtLCAmount2').value=objXMLApplet.getValue("OLC_LC_CURR_CODE");
			    		gid('MF:txtLCAmount21').value=objXMLApplet.getValue("OLC_LC_AMOUNT");
			    		setAmount('MF:txtLCAmount21',gid("MF:txtLCAmount21").value);
				  	}
				    //Changes P.Subramani-Chn-07/04/2008 End
				  
			   		//Following two methods are used to fetch previous lastdateofnegotiation and usancedays in modify mode
			   		//Changes P.Subramani-Chn-18/04/2008 Beg
			   		amdsl = unFormat(gid("MF:txtAmendmentSerial").value)*1;
			  
			   		if(amdsl==1)
			   		{
			   			fetchprevvalues1();  
			   		}
				   else
				   {
				  	 	amdsl=amdsl-1;
				  		fetchprevvalues2();
				   }
				   //Changes P.Subramani-Chn-18/04/2008 End
				   
				   fetchfromOLCAMD();
				   fetchfromOLCTENORSAMD();
				   
				   
				   
				   //Changes P.Subramani-Chn-28/07/2008 Beg
				   LcCompValue(row,col);
				   Liabcompdetails();
				   Limitdetails();
				   Liabdetails();
				   //Changes P.Subramani-Chn-28/07/2008 End
				   fetchfromOLCAMDDETAILS();//ADDED ON 16/10/2018
				}
				
				//Changes P.Subramani-Chn-22/10/2008 Beg
				   fetchfromOLCMAR();
				//Changes P.Subramani-Chn-22/10/2008 End
				
				//Changes P.Subramani-Chn-25/08/2008 Beg
   				//To Calculate Totalliabilitybeforeamd and its BaseCurrency Equivalent for the tenorwise
   				TotalValueBeforeAmd(row,col);
   				TotalValueBeforeAmdBaseCurrEqui(row,col);
   				//Changes P.Subramani-Chn-25/08/2008 End
   				
		 	}
			gid('MF:Next').focus();
		}	
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			 		
	//Changes P.Subramani-Chn-22/10/2008 Beg
	function fetchfromOLCMAR()
	{//Changes P.Subramani-Chn-07/11/08 
		objXMLApplet.clearMap();         			
		objXMLApplet.setValue("Package", "panaceaweb.utility");
		objXMLApplet.setValue("Package","panacea.OLCaction.eolcamdval");
		objXMLApplet.setValue("Method","olcmarkeypress");
	    objXMLApplet.setValue("ValidateToken", "true");
	    objXMLApplet.setValue("OLCM_BRN_CODE",trim(gid('MF:txtBranchCode').value));
        objXMLApplet.setValue("OLCM_LC_TYPE",trim(gid('MF:txtReferenceType').value));
        objXMLApplet.setValue("OLCM_LC_YEAR",trim(gid('MF:txtReferenceYear').value));
        objXMLApplet.setValue("OLCM_LC_SL",trim(gid('MF:txtReferenceSl').value));
        objXMLApplet.setValue("OLCM_AMD_SL",trim(gid('MF:txtAmendmentSerial').value));
        objXMLApplet.setValue("OPTION",trim(gid('MF:seluseroption').value));
		objXMLApplet.sendAndReceive();
		if(objXMLApplet.getValue("ErrorMsg") != "")
		{  
			setMsg(objXMLApplet.getValue("ErrorMsg"));
			gid('MF:txtReferenceSl').focus();
			return;         	
		}
		else
		{
		    gid("MF:txtmargincurr").value=objXMLApplet.getValue("OLCM_MARGIN_CURR");
		    if(objXMLApplet.getValue("OLCM_MARGIN_PERC")==0)
		    {
		    	gid("MF:txtmarginpercentage").value="";
		    }
		    else
		    {
		    	gid("MF:txtmarginpercentage").value=objXMLApplet.getValue("OLCM_MARGIN_PERC");
		    }
			if(objXMLApplet.getValue("OLCM_EX_OVER_LIMIT_MARGIN_PERC")==0)
		    {
		    	gid("MF:txtmarginpercentage1").value="";
		    }
		    else
		    {
		    	gid("MF:txtmarginpercentage1").value=objXMLApplet.getValue("OLCM_EX_OVER_LIMIT_MARGIN_PERC");
		    }
			if(objXMLApplet.getValue("OLCM_MARGIN_AMT")==0)
		    {
		    	gid("MF:txtmarginamt1").value="";
		    }
		    else
		    {
		    	gid("MF:txtmarginamt1").value=objXMLApplet.getValue("OLCM_MARGIN_AMT");
		    }
		    if(objXMLApplet.getValue("OLCM_EX_OVER_LIMIT_MARGIN_AMT")==0)
		    {
		    	gid("MF:txtmarginamt2").value="";
		    }
		    else
		    {
		    	gid("MF:txtmarginamt2").value=objXMLApplet.getValue("OLCM_EX_OVER_LIMIT_MARGIN_AMT");
		    }
		    if(objXMLApplet.getValue("OLCM_CASH_MARGIN_AMT")==0)
		    {
		    	gid("MF:txtcashmarginamt1").value="";
		    }
		    else
		    {
		    	gid("MF:txtcashmarginamt1").value=objXMLApplet.getValue("OLCM_CASH_MARGIN_AMT");
		    }
			if(objXMLApplet.getValue("OLCM_EOL_CASH_MARGIN_AMT")==0)
		    {
		    	gid("MF:txtcashmarginamt2").value="";
		    }
		    else
		    {
		    	gid("MF:txtcashmarginamt2").value=objXMLApplet.getValue("OLCM_EOL_CASH_MARGIN_AMT");
		    }
			gid('MF:lstmargintypeforLC').value=objXMLApplet.getValue("OLCM_MARGIN_TYPE");
			
			gid("MF:prevmarginamt").value = gid("MF:txtmarginamt1").value;
			gid("MF:prevexcmarginamt").value = gid("MF:txtmarginamt2").value;
			gid("MF:prevcashmarginamt").value = gid("MF:txtcashmarginamt1").value;
			gid("MF:prevexccashmarginamt").value = gid("MF:txtcashmarginamt2").value;
		}    
	}
	//Changes P.Subramani-Chn-22/10/2008 End
				   
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			 	
	//Changes P.Subramani-Chn-28/07/2008 Beg
	//Changes P.Subramani-Chn-20/08/2008 Beg
	function Liabcompdetails()
	{
			objXMLApplet.clearMap();
			objXMLApplet.setValue("Package","panacea.OLCaction.eolcamdval");
			objXMLApplet.setValue("Method","olcConvToBaseCurrkeypress");
		    objXMLApplet.setValue("ValidateToken", "true");
		    objXMLApplet.setValue("LC_CURR",trim(gid('MF:txtLCAmount2').value));
		    objXMLApplet.setValue("BASE_CURR",baseCurrency);
		    
		    //M.Murali - 16-05-2012  - Change - Beg
		    objXMLApplet.setValue("ENC_RED",gid("MF:txtLCEnhancementReductionNochange").value);		   
		     if(gid("MF:txtLCEnhancementReductionNochange").value=="E")
		     {		
		     //M.Murali - 16-05-2012  - Change - End
		    objXMLApplet.setValue("ADD_LC_LIAB_AMT",unFormat(gid('MF:txtAdditionalLCliabAmount1').value)*1);
		    //M.Murali - 16-05-2012  - Change - Beg
		    }
		    else if(gid("MF:txtLCEnhancementReductionNochange").value=="R")
		    {
		    objXMLApplet.setValue("RED_LC_LIAB_AMT",unFormat(gid('MF:txtReductionLCliabAmount1').value)*1);
		    }
		    //M.Murali - 16-05-2012  - Change - End
		    
		   // objXMLApplet.setValue("ADD_LC_LIAB_AMT",unFormat(gid('MF:txtAdditionalLCliabAmount1').value)*1);
		    objXMLApplet.setValue("CONV_RATE",unFormat(gid('MF:txtConvRatetobasecurr').value)*1);
		    objXMLApplet.setValue("TOTAL_AFT_AMD",unFormat(gid('MF:txtTotalAfterAmd').value)*1);
		    //Vinoth S Changes on 24-Dec-2010 Beg For Rounding Off Value
			objXMLApplet.setValue("TRAN_DATE",gid('MF:txtLcDate').value);
			objXMLApplet.setValue("TYPE","N");
 			//Vinoth S Changes on 24-Dec-2010 End
			objXMLApplet.sendAndReceive();
			gid('MF:txtTotalLcAmtinbaseCurrafteramendment1').value=objXMLApplet.getValue("AMT_AGNST_CURR2");
			decilength="";
			decilength=objXMLApplet.getValue("DEC_LEN");
	  		
	  		gid('MF:txtAdditionallcamtinBasecurr').value=baseCurrency;
			gid('MF:txtTotalLcAmtinbaseCurrafteramendment').value=baseCurrency;
			gid('MF:txtReductioninLCliabinBasecurr').value=baseCurrency;
	  		gid('MF:txtChangeinLCliabinBasecurrency').value=baseCurrency;
	  		
	  		var W_liab_before_amend = parseFloat(unFormat(gid('MF:txttotalliabbasecurr').value));
	  		var A  = unFormat(gid('MF:txtConvRatetobasecurr').value)*1;
	  		var T2 = unFormat(gid('MF:txtTotalAfterAmd').value)*1;
	  		var W_liab_after_amend = (parseFloat(A)) * (parseFloat(T2)); 
	  		// M.Murali - Changes - 15-05-2102 - Beg
	  		//var Tot_liab = W_liab_after_amend - W_liab_before_amend;
	  		var Tot_liab = objXMLApplet.getValue("AMT_AGNST_CURR1");
	  		// M.Murali - Changes - 15-05-2102 - End
	  		gid('MF:totalliablccurrency').value = T2;
	  		// M.Murali - Changes - 15-05-2102 - Beg
	  		//gid('MF:totalliabbasecurrency').value = W_liab_after_amend;
	  		gid('MF:totalliabbasecurrency').value = Tot_liab;
	  		// M.Murali - Changes - 15-05-2102 - End
	  				
	  		if(Tot_liab > 0)
	  		{
	  			//Changes P.Subramani-Chn-11/09/2008 Beg	  	
	  			if(gid("MF:txtLCEnhancementReductionNochange").value=="E")
	  			{		
	  			gid('MF:txtAdditionallcamtinBasecurr1').value=Tot_liab;
	  			//Changes P.Subramani-Chn-11/09/2008 End
	  			setAmount('MF:txtAdditionallcamtinBasecurr1',gid('MF:txtAdditionallcamtinBasecurr1').value);
	  			gid('MF:txtReductioninLCliabinBasecurr1').value=0;
	  			setAmount('MF:txtReductioninLCliabinBasecurr1',gid('MF:txtReductioninLCliabinBasecurr1').value);
	  			gid('MF:txtChangeinLCliabinBasecurrency1').value = gid('MF:txtAdditionallcamtinBasecurr1').value;
	  			}
	  		}
	  		else
	  		{
	  			gid('MF:txtAdditionallcamtinBasecurr1').value=0;
	  			setAmount('MF:txtAdditionallcamtinBasecurr1',gid('MF:txtAdditionallcamtinBasecurr1').value);
				//Changes P.Subramani-Chn-11/09/2008 Beg
	  			gid('MF:txtReductioninLCliabinBasecurr1').value=Tot_liab;
				//Changes P.Subramani-Chn-11/09/2008 End
	  			setAmount('MF:txtReductioninLCliabinBasecurr1',gid('MF:txtReductioninLCliabinBasecurr1').value);
	  			gid('MF:txtChangeinLCliabinBasecurrency1').value = gid('MF:txtReductioninLCliabinBasecurr1').value;
	  			gid("MF:txtExcOverlimitDueCurrTrancurrAmt").value=0;
	  		}
	  		
	  		gid('MF:txtProductCode').value=productCode;
			gid('MF:outputProductCode').innerText=productDesc; 
			Limitdetails();
	} 
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			 
	function Limitdetails()
	{
	    if(gid('MF:txtLimitCurrency').value==baseCurrency)
		{
			gid('MF:txtConvRateToLimitCurrency').value=1;
			setAmount('MF:txtConvRateToLimitCurrency',gid('MF:txtConvRateToLimitCurrency').value);	
			gid('MF:txtChangeinLCLiabAmountInLimitCurrency1').value=gid('MF:txtChangeinLCliabinBasecurrency1').value;
			setAmount('MF:txtChangeinLCLiabAmountInLimitCurrency1',gid('MF:txtChangeinLCLiabAmountInLimitCurrency1').value);	
			decilength1="";
			decilength1=2;
			Liabdetails();
			//this is case when convrate=1
		}
		else
		{
			ConvrateLimCurr();
			//this is the case when convrate!= 1
		}
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			
	function ConvrateLimCurr()
	{
			objXMLApplet.clearMap();
			objXMLApplet.setValue("Package","panacea.OLCaction.eolcamdval");
			objXMLApplet.setValue("Method","olcConvToBaseCurrkeypress");
		    objXMLApplet.setValue("ValidateToken", "true");
		    objXMLApplet.setValue("LC_CURR",trim(gid('MF:txtLCAmount2').value));
		    objXMLApplet.setValue("BASE_CURR",trim(gid('MF:txtChangeinLCliabinBasecurrency').value));
		    objXMLApplet.setValue("ADD_LC_LIAB_AMT",unFormat(gid('MF:txtChangeinLCliabinBasecurrency1').value)*1);
		    objXMLApplet.setValue("CONV_RATE",unFormat(gid('MF:txtConvRateToLimitCurrency').value)*1);
		    //Vinoth S Changes on 24-Dec-2010 Beg For Rounding Off Value
		    objXMLApplet.setValue("TOTAL_AFT_AMD",unFormat(gid('MF:txtTotalAfterAmd').value)*1);
			objXMLApplet.setValue("TRAN_DATE",gid('MF:txtLcDate').value);
			objXMLApplet.setValue("TYPE","N");
 			//Vinoth S Changes on 24-Dec-2010 End
			objXMLApplet.sendAndReceive();
			gid('MF:txtChangeinLCLiabAmountInLimitCurrency').value=gid('MF:txtLimitCurrency').value;
			gid('MF:txtChangeinLCLiabAmountInLimitCurrency1').value=objXMLApplet.getValue("AMT_AGNST_CURR");
		    // setAmount('MF:txtChangeinLCLiabAmountInLimitCurrency1',objXMLApplet.getValue("AMT_AGNST_CURR"));
		    //To get the hidden values At Liability Details
		    decilength1="";
		    decilength1=objXMLApplet.getValue("DEC_LEN");
		    setAmount('MF:txtChangeinLCLiabAmountInLimitCurrency1',objXMLApplet.getValue("AMT_AGNST_CURR"));
		    Liabdetails();
	}	    
//-------------------------------------------------------------------------------------------------------------------------------------------------------------		
	function Liabdetails()
	{
		objXMLApplet.clearMap();
		objXMLApplet.setValue("Package","panacea.OLCaction.eolcamdval");
		objXMLApplet.setValue("Method","olcsCustLiabAccNumkeypress");
		objXMLApplet.setValue("ValidateToken", "true");
		objXMLApplet.setValue("LCPS_BRN_CODE",trim(gid('MF:txtBranchCode').value));
		objXMLApplet.setValue("LCPS_CUST_LIAB_ACC_NUM",trim(gid('MF:txtCustomerLCLiabilityAccount').value));
		objXMLApplet.setValue("LCPS_CUST_NUM",unFormat(gid('MF:txtCustomerNumber').value)*1);
		objXMLApplet.setValue("LCPS_LC_CURR",gid('MF:txtLCAmount').value);
		objXMLApplet.setValue("LCPS_LC_AMT",unFormat(gid('MF:txtLCAmount1').value)*1);
		objXMLApplet.setValue("PRODUCT_CODE",gid('MF:txtProductCode').value);
		objXMLApplet.setValue("LIMIT_CURR",gid('MF:txtLimitCurrency').value);
		objXMLApplet.sendAndReceive();
		
		gid('MF:txtInternalAccountNum').value=objXMLApplet.getValue("INTERNAL_ACNT_NUM");
		gid('MF:txtFacilityLimit').value=objXMLApplet.getValue("SANC_CURR");
		setAmount('MF:txtFacilityLimit1',objXMLApplet.getValue("SANC_AMT"));
		gid('MF:txtOsbeforethisamendment').value=objXMLApplet.getValue("SANC_CURR");
		gid('MF:txtLCPendingToBeSanctioned').value=objXMLApplet.getValue("SANC_CURR");
			
		var outstd_amt;
		var outstd_amt1;
		outstd_amt = parseFloat(unFormat(objXMLApplet.getValue("OUTSTD_AMT")));
		//Changes P.Subramani-Chn-11/09/2008 Beg
		var  changelcliabamtlimtamt;
		changelcliabamtlimtamt=parseFloat(unFormat(gid("MF:txtChangeinLCLiabAmountInLimitCurrency1").value));
		//Changes P.Subramani-Chn-11/09/2008 End
		if(outstd_amt < 0)
		{
			outstd_amt1 = outstd_amt * (-1);
			//Changes P.Subramani-Chn-11/09/2008 Beg
			if(gid('MF:seluseroption').value=="A")
			{
				gid('MF:txtOsbeforethisamendment1').value=outstd_amt1;
			}
			else
			{
				if(outstd_amt1 > changelcliabamtlimtamt)
				{
					gid('MF:txtOsbeforethisamendment1').value=outstd_amt1-changelcliabamtlimtamt;
				}
				else
				{
					gid('MF:txtOsbeforethisamendment1').value=changelcliabamtlimtamt-outstd_amt1;
				}
			}	
			//Changes P.Subramani-Chn-11/09/2008 End
		}
		else
		{
			//Changes P.Subramani-Chn-10/09/2008 Beg
			if(gid('MF:seluseroption').value=="A")
			{
				gid('MF:txtOsbeforethisamendment1').value=outstd_amt;
			}
			else
			{
				if(outstd_amt > changelcliabamtlimtamt)
				{
					gid('MF:txtOsbeforethisamendment1').value=outstd_amt-changelcliabamtlimtamt;
				}
				else
				{
					gid('MF:txtOsbeforethisamendment1').value=changelcliabamtlimtamt-outstd_amt;
				}
			}	
			//Changes P.Subramani-Chn-10/09/2008 End
		}
		setAmount('MF:txtOsbeforethisamendment1',gid('MF:txtOsbeforethisamendment1').value);
		setAmount('MF:txtLCPendingToBeSanctioned1',objXMLApplet.getValue("TOT_LIAB_LIM_CURR"));
		gid('MF:txtLCliabafterthisamendment').value=objXMLApplet.getValue("SANC_CURR");
		
		//Changes P.Subramani-Chn-20/08/2008 Beg			
		gid('MF:txtLCliabafterthisamendment1').value=unFormat(gid('MF:txtOsbeforethisamendment1').value)*1+unFormat(gid('MF:txtLCPendingToBeSanctioned1').value)*1+unFormat(gid('MF:txtChangeinLCLiabAmountInLimitCurrency1').value)*1;
		//Changes P.Subramani-Chn-20/08/2008 End
			
		setAmount('MF:txtLCliabafterthisamendment1',gid('MF:txtLCliabafterthisamendment1').value);
		gid('MF:txtExcessOverLimit').value=objXMLApplet.getValue("SANC_CURR");
		gid("MF:txtExcOverlimitDueCurrTrancurr").value=objXMLApplet.getValue("SANC_CURR");
		gid("MF:txtExcessOverLimit1").value="";
		gid("MF:txtExcOverlimitDueCurrTrancurrAmt").value="";
		if( unFormat(gid('MF:txtLCliabafterthisamendment1').value)*1 > unFormat(gid('MF:txtFacilityLimit1').value)*1)
		{
			var _outstdaftlc1 = unFormat(trim(gid('MF:txtLCliabafterthisamendment1').value));
			var _faclmt = unFormat(trim(gid('MF:txtFacilityLimit1').value));
			var _excoverlmt = (_outstdaftlc1) - (_faclmt);
			gid('MF:txtExcessOverLimit1').value = _excoverlmt ;
			setAmount('MF:txtExcessOverLimit1',gid('MF:txtExcessOverLimit1').value);
		}
		if(!gid('MF:txtExcessOverLimit1').value=="")
		{
			if( unFormat(gid('MF:txtExcessOverLimit1').value)*1 < unFormat(gid('MF:txtChangeinLCLiabAmountInLimitCurrency1').value)*1 )
			{
				 gid('MF:txtExcOverlimitDueCurrTrancurrAmt').value = gid('MF:txtExcessOverLimit1').value;
				 setAmount('MF:txtExcOverlimitDueCurrTrancurrAmt',gid('MF:txtExcOverlimitDueCurrTrancurrAmt').value);
			}
			else if( unFormat(gid('MF:txtExcessOverLimit1').value)*1 > unFormat(gid('MF:txtChangeinLCLiabAmountInLimitCurrency1').value)*1 )
			{
				 gid('MF:txtExcOverlimitDueCurrTrancurrAmt').value = gid('MF:txtChangeinLCLiabAmountInLimitCurrency1').value;
				 setAmount('MF:txtExcOverlimitDueCurrTrancurrAmt',gid('MF:txtExcOverlimitDueCurrTrancurrAmt').value);
			}
		}
		setAmount('MF:txtExcessOverLimit1',gid('MF:txtExcessOverLimit1').value);
	}	
	//Changes P.Subramani-Chn-28/07/2008 End
//-------------------------------------------------------------------------------------------------------------------------------------------------------------		
	function fetchfromOLC() 
	{
		objXMLApplet.clearMap();
		objXMLApplet.setValue("Package","panacea.OLCaction.eolcamdval");
		objXMLApplet.setValue("Method","CaseOne");
        objXMLApplet.setValue("ValidateToken", "true");
        objXMLApplet.setValue("OLC_BRN_CODE",trim(gid('MF:txtBranchCode').value));
        objXMLApplet.setValue("OLC_LC_TYPE",trim(gid('MF:txtReferenceType').value));
        objXMLApplet.setValue("OLC_LC_YEAR",trim(gid('MF:txtReferenceYear').value));
        objXMLApplet.setValue("OLC_LC_SL",trim(gid('MF:txtReferenceSl').value));
        objXMLApplet.sendAndReceive();
		if(objXMLApplet.getValue("ErrorMsg") != "")
		{
			setMsg(objXMLApplet.getValue("ErrorMsg"));
			gid('MF:txtReferenceSl').focus();
			return;  
		}
		else
		{
		    gid('MF:txtBeneficiaryCode').value=objXMLApplet.getValue("OLC_BENEF_CODE");
		    oldBenCode=gid('MF:txtBeneficiaryCode').value;
		    
		    gid('MF:txtBeneficiaryName').value=objXMLApplet.getValue("OLC_BENEF_NAME");
		    gid('MF:txtBeneficiaryCountryCode').value=objXMLApplet.getValue("OLC_BENEF_CNTRY_CODE");
		    oldBenName=gid('MF:txtBeneficiaryName').value;
		    oldBenCountry=gid('MF:txtBeneficiaryCountryCode').value;
		    
		    
		    var a=objXMLApplet.getValue("OLC_BENEF_ADDR1");
		    var b=objXMLApplet.getValue("OLC_BENEF_ADDR2");
		    var c=objXMLApplet.getValue("OLC_BENEF_ADDR3");
		    var d=objXMLApplet.getValue("OLC_BENEF_ADDR4");
		    var e=objXMLApplet.getValue("OLC_BENEF_ADDR5");
		    gid('MF:txtAddress1').value=a+"\r\n"+"" +b+"\r\n"+"" +c+"\r\n"+"" +d+"\r\n"+"" +e;
		    
		    
		    oldBenAddress=gid('MF:txtAddress1').value;
		    
		    
		    gid('MF:txtLCAmount2').value=objXMLApplet.getValue("OLC_LC_CURR_CODE");
		    gid('MF:txtLCAmount21').value=objXMLApplet.getValue("OLC_LC_AMOUNT");
			setAmount('MF:txtLCAmount21',gid("MF:txtLCAmount21").value);
			gid('MF:txtDeviationAllowed').value=objXMLApplet.getValue("OLC_POS_DEV_ALLWD");
			gid('MF:txtDeviationAllowed1').value=objXMLApplet.getValue("OLC_NEG_DEV_ALLWD");
			
			
			oldDevAmt1=gid('MF:txtDeviationAllowed').value;
			oldDevAmt2=gid('MF:txtDeviationAllowed1').value;
			
			gid('MF:txtDeviationAmount').value=objXMLApplet.getValue("OLC_DEV_AMOUNT");
			//Changes P.Subramani-Chn-26/08/2008 BEg
			gid('MF:txtprevDeviationAmount').value=objXMLApplet.getValue("OLC_DEV_AMOUNT");
			//Changes P.Subramani-Chn-26/08/2008 End
			setAmount('MF:txtDeviationAmount',gid("MF:txtDeviationAmount").value);
			gid('MF:lstAmountQualifier').value=objXMLApplet.getValue("OLC_AMT_QUALFR");
			oldMaxCredAmt=gid('MF:lstAmountQualifier').value;
			
			gid('MF:txtTermsofPrice').value=objXMLApplet.getValue("OLC_PRICE_TERMS");
			//Changes P.Subramani-Chn-12/04/2008 Beg
			prevlastdatefornegotiation=objXMLApplet.getValue("OLC_LAST_DATE_OF_NEG");
			//Changes P.Subramani-Chn-12/04/2008 End
			gid('MF:txtLastDateforNegotiation').value=objXMLApplet.getValue("OLC_LAST_DATE_OF_NEG");
			
			oldValueExpiryDate=gid('MF:txtLastDateforNegotiation').value;
			
			gid('MF:txtPlaceofExpiry').value=objXMLApplet.getValue("OLC_PLACE_OF_EXPIRY");
			gid('MF:txtLatestDateofShipment').value=objXMLApplet.getValue("OLC_LATEST_DATE_OF_SHPMNT");
			
			oldLateDateShip=gid('MF:txtLatestDateofShipment').value;
			gid('MF:txtPresentationDetails').value= trim(objXMLApplet3.getValue("LC_PER_PRESENTATION_REMARKS"));
					
			if(objXMLApplet.getValue("OLC_WITHIN_VALIDATE_LC")=="1")
			{
				gid('MF:chkWithinValidityofLC').checked=true;
				gid('MF:outlblWithinValidityofLC').innerText="Yes";
			}
			else
			{
				gid('MF:chkWithinValidityofLC').checked=false;
				gid('MF:outlblWithinValidityofLC').innerText="No";
			}
			if(objXMLApplet.getValue("OLC_LC_UI_BORNE_BY_APPLCNT")=="1")
			{
				gid('MF:chkUsanceInterestToBeBorneByApplicant').checked=true;
				gid('MF:outlblUsanceInterestToBeBorneByApplicant').innerText="Yes";
			}
			else
			{
				gid('MF:chkUsanceInterestToBeBorneByApplicant').checked=false;
				gid('MF:outlblUsanceInterestToBeBorneByApplicant').innerText="No";
			}
			gid('MF:txtDrawDowns').value=objXMLApplet.getValue("OLC_NOF_TENORS");
			
			gid('MF:txtLCBeforeAmd').value=objXMLApplet.getValue("OLC_LC_AMOUNT");
			gid('MF:txtPositiveBeforeAmd').value=objXMLApplet.getValue("OLC_POS_DEV_ALLWD");
			gid('MF:txtAdditionalLCliabAmount1').value=objXMLApplet.getValue("OLC_TOT_LIAB_LC_CURR");
			//Changes P.Subramani-Chn-19/08/2008 Beg
			gid("MF:txttotalliabbasecurr").value=objXMLApplet.getValue("OLC_TOT_LIAB_BASE_CURR");
			//Changes P.Subramani-Chn-19/08/2008 End
			if(objXMLApplet.getValue("OLC_CONV_RATE_BASE_CURR")==0)
			{
			 	gid('MF:txtConvRatetobasecurr').value="";
			}
		    else
		    {	
				gid('MF:txtConvRatetobasecurr').value=objXMLApplet.getValue("OLC_CONV_RATE_BASE_CURR");
			}
			prevconvrate = objXMLApplet.getValue("OLC_CONV_RATE_BASE_CURR");
			if(objXMLApplet.getValue("OLC_CONV_RATE_LIM_CURR")==0)
			{
				gid('MF:txtConvRateToLimitCurrency').value="";
			}
			else
			{
				gid('MF:txtConvRateToLimitCurrency').value=objXMLApplet.getValue("OLC_CONV_RATE_LIM_CURR");
			}
			
			gid('MF:txtDateOfIssue').value=objXMLApplet.getValue("OLC_LC_PRESANC_DATE");//ADDED ON 16/10/2018
		}
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------		
	function fetchfromOLCTENORS()
	{
	 	objXMLApplet.clearMap();
		objXMLApplet.setValue("Package","panaceaweb.utility");
		objXMLApplet.setValue("SQLToken","valeolcamd1");						       				
		objXMLApplet.setValue("GridToken","FetchGridData");  
		Args=gid('MF:txtBranchCode').value+"|"+gid('MF:txtReferenceType').value+"|"+gid('MF:txtReferenceYear').value+"|"+gid('MF:txtReferenceSl').value;
		objXMLApplet.setValue("Args",Args);
		objXMLApplet.setValue("DataTypes","N|S|N|N");
		objXMLApplet.setValue("MTable","OLCTENORS");
		objXMLApplet.setValue("Primkey",Args);   
		objXMLApplet.sendAndReceive();
		if(objXMLApplet.getValue("ErrorMsg") != "")
	  	{
	  		setMsg(objXMLApplet.getValue("ErrorMsg"));
			gid('MF:txtReferenceSl').focus();
			return;  
		}
		if (objXMLApplet.getValue("Result") == "RowPresent") 
	    {
			gridEolcamd.clearAll();		
	    	if(gid("MF:txtAmendmentSerial").value==1)
			{
				//Changes P.Subramani-Chn-23/08/2008 Beg
				gridEolcamd.setxmlcolumn("0,1,0,1,0,0,1,1,1,1,0,1,0,1,0,0,1,1,1,1,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0");
				//Changes P.Subramani-Chn-23/08/2008 End
			}
			else 
			{
	    		gridEolcamd.setxmlcolumn("0,1,0,1,0,1,1,1,1,1,0,1,0,1,0,1,1"); 
	    	}
	    	gridEolcamd.loadXMLString(objXMLApplet.getValue("GetGridData"));
		}	
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			
	//In modify mode, we need to specify the amendedLCamt of previousamdsl in LCamount amount field in Amount I tab.
	//Changes P.Subramani-Chn-07/04/2008 Beg
	function fetchLCAMOUNT()
	{
		objXMLApplet.clearMap();         			
		objXMLApplet.setValue("Package","panaceaweb.utility");
		objXMLApplet.setValue("SQLToken","valeolcamd2");
		Args = gid('MF:txtBranchCode').value+"|"+gid('MF:txtReferenceType').value+"|"+gid('MF:txtReferenceYear').value+"|"+gid("MF:txtReferenceSl").value+"|"+prevamdsl;
		objXMLApplet.setValue("Args",Args);
		objXMLApplet.setValue("DataTypes","N|S|N|N|N");     
		objXMLApplet.sendAndReceive();	         
		if(objXMLApplet.getValue("ErrorMsg") != "")
		{  
			clearNonKeyFields();
			setMsg(objXMLApplet.getValue("ErrorMsg"));
			gid('MF:txtReferenceSl').focus();
			return;         	
		}
		else
		{
		    gid('MF:txtLCAmount2').value=objXMLApplet.getValue("OLCA_LC_CURR_CODE");
		    gid('MF:txtLCAmount21').value=objXMLApplet.getValue("OLCA_AMENDED_AMT");
		    setAmount('MF:txtLCAmount21',gid("MF:txtLCAmount21").value);
		    //Changes P.Subramani-19/08/2008 BEg
			gid("MF:txttotalliabbasecurr").value=objXMLApplet.getValue("OLCA_TOT_LIAB_BASE_CURR");
			//Changes P.Subramani-19/08/2008 End
		}
	}
	//Changes P.Subramani-Chn-07/04/2008 End
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			
	//Changes P.Subramani-Chn-18/04/2008 Beg
	function fetchprevvalues1()
	{
		objXMLApplet.clearMap();
		objXMLApplet.setValue("Package","panacea.OLCaction.eolcamdval");
		objXMLApplet.setValue("Method","CaseOne");
        objXMLApplet.setValue("ValidateToken", "true");
        objXMLApplet.setValue("OLC_BRN_CODE",trim(gid('MF:txtBranchCode').value));
        objXMLApplet.setValue("OLC_LC_TYPE",trim(gid('MF:txtReferenceType').value));
        objXMLApplet.setValue("OLC_LC_YEAR",trim(gid('MF:txtReferenceYear').value));
        objXMLApplet.setValue("OLC_LC_SL",trim(gid('MF:txtReferenceSl').value));
        objXMLApplet.sendAndReceive();
		if(objXMLApplet.getValue("ErrorMsg") != "")
		{
			setMsg(objXMLApplet.getValue("ErrorMsg"));
			gid('MF:txtReferenceSl').focus();
			return;  
		}
		else
		{
		    prevlastdatefornegotiation=objXMLApplet.getValue("OLC_LAST_DATE_OF_NEG");
		    //Changes P.Subramani-Chn-27/08/2008
		    prevposdevallwd=objXMLApplet.getValue("OLC_POS_DEV_ALLWD");
		}
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			
	function fetchprevvalues2()
	{
		objXMLApplet.clearMap();         			
		objXMLApplet.setValue("Package", "panaceaweb.utility");
		objXMLApplet.setValue("SQLToken","valeolcamd4");
		Args = gid('MF:txtBranchCode').value+"|"+gid('MF:txtReferenceType').value+"|"+gid('MF:txtReferenceYear').value+"|"+gid("MF:txtReferenceSl").value+"|"+amdsl;
		objXMLApplet.setValue ("Args",Args);
		objXMLApplet.setValue("DataTypes","N|S|N|N|N");     
		objXMLApplet.sendAndReceive();	         
		if(objXMLApplet.getValue("ErrorMsg") != "")
		{  
			setMsg(objXMLApplet.getValue("ErrorMsg"));
			gid('MF:txtReferenceSl').focus();
			return;         	
		}
		else
		{
		    prevlastdatefornegotiation=objXMLApplet.getValue("OLCA_LAST_DATE_OF_NEG");
		    //Changes P.Subramani-Chn-12/04/2008 Beg
			if(unFormat(objXMLApplet.getValue("OLCA_ADD_LIAB_BASE_CURR"))*1 > 0)
			{
				_total_liab_base_curr=objXMLApplet.getValue("OLCA_ADD_LIAB_BASE_CURR");
			}
			//Changes P.Subramani-Chn-27/08/2008 
			prevposdevallwd=objXMLApplet.getValue("OLCA_POS_DEV_ALLWD");
		}
	}
	//Changes P.Subramani-Chn-18/04/2008 End
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			
	function fetchprevolcdays1()
	{
		//Changes P.Subramani-Chn-23/08/2008 Beg	    
	    objXMLApplet.clearMap();
		objXMLApplet.setValue("Package","panaceaweb.utility");
		objXMLApplet.setValue("SQLToken","valeolcamd8");
		//objXMLApplet.setValue("GridToken","FetchGridData");						       				
		Args=gid('MF:txtBranchCode').value+"|"+gid('MF:txtReferenceType').value+"|"+gid('MF:txtReferenceYear').value+"|"+gid('MF:txtReferenceSl').value+"|"+TenorSerial;
		objXMLApplet.setValue("Args",Args);
		objXMLApplet.setValue("DataTypes","N|S|N|N|N");
		objXMLApplet.setValue("MTable","OLCTENORS");
		objXMLApplet.setValue("Primkey",Args);   
		objXMLApplet.sendAndReceive();
		if(objXMLApplet.getValue("ErrorMsg") != "")
	  	{
	  		setMsg(objXMLApplet.getValue("ErrorMsg"));
			gid('MF:txtReferenceSl').focus();
			return;  
		}
		else
	    {
	    	prev_olc_days=objXMLApplet.getValue("PREV_OLC_DAYS");
		}
		//Changes P.Subramani-Chn-23/08/2008 End	
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			
	function fetchprevolcdays2()
	{
		//Changes P.Subramani-Chn-23/08/2008 Beg	
		objXMLApplet.clearMap();
		objXMLApplet.setValue("Package","panaceaweb.utility");
		objXMLApplet.setValue("SQLToken","valeolcamd9");
		//objXMLApplet.setValue("GridToken","FetchGridData");
		Args=gid('MF:txtBranchCode').value+"|"+gid('MF:txtReferenceType').value+"|"+gid('MF:txtReferenceYear').value+"|"+gid('MF:txtReferenceSl').value+"|"+amdsl+"|"+TenorSerial;
		objXMLApplet.setValue("Args",Args);
		objXMLApplet.setValue("DataTypes","N|S|N|N|N|N");
		objXMLApplet.setValue("Primkey",Args);   
		objXMLApplet.sendAndReceive();
		if(objXMLApplet.getValue("ErrorMsg")!= "")
	  	{
	  		setMsg(objXMLApplet.getValue("ErrorMsg"));
			gid('MF:txtReferenceSl').focus();
			return;  
		}
		else
	    {
			prev_olc_days=objXMLApplet.getValue("PREV_OLC_DAYS");
		}//Changes P.Subramani-Chn-23/08/2008 End	
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			
	function fetchfromOLCAMD()
	{
		objXMLApplet.clearMap();         			
		objXMLApplet.setValue("Package", "panaceaweb.utility");
		objXMLApplet.setValue("SQLToken","valeolcamd4");
		Args = gid('MF:txtBranchCode').value+"|"+gid('MF:txtReferenceType').value+"|"+gid('MF:txtReferenceYear').value+"|"+gid("MF:txtReferenceSl").value+"|"+gid("MF:txtAmendmentSerial").value;
		objXMLApplet.setValue ("Args",Args);
		objXMLApplet.setValue("DataTypes","N|S|N|N|N");     
		objXMLApplet.sendAndReceive();	         
		if(objXMLApplet.getValue("ErrorMsg") != "")
		{  
			//clearNonKeyFields();
			setMsg(objXMLApplet.getValue("ErrorMsg"));
			gid('MF:txtReferenceSl').focus();
			return;         	
		}
		else
		{
		
				// NEW FIELDS ADDED BY PRASHANTH ON 09 FEB 2019
				
				 clearGoodsTab();
		  		 clearDocumentsTab();
		  		 clearAdditionalDetailsTab();
		   		clearSplBenficieryDetailsTab();
		   		clearSplRecvBkDetailsTab();
		   		
		   	 gid('MF:amdGoodsValue').value="";
    	     gid('MF:amdDocsValue').value="";
    	     gid('MF:amdAddlValue').value="";
    	     gid('MF:amdSpl1Value').value="";
    	     gid('MF:amdSpl2Value').value="";
    	     
    	     
			 if(objXMLApplet.getValue("OLCA_CHG_IN_DESC_GOODS")=="1")
		    {
			    gid('MF:chkChgDesc').checked=true;
			    gid('MF:outlblChgDesc').innerText="Yes";
		    }
		    else
		    {
			    gid('MF:chkChgDesc').checked=false;
			    gid('MF:outlblChgDesc').innerText="No";
		    }
		    
		    	 //added by prashanth on 23 feb 2019
			    loadLogInModify("45B");
			    LoadCompleteDetailInModify("45B");
			    loadAmdChoiceMod("45B");
			    //added by prashanth on 23 feb 2019
			    
			    
		     if(objXMLApplet.getValue("OLCA_CHG_IN_DOC")=="1")
		    {
			    gid('MF:chkChgDoc').checked=true;
			    gid('MF:outlblchkChgDoc').innerText="Yes";
		    }
		    else
		    {
			    gid('MF:chkChgDoc').checked=false;
			    gid('MF:outlblchkChgDoc').innerText="No";
		    }
		    
		     	loadLogInModify("46B");
			    LoadCompleteDetailInModify("46B");
			    loadAmdChoiceMod("46B");
			    
			    
		     if(objXMLApplet.getValue("OLCA_CHG_IN_ADDL_COND")=="1")
		    {
			    gid('MF:chkChgAddCond').checked=true;
			    gid('MF:outlblChgAddCond').innerText="Yes";
		    }
		    else
		    {
			    gid('MF:chkChgAddCond').checked=false;
			    gid('MF:outlblChgAddCond').innerText="No";
		    }
		    	loadLogInModify("47B");
			    LoadCompleteDetailInModify("47B");
			    loadAmdChoiceMod("47B");
		    
		    gid('MF:amdSpl1Value').value="";
    	    gid('MF:amdSpl2Value').value="";
    	 
    	     
    	     
    	     
		    
		    loadLogInModify("49M");
			LoadCompleteDetailInModify("49M");
			loadAmdChoiceMod("49M");
			
			
			
			loadLogInModify("49N");
			LoadCompleteDetailInModify("49N");
		    loadAmdChoiceMod("49N");
			
			
			
		     if(objXMLApplet.getValue("OLCA_REQ_FOR_CANCEL")=="1")
		    {
			    gid('MF:chkReqForCancel').checked=true;
			    gid('MF:outlblchkReqForCancel').innerText="Yes";
		    }
		    else
		    {
			    gid('MF:chkReqForCancel').checked=false;
			    gid('MF:outlblchkReqForCancel').innerText="No";
		    }
		    
		    
		    
		     if(objXMLApplet.getValue("OLCA_CHG_OF_APPL")=="1")
		    {
			    gid('MF:chkChgAppl').checked=true;
			    gid('MF:outlblchkChgAppl').innerText="Yes";
		    }
		    else
		    {
			    gid('MF:chkChgAppl').checked=false;
			    gid('MF:outlblchkChgAppl').innerText="No";
		    }
		    
		    
		    
		     if(objXMLApplet.getValue("OLCA_CHG_IN_AVL_WITH")=="1")
		    {
			    gid('MF:chkChgAvlWith').checked=true;
			    gid('MF:outlblchkChgAvlWith').innerText="Yes";
		    }
		    else
		    {
			    gid('MF:chkChgAvlWith').checked=false;
			    gid('MF:outlblchkChgAvlWith').innerText="No";
		    }
		    
		    
		     if(objXMLApplet.getValue("OLCA_CHG_IN_DRAWEE_PAY")=="1")
		    {
			    gid('MF:chkCgDrawee').checked=true;
			    gid('MF:outlblchkCgDrawee').innerText="Yes";
		    }
		    else
		    {
			    gid('MF:chkCgDrawee').checked=false;
			    gid('MF:outlblchkCgDrawee').innerText="No";
		    }
		    
		    
		    
		    if(objXMLApplet.getValue("OLCA_CHG_IN_REIMB")=="1")
		    {
			    gid('MF:chkChgReimbus').checked=true;
			    gid('MF:outlblchkChgReimbus').innerText="Yes";
		    }
		    else
		    {
			    gid('MF:chkChgReimbus').checked=false;
			    gid('MF:outlblchkChgReimbus').innerText="No";
		    }
		    
		    
		    
		    
		    
		    if(objXMLApplet.getValue("OLCA_CHG_IN_ADV_BK")=="1")
		    {
			    gid('MF:chkCgAdvBk').checked=true;
			    gid('MF:outlblchkCgAdvBk').innerText="Yes";
		    }
		    else
		    {
			    gid('MF:chkCgAdvBk').checked=false;
			    gid('MF:outlblchkCgAdvBk').innerText="No";
		    }
		    
		    if(objXMLApplet.getValue("OLCA_CHG_IN_FORM_OF_DC")=="1")
		    {
			    gid('MF:chkChgFormDc').checked=true;
			    gid('MF:outlblchkChgFormDc').innerText="Yes";
		    }
		    else
		    {
			    gid('MF:chkChgFormDc').checked=false;
			    gid('MF:outlblchkChgFormDc').innerText="No";
		    }
		    
		     if(objXMLApplet.getValue("OLCA_CHG_IN_APPL_RULES")=="1")
		    {
			    gid('MF:chkChgApplRules').checked=true;
			    gid('MF:outlblchkChgApplRules').innerText="Yes";
		    }
		    else
		    {
			    gid('MF:chkChgApplRules').checked=false;
			    gid('MF:outlblchkChgApplRules').innerText="No";
		    }
				// NEW FIELDS ADDED BY PRASHANTH ON 09 FEB 2019
		
		    gid('MF:txtAmendmentEntryDate').value=objXMLApplet.getValue("OLCA_ENTRY_DATE");
		    gid('MF:txtolcaentrydate').value=gid('MF:txtAmendmentEntryDate').value;
		    gid('MF:txtCustomerletterNumber').value=objXMLApplet.getValue("OLCA_CUST_LETTER_NUM");
		    gid('MF:txtCustomerletterDate').value=objXMLApplet.getValue("OLCA_CUST_LTR_DATE");
		    //gid('MF:txtReasonForAmendment').value=objXMLApplet.getValue("OLCA_RSN_FOR_AMD");//COMMENTED ON 16/10/2018
		    if(objXMLApplet.getValue("OLCA_CHANGE_OF_BENEF")=="1")
		    {
			    gid('MF:chkChangeofBeneficiary').checked=true;
			    gid('MF:outlblChangeofBeneficiary').innerText="Yes";
		    }
		    else
		    {
			    gid('MF:chkChangeofBeneficiary').checked=false;
			    gid('MF:outlblChangeofBeneficiary').innerText="No";
		    }
		    gid('MF:txtBeneficiaryCode').value=objXMLApplet.getValue("OLCA_BENEF_CODE");
		    gid('MF:txtBeneficiaryName').value=objXMLApplet.getValue("OLCA_BENEF_NAME");
		    gid('MF:txtBeneficiaryCountryCode').value=objXMLApplet.getValue("OLCA_BENEF_CNTRY_CODE");
		    var a=objXMLApplet.getValue("OLCA_BENEF_ADDR1");
		    var b=objXMLApplet.getValue("OLCA_BENEF_ADDR3");
		    var c=objXMLApplet.getValue("OLCA_BENEF_ADDR4");
		    var d=objXMLApplet.getValue("OLCA_BENEF_ADDR5");
		    var e=objXMLApplet.getValue("OLCA_BENEF_ADDR5");
		    gid('MF:txtAddress1').value=a+"\r\n"+"" +b+"\r\n"+"" +c+"\r\n"+"" +d+"\r\n"+"" +e;
		    
		    //Changes Sanjay 02-07-2019 Begin
		    
		    oldchkChangeofBeneficiary=gid('MF:chkChangeofBeneficiary').checked;
		    oldchkChgAppl=gid('MF:chkChgAppl').checked;
		    oldchkChgFormDc=gid('MF:chkChgFormDc').checked;
		    oldchkChgApplRules=gid("MF:chkChgApplRules").checked;
		    oldchkChgDesc=gid('MF:chkChgDesc').checked;
		    oldchkChgDoc=gid('MF:chkChgDoc').checked;
		    oldchkChgAddCond=gid("MF:chkChgAddCond").checked;
		    oldchkChgAvlWith=gid('MF:chkChgAvlWith').checked;
		    oldchkCgDrawee=gid('MF:chkCgDrawee').checked;
		    oldchkChgReimbus=gid('MF:chkChgReimbus').checked;
		    oldchkCgAdvBk=gid('MF:chkCgAdvBk').checked;
		    gid('MF:oldchkChgDesc').value=gid('MF:chkChgDesc').checked;
   	     	gid('MF:oldchkChgDoc').value=gid('MF:chkChgDoc').checked;
     	 	gid('MF:oldchkChgAddCond').value=gid("MF:chkChgAddCond").checked;
     	 	gid('MF:lstAmdPayableBy').value=objXMLApplet.getValue("OLCA_AMD_CHG_PAY_BY");
     	 	gid('MF:txtperiodOfPres').value=objXMLApplet.getValue("OLCA_PER_OF_PRES_DAYS");
		    //Changes Sanjay 02-07-2019 End
		    
		    oldBenCode=gid('MF:txtBeneficiaryCode').value;
		    oldBenName=gid('MF:txtBeneficiaryName').value;
		    oldBenCountry=gid('MF:txtBeneficiaryCountryCode').value;
		    oldBenAddress=gid('MF:txtAddress1').value;
		    
		    
		    //Amount Tab 1
		    gid('MF:txtLCEnhancementReductionNochange').value=objXMLApplet.getValue("OLCA_ENHANCEMNT_REDUCN");
		    
		    oldValueIncDecDC=gid('MF:txtLCEnhancementReductionNochange').value;
		    
		    		    
		    //Changes P.Subramani-Chn-02/04/2008 Beg
		    gid('MF:txtAmendedLCAmount').value=objXMLApplet.getValue("OLCA_LC_CURR_CODE"); 
		    gid('MF:txtAmendedLCAmount1').value=objXMLApplet.getValue("OLCA_AMENDED_AMT");
		    setAmount('MF:txtAmendedLCAmount1',gid("MF:txtAmendedLCAmount1").value); 					    
		    gid('MF:txtEnhancementReductionAmount').value=gid('MF:txtLCAmount').value;
					    
		    var A = unFormat(gid('MF:txtLCAmount21').value)*1;
		    var B = unFormat(gid('MF:txtAmendedLCAmount1').value)*1;
		    var C;
		    if(objXMLApplet.getValue("OLCA_ENHANCEMNT_REDUCN")=="E")
		    {
		    	C = (B)-(A);
		    	gid('MF:txtEnhancementReductionAmount1').value=C;			
		    }
		    else if(objXMLApplet.getValue("OLCA_ENHANCEMNT_REDUCN")=="R")
		    {
		    	C = (A)-(B);
		    	gid('MF:txtEnhancementReductionAmount1').value=C;
		    }
		    else if(objXMLApplet.getValue("OLCA_ENHANCEMNT_REDUCN")=="")
		    {
		    	gid('MF:txtEnhancementReductionAmount1').value=0;
		    }
		    setAmount('MF:txtEnhancementReductionAmount1',gid("MF:txtEnhancementReductionAmount1").value);	
		    //Changes P.Subramani-Chn-02/04/2008 End
		    
		    gid('MF:txtDeviationAllowed').value=objXMLApplet.getValue("OLCA_POS_DEV_ALLWD");
		    //Changes P.Subramani-Chn-25/08/2008 Beg
		    olcPositivDeviationAllow=objXMLApplet.getValue("OLCA_POS_DEV_ALLWD");
		    //Changes P.Subramani-Chn-25/08/2008 End
			gid('MF:txtDeviationAllowed1').value=objXMLApplet.getValue("OLCA_NEG_DEV_ALLWD");
			
			oldDevAmt1=gid('MF:txtDeviationAllowed').value;
			oldDevAmt2=gid('MF:txtDeviationAllowed1').value;
			
			
			gid('MF:txtDeviationAmount').value=objXMLApplet.getValue("OLCA_DEV_AMT");
			//Changes P.Subramani-Chn-26/08/2008 BEg
			gid('MF:txtprevDeviationAmount').value=objXMLApplet.getValue("OLCA_DEV_AMT");
			//Changes P.Subramani-Chn-26/08/2008 End
			gid('MF:lstAmountQualifier').value=objXMLApplet.getValue("OLCA_AMT_QUALFR");
						oldMaxCredAmt=gid('MF:lstAmountQualifier').value;
			
			gid('MF:txtTermsofPrice').value=objXMLApplet.getValue("OLCA_PRICE_TERMS");
			gid('MF:txtLastDateforNegotiation').value=objXMLApplet.getValue("OLCA_LAST_DATE_OF_NEG");
			oldValueExpiryDate=gid('MF:txtLastDateforNegotiation').value;
			
			gid('MF:txtPlaceofExpiry').value=objXMLApplet.getValue("OLCA_PLACE_OF_EXPIRY");
			gid('MF:txtLatestDateofShipment').value=objXMLApplet.getValue("OLCA_LATEST_DATE_OF_SHPMNT");
			oldLateDateShip=gid('MF:txtLatestDateofShipment').value;
					
			if(objXMLApplet.getValue("OLCA_WITHIN_VALIDATE_LC")=="1")
			{
				gid('MF:chkWithinValidityofLC').checked=true;
				gid('MF:outlblWithinValidityofLC').innerText="Yes";
			}
			else
			{
				gid('MF:chkWithinValidityofLC').checked=false;
				gid('MF:outlblWithinValidityofLC').innerText="No";
			}
			if(objXMLApplet.getValue("OLCA_LC_UI_BORNE_BY_APPLCNT")=="1")
			{
				gid('MF:chkUsanceInterestToBeBorneByApplicant').checked=true;
				gid('MF:outlblUsanceInterestToBeBorneByApplicant').innerText="Yes";
			}
			else
			{
				gid('MF:chkUsanceInterestToBeBorneByApplicant').checked=false;
				gid('MF:outlblUsanceInterestToBeBorneByApplicant').innerText="No";
			}
			gid('MF:txtDrawDowns').value=objXMLApplet.getValue("OLCA_NOF_TENORS");
			gid('MF:txtLCAfterAmd').value=objXMLApplet.getValue("OLCA_AMENDED_AMT");
			gid('MF:txtPositiveAfterAmd').value=objXMLApplet.getValue("OLCA_POS_DEV_ALLWD");
			gid('MF:txtAdditionalLCliabAmount1').value=objXMLApplet.getValue("OLCA_ADD_LIAB_LC_CURR");
			gid('MF:txtConvRatetobasecurr').value=objXMLApplet.getValue("OLCA_CONV_RATE_BASE_CURR");
			prevconvrate = objXMLApplet.getValue("OLCA_CONV_RATE_BASE_CURR");
			gid('MF:txtAdditionallcamtinBasecurr1').value=objXMLApplet.getValue("OLCA_ADD_LIAB_BASE_CURR");
			gid('MF:txtConvRateToLimitCurrency').value=objXMLApplet.getValue("OLCA_CONV_RATE_LIM_CURR");
			gid('MF:txtChangeinLCLiabAmountInLimitCurrency1').value=objXMLApplet.getValue("OLCA_TOT_LIAB_LIM_CURR");
			
			
			
			gid('MF:txtusnchgscurr').value=baseCurrency;
			gid('MF:txtusnchgsamt').value = objXMLApplet.getValue("OLCA_USANCE_CHARGES");
			gid('MF:txtusnchgsamt').value=formatNumbercurr(gid('MF:txtusnchgsamt').value,declength2)
			gid('MF:txtusnchgscurr1').value=baseCurrency;
			gid('MF:txtusnchgsamt1').value = objXMLApplet.getValue("OLCA_USANCE_CHARGES");
			gid('MF:txtusnchgsamt1').value=formatNumbercurr(gid('MF:txtusnchgsamt1').value,declength2)
			//gid('MF:txtusnchgstakendays').value=objXMLApplet.getValue("OLCA_USN_CHG_TAKEN_DAYS");
			gid('MF:txtcommchgscurr').value=baseCurrency;
			gid('MF:txtcommchgsamt').value = objXMLApplet.getValue("OLCA_COMMITMENT_CHARGES");
			gid('MF:txtcommchgsamt').value=formatNumbercurr(gid('MF:txtcommchgsamt').value,declength2)
			gid('MF:txtcommchgscurr1').value=baseCurrency;
			gid('MF:txtcommchgsamt1').value = objXMLApplet.getValue("OLCA_COMMITMENT_CHARGES");
			gid('MF:txtcommchgsamt1').value=formatNumbercurr(gid('MF:txtcommchgsamt1').value,declength2)
			//gid('MF:txtcommchgstakendays').value=objXMLApplet.getValue("OLCA_COMMIT_CHG_TAKEN_DAYS");
			//Changes P.Subramani-Chn-12/04/2008 End
			
			//Changes P.Subramani-Chn-28/07/2008 Beg
			tranchgs_sl=objXMLApplet.getValue("TRANCHGS_CHGS_SL");
			invoiceNumber=objXMLApplet.getValue("TRANSTLMNT_INV_NUM");
			
			//SUGANYA BEGIN 23-MAY-2017
			objTFMCharges.brncode=gid('MF:txtBranchCode').value;
			//SUGANYA END 23-MAY-2017
		    //SUGANYA BEGIN 28-FEB-2017
			objTFMCharges.customerno=gid("MF:txtCustomerNumber").value;
			
			//SUGANYA END 28-FEB-2017
			
			//Vinoth.S-Chns- 28-01-2011-Beg
		    objTFMCharges.trandate = gid('MF:txtLcDate').value;
		    //Vinoth.S-Chns- 28-01-2011-End
			objTFMCharges.AddOrModify = gid('MF:seluseroption').value;
			objTFMCharges.TRANCHGS_SL = objXMLApplet.getValue("TRANCHGS_CHGS_SL");
			objTFMCharges.validateComponentOnLoad();
			
			var total_chg_amt = parseFloat(unFormat(gid("MF:TFMChargesDetails:outtxttotal").value));
			var usance_chgs = parseFloat(unFormat(gid('MF:txtusnchgsamt1').value));
			var comm_chgs = parseFloat(unFormat(gid('MF:txtcommchgsamt1').value));
			var tran_amt = total_chg_amt + usance_chgs + comm_chgs;
			if(invoiceNumber!=0)
			{
				if(trim(gid("MF:seluseroption").value)=="M")
				{
		    		objTranStmntPost.InventoryNumber =invoiceNumber;
		    		objTranStmntPost.FetchFromTable=true;
		    		objTranStmntPost.ResultType="MAIN";
		    		objTranStmntPost.SourceKey=gid('MF:txtBranchCode').value+"|"+gid('MF:txtReferenceType').value+"|"+gid('MF:txtReferenceYear').value+"|"+gid("MF:txtReferenceSl").value+"|"+gid("MF:txtAmendmentSerial").value;
				}
		    	else
				{
					objTranStmntPost.InventoryNumber = 0;
				}
				objTranStmntPost.AddOrModify=gid("MF:seluseroption").value;
				objTranStmntPost.SourceTable="OLCAMD";
				objTranStmntPost.isDbCr = "D";
				objTranStmntPost.TranCurrCode=baseCurrency;
				objTranStmntPost.TranAmount=tran_amt;
				objTranStmntPost.TranBaseCurrEqu=tran_amt;
				objTranStmntPost.BranchCode=gid("MF:txtBranchCode").value;
				objTranStmntPost.valueDate=objXMLApplet.getValue("OLCA_ENTRY_DATE");
				objTranStmntPost.ProgramID="EOLCAMD";
		    	objTranStmntPost.fetch();
			}
			//Changes P.Subramani-Chn-28/07/2008 End
						
						
			//Changes P.Subramani-Chn-02/04/2008
			//Procedure Values
			gid('MF:chkPrevEnhanceReduction').value=gid('MF:txtLCEnhancementReductionNochange').value;
			gid('MF:txtPrevEnhaceeReductionAmt').value=unFormat(gid('MF:txtEnhancementReductionAmount1').value)*1;
			
			validateOLCSHIPTEXT1();
			validateOLCSHIPTEXT2();
			validateOLCOTEXT();
		}
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------		
	function validateOLCOTEXT()
	{
		objXMLApplet.clearMap();
		objXMLApplet.setValue("Package","panaceaweb.utility");
		objXMLApplet.setValue("SQLToken","valeolcamd6");
		if(gid('MF:seluseroption').value=="A")
		{
			if(gid('MF:txtAmendmentSerial').value>1)
			{
				Args=gid('MF:txtBranchCode').value+"|"+gid('MF:txtReferenceType').value+"|"+gid('MF:txtReferenceYear').value+"|"+gid('MF:txtReferenceSl').value+"|"+"A"+"|"+(gid('MF:txtAmendmentSerial').value-1);						       				
			}
			else
			{
				Args=gid('MF:txtBranchCode').value+"|"+gid('MF:txtReferenceType').value+"|"+gid('MF:txtReferenceYear').value+"|"+gid('MF:txtReferenceSl').value+"|"+"A"+"|"+gid('MF:txtAmendmentSerial').value;
			}
		}
		else
		{
			Args=gid('MF:txtBranchCode').value+"|"+gid('MF:txtReferenceType').value+"|"+gid('MF:txtReferenceYear').value+"|"+gid('MF:txtReferenceSl').value+"|"+"A"+"|"+gid('MF:txtAmendmentSerial').value;
		}	
		objXMLApplet.setValue("Args",Args);
		objXMLApplet.setValue("DataTypes","N|S|N|N|S|N");
		objXMLApplet.setValue("MTable","OLCOTEXT");
		objXMLApplet.setValue("Primkey",Args);   
		objXMLApplet.sendAndReceive();
		if(objXMLApplet.getValue("ErrorMsg")!= "")
	  	{
	  		setMsg(objXMLApplet.getValue("ErrorMsg"));
			gid('MF:txtReferenceSl').focus();
			return;  
		}
		if (objXMLApplet.getValue("Result") == "RowPresent") 
	    {
	    	var m=objXMLApplet.getValue("OLCOTX_ADDTNL_AMT_CVRD1");
	    	var n=objXMLApplet.getValue("OLCOTX_ADDTNL_AMT_CVRD2");
	    	var o=objXMLApplet.getValue("OLCOTX_ADDTNL_AMT_CVRD3");
	    	var p=objXMLApplet.getValue("OLCOTX_ADDTNL_AMT_CVRD4");
	    	gid('MF:txtAdditionalAmountsCovered').value=m+"\r\n"+"" +n+"\r\n"+"" +o+"\r\n"+"" +p;
	    }	
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------		
	function fetchfromOLCTENORSAMD()
	{
		objXMLApplet.clearMap();
		objXMLApplet.setValue("Package","panaceaweb.utility");
		objXMLApplet.setValue("SQLToken","valeolcamd7");						       				
		objXMLApplet.setValue("GridToken","FetchGridData");  
		Args=gid('MF:txtBranchCode').value+"|"+gid('MF:txtReferenceType').value+"|"+gid('MF:txtReferenceYear').value+"|"+gid('MF:txtReferenceSl').value+"|"+gid('MF:txtAmendmentSerial').value;
		objXMLApplet.setValue("Args",Args);
		objXMLApplet.setValue("DataTypes","N|S|N|N|N");
		objXMLApplet.setValue("MTable","OLCTENORSAMD");
		objXMLApplet.setValue("Primkey",Args);   
		objXMLApplet.sendAndReceive();
		if(objXMLApplet.getValue("ErrorMsg")!= "")
	  	{
	  		setMsg(objXMLApplet.getValue("ErrorMsg"));
			gid('MF:txtReferenceSl').focus();
			return;  
		}
		if (objXMLApplet.getValue("Result") == "RowPresent") 
	    {
	    	gridEolcamd.clearAll();
	    	//Changes P.Subramani-Chn-27/02/2008
	    	//Changes P.Subramani-Chn-23/08/2008 Beg
	    	gridEolcamd.setxmlcolumn("0,1,0,1,0,1,1,1,1,1,0,1,0,1,0,1,1,1,1,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0");
	    	//Changes P.Subramani-Chn-23/08/2008 End
	    	gridEolcamd.loadXMLString(objXMLApplet.getValue("GetGridData"));
	    	
	    	//Changes P.Subramani-Chn-22/08/2008 Beg
			for(var i=1;i<=gridEolcamd.getRowsNum();i++)
			{
				TenorSerial = i;
				Prev_enhanc_reduct_amt =parseFloat(unFormat(gridEolcamd.cells(i,5).getValue()))-parseFloat(unFormat(gridEolcamd.cells(i,3).getValue()));
				gridEolcamd.cells(i,20).setValue(Prev_enhanc_reduct_amt);	
				//Changes P.Subramani-Chn-27/08/2008 BEg
				if(amdsl==1)
		   	   {
		   			fetchprevolcdays1();  
		   			gridEolcamd.cells(i,23).setValue(prev_olc_days);
		   	   }
			   else
			   {
			  	 	amdsl=amdsl-1;
			  		fetchprevolcdays2();
			  		gridEolcamd.cells(i,23).setValue(prev_olc_days);
			   }
   				//Changes P.Subramani-Chn-27/08/2008 End	
			}	    	
	    	//Changes P.Subramani-Chn-22/08/2008 End
		}	
	} 
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	function fetchfromOLCAMDADD()
	{
		objXMLApplet.clearMap();         			
		objXMLApplet.setValue("Package", "panaceaweb.utility");
		objXMLApplet.setValue("SQLToken","valeolcamd4");
		Args = gid('MF:txtBranchCode').value+"|"+gid('MF:txtReferenceType').value+"|"+gid('MF:txtReferenceYear').value+"|"+gid("MF:txtReferenceSl").value+"|"+(gid("MF:txtAmendmentSerial").value-1);
		objXMLApplet.setValue ("Args",Args);
		objXMLApplet.setValue("DataTypes","N|S|N|N|N");     
		objXMLApplet.sendAndReceive();	         
		if(objXMLApplet.getValue("ErrorMsg") != "")
		{  
		clearNonKeyFields();
		setMsg(objXMLApplet.getValue("ErrorMsg"));
		gid('MF:txtReferenceSl').focus();
		return;         	
		}
		else
		{   
		
		
		
		
		//ADDED ON 12 MARCH 2019
		
		
			// NEW FIELDS ADDED BY PRASHANTH ON 09 FEB 2019
					    gid('MF:amdSpl1Value').value="";
    	    gid('MF:amdSpl2Value').value="";
 		    gid('MF:amdlogtemp4').value="";
 		    gid('MF:amdlogtemp5').value="";
				 clearGoodsTab();
		  		 clearDocumentsTab();
		  		 clearAdditionalDetailsTab();
		   		clearSplBenficieryDetailsTab();
		   		clearSplRecvBkDetailsTab();
		   		
		   	 gid('MF:amdGoodsValue').value="";
    	     gid('MF:amdDocsValue').value="";
    	     gid('MF:amdAddlValue').value="";
    	     gid('MF:amdSpl1Value').value="";
    	     gid('MF:amdSpl2Value').value="";
    	     
    	     
			 if(objXMLApplet.getValue("OLCA_CHG_IN_DESC_GOODS")=="1")
		    {
			    gid('MF:chkChgDesc').checked=true;
			    gid('MF:outlblChgDesc').innerText="Yes";
		    }
		    else
		    {
			    gid('MF:chkChgDesc').checked=false;
			    gid('MF:outlblChgDesc').innerText="No";
		    }
		    
		      //added by prashanth on 23 feb 2019
			    loadLogInModify("45B");
			    LoadCompleteDetailInModify("45B");
			    loadAmdChoiceMod("45B");
			    //added by prashanth on 23 feb 2019
			    
			    
		     if(objXMLApplet.getValue("OLCA_CHG_IN_DOC")=="1")
		    {
			    gid('MF:chkChgDoc').checked=true;
			    gid('MF:outlblchkChgDoc').innerText="Yes";
		    }
		    else
		    {
			    gid('MF:chkChgDoc').checked=false;
			    gid('MF:outlblchkChgDoc').innerText="No";
		    }
		    
		   	    loadLogInModify("46B");
			    LoadCompleteDetailInModify("46B");
			    loadAmdChoiceMod("46B");
			    
		     if(objXMLApplet.getValue("OLCA_CHG_IN_ADDL_COND")=="1")
		    {
			    gid('MF:chkChgAddCond').checked=true;
			    gid('MF:outlblChgAddCond').innerText="Yes";
		    }
		    else
		    {
			    gid('MF:chkChgAddCond').checked=false;
			    gid('MF:outlblChgAddCond').innerText="No";
		    }
		    
		    	 loadLogInModify("47B");
			    LoadCompleteDetailInModify("47B");
			    loadAmdChoiceMod("47B");
		    
		    
    	     
    	     
    	     
		    
		    loadLogInModify("49M");
			LoadCompleteDetailInModify("49M");
			loadAmdChoiceMod("49M");
			
			
			
			loadLogInModify("49N");
			LoadCompleteDetailInModify("49N");
		    loadAmdChoiceMod("49N");
			
			
			
		     if(objXMLApplet.getValue("OLCA_REQ_FOR_CANCEL")=="1")
		    {
			    gid('MF:chkReqForCancel').checked=true;
			    gid('MF:outlblchkReqForCancel').innerText="Yes";
		    }
		    else
		    {
			    gid('MF:chkReqForCancel').checked=false;
			    gid('MF:outlblchkReqForCancel').innerText="No";
		    }
		    
		    
		    
		     if(objXMLApplet.getValue("OLCA_CHG_OF_APPL")=="1")
		    {
			    gid('MF:chkChgAppl').checked=true;
			    gid('MF:outlblchkChgAppl').innerText="Yes";
		    }
		    else
		    {
			    gid('MF:chkChgAppl').checked=false;
			    gid('MF:outlblchkChgAppl').innerText="No";
		    }
		    
		    
		    
		     if(objXMLApplet.getValue("OLCA_CHG_IN_AVL_WITH")=="1")
		    {
			    gid('MF:chkChgAvlWith').checked=true;
			    gid('MF:outlblchkChgAvlWith').innerText="Yes";
		    }
		    else
		    {
			    gid('MF:chkChgAvlWith').checked=false;
			    gid('MF:outlblchkChgAvlWith').innerText="No";
		    }
		    
		    
		     if(objXMLApplet.getValue("OLCA_CHG_IN_DRAWEE_PAY")=="1")
		    {
			    gid('MF:chkCgDrawee').checked=true;
			    gid('MF:outlblchkCgDrawee').innerText="Yes";
		    }
		    else
		    {
			    gid('MF:chkCgDrawee').checked=false;
			    gid('MF:outlblchkCgDrawee').innerText="No";
		    }
		    
		    
		    
		    if(objXMLApplet.getValue("OLCA_CHG_IN_REIMB")=="1")
		    {
			    gid('MF:chkChgReimbus').checked=true;
			    gid('MF:outlblchkChgReimbus').innerText="Yes";
		    }
		    else
		    {
			    gid('MF:chkChgReimbus').checked=false;
			    gid('MF:outlblchkChgReimbus').innerText="No";
		    }
		    
		    
		    
		    
		    
		    if(objXMLApplet.getValue("OLCA_CHG_IN_ADV_BK")=="1")
		    {
			    gid('MF:chkCgAdvBk').checked=true;
			    gid('MF:outlblchkCgAdvBk').innerText="Yes";
		    }
		    else
		    {
			    gid('MF:chkCgAdvBk').checked=false;
			    gid('MF:outlblchkCgAdvBk').innerText="No";
		    }
		    
		    if(objXMLApplet.getValue("OLCA_CHG_IN_FORM_OF_DC")=="1")
		    {
			    gid('MF:chkChgFormDc').checked=true;
			    gid('MF:outlblchkChgFormDc').innerText="Yes";
		    }
		    else
		    {
			    gid('MF:chkChgFormDc').checked=false;
			    gid('MF:outlblchkChgFormDc').innerText="No";
		    }
		    
		     if(objXMLApplet.getValue("OLCA_CHG_IN_APPL_RULES")=="1")
		    {
			    gid('MF:chkChgApplRules').checked=true;
			    gid('MF:outlblchkChgApplRules').innerText="Yes";
		    }
		    else
		    {
			    gid('MF:chkChgApplRules').checked=false;
			    gid('MF:outlblchkChgApplRules').innerText="No";
		    }
				// NEW FIELDS ADDED BY PRASHANTH ON 09 FEB 2019
		
		
		
		
		
		
		
		//ADDED ON 12 MARCH 2019
		    gid('MF:txtAmendmentEntryDate').value=objXMLApplet.getValue("OLCA_ENTRY_DATE");
		    gid('MF:txtCustomerletterNumber').value=objXMLApplet.getValue("OLCA_CUST_LETTER_NUM");
		    gid('MF:txtCustomerletterDate').value=objXMLApplet.getValue("OLCA_CUST_LTR_DATE");
		    //gid('MF:txtReasonForAmendment').value=objXMLApplet.getValue("OLCA_RSN_FOR_AMD");//COMMENTED ON 16/10/2018
		    if(objXMLApplet.getValue("OLCA_CHANGE_OF_BENEF")=="1")
		    {
		    	gid('MF:chkChangeofBeneficiary').checked=true;
		    	gid('MF:outlblChangeofBeneficiary').innerText="Yes";
		    }
		    else
		    {
		    	gid('MF:chkChangeofBeneficiary').checked=false;
		    	gid('MF:outlblChangeofBeneficiary').innerText="No";
		    }
		    gid('MF:txtBeneficiaryCode').value=objXMLApplet.getValue("OLCA_BENEF_CODE");
		    gid('MF:txtBeneficiaryName').value=objXMLApplet.getValue("OLCA_BENEF_NAME");
		    gid('MF:txtBeneficiaryCountryCode').value=objXMLApplet.getValue("OLCA_BENEF_CNTRY_CODE");
		    var a=objXMLApplet.getValue("OLCA_BENEF_ADDR1");
		    var b=objXMLApplet.getValue("OLCA_BENEF_ADDR3");
		    var c=objXMLApplet.getValue("OLCA_BENEF_ADDR4");
		    var d=objXMLApplet.getValue("OLCA_BENEF_ADDR5");
		    var e=objXMLApplet.getValue("OLCA_BENEF_ADDR5");
		    gid('MF:txtAddress1').value=a+"\r\n"+"" +b+"\r\n"+"" +c+"\r\n"+"" +d+"\r\n"+"" +e;
		    
		    //Changes Sanjay 02-07-2019 Begin
		    oldchkChangeofBeneficiary=gid('MF:chkChangeofBeneficiary').checked;
		    oldchkChgAppl=gid('MF:chkChgAppl').checked;
		    oldchkChgFormDc=gid('MF:chkChgFormDc').checked;
		    oldchkChgApplRules=gid("MF:chkChgApplRules").checked;
		    oldchkChgDesc=gid('MF:chkChgDesc').checked;
		    oldchkChgDoc=gid('MF:chkChgDoc').checked;
		    oldchkChgAddCond=gid("MF:chkChgAddCond").checked;
		    oldchkChgAvlWith=gid('MF:chkChgAvlWith').checked;
		    oldchkCgDrawee=gid('MF:chkCgDrawee').checked;
		    oldchkChgReimbus=gid('MF:chkChgReimbus').checked;
		    oldchkCgAdvBk=gid('MF:chkCgAdvBk').checked;
		    gid('MF:oldchkChgDesc').value=gid('MF:chkChgDesc').checked;
   	     	gid('MF:oldchkChgDoc').value=gid('MF:chkChgDoc').checked;
     	 	gid('MF:oldchkChgAddCond').value=gid("MF:chkChgAddCond").checked;
     	 	gid('MF:lstAmdPayableBy').value=objXMLApplet.getValue("OLCA_AMD_CHG_PAY_BY");
     	 	gid('MF:txtperiodOfPres').value=objXMLApplet.getValue("OLCA_PER_OF_PRES_DAYS");
		    //Changes Sanjay 02-07-2019 End
		    oldBenCode=gid('MF:txtBeneficiaryCode').value;
			oldBenName=gid('MF:txtBeneficiaryName').value;
		    oldBenCountry=gid('MF:txtBeneficiaryCountryCode').value;
		    oldBenAddress=gid('MF:txtAddress1').value;
		    
		    //Amount Tab 1
		    gid('MF:txtLCEnhancementReductionNochange').value=objXMLApplet.getValue("OLCA_ENHANCEMNT_REDUCN");
		    		    oldValueIncDecDC=gid('MF:txtLCEnhancementReductionNochange').value;
		    
		    //Changes P.Subramani-Chn-01/04/2008 Beg
		    gid('MF:txtLCAmount2').value=objXMLApplet.getValue("OLCA_LC_CURR_CODE"); 
		    gid('MF:txtLCAmount21').value=objXMLApplet.getValue("OLCA_AMENDED_AMT");
		    setAmount('MF:txtLCAmount21',gid("MF:txtLCAmount21").value);
		    gid('MF:txtDeviationAllowed').value=objXMLApplet.getValue("OLCA_POS_DEV_ALLWD");
		    olcPositivDeviationAllow=objXMLApplet.getValue("OLCA_POS_DEV_ALLWD");
			gid('MF:txtDeviationAllowed1').value=objXMLApplet.getValue("OLCA_NEG_DEV_ALLWD");
			gid('MF:txtDeviationAmount').value=objXMLApplet.getValue("OLCA_DEV_AMT");
			//Changes P.Subramani-Chn-26/08/2008 BEg
			gid('MF:txtprevDeviationAmount').value=objXMLApplet.getValue("OLCA_DEV_AMT");
			//Changes P.Subramani-Chn-26/08/2008 End
			//olcPositivDeviationAllow=gid('MF:txtDeviationAllowed').value;
			gid('MF:lstAmountQualifier').value=objXMLApplet.getValue("OLCA_AMT_QUALFR");
						oldMaxCredAmt=gid('MF:lstAmountQualifier').value;
			
			gid('MF:txtTermsofPrice').value=objXMLApplet.getValue("OLCA_PRICE_TERMS");
			//gid("MF:txtDeviationBalance").value=objXMLApplet.getValue("OLC_DEV_BAL");	
			//Changes P.Subramani-Chn-12/04/2008 Beg
			prevlastdatefornegotiation=objXMLApplet.getValue("OLCA_LAST_DATE_OF_NEG");
			//Changes P.Subramani-Chn-12/04/2008 End
			gid('MF:txtLastDateforNegotiation').value=objXMLApplet.getValue("OLCA_LAST_DATE_OF_NEG");
						
						oldValueExpiryDate=gid('MF:txtLastDateforNegotiation').value;
			
			gid('MF:txtPlaceofExpiry').value=objXMLApplet.getValue("OLCA_PLACE_OF_EXPIRY");
			gid('MF:txtLatestDateofShipment').value=objXMLApplet.getValue("OLCA_LATEST_DATE_OF_SHPMNT");
								oldLateDateShip=gid('MF:txtLatestDateofShipment').value;
					
			if(objXMLApplet.getValue("OLCA_WITHIN_VALIDATE_LC")=="1")
			{
				gid('MF:chkWithinValidityofLC').checked=true;
				gid('MF:outlblWithinValidityofLC').innerText="Yes";
			}
			else
			{
				gid('MF:chkWithinValidityofLC').checked=false;
				gid('MF:outlblWithinValidityofLC').innerText="No";
			}
			if(objXMLApplet.getValue("OLCA_LC_UI_BORNE_BY_APPLCNT")=="1")
			{
				gid('MF:chkUsanceInterestToBeBorneByApplicant').checked=true;
				gid('MF:outlblUsanceInterestToBeBorneByApplicant').innerText="Yes";
			}
			else
			{
				gid('MF:chkUsanceInterestToBeBorneByApplicant').checked=false;
				gid('MF:outlblUsanceInterestToBeBorneByApplicant').innerText="No";
			}
			gid('MF:txtDrawDowns').value=objXMLApplet.getValue("OLCA_NOF_TENORS");
			//Changes P.Subramani-Chn-01/04/2008 Beg
			gid('MF:txtLCBeforeAmd').value=objXMLApplet.getValue("OLCA_AMENDED_AMT");
			gid('MF:txtPositiveBeforeAmd').value=objXMLApplet.getValue("OLCA_POS_DEV_ALLWD");
			gid('MF:txtLCAfterAmd').value="";
			gid('MF:txtPositiveAfterAmd').value="";
			//Changes P.Subramani-Chn-01/04/2008 End
			
			//Changes P.Subramani-Chn-19/08/2008 Beg
			gid("MF:txttotalliabbasecurr").value=objXMLApplet.getValue("OLCA_TOT_LIAB_BASE_CURR");
			//Changes P.Subramani-Chn-19/08/2008 End
						
			gid('MF:txtAdditionalLCliabAmount1').value=objXMLApplet.getValue("OLCA_ADD_LIAB_LC_CURR");
			gid('MF:txtConvRatetobasecurr').value=objXMLApplet.getValue("OLCA_CONV_RATE_BASE_CURR");
			prevconvrate = objXMLApplet.getValue("OLCA_CONV_RATE_BASE_CURR");
			gid('MF:txtAdditionallcamtinBasecurr1').value=objXMLApplet.getValue("OLCA_ADD_LIAB_BASE_CURR");
			gid('MF:txtConvRateToLimitCurrency').value=objXMLApplet.getValue("OLCA_CONV_RATE_LIM_CURR");
			gid('MF:txtChangeinLCLiabAmountInLimitCurrency1').value=objXMLApplet.getValue("OLCA_TOT_LIAB_LIM_CURR");
			gid('MF:txtaddtranchgs').value=objXMLApplet.getValue("TRANCHGS_CHGS_SL");
			gid('MF:txtaddtranstlmntinvnum').value=objXMLApplet.getValue("TRANSTLMNT_INV_NUM");
			gid('MF:txtEnhancementReductionAmount').value=gid('MF:txtLCAmount').value;
			gid('MF:txtEnhancementReductionAmount1').value="";
			//Changes P.Subramani-Chn-01/04/2008  End
			
			//Procedure Values
			gid('MF:chkPrevEnhanceReduction').value=gid('MF:txtLCEnhancementReductionNochange').value;
			gid('MF:txtPrevEnhaceeReductionAmt').value=unFormat(gid('MF:txtEnhancementReductionAmount1').value)*1;
			
			//Changes P.Subramani-Chn-12/04/2008 Beg
			if(unFormat(objXMLApplet.getValue("OLCA_ADD_LIAB_BASE_CURR"))*1 > 0)
			{
				_total_liab_base_curr=objXMLApplet.getValue("OLCA_ADD_LIAB_BASE_CURR");
			}
			//Changes P.Subramani-Chn-12/04/2008 End
			
			tranchgs_sl=objXMLApplet.getValue("TRANCHGS_CHGS_SL");
			invoiceNumber=objXMLApplet.getValue("TRANSTLMNT_INV_NUM");
			//to get values from OLCSHIPTEXT
			validateOLCSHIPTEXT1();
			validateOLCSHIPTEXT2();
			validateOLCOTEXT();
		}	
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------		
	function fetchfromOLCTENORSAMDADD()
	{
		objXMLApplet.clearMap();
		objXMLApplet.setValue("Package","panaceaweb.utility");
		objXMLApplet.setValue("SQLToken","valeolcamd3");						       				
		objXMLApplet.setValue("GridToken","FetchGridData");  
		Args=gid('MF:txtBranchCode').value+"|"+gid('MF:txtReferenceType').value+"|"+gid('MF:txtReferenceYear').value+"|"+gid('MF:txtReferenceSl').value+"|"+(gid('MF:txtAmendmentSerial').value-1);
		objXMLApplet.setValue("Args",Args);
		objXMLApplet.setValue("DataTypes","N|S|N|N|N");
		objXMLApplet.setValue("MTable","OLCTENORSAMD");
		objXMLApplet.setValue("Primkey",Args);   
		objXMLApplet.sendAndReceive();
		if(objXMLApplet.getValue("ErrorMsg") != "")
	  	{
	  		setMsg(objXMLApplet.getValue("ErrorMsg"));
			gid('MF:txtReferenceSl').focus();
			return;  
		}
		if (objXMLApplet.getValue("Result") == "RowPresent") 
	    {
	    	gridEolcamd.clearAll();
	    	//Changes P.Subramani-Chn-22/08/2008 Beg
	    	gridEolcamd.setxmlcolumn("0,1,0,1,0,0,1,1,1,1,0,1,0,1,0,0,1,1,1,1,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0");
	    	//Changes P.Subramani-Chn-22/08/2008 End
			gridEolcamd.loadXMLString(objXMLApplet.getValue("GetGridData"));
		}	
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------		
	//OLCSHIPTEXT
	function  validateOLCSHIPTEXT1()
	{
	    objXMLApplet.clearMap();
		objXMLApplet.setValue("Package","panaceaweb.utility");
		objXMLApplet.setValue("SQLToken","valeolcamd5");						       				
		Args=gid('MF:txtBranchCode').value+"|"+gid('MF:txtReferenceType').value+"|"+gid('MF:txtReferenceYear').value+"|"+gid('MF:txtReferenceSl').value+"|"+"A"+"|"+1+"|"+"SH";
		objXMLApplet.setValue("Args",Args);
		objXMLApplet.setValue("DataTypes","N|S|N|N|S|N|S");
		objXMLApplet.setValue("MTable","OLCSHIPTEXT");
		objXMLApplet.setValue("Primkey",Args);   
		objXMLApplet.sendAndReceive();
		if(objXMLApplet.getValue("ErrorMsg") != "")
	  	{
	  		setMsg(objXMLApplet.getValue("ErrorMsg"));
			gid('MF:txtReferenceSl').focus();
			return;  
		}
	    if(objXMLApplet.getValue("Result") == "RowPresent")
		{	
			 var p=objXMLApplet.getValue("OLCST_TEXT1");
			 var q=objXMLApplet.getValue("OLCST_TEXT2");
			 var r=objXMLApplet.getValue("OLCST_TEXT3");
			 var z=objXMLApplet.getValue("OLCST_TEXT4")
			 gid('MF:txtShipmentPeriodSchedule').value=p+"\r\n"+"" +q+"\r\n"+"" +r+"\r\n"+"" +z;
			 shipPer=trim(gid('MF:txtShipmentPeriodSchedule').value);
			 
		}
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------		
	function  validateOLCSHIPTEXT2()
	{
	    objXMLApplet.clearMap();
		objXMLApplet.setValue("Package","panaceaweb.utility");
		objXMLApplet.setValue("SQLToken","valeolcamd5");						       				
		Args=gid('MF:txtBranchCode').value+"|"+gid('MF:txtReferenceType').value+"|"+gid('MF:txtReferenceYear').value+"|"+gid('MF:txtReferenceSl').value+"|"+"A"+"|"+1+"|"+"PD";
		objXMLApplet.setValue("Args",Args);
		objXMLApplet.setValue("DataTypes","N|S|N|N|S|N|S");
		objXMLApplet.setValue("MTable","OLCSHIPTEXT");
		objXMLApplet.setValue("Primkey",Args);   
		objXMLApplet.sendAndReceive();
		if(objXMLApplet.getValue("ErrorMsg") != "")
	  	{
	  		setMsg(objXMLApplet.getValue("ErrorMsg"));
			gid('MF:txtReferenceSl').focus();
			return;  
		}
	    if(objXMLApplet.getValue("Result") == "RowPresent")
		{	
			 var p=objXMLApplet.getValue("OLCST_TEXT1");
			 var q=objXMLApplet.getValue("OLCST_TEXT2");
			 var r=objXMLApplet.getValue("OLCST_TEXT3");
			 var z=objXMLApplet.getValue("OLCST_TEXT4");
			 gid('MF:txtPresentationDetails').value=p+"\r\n"+"" +q+"\r\n"+"" +r+"\r\n"+"" +z;
		}
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------		
	function validateNext()
	{
		setTabfocus("maintab","tcontent2");	
		gid('MF:txtAmendmentEntryDate').focus();	
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------		
	//Changes P.Subramani-Chn-20/10/2008 Beg
	function validateLimitNext()
	{
		if( (unFormat(gid('MF:txtAdditionallcamtinBasecurr1').value)*1) > 0 )
	    {
			setTabfocus("maintab","tcontent6a");
			enableTab("maintab","tcontent6a");
			gid('MF:txtmargincurr').focus();
		}
		else if( (unFormat(gid('MF:txtReductioninLCliabinBasecurr1').value)*1) > 0 )
	    {
	    	//Changes P.Subramani-Chn-29/10/2008 Beg
		     gid('MF:txtmargincurr').value=""; 
	    	 gid('MF:outlblmargincurr').innerText=""; 
	    	 gid('MF:txtmarginpercentage').value=""; 
	    	 gid('MF:txtmarginpercentage1').value=""; 
	    	 gid('MF:txtmarginamtcurr').value=""; 
	    	 gid('MF:txtmarginamt1').value=""; 
	    	 gid('MF:txtmarginamt2').value=""; 
	    	 gid('MF:txtmarginamt3').value=""; 
			 gid('MF:txtcashmargincurr').value=""; 
			 gid('MF:txtcashmarginamt1').value=""; 
			 gid('MF:txtcashmarginamt2').value=""; 
			 gid('MF:txtcashmarginamt3').value=""; 
			 gid('MF:lstmargintypeforLC').value="";
	     	//Changes P.Subramani-Chn-29/10/2008 End
			disableTab("maintab","tcontent6a");
			callCharges();
		}
	 	else
	 	{
	 		disableTab("maintab","tcontent6a");
	 		callCharges();
	 	}	
	}
	//Changes P.Subramani-Chn-20/10/2008 End	
//-------------------------------------------------------------------------------------------------------------------------------------------------------------		
	function validateAmendmentEntryDate()
	{
		if(trim(gid('MF:txtAmendmentEntryDate').value)=="")
       	{	
       		 gid('MF:txtAmendmentEntryDate').value=currbusDate;
	  	 	 gid('MF:txtAmendmentEntryDate').focus();
	  	}
       	dateobj=parseDate(gid('MF:txtAmendmentEntryDate').value,"true");
	  	if(dateobj == null)
   		{
   		    setMsg(INVALIDDATE);
			gid('MF:txtAmendmentEntryDate').focus();
		   	return;		        
   		}
    	dateobj = formatDate(dateobj,'dd-MM-yyyy');
  		gid('MF:txtAmendmentEntryDate').value =dateobj;
  		dateok = isDate(gid('MF:txtAmendmentEntryDate').value,'dd-MM-yyyy');
		if (dateok == 0)
   		{
	   		setMsg(INVALIDDATE);
	   		gid('MF:txtAmendmentEntryDate').focus();
	   		return ;
	   	}		
  		dateok =compareDates(dateobj,'dd-MM-yyyy', currbusDate,'dd-MM-yyyy');
  		if (!(dateok == 0) && !(dateok == 1))
   		{	
	   		setMsg(DATE_LESS_EQ_CBD);
	   		gid('MF:txtAmendmentEntryDate').focus();
	   		return ;
   		} 
   		if (dateok == -1 ) 
   		{
   			setMsg(INVALIDDATE);
	   		gid('MF:txtAmendmentEntryDate').focus();
	   		return ;
   		}
   		else
   		{
   		  	objXMLApplet.clearMap();
			objXMLApplet.setValue("Package","panacea.OLCaction.eolcamdval");
			objXMLApplet.setValue("Method","ircrTranDatekeypress");
	        objXMLApplet.setValue("ValidateToken", "true");
	        objXMLApplet.setValue("AMENDMENT_ENTRY_DATE",trim(gid('MF:txtAmendmentEntryDate').value));
	        objXMLApplet.setValue("CBD",currbusDate);
	        objXMLApplet.setValue("LC_DATE",trim(gid('MF:txtLCDate').value));
	        objXMLApplet.sendAndReceive();
			if(objXMLApplet.getValue("ErrorMsg") != "")
			{
				setMsg(objXMLApplet.getValue("ErrorMsg"));
				gid('MF:txtAmendmentEntryDate').focus();
				return;  
			}
			else
			{
				gid('MF:txtCustomerletterNumber').focus();
	   		}
   		}
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------		   		   		   		
	function validateCustomerletterNumber()
	{
	    gid('MF:txtCustomerletterDate').focus();  
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------		
	function validateCustomerletterDate()
	{	
	    if(trim(gid('MF:txtCustomerletterDate').value)!="")
	    {
	    	if(trim(gid('MF:txtCustomerletterDate').value)=="")
	       	{	
	       		 gid('MF:txtCustomerletterDate').value=currbusDate;
		  	 	 gid('MF:txtCustomerletterDate').focus();
		  	 	 return;
	       	}
	       	dateobj=parseDate(gid('MF:txtCustomerletterDate').value,"true");
   	  		if(dateobj == null)
	   		{
	   		    setMsg(INVALIDDATE);
				gid('MF:txtCustomerletterDate').focus();
			   	return;		        
	   		}
	    	dateobj = formatDate(dateobj,'dd-MM-yyyy');
	  		gid('MF:txtCustomerletterDate').value =dateobj;
	  		dateok = isDate(gid('MF:txtCustomerletterDate').value,'dd-MM-yyyy');
			if (dateok == 0)
	   		{
		   		setMsg(INVALIDDATE);
		   		gid('MF:txtCustomerletterDate').focus();
		   		return ;
		   		}		
	  		dateok =compareDates(dateobj,'dd-MM-yyyy', currbusDate,'dd-MM-yyyy');
      		if (!(dateok == 0) && !(dateok == 1))
	   		{	
		   		setMsg(DATE_LESS_EQ_CBD);
		   		gid('MF:txtCustomerletterDate').focus();
		   		return ;
	   		} 
	   		if (dateok == -1 ) 
	   		{
	   			setMsg(INVALIDDATE);
		   		gid('MF:txtCustomerletterDate').focus();
		   		return ;
	   		}
	   		else
	   		{
      			//gid('MF:txtReasonForAmendment').focus();//COMMENETED ON 16/10/2018
      			gid('MF:chkExpiryDate').focus();//ADDED ON 16/10/2018 START
			}
	  	}
	  	else
	  	{
	  		//gid('MF:txtReasonForAmendment').focus();//COMMENETED ON 16/10/2018
	  		gid('MF:chkExpiryDate').focus();//ADDED ON 16/10/2018 START
      	}		
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			
	/*function validateReasonForAmendment()COMMENTED ON 16/10/2018
	{
    	if(gid("MF:txtReasonForAmendment").value=="")
		{
			setMsg(OPTION_MESSAGE);
			gid("MF:txtReasonForAmendment").focus();
			return;
		}
		gid("MF:chkChangeofBeneficiary").focus();			
	}*/
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			
	function validateChangeofBeneficiary()
	{
  		//ADDED ON 16/10/2018 START
  		//newbenef ="0";
  		chkbenficiary();
  		/*if(gid('MF:txtBeneficiaryCode').disabled == false )
   		{
		 		gid("MF:txtBeneficiaryCode").focus();	
		}
		else
		{
  			setTabfocus("maintab","tcontent3");gid('MF:txtLCEnhancementReductionNochange').focus();
  		}
  		COMMENTTED BY PRASHANTH
  		*/
  		
  		//ADDED BY PRASHANTH
  		gid("MF:chkChgDesc").focus();	
       //ADDED BY PRASHANTH
  		
  		
  		
  		//ADDED ON 16/10/2018 END
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			
	
	
	//added by prashanth
	function gridAllocKeypress(row,col)
	   {
	   
	   }
	   
	   function gridAllocDocKeypress(row,col)
	   {
	   
	   }
	   
	   function gridAllocAddlKeypress(row,col)
	   {
	   
	   }
	   
	   
	   
	   function gridAllocSplBeneKeypress(row,col)
	   {
	   
	   }
	   function gridAllocSplRecevKeypress(row,col)
	   {
	   
	   }
	   
	   
	   
	    function onchange_selall(gridname,id,outlabel,colID)
	   {
	       if(gridname=="")
	       {
	       		gridAlloc.clearAll();
	       		clearGoodsTab();
       	   		
       	   		
       	   		gridAllocDoc.clearAll();
       	   		clearDocumentsTab();
       	   		
       	   		
       	   		gridAllocAddl.clearAll();
       	   		clearAdditionalDetailsTab();
       	   		
       	   		
       	   		gridAllocSplBene.clearAll();
       	   		clearSplBenficieryDetailsTab();
       	   		
       	   		
       	   		
       	   		gridAllocSplRecev.clearAll();
       	   		clearSplRecvBkDetailsTab();
       	   		
       	   		
       	   		
       	   		return true;
	       }
	   
	        var id=gid('MF:'+id);
	        var outlabel=gid('MF:'+outlabel);
	   		if(id.checked)
	   		{
	   		outlabel.innerText="Yes";
	   		}
	   		else
	   		{
	   		outlabel.innerText="No";
	   		}
	   		var rows=gridname.getRowsNum();
	   		if(rows==0)
	   		{
	   		AddRowToGrid(gridname);
	   		}
	   		else
	   		{
	   		if(id.checked)
	   		{
	   		for(var i=0;i<rows;i++)
	   		{	
	   			var pc=gridname.cells(i+1,1).getValue();
	   			var pc1=pc.charAt(0);
	   			{
	   			gridname.cells(i+1,colID).setValue("Yes");
	   			}
	   		}
	   		}
	   		if(id.checked==false)
	   		{
	   		for(var i=0;i<rows;i++)
	   		{
	   			var pc=gridname.cells(i+1,1).getValue();
	   			var pc1=pc.charAt(0);
	   			{
	   			gridname.cells(i+1,colID).setValue("No");
	   			}
	   		}
	   		}
	   		}
	  	   }
		//added by prashanth
	
	function validateBeneficiaryCode()
	{
	
		if(!checkOldValuBen())
	    {
          return false;	    
	    } 
		//ADDED ON 16/10/2018 START
        var _benfCodeChecked ="";
		if(gid("MF:chkChangeofBeneficiary").checked==true)
   		{
   			_benfCodeChecked ="1";
   		}
   		else
   		{
   			_benfCodeChecked ="0";
   		}
   		//ADDED ON 16/10/2018 END
		
		if(gid("MF:txtBeneficiaryCode").value!="")
	    {									
			objXMLApplet.clearMap();
			objXMLApplet.setValue("Package","panacea.OLCaction.eolcamdval");
			objXMLApplet.setValue("Method","olcBenefCodekeypress");
			objXMLApplet.setValue("ValidateToken", "true");
			objXMLApplet.setValue("BENEF_CODE",trim(gid('MF:txtBeneficiaryCode').value));
			//ADDED ON 16/10/2018 START
	 		objXMLApplet.setValue("AMEND_FIELDNO","6");
	 		objXMLApplet.setValue("AMEND_CHKBOX",_benfCodeChecked); 
	 		objXMLApplet.setValue("OLC_LC_TYPE",trim(gid('MF:txtReferenceType').value));
	 		//ADDED ON 16/10/2018 END
			objXMLApplet.sendAndReceive();
			if(objXMLApplet.getValue("ErrorMsg") != "")
			{
				setMsg(objXMLApplet.getValue("ErrorMsg"));
				gid('MF:txtBeneficiaryCode').focus();
				return;  
			}
			else
			{
				gid('MF:txtBeneficiaryName').value=objXMLApplet.getValue("CPARTY_NAME");
				var a=objXMLApplet.getValue("CPARTY_ADDR1");
				var b=objXMLApplet.getValue("CPARTY_ADDR2");
				var c=objXMLApplet.getValue("CPARTY_ADDR3");
				var d=objXMLApplet.getValue("CPARTY_ADDR4");
				var e=objXMLApplet.getValue("CPARTY_ADDR5");
				gid('MF:txtAddress1').value=a+"\r\n"+"" +b+"\r\n"+"" +c+"\r\n"+"" +d+"\r\n"+"" +e;
				gid('MF:txtBeneficiaryCountryCode').value=objXMLApplet.getValue("CNTRY_CODE");
				gid('MF:outputlblBeneficiaryCountryCode').innerText=objXMLApplet.getValue("CNTRY_NAME");
			    gid("MF:txtBeneficiaryName").focus();
		    }				
	  	}
	    else
	    {
	   		//gid("MF:txtBeneficiaryName").focus();
	   		//ADDED ON 16/10/2018 START
	   		if(gid("MF:txtReferenceType").value=="OLC")
	   		{
	   		setMsg(BLANK_CHECK);
			gid("MF:txtBeneficiaryCode").focus();
			return;
			}
			else
			{
				gid("MF:txtBeneficiaryName").focus();
			}
			//ADDED ON 16/10/2018 END
	  	}			
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			
	function validateBeneficiaryName()
	{
	   if(gid("MF:txtBeneficiaryName").value=="")
	   {						
	   		setMsg(BLANK_CHECK);
			gid("MF:txtBeneficiaryName").focus();
			return;
	   }
	   else
	   {
	   		focusTextArea('MF:txtAddress1');
	   }  
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------				
	function validateAddress1()
	{
	  if(gid("MF:txtAddress1").value=="")
	  {
	  	 setMsg(BLANK_CHECK);
		 focusTextArea('MF:txtAddress1');
		 return;
	  }
	  else
	  {
	  	 gid("MF:txtBeneficiaryCountryCode").focus();	  
	  }
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			
	function validateBeneficiaryCountryCode()
	{
	
	
	    if(!checkOldValuBen())
	    {
          return false;	    
	    } 
	    
	    
	    
		//ADDED ON 16/10/2018 START
        var _benfCntryChecked ="";
		if(gid("MF:chkChangeofBeneficiary").checked==true)
   		{
   			_benfCntryChecked ="1";
   		}
   		else
   		{
   			_benfCntryChecked ="0";
   		}
   		//ADDED ON 16/10/2018 END
		
		if(gid("MF:txtBeneficiaryCountryCode").value=="")
		{	
			setMsg(BLANK_CHECK);
			gid("MF:txtBeneficiaryCountryCode").focus();
			return;
		}
	 	else
	  	{
		    objXMLApplet.clearMap();
			objXMLApplet.setValue("Package","panacea.OLCaction.eolcamdval");
			objXMLApplet.setValue("Method","olcBenefCountryCodekeypress");
			objXMLApplet.setValue("ValidateToken", "true");
			objXMLApplet.setValue("OLC_COUNTRY_CODE",trim(gid('MF:txtBeneficiaryCountryCode').value));
			//ADDED ON 16/10/2018 START
	 		objXMLApplet.setValue("AMEND_FIELDNO","6");
	 		objXMLApplet.setValue("AMEND_CHKBOX",_benfCntryChecked);
	 		//ADDED ON 16/10/2018 END
			objXMLApplet.sendAndReceive();
			if(objXMLApplet.getValue("ErrorMsg") != "")
			{
			  setMsg(objXMLApplet.getValue("ErrorMsg"));
			  gid('MF:txtBeneficiaryCountryCode').focus();
			  return;  
			}
			else
			{
			  gid('MF:outputlblBeneficiaryCountryCode').innerText=objXMLApplet.getValue("CNTRY_NAME");
		   	  setTabfocus("maintab","tcontent3");
		      gid("MF:lstAmdPayableBy").focus();
		    }
	  	}  
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			
	function validateLCEnhancementReductionNochange()
	{			
	
	
	     if(!checkOldValueIncreaseDecDC())
	     { 
	       return false;
	     }
		//ADDED ON 16/10/2018 START
		if(gid("MF:chkIncDec").checked==true)
   		{
   			if(gid("MF:txtLCEnhancementReductionNochange").value=="")
   			{
   				if(gid("MF:txtReferenceType").value=="OLC")
   					setMsg("Should not be blank if F32B/F32DIncrease/Decrease Of DC is checked");
   				else
   					setMsg("Should not be blank if L/C Enhancement /Reduction / No change is checked");
		   		gid("MF:txtLCEnhancementReductionNochange").focus();
		   		return;
   			}
   		}
   		else
   		{
   		if( gid("MF:txtLCEnhancementReductionNochange").value != "" )// && gid("MF:txtReferenceType").value=="OLC" )
   			{
   				
   				if(gid("MF:txtReferenceType").value=="OLC")
   					setMsg("F32B/F32DIncrease/Decrease Of DC is not checked");
   				else
   				setMsg("L/C Enhancement /Reduction / No change is not checked");
   				
		   		gid("MF:txtLCEnhancementReductionNochange").focus(); 
		   		return;
   			}
   		}
   		//ADDED ON 16/10/2018 END
		
		if(gid("MF:txtLCEnhancementReductionNochange").value=="E") 
		{
			gid("MF:lbleolcamd25").innerText="Enhancement Amount";
			gid("MF:txtEnhancementReductionAmount1").focus();
		}
		else if(gid("MF:txtLCEnhancementReductionNochange").value=="R")
		{
			gid("MF:lbleolcamd25").innerText="Reduction Amount";
		 	gid("MF:txtEnhancementReductionAmount1").focus();
		}
		else if(gid("MF:txtLCEnhancementReductionNochange").value=="")
		{
			//gid("MF:txtEnhancementReductionAmount").value="";
			gid("MF:txtEnhancementReductionAmount1").value="";
			gid("MF:txtAmendedLCAmount").value=gid("MF:txtLCAmount").value;
			//gid("MF:txtAmendedLCAmount").value="";
			gid("MF:txtEnhancementReductionAmount1").value=0;
			setAmount('MF:txtEnhancementReductionAmount1',gid("MF:txtEnhancementReductionAmount1").value);
			//Changes P.Subramani-Chn-01/04/2008
			gid("MF:txtAmendedLCAmount1").value=gid("MF:txtLCAmount21").value;
			setAmount('MF:txtAmendedLCAmount1',gid("MF:txtAmendedLCAmount1").value);
			//gid("MF:txtDeviationAllowed").focus();	COMMENTED ON 16/10/2018
			//ADDED ON 16/10/2018 START
			if(gid('MF:txtDeviationAllowed').disabled == false )
   			{
		 		gid("MF:txtDeviationAllowed").focus();	
			}
			else if (gid('MF:txtDeviationAmount').disabled == false )
			{
				gid("MF:txtDeviationAmount").focus();
			}
			else
			{
				gid("MF:lstAmountQualifier").focus();
			}
			//ADDED ON 16/10/2018 END
		}
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			
	function validateEnhancementReductionAmount1()
	{
		if(gid("MF:txtLCEnhancementReductionNochange").value!="")
	    {
	    	if(gid("MF:txtEnhancementReductionAmount1").value=="")
	      	{
	       		setMsg(BLANK_CHECK);
		   		gid("MF:txtEnhancementReductionAmount1").focus();
		   		return;
	      	}
	        else if(gid("MF:txtEnhancementReductionAmount1").value==0)
	      	{
	        	setMsg(ZERO_CHECK);
		   		gid("MF:txtEnhancementReductionAmount1").focus();
		   		return;
	      	}
	      	else if(gid("MF:txtLCEnhancementReductionNochange").value=="E")
	      	{
	      		gid("MF:txtAmendedLCAmount").value=gid("MF:txtLCAmount2").value
	       		gid("MF:txtAmendedLCAmount1").value=(unFormat(gid("MF:txtLCAmount21").value)*1)+(unFormat(gid("MF:txtEnhancementReductionAmount1").value)*1);
	       		setAmount('MF:txtAmendedLCAmount1',gid("MF:txtAmendedLCAmount1").value);
	       		
	       		//ADDED ON 31/10/2018 START
	       		if(gid('MF:txtDeviationAllowed').disabled == false )
				gid("MF:txtDeviationAllowed").focus(); 
					else
	       		gid("MF:lstAmountQualifier").focus();	
	       			
	       			//ADDED ON 31/10/2018 END   
	      	}  
	      	else if(gid("MF:txtLCEnhancementReductionNochange").value=="R")
	      	{
	      	 	//Changes P.Subramani-Chn-01/04/2008 Beg
		        if( unFormat(gid("MF:txtEnhancementReductionAmount1").value)*1 >= unFormat(gid("MF:txtLCAmount21").value)*1 )
		        {
		       	 	setMsg("");
		       	 	setMsg("Reduction Amount Should be < LC Amount");
		       	 	gid("MF:txtEnhancementReductionAmount1").focus();
		        }
		        //Changes P.Subramani-Chn-01/04/2008 End
	       		else
	       		{
		       		gid("MF:txtAmendedLCAmount").value=gid("MF:txtLCAmount2").value;
		       		gid("MF:txtAmendedLCAmount1").value=(unFormat(gid("MF:txtLCAmount21").value)*1)-(unFormat(gid("MF:txtEnhancementReductionAmount1").value)*1);
			        setAmount('MF:txtAmendedLCAmount1',gid("MF:txtAmendedLCAmount1").value);	
			        gid("MF:txtDeviationAllowed").focus();       
	       		}
	      	}
	  }
	  else
	  {
	  	gid("MF:txtDeviationAllowed").focus();       
	  }
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			
	function validateEnhancementReductionAmount()
	{
		if(gid("MF:txtEnhancementReductionAmount").value=="")
		{
			setMsg(BLANK_CHECK);
			gid("MF:txtEnhancementReductionAmount").focus();
			return;
		}
		if(gid("MF:txtEnhancementReductionAmount").value==0)
		{
			setMsg(ZERO_CHECK);
			gid("MF:txtEnhancementReductionAmount").focus();
			return;
		}
		gid("MF:txtEnhancementReductionAmount1").focus();				
    }
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			
	function validateDeviationAllowed()
	{
		if(gid("MF:txtDeviationAllowed").value!="")
		{
			if(gid("MF:txtDeviationAllowed").value>100)
			{
				setMsg("Deviation Allowed Should Be Less Than 100");
				gid("MF:txtDeviationAllowed").focus();
				return;
			}
		}
		if(gid("MF:txtDeviationAllowed").value>0)
		{
			calDeviAmt();
			gid('MF:txtDeviationAmount').value=res;
		}
		else
		{
			gid('MF:txtDeviationAmount').value="";
			gid('MF:txtDeviationAllowed').value=0;
			setAmount('MF:txtDeviationAllowed',gid("MF:txtDeviationAllowed").value);	
		}
		gid("MF:txtDeviationAllowed1").focus();				
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			
	function validateDeviationAllowed1()
	{
	
	    
		if(gid("MF:txtDeviationAllowed1").value!="")
		{	
			if(gid("MF:txtDeviationAllowed1").value>100)
			{	
				setMsg("Deviation Allowed Should Be Less Than 100");
				gid("MF:txtDeviationAllowed1").focus();
				return;
			}
		}
		if(gid("MF:txtDeviationAllowed").value>0)
		{
			 //calDeviAmt();
			 gid('MF:txtDeviationAmount').value=res;
			 //gid("MF:lstAmountQualifier").focus();COMMENTED ON 16/10/2018
			 //gid("MF:txtDeviationAmount").focus();COMMENTED ON 16/10/2018
		}
		else
		{
			gid('MF:txtDeviationAllowed1').value=0;
			setAmount('MF:txtDeviationAllowed1',gid("MF:txtDeviationAllowed1").value);	
			//gid("MF:txtDeviationAmount").focus();COMMENTED ON 16/10/2018
		}
		
		//ADDED ON 16/10/2018 START
			if (gid('MF:txtDeviationAmount').disabled == false )
			{
				validateDeviationAmount();
			}
			else
			{
				gid("MF:lstAmountQualifier").focus();
			}
		//ADDED ON 16/10/2018 END
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			
	function calDeviAmt()
	{
		 var pdevi=unFormat(gid("MF:txtDeviationAllowed").value)*1;
		 var lcamt=unFormat(gid("MF:txtAmendedLCAmount1").value)*1;
		 res=(pdevi/100)*(lcamt);
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			
	function validateDeviationAmount()
	{
	 	if(unFormat(gid("MF:txtDeviationAmount").value)*1!=0)
	 	{
	 		gid('MF:txtDeviationAmount').value=res;
			gid("MF:txtPositiveAfterAmd").value=gid("MF:txtDeviationAmount").value;
		}
		else
		{
			gid("MF:txtDeviationAmount").value=0;
		}
	   	gid("MF:lstAmountQualifier").focus();	
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			
	function validateAmountQualifier()
	{
	
	   if(!checkMaxCredit()){
	        return false;
	   }
		if(gid("MF:lstAmountQualifier").value=="" && gid("MF:chkPerTolr").checked == true )//ADDED ON 13/11/2018
		{
			
			setMsg(OPTION_MESSAGE);
			gid("MF:lstAmountQualifier").focus();
			return;
		}
		focusTextArea("MF:txtAdditionalAmountsCovered");	
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			
	function validateAdditionalAmountsCovered()
	{
	  setTabfocus("maintab","tcontent9");
	  gid("MF:txtTermsofPrice").focus();	
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			
	function validateTermsofPrice()
	{
  		 if(gid("MF:txtTermsofPrice").value=="")
		 {	
			setMsg(BLANK_CHECK);
			gid("MF:txtTermsofPrice").focus();
			return;
		 }
		 else
		 {
			 objXMLApplet.clearMap();
			 objXMLApplet.setValue("Package","panacea.OLCaction.eolcamdval");
			 objXMLApplet.setValue("Method","olcTermsOfPricekeypress");
			 objXMLApplet.setValue("ValidateToken", "true");
			 objXMLApplet.setValue("TERMS_OF_PRICE",trim(gid('MF:txtTermsofPrice').value));
			 objXMLApplet.sendAndReceive();
			 if(objXMLApplet.getValue("ErrorMsg") != "")
			 {
				  setMsg(objXMLApplet.getValue("ErrorMsg"));
				  gid('MF:txtTermsofPrice').focus();
				  return;  
			 }
			 else
			 {
				 gid('MF:outputlblTermsofPrice').innerText=objXMLApplet.getValue("TERMS_DESCN");
			   	 setTabfocus("maintab","tcontent3");
			     gid("MF:txtLCEnhancementReductionNochange").focus();
		     }
		 }
		 setTabfocus("maintab","tcontent9");
	     //gid("MF:txtLastDateforNegotiation").focus();	COMMENTED ON 16/10/2018
	     //ADDED ON 16/01/2018 START
	     if(gid('MF:txtLastDateforNegotiation').disabled == false )
   			{
		 		gid("MF:txtLastDateforNegotiation").focus();	
			}
			else 
			{
				gid("MF:txtPlaceofExpiry").focus();
			}
	   //ADDED ON 16/01/2018 END
	}
	
	
      //ADDED BY PRASHANTH ON 14 MARCH 2019
	function checkOldValueExpiryDate(){
		var currentvalue=gid("MF:txtLastDateforNegotiation").value;
		var oldValue=oldValueExpiryDate;
		//Changes Sanjay 02-07-2019 Begin
		var currentcheckbox=gid("MF:chkExpiryDate").checked;
		var oldcheckbox=oldchkExpiryDate;
		if(currentcheckbox!=oldcheckbox)
		{
		//Changes Sanjay 02-07-2019 End
			if(gid("MF:chkExpiryDate").checked==true)
	   		{
	   		  if(currentvalue!="" && oldValue!="")
	   		  {
	   		    if(currentvalue==oldValue)
	   		    {
	   		      	setMsg("Change the value of F31E Expiry Date When Change in F31E Expiry Date checkbox is Checked");
			   		gid("MF:txtLastDateforNegotiation").focus();
			   		return false;
	   		    }
	   		  }
	   		}
	   	}
  		return true;
	}
	
	
	
	function checkOldValueIncreaseDecDC(){
		var currentvalue=gid("MF:txtLCEnhancementReductionNochange").value;
		var oldValue=oldValueIncDecDC;
		//Changes Sanjay 02-07-2019 Begin
		var currentcheckbox=gid("MF:chkIncDec").checked;
		var oldcheckbox=oldchkIncDec;
		if(currentcheckbox!=oldcheckbox)
		{
		//Changes Sanjay 02-07-2019 End
			if(gid("MF:chkIncDec").checked==true)
	   		{
	   		  if(currentvalue!="" && oldValue!="")
	   		  {
	   		    if(currentvalue==oldValue)
	   		    {
	   		      	setMsg("Change the value of F32B/F32D Increase/Decrease Of DC  When Change in F32B/F32DIncrease/Decrease Of DC is Checked");
			   		gid("MF:txtLCEnhancementReductionNochange").focus();
			   		return false;
	   		    }
	   		  }
	   		}
	   	}
  		return true;
	}
	
	
	
	
	function checkMaxCredit(){
		var currentvalue1=gid("MF:txtDeviationAllowed").value;
	    var currentvalue2=gid("MF:txtDeviationAllowed1").value;
	    var currentvalue3=gid("MF:lstAmountQualifier").value;
		var oldValue1=oldDevAmt1;
		var oldValue2=oldDevAmt2;
		var oldValue3=oldMaxCredAmt;
		//Changes Sanjay 02-07-2019 Begin
		var currentcheckbox=gid("MF:chkPerTolr").checked;
		var oldcheckbox=oldchkPerTolr;
		if(currentcheckbox!=oldcheckbox)
		{
		//Changes Sanjay 02-07-2019 End 
			if(gid("MF:chkPerTolr").checked==true)
	   		{
	   		  if(currentvalue1!="" && oldValue1!=""  ||  currentvalue2!="" && oldValue2!=""   ||  currentvalue3!="" && oldValue3!="")
	   		  {
	   		    if(currentvalue1==oldValue1 && currentvalue2==oldValue2   && currentvalue3==oldValue3)
	   		    {
	   		      	setMsg("Change the value of F39A Percentage Of Tolerance/F39B Max Credit Amount  When Change in F39A/F39B Percentage Tolerance/Max Credit Amount is checked");
			   		gid("MF:lstAmountQualifier").focus();
			   		return false;
	   		    }
	   		  }
	   		}
	   	}
  		return true;
	}
	
	
	
	
	function checkShipPeriodDup(){
		var currentvalue1=gid("MF:txtLatestDateofShipment").value;
	    var currentvalue2=gid("MF:txtShipmentPeriodSchedule").value;
		var oldValue1=oldLateDateShip;
		var oldValue2=shipPer;
		//Changes Sanjay 02-07-2019 Begin
		var currentcheckbox=gid("MF:chkShipPeriod").checked;
		var oldcheckbox=oldchkShipPeriod;
		if(currentcheckbox!=oldcheckbox)
		{
		//Changes Sanjay 02-07-2019 End
			if(gid("MF:chkShipPeriod").checked==true)
	   		{
	   		  if(currentvalue1!="" && oldValue1!=""  ||  currentvalue2!="" && oldValue2!="")
	   		  {
	   		    if(currentvalue1==oldValue1 && currentvalue2==oldValue2)
	   		    {
	   		      	setMsg("Change the value of F39A Percentage Of Latest Date of Shipment/Shipment Period  When Change in F44D,F44C Last Date Of Shipment and Period is checked");
			   		gid("MF:txtShipmentPeriodSchedule").focus();
			   		return false;
	   		    }
	   		  }
	   		}
	   	}
  		return true;
	}
	
	
	
	function checkOldValuBen(){
		
		var currentvalue1=gid("MF:txtBeneficiaryCode").value;
		var oldValue1=oldBenCode;
		var currentvalue2=gid("MF:txtBeneficiaryName").value;
		var oldValue2=oldBenName;
		var currentvalue3=gid("MF:txtAddress1").value;
		var oldValue3=oldBenAddress;
		var currentvalue4=gid("MF:txtBeneficiaryCountryCode").value;
		var oldValue4=oldBenCountry;
		//Changes Sanjay 02-07-2019 Begin
		var currentcheckbox=gid("MF:chkChangeofBeneficiary").checked;
		var oldcheckbox=oldchkChangeofBeneficiary;
		if(currentcheckbox!=oldcheckbox)
		{
		//Changes Sanjay 02-07-2019 End
			if(gid("MF:chkChangeofBeneficiary").checked==true)
	   		{
	   		  if(currentvalue1!="" && oldValue1!=""   ||  currentvalue2!="" && oldValue2!=""   ||  currentvalue3!="" && oldValue3!="")
	   		  {
	   		    if(currentvalue1==oldValue1  && currentvalue2==oldValue2    && currentvalue3==oldValue3    && currentvalue4==oldValue4)
	   		    {
	   		      	setMsg("Atleast one of the details of beneficiary should be changed when change in beneficiary is checked");
			   		gid("MF:txtBeneficiaryCountryCode").focus();
			   		return false;
	   		    }
	   		  }
	   		}
   		}
  			return true;
	}
	
	
	
	
	function checkOldValuApplicant(){
		var currentvalue1=gid("MF:txtApplCode").value;
		var oldValue1=oldApplCode;
		var currentvalue2=gid("MF:txtApplName").value;
		var oldValue2=oldApplName;
		var currentvalue3=gid("MF:txtApplAddress").value;
		var oldValue3=oldApplAddress;
		
		//Changes Sanjay 02-07-2019 Begin
		var currentcheckbox=gid("MF:chkChgAppl").checked;
		var oldcheckbox=oldchkChgAppl;
		if(currentcheckbox!=oldcheckbox)
		{
		//Changes Sanjay 02-07-2019 End
			if(gid("MF:chkChgAppl").checked==true)
	   		{
	   		  if(currentvalue1!="" && oldValue1!=""   ||  currentvalue2!="" && oldValue2!=""   ||  currentvalue3!="" && oldValue3!="")
	   		  {
	   		    if(currentvalue1==oldValue1  && currentvalue2==oldValue2    && currentvalue3==oldValue3)
	   		    {
	   		      	setMsg("Atleast one of the details of appllicant should be changed when change in applicant is checked");
			   		gid("MF:txtApplAddress").focus();
			   		return false;
	   		    }
	   		  }
	   		}
	   	}
  		return true;
	}
	
	
	
	
	function checkOldValueFormOfDC(){
		var currentvalue=gid("MF:lstcredit").value;
		var oldValue=oldFormOfDC;
		//Changes Sanjay 02-07-2019 Begin
		var currentcheckbox=gid("MF:chkChgFormDc").checked;
		var oldcheckbox=oldchkChgFormDc;
		if(currentcheckbox!=oldcheckbox)
		{
		//Changes Sanjay 02-07-2019 End
			if(gid("MF:chkChgFormDc").checked==true)
	   		{
	   		  if(currentvalue!="" && oldValue!="")
	   		  {
	   		    if(currentvalue==oldValue)
	   		    {
	   		      	setMsg("Change the value of Form Of DC  When Change in Form Of DC is Checked");
			   		gid("MF:lstcredit").focus();
			   		return false;
	   		    }
	   		  }
	   		}
	   	}
  		return true;
	}
	
	
	
	function checkOldValueApplRules(){
		var currentvalue=gid("MF:lstAppRule").value;
		var oldValue=lstAppRule_backup;
		//Changes Sanjay 02-07-2019 Begin
		var currentcheckbox=gid("MF:chkChgApplRules").checked;
		var oldcheckbox=oldchkChgApplRules;
		if(currentcheckbox!=oldcheckbox)
		{
		//Changes Sanjay 02-07-2019 End
			if(gid("MF:chkChgApplRules").checked==true)
	   		{
	   		  if(currentvalue!="" && oldValue!="")
	   		  {
	   		    if(currentvalue==oldValue)
	   		    {
	   		      	setMsg("Change the value of Appl Rules When Change in Appl Rules is Checked");
			   		gid("MF:lstAppRule").focus();
			   		return false;
	   		    }
	   		  }
	   		}
	   	}
  		return true;
	}
	
	//ADDED BY PRASHANTH ON 14 MARCH 2019
	
	
	function checkOldValueAvailable(){
		var currentvalue1=gid("MF:lstAvl").value;
		var oldValue1=lstAvl_backup;
		var currentvalue2=gid("MF:lstAvlBICdtl").value;
		var oldValue2=lstAvlBICdtl_backup;
		var currentvalue3=gid("MF:txtAvlBicCode").value;
		var oldValue3=txtAvlBicCode_backup;
		var currentvalue4=gid("MF:txtAvlBicBrn").value;
		var oldValue4=txtAvlBicBrn_backup;
		var currentvalue5=gid("MF:txtAvlBankName").value;
		var oldValue5=txtAvlBankName_backup;
		var currentvalue6=gid("MF:txtAvlAcnt").value;
		var oldValue6=txtAvlAcnt_backup;
		var currentvalue7=(gid("MF:txtAvlAddress").value).replace(/\r\n/gi,"");
		var oldValue7=txtAvlAddress_backup.replace(/\r\n/gi,"");
		var currentvalue8=gid("MF:txtAvlCntry").value;
		var oldValue8=txtAvlCntry_backup;
		var currentvalue9=(gid("MF:txtDraft").value).replace(/\r\n/gi,"");
		var oldValue9=txtDraft_backup.replace(/\r\n/gi,"");
		//Changes Sanjay 02-07-2019 Begin
		var currentcheckbox=gid("MF:chkChgAvlWith").checked;
		var oldcheckbox=oldchkChgAvlWith;
		if(currentcheckbox!=oldcheckbox)
		{
		//Changes Sanjay 02-07-2019 End
			if(gid("MF:chkChgAvlWith").checked==true)
	   		{
	   		  if(currentvalue1!="" && oldValue1!=""   ||  currentvalue2!="" && oldValue2!=""   ||  currentvalue3!="" && oldValue3!=""   ||  currentvalue4!="" && oldValue4!=""   ||  currentvalue5!="" && oldValue5!=""   ||  currentvalue6!="" && oldValue6!=""   ||  currentvalue7!="" && oldValue7!=""   ||  currentvalue8!="" && oldValue8!=""   ||  currentvalue9!="" && oldValue9!="")
	   		  {
	   		    if(currentvalue1==oldValue1  && currentvalue2==oldValue2    && currentvalue3==oldValue3  && currentvalue4==oldValue4    && currentvalue5==oldValue5  && currentvalue6==oldValue6    && currentvalue7==oldValue7  && currentvalue8==oldValue8    && currentvalue9==oldValue9)
	   		    {
	   		      	setMsg("Change the value of Available with When Change in Available with is Checked");
			   		gid("MF:txtDraft").focus();
			   		return false;
	   		    }
	   		  }
	   		}
	   	}
  		return true;
	}
	
	function checkOldValueDrawee(){					
		var currentvalue1=gid("MF:chkDrawee").value;
		var oldValue1="";
		if(chkDrawee_backup == "1")
		{
			oldValue1="true";
		}
		else
		{
			oldValue1="false";
		}
		var currentvalue2=gid("MF:lstDrwBICdtl").value;
		var oldValue2=lstDrwBICdtl_backup;
		var currentvalue3=gid("MF:txtDrwBicCode").value;
		var oldValue3=txtDrwBicCode_backup;
		var currentvalue4=gid("MF:txtDrwBicBrn").value;
		var oldValue4=txtDrwBicBrn_backup;
		var currentvalue5=gid("MF:txtDrwBankName").value;
		var oldValue5=txtDrwBankName_backup;
		var currentvalue6=gid("MF:txtDrwAcnt").value;
		var oldValue6=txtDrwAcnt_backup;
		var currentvalue7=(gid("MF:txtDrwAddress").value).replace(/\r\n/gi,"");
		var oldValue7=txtDrwAddress_backup.replace(/\r\n/gi,"");
		var currentvalue8=gid("MF:txtDrwCntry").value;
		var oldValue8=txtDrwCntry_backup;
		var currentvalue9=(gid("MF:txtMixedPaydtl").value).replace(/\r\n/gi,"");
		var oldValue9=txtMixedPaydtl_backup.replace(/\r\n/gi,"");
		var currentvalue10=(gid("MF:txtDeferPaydtl").value).replace(/\r\n/gi,"");
		var oldValue10=txtDeferPaydtl_backup.replace(/\r\n/gi,"");
		//Changes Sanjay 02-07-2019 Begin
		var currentcheckbox=gid("MF:chkCgDrawee").checked;
		var oldcheckbox=oldchkCgDrawee;
		if(currentcheckbox!=oldcheckbox)
		{
		//Changes Sanjay 02-07-2019 End
			if(gid("MF:chkCgDrawee").checked==true)
	   		{
	   		  if(currentvalue1!="" && oldValue1!=""   ||  currentvalue2!="" && oldValue2!=""   ||  currentvalue3!="" && oldValue3!=""   ||  currentvalue4!="" && oldValue4!=""   ||  currentvalue5!="" && oldValue5!=""   ||  currentvalue6!="" && oldValue6!=""   ||  currentvalue7!="" && oldValue7!=""   ||  currentvalue8!="" && oldValue8!=""   ||  currentvalue9!="" && oldValue9!=""  ||  currentvalue10!="" && oldValue10!="" )
	   		  {
	   		    if(currentvalue1==oldValue1  && currentvalue2==oldValue2    && currentvalue3==oldValue3  && currentvalue4==oldValue4    && currentvalue5==oldValue5  && currentvalue6==oldValue6    && currentvalue7==oldValue7  && currentvalue8==oldValue8    && currentvalue9==oldValue9  && currentvalue10==oldValue10)
	   		    {
	   		      	setMsg("Change the value of Drawee/Payment When Change in Drawee/Payment is Checked");
			   		gid("MF:txtDeferPaydtl").focus();
			   		return false;
	   		    }
	   		  }
	   		}
	   	}
  		return true;
	}
	
	function checkOldValueReimbursement(){					
		var currentvalue1=gid("MF:chkReimb").value;
		var oldValue1="";
		if(chkReimb_backup == "1")
		{
			oldValue1="true";
		}
		else
		{
			oldValue1="false";
		}
		var currentvalue2=gid("MF:lstReimbBank").value;
		var oldValue2=lstReimbBank_backup;
		var currentvalue3=gid("MF:txtReimBicCode").value;
		var oldValue3=txtReimBicCode_backup;
		var currentvalue4=gid("MF:txtReimBicBrn").value;
		var oldValue4=txtReimBicBrn_backup;
		var currentvalue5=gid("MF:txtReimBankName").value;
		var oldValue5=txtReimBankName_backup;
		var currentvalue6=gid("MF:txtReimAcnt").value;
		var oldValue6=txtReimAcnt_backup;
		var currentvalue7=(gid("MF:txtReimAddress").value).replace(/\r\n/gi,"");
		var oldValue7=txtReimAddress_backup.replace(/\r\n/gi,"");
		var currentvalue8=gid("MF:txtReimCntry").value;
		var oldValue8=txtReimCntry_backup;
		//Changes Sanjay 02-07-2019 Begin
		var currentcheckbox=gid("MF:chkChgReimbus").checked;
		var oldcheckbox=oldchkChgReimbus;
		if(currentcheckbox!=oldcheckbox)
		{
		//Changes Sanjay 02-07-2019 End
			if(gid("MF:chkChgReimbus").checked==true)
	   		{
	   		  if(currentvalue1!="" && oldValue1!=""   ||  currentvalue2!="" && oldValue2!=""   ||  currentvalue3!="" && oldValue3!=""   ||  currentvalue4!="" && oldValue4!=""   ||  currentvalue5!="" && oldValue5!=""   ||  currentvalue6!="" && oldValue6!=""   ||  currentvalue7!="" && oldValue7!=""   ||  currentvalue8!="" && oldValue8!="")
	   		  {
	   		    if(currentvalue1==oldValue1  && currentvalue2==oldValue2    && currentvalue3==oldValue3  && currentvalue4==oldValue4    && currentvalue5==oldValue5  && currentvalue6==oldValue6    && currentvalue7==oldValue7  && currentvalue8==oldValue8 )
	   		    {
	   		      	setMsg("Change the value of  Reimbursement When Change in  Reimbursement is Checked");
			   		return false;
	   		    }
	   		  }
	   		}
	   	}
  		return true;
	}
	
	function checkOldValueAdvise(){
		var currentvalue1=gid("MF:chkAdvise").value;
		var oldValue1="";
		if(chkAdvise_backup == "1")
		{
			oldValue1="true";
		}
		else
		{
			oldValue1="false";
		}
		var currentvalue2=gid("MF:lstAdviseBank").value;
		var oldValue2=lstAdviseBank_backup;
		var currentvalue3=gid("MF:txtAdviseBicCode").value;
		var oldValue3=txtAdviseBicCode_backup;
		var currentvalue4=gid("MF:txtAdviseBicBrn").value;
		var oldValue4=txtAdviseBicBrn_backup;
		var currentvalue5=gid("MF:txtAdviseBankName").value;
		var oldValue5=txtAdviseBankName_backup;
		var currentvalue6=gid("MF:txtAdviseAcnt").value;
		var oldValue6=txtAdviseAcnt_backup;
		var currentvalue7=(gid("MF:txtAdviseAddress").value).replace(/\r\n/gi,"");
		var oldValue7=txtAdviseAddress_backup.replace(/\r\n/gi,"");
		var currentvalue8=gid("MF:txtAdviseCntry").value;
		var oldValue8=txtAdviseCntry_backup;
		//Changes Sanjay 02-07-2019 Begin
		var currentcheckbox=gid("MF:chkCgAdvBk").checked;
		var oldcheckbox=oldchkCgAdvBk;
		if(currentcheckbox!=oldcheckbox)
		{
		//Changes Sanjay 02-07-2019 End
			if(gid("MF:chkCgAdvBk").checked==true)
	   		{
	   		  if(currentvalue1!="" && oldValue1!=""   ||  currentvalue2!="" && oldValue2!=""   ||  currentvalue3!="" && oldValue3!=""   ||  currentvalue4!="" && oldValue4!=""   ||  currentvalue5!="" && oldValue5!=""   ||  currentvalue6!="" && oldValue6!=""   ||  currentvalue7!="" && oldValue7!=""   ||  currentvalue8!="" && oldValue8!="")
	   		  {
	   		    if(currentvalue1==oldValue1  && currentvalue2==oldValue2    && currentvalue3==oldValue3  && currentvalue4==oldValue4    && currentvalue5==oldValue5  && currentvalue6==oldValue6    && currentvalue7==oldValue7  && currentvalue8==oldValue8 )
	   		    {
	   		      	setMsg("Change the value of  Advising Bank When Change in  Advising Bank is Checked");
			   		return false;
	   		    }
	   		  }
	   		}
	   	}
  		return true;
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			
	function validateLastDateforNegotiation()
	{
        
        //ADDED BY PRASHANTH ON 14 MARCH 2019
        if(!checkOldValueExpiryDate())
        {
          return false;
        }
       //ADDED BY PRASHANTH ON 14 MARCH 2019
        
        //ADDED ON 16/10/2018 START
        var _expiryChecked ="";
		if(gid("MF:chkExpiryDate").checked==true)
   		{
   			_expiryChecked ="1";
   			if(gid("MF:txtLastDateforNegotiation").value=="")
   			{
   				if(gid("MF:txtReferenceType").value=="OLC")
   					setMsg("Should not be blank if F31E Expiry Date is checked");
   				else
   					setMsg("Should not be blank if Last Date for Negotiation is checked");
		   		gid("MF:txtLastDateforNegotiation").focus();
		   		return;
   			}
   			
   		}
   		else
   		{
   			_expiryChecked ="0";
   			if(gid("MF:txtLastDateforNegotiation").value != "" )//&& gid("MF:txtReferenceType").value=="OLC")
   			{
   				
   				if(gid("MF:txtReferenceType").value=="OLC")
   					setMsg("F31E Expiry Date is not checked");
   				else
   				setMsg("Last Date for Negotiation is not checked");
   				
		   		gid("MF:txtLastDateforNegotiation").focus();
		   		return;
   			}
   		}
   		//ADDED ON 16/10/2018 END
        
        if(trim(gid('MF:txtLastDateforNegotiation').value)=="")
   		{	
   			//Changes P.Subramani-Chn-29/02/2008
	   		setMsg("");
	   		setMsg(BLANK_CHECK);
	     	gid('MF:txtLastDateforNegotiation').focus();
	    }
     	else
     	{
   	   		dateobj=parseDate(gid('MF:txtLastDateforNegotiation').value,"true");
       	   	if(dateobj == null)
	   		{
	   			setMsg(INVALIDDATE);
				gid('MF:txtLastDateforNegotiation').focus();
			   	return;		        
	   		}
	    	dateobj = formatDate(dateobj,'dd-MM-yyyy');
	  		gid('MF:txtLastDateforNegotiation').value =dateobj;
	  		dateok = isDate(gid('MF:txtLastDateforNegotiation').value,'dd-MM-yyyy');
			//Changes P.Subramani-Chn-25/02/2008 Beg
			if (dateok == 1)
	   		{
		   		setMsg(INVALIDDATE);
		   		gid('MF:txtLastDateforNegotiation').focus();
		   		return ;
		   	}
	   		var dateobj=parseDate(gid('MF:txtLastDateforNegotiation').value,"true");
        	dateobj = formatDate(dateobj,'dd-MM-yyyy');
			gid('MF:txtLastDateforNegotiation').value =dateobj;	
			dateok =compareDates(dateobj,'dd-MM-yyyy',gid('MF:txtAmendmentEntryDate').value,'dd-MM-yyyy');
			if (dateok == 0) 
			{
				setMsg("Last date of negotiation should be >= Amendment Date");
				gid('MF:txtLastDateforNegotiation').focus();
				return ;
			}
			//Changes P.Subramani-Chn-25/02/2008 End		
	  		else if (dateok == -1 ) 
	   		{
	   			setMsg(INVALIDDATE);
		   		gid('MF:txtLastDateforNegotiation').focus();
		   		return ;
	   		}
		   	else
	   		{
	   			objXMLApplet.clearMap();
	 			objXMLApplet.setValue("Package","panacea.OLCaction.eolcamdval");
	 			objXMLApplet.setValue("Method","olclastDatekeypress");
	 			objXMLApplet.setValue("ValidateToken", "true");
	 			objXMLApplet.setValue("LAST_DATE_NEGOCIATION",trim(gid('MF:txtLastDateforNegotiation').value));
	 			objXMLApplet.setValue("AMD_DATE",trim(gid('MF:txtAmendmentEntryDate').value));
	 			//ADDED ON 16/10/2018 START
	 			objXMLApplet.setValue("AMEND_FIELDNO","1");
	 			objXMLApplet.setValue("AMEND_CHKBOX",_expiryChecked);
	 		//ADDED ON 16/10/2018 END
	 			objXMLApplet.sendAndReceive();
	 			if(objXMLApplet.getValue("ErrorMsg") != "")
	 			{
		  			setMsg(objXMLApplet.getValue("ErrorMsg"));
		  			gid('MF:txtLastDateforNegotiation').focus();
		  			return;  
	 			}
	 			else
	 			{
	 				gid('MF:txtPlaceofExpiry').focus();
	 			}
	 		}
	   }
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			
	function validatePlaceofExpiry()
	{
	  	//gid("MF:txtLatestDateofShipment").focus();COMMENTED ON 16/10/2018
	     //ADDED ON 16/01/2018 START
	     if(gid('MF:txtLatestDateofShipment').disabled == false )
   			{
		 		gid("MF:txtLatestDateofShipment").focus();	
			}
			else 
			{
				gid("MF:txtPresentationDetails").focus();
			}
	   //ADDED ON 16/01/2018 END
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			
	function validateLatestDateofShipment()
	{
        
        //ADDED ON 16/10/2018 START
       /* var _shipChecked ="1";
		if(gid("MF:chkShipPeriod").checked==true)
   		{
   			if(gid("MF:txtLatestDateofShipment").value=="")
   			{
   				if(gid("MF:txtReferenceType").value=="OLC")
   					setMsg("Should be selected if F44D,F44C Last Date Of Shipment and Period is checked");
   				else
   					setMsg("Should be selected if Last Date Of Shipment and Period is checked");
		   		gid("MF:txtLatestDateofShipment").focus();
		   		return;
   			}
   		}
   		else
   		{
   			_shipChecked ="0";
   			if(gid("MF:txtLatestDateofShipment").value != "" ) //&& gid("MF:txtReferenceType").value=="OLC")
   			{
   				if(gid("MF:txtReferenceType").value=="OLC")
   					setMsg("F44D,F44C Last Date Of Shipment and Period is not checked");
   				else
   					setMsg("Latest Date of Shipment and Period is not checked");
   				
		   		gid("MF:txtLatestDateofShipment").focus();
		   		return;
   			}
   		}*/
   		
   		var _shipChecked ="1";
   		if(gid("MF:chkShipPeriod").checked==true)
   		_shipChecked ="1";
   		else
   		_shipChecked ="0";
   		
   		
   		//ADDED ON 16/10/2018 END
        
        if(trim(gid('MF:txtLatestDateofShipment').value)!="")
        {
        	//Changes P.Subramani-Chn-29/02/2008
            dateobj=parseDate(gid('MF:txtLatestDateofShipment').value,"true");
       	   	if(dateobj == null)
		   	{
				setMsg(INVALIDDATE);
				gid('MF:txtLatestDateofShipment').focus();
				return;		        
		   	}
		    dateobj = formatDate(dateobj,'dd-MM-yyyy');
		  	gid('MF:txtLatestDateofShipment').value =dateobj;
		  	dateok = isDate(gid('MF:txtLatestDateofShipment').value,'dd-MM-yyyy');
			if (dateok == 0)
		   	{
				setMsg(INVALIDDATE);
				gid('MF:txtLatestDateofShipment').focus();
				return ;
  		   	}
  		   	//Changes P.Subramani-Chn-25/02/2008 Beg
  		   	dateok =compareDates(dateobj,'dd-MM-yyyy',gid('MF:txtAmendmentEntryDate').value,'dd-MM-yyyy');
		  	if (!(dateok == 2))
		   	{	
				setMsg("Latest Shipment Date Should Be > Amendment Entry Date");
				gid('MF:txtLatestDateofShipment').focus();
				return ;
		   	}
		   	dateok =compareDates(dateobj,'dd-MM-yyyy',gid('MF:txtLastDateforNegotiation').value,'dd-MM-yyyy');
		  	if (dateok == 2)
		   	{	
				setMsg("Latest Shipment Date Should Be <= Last Date for Negotiation ");
				gid('MF:txtLatestDateofShipment').focus();
				return ;
		   	}
	   		//Changes P.Subramani-Chn-25/02/2008 End 		
	  		if (dateok == -1 ) 
	   		{
	   			setMsg(INVALIDDATE);
		   		gid('MF:txtLatestDateofShipment').focus();
		   		return ;
	   		}
	   		else
   			{
      			objXMLApplet.clearMap();
	 			objXMLApplet.setValue("Package","panacea.OLCaction.eolcamdval");
	 			objXMLApplet.setValue("Method","olcLatestdateofShipmentkeypress");
	 			objXMLApplet.setValue("ValidateToken", "true");
	 			objXMLApplet.setValue("LATEST_DATE_OF_SHIPMENT",trim(gid('MF:txtLatestDateofShipment').value));
	 			objXMLApplet.setValue("ENTRY_DATE",trim(gid('MF:txtAmendmentEntryDate').value));
	 			objXMLApplet.setValue("NEGOCIATION_DATE",trim(gid('MF:txtLastDateforNegotiation').value)); 
	 			objXMLApplet.setValue("LC_SHPMNT_PERIOD",trim(gid('MF:txtShipmentPeriodSchedule').value)); 
	 			//ADDED ON 16/10/2018 START
	 			objXMLApplet.setValue("AMEND_FIELDNO","5");
	 			objXMLApplet.setValue("AMEND_CHKBOX",_shipChecked);
	 			//ADDED ON 16/10/2018 END
	 			objXMLApplet.sendAndReceive();
	 			if(objXMLApplet.getValue("ErrorMsg") != "")
	 			{
		  			setMsg(objXMLApplet.getValue("ErrorMsg"));
		  			gid('MF:txtLatestDateofShipment').focus();
		  			return;  
 				}
	 			else
	 			{
		 			gid('MF:txtShipmentPeriodSchedule').value="";
		 			gid('MF:txtPresentationDetails').focus();
		 			//gid('MF:txtShipmentPeriodSchedule').focus();//ADDED ON 16/10/2018
	 			}
 			}
  		}
		else
		{
			//gid('MF:txtPresentationDetails').value="";
		    gid('MF:txtShipmentPeriodSchedule').focus();
		    //gid('MF:txtShipmentPeriodSchedule').value="";
		   // gid('MF:txtPresentationDetails').focus();//ADDED ON 16/10/2018	
		}
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			
	function validateShipmentPeriodSchedule()
	{
	
	      if(!checkShipPeriodDup())
	      {
	        return false;
	      }
		 //ADDED ON 16/10/2018 START
		if(gid("MF:chkShipPeriod").checked==true)
   		{
   			if(trim(gid("MF:txtShipmentPeriodSchedule").value)=="" && gid("MF:txtLatestDateofShipment").value == "")
   			{
   				if(gid("MF:txtReferenceType").value=="OLC")
   					setMsg("Should not be blank if F44D,F44C Last Date Of Shipment and Period is checked");
   				else
   					setMsg("Should not be blank if Last Date Of Shipment and Period is checked");
		   		gid("MF:txtShipmentPeriodSchedule").focus();
		   		return;
   			}
   			
   		}
   		else
   		{
   			if(trim(gid("MF:txtShipmentPeriodSchedule").value) != "" || gid("MF:txtLatestDateofShipment").value != "" )// && gid("MF:txtReferenceType").value=="OLC")
   			{
   				if(gid("MF:txtReferenceType").value=="OLC")
   					setMsg("F44D,F44C Last Date Of Shipment and Period is not checked");
   				else
   					setMsg("Latest Date of Shipment and Period is not checked");
   				
		   		gid("MF:txtShipmentPeriodSchedule").focus();
		   		return;
   			}
   		}
   		//ADDED ON 16/10/2018 END
		
		gid('MF:txtPresentationDetails').focus();
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			
	function validatePresentationDetails()
	{
		if(gid('MF:txtPresentationDetails').value=="")
		{
			gid('MF:chkWithinValidityofLC').focus();
		}
		else
		{
		    setTabfocus("maintab","tcontent4");
		    gid('MF:chkUsanceInterestToBeBorneByApplicant').focus();
		}	
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			
	function validateWithinValidityofLC()
	{
		if(gid('MF:chkWithinValidityofLC').checked==true)
		{
			gid('MF:outlblWithinValidityofLC').innerText="Yes";
		}
		else
		{
			gid('MF:outlblWithinValidityofLC').innerText="No";
		}
		setTabfocus("maintab","tcontent4");
		gid('MF:chkUsanceInterestToBeBorneByApplicant').focus();
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			
	function validateUsanceInterestToBeBorneByApplicant()
	{
		if(gid('MF:chkUsanceInterestToBeBorneByApplicant').checked==true)
		{
			gid('MF:outlblUsanceInterestToBeBorneByApplicant').innerText="Yes";
		}
		else
		{
			gid('MF:outlblUsanceInterestToBeBorneByApplicant').innerText="No";
		}
		SetFocus(gridEolcamd,1,"ttype");
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			
	function validateConvRatetobasecurr()
	{
		if(gid('MF:txtConvRatetobasecurr').value=="")
		{
			setMsg(BLANK_CHECK);
			gid('MF:txtConvRatetobasecurr').focus();
			return ;
		}
		
		//Changes P.Subramani-Chn-19/08/2008 Beg
		else if(gid('MF:txtConvRatetobasecurr').value==0)
	  	{
	    	setMsg(ZERO_CHECK);
			gid('MF:txtConvRatetobasecurr').focus();
			return ;
	  	}
	  	else
	  	{
	  		objXMLApplet.clearMap();
			objXMLApplet.setValue("Package","panacea.OLCaction.eolcamdval");
			objXMLApplet.setValue("Method","olcConvToBaseCurrkeypress");
		    objXMLApplet.setValue("ValidateToken", "true");
		    objXMLApplet.setValue("LC_CURR",trim(gid('MF:txtLCAmount2').value));
		    objXMLApplet.setValue("BASE_CURR",baseCurrency);
		    objXMLApplet.setValue("ENC_RED",gid("MF:txtLCEnhancementReductionNochange").value);
		    //M.Murali - 16-05-2012  - Change - Beg
		     if(gid("MF:txtLCEnhancementReductionNochange").value=="E")
		     {		
		     //M.Murali - 16-05-2012  - Change - End
		    objXMLApplet.setValue("ADD_LC_LIAB_AMT",unFormat(gid('MF:txtAdditionalLCliabAmount1').value)*1);
		    //M.Murali - 16-05-2012  - Change - Beg
		    }
		    else if(gid("MF:txtLCEnhancementReductionNochange").value=="R")
		    {
		    objXMLApplet.setValue("RED_LC_LIAB_AMT",unFormat(gid('MF:txtReductionLCliabAmount1').value)*1);
		    }
		    //M.Murali - 16-05-2012  - Change - End
		    objXMLApplet.setValue("CONV_RATE",unFormat(gid('MF:txtConvRatetobasecurr').value)*1);
		    objXMLApplet.setValue("TOTAL_AFT_AMD",unFormat(gid('MF:txtTotalAfterAmd').value)*1);
			objXMLApplet.sendAndReceive();
			gid('MF:txtTotalLcAmtinbaseCurrafteramendment1').value=objXMLApplet.getValue("AMT_AGNST_CURR2");
			decilength="";
			decilength=objXMLApplet.getValue("DEC_LEN");
	  		gid('MF:txtAdditionallcamtinBasecurr').value=baseCurrency;
			gid('MF:txtTotalLcAmtinbaseCurrafteramendment').value=baseCurrency;
			gid('MF:txtReductioninLCliabinBasecurr').value=baseCurrency;
	  		gid('MF:txtChangeinLCliabinBasecurrency').value=baseCurrency;
	  		
	  		var W_liab_before_amend = parseFloat(unFormat(gid('MF:txttotalliabbasecurr').value));
	  		var A  = unFormat(gid('MF:txtConvRatetobasecurr').value)*1;
	  		var T2 = unFormat(gid('MF:txtTotalAfterAmd').value)*1;
	  		var W_liab_after_amend = (parseFloat(A)) * (parseFloat(T2)); 
	  		// M.Murali - Changes - 15-05-2102 - Beg
	  		//var Tot_liab = W_liab_after_amend - W_liab_before_amend;// Removed vinoth.S
	  		var Tot_liab = objXMLApplet.getValue("AMT_AGNST_CURR1");
	  		// M.Murali - Changes - 15-05-2102 - End
	  		gid('MF:totalliablccurrency').value = T2;
	  		// M.Murali - Changes - 15-05-2102 - Beg
	  		//gid('MF:totalliabbasecurrency').value = W_liab_after_amend;
	  		gid('MF:totalliabbasecurrency').value = Tot_liab;
	  		// M.Murali - Changes - 15-05-2102 - End
	  				
	  		if(Tot_liab > 0)
	  		{
				//Changes P.Subramani-Chn-10/09/2008 Beg
	  			gid('MF:txtAdditionallcamtinBasecurr1').value=Tot_liab;
				//Changes P.Subramani-Chn-10/09/2008 End
				//M.Jayakumaran 01/06/2011 Beg
				//	setAmount('MF:txtAdditionallcamtinBasecurr1',gid('MF:txtAdditionallcamtinBasecurr1').value);
				objXMLApplet.clearMap();
				objXMLApplet.setValue("Package","panacea.OLCaction.eolcamdval");
				objXMLApplet.setValue("Method","roundofkeypress");
		    	objXMLApplet.setValue("ValidateToken", "true");
		    	objXMLApplet.setValue("baseCurr",gid('MF:txtAdditionallcamtinBasecurr').value);
		    	objXMLApplet.setValue("CBD",gid('MF:txtLCDate').value);
	  			objXMLApplet.setValue("TOTAL_AMT",Tot_liab);
				objXMLApplet.setValue("TYPE","N");
				objXMLApplet.sendAndReceive();
				//gid('MF:txtAdditionallcamtinBasecurr1').value=objXMLApplet.getValue("ROUNDOFF_AMT");
				//M.Jayakumaran 01/06/2011 End
					if(gid("MF:txtLCEnhancementReductionNochange").value=="E")
	  				{
	  				gid('MF:txtAdditionallcamtinBasecurr1').value=objXMLApplet.getValue("ROUNDOFF_AMT");
	  				setAmount('MF:txtAdditionallcamtinBasecurr1',gid('MF:txtAdditionallcamtinBasecurr1').value);
		  			gid('MF:txtReductioninLCliabinBasecurr1').value=0;
		  			setAmount('MF:txtReductioninLCliabinBasecurr1',gid('MF:txtReductioninLCliabinBasecurr1').value);
		  			gid('MF:txtChangeinLCliabinBasecurrency1').value = gid('MF:txtAdditionallcamtinBasecurr1').value;
		  			} 
		  			else if(gid("MF:txtLCEnhancementReductionNochange").value=="R")
	  				{	
	  				gid('MF:txtReductioninLCliabinBasecurr1').value=objXMLApplet.getValue("ROUNDOFF_AMT");
	  				setAmount('MF:txtReductioninLCliabinBasecurr1',gid('MF:txtReductioninLCliabinBasecurr1').value);
		  			gid('MF:txtAdditionallcamtinBasecurr1').value=0;
		  			setAmount('MF:txtAdditionallcamtinBasecurr1',gid('MF:txtAdditionallcamtinBasecurr1').value);		  			
		  			gid('MF:txtChangeinLCliabinBasecurrency1').value = gid('MF:txtReductioninLCliabinBasecurr1').value;		  				  				
			     	}
	  		}
	  		else
	  		{
	  			gid('MF:txtAdditionallcamtinBasecurr1').value=0;
	  			setAmount('MF:txtAdditionallcamtinBasecurr1',gid('MF:txtAdditionallcamtinBasecurr1').value);
				//Changes P.Subramani-Chn-10/09/2008 Beg
				if(Tot_liab<0)
				{
					Tot_liab=Tot_liab*(-1);
				}
				//M.Jayakumaran-Chn-01/06/2011 Begin
	  			//gid('MF:txtReductioninLCliabinBasecurr1').value=Tot_liab;
	  			objXMLApplet.clearMap();
				objXMLApplet.setValue("Package","panacea.OLCaction.eolcamdval");
				objXMLApplet.setValue("Method","roundofkeypress");
		    	objXMLApplet.setValue("ValidateToken", "true");
		    	objXMLApplet.setValue("baseCurr",gid('MF:txtReductioninLCliabinBasecurr').value);
		    	objXMLApplet.setValue("CBD",gid('MF:txtLCDate').value);
	  			objXMLApplet.setValue("TOTAL_AMT",Tot_liab);
				objXMLApplet.setValue("TYPE","N");
				objXMLApplet.sendAndReceive();
				gid('MF:txtReductioninLCliabinBasecurr1').value=objXMLApplet.getValue("ROUNDOFF_AMT");
	  			//M.Jayakumaran-Chn-01/06/2011 End
	  			
	  			//M.Jayakumaran-Chn-23/05/2011 Begin
	  			if(gid('MF:txtReductioninLCliabinBasecurr1').value=="")
	  			{
	  				gid('MF:txtReductioninLCliabinBasecurr1').value=0;
	  			}
	  			//M.Jayakumaran-Chn-23/05/2011 End
				//Changes P.Subramani-Chn-10/09/2008 End
	  			setAmount('MF:txtReductioninLCliabinBasecurr1',gid('MF:txtReductioninLCliabinBasecurr1').value);
	  			gid('MF:txtChangeinLCliabinBasecurrency1').value = gid('MF:txtReductioninLCliabinBasecurr1').value;
	  			gid("MF:txtExcOverlimitDueCurrTrancurrAmt").value=0;
	  		}
	  		
	  		gid('MF:txtProductCode').value=productCode;
			gid('MF:outputProductCode').innerText=productDesc; 
			validateConvRate();
	  	}
	} 
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			 
	function validateConvRate()
	{
		if(gid('MF:txtLimitCurrency').value==baseCurrency)
		{
			gid('MF:txtConvRateToLimitCurrency').value=1;
			setAmount('MF:txtConvRateToLimitCurrency',gid('MF:txtConvRateToLimitCurrency').value);	
			gid('MF:txtChangeinLCLiabAmountInLimitCurrency1').value=gid('MF:txtChangeinLCliabinBasecurrency1').value;
			setAmount('MF:txtChangeinLCLiabAmountInLimitCurrency1',gid('MF:txtChangeinLCLiabAmountInLimitCurrency1').value);	
			decilength1="";
			decilength1=2;
			validatehiddenvalues();
			setTabfocus("maintab","tcontent5");
			gid('MF:ConversionNext').focus();
			//this is case when convrate=1
		}
		else
		{
			setTabfocus("maintab","tcontent5");
			gid('MF:txtConvRateToLimitCurrency').focus();
			//this is the case when convrate!= 1
		}
	} 
	//Changes P.Subramani-Chn-19/08/2008 End
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			 
	function validateConvRateToLimitCurrency()
	{
		if(gid('MF:txtConvRateToLimitCurrency').value=="")
		{
			setMsg(BLANK_CHECK);
			gid('MF:txtConvRateToLimitCurrency').focus();
			return ;
		}
		else if(gid('MF:txtConvRateToLimitCurrency').value==0)
		{
		    setMsg(ZERO_CHECK);
			gid('MF:txtConvRateToLimitCurrency').focus();
			return ;
		}
		else
		{
		  	objXMLApplet.clearMap();
			objXMLApplet.setValue("Package","panacea.OLCaction.eolcamdval");
			objXMLApplet.setValue("Method","olcConvToBaseCurrkeypress");
		    objXMLApplet.setValue("ValidateToken", "true");
		    objXMLApplet.setValue("LC_CURR",trim(gid('MF:txtLCAmount2').value));
		    objXMLApplet.setValue("BASE_CURR",trim(gid('MF:txtChangeinLCliabinBasecurrency').value));
		    objXMLApplet.setValue("ADD_LC_LIAB_AMT",unFormat(gid('MF:txtChangeinLCliabinBasecurrency1').value)*1);
		    objXMLApplet.setValue("CONV_RATE",unFormat(gid('MF:txtConvRateToLimitCurrency').value)*1);
		     //Vinoth S Changes on 24-Dec-2010 Beg For Rounding Off Value
		    objXMLApplet.setValue("TOTAL_AFT_AMD",unFormat(gid('MF:txtTotalAfterAmd').value)*1);
			objXMLApplet.setValue("TRAN_DATE",gid('MF:txtLcDate').value);
			objXMLApplet.setValue("TYPE","N");
 			//Vinoth S Changes on 24-Dec-2010 End
			objXMLApplet.sendAndReceive();
			if(objXMLApplet.getValue("ErrorMsg") != "")
			{
	  			setMsg(objXMLApplet.getValue("ErrorMsg"));
				gid('MF:txtConvRateToLimitCurrency').focus();
				return;  
			}
			else
			{
			    gid('MF:txtChangeinLCLiabAmountInLimitCurrency').value=gid('MF:txtLimitCurrency').value;
			    gid('MF:txtChangeinLCLiabAmountInLimitCurrency1').value=objXMLApplet.getValue("AMT_AGNST_CURR");
			    // setAmount('MF:txtChangeinLCLiabAmountInLimitCurrency1',objXMLApplet.getValue("AMT_AGNST_CURR"));
			    //To get the hidden values At Liability Details
			    decilength1="";
			    decilength1=objXMLApplet.getValue("DEC_LEN");
			    //Vinoth S Changes on 24-Dec-2010 Begin
			   // setAmount('MF:txtChangeinLCLiabAmountInLimitCurrency1',objXMLApplet.getValue("AMT_AGNST_CURR"));
			    gid('MF:txtChangeinLCLiabAmountInLimitCurrency1',objXMLApplet.getValue("AMT_AGNST_CURR12"));
			   //Vinoth S Changes on 24-Dec-2010 End
			    validatehiddenvalues();
			    gid('MF:LimitNext').focus();
			}	
		}
	}
//------------------------------------------Hidden---------------------------------------------------------------------------------------
	function validatehiddenvalues()
	{
		objXMLApplet.clearMap();
		objXMLApplet.setValue("Package","panacea.OLCaction.eolcamdval");
		objXMLApplet.setValue("Method","olcsCustLiabAccNumkeypress");
		objXMLApplet.setValue("ValidateToken", "true");
		objXMLApplet.setValue("LCPS_BRN_CODE",trim(gid('MF:txtBranchCode').value));
		objXMLApplet.setValue("LCPS_CUST_LIAB_ACC_NUM",trim(gid('MF:txtCustomerLCLiabilityAccount').value));
		objXMLApplet.setValue("LCPS_CUST_NUM",unFormat(gid('MF:txtCustomerNumber').value)*1);
		objXMLApplet.setValue("LCPS_LC_CURR",gid('MF:txtLCAmount').value);
		objXMLApplet.setValue("LCPS_LC_AMT",unFormat(gid('MF:txtLCAmount1').value)*1);
		objXMLApplet.setValue("PRODUCT_CODE",gid('MF:txtProductCode').value);
		objXMLApplet.setValue("LIMIT_CURR",gid('MF:txtLimitCurrency').value);
		objXMLApplet.sendAndReceive();
		if(objXMLApplet.getValue("ErrorMsg") != "")
		{
			setMsg(objXMLApplet.getValue("ErrorMsg"));
			gid('MF:txtConvRateToLimitCurrency').focus();
			return;  
		}
		else
		{
			//decilength1=objXMLApplet.getValue("DEC_LEN");
			gid('MF:txtInternalAccountNum').value=objXMLApplet.getValue("INTERNAL_ACNT_NUM");
			gid('MF:txtFacilityLimit').value=objXMLApplet.getValue("SANC_CURR");
			gid('MF:txtChangeinLCLiabAmountInLimitCurrency').value=objXMLApplet.getValue("SANC_CURR");
			setAmount('MF:txtFacilityLimit1',objXMLApplet.getValue("SANC_AMT"));
			gid('MF:txtOsbeforethisamendment').value=objXMLApplet.getValue("SANC_CURR");
			//setAmount('MF:txtOsbeforethisamendment1',objXMLApplet.getValue("OUTSTD_AMT"));
			gid('MF:txtLCPendingToBeSanctioned').value=objXMLApplet.getValue("SANC_CURR");
			
			//Changes P.Subramani-Chn-24/07/2008 Beg
			var outstd_amt;
			var outstd_amt1;
			outstd_amt = parseFloat(unFormat(objXMLApplet.getValue("OUTSTD_AMT")));
			//Changes P.Subramani-Chn-11/09/2008 Beg
			var  changelcliabamtlimtamt;
			changelcliabamtlimtamt=parseFloat(unFormat(gid("MF:txtChangeinLCLiabAmountInLimitCurrency1").value));
			//Changes P.Subramani-Chn-11/09/2008 End
			if(outstd_amt < 0)
			{
				outstd_amt1 = outstd_amt * (-1);
				//Changes P.Subramani-Chn-11/09/2008 Beg
				if(gid('MF:seluseroption').value=="A")
				{
					gid('MF:txtOsbeforethisamendment1').value=outstd_amt1;
				}
				else
				{
					if(outstd_amt1 > changelcliabamtlimtamt)
					{
						gid('MF:txtOsbeforethisamendment1').value=outstd_amt1-changelcliabamtlimtamt;
					}
					else
					{
						gid('MF:txtOsbeforethisamendment1').value=changelcliabamtlimtamt-outstd_amt1;
					}
				}	
				//Changes P.Subramani-Chn-11/09/2008 End
			}
			else
			{
				//Changes P.Subramani-Chn-10/09/2008 Beg
				if(gid('MF:seluseroption').value=="A")
				{
					gid('MF:txtOsbeforethisamendment1').value=outstd_amt;
				}
				else
				{
					if(outstd_amt > changelcliabamtlimtamt)
					{
						gid('MF:txtOsbeforethisamendment1').value=outstd_amt-changelcliabamtlimtamt;
					}
					else
					{
						gid('MF:txtOsbeforethisamendment1').value=changelcliabamtlimtamt-outstd_amt;
					}
				}	
				//Changes P.Subramani-Chn-10/09/2008 End
			}
			setAmount('MF:txtOsbeforethisamendment1',gid('MF:txtOsbeforethisamendment1').value);
			setAmount('MF:txtLCPendingToBeSanctioned1',objXMLApplet.getValue("TOT_LIAB_LIM_CURR"));
			gid('MF:txtLCliabafterthisamendment').value=objXMLApplet.getValue("SANC_CURR");
		
					
			//Changes P.Subramani-Chn-19/08/2008 Beg			
			gid('MF:txtLCliabafterthisamendment1').value=unFormat(gid('MF:txtOsbeforethisamendment1').value)*1+unFormat(gid('MF:txtLCPendingToBeSanctioned1').value)*1+unFormat(gid('MF:txtChangeinLCLiabAmountInLimitCurrency1').value)*1;
			//Changes P.Subramani-Chn-19/08/2008 End
			
			setAmount('MF:txtLCliabafterthisamendment1',gid('MF:txtLCliabafterthisamendment1').value);
			gid('MF:txtExcessOverLimit').value=objXMLApplet.getValue("SANC_CURR");
			
			//Changes P.Subramani-Chn-27/02/2008 Beg
			gid("MF:txtExcOverlimitDueCurrTrancurr").value=objXMLApplet.getValue("SANC_CURR");
			gid("MF:txtExcessOverLimit1").value="";
			gid("MF:txtExcOverlimitDueCurrTrancurrAmt").value="";
			if( unFormat(gid('MF:txtLCliabafterthisamendment1').value)*1 > unFormat(gid('MF:txtFacilityLimit1').value)*1)
			{
				var _outstdaftlc1 = unFormat(trim(gid('MF:txtLCliabafterthisamendment1').value));
				var _faclmt = unFormat(trim(gid('MF:txtFacilityLimit1').value));
				var _excoverlmt = (_outstdaftlc1) - (_faclmt);
				gid('MF:txtExcessOverLimit1').value = _excoverlmt ;
				setAmount('MF:txtExcessOverLimit1',gid('MF:txtExcessOverLimit1').value);
			}
			if(!gid('MF:txtExcessOverLimit1').value=="")
			{
				if( unFormat(gid('MF:txtExcessOverLimit1').value)*1 < unFormat(gid('MF:txtChangeinLCLiabAmountInLimitCurrency1').value)*1 )
				{
					 gid('MF:txtExcOverlimitDueCurrTrancurrAmt').value = gid('MF:txtExcessOverLimit1').value;
					 setAmount('MF:txtExcOverlimitDueCurrTrancurrAmt',gid('MF:txtExcOverlimitDueCurrTrancurrAmt').value);
				}
				else if( unFormat(gid('MF:txtExcessOverLimit1').value)*1 > unFormat(gid('MF:txtChangeinLCLiabAmountInLimitCurrency1').value)*1 )
				{
					 gid('MF:txtExcOverlimitDueCurrTrancurrAmt').value = gid('MF:txtChangeinLCLiabAmountInLimitCurrency1').value;
					 setAmount('MF:txtExcOverlimitDueCurrTrancurrAmt',gid('MF:txtExcOverlimitDueCurrTrancurrAmt').value);
				}
			}
			//Changes P.Subramani-Chn-27/02/2008 End
			setAmount('MF:txtExcessOverLimit1',gid('MF:txtExcessOverLimit1').value);
		}
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
//Changes P.Subramani-Chn-20/10/2008 Beg	
	function validateMarginCurrency()
	{
		if(gid("MF:txtmargincurr").value=="")
		{
			setMsg(BLANK_CHECK);
			gid('MF:txtmargincurr').focus();
			return;
		}
		else
		{
			objXMLApplet.clearMap();
			objXMLApplet.setValue("Package","panacea.OLCaction.eolcamdval");
			objXMLApplet.setValue("Method","olcLcCurrkeypress");
			objXMLApplet.setValue("ValidateToken", "true");
			objXMLApplet.setValue("OLC_LC_CURR",trim(gid('MF:txtmargincurr').value));
			objXMLApplet.sendAndReceive();
			if(objXMLApplet.getValue("ErrorMsg") != "")
			{
				setMsg(objXMLApplet.getValue("ErrorMsg"));
				gid('MF:txtmargincurr').focus();
				return;  
			}
			else
			{
				mardecilen="";
				mardecilen=objXMLApplet.getValue("REM_DEC_LEN");
				gid('MF:outlblmargincurr').innerText=objXMLApplet.getValue("REM_CURR_NAME");
				setTabfocus("maintab","tcontent6a");
			}
	    }
  		if(unFormat(gid('MF:txtExcessOverLimit1').value)*1==0 || unFormat(gid('MF:txtExcessOverLimit1').value)*1==0.00)
  		{
			flag1=1;
			gid('MF:txtmarginpercentage1').value="";
			gid('MF:txtmarginamt2').value="";
			gid('MF:txtcashmarginamt2').value="";
			gid('MF:txtmarginpercentage1').disabled=true;
			gid('MF:txtmarginamt2').disabled=true;
			gid('MF:txtcashmarginamt2').disabled=true;
			gid('MF:txtmarginamtcurr').value=gid('MF:txtmargincurr').value;
			gid('MF:txtcashmargincurr').value=gid('MF:txtmargincurr').value;
			gid("MF:txtmarginpercentage").focus();
  		}
  		else if(unFormat(gid('MF:txtExcOverlimitDueCurrTrancurrAmt').value)*1==unFormat(gid('MF:txtChangeinLCLiabAmountInLimitCurrency1').value)*1)
  		{
			flag1=2;
			gid('MF:txtmarginpercentage').value="";
			gid('MF:txtmarginamt1').value="";
			gid('MF:txtcashmarginamt1').value="";
			gid('MF:txtmarginpercentage').disabled=true;
			gid('MF:txtmarginamt1').disabled=true;
			gid('MF:txtcashmarginamt1').disabled=true;
			gid('MF:txtmarginamtcurr').value=gid('MF:txtmargincurr').value;
			gid('MF:txtcashmargincurr').value=gid('MF:txtmargincurr').value;
	   		gid("MF:txtmarginpercentage1").focus();
		}
	    else
	    {
	   		flag1=3;
	   		gid("MF:txtmarginpercentage").focus();
			gid('MF:txtmarginamtcurr').value=gid('MF:txtmargincurr').value;
			gid('MF:txtcashmargincurr').value=gid('MF:txtmargincurr').value;
	    }
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
	function validateMarginPerc()
	{
		marginamt=0;
		w_eolm=0;
		if(gid("MF:txtmarginpercentage").value=="")
		{
			if(flag1==1)
			{
			setTabfocus("maintab","tcontent6a");
			gid("MF:txtmarginamt1").focus();
			}
			else if(flag1==3)
			{
			setTabfocus("maintab","tcontent6a");
			gid("MF:txtmarginpercentage1").focus();
			}
		}
		else
		{
			marginper=unFormat(gid("MF:txtmarginpercentage").value)*1;
		
			if( marginper > 100 )
			{
				setMsg("Margin Percentage Not To Exceed 100%");
				setTabfocus("maintab","tcontent6a");
				gid("MF:txtmarginpercentage").focus();
			}
			else
			{
			 	w_eolm_pc=unFormat(gid('MF:txtExcOverlimitDueCurrTrancurrAmt').value)/unFormat(gid('MF:txtChangeinLCLiabAmountInLimitCurrency1').value);
	    		
	    		if(gid('MF:txtmargincurr').value==gid('MF:txtLCAmount2').value)
    			{
    				w_totliabm=unFormat(gid('MF:txtAdditionalLCliabAmount1').value);
    			}
	    		else if(gid('MF:txtmargincurr').value==baseCurrency)
    			{
    				w_totliabm=unFormat(gid('MF:txtChangeinLCliabinBasecurrency1').value);
    			}
	    		else if(gid('MF:txtmargincurr').value==gid('MF:txtLimitCurrency').value)
    			{
    				w_totliabm=unFormat(gid('MF:txtChangeinLCLiabAmountInLimitCurrency1').value);
    			}		
	    		
	    		if(unFormat(gid('MF:txtExcOverlimitDueCurrTrancurrAmt').value)!=0)
    			{
	    			w_eolm_pc=unFormat(gid('MF:txtExcOverlimitDueCurrTrancurrAmt').value)/unFormat(gid('MF:txtChangeinLCLiabAmountInLimitCurrency1').value);
	    			w_eolm=w_totliabm*w_eolm_pc;
	    			w_amt=w_totliabm-w_eolm;
    			}
	    		else
    		   {
    		   		w_amt=w_totliabm;
    		   }	
	    			
	    	   if( marginper > 0 )
	    	   {
	    	   		if(unFormat(gid('MF:txtFacilityLimit1').value)!=0)
	    			{
		    			var moveamt=w_amt*(marginper/100);
		    			marginamt=moveamt;
		    			gid('MF:txtmarginamt1').value=moveamt;
		    			//setAmount('MF:txtmarginamt1',gid('MF:txtmarginamt1').value);
		    			//setTabfocus("maintab","tcontent6");
						
						if(flag1==1)
						{
							setTabfocus("maintab","tcontent6a");
							gid('MF:txtmarginamt1').focus();
							return;
						}
						else if(flag1==3)
						{
							setTabfocus("maintab","tcontent6a");
							gid('MF:txtmarginpercentage1').focus();
							return;
						}
	    			}
	    			else
	    			{
		    			var moveamt=w_totliabm*(marginper/100);
		    			marginamt=moveamt;
		    			gid('MF:txtmarginamt1').value=moveamt;
		    			//setAmount('MF:txtmarginamt1',gid('MF:txtmarginamt1').value);
		    			//setTabfocus("maintab","tcontent6");
		    			
						if(flag1==1)
						{
							setTabfocus("maintab","tcontent6a");
							gid('MF:txtmarginamt1').focus();
						}
						else if(flag1==3)
						{
							setTabfocus("maintab","tcontent6a");
							gid('MF:txtmarginpercentage1').focus();
						}
					}
	    		}	
    			else if(marginper==0)
    			{
					if(flag1==1)
					{
						setTabfocus("maintab","tcontent6a");
						gid('MF:txtmarginamt1').focus();
					}
					else if(flag1==3)
					{
						setTabfocus("maintab","tcontent6a");
						gid('MF:txtmarginpercentage1').focus();
					}
				}	
    	    }
	    }
     }	   
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
	function validateEOLMarginPerc()
	{
		if(gid('MF:txtmarginpercentage1').value=="")
		{
			if(flag1==2)
			{
				setTabfocus("maintab","tcontent6a");
				gid('MF:txtmarginamt2').focus();
			}
			else if(flag1==3)
			{
				setTabfocus("maintab","tcontent6a");
				gid('MF:txtmarginamt1').focus();
			}
		}
		else
		{
			eolmarginper=unFormat(gid('MF:txtmarginpercentage1').value)*1;
			if( eolmarginper > 100 )
			{
				setMsg("Margin Percentage Not To Exceed 100%");
				setTabfocus("maintab","tcontent6a");
				gid('MF:txtmarginpercentage1').focus();
				return;
			}
			if( eolmarginper > 0 )
			{
			 	w_eolm_pc=unFormat(gid('MF:txtExcOverlimitDueCurrTrancurrAmt').value)/unFormat(gid('MF:txtChangeinLCLiabAmountInLimitCurrency1').value);
	    		
	    		if(w_eolm!=0)
    			{
	    			var moveamt1=w_eolm*(eolmarginper/100);
	    			gid('MF:txtmarginamt2').value=moveamt1;
    			}
    			else
    			{
	    			if(gid('MF:txtmargincurr').value==gid('MF:txtLCAmount2').value)
	    			{
	    				w_totliabm=unFormat(gid('MF:txtAdditionallcamtinBasecurr1').value);
	    			}
		    		else if(gid('MF:txtmargincurr').value==baseCurrency)
	    			{
	    				w_totliabm=unFormat(gid('MF:txtChangeinLCliabinBasecurrency1').value);
	    			}
		    		else if(gid('MF:txtmargincurr').value==gid('MF:txtLimitCurrency').value)
	    			{
	    				w_totliabm=unFormat(gid('MF:txtChangeinLCLiabAmountInLimitCurrency1').value);
	    			}		
	    			var eolamt=w_totliabm*(eolmarginper/100);
    				gid('MF:txtmarginamt2').value=eolamt;
    			}
				if(flag1==2)
				{
					setTabfocus("maintab","tcontent6a");
					gid('MF:txtmarginamt2').focus();
				}
				else if(flag1==3)
				{
					setTabfocus("maintab","tcontent6a");
					gid('MF:txtmarginamt1').focus();
				}
		  }
    	  else if(eolmarginper==0)
    	  {
    	  	if(flag1==2)
			{
				setTabfocus("maintab","tcontent6a");
				gid('MF:txtmarginamt2').focus();
			}
			else if(flag1==3)
			{
				setTabfocus("maintab","tcontent6a");
				gid('MF:txtmarginamt1').focus();
			}
		 }	
    	}
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------		
	function validateMarginAmt()
	{
		if(gid('MF:txtmarginamt1').value=="")
		{
			marginamt=unFormat(gid('MF:txtmarginamt1').value)*1;
						
			if(flag1==1)
			{
				gid('MF:txtmarginamt3').value="0";
				setTabfocus("maintab","tcontent6a");
				gid('MF:txtcashmarginamt1').focus();
			}
			else if(flag1==3)
			{
				setTabfocus("maintab","tcontent6a");
				gid('MF:txtmarginamt2').focus();
			}
		}
		
		marginamt=unFormat(gid('MF:txtmarginamt1').value)*1;
		
		if(marginamt>0)
		{
			if(gid('MF:txtmargincurr').value==gid('MF:txtLCAmount2').value)
    		{
    			if( marginamt > unFormat(gid('MF:txtAdditionallcamtinBasecurr1').value)*1 )
				{
					setMsg("Margin Amount Should Be <= Additional Amount in BaseCurrency");
					setTabfocus("maintab","tcontent6a");
					gid('MF:txtmarginamt1').focus();
					return;
				}
				else if(flag1==1)
				{
					gid('MF:txtmarginamt3').value=marginamt;
					setTabfocus("maintab","tcontent6a");
					gid('MF:txtcashmarginamt1').focus();
					return;
				}
				else if(flag1==3)
				{
					setTabfocus("maintab","tcontent6a");
					gid('MF:txtmarginamt2').focus();
					return;
				}	
			}		
			else if(gid('MF:txtmargincurr').value==gid('MF:txtLimitCurrency').value)
			{
				if( marginamt > unFormat(gid('MF:txtChangeinLCLiabAmountInLimitCurrency1').value)*1 )
				{
					setMsg("Margin Amount Should Be <= Change in LCLiab Amount in Limit Currency");
					setTabfocus("maintab","tcontent6a");
					gid('MF:txtmarginamt1').focus();
					return;
				}
				else if(flag1==1)
				{
					gid('MF:txtmarginamt3').value=marginamt;
					setTabfocus("maintab","tcontent6a");
					gid('MF:txtcashmarginamt1').focus();
				return;
				}
				else if(flag1==3)
				{
					setTabfocus("maintab","tcontent6a");
					gid('MF:txtmarginamt2').focus();
					return;
				}	
			}
			else if(gid('MF:txtmargincurr').value==baseCurrency)
			{
				if( marginamt > unFormat(gid('MF:txtChangeinLCliabinBasecurrency1').value)*1 )
				{
					setMsg("Margin Amount Should Be <= Change in LCLiab in BaseCurrency");
					setTabfocus("maintab","tcontent6a");
					gid('MF:txtmarginamt1').focus();
					return;
				}
				else if(flag1==1)
				{
					gid('MF:txtmarginamt3').value=marginamt;
					setTabfocus("maintab","tcontent6a");
					gid('MF:txtcashmarginamt1').focus();
					return;
				}
				else if(flag1==3)
				{
					setTabfocus("maintab","tcontent6a");
					gid('MF:txtmarginamt2').focus();
					return;
				}		
			}
		}
		else if(marginamt==0)
		{
			if(flag1==1)
			{
				gid('MF:txtmarginamt3').value=marginamt;
				setTabfocus("maintab","tcontent6a");
				gid('MF:txtcashmarginamt1').focus();
			}
			else if(flag1==3)
			{
				setTabfocus("maintab","tcontent6a");
				gid('MF:txtmarginamt2').focus();
			}	
		}
	}		
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------		
	function validateEOLMarginAmt()
	{
		if(gid('MF:txtmarginamt2').value=="")
		{
			eolmarginamt=unFormat(gid('MF:txtmarginamt2').value)*1;
			if(flag1==2)
			{
				gid('MF:txtmarginamt3').value="0";
				setTabfocus("maintab","tcontent6a");
				gid('MF:txtcashmarginamt2').focus();
			}
			else if(flag1==3)
			{
				gid('MF:txtcashmarginamt3').value=marginamt;
				setTabfocus("maintab","tcontent6a");
				gid('MF:txtcashmarginamt1').focus();
			}
		}
		eolmarginamt=unFormat(gid('MF:txtmarginamt2').value)*1;
		if(eolmarginamt > 0)
		{
			if(gid('MF:txtcashmarginamt2').value=="")
			{
				gid('MF:txtcashmarginamt2').value=eolmarginamt;
				if(flag1==2)
				{
					gid('MF:txtmarginamt3').value=eolmarginamt;
					setTabfocus("maintab","tcontent6a");
					gid('MF:txtcashmarginamt2').focus();
				}
				else if(flag1==3)
				{
					gid('MF:txtmarginamt3').value=marginamt+eolmarginamt;
					setTabfocus("maintab","tcontent6a");
					gid('MF:txtcashmarginamt1').focus();
				}
			}
			else
			{
				//Changes P.Subramani-Chn-23/05/2008 Beg
				gid('MF:txtcashmarginamt2').value=eolmarginamt;
				//Changes P.Subramani-Chn-23/05/2008 End
				if(flag1==2)
				{
					gid('MF:txtmarginamt3').value=eolmarginamt;
					setTabfocus("maintab","tcontent6a");
					gid('MF:txtcashmarginamt2').focus();
				}
				else if(flag1==3)
				{
					gid('MF:txtmarginamt3').value=marginamt+eolmarginamt;
					setTabfocus("maintab","tcontent6a");
					gid('MF:txtcashmarginamt1').focus();
				}
			}			
		}
		else if(eolmarginamt==0)
		{
			gid('MF:txtmarginamt3').value=marginamt+eolmarginamt;
			if(flag1==2)
			{
				gid('MF:txtmarginamt3').value=eolmarginamt;
				setTabfocus("maintab","tcontent6a");
				gid('MF:txtcashmarginamt2').focus();
			}
			else if(flag1==3)
			{
				gid('MF:txtmarginamt3').value=marginamt+eolmarginamt;
				setTabfocus("maintab","tcontent6a");
				gid('MF:txtcashmarginamt1').focus();
			}
		}
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------		
	function validateCashMargin()
	{
		var totalcashamt; 
		 
		if(gid('MF:txtcashmarginamt1').value=="0")
		{
			setMsg(ZERO_CHECK);
		    gid('MF:txtcashmarginamt1').focus();
		    return;
		}
	    if(gid('MF:txtcashmarginamt1').value=="")
		{
			if(flag1==1)
			{
				gid('MF:txtcashmarginamt3').value="0";
				setTabfocus("maintab","tcontent6a");
				gid('MF:lstmargintypeforLC').focus();
				return;
			}
			else
			{
				setTabfocus("maintab","tcontent6a");
				gid('MF:txtcashmarginamt2').focus();
				return;
			}
		}
		
		if((unFormat(gid('MF:txtcashmarginamt1').value)*1)>(unFormat(gid('MF:txtmarginamt1').value)*1))
		{
			setMsg("Cash Margin Amount Should Be <= Margin Amount");
			gid('MF:txtcashmarginamt1').focus();
			return;  
		}
		cashmarginamt=unFormat(gid('MF:txtcashmarginamt1').value)*1;
		
		if(cashmarginamt > 0)
		{
			if(flag1==1)
			{
				totalcashamt=cashmarginamt*1+unFormat(gid('MF:txtcashmarginamt2').value)*1;
				gid('MF:txtcashmarginamt3').value=totalcashamt;
				if(totalcashamt!=gid('MF:txtmarginamt3').value)
				{
					if(flag1==1)
					{
					setTabfocus("maintab","tcontent6a");
					gid('MF:lstmargintypeforLC').focus();
					return;
					}
					else
					{
					setTabfocus("maintab","tcontent6a");
					gid('MF:txtcashmarginamt2').focus();
					return;
					}
			   }
			   else
		 	   {
			 	   	setTabfocus("maintab","tcontent6a");
					gid('MF:MarginNext').focus();
					return;  		 
		 	   }
			}
			else
			{
				setTabfocus("maintab","tcontent6a");
				gid('MF:txtcashmarginamt2').focus();
				return;
			}	
		}
	}	
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------		
	function validateEOLCashMargin()
	{
		if(gid('MF:txtcashmarginamt2').value=="")
		{
			gid('MF:txtcashmarginamt3').value=cashmarginamt;
			setTabfocus("maintab","tcontent6a");
			gid('MF:lstmargintypeforLC').focus();
			return;
		}
		if(eolmarginamt > 0)
		{
			eolcashmarginamt=unFormat(gid('MF:txtcashmarginamt2').value)*1;
			var tot=cashmarginamt+eolcashmarginamt;
			gid('MF:txtcashmarginamt3').value=tot;
			
			if(tot!=gid('MF:txtmarginamt3').value)
			{
				setTabfocus("maintab","tcontent6a");
			 	gid('MF:lstmargintypeforLC').focus();
			 	return;
			}
			else
			{
				setTabfocus("maintab","tcontent6a");
				gid('MF:MarginNext').focus();
				return;	 	
			}
		}
	}	
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------				
	function validateMarginType()
	{
		/*if(gid('MF:lstmargintypeforLC').value=="")
		{
			setMsg(OPTION_MESSAGE);
			gid('MF:lstmargintypeforLC').focus();
			return;
		}
		else
		{*/
			setTabfocus("maintab","tcontent6a");
			gid('MF:MarginNext').focus();
			return;		
		//}
	}
//Changes P.Subramani-Chn-20/10/2008 End		
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			
	function callCharges()
	{
		//Methods for calculating Usance and Commitment Charges
		
		//Changes P.Subramani-Chn-28/04/2008 Beg
		getcustno();
		//Changes P.Subramani-Chn-28/04/2008 End
		
		//Changes P.Subramani-Chn-12/04/2008 Beg
		gettenortypechargecurroption();
		//Changes P.Subramani-Chn-25/08/2008 Beg
		
		//Methods For Calculating Usance Charges
		//Changes P.Subramani-Chn-25/08/2008 BEg
		callusancechgsforamount(row,col);
		callusancechgsforperiod(row,col);
		callusancechgstotvalue(row,col);
		//Changes P.Subramani-Chn-25/08/2008 End	    
		//Methods For Calculating Usance Charges End
	    
	    
		//Methods For Calculating Commitment Charges	Beg    
	    getcommmonth();
		getprevcommmonth();
	    var totalbeforeamd = unFormat(gid('MF:txtTotalBeforeAmd').value)*1;
	    var totalafteramd = unFormat(gid('MF:txtTotalAfterAmd').value)*1;
	    var Diff = (totalafteramd) - (totalbeforeamd);
		Diff = parseInt(totalafteramd) - parseInt(totalbeforeamd);
	    if(Diff > 0)
		{
			callcommchgsforamount(row,col);
		}
		
	    var Diff2 = (parseInt(olccommmonth) - parseInt(prevcommmonth));
	    if(Diff2 > 0)
	    {	
	    	callcommchgsforperiod();
	    }
	    commitcharges = ( (unFormat(commchgsamt1)*1) + (unFormat(commchgsamt2)*1) );
	    gid('MF:txtcommchgscurr').value=baseCurrency;
	    gid('MF:txtcommchgscurr1').value=baseCurrency;
	    gid('MF:txtcommchgsamt').value=commitcharges;
	    gid('MF:txtcommchgsamt1').value=commitcharges;
	    gid('MF:txtcommchgsamt').value=formatNumbercurr(gid('MF:txtcommchgsamt').value,declength2);
	    gid('MF:txtcommchgsamt1').value=formatNumbercurr(gid('MF:txtcommchgsamt1').value,declength2);
	    if(commchgstakendays=="")
	    {
	    	gid('MF:txtcommchgstakendays').value="0";
	    }
	    else
	    {
	    	gid('MF:txtcommchgstakendays').value=commchgstakendays;
	    }		
	    //Methods For Calculating Commitment Charges	End
	    //Changes P.Subramani-Chn-12/04/2008 End
		
	  	objXMLApplet.clearMap();
		objXMLApplet.setValue("Package","panacea.OLCaction.eolcamdval");
		objXMLApplet.setValue("Method","OlcChargeComp");
		objXMLApplet.setValue("ValidateToken", "true");
		objXMLApplet.setValue("TRCHG_NOMEN_CODE",trim(gid('MF:txtReferenceType').value));
		objXMLApplet.setValue("TRCHG_FACILITY_CURR",trim(gid('MF:txtLCAmount').value));
		objXMLApplet.sendAndReceive();
		if(objXMLApplet.getValue("ErrorMsg") != "")
		{
			setMsg(objXMLApplet.getValue("ErrorMsg"));
			gid('MF:LimitNext').focus();
			return;  
		}
		else
	    { 
		   
		    objTFMCharges.custaccflag ="1";
		    objTFMCharges.clearControl();//Jayakumaran CHG-06-06-2011
		    objTFMCharges.internalaccno ="0";
		    //SUGANYA BEGIN 23-MAY-2017
			objTFMCharges.brncode=gid('MF:txtBranchCode').value;
			//SUGANYA END 23-MAY-2017
		    //SUGANYA BEGIN 28-FEB-2017
			objTFMCharges.customerno=gid("MF:txtCustomerNumber").value;
			
			//SUGANYA END 28-FEB-2017
		    
		    //Vinoth.S-Chns- 28-01-2011-Beg
		    objTFMCharges.trandate = gid('MF:txtLcDate').value;
		    //Vinoth.S-Chns- 28-01-2011-End
			objTFMCharges.AddOrModify  = gid('MF:seluseroption').value;
			objTFMCharges.chargeslist = objXMLApplet.getValue("TRCHG_COMMN_CHGCD")+"|"+objXMLApplet.getValue("TRCHG_HANDLING_CHGCD")+"|"+objXMLApplet.getValue("TRCHG_COURIER_CHGCD")+"|"+objXMLApplet.getValue("TRCHG_POSTAL_CHGCD")+"|"+objXMLApplet.getValue("TRCHG_SWIFT_CHGCD");
			objTFMCharges.trancurrency = baseCurrency;//gid('MF:txtLCAmount').value;
			//Changes P.Subramani-Chn-21/10/2008 Beg
			
			if( (parseFloat(unFormat(gid('MF:txtAdditionallcamtinBasecurr1').value)*1))> 0 )
			{
				
				objTFMCharges.prevTab ="tcontent6a"; 
				objTFMCharges.prevFld = 'MF:MarginNext';
				objTFMCharges.tranamount = unFormat(gid('MF:txtAdditionallcamtinBasecurr1').value);
			}
			else if( parseFloat((unFormat(gid('MF:txtReductioninLCliabinBasecurr1').value)*1)) > 0 )
			{
				
				objTFMCharges.prevTab ="tcontent6";
				objTFMCharges.prevFld ='MF:LimitNext';
				objTFMCharges.tranamount = unFormat(gid('MF:txtReductioninLCliabinBasecurr1').value);
			}
			
			//Changes P.Subramani-Chn-21/10/2008 End
			if(objTFMCharges.AddOrModify == "M")
	   		{
	   			//M.Jayakumaran - Chn - 23-05-2011 - Begin
	   				if(gid('MF:txtAdditionallcamtinBasecurr1').value=="0" && gid('MF:txtReductioninLCliabinBasecurr1').value=="0" )
	   				{
	   					objTFMCharges.tranamount =0;
	   				}
	   			//M.Jayakumaran - Chn - 23-05-2011 - End
	   			
	   	    	objTFMCharges.TRANCHGS_SL =tranchgs_sl;
	   	  		objTFMCharges.validateComponentOnLoad();
	   		}
	   		else
	   	 	{
	   			if(gid('MF:txtAmendmentSerial').value>1)
				{
					
					objTFMCharges.TRANCHGS_SL =tranchgs_sl;
					
					objTFMCharges.AddOrModify ="M";
					//SUGANYA BEGIN 23-09-2016
					if(gid('MF:txtAdditionallcamtinBasecurr1').value=="0" && gid('MF:txtReductioninLCliabinBasecurr1').value=="0" )
	   				{
					objTFMCharges.tranamount =0;
					}
					//SUGANYA END 23-09-2016
					
					//Vinoth.S-Chns- 28-01-2011-Beg
				    objTFMCharges.trandate = gid('MF:txtLcDate').value;
				    //Vinoth.S-Chns- 28-01-2011-End
					objTFMCharges.validateComponentOnLoad();
	    		}
	   			else 
	   			{	
	   				//M.Jayakumaran - Chn - 23-05-2011 - Begin
	   				
	   				if(gid('MF:txtAdditionallcamtinBasecurr1').value=="0" && gid('MF:txtReductioninLCliabinBasecurr1').value=="0" )
	   				{
	   					objTFMCharges.tranamount =0;
	   				}
	   				//M.Jayakumaran - Chn - 23-05-2011 - End
	   	 			objTFMCharges.TRANCHGS_SL =  "";
	   			} 
			}
		
			
			setTabfocus("maintab","tcontent7");
	   		objTFMCharges.Focus();
	    }	
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------			
	function callSettlement()
	{
		//Changes P.Subramani-Chn-23/06/2008 Beg
		var usancecharge=unFormat(gid('MF:txtusnchgsamt1').value)*1;
		var commitcharge=unFormat(gid('MF:txtcommchgsamt1').value)*1;
		var totalcharge=parseFloat(totalamount)+parseFloat(usancecharge)+parseFloat(commitcharge);
		gid('MF:totalAmount1').value=totalcharge;
		   
 	   setTabfocus("maintab","tcontent8");
	   objTranStmntPost.ProgramID="EOLCAMD";
	   objTranStmntPost.isDbCr = "D";
	   objTranStmntPost.AddOrModify=gid('MF:seluseroption').value;
	   if(trim(gid('MF:seluseroption').value)=="M")
       {
       		objTranStmntPost.InventoryNumber = invoiceNumber;
    		objTranStmntPost.FetchFromTable=true;
    		objTranStmntPost.ResultType="MAIN";
       }
	   else
	   {
			if(trim(gid('MF:txtAmendmentSerial').value)>1)
			{
				objTranStmntPost.InventoryNumber = invoiceNumber;
				objTranStmntPost.FetchFromTable=true;
				objTranStmntPost.ResultType="MAIN";
				objTranStmntPost.AddOrModify="M";
			}
			else
			{
				objTranStmntPost.InventoryNumber = 0;
			}
	   }
	   objTranStmntPost.SourceTable="OLCAMD";
	   objTranStmntPost.SourceKey=gid('MF:txtBranchCode').value+"|"+gid('MF:txtReferenceType').value+"|"+gid('MF:txtReferenceYear').value+"|"+gid('MF:txtReferenceSl').value+"|"+gid('MF:txtAmendmentSerial').value;
	   objTranStmntPost.BranchCode=gid('MF:txtBranchCode').value;
	   objTranStmntPost.TranCurrCode=recoverycurr;
	   objTranStmntPost.TranAmount=totalcharge;
	   objTranStmntPost.TranBaseCurrEqu=totalcharge;
	   objTranStmntPost.valueDate=gid('MF:txtAmendmentEntryDate').value;
	   objTranStmntPost.Focus();
	   //Changes P.Subramani-Chn-23/06/2008 End
	}	  
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------			
	//Changes P.Subramani-Chn-12/04/2008 Beg
	function validateusnchgs()
	{
		setTabfocus("maintab","tcontent7");
		gid('MF:txtcommchgsamt1').focus();
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------			
	function validatecommchgs()
	{	
		if(trim(gid("MF:TFMChargesDetails:outtxttotal").value) == 0)
		{
		   //test
		   if((trim(gid("MF:txtusnchgsamt1").value) == 0) && (trim(gid("MF:txtcommchgsamt1").value) == 0))
		   {
			  setTabfocus("maintab","tcontent7");
			  gid('MF:Submit').focus();
		   }
		   else
		   {
		   	 setTabfocus("maintab","tcontent7");
			 gid('MF:ChargeNext').focus();
		   }
		}
		else
		{
			setTabfocus("maintab","tcontent7");
			gid('MF:ChargeNext').focus();
		}
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------						
	//Changes P.Subramani-Chn-25/08/2008 Beg
	function callusancechgsforamount(row,col)
	{
		var convrate = parseInt(unFormat(gid('MF:txtConvRatetobasecurr').value))*1;
		for(var i=1;i<=gridEolcamd.getRowsNum();i++)
		{
			var totalbeforeamd = unFormat(gridEolcamd.cells(i,26).getValue())*1;
		    var totalafteramd = unFormat(gridEolcamd.cells(i,30).getValue())*1;
		    Diff = parseInt(totalafteramd) - parseInt(totalbeforeamd);
		    if(Diff > 0)
			{
				objXMLApplet.clearMap();
				objXMLApplet.setValue("Package","panacea.OLCaction.eolcamdval");
				objXMLApplet.setValue("Method","olcusanceforamountkeypress");
		        objXMLApplet.setValue("ValidateToken","true");
		        objXMLApplet.setValue("OLC_PROD_CODE",trim(gid('MF:txtProductCode').value));
		        objXMLApplet.setValue("OLC_LC_TYPE",trim(gid('MF:txtReferenceType').value));
				//Changes P.Subramani-Chn-28/04/2008
				objXMLApplet.setValue("OLC_CUST_NUM",custno);
				//if chargecurroption is basecurrency or transaction currency
				if(chargecurroption=="B")
				{
					if(gid('MF:seluseroption').value=="A")
					{
						if(gid('MF:txtAmendmentSerial').value=="1")
						{
							objXMLApplet.setValue("OLC_PREV_LC_AMT",unFormat(gridEolcamd.cells(i,28).getValue())*1);	
						}
						else
						{
							objXMLApplet.setValue("OLC_PREV_LC_AMT",unFormat(gridEolcamd.cells(i,28).getValue())*1-unFormat(gridEolcamd.cells(i,21).getValue())*1);	
						}
					}
					else
					{
						objXMLApplet.setValue("OLC_PREV_LC_AMT",unFormat(gridEolcamd.cells(i,28).getValue())*1-unFormat(gridEolcamd.cells(i,21).getValue())*1);	
					}
					objXMLApplet.setValue("OLC_LC_AMT",((Diff)*(convrate)));
				}
				else
				{
					objXMLApplet.setValue("OLC_PREV_LC_AMT",unFormat(gridEolcamd.cells(i,26).getValue())*1);
					objXMLApplet.setValue("OLC_LC_AMT",unFormat(gridEolcamd.cells(i,30).getValue())*1);
				}
				if(gridEolcamd.cells(i,22).getValue()=="")
				{
					objXMLApplet.setValue("OLC_LC_DAYS",0);
				}
				else
				{
					objXMLApplet.setValue("OLC_LC_DAYS",gridEolcamd.cells(i,22).getValue());
				}
				objXMLApplet.setValue("OLC_TENOR_TYPE",gridEolcamd.cells(i,1).getValue());
				//Changes P.Subramani-Chn-10/09/2008 Beg
				//Amd Type changes to "A" given by A.E.SenthilKumar
				objXMLApplet.setValue("OLC_AMD_TYPE","A");
				//objXMLApplet.setValue("OLC_AMD_TYPE",chargecurroption);
				//Changes P.Subramani-Chn-10/09/2008 End
				objXMLApplet.sendAndReceive();
				if(objXMLApplet.getValue("ErrorMsg") != "")
				{
		  			setMsg(objXMLApplet.getValue("ErrorMsg"));
		  			setTabfocus("maintab","tcontent7");
					gid('MF:txtusnchgsamt1').focus();
				}
				else  
				{
					//Removed P.Subramani-Chn-25/08/2008
					//usnchgamt1 = objXMLApplet.getValue("USANCE_CHGS");
					//callcommchgsforamount();
					gridEolcamd.cells(i,31).setValue(2);
					gridEolcamd.cells(i,32).setValue(objXMLApplet.getValue("USANCE_CHGS"));
				}//Changes P.Subramani-Chn-25/08/2008 End
			}
	    }
	}    	
	//Changes P.Subramani-Chn-25/08/2008 End	
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------			
	function callcommchgsforamount()
	{
		objXMLApplet.clearMap();
		objXMLApplet.setValue("Package","panacea.OLCaction.eolcamdval");
		objXMLApplet.setValue("Method","olccommforamountkeypress");
        objXMLApplet.setValue("ValidateToken","true");
        objXMLApplet.setValue("OLC_PROD_CODE",trim(gid('MF:txtProductCode').value));
        objXMLApplet.setValue("OLC_LC_TYPE",trim(gid('MF:txtReferenceType').value));
		//Changes P.Subramani-Chn-28/04/2008
		objXMLApplet.setValue("OLC_CUST_NUM",custno);
		//Changes P.Subramani-Chn-22/10/2008 Beg
		if(_total_liab_base_curr==0)
		{
			objXMLApplet.setValue("OLC_PREV_LC_AMT",_total_liab_base_curr);
		}
		else
		{
			objXMLApplet.setValue("OLC_PREV_LC_AMT",unFormat(_total_liab_base_curr));
		}
		//Changes P.Subramani-Chn-22/10/2008 End
		objXMLApplet.setValue("OLC_LC_AMT",unFormat(gid('MF:txtAdditionallcamtinBasecurr1').value));
		objXMLApplet.setValue("OLC_LC_DAYS",olccommmonth);
		objXMLApplet.sendAndReceive();
		if(objXMLApplet.getValue("ErrorMsg") != "")
		{
		
  			setMsg(objXMLApplet.getValue("ErrorMsg"));
  			setTabfocus("maintab","tcontent7");
			gid('MF:txtcommchgsamt1').focus();
			return;  
		}
		else  
		{
			commchgsamt1 = objXMLApplet.getValue("COMM_CHGS");
		}	
	}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------					
	//Changes P.Subramani-Chn-25/08/2008 Beg
	function callusancechgsforperiod(row,col)
	{
		var convrate = parseInt(unFormat(gid('MF:txtConvRatetobasecurr').value))*1;
		for(var i=1;i<=gridEolcamd.getRowsNum();i++)
		{
			Diff1 = parseInt(unFormat(gridEolcamd.cells(i,22).getValue())*1) - parseInt(unFormat(gridEolcamd.cells(i,24).getValue())*1);
			
		    if(Diff1 > 0)
		    {
			    objXMLApplet.clearMap();
				objXMLApplet.setValue("Package","panacea.OLCaction.eolcamdval");
				objXMLApplet.setValue("Method","olcusanceforperiodkeypress");
		        objXMLApplet.setValue("ValidateToken","true");
		        objXMLApplet.setValue("OLC_PROD_CODE",trim(gid('MF:txtProductCode').value));
		        objXMLApplet.setValue("OLC_LC_TYPE",trim(gid('MF:txtReferenceType').value));
				//Changes P.Subramani-Chn-28/04/2008
				objXMLApplet.setValue("OLC_CUST_NUM",custno);
				//if chargecurroption is basecurrency or transaction currency
				if(chargecurroption=="B")
				{
					if(gid('MF:txtAmendmentSerial').value=="1")
					{
						var tot = parseInt(unFormat(gridEolcamd.cells(i,28).getValue()))*1;
						if(tot==0)
						{
							objXMLApplet.setValue("OLC_LC_AMT",( (unFormat(gridEolcamd.cells(i,30).getValue())*1)* (convrate) ));
						}
						else
						{
							objXMLApplet.setValue("OLC_LC_AMT",tot);
						}
					}
					else
					{
						var prevtotliabbase=0;
						prevtotliabbase = ((parseFloat(unFormat(gridEolcamd.cells(i,21).getValue()))*1) * (prevconvrate));
						var tot = parseInt(parseFloat(unFormat(gridEolcamd.cells(i,28).getValue()))*1- (prevtotliabbase));
						if(tot==0)
						{
							objXMLApplet.setValue("OLC_LC_AMT",( (unFormat(gridEolcamd.cells(i,30).getValue())*1)* (convrate) ));
						}
						else
						{
							objXMLApplet.setValue("OLC_LC_AMT",tot);
						}
					}
				}
				else
				{
					objXMLApplet.setValue("OLC_LC_AMT",unFormat(gridEolcamd.cells(i,30).getValue()));
				}
				//here we should pass Difference of currusancemonth and prevusancemonth for olc_lc_days
				objXMLApplet.setValue("OLC_LC_DAYS",Diff1);
				objXMLApplet.setValue("OLC_TENOR_TYPE",gridEolcamd.cells(i,1).getValue());
				objXMLApplet.setValue("OLC_AMD_TYPE",chargecurroption);
				objXMLApplet.setValue("OLC_PREV_USANCE_DAYS",gridEolcamd.cells(i,24).getValue());
				objXMLApplet.sendAndReceive();
				if(objXMLApplet.getValue("ErrorMsg") != "")
				{
		  			setMsg(objXMLApplet.getValue("ErrorMsg"));
		  			setTabfocus("maintab","tcontent7");
					gid('MF:txtusnchgsamt1').focus();
					return false;  
				}
				else  
				{
					gridEolcamd.cells(i,33).setValue(2);
					gridEolcamd.cells(i,34).setValue(objXMLApplet.getValue("USANCE_CHGS"));
					gridEolcamd.cells(i,35).setValue(objXMLApplet.getValue("USANCE_CHGS_TAKEN_DAYS"));
				}
		    }
	    }
	}
	//Changes P.Subramani-Chn-25/08/2008 End    
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------			
	function callcommchgsforperiod()
	{
		objXMLApplet.clearMap();
		objXMLApplet.setValue("Package","panacea.OLCaction.eolcamdval");
		objXMLApplet.setValue("Method","olccommforperiodkeypress");
        objXMLApplet.setValue("ValidateToken","true");
        objXMLApplet.setValue("OLC_PROD_CODE",trim(gid('MF:txtProductCode').value));
        objXMLApplet.setValue("OLC_LC_TYPE",trim(gid('MF:txtReferenceType').value));
		//Changes P.Subramani-Chn-28/04/2008
		objXMLApplet.setValue("OLC_CUST_NUM",custno);
		if(_total_liab_base_curr==0)
		{
			objXMLApplet.setValue("OLC_LC_AMT",unFormat(gid("MF:txtTotalLcAmtinbaseCurrafteramendment1").value));
		}
		else
		{
			objXMLApplet.setValue("OLC_LC_AMT",unFormat(_total_liab_base_curr));
		}
		objXMLApplet.setValue("OLC_LC_DAYS",olccommmonth);
		objXMLApplet.setValue("OLC_PREV_COMM_DAYS",prevcommmonth);
		objXMLApplet.sendAndReceive();
		if(objXMLApplet.getValue("ErrorMsg") != "")
		{
  			setMsg(objXMLApplet.getValue("ErrorMsg"));
  			setTabfocus("maintab","tcontent7");
			gid('MF:txtcommchgsamt1').focus();
			return;  
		}
		else  
		{
			commchgsamt2 = objXMLApplet.getValue("COMM_CHGS");
			commchgstakendays=objXMLApplet.getValue("COMM_CHGS_TAKEN_DAYS");
		}	
	}	
//Changes P.Subramani-Chn-12/04/2008 End
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------					
	//Changes P.Subramani-Chn-25/08/2008 Beg
	function callusancechgstotvalue(row,col)
	{
		var Total=0;
		var Total1=0;
		for(var i=1;i<=gridEolcamd.getRowsNum();i++)
		{
			Total=Total+unFormat(gridEolcamd.cells(i,32).getValue())*1;
			Total1=Total1+unFormat(gridEolcamd.cells(i,34).getValue())*1;
		}
		usancecharges = Total + Total1;
	    gid('MF:txtusnchgscurr').value=baseCurrency;
	    gid('MF:txtusnchgscurr1').value=baseCurrency;
	    gid('MF:txtusnchgsamt').value=usancecharges;
	    gid('MF:txtusnchgsamt1').value=usancecharges;
	    gid('MF:txtusnchgsamt').value=formatNumbercurr(gid('MF:txtusnchgsamt').value,declength2);
	    gid('MF:txtusnchgsamt1').value=formatNumbercurr(gid('MF:txtusnchgsamt1').value,declength2);
	}
	//Changes P.Subramani-Chn-25/08/2008 End	
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------			
//Grid validations
//-----------------------------------------------------------------------------------------------------------------------------------	     
	function GridKeyDownF5(gridobj,row,col)
	{  
		switch (gridobj.gridname)
		{
              case "gridEolcamd":
		 							if(col==2)
		 							{
		                            	helpToken = "Hlpeinremreal1";
		                            	fldArgs = gridEolcamd.cells(row,1 ).getValue();
		 			  					showHelp(helpToken,gridobj,fldArgs);
		 			  				}
		 			  				else if(col==4)
		 			  				{
		                            	helpToken = "Hlpeinremreal8";
		                            	fldArgs = gridEolcamd.cells(row,1 ).getValue();
		 			  					showHelp(helpToken,gridobj,fldArgs);
		 			  				}
									break;
		}  
	}
//-----------------------------------------------------------------------------------------------------------------------------------	     
	function gridamdKeypress(row, col)
    {
       setMsg("");
       var t= gridEolcamd.cells(row,col).getValue();
       switch(col)
       {
	       case 1: validateTenorType(row,col);break;
	       case 3: validatePrevTenorAmount(row,col);break;
	       case 5: validateTenorAmount(row,col);break;
	       case 6: validateUsanceDays(row,col);break;
	       case 7: validateUsancePeriodFrom(row,col);break;
	       case 8: validateOtherDtDesc(row,col);break;
	       case 9: validateOtherDtStart(row,col);break;
	       case 11: validateUsanceInterest(row,col);break;
	       case 13: validatePrevUsanceInterest(row,col);break;
	       case 15: validateUsanceInterestAmount(row,col);break;
	       case 16: validateDocumentDelivery(row,col);break;
       }
   }
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	   
	function validateTenorType(row,col)
	{
		var drawdown=gid('MF:txtDrawDowns').value;
		var curr_row=row;
		setMsg("");
		if(curr_row>drawdown)
		{
			setMsg("");
			gridEolcamd.cells(curr_row,col).setValue("");
			setMsg("Row Should not be > DrawDowns");
			SetFocus(gridEolcamd,row,"ttype");
			gridEolcamd.cells(curr_row,1).setValue("");
			return; 
		}
		if(gridEolcamd.cells(row,col).getValue()=="")
	 	{  
			setMsg("");
			setMsg(OPTION_MESSAGE);
			SetFocus(gridEolcamd,row,"ttype");
			return; 		
		}
		var amdlcamt = unFormat(gid('MF:txtAmendedLCAmount1').value)*1;
		if(drawdown==1)
		{
			if(row==1 )
			{
			 	if(gridEolcamd.cells(row,col).getValue()=="S")
				{
					setMsg("");
					gridEolcamd.cells(row,2).setValue(2);
					//Changes P.Subramani-Chn-25/02/2008
					gridEolcamd.cells(row,3).setValue(gid('MF:txtLCAmount21').value);
					gridEolcamd.cells(row,4).setValue(2);
					//Changes P.Subramani-Chn-18/08/2008 Beg
					gridEolcamd.cells(row,5).setValue(amdlcamt);
					//Changes P.Subramani-Chn-18/08/2008 End
					gridEolcamd.cells(row,6).setValue("0");
					gridEolcamd.cells(row,7).setValue(" ");
					gridEolcamd.cells(row,8).setValue(" ");
					gridEolcamd.cells(row,9).setValue(" ");
	 	      		gridEolcamd.cells(row,10).setValue(6);
	 	      		gridEolcamd.cells(row,11).setValue("00.000000");
	 	      		gridEolcamd.cells(row,12).setValue(2);
	 	      		gridEolcamd.cells(row,14).setValue(2);
	 	      		gridEolcamd.cells(row,15).setValue("0.00");
	 	      		gridEolcamd.cells(row,16).setValue(2);
	 	      		//Changes P.Subramani-Chn-22/08/2008 BEg
	 	      		if(gid('MF:seluseroption').value=="A")
	 	    		{
	 	      			gridEolcamd.cells(row,20).setValue("0");
	 	      		}	
	 	      		//Changes P.Subramani-Chn-22/08/2008 End
	 	      		SetFocus(gridEolcamd,row,"tamt");
				}
				else if(gridEolcamd.cells(row,col).getValue()=="U")
				{
					setMsg("");
					gridEolcamd.cells(row,2).setValue(2);
					//Changes P.Subramani-01/04/2008
					gridEolcamd.cells(row,3).setValue(gid('MF:txtLCAmount21').value);
					gridEolcamd.cells(row,4).setValue(2);
					//Changes P.Subramani-Chn-18/08/2008 Beg
					gridEolcamd.cells(row,5).setValue(amdlcamt);
					//Changes P.Subramani-Chn-18/08/2008 End
					SetFocus(gridEolcamd,row,"udays");
				}
				else if(amdlcamt != gid('MF:txtTotalTenorAmount').value)
				{
					setMsg("");
					setMsg("Tenor Amount should be equal to the Amended LC Amount");
					SetFocus(gridEolcamd,row,"ttype");
					return;
				}
			}
			else if(row==2)
			{
				setMsg("");
				setMsg("Row should not be > DrawDowns");
			}
		}
		else if(drawdown>1 )
		{
			if(row==1)
			{
				 if(gridEolcamd.cells(row,col).getValue()=="S")
				 {
					setMsg("");
					gridEolcamd.cells(row,2).setValue(2);
					gridEolcamd.cells(row,4).setValue(2);
					SetFocus(gridEolcamd,row,"tamt");
				 }
				 else if(gridEolcamd.cells(row,col).getValue()=="U")
				 {	
					setMsg("");
					gridEolcamd.cells(row,2).setValue(2);
					gridEolcamd.cells(row,4).setValue(2);
					SetFocus(gridEolcamd,row,"tamt");
				 }
			}
			if(row>1)
			{
				if(gridEolcamd.cells(row,col).getValue()=="S")
				{
					var rownum=gridEolcamd.getRowsNum();
					var flag;
					//Changes P.Subramani-Chn-28/08/2008  Beg
					//for(var i=1;i<rownum;i++)
					//{
						if(gridEolcamd.cells(row,col).getValue()=="S")
				 		{
				 			if(gridEolcamd.cells(row,col).getValue()==gridEolcamd.cells(row-1,col).getValue())
				 			{
				 				flag=1;
					 			setMsg("Sight should not be Duplicated");
								SetFocus(gridEolcamd,row,"ttype");
								return;
							}
							else
							{
								flag=0;
							}
							if(flag==0)
							{
								setMsg("");
								gridEolcamd.cells(row,4).setValue(2);
								SetFocus(gridEolcamd,row,"tamt");
								return;
							}
				 		}
						else
						{
							flag=0;
						}
					//}//Changes P.Subramani-Chn-28/08/2008  End
					if(flag==0)
					{
						setMsg("");
						gridEolcamd.cells(row,4).setValue(2);
						SetFocus(gridEolcamd,row,"tamt");
						return;
					}
				}
				else if(gridEolcamd.cells(row,col).getValue()=="U")
				{
				 	setMsg("");
				 	gridEolcamd.cells(row,4).setValue(2);
				 	SetFocus(gridEolcamd,row,"tamt");
				}
			}
		}
	}	
//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	  
	function validateTenorAmount(row,col)
	{
		var no_of_row=0;
		setMsg("");
	 	var drawdown=gid('MF:txtDrawDowns').value;
	 	tottenoramt=0;
	 	if(gridEolcamd.getRowsNum()==1)
	 	{
	 		tottenoramt=unFormat(gridEolcamd.cells(row,5).getValue())*1;
	 	}
	 	else
	 	{
	 		tottenoramt=0;
	 		for(var i=1;i<=gridEolcamd.getRowsNum();i++)
			{
				tottenoramt=(tottenoramt*1)+unFormat(gridEolcamd.cells(i,5).getValue())*1;
				if(gridEolcamd.cells(i,5).getValue()!="")
				{
					no_of_row=i;
				}
				tottenoramt=tottenoramt*1;
			}
	 	}
		var amdlcamt = unFormat(gid('MF:txtAmendedLCAmount1').value)*1;
		if(gridEolcamd.cells(row,col).getValue()=="")
		{
			setMsg("");
			setMsg(BLANK_CHECK);
			SetFocus(gridEolcamd,row,"tamt");
			return;
		}
		else if(gridEolcamd.cells(row,col).getValue()==0)
		{
			setMsg("");
			setMsg(ZERO_CHECK);
			SetFocus(gridEolcamd,row,"tamt");
			return;
		}
		else
		{
			setMsg("");
		    var tamt=gridEolcamd.cells(row,5).getValue();
			//var rownno=gridEolcamd.getRowsNum();
		    objXMLApplet.clearMap();
			objXMLApplet.setValue("Package","panacea.OLCaction.eolcamdval");
			objXMLApplet.setValue("Method","olcTenorAmtkeypress");
	        objXMLApplet.setValue("ValidateToken", "true");
			//Changes P.Subramani-Chn-18/08/2008 Beg	        
	        objXMLApplet.setValue("LC_AMT",amdlcamt);
	        //Changes P.Subramani-Chn-18/08/2008 End
	        objXMLApplet.setValue("DRAW_DOWNS",gid('MF:txtDrawDowns').value);
	        objXMLApplet.setValue("TOTAL_TENOR_AMT",tottenoramt);
	        objXMLApplet.setValue("TENOR_AMT",tamt);
	        objXMLApplet.setValue("NO_OF_ROWS",no_of_row);
	        objXMLApplet.sendAndReceive();
			if(objXMLApplet.getValue("ErrorMsg") != "")
			{
	  			setMsg(objXMLApplet.getValue("ErrorMsg"));
				SetFocus(gridEolcamd,row,"tamt");
				return;  
			}
			else 
			{
				if(gridEolcamd.cells(row,1).getValue()=="S")
				{
					//Changes P.Subramani-Chn-28/08/2008 Beg
					var curr_row=row;
					//Changes P.Subramani-Chn-28/08/2008 End
					if(curr_row<drawdown)
					{
						gridEolcamd.cells(row,6).setValue("0");
						gridEolcamd.cells(row,7).setValue(" ");
						gridEolcamd.cells(row,8).setValue(" ");
						gridEolcamd.cells(row,9).setValue(" ");
		 	      		gridEolcamd.cells(row,10).setValue(6);
		 	      		gridEolcamd.cells(row,11).setValue("00.000000");
		 	      		gridEolcamd.cells(row,12).setValue(2);
		 	      		gridEolcamd.cells(row,14).setValue(2);
		 	      		gridEolcamd.cells(row,15).setValue("0.00");
		 	      		gridEolcamd.cells(row,16).setValue(2);
		 	      		//Changes P.Subramani-Chn-22/08/2008 BEg
	 	      			if(gid('MF:seluseroption').value=="A")
	 	    			{
	 	      				gridEolcamd.cells(row,20).setValue("0");
	 	      			}	
	 	      			//Changes P.Subramani-Chn-22/08/2008 End
	 	      		
	 	      			//Changes P.Subramani-Chn-23/08/2008 Beg
				 	    getusancemonth(row,col);
						getprevusancemonth(row,col);
						TotalValueAfterAmd(row,col);
				 	    //Changes P.Subramani-Chn-23/08/2008 End
	 	      			
						AddRowToGrid(gridEolcamd); 
						SetFocus(gridEolcamd,row+1,"ttype");
						return; 
					}
					else if(curr_row==drawdown)
					{
						gridEolcamd.cells(row,6).setValue("0");
						gridEolcamd.cells(row,7).setValue(" ");
						gridEolcamd.cells(row,8).setValue(" ");
						gridEolcamd.cells(row,9).setValue(" ");
		 	      		gridEolcamd.cells(row,10).setValue(6);
		 	      		gridEolcamd.cells(row,11).setValue("00.000000");
		 	      		gridEolcamd.cells(row,12).setValue(2);
		 	      		gridEolcamd.cells(row,14).setValue(2);
		 	      		gridEolcamd.cells(row,15).setValue("0.00");
		 	      		gridEolcamd.cells(row,16).setValue(2);
		 	      		//Changes P.Subramani-Chn-22/08/2008 BEg
	 	      			if(gid('MF:seluseroption').value=="A")
	 	    			{
	 	      				gridEolcamd.cells(row,20).setValue("0");
	 	      			}	
	 	      			//Changes P.Subramani-Chn-22/08/2008 End
	 	      			
	 	      			//Changes P.Subramani-Chn-23/08/2008 Beg
				 	    getusancemonth(row,col);
						getprevusancemonth(row,col);
						TotalValueAfterAmd(row,col);
				 	    //Changes P.Subramani-Chn-23/08/2008 End
	 	      			
		 	      		AddRowToGrid(gridEolcamd); 
						SetFocus(gridEolcamd,row+1,"ttype");
						return; 
					}
				}
				else if(gridEolcamd.cells(row,1).getValue()=="U")
				{
				    SetFocus(gridEolcamd,row,"udays");
				}
			}	
		}
	}	
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
	function validateUsanceDays(row,col)
	{
		setMsg("");
	 	if(gridEolcamd.cells(row,6).getValue()=="")
	 	{  
	 		setMsg("");
			setMsg(BLANK_CHECK);
			SetFocus(gridEolcamd,row,"udays");
			return; 		
	 	}
	 	else if(gridEolcamd.cells(row,6).getValue()<=0)
	 	{	
	 	    setMsg("Should be > 0");
			SetFocus(gridEolcamd,row,"udays");
			return; 		
		}
		else
		{
			setMsg("");
		  	SetFocus(gridEolcamd,row,"uperiod");
		}
    }
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------		
	function validateUsancePeriodFrom(row,col)
	{
		if(gridEolcamd.cells(row,7).getValue()=="")
	 	{  
	 		setMsg("");
			setMsg(BLANK_CHECK);
			SetFocus(gridEolcamd,row,"uperiod");
			return; 		
	 	}
	 	else if(gridEolcamd.cells(row,7).getValue()<0)
	 	{  
	 		setMsg("");
			setMsg("Usance Period Should Be Greater Than Zero");
			SetFocus(gridEolcamd,row,"uperiod");
			return; 		
	 	}
	 	else if(!(gridEolcamd.cells(row,7).getValue()==4))
	 	{	
	 	    gridEolcamd.cells(row,8).setValue(" ");
	 	    gridEolcamd.cells(row,9).setValue(" ");
	 	    gridEolcamd.cells(row,8).setValue(2);
	 	    gridEolcamd.cells(row,10).setValue(6);
	 	    SetFocus(gridEolcamd,row,"usanceintrat");
			return; 		
		}
		else
		{
		 	SetFocus(gridEolcamd,row,"otherdate");
		 	return; 
		}		
	}
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------		
	function validateOtherDtDesc(row,col)
	{
		SetFocus(gridEolcamd,row,"otherdtusance");	
	}
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------		
	function validateOtherDtStart(row,col)
	{	
		if(gridEolcamd.cells(row,9).getValue()=="")
	  	{
			gridEolcamd.cells(row,10).setValue(6);	
	   	    SetFocus(gridEolcamd,row,"usanceintrat");	
	   	}
   	  	else
   	  	{
   	  		var dateval=parseDate(gridEolcamd.cells(row,col).getValue(),"true");			  
			if(dateval == null)
			{
				 setMsg(INVALIDDATE);
				 SetFocus(gridEolcamd,row,"otherdtusance");
				 return;		        
			}
			else
			{
				 setMsg("");
				 dateval = formatDate(dateval,'dd-MM-yyyy');
				 gridEolcamd.cells(row,col).setValue(dateval);
				 gridEolcamd.cells(row,10).setValue(6);
				 SetFocus(gridEolcamd,row,"usanceintrat");
				 gridEolcamd.cells(row,col).setValue(dateval);
	       		 return; 		
	        }
   	  	}
	}
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------		
	function validateUsanceInterest(row,col)
	{
		 if(gridEolcamd.cells(row,11).getValue()=="")
	 	 {  
	 	 	setMsg(BLANK_CHECK);
			SetFocus(gridEolcamd,row,"usanceintrat");
			return; 		
	 	 }
	     else if(gridEolcamd.cells(row,11).getValue()<0)
	 	 {	
	 	    setMsg("Should be >= 0");
			SetFocus(gridEolcamd,row,"usanceintrat");
			return; 		
		 }
		 //Changes P.Subramani-Chn-27/02/2008 Beg
		 else if(unFormat(gridEolcamd.cells(row,11).getValue())*1==0)
	 	 {
	 	 	if(unFormat(gridEolcamd.cells(row,13).getValue())*1==0)
	 	    { 
		 	    //Changes P.Subramani-Chn-22/04/2008 Beg
		 	    if(unFormat(gridEolcamd.cells(row,15).getValue())*1==0)
		 	    { 
		 	    	setMsg("");
		 	      	gridEolcamd.cells(row,14).setValue(2);
		 	      	gridEolcamd.cells(row,15).setValue("0.00");
		 	      	SetFocus(gridEolcamd,row,"usanceintamt");
		 	      	//SetFocus(gridEolcamd,row,"docdelivery");
		 	    }
		 	    else 
		 	    {
		 	     	setMsg("");
		 	      	gridEolcamd.cells(row,14).setValue(2);
		 	      	//Changes P.Subramani-Chn-14/10/2008 
		 	      	gridEolcamd.cells(row,15).setValue(unFormat(gridEolcamd.cells(row,13).getValue()));
		 	      	SetFocus(gridEolcamd,row,"usanceintamt");
		 	    }
	 	 	}
	 	    else if(unFormat(gridEolcamd.cells(row,13).getValue())*1!=0)
	 	    {
	 	      	//Changes P.Subramani-Chn-18/08/2008 Beg
	 	     	if(unFormat(gridEolcamd.cells(row,15).getValue())*1==0)
		 	    { 
		 	    	setMsg("");
		 	      	gridEolcamd.cells(row,14).setValue(2);
		 	      	//Changes P.Subramani-Chn-14/10/2008
		 	      	gridEolcamd.cells(row,15).setValue(unFormat(gridEolcamd.cells(row,13).getValue()));
		 	      	SetFocus(gridEolcamd,row,"usanceintamt");
		 	      	//SetFocus(gridEolcamd,row,"docdelivery");
		 	    }
		 	    else 
		 	    {
		 	     	setMsg("");
		 	      	gridEolcamd.cells(row,14).setValue(2);
		 	      	//Changes P.Subramani-Chn-14/10/2008
		 	      	gridEolcamd.cells(row,15).setValue(unFormat(gridEolcamd.cells(row,13).getValue()));
		 	      	SetFocus(gridEolcamd,row,"usanceintamt");
		 	    }
	 	       	//Changes P.Subramani-Chn-18/08/2008 End
	 	    }
	 	    //Changes P.Subramani-Chn-22/04/2008 End
	 	    else
			{
			 	var a1=unFormat(gridEolcamd.cells(row,5).getValue())*1;
		      	var a2=unFormat(gid("MF:txtDeviationAllowed").value)*1;
	 	      	var a3=unFormat(gridEolcamd.cells(row,11).getValue())*1;
	 	      	var a4=unFormat(gridEolcamd.cells(row,6).getValue())*1;
	 	      	//Changes P.Subramani-Chn-02/04/2008
	 	      	var A=a1+((a2*a1)/100);
	 	      	var B=(A*a3)/100;
	 	      	var C=(B*a4)/360;
	 	      	if(C==0)
	 	      	{
	 	      		gridEolcamd.cells(row,15).setValue("0.00");
	 	      	}
	 	      	else
	 	      	{
	 	      		setMsg("");
		 	      gridEolcamd.cells(row,14).setValue(2);
		 	      gridEolcamd.cells(row,15).setValue(C);
	 	      	}
	 	      		SetFocus(gridEolcamd,row,"usanceintamt");
		 	 }//Changes P.Subramani-Chn-27/02/2008 End
		}		
   	    else 
	 	{	
			var a1=unFormat(gridEolcamd.cells(row,5).getValue())*1;
		    var a2=unFormat(gid("MF:txtDeviationAllowed").value)*1;
	 	    var a3=unFormat(gridEolcamd.cells(row,11).getValue())*1;
	 	    var a4=unFormat(gridEolcamd.cells(row,6).getValue())*1;
	 	     var A=a1+((a1*a2)/100);
	 	    var B=(A*a3)/100;
	 	    var C=(B*a4)/360;
	 	    //var D=C+a5;
	 	      	
	 	    setMsg("");
	 	    //Changes P.Subramani-Chn-27/02/2008
	 	    gridEolcamd.cells(row,14).setValue(2);
	 	    gridEolcamd.cells(row,15).setValue(C);
	 	    SetFocus(gridEolcamd,row,"usanceintamt");
	 	    //SetFocus(gridEolcamd,row,"docdelivery");	
   		}
   	}	
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------		
	function validateUsanceInterestAmount(row,col)
	{
		if(gridEolcamd.cells(row,15).getValue()=="")
	 	{  
	 		setMsg(BLANK_CHECK);
			SetFocus(gridEolcamd,row,"usanceintamt");
			return; 		
	 	}
	    else if(gridEolcamd.cells(row,15).getValue()<0)
	 	{	
	 	    setMsg("Should be >= 0");
			SetFocus(gridEolcamd,row,"usanceintamt");
			return; 		
		}
	    else 
	 	{	
		   setMsg("");
		   gridEolcamd.cells(row,14).setValue(2);
 	       SetFocus(gridEolcamd,row,"docdelivery");
		   return; 
		}	  
	}
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
	function validateDocumentDelivery(row,col)
	{		
		var drawdown=gid('MF:txtDrawDowns').value;
		var curr_row=row;
		if(gridEolcamd.cells(row,16).getValue()=="")
		{
			setMsg("");
			setMsg(OPTION_MESSAGE);
			SetFocus(gridEolcamd,row,"docdelivery");
			return;
		}
		else if(drawdown==1 && curr_row==1)
		{
			//Changes P.Subramani-Chn-22/08/2008 BEg
	 	    if(gid('MF:seluseroption').value=="A")
	 	    {
	 	    	gridEolcamd.cells(row,20).setValue("0");
	 	    }
	 	    //Changes P.Subramani-Chn-22/08/2008 End
	 	    
	 	    //Changes P.Subramani-Chn-23/08/2008 Beg
	 	    getusancemonth(row,col);
			getprevusancemonth(row,col);
			TotalValueAfterAmd(row,col);
	 	    //Changes P.Subramani-Chn-23/08/2008 End
				 	    
	 	    AddRowToGrid(gridEolcamd); 
			SetFocus(gridEolcamd,row+1,"ttype");
			//return; 
		}
		else
		{
			setMsg("");
			if(drawdown==curr_row)
			{
				LcCompValue(row,col);
				var totaltenoramount = unFormat(gid("MF:txtTotalTenorAmount").value)*1;
				if(totaltenoramount!=unFormat(gid("MF:txtAmendedLCAmount1").value)*1)
				{
					setMsg("Total Tenor Amount doesn't tally with LC Amount");
					SetFocus(gridEolcamd,row,"docdelivery");
					return; 
				}
				else
				{
					//Changes P.Subramani-Chn-22/08/2008 BEg
	 	      		if(gid('MF:seluseroption').value=="A")
			 	    {
			 	    	gridEolcamd.cells(row,20).setValue("0");
			 	    }
	 	      		//Changes P.Subramani-Chn-22/08/2008 End
	 	      		
			 	    //Changes P.Subramani-Chn-23/08/2008 Beg
			 	    getusancemonth(row,col);
					getprevusancemonth(row,col);
					TotalValueAfterAmd(row,col);
			 	    //Changes P.Subramani-Chn-23/08/2008 End	 	      		
	 	      		
	 	      		AddRowToGrid(gridEolcamd); 
					SetFocus(gridEolcamd,row+1,"ttype");
					return;
				}
			}
		    else if(drawdown!=curr_row)
			{
				//Changes P.Subramani-Chn-22/08/2008 BEg
	 	      	if(gid('MF:seluseroption').value=="A")
	 	    	{
	 	    		gridEolcamd.cells(row,20).setValue("0");
	 	    	}
	 	      	//Changes P.Subramani-Chn-22/08/2008 End
	 	      	
		 	    //Changes P.Subramani-Chn-23/08/2008 Beg
		 	    getusancemonth(row,col);
				getprevusancemonth(row,col);
				TotalValueAfterAmd(row,col);
		 	    //Changes P.Subramani-Chn-23/08/2008 End
	 	    	 	      	
	 	      	AddRowToGrid(gridEolcamd); 
				SetFocus(gridEolcamd,row+1,"ttype");
			}
		}
	} 	
//Grid Validations Over-----------------------------------------------------------------------------------------------------------------------------------
	function GridKeyDownF12(objname)
	{  
    	switch (objname)
 		{
 			case "gridEolcamd":	
 			
 								var drawdown = gid('MF:txtDrawDowns').value;
	 							var curr_row = gridEolcamd.getRowsNum();
 								if( curr_row == drawdown )
 								{  
 											 							LcCompValue(row,col);
				       			    var lcCurr=gid("MF:txtLCAmount").value;
				       			    var T1=unFormat(gid("MF:txtTotalBeforeAmd").value)*1;
	   							    var T2=unFormat(gid("MF:txtTotalAfterAmd").value)*1;	
	   							    // M.Murali - Added - 16-05-2012 - Beg
	   							    if(gid("MF:txtLCEnhancementReductionNochange").value=="E")
	   							    {
	   							    // M.Murali - Added - 16-05-2012 - End
									if((T2>T1))
				       			    {
				       			    	 if(lcCurr==baseCurrency)
										 {
										 	gid("MF:txtConvRatetobasecurr").value=1;
										    setAmount('MF:txtConvRatetobasecurr',gid("MF:txtConvRatetobasecurr").value);
										 }
										 gid('MF:txtAdditionalLCliabAmount').value=gid('MF:txtLCAmount').value;
										 gid('MF:txtReductionLCliabAmount').value=gid('MF:txtLCAmount').value;
									    
									     setTabfocus("maintab","tcontent5");
									     setTabfocus("maintab","tcontent5");
									     gid('MF:txtAdditionalLCliabAmount1').focus();
					       			     gid('MF:txtConvRatetobasecurr').focus();
					       			     gid('MF:txtConvRatetobasecurr').focus();
					       			}
				       				else
				       				{
				       					//gid("MF:txtConvRatetobasecurr").value="0.000";
					       				gid('MF:txtAdditionalLCliabAmount').value=gid('MF:txtLCAmount').value;
					       				gid('MF:txtReductionLCliabAmount').value=gid('MF:txtLCAmount').value;
					       				gid("MF:txtAdditionalLCliabAmount1").value="0.00";
					       				gid('MF:txtAdditionallcamtinBasecurr1').value="0.00";
					       				//validateConvRate();
					       				
					       				setTabfocus("maintab","tcontent5");
					       				setTabfocus("maintab","tcontent5");
					       			    gid('MF:txtAdditionalLCliabAmount1').focus();
					       			    gid('MF:txtConvRatetobasecurr').focus();
					       			    gid('MF:txtConvRatetobasecurr').focus();
					       			    //validateConvRate();
					       			} 
					       			// M.Murali - Added - 16-05-2012 - Beg
					       			}
					       			else if(gid("MF:txtLCEnhancementReductionNochange").value=="R")
					       			{
					       			if((T2<T1))
				       			    {	
				       			    	 if(lcCurr==baseCurrency)
										 {
										 	gid("MF:txtConvRatetobasecurr").value=1;
										    setAmount('MF:txtConvRatetobasecurr',gid("MF:txtConvRatetobasecurr").value);
										 }
										
										 gid('MF:txtReductionLCliabAmount').value=gid('MF:txtLCAmount').value;
										 gid('MF:txtAdditionalLCliabAmount').value=gid('MF:txtLCAmount').value;
										 gid("MF:txtAdditionalLCliabAmount1").value="0.00";
										 setTabfocus("maintab","tcontent5");
									     setTabfocus("maintab","tcontent5");
									     gid('MF:txtReductionLCliabAmount1').focus();
					       			     gid('MF:txtConvRatetobasecurr').focus();
					       			     gid('MF:txtConvRatetobasecurr').focus();
					       			}				       			
					       			}  
					       			// M.Murali - Added - 16-05-2012 - End
					       			//SUGANYA
					       			setMsg("");
					       			gridEolcamd.editStop();
					   			setTabfocus("maintab","tcontent5");
					   			gid('MF:txtConvRatetobasecurr').focus();
					   			//SUGANYA
                            			   		
   									//window.event.keyCode =0;
   									
					   				return;
					   			}
					   			else
					   			{	
						   			setMsg("");
						   			
						   			setMsg("No. Of Rows in Grid Should be equal to Draw Down Value");
						   			SetFocus(gridEolcamd,curr_row,"docdelivery");
						   			return;
					   			}
					   			//SUGANYA
					   			setTabfocus("maintab","tcontent5");
					   			gid('MF:txtConvRatetobasecurr').focus();
					   			//SUGANYA
								break;	
		}			
	}
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	  	
	function getXML()
	{ 
		//Starts
	  	for(var i=1;i<=gridEolcamd.getRowsNum();i++)
		{
			PrevTenorAmt = PrevTenorAmt+unFormat(gridEolcamd.cells(i,3).getValue())*1+Separator;
			TotalLiabAmt= TotalLiabAmt+unFormat(gridEolcamd.cells(i,17).getValue())*1+Separator;
			baltenoramt=baltenoramt+unFormat(gridEolcamd.cells(i,18).getValue())*1+Separator;
			balusanceintamt=balusanceintamt+unFormat(gridEolcamd.cells(i,19).getValue())*1+Separator;
		}
		gid("MF:PrevGridTenorAmt").value=PrevTenorAmt;
		gid("MF:TotalGridLiabAmt").value=TotalLiabAmt;
		gid("MF:txtBalTenorAmt").value=baltenoramt;
		gid("MF:txtBalUsanceAmt").value=balusanceintamt;
		//ends
		//Changes P.Subramani-Chn-22/08/2008 BEg
		
	  	gridEolcamd.setxmlcolumn("0,1,0,1,0,1,1,1,1,1,0,1,0,1,0,1,1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1");
		//Changes P.Subramani-Chn-22/08/2008 End
	  	gid('MF:mxmlstr1').value=GetXMLString(gridEolcamd);
	  	window.event.keyCode =0 ;
		gid('MF:Submit').focus();
	   	return;
	}	    	
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------  	
    function GridKeyDownF2(objname,row,col)
    {  
    	setMsg("");
        if(objname=="gridEolcamd")
        {
        	if ((row == 1 ) && (col==1) )
		    {
		    	gid('MF:chkUsanceInterestToBeBorneByApplicant').focus();
		    }
		    else if(col==1)
		    {
		        if(gridEolcamd.cells(row,1).getValue()=="")
		        {
		          	gridEolcamd.deleteRow(row);
		        }	
		        if(gridEolcamd.cells(row-1,1).getValue()=="S")
		        {
		            SetFocus(gridEolcamd,row-1,"tamt");
		        }
		        else
		        {
		            SetFocus(gridEolcamd,row-1,"docdelivery");
		        }
		    }   
		    else if(col==5)
		    	SetFocus(gridEolcamd,row,"ttype");
		    else if(col==6)
		    	SetFocus(gridEolcamd,row,"tamt");
		    else if(col==7)	
		        SetFocus(gridEolcamd,row,"udays");
		    else if(col==8)	
		        SetFocus(gridEolcamd,row,"uperiod");
		    else if(col==9)	
		        SetFocus(gridEolcamd,row,"otherdate");
		    else if(col==11)	
		        SetFocus(gridEolcamd,row,"otherdtusance");
		    else if(col==15)	
		        SetFocus(gridEolcamd,row,"usanceintrat");
		    else if(col==16)
		    {	
		        if(gridEolcamd.cells(row,1).getValue()=="S")
		        {
		         	SetFocus(gridEolcamd,row,"tamt");
		        }
		        else
		        {
		            SetFocus(gridEolcamd,row,"usanceintamt");
		        }
		    }   
		   }
		   else if(objname=="gridNormChgs") 
		   { 	
		   		if(row == 1)
	          	{
		       		gid('MF:TFMChargesDetails:txtchgsreccurr').focus();	
	          	}
		      	else
			  	{
			   		SetFocus(gridNormChgs,row-1,"actamount");
			  	}	     
		   }
    }	
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------		  
	 function saveData()
	 {
	 	objTFMCharges.exitControl(); 
	 	gid('MF:Submit').focus();
	 }
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------		 
	function LcCompValue(row,col)
	{
		var A1=0;
		var C1=0;
		var D1=0;
		var chkdraw=1;
		//var E1=1;
		for(var i=1;i<=gridEolcamd.getRowsNum();i++)
		{
			A1=A1+unFormat(gridEolcamd.cells(i,5).getValue())*1;//Tenor Amt
			C1=C1+unFormat(gridEolcamd.cells(i,13).getValue())*1;	//Prev Usnce int Amt
			D1=D1+unFormat(gridEolcamd.cells(i,15).getValue())*1;	//Usnce int Amt
		}
		//Changes P.Subramani-Chn-01/04/2008
		var x=unFormat(gid("MF:txtLCAmount21").value)*1;
	 	var x1=unFormat(olcPositivDeviationAllow)*1;
	 	//Changes P.Subramani-Chn-25/08/2008 Beg
		var B1=(x1/100)*x;
	 	//Changes P.Subramani-Chn-25/08/2008 End
		gid("MF:txtTotalTenorAmount").value=A1;
		setAmount('MF:txtTotalTenorAmount',gid("MF:txtTotalTenorAmount").value);
	 
		gid("MF:txtLCBeforeAmd").value=x;
		setAmount('MF:txtLCBeforeAmd',gid("MF:txtLCBeforeAmd").value);
		gid("MF:txtPositiveBeforeAmd").value=B1;
		setAmount('MF:txtPositiveBeforeAmd',gid("MF:txtPositiveBeforeAmd").value);
		gid("MF:txtUsanceBeforeAmd").value=C1;
		setAmount('MF:txtUsanceBeforeAmd',gid("MF:txtUsanceBeforeAmd").value);
		 //Jeyamurugan.T  Chn -10/05/2010-begn add this line for sum lcamount and usance int in before_amendment
		//gid("MF:txtTotalBeforeAmd").value=x+B1+C1;
		gid("MF:txtTotalBeforeAmd").value=x+C1;
		 //Jeyamurugan.T  Chn -10/05/2010-begn add this line for sum lcamount and usance int
		setAmount('MF:txtTotalBeforeAmd',gid("MF:txtTotalBeforeAmd").value);
	
		//Changes P.Subramani-Chn-31/03/2008
		setAmount('MF:txtLCAfterAmd',gid("MF:txtAmendedLCAmount1").value);
		var p1=unFormat(gid("MF:txtLCAfterAmd").value)*1;
		var p2=unFormat(gid("MF:txtDeviationAllowed").value)*1;
		//Changes P.Subramani-Chn-25/08/2008 Beg
		var p3=(p2/100)*p1;
		//Changes P.Subramani-Chn-25/08/2008 End
		gid("MF:txtPositiveAfterAmd").value=p3;
		setAmount('MF:txtPositiveAfterAmd',gid("MF:txtPositiveAfterAmd").value);	
		gid("MF:txtUsanceAfterAmd").value=D1;
		setAmount('MF:txtUsanceAfterAmd',gid("MF:txtUsanceAfterAmd").value);	
		var p4=unFormat(gid("MF:txtPositiveAfterAmd").value)*1;
		 //Jeyamurugan.T  Chn -10/05/2010-begn add this line for sum lcamount and usance int in after_amendment
			//var z=p1+p4+D1
			var z=p1+D1;
		 //Jeyamurugan.T  Chn -10/05/2010-end add this line for sum lcamount and usance int
		gid("MF:txtTotalAfterAmd").value=z;
		setAmount('MF:txtTotalAfterAmd',gid("MF:txtTotalAfterAmd").value);
		// M.Murali - Added - 16-05-2012 - Beg
		if(gid("MF:txtLCEnhancementReductionNochange").value=="E")
		{
		// M.Murali - Added - 16-05-2012 - End
		var T1=unFormat(gid("MF:txtTotalBeforeAmd").value)*1;
		var T2=unFormat(gid("MF:txtTotalAfterAmd").value)*1;
		if(T2>T1)
		{		
			gid("MF:txtAdditionalLCliabAmount1").value=(T2-T1);
			//ADDED BY PRASHANTH ON 22 AUGUST 2019
			if(gid("MF:txtDeviationAmount").value>0 && gid('MF:txtDeviationAmount').value!=""){
				gid("MF:txtAdditionalLCliabAmount1").value=parseInt(unFormat(gid("MF:txtAdditionalLCliabAmount1").value))+parseInt(gid("MF:txtDeviationAmount").value);
			}
			//ADDED BY PRASHANTH ON 22 AUGUST 2019
			setAmount('MF:txtAdditionalLCliabAmount1',gid("MF:txtAdditionalLCliabAmount1").value);
			gid("MF:txtReductionLCliabAmount1").value=0;
			setAmount('MF:txtReductionLCliabAmount1',gid("MF:txtReductionLCliabAmount1").value);
		}
		else if(T2<T1)
		{
			gid("MF:txtReductionLCliabAmount1").value=(T1-T2);
			//ADDED BY PRASHANTH ON 22 AUGUST 2019
			if(gid("MF:txtDeviationAmount").value>0 && gid('MF:txtDeviationAmount').value!=""){
				gid("MF:txtReductionLCliabAmount1").value=parseInt(unFormat(gid("MF:txtReductionLCliabAmount1").value))+parseInt(gid("MF:txtDeviationAmount").value);
			}
			//ADDED BY PRASHANTH ON 22 AUGUST 2019
			setAmount('MF:txtReductionLCliabAmount1',gid("MF:txtReductionLCliabAmount1").value);
			gid("MF:txtReductionLCliabAmount1").value=0;
			setAmount('MF:txtReductionLCliabAmount1',gid("MF:txtReductionLCliabAmount1").value);
		}
		// M.Murali - Added - 16-05-2012 - Beg
		}
		else if(gid("MF:txtLCEnhancementReductionNochange").value=="R")
		{
		var T1=unFormat(gid("MF:txtTotalBeforeAmd").value)*1;
		var T2=unFormat(gid("MF:txtTotalAfterAmd").value)*1;
		if(T2<T1)
		{
			gid("MF:txtReductionLCliabAmount1").value=(T1-T2);
			//ADDED BY PRASHANTH ON 22 AUGUST 2019
			if(gid("MF:txtDeviationAmount").value>0 && gid('MF:txtDeviationAmount').value!=""){
				gid("MF:txtReductionLCliabAmount1").value=parseInt(unFormat(gid("MF:txtReductionLCliabAmount1").value))+parseInt(gid("MF:txtDeviationAmount").value);
			}
			//ADDED BY PRASHANTH ON 22 AUGUST 2019
			setAmount('MF:txtReductionLCliabAmount1',gid("MF:txtReductionLCliabAmount1").value);
			gid("MF:txtAdditionalLCliabAmount1").value=0;
			setAmount('MF:txtAdditionalLCliabAmount1',gid("MF:txtAdditionalLCliabAmount1").value);
		}
		
		}
		// M.Murali - Added - 16-05-2012 - End
		
	}
//---------------------------------------Components--------------------------------------------------------------------------------------------------------------------------------
	function formKeyDown()
    {
    	if(window.event.keyCode ==KEY_ESC)
        {
            switch(lastEntdFld.name)
            {
            	case "MF:seluseroption"  		: exitPage();break;
                default   					    : cancelPage();break;
            }
        }
        if((window.event.keyCode == KEY_ENTER)&&(gid("MF:TFMChargesDetails:outtxttotal").value != ""))
        {  
          	recoverycurr = gid("MF:TFMChargesDetails:txtchgsreccurr").value;
            totalamount  = gid("MF:TFMChargesDetails:outtxttotal").value;
            totalservicetax=gid("MF:TFMChargesDetails:outtxtstaxtot").value;
            //Hidden value set
            gid("MF:totalAmount").value=totalamount;
            gid("MF:totalAmount1").value=totalamount;
            gid("MF:txtRecovCurr").value=recoverycurr;  
            gid("MF:txtServiceTax").value=totalservicetax; 
        }
    }
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------		       	 
	function ConversionPage()
	{
		if((unFormat(gid("MF:txtTotalAfterAmd").value)*1)>(unFormat(gid("MF:txtTotalBeforeAmd").value)*1))
	    {
			if(gid('MF:txtLimitCurrency').value==baseCurrency)
		 	{
		 		setTabfocus("maintab","tcontent6");
		    	gid('MF:LimitNext').focus();
		 	}
		    else 
		 	{
		 		setTabfocus("maintab","tcontent6");
				gid('MF:txtConvRateToLimitCurrency').focus();
		 	}
	 	}
	 	else
	 	{
	 		setTabfocus("maintab","tcontent6");
	  	 	gid('MF:LimitNext').focus();
	 	}
	}
//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------- 			
	//Changes P.Subramani-Chn-25/08/2008 Beg
	function TotalValueBeforeAmd(row,col)
	{
		var A1=0;
		var C1=0;
		var B1=0;
		var x1=0;
		var TotalBeforeAmd=0;
		for(var i=1;i<=gridEolcamd.getRowsNum();i++)
		{
			A1=unFormat(gridEolcamd.cells(i,3).getValue())*1;
			C1=unFormat(gridEolcamd.cells(i,13).getValue())*1;	
			if(gid('MF:seluseroption').value=="A")
			{
				x1=unFormat(olcPositivDeviationAllow)*1;
			}
			else if(gid('MF:seluseroption').value=="M")
			{
				x1=unFormat(prevposdevallwd)*1;
			}
			B1=(x1/100)*A1;
			TotalBeforeAmd = A1+B1+C1;
			gridEolcamd.cells(i,25).setValue(2);
			gridEolcamd.cells(i,26).setValue(TotalBeforeAmd);
		}
	}
	//Changes P.Subramani-Chn-25/08/2008 End
//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------- 			
	//Changes P.Subramani-Chn-25/08/2008 Beg
	function TotalValueBeforeAmdBaseCurrEqui(row,col)
	{
		var A1=0;
		for(var i=1;i<=gridEolcamd.getRowsNum();i++)
		{
			A1=(unFormat(gridEolcamd.cells(i,26).getValue())*1) * prevconvrate;
			gridEolcamd.cells(i,27).setValue(2);
			gridEolcamd.cells(i,28).setValue(A1);
		}
	}
	//Changes P.Subramani-Chn-25/08/2008 End		
//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------- 			
	//Changes P.Subramani-Chn-23/08/2008 Beg
	function TotalValueAfterAmd(row,col)
	{
		var A1=0;
		var C1=0;
		var B1=0;
		var x1=0;
		var TotalAfterAmd=0;
			A1=unFormat(gridEolcamd.cells(row,5).getValue())*1;
			C1=unFormat(gridEolcamd.cells(row,15).getValue())*1;	
			x1=unFormat(gid("MF:txtDeviationAllowed").value)*1;
			B1=(x1/100)*A1;
			TotalAfterAmd = A1+B1+C1;
			gridEolcamd.cells(row,29).setValue(2);
			gridEolcamd.cells(row,30).setValue(TotalAfterAmd);
	}
	//Changes P.Subramani-Chn-23/08/2008 End	
//-----------------------------------------------------------------------------------------------------------------------------		 	
	//Changes P.Subramani-Chn-12/04/2008  Beg
	//Changes P.Subramani-Chn-23/08/2008 Beg
	function getusancemonth(row,col)
	{
		if(gridEolcamd.cells(row,1).getValue()=="S")
		{
			olcusancemonth=0;
		}
		else
		{
			olcusancedays = gridEolcamd.cells(row,6).getValue();
			if( ( (olcusancedays/30) - parseInt(olcusancedays/30) ) > 0 )
			{
				olcusancemonth = parseInt(olcusancedays/30) + (1);
			}
			else
			{
				olcusancemonth = (olcusancedays/30);
			}
		}
		gridEolcamd.cells(row,22).setValue(olcusancemonth);
		//Changes P.Subramani-Chn-23/08/2008 End
	}
//-----------------------------------------------------------------------------------------------------------------------------		 	
	//Changes P.Subramani-Chn-23/08/2008 Beg
	function getprevusancemonth(row,col)
	{
		if(gridEolcamd.cells(row,1).getValue()=="S")
		{
			prevusancemonth=0;
		}
		else
		{
			//Changes P.Subramani-Chn-23/08/2008 Beg
			prevolcdays = gridEolcamd.cells(row,23).getValue();
			//Changes P.Subramani-Chn-23/08/2008 End
			if( ( (prevolcdays/30) - parseInt(prevolcdays/30) ) > 0 )
			{
				prevusancemonth = parseInt(prevolcdays/30) + (1);
			}
			else
			{
				prevusancemonth = (prevolcdays/30);
			}
		}
		gridEolcamd.cells(row,24).setValue(prevusancemonth);
	}
		//Changes P.Subramani-Chn-23/08/2008 End	
//-----------------------------------------------------------------------------------------------------------------------------		 			
	function getcommmonth()
	{
		var fromdate = gid('MF:txtLCDate').value;
		var todate = gid('MF:txtLastDateforNegotiation').value;
		olccommmonth = getMonthDiff(fromdate,todate);
	}
//-----------------------------------------------------------------------------------------------------------------------------		 			
	function getprevcommmonth()
	{
		var fromdate = gid('MF:txtLCDate').value;
		var todate = prevlastdatefornegotiation;
		prevcommmonth = getMonthDiff(fromdate,todate);
	}	
//-----------------------------------------------------------------------------------------------------------------------------		 		
	function gettenortypechargecurroption()
	{
		objXMLApplet.clearMap();
		objXMLApplet.setValue("Package","panacea.OLCaction.eolcamdval");
		objXMLApplet.setValue("Method","olctenortypechgcodecurroptionkeypress");
        objXMLApplet.setValue("ValidateToken","true");
        objXMLApplet.setValue("TENOR_TYPE","USANCE");
        objXMLApplet.sendAndReceive();
    	chargecurroption = objXMLApplet.getValue("CHGCD_CHG_CURR_OPTION");
	}
	//Changes P.Subramani-Chn-12/04/2008  End
//-----------------------------------------------------------------------------------------------------------------------------		 		       	      											
	//Changes P.Subramani-Chn-28/04/2008 Beg
	function getcustno()
	{
		objXMLApplet.clearMap();
		objXMLApplet.setValue("Package","panacea.OLCaction.eolcamdval");
		objXMLApplet.setValue("Method","olccustnumkeypress");
        objXMLApplet.setValue("ValidateToken","true");
        objXMLApplet.setValue("OLC_PROD_CODE",trim(gid('MF:txtProductCode').value));
        objXMLApplet.setValue("OLC_LC_TYPE",trim(gid('MF:txtReferenceType').value));
		objXMLApplet.setValue("OLC_CUST_NUM",trim(gid('MF:txtCustomerNumber').value));
		objXMLApplet.sendAndReceive();
		custno = objXMLApplet.getValue("CUSTOMER_NUMBER");
	}
	//Changes P.Subramani-Chn-28/04/2008  End
//-----------------------------------------------------------------------------------------------------------------------------		
//ADDED ON 16/10/2018 START

	function validateReceRef()
	{
		 var _refRecvAdv1 = gid('MF:txtReceRef').value;
		//  var _refRecvAdv = _refRecvAdv1.length;//COMMENTTED BY PRASHANTH ON 06 FEB 2019
		 if(trim(_refRecvAdv1)== "")
		{
			setMsg(BLANK_CHECK);
			gid("MF:txtReceRef").focus();
			return;
		}
		else if(_refRecvAdv1 == 0)//CHANGED BY PRASHANTH ON 06 FEB 2019
		{
			setMsg(ZERO_CHECK);
			gid("MF:txtReceRef").focus();
			return;
		}
		// else if(_refRecvAdv > 16)
		else if(_refRecvAdv1.length > 16)//CHANGED BY PRASHANTH ON 06 FEB 2019
		{	
			setMsg("Length cannot exceed 16");
			gid("MF:txtReceRef").focus();
			return;
		}
		else
		{
			
		if(gid("MF:txtReferenceType").value=="OLC")
		{
			if(gid("MF:txtReceRef").value=="")
			{
				setMsg(BLANK_CHECK);
				gid("MF:txtReceRef").focus();
				return;
			}
			
			else
			{
				objXMLApplet.clearMap();
			    objXMLApplet.setValue("Package","panacea.OLCaction.eolcamdval");
			    objXMLApplet.setValue("ValidateToken","true");
			    objXMLApplet.setValue("Method","Reciever_ReferenceKeyPress");
			    objXMLApplet.setValue("LC_REC_BIC_CODE",trim(gid("MF:txtReceRef").value));
			    objXMLApplet.sendAndReceive();
			    if (objXMLApplet.getValue("ErrorMsg") != "")
			    {
			    	setMsg(objXMLApplet.getValue("ErrorMsg"));
					gid('MF:txtReceRef').focus();
			    }
			    else
			    {
			    	setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent1");
					gid('MF:txtDocCredit').focus();  
			    }
				
			}	
 		}
 		else
		    {
		    	gid("MF:txtReceRef").focus();
				return;  
		    }
			
		}				
	}
	
	function validateDocCredit()
	{
		var _docCredit = gid('MF:txtDocCredit').value;
		 if(trim(_docCredit)== "")
		{
			setMsg(BLANK_CHECK);
			gid("MF:txtDocCredit").focus();
			return;
		}
		else if(_docCredit == 0)
		{
			setMsg(ZERO_CHECK);
			gid("MF:txtDocCredit").focus();
			return;
		}
		else if(_docCredit > 16)
		{	
			setMsg("Length cannot exceed 16");
			gid("MF:txtDocCredit").focus();
			return;
		}
		else
		{
			gid('MF:chkIssueBank').focus();
		}		
	}
	
	function validatechkIssueBank()
	{
		checkIssueBank()
		if(gid('MF:chkIssueBank').checked==true)
		{
			gid('MF:lstIssueBICdtl').focus();
		}
		else
		{
			gid('MF:txtDateOfIssue').focus();
		}
	}
	function validatelstBicdtl(banklst,txtlst)
	{
	
	if(txtlst == "1")
		{
			IssueBicList();
			setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent1");
			if(banklst == "")
			{
				setMsg(BLANK_CHECK);
				gid('MF:lstIssueBICdtl').focus();
				return;
			}
			else if(banklst == "1")
			{
				gid('MF:txtIssueBicCode').focus();
			}
			else if(banklst == "2")
			{
				gid('MF:txtIssueAcnt').focus();
			}
			
		}
		
		if(txtlst == "2")
		{
			avlBicList();
			setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent8");
			if(banklst == "")
			{
				setMsg(BLANK_CHECK);
				gid('MF:lstAvlBICdtl').focus();
				return;
			}
			else if(banklst == "1")
			{
				gid('MF:txtAvlBicCode').focus();
			}
			else if(banklst == "2")
			{
				gid('MF:txtAvlAcnt').focus();
			}
			
		}
		
		if(txtlst == "3")
		{
			draweeBicList();
			setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent9");
			if(banklst == "")
			{
				setMsg(BLANK_CHECK);
				gid('MF:lstDrwBICdtl').focus();
				return;
			}
			else if(banklst == "1")
			{
				gid('MF:txtDrwBicCode').focus();
			}
			else if(banklst == "2")
			{
				gid('MF:txtDrwAcnt').focus();
			}
			
		}
		
		if(txtlst == "4")
		{
			reimbBiclist();
			setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10");
			if(banklst == "")
			{
				setMsg(BLANK_CHECK);
				gid('MF:lstReimbBank').focus();
				return;
			}
			else if(banklst == "1")
			{
				gid('MF:txtReimBicCode').focus();
			}
			else if(banklst == "2")
			{
				gid('MF:txtReimAcnt').focus();
			}
			
		}
		
		if(txtlst == "5")
		{
			AvlThrBiclist();
			setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent11");
			if(banklst == "")
			{
				setMsg(BLANK_CHECK);
				gid('MF:lstAdviseBank').focus();
				return;
			}
			else if(banklst == "1")
			{
				gid('MF:txtAdviseBicCode').focus();
			}
			else if(banklst == "2")
			{
				gid('MF:txtAdviseAcnt').focus();
			}
			
		}
		//Changes Sanjay1 18-07-2019 Begin
		if(txtlst == "6")
		{
			reimbcfmBiclist();
			setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10");
			if(banklst == "")
			{
				setMsg(BLANK_CHECK);
				gid('MF:lstReimbcfmBank').focus();
				return;
			}
			else if(banklst == "1")
			{
				gid('MF:txtReimcfmBicCode').focus();
			}
			else if(banklst == "2")
			{
				gid('MF:txtcfmReimAcnt').focus();
			}
			
		}
		//Changes Sanjay1 18-07-2019 End
	} 
	
	
	
	
	
	
	function validateIssueAddress1()
	{
	 	validateBankAddr(gid('MF:chkIssueBank').checked,gid('MF:lstIssueBICdtl').value,gid('MF:txtIssueAddress').value,"1");
	}
	

	
	function validateDateOfIssue()
	{
		if(trim(gid('MF:txtDateOfIssue').value)=="")
       	{	
       		 setMsg(BLANK_CHECK);
       		 gid('MF:txtDateOfIssue').focus();
       		 return;
	  	}
       	dateobj=parseDate(gid('MF:txtDateOfIssue').value,"true");
	  	if(dateobj == null)
   		{
   		    setMsg(INVALIDDATE);
			gid('MF:txtDateOfIssue').focus();
		   	return;		        
   		}
    	dateobj = formatDate(dateobj,'dd-MM-yyyy');
  		gid('MF:txtDateOfIssue').value =dateobj;
  		dateok = isDate(gid('MF:txtDateOfIssue').value,'dd-MM-yyyy');
		if (dateok == 0)
   		{
	   		setMsg(INVALIDDATE);
	   		gid('MF:txtDateOfIssue').focus();
	   		return ;
	   	}		
  		dateok =compareDates(dateobj,'dd-MM-yyyy', currbusDate,'dd-MM-yyyy');
  		if (!(dateok == 0) && !(dateok == 1))
   		{	
	   		setMsg(DATE_LESS_EQ_CBD);
	   		gid('MF:txtDateOfIssue').focus();
	   		return ;
   		} 
   		if (dateok == -1 ) 
   		{
   			setMsg(INVALIDDATE);
	   		gid('MF:txtDateOfIssue').focus();
	   		return ;
   		}
   		else
   		{
   			if(gid('MF:txtTakCharge').disabled == false)
   			{
	   			setTabfocus("maintab","tcontent10");;setTabfocus("subtab","tsubcontent2");
				gid('MF:txtTakCharge').focus();
			}
			else
			{
				setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent3");
				gid('MF:txtSendInfo').focus();
			}
   		}
	}
	
	
	function FetchlcDetails()
	{
					objXMLApplet3.clearMap();         			
					objXMLApplet3.setValue("Package", "panaceaweb.utility");
					objXMLApplet3.setValue("SQLToken","Valolcdetails");
					var Args = gid('MF:txtBranchCode').value+"|"+gid('MF:txtReferenceType').value+"|"+gid('MF:txtReferenceYear').value+"|"+gid("MF:txtReferenceSl").value;
					
					objXMLApplet3.setValue ("Args",Args);
					objXMLApplet3.setValue("DataTypes","N|S|N|N");     
					objXMLApplet3.sendAndReceive();
					if (objXMLApplet3.getValue("ErrorMsg") != "")
					{	
						setMsg(objXMLApplet3.getValue("ErrorMsg"));
						gid('MF:txtReferenceSl').focus();
						return;
					}
					//,receref,documen,drwaee,place tak,load ,dis, final,send to rec,period days + naar,
					if(objXMLApplet3.getValue("Result")=="RowPresent")
					{
					//gid('MF:txtReceRef').value=objXMLApplet3.getValue("LC_REC_BIC_CODE");//commentted by prashanth
					//gid('MF:txtReceRef').readOnly=true;
					gid('MF:txtDocCredit').value=gid("MF:txtCorrespondentRefNumber").value;
					if(objXMLApplet3.getValue("LC_DRAWEE_REQ") == "0")
					{
						gid('MF:chkIssueBank').checked=false;
		    			gid('MF:outlblIssueBank').innerText="No";	
		    		}
		    		else
		    		{
		    			gid('MF:chkIssueBank').checked=true;
		    			gid('MF:outlblIssueBank').innerText="Yes";	 
		    		}	
					gid('MF:lstIssueBICdtl').value=objXMLApplet3.getValue("LC_DRAWEE_TYPE");
					gid('MF:txtIssueBicCode').value=objXMLApplet3.getValue("LC_DRAWEE_BIC_CODE");
					gid('MF:txtIssueBicBrn').value=objXMLApplet3.getValue("LC_DRAWEE_BRN_CODE");
					gid('MF:txtIssueBankName').value=objXMLApplet3.getValue("LC_DRAWEE_BNK_CODE");
					gid('MF:txtIssueAcnt').value=objXMLApplet3.getValue("LC_DRAWEE_ROUTID");
					gid('MF:txtIssueAddress').value=trim(objXMLApplet3.getValue("LC_DRAWEE_ADDR1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("LC_DRAWEE_ADDR2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_DRAWEE_ADDR3"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_DRAWEE_ADDR4"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_DRAWEE_ADDR5"));
					gid('MF:txtIssueCntry').value=objXMLApplet3.getValue("LC_DRAWEE_CNTRY_CODE");
					//var parsedateobj=parseDate(objXMLApplet3.getValue("OLC_ENTD_ON"),"true");
					//gid('MF:txtDateOfIssue').value=formatDate(parsedateobj,'dd-MM-yyyy');
					//gid('MF:txtDateOfIssue').value=objXMLApplet3.getValue("OLC_ENTD_ON");
					gid('MF:txtTakCharge').value=objXMLApplet3.getValue("LC_PLACE_OF_TAKING_IN_CHARGE");
					gid('MF:txtPortLoad').value=objXMLApplet3.getValue("LC_PORT_OF_LOADING");
					gid('MF:txtPortDis').value=objXMLApplet3.getValue("LC_PORT_OF_DISCHARGE");
					gid('MF:txtPortDest').value=objXMLApplet3.getValue("LC_PLACE_OF_FINAL_DEST"); 
					gid('MF:txtShipmentPeriodSchedule').value=trim(objXMLApplet3.getValue("LC_SHIPMENT_PERIOD1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("LC_SHIPMENT_PERIOD2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_SHIPMENT_PERIOD3"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_SHIPMENT_PERIOD4"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_SHIPMENT_PERIOD5")) +"\r\n"+"" +trim(objXMLApplet3.getValue("LC_SHIPMENT_PERIOD6"));
					shipPer=trim(gid('MF:txtShipmentPeriodSchedule').value);
					gid('MF:txtSendInfo').value=trim(objXMLApplet3.getValue("LC_SNDR_REC_INFO1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("LC_SNDR_REC_INFO2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_SNDR_REC_INFO3"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_SNDR_REC_INFO4"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_SNDR_REC_INFO5"));
					//Changes Sanjay 16-08-2019 Begin
					gid('MF:lstcredit').value=objXMLApplet3.getValue("LC_FORM_OF_DOC_CREDIT");
					lstcredit_backup = gid('MF:lstcredit').value;
					gid('MF:lstAppRule').value=objXMLApplet3.getValue("LC_APPLICABLE_RULES");
					lstAppRule_backup = gid('MF:lstAppRule').value;
					gid('MF:lstAvl').value=objXMLApplet3.getValue("LC_AVAILABLE_WITH_CODETYP");
					lstAvl_backup = gid('MF:lstAvl').value;
					gid('MF:lstAvlBICdtl').value=objXMLApplet3.getValue("LC_AVAILABLE_WITH_TYPE");
					lstAvlBICdtl_backup = gid('MF:lstAvlBICdtl').value;
					gid('MF:txtAvlBicCode').value=objXMLApplet3.getValue("LC_AVAILABLE_WITH_CODE");
					txtAvlBicCode_backup = gid('MF:txtAvlBicCode').value;
					gid('MF:txtAvlBicBrn').value=objXMLApplet3.getValue("LC_AVAILABLE_WITH_BRN_CODE");
					txtAvlBicBrn_backup = gid('MF:txtAvlBicBrn').value;
					gid('MF:txtAvlBankName').value=objXMLApplet3.getValue("LC_AVAILABLE_WITH_BNK_CODE");
					txtAvlBankName_backup = gid('MF:txtAvlBankName').value;
					gid('MF:txtAvlAcnt').value=objXMLApplet3.getValue("LC_AVAILABLE_WITH_ROUTID");
					txtAvlAcnt_backup = gid('MF:txtAvlAcnt').value;
					gid('MF:txtAvlAddress').value=trim(objXMLApplet3.getValue("LC_AVAILABLE_WITH_ADDR1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("LC_AVAILABLE_WITH_ADDR2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_AVAILABLE_WITH_ADDR3"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_AVAILABLE_WITH_ADDR4"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_AVAILABLE_WITH_ADDR5"));
					txtAvlAddress_backup = gid('MF:txtAvlAddress').value;
					gid('MF:txtAvlCntry').value=objXMLApplet3.getValue("LC_AVAILABLE_WITH_CNTRY");
					txtAvlCntry_backup = gid('MF:txtAvlCntry').value;
					gid('MF:txtDraft').value=trim(objXMLApplet3.getValue("LC_DRAFTS_AT1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("LC_DRAFTS_AT2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_DRAFTS_AT3"));
					txtDraft_backup = gid('MF:txtDraft').value;
					if(objXMLApplet3.getValue("LC_DRAWEE_REQ") == "0")
					{
						gid('MF:chkDrawee').checked=false;
		    			gid('MF:outlblDrawee').innerText="No";	
		    		}
		    		else
		    		{
		    			gid('MF:chkDrawee').checked=true;
		    			gid('MF:outlblDrawee').innerText="Yes";	 
		    		}	
		    		chkDrawee_backup = objXMLApplet3.getValue("LC_DRAWEE_REQ");
					gid('MF:lstDrwBICdtl').value=objXMLApplet3.getValue("LC_DRAWEE_TYPE");
					lstDrwBICdtl_backup = gid('MF:lstDrwBICdtl').value;
					gid('MF:txtDrwBicCode').value=objXMLApplet3.getValue("LC_DRAWEE_BIC_CODE");
					txtDrwBicCode_backup = gid('MF:txtDrwBicCode').value;
					gid('MF:txtDrwBicBrn').value=objXMLApplet3.getValue("LC_DRAWEE_BRN_CODE");
					txtDrwBicBrn_backup = gid('MF:txtDrwBicBrn').value;
					gid('MF:txtDrwBankName').value=objXMLApplet3.getValue("LC_DRAWEE_BNK_CODE");
					txtDrwBankName_backup = gid('MF:txtDrwBankName').value;
					gid('MF:txtDrwAcnt').value=objXMLApplet3.getValue("LC_DRAWEE_ROUTID");
					txtDrwAcnt_backup = gid('MF:txtDrwAcnt').value;
					gid('MF:txtDrwAddress').value=trim(objXMLApplet3.getValue("LC_DRAWEE_ADDR1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("LC_DRAWEE_ADDR2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_DRAWEE_ADDR3"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_DRAWEE_ADDR4"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_DRAWEE_ADDR5"));
					txtDrwAddress_backup = gid('MF:txtDrwAddress').value;
					gid('MF:txtDrwCntry').value=objXMLApplet3.getValue("LC_DRAWEE_CNTRY_CODE");
					txtDrwCntry_backup = gid('MF:txtDrwCntry').value;
					gid('MF:txtMixedPaydtl').value=trim(objXMLApplet3.getValue("LC_MIXED_PAY_DETAILS1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("LC_MIXED_PAY_DETAILS2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_MIXED_PAY_DETAILS3"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_MIXED_PAY_DETAILS4"));
					txtMixedPaydtl_backup =gid('MF:txtMixedPaydtl').value; 
					gid('MF:txtDeferPaydtl').value=trim(objXMLApplet3.getValue("LC_DEFERRED_PAY_DETAILS1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("LC_DEFERRED_PAY_DETAILS2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_DEFERRED_PAY_DETAILS3"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_DEFERRED_PAY_DETAILS4"));
					txtDeferPaydtl_backup =gid('MF:txtDeferPaydtl').value; 
					gid('MF:lstparShip').value=objXMLApplet3.getValue("LC_PARTIAL_SHIPMENTS");
					lstparShip_backup =gid('MF:lstparShip').value; 
					gid('MF:lsttranShip').value=objXMLApplet3.getValue("LC_TRANSHIPMENT");
					lsttranShip_backup =gid('MF:lsttranShip').value; 
					gid('MF:lstConfInst').value=objXMLApplet3.getValue("LC_CONFIRMATION_INST");
					lstConfInst_backup =gid('MF:lstConfInst').value; 
					gid('MF:lstReimbcfmBank').value=objXMLApplet3.getValue("LC_CFM_REIMB_TYPE");
					lstReimbcfmBank_backup =gid('MF:lstReimbcfmBank').value; 
					gid('MF:txtReimcfmBicCode').value=objXMLApplet3.getValue("LC_CFM_REIMB_BIC_CODE");
					txtReimcfmBicCode_backup = gid('MF:txtReimcfmBicCode').value; 
					gid('MF:txtReimcfmBicBrn').value=objXMLApplet3.getValue("LC_CFM_REIMB_BRN_CODE");
					txtReimcfmBicBrn_backup = gid('MF:txtReimcfmBicBrn').value;
					gid('MF:txtcfmReimBankName').value=objXMLApplet3.getValue("LC_CFM_REIMB_BNK_CODE");
					txtcfmReimBankName_backup = gid('MF:txtcfmReimBankName').value;
					gid('MF:txtcfmReimAcnt').value=objXMLApplet3.getValue("LC_CFM_REIMB_ROUTID");
					txtcfmReimAcnt_backup = gid('MF:txtcfmReimAcnt').value; 
					gid('MF:txtcfmReimAddress').value=trim(objXMLApplet3.getValue("LC_CFM_REIMB_ADDR1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("LC_CFM_REIMB_ADDR2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_CFM_REIMB_ADDR3"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_CFM_REIMB_ADDR4"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_CFM_REIMB_ADDR5"));
					txtcfmReimAddress_backup = gid('MF:txtcfmReimAddress').value; 
					gid('MF:txtcfmReimCntry').value=objXMLApplet3.getValue("LC_CFM_REIMB_CNTRY_CODE");
					txtcfmReimCntry_backup = gid('MF:txtcfmReimCntry').value;
					if(objXMLApplet3.getValue("LC_REIMB_REQ") == "0")
					{
						gid('MF:chkReimb').checked=false;
		    			gid('MF:outlblReimb').innerText="No";	
		    		}
		    		else
		    		{
		    			gid('MF:chkReimb').checked=true;
		    			gid('MF:outlblReimb').innerText="Yes";	 
		    		}	
		    		chkReimb_backup = objXMLApplet3.getValue("LC_REIMB_REQ");
					gid('MF:lstReimbBank').value=objXMLApplet3.getValue("LC_REIMB_TYPE");
					lstReimbBank_backup = gid('MF:lstReimbBank').value;
					gid('MF:txtReimBicCode').value=objXMLApplet3.getValue("LC_REIMB_BIC_CODE");
					txtReimBicCode_backup = gid('MF:txtReimBicCode').value;
					gid('MF:txtReimBicBrn').value=objXMLApplet3.getValue("LC_REIMB_BRN_CODE");
					txtReimBicBrn_backup = gid('MF:txtReimBicBrn').value;
					gid('MF:txtReimBankName').value=objXMLApplet3.getValue("LC_REIMB_BNK_CODE");
					txtReimBankName_backup = gid('MF:txtReimBankName').value; 
					gid('MF:txtReimAcnt').value=objXMLApplet3.getValue("LC_REIMB_ROUTID");
					txtReimAcnt_backup = gid('MF:txtReimAcnt').value;
					gid('MF:txtReimAddress').value=trim(objXMLApplet3.getValue("LC_REIMB_ADDR1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("LC_REIMB_ADDR2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_REIMB_ADDR3"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_REIMB_ADDR4"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_REIMB_ADDR5"));
					txtReimAddress_backup = gid('MF:txtReimAddress').value; 
					gid('MF:txtReimCntry').value=objXMLApplet3.getValue("LC_REIMB_CNTRY_CODE");
					txtReimCntry_backup = gid('MF:txtReimCntry').value;
					gid('MF:txtInstPay').value=trim(objXMLApplet3.getValue("LC_INST_PAYING1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("LC_INST_PAYING2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_INST_PAYING3"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_INST_PAYING4"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("LC_INST_PAYING5"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_INST_PAYING6"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_INST_PAYING7"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("LC_INST_PAYING8"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_INST_PAYING9"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_INST_PAYING10"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("LC_INST_PAYING11"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_INST_PAYING12"));
					txtInstPay_backup = gid('MF:txtInstPay').value; 
					if(objXMLApplet3.getValue("LC_SECOND_ADV_REQ") == "0")
					{
						gid('MF:chkAdvise').checked=false;
		    			gid('MF:outlblAdvise').innerText="No";	
		    		}
		    		else
		    		{
		    			gid('MF:chkAdvise').checked=true;
		    			gid('MF:outlblAdvise').innerText="Yes";	 
		    		}	
		    		chkAdvise_backup = objXMLApplet3.getValue("LC_SECOND_ADV_REQ");
					gid('MF:lstAdviseBank').value=objXMLApplet3.getValue("LC_SECOND_ADV_TYPE");
					lstAdviseBank_backup = gid('MF:lstAdviseBank').value; 
					gid('MF:txtAdviseBicCode').value=objXMLApplet3.getValue("LC_SECOND_ADV_BIC_CODE");
					txtAdviseBicCode_backup = gid('MF:txtAdviseBicCode').value; 
					gid('MF:txtAdviseBicBrn').value=objXMLApplet3.getValue("LC_SECOND_ADV_BRN_CODE");
					txtAdviseBicBrn_backup = gid('MF:txtAdviseBicBrn').value; 
					gid('MF:txtAdviseBankName').value=objXMLApplet3.getValue("LC_SECOND_ADV_BNK_CODE");
					txtAdviseBankName_backup = gid('MF:txtAdviseBankName').value; 
					gid('MF:txtAdviseAcnt').value=objXMLApplet3.getValue("LC_SECOND_ADV_ROUTID");
					txtAdviseAcnt_backup = gid('MF:txtAdviseAcnt').value;
					gid('MF:txtAdviseAddress').value=trim(objXMLApplet3.getValue("LC_SECOND_ADV_ADDR1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("LC_SECOND_ADV_ADDR2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_SECOND_ADV_ADDR3"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_SECOND_ADV_ADDR4"))+"\r\n"+"" +trim(objXMLApplet3.getValue("LC_SECOND_ADV_ADDR5"));
					txtAdviseAddress_backup = gid('MF:txtAdviseAddress').value;
					gid('MF:txtAdviseCntry').value=objXMLApplet3.getValue("LC_SECOND_ADV_CNTRYCODE");
					txtAdviseCntry_backup = gid('MF:txtAdviseCntry').value; 
					avlBicList();
					draweeBicList();
					reimbcfmBiclist();
					reimbBiclist();
					AvlThrBiclist();
					//Changes Sanjay 16-08-2019 End 
					placeTake =gid('MF:txtTakCharge').value;
					placeload =gid('MF:txtPortLoad').value;
					placeDis =gid('MF:txtPortDis').value;
					placeFinal =gid('MF:txtPortDest').value;
					shipSch=gid('MF:txtShipmentPeriodSchedule').value;
					sendInfo=gid('MF:txtSendInfo').value;
					
					IssueBicList();
					}
					else if(objXMLApplet3.getValue("Result")=="RowNotPresent")
					{
						//alert("No Records Present");
						gid('MF:txtDocCredit').value=gid("MF:txtCorrespondentRefNumber").value;
						//gid('MF:txtReceRef').readOnly=false;
					}
}

	
	function fetchfromOLCAMDDETAILS()
	{
					var Args1 = "";
					objXMLApplet3.clearMap();         			
					objXMLApplet3.setValue("Package", "panaceaweb.utility");
					objXMLApplet3.setValue("SQLToken","Valolcamddetails");
					if(gid("MF:seluseroption").value=="M")
						Args1 = gid('MF:txtBranchCode').value+"|"+gid('MF:txtReferenceType').value+"|"+gid('MF:txtReferenceYear').value+"|"+gid("MF:txtReferenceSl").value+"|"+parseInt(gid('MF:txtAmendmentSerial').value);
					else
						Args1 = gid('MF:txtBranchCode').value+"|"+gid('MF:txtReferenceType').value+"|"+gid('MF:txtReferenceYear').value+"|"+gid("MF:txtReferenceSl").value+"|"+(parseInt(gid("MF:txtAmendmentSerial").value)-1);
					objXMLApplet3.setValue ("Args",Args1);
					objXMLApplet3.setValue("DataTypes","N|S|N|N|N");     
					objXMLApplet3.sendAndReceive();
					if (objXMLApplet3.getValue("ErrorMsg") != "")
					{	
						setMsg(objXMLApplet3.getValue("ErrorMsg"));
						gid('MF:txtAmendmentSerial').focus();
						return;
					}
					
				if(gid("MF:seluseroption").value=="M" || gid("MF:txtAmendmentSerial").value > 1 )
				{
					if(objXMLApplet3.getValue("Result")=="RowPresent")
					{
					
					//ADDED BY PRASHANTH ON 23 FEB 2019 FOR FETCHING NEW FIELDS IN MODIFY MODE
                        LoadNewFieldsModifyMode();					
					//ADDED BY PRASHANTH ON 23 FEB 2019 FOR FETCHING NEW FIELDS IN MODIFY MODE
					
					var detailCheckBox = objXMLApplet3.getValue("AMEND_CHKBOX");
					
					var expiryDate = detailCheckBox.split("|")[0];
					var incdecr = detailCheckBox.split("|")[1];
					var perTolr = detailCheckBox.split("|")[2];
					var placePort = detailCheckBox.split("|")[3];
					var shipPeriod = detailCheckBox.split("|")[4];
					
					if(expiryDate == "0")
					{
						gid('MF:chkExpiryDate').checked=false;
		    			gid('MF:outlblExpiryDate').innerText="No";	
		    		}
		    		else
		    		{
		    			gid('MF:chkExpiryDate').checked=true;
		    			gid('MF:outlblExpiryDate').innerText="Yes";	
		    		}
		    		if(incdecr == "0")
					{
						gid('MF:chkIncDec').checked=false;
		    			gid('MF:outlblIncDec').innerText="No";	
		    		}
		    		else
		    		{
		    			gid('MF:chkIncDec').checked=true;
		    			gid('MF:outlblIncDec').innerText="Yes";	
		    		}
		    		if(perTolr == "0")
					{
						gid('MF:chkPerTolr').checked=false;
		    			gid('MF:outlblPerTolr').innerText="No";	
		    		}
		    		else
		    		{
		    			gid('MF:chkPerTolr').checked=true;
		    			gid('MF:outlblPerTolr').innerText="Yes";	
		    		}
		    		if(placePort == "0")
					{
						gid('MF:chkPlacePort').checked=false;
		    			gid('MF:outlblPlacePort').innerText="No";	
		    		}
		    		else
		    		{
		    			gid('MF:chkPlacePort').checked=true;
		    			gid('MF:outlblPlacePort').innerText="Yes";	
		    		}
		    		if(shipPeriod == "0")
					{
						gid('MF:chkShipPeriod').checked=false;
		    			gid('MF:outlblShipPeriod').innerText="No";	
		    		}
		    		else
		    		{
		    			gid('MF:chkShipPeriod').checked=true;
		    			gid('MF:outlblShipPeriod').innerText="Yes";	
		    		}
		    		if(objXMLApplet3.getValue("AMEND_ISSUING_BNK_REQ") == "0")
					{
						gid('MF:chkIssueBank').checked=false;
		    			gid('MF:outlblIssueBank').innerText="No";	
		    		}
		    		else
		    		{
		    			gid('MF:chkIssueBank').checked=true;
		    			gid('MF:outlblIssueBank').innerText="Yes";	
		    		}
		    		//Changes Sanjay 02-07-2019 Begin
		    		oldchkExpiryDate=gid("MF:chkExpiryDate").checked;
				    oldchkIncDec=gid("MF:chkIncDec").checked;
				    oldchkPerTolr=gid("MF:chkPerTolr").checked;
				    oldchkShipPeriod=gid("MF:chkShipPeriod").checked;
				    //Changes Sanjay 02-07-2019 End
					gid('MF:txtReceRef').value=objXMLApplet3.getValue("AMEND_RCVR_REF");
					gid('MF:txtDocCredit').value=objXMLApplet3.getValue("AMEND_DOC_CR_NUM");
					
		    		
		    		
					gid('MF:lstIssueBICdtl').value=objXMLApplet3.getValue("AMEND_ISSUING_TYPE");
					gid('MF:txtIssueBicCode').value=objXMLApplet3.getValue("AMEND_ISSUING_BIC_CODE");
					gid('MF:txtIssueBicBrn').value=objXMLApplet3.getValue("AMEND_ISSUING_BRN_CODE");
					gid('MF:txtIssueBankName').value=objXMLApplet3.getValue("AMEND_ISSUING_BNK_CODE");
					gid('MF:txtIssueAcnt').value=objXMLApplet3.getValue("AMEND_ISSUING_ROUTID");
					gid('MF:txtIssueAddress').value=trim(objXMLApplet3.getValue("AMEND_ISSUING_ADDR1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("AMEND_ISSUING_ADDR2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_ISSUING_ADDR3"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_ISSUING_ADDR4"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_ISSUING_ADDR5"));
					gid('MF:txtIssueCntry').value=objXMLApplet3.getValue("AMEND_ISSUING_CNTRY");
					gid('MF:txtDateOfIssue').value=objXMLApplet3.getValue("AMEND_DATE_OF_ISSUE");
					gid('MF:txtTakCharge').value=objXMLApplet3.getValue("AMEND_PLACE_TAKIN_IN_CHRG");
					gid('MF:txtPortLoad').value=objXMLApplet3.getValue("AMEND_PORT_OF_LOADING");
					gid('MF:txtPortDis').value=objXMLApplet3.getValue("AMEND_PORT_OF_DISCHARGE");
					gid('MF:txtPortDest').value=objXMLApplet3.getValue("AMEND_PLACE_OF_FINAL_DEST");
					//Changes Sanjay1 18-07-2019 Begin
					//gid('MF:txtNarrative').value=objXMLApplet3.getValue("AMEND_NARRATIVE");
					//Changes Sanjay1 18-07-2019 End
					gid('MF:txtSendInfo').value=trim(objXMLApplet3.getValue("AMEND_SNDR_REC_INFO1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("AMEND_SNDR_REC_INFO2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_SNDR_REC_INFO3"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_SNDR_REC_INFO4"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_SNDR_REC_INFO5"));
					//ADDED BY PRASHANTH ON 27 JUNE 2019
					gid('MF:txtCharge').value=trim(objXMLApplet3.getValue("AMEND_CHRG_PAYABLE1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("AMEND_CHRG_PAYABLE2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_CHRG_PAYABLE3"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_CHRG_PAYABLE4"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_CHRG_PAYABLE5")) +"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_CHRG_PAYABLE6"));
					//ADDED BY PRASHANTH ON 27 JUNE 2019
					//FetchClobData();
					
					//ADDED BY PRASHANTH ON 08 FEB 2019
					// FetchClobData();
					//ADDED BY PRASHANTH ON 08 FEB 2019
					placeTake =gid('MF:txtTakCharge').value;
					placeload =gid('MF:txtPortLoad').value;
					placeDis =gid('MF:txtPortDis').value;
					placeFinal =gid('MF:txtPortDest').value;
					shipSch=gid('MF:txtShipmentPeriodSchedule').value;
					sendInfo=gid('MF:txtSendInfo').value;
					IssueBicList();
					checkExpiryDate();
					checkIncrDecr();
					checkPerTolr();
				    checkPlacePort();
					checkShipPeriod();	
					chkbenficiary();	
					}
					else if(objXMLApplet3.getValue("Result")=="RowNotPresent")
					{
						alert("No REcords Present");
					}
					
				}
				else
				{
					gid('MF:txtDateOfIssue').value=objXMLApplet3.getValue("AMEND_DATE_OF_ISSUE");
				}

	}

		//ADDED BY PRASHANTH ON 23 FEB 2019 FOR FETCHING NEW FIELDS IN MODIFY MODE
		function LoadNewFieldsModifyMode(){
		 /*olc dtls  tab*/
		 
		 
			gid('MF:lstcredit').value=objXMLApplet3.getValue("AMEND_FORM_OF_DOC_CREDIT");
			oldFormOfDC=gid('MF:lstcredit').value;
			lstcredit_backup = gid('MF:lstcredit').value;
			gid('MF:lstAppRule').value=objXMLApplet3.getValue("AMEND_LC_APPLICABLE_RULES");
			lstAppRule_backup = gid('MF:lstAppRule').value;
			gid('MF:txtApplName').value=objXMLApplet3.getValue("AMEND_LC_APPLICANT_NAME");
			gid('MF:txtApplAddress').value=trim(objXMLApplet3.getValue("AMEND_LC_APPLICANT_ADDR1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("AMEND_LC_APPLICANT_ADDR2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_LC_APPLICANT_ADDR3"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_LC_APPLICANT_ADDR4"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_LC_APPLICANT_ADDR5"));
			
			oldApplName=gid('MF:txtApplName').value;
			oldApplAddress=gid('MF:txtApplAddress').value;
			//Changes Sanjay1 18-07-2019 Begin
			//gid('MF:lstAppRule').value=objXMLApplet3.getValue("AMEND_LC_APPLICANT_RULES");
			//Changes Sanjay1 18-07-2019 End
		 /*olc dtls tab*/
			
		 /*avl with  tab*/
		 
		 
		    gid('MF:lstAvl').value=objXMLApplet3.getValue("AMEND_LC_AVL_WITH_CODETYP");
		    lstAvl_backup = gid('MF:lstAvl').value;
			gid('MF:lstAvlBICdtl').value=objXMLApplet3.getValue("AMEND_LC_AVL_WITH_TYPE");
			lstAvlBICdtl_backup = gid('MF:lstAvlBICdtl').value;
			//Changes Sanjay1 18-07-2019 Begin
			gid('MF:txtAvlBicCode').value=objXMLApplet3.getValue("AMEND_LC_AVL_WITH_BIC_CODE");
			txtAvlBicCode_backup = gid('MF:txtAvlBicCode').value;
			//Changes Sanjay1 18-07-2019 Begin
			gid('MF:txtAvlBicBrn').value=objXMLApplet3.getValue("AMEND_LC_AVL_WITH_BRN_CODE");
			txtAvlBicBrn_backup = gid('MF:txtAvlBicBrn').value;
			gid('MF:txtAvlAcnt').value=objXMLApplet3.getValue("AMEND_LC_LC_AVL_WITH_ROUTID");
			txtAvlAcnt_backup = gid('MF:txtAvlAcnt').value;
			gid('MF:txtAvlBankName').value=objXMLApplet3.getValue("AMEND_LC_AVL_WITH_BNK_CODE");
			txtAvlBankName_backup = gid('MF:txtAvlBankName').value;
			gid('MF:txtAvlAddress').value=trim(objXMLApplet3.getValue("AMEND_LC_AVL_WITH_ADDR1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("AMEND_LC_AVL_WITH_ADDR2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_LC_AVL_WITH_ADDR3"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_LC_AVL_WITH_ADDR4"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_LC_AVL_WITH_ADDR5"));
			txtAvlAddress_backup = gid('MF:txtAvlAddress').value;
			gid('MF:txtAvlCntry').value=objXMLApplet3.getValue("AMEND_LC_AVL_WITH_CNTRY");
			txtAvlCntry_backup = gid('MF:txtAvlCntry').value;
			avlBicList();
			gid('MF:txtDraft').value=trim(objXMLApplet3.getValue("AMEND_LC_DRAFTS_AT1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("AMEND_LC_DRAFTS_AT2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_LC_DRAFTS_AT3"));
			txtDraft_backup = gid('MF:txtDraft').value;
			/*avl with  tab*/
			
			/*drawee  tab*/
			if(objXMLApplet3.getValue("AMEND_LC_DRAWEE_REQ") == "0")
			{
				gid('MF:chkDrawee').checked=false;
	   			gid('MF:outlblDrawee').innerText="No";	
	   		}
	   		else
	   		{
	   			gid('MF:chkDrawee').checked=true;
	   			gid('MF:outlblDrawee').innerText="Yes";	
	   		}
	   		chkDrawee_backup = objXMLApplet3.getValue("AMEND_LC_DRAWEE_REQ");
			gid('MF:lstDrwBICdtl').value=objXMLApplet3.getValue("AMEND_LC_DRAWEE_TYPE");
			lstDrwBICdtl_backup = gid('MF:lstDrwBICdtl').value;
			gid('MF:txtDrwBicBrn').value=objXMLApplet3.getValue("AMEND_LC_DRAWEE_BRN_CODE");
			txtDrwBicBrn_backup = gid('MF:txtDrwBicBrn').value;
			gid('MF:txtDrwBicCode').value=objXMLApplet3.getValue("AMEND_LC_DRAWEE_BIC_CODE");
			txtDrwBicCode_backup = gid('MF:txtDrwBicCode').value;
			gid('MF:txtDrwAcnt').value=objXMLApplet3.getValue("AMEND_LC_DRAWEE_ROUTID");
			txtDrwAcnt_backup = gid('MF:txtDrwAcnt').value;
			gid('MF:txtDrwBankName').value=objXMLApplet3.getValue("AMEND_LC_DRAWEE_BNK_CODE");
			txtDrwBankName_backup = gid('MF:txtDrwBankName').value;
			gid('MF:txtDrwAddress').value=trim(objXMLApplet3.getValue("AMEND_LC_DRAWEE_ADDR1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("AMEND_LC_DRAWEE_ADDR2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_LC_DRAWEE_ADDR3"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_LC_DRAWEE_ADDR4"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_LC_DRAWEE_ADDR5"));
			txtDrwAddress_backup = gid('MF:txtDrwAddress').value;
			gid('MF:txtDrwCntry').value=objXMLApplet3.getValue("AMEND_DRAWEE_CNTRY_CODE");
			txtDrwCntry_backup = gid('MF:txtDrwCntry').value;
			draweeBicList();
			//Changes Sanjay1 18-07-2019 Begin
			if((trim(objXMLApplet3.getValue("AMEND_LC_MIXED_PAY_DETAILS1"))!="") || (trim(objXMLApplet3.getValue("AMEND_LC_MIXED_PAY_DETAILS2"))!="") || (trim(objXMLApplet3.getValue("AMEND_LC_MIXED_PAY_DETAILS3"))!="") || (trim(objXMLApplet3.getValue("AMEND_LC_MIXED_PAY_DETAILS4"))!=""))
			{
				gid('MF:txtMixedPaydtl').value=trim(objXMLApplet3.getValue("AMEND_LC_MIXED_PAY_DETAILS1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("AMEND_LC_MIXED_PAY_DETAILS2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_LC_MIXED_PAY_DETAILS3"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_LC_MIXED_PAY_DETAILS4"));
				txtMixedPaydtl_backup =gid('MF:txtMixedPaydtl').value; 
			}
			else
			{
				gid('MF:txtMixedPaydtl').value="";
			}
			if((trim(objXMLApplet3.getValue("AMEND_LC_DEFERRED_PAY_DETAILS1"))!="") || (trim(objXMLApplet3.getValue("AMEND_LC_DEFERRED_PAY_DETAILS2"))!="") || (trim(objXMLApplet3.getValue("AMEND_LC_DEFERRED_PAY_DETAILS3"))!="") || (trim(objXMLApplet3.getValue("AMEND_LC_DEFERRED_PAY_DETAILS4"))!=""))
			{
				gid('MF:txtDeferPaydtl').value=trim(objXMLApplet3.getValue("AMEND_LC_DEFERRED_PAY_DETAILS1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("AMEND_LC_DEFERRED_PAY_DETAILS2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_LC_DEFERRED_PAY_DETAILS3"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_LC_DEFERRED_PAY_DETAILS4"));
				txtDeferPaydtl_backup =gid('MF:txtDeferPaydtl').value; 
			}
			else
			{
				gid('MF:txtDeferPaydtl').value="";
			}
			//Changes Sanjay1 18-07-2019 End
			gid('MF:lstparShip').value=objXMLApplet3.getValue("AMEND_LC_PARTIAL_SHIPMENTS");
			lstparShip_backup =gid('MF:lstparShip').value; 
			gid('MF:lsttranShip').value=objXMLApplet3.getValue("AMEND_LC_TRANSHIPMENT");
			lsttranShip_backup =gid('MF:lsttranShip').value; 
			/*drawee  tab*/
			
			/*Reimb  tab*/
			gid('MF:lstConfInst').value=objXMLApplet3.getValue("AMEND_LC_CONFIRMATION_INST");
			lstConfInst_backup =gid('MF:lstConfInst').value; 
			//Changes Sanjay1 18-07-2019 Begin
			/*gid('MF:txtConfirmedByBank').value=objXMLApplet3.getValue("AMEND_LC_CNF_BY_BANK");
			
			if(objXMLApplet3.getValue("AMEND_LC_CNF_BY_BRN")!="0"){
			gid('MF:txtConfirmedBYBranch').value=objXMLApplet3.getValue("AMEND_LC_CNF_BY_BRN");
			}*/
			gid('MF:lstReimbcfmBank').value=objXMLApplet3.getValue("AMEND_LC_CNF_ADV_TYPE");
			lstReimbcfmBank_backup =gid('MF:lstReimbcfmBank').value; 
			gid('MF:txtReimcfmBicBrn').value=objXMLApplet3.getValue("AMEND_LC_CNF_ADV_BRN_CODE");
			txtReimcfmBicBrn_backup = gid('MF:txtReimcfmBicBrn').value;
			gid('MF:txtReimcfmBicCode').value=objXMLApplet3.getValue("AMEND_LC_CNF_ADV_BIC_CODE");
			txtReimcfmBicCode_backup = gid('MF:txtReimcfmBicCode').value; 
			gid('MF:txtcfmReimAcnt').value=objXMLApplet3.getValue("AMEND_LC_CNF_ADV_ROUTID");
			txtcfmReimAcnt_backup = gid('MF:txtcfmReimAcnt').value; 
			gid('MF:txtcfmReimBankName').value=objXMLApplet3.getValue("AMEND_LC_CNF_ADV_BNK_CODE");
			txtcfmReimBankName_backup = gid('MF:txtcfmReimBankName').value;
		    gid('MF:txtcfmReimAddress').value=trim(objXMLApplet3.getValue("AMEND_LC_CNF_ADV_ADDR1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("AMEND_LC_CNF_ADV_ADDR2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_LC_CNF_ADV_ADDR3"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_LC_CNF_ADV_ADDR4"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_LC_CNF_ADV_ADDR5"));
		    txtcfmReimAddress_backup = gid('MF:txtcfmReimAddress').value; 
		    gid('MF:txtcfmReimCntry').value=objXMLApplet3.getValue("AMEND_LC_CNF_ADV_CNTRYCODE");
		    txtcfmReimCntry_backup = gid('MF:txtcfmReimCntry').value;
		    reimbcfmBiclist();
			//Changes Sanjay1 18-07-2019 End
			if(objXMLApplet3.getValue("AMEND_LC_REIMB_REQ") == "0")
			{
				gid('MF:chkReimb').checked=false;
	    		gid('MF:outlblReimb').innerText="No";
	   		}
	   		else
	   		{
	   			gid('MF:chkReimb').checked=true;
	    		gid('MF:outlblReimb').innerText="Yes";
	   		}
	   		chkReimb_backup = objXMLApplet3.getValue("AMEND_LC_REIMB_REQ");
			gid('MF:lstReimbBank').value=objXMLApplet3.getValue("AMEND_LC_REIMB_TYPE");
			lstReimbBank_backup = gid('MF:lstReimbBank').value;
			gid('MF:txtReimBicBrn').value=objXMLApplet3.getValue("AMEND_LC_REIMB_BRN_CODE");
			txtReimBicBrn_backup = gid('MF:txtReimBicBrn').value;
			gid('MF:txtReimBicCode').value=objXMLApplet3.getValue("AMEND_LC_REIMB_BIC_CODE");
			txtReimBicCode_backup = gid('MF:txtReimBicCode').value;
			gid('MF:txtReimAcnt').value=objXMLApplet3.getValue("AMEND_LC_REIMB_ROUTID");
			txtReimAcnt_backup = gid('MF:txtReimAcnt').value;
			gid('MF:txtReimBankName').value=objXMLApplet3.getValue("AMEND_LC_REIMB_BNK_CODE");
			txtReimBankName_backup = gid('MF:txtReimBankName').value; 
		    gid('MF:txtReimAddress').value=trim(objXMLApplet3.getValue("AMEND_LC_REIMB_ADDR1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("AMEND_LC_REIMB_ADDR2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_LC_REIMB_ADDR3"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_LC_REIMB_ADDR4"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_LC_REIMB_ADDR5"));
		    txtReimAddress_backup = gid('MF:txtReimAddress').value; 
		    //28 JUNE 2019
		    gid('MF:txtReimCntry').value=objXMLApplet3.getValue("AMEND_LC_REIMB_CNTRY_CODE");
		    txtReimCntry_backup = gid('MF:txtReimCntry').value;
		    reimbBiclist();
		    //28 JUNE 2019
			gid('MF:txtInstPay').value=trim(objXMLApplet3.getValue("AMEND_LC_INST_PAYING1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("AMEND_LC_INST_PAYING2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_LC_INST_PAYING3"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_LC_INST_PAYING4"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_LC_INST_PAYING5")) +"\r\n"+"" + trim(objXMLApplet3.getValue("AMEND_LC_INST_PAYING6"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("AMEND_LC_INST_PAYING7"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_LC_INST_PAYING8"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_LC_INST_PAYING9"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_LC_INST_PAYING10"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_LC_INST_PAYING11"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_LC_INST_PAYING12"));
			txtInstPay_backup = gid('MF:txtInstPay').value;
			/*Reimb  tab*/
			/*Advice Bank  tab*/
			
			if(objXMLApplet3.getValue("AMEND_LC_SECOND_ADV_REQ") == "0")
			{
				gid('MF:chkAdvise').checked=false;
	   			gid('MF:outlblAdvise').innerText="No";   
	   		}
	   		else
	   		{
	   			gid('MF:chkAdvise').checked=true;
	   			gid('MF:outlblAdvise').innerText="Yes";
	   		}
	   		
	   		chkAdvise_backup = objXMLApplet3.getValue("AMEND_LC_SECOND_ADV_REQ");
	   		if(gid('MF:chkAdvise').checked==true)
		{
			gid('MF:outlblAdvise').innerText="Yes";
			//gid('MF:lstAdviseBank').value ="";
			gid('MF:lstAdviseBank').disabled=false;
			gid('MF:txtAdviseBicCode').disabled=false;
			gid('MF:txtAdviseBicBank').readOnly=false;
			gid('MF:txtAdviseBicBrn').readOnly=false;
			gid('MF:txtAdviseBankName').readOnly=false;
			gid('MF:txtAdviseAddress').readOnly=false;
			gid('MF:txtAdviseCntry').readOnly=false;
			gid('MF:txtAdviseAcnt').readOnly=false;
			
		}
		else
		{
			gid('MF:outlblAdvise').innerText="No";
			gid('MF:lstAdviseBank').value ="";
			gid('MF:lstAdviseBank').disabled=true;
			gid('MF:txtAdviseBicCode').disabled=true;
			gid('MF:txtAdviseBicBank').readOnly=true;
			gid('MF:txtAdviseBicBrn').readOnly=true;
			gid('MF:txtAdviseBankName').readOnly=true;
			gid('MF:txtAdviseAddress').readOnly=true;
			gid('MF:txtAdviseCntry').readOnly=true;
			gid('MF:txtAdviseAcnt').readOnly=true;
		}
	   		
	   		
			gid('MF:lstAdviseBank').value=objXMLApplet3.getValue("AMEND_LC_SECOND_ADV_TYPE");
			lstAdviseBank_backup = gid('MF:lstAdviseBank').value; 
			gid('MF:txtAdviseBicBrn').value=objXMLApplet3.getValue("AMEND_LC_SECOND_ADV_BRN_CODE");
			txtAdviseBicBrn_backup = gid('MF:txtAdviseBicBrn').value; 
			gid('MF:txtAdviseBicCode').value=objXMLApplet3.getValue("AMEND_LC_SECOND_ADV_BIC_CODE");
			txtAdviseBicCode_backup = gid('MF:txtAdviseBicCode').value; 
			gid('MF:txtAdviseAcnt').value=objXMLApplet3.getValue("AMEND_LC_SECOND_ADV_ROUTID");
			txtAdviseAcnt_backup = gid('MF:txtAdviseAcnt').value;
			gid('MF:txtAdviseBankName').value=objXMLApplet3.getValue("AMEND_LC_SECOND_ADV_BNK_CODE");
			txtAdviseBankName_backup = gid('MF:txtAdviseBankName').value; 
			gid('MF:txtAdviseAddress').value=trim(objXMLApplet3.getValue("AMEND_LC_SECOND_ADV_ADDR1"))+ "\r\n"+"" + trim(objXMLApplet3.getValue("AMEND_LC_SECOND_ADV_ADDR2"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_LC_SECOND_ADV_ADDR3"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_LC_SECOND_ADV_ADDR4"))+"\r\n"+"" +trim(objXMLApplet3.getValue("AMEND_LC_SECOND_ADV_ADDR5"));
			txtAdviseAddress_backup = gid('MF:txtAdviseAddress').value;
		    gid('MF:txtAdviseCntry').value=objXMLApplet3.getValue("AMEND_LC_SECOND_ADV_CNTRYCODE");
		    txtAdviseCntry_backup = gid('MF:txtAdviseCntry').value; 
		    AvlThrBiclist();
			/*Advice Bank  tab*/
		}








			function loadAmdChoiceMod(amdFor){
			    var value="";
			    var objXMLApplet5=new xmlHTTPValidator();
			    var fromRange="";
			    var upToRange="";
			    var choiceSerial="";
			    var chslforgrid;
			    
			    
			    if(amdFor=="45B"){
			    	value=gid('MF:amdGoodsValue').value;
			    	choiceSerial=gid('MF:txtChoiceSl');
			    	chslforgrid="choiceSlforGrid1";
			    }
			    else if(amdFor=="46B"){
			    	value=gid('MF:amdDocsValue').value;
			    	choiceSerial=gid('MF:txtChoiceSlDoc');
			    	chslforgrid="choiceSlforGrid2";
			    }
			    else if(amdFor=="47B"){
			    	value=gid('MF:amdAddlValue').value;
			    	choiceSerial=gid('MF:txtChoiceSlAddl');
			    	chslforgrid="choiceSlforGrid3";
			    }
			    else if(amdFor=="49M"){
			    	value=gid('MF:amdSpl1Value').value;
			    	choiceSerial=gid('MF:txtChoiceSlSplBene');
			    	chslforgrid="choiceSlforGrid4";
			    }
			     else if(amdFor=="49N"){
			     	value=gid('MF:amdSpl2Value').value;
			     	choiceSerial=gid('MF:txtChoiceSlSplRecev');
			    	chslforgrid="choiceSlforGrid5";
			    }
				objXMLApplet5.clearMap();
				objXMLApplet5.setValue("Package","panacea.OLCaction.eolcamdval"); 
				objXMLApplet5.setValue("Method","loadAmdChoiceMod");
	            objXMLApplet5.setValue("ValidateToken","true");
	            objXMLApplet5.setValue("OLC_BRN_CODE",trim(gid('MF:txtBranchCode').value));
	            objXMLApplet5.setValue("OLC_TYPE",trim(gid('MF:txtReferenceType').value));
	            objXMLApplet5.setValue("OLC_YEAR",trim(gid('MF:txtReferenceYear').value));
	            objXMLApplet5.setValue("OLC_LC_SL",trim(gid('MF:txtReferenceSl').value));
	            objXMLApplet5.setValue("OLC_AMD_SL",trim(gid('MF:txtAmendmentSerial').value));
	            objXMLApplet5.setValue("AMDFOR",trim(amdFor));
	         	objXMLApplet5.setValue("MODE",trim(gid('MF:seluseroption').value));
	            
	           	objXMLApplet5.sendAndReceive();
	           	if(objXMLApplet5.getValue("ErrorMsg") != "")
				{
					setMsg(objXMLApplet5.getValue("ErrorMsg"));
					gid('MF:txtApplInsOrRepl').focus();
					return;  
				}
				else
				{
					if (objXMLApplet5.getValue("Result") == "RowPresent"&& objXMLApplet5.getValue("OLCAC_CHOICE_SL").length>0) 
	   				 {	
				
					var arr = [];
					arr=objXMLApplet5.getValue("OLCAC_CHOICE_SL").split("/");
					
					var arr2 = [];
					arr2=objXMLApplet5.getValue("OLCAC_AMD_CHOICE").split("/");
					
					
					var arr3 = [];
					arr3=objXMLApplet5.getValue("OLCAC_AMD_RANGE_FROM").split("/");
					
					
					var arr4 = [];
					arr4=objXMLApplet5.getValue("OLCAC_AMD_RANGE_UPTO").split("/");
					
					
				//if empty gid('MF:amdGoodsValue').value=gid('MF:txtChoiceSl').value+","+gid('MF:txtfrmRange').value+","+gid('MF:uptoRange').value+","+gid('MF:lstamdChoice').value;
					
				// 	else gid('MF:amdGoodsValue').value=gid('MF:amdGoodsValue').value+"|"+gid('MF:txtChoiceSl').value+","+gid('MF:txtfrmRange').value+","+gid('MF:uptoRange').value+","+gid('MF:lstamdChoice').value;
					
					var logvalueLength = objXMLApplet5.getValue("OLCAC_CHOICE_SL").split("/").length;
				    for(var i=1; i<=logvalueLength; i++) {
					    	if(value==""){
					    		value=arr[i-1]+","+arr3[i-1]+","+arr4[i-1]+","+arr2[i-1];
					    		
					    		if(amdFor=="45B"){
					    			addValueToKey(chslforgrid,value);
					    		}
					    		else if(amdFor=="46B"){
					    			addValueToKey2(chslforgrid,value);
					    		}
					    		else if(amdFor=="47B"){
					    			addValueToKey3(chslforgrid,value);
					    		}
					    		else if(amdFor=="49M"){
					    			addValueToKey4(chslforgrid,value);
					    		}
					    		else if(amdFor=="49N"){
					    		    addValueToKey5(chslforgrid,value);
					    		}
					    		choiceSerial.value=parseInt(0)+1;
					    		
					    		if(amdFor=="45B"){
					    			choiceSlforGrid1=parseInt(choiceSerial.value);
					    		}
					    		else if(amdFor=="46B"){
					    			choiceSlforGrid2=parseInt(choiceSerial.value);
					    		}
					    		else if(amdFor=="47B"){
					    			choiceSlforGrid3=parseInt(choiceSerial.value);
					    		}
					    		else if(amdFor=="49M"){
					    			choiceSlforGrid4=parseInt(choiceSerial.value);
					    		}
					    		else if(amdFor=="49N"){
					    			choiceSlforGrid5=parseInt(choiceSerial.value);
					    		}
					    		
					    	}
					    	else{
					    		value=value+"|"+arr[i-1]+","+arr3[i-1]+","+arr4[i-1]+","+arr2[i-1];
					    		if(amdFor=="45B"){
					    			addValueToKey(chslforgrid,value);
					    		}
					    		else if(amdFor=="46B"){
					    			addValueToKey2(chslforgrid,value);
					    		}
					    		else if(amdFor=="47B"){
					    			addValueToKey3(chslforgrid,value);
					    		}
					    		else if(amdFor=="49M"){
					    			addValueToKey4(chslforgrid,value);
					    		}
					    		else if(amdFor=="49N"){
					    		    addValueToKey5(chslforgrid,value);
					    		 }
					    		choiceSerial.value=parseInt(choiceSerial.value)+1;
					    		
					    		if(amdFor=="45B"){
					    			choiceSlforGrid1=parseInt(choiceSerial.value);
					    		}
					    		else if(amdFor=="46B"){
					    			choiceSlforGrid2=parseInt(choiceSerial.value);
					    		}
					    		else if(amdFor=="47B"){
					    			choiceSlforGrid3=parseInt(choiceSerial.value);
					    		}
					    		else if(amdFor=="49M"){
					    			choiceSlforGrid4=parseInt(choiceSerial.value);
					    		}
					    		else if(amdFor=="49N"){
					    			choiceSlforGrid5=parseInt(choiceSerial.value);
					    		}
					    	}
						}
					}
					
					
				}
				
				if (objXMLApplet5.getValue("Result") == "RowPresent"&& objXMLApplet5.getValue("OLCAC_CHOICE_SL").length>0) 
	   				 {	
					if(amdFor=="45B"){
				    	gid('MF:amdGoodsValue').value=value;
				    	goodsMod="1";
				    	choiceSlforGrid1=parseInt(choiceSlforGrid1)+1;
				    	gid('MF:txtChoiceSl').value=choiceSlforGrid1;
				    }
				    else if(amdFor=="46B"){
				    	gid('MF:amdDocsValue').value=value;
				    	 DocsMod="";
				    	 choiceSlforGrid2=parseInt(choiceSlforGrid2)+1;
				    	 gid('MF:txtChoiceSlDoc').value=choiceSlforGrid2;
				    }
				    else if(amdFor=="47B"){
				    	gid('MF:amdAddlValue').value=value;
				    	AddlMod="";
				        choiceSlforGrid3=parseInt(choiceSlforGrid3)+1;
				        gid('MF:txtChoiceSlAddl').value=choiceSlforGrid3;
				    }
				    else if(amdFor=="49M"){
				    	gid('MF:amdSpl1Value').value=value;
				    	Spcl1Mod="";
				    	choiceSlforGrid4=parseInt(choiceSlforGrid4)+1;
				    	gid('MF:txtChoiceSlSplBene').value=choiceSlforGrid4;
				    }
				     else if(amdFor=="49N"){
				     	gid('MF:amdSpl2Value').value=value;
				     	Spcl2Mod="";
				        choiceSlforGrid5=parseInt(choiceSlforGrid5)+1;
				        gid('MF:txtChoiceSlSplRecev').value=choiceSlforGrid5;
				    }
			    }
			    
			}
			
			
			
			function loadLogInModify(amdFor){
			    var value="";
			    var value2="";
			    var objXMLApplet5=new xmlHTTPValidator();
			    if(amdFor=="45B"){
			    	value=gid('MF:txtAmdLog').value;
			    	value2=value;
			    }
			    else if(amdFor=="46B"){
			    	value=gid('MF:txtAmdLogDoc').value;
			    	value2=value;
			    }
			    else if(amdFor=="47B"){
			    	value=gid('MF:txtAmdLogAddl').value;
			    	value2=value;
			    }
			    else if(amdFor=="49M"){
			    	value=gid('MF:txtAmdLogSplBene').value;
			    	value2=value;
			    }
			     else if(amdFor=="49N"){
			     	value=gid('MF:txtAmdLogSplRecev').value;
			     	value2=value;
			    }
			    
				objXMLApplet5.clearMap();
				objXMLApplet5.setValue("Package","panacea.OLCaction.eolcamdval"); 
				objXMLApplet5.setValue("Method","loadLogMod");
	            objXMLApplet5.setValue("ValidateToken","true");
	            objXMLApplet5.setValue("OLC_BRN_CODE",trim(gid('MF:txtBranchCode').value));
	            objXMLApplet5.setValue("OLC_TYPE",trim(gid('MF:txtReferenceType').value));
	            objXMLApplet5.setValue("OLC_YEAR",trim(gid('MF:txtReferenceYear').value));
	            objXMLApplet5.setValue("OLC_LC_SL",trim(gid('MF:txtReferenceSl').value));
	            objXMLApplet5.setValue("OLC_AMD_SL",trim(gid('MF:txtAmendmentSerial').value));
	            objXMLApplet5.setValue("AMDFOR",trim(amdFor));
	            objXMLApplet5.setValue("MODE",trim(gid('MF:seluseroption').value));
	            
	           	objXMLApplet5.sendAndReceive();
	           	if(objXMLApplet5.getValue("ErrorMsg") != "")
				{
					setMsg(objXMLApplet5.getValue("ErrorMsg"));
					gid('MF:txtApplInsOrRepl').focus();
					return;  
				}
				else
				{
					if (objXMLApplet5.getValue("Result") == "RowPresent"  && objXMLApplet5.getValue("OLCATL_TEXT").length>0)
	   				 {	
				
					var arr = [];
					arr=objXMLApplet5.getValue("OLCATL_TEXT").split("/");
					var logvalueLength = objXMLApplet5.getValue("OLCATL_TEXT").split("/").length;
					
					var arr2 = [];
					arr2=objXMLApplet5.getValue("OLCATL_CHOICE_SL").split("/");
					
				    for(var i=1; i<=logvalueLength; i++) {
					    	if(value==""){
					    		value=value+arr[i-1];
					    		value2=value2+arr[i-1]+"|"+arr2[i-1]; 
					    	}
					    	else{
					    		value=value+"\n"+arr[i-1];
					    	    value2=value2+"\n"+arr[i-1]+"|"+arr2[i-1]; 
					    	}
						}
					}
					
					
				}
				
		if (objXMLApplet5.getValue("Result") == "RowPresent" && objXMLApplet5.getValue("OLCATL_TEXT").length>0)
	   				 {	
					if(amdFor=="45B"){
				    	gid('MF:txtAmdLog').value=value;
				        gid('MF:amdlogtemp1').value=value2;
				        oldAmdLogValueGoods=gid('MF:txtAmdLog').value;
				    }
				    else if(amdFor=="46B"){
				    	gid('MF:txtAmdLogDoc').value=value;
				        gid('MF:amdlogtemp2').value=value2;
				        oldAmdLogValueDocs=gid('MF:txtAmdLogDoc').value;
				    }
				    else if(amdFor=="47B"){
				    	gid('MF:txtAmdLogAddl').value=value;
				    	gid('MF:amdlogtemp3').value=value2;
				    	oldAmdLogValueAddl=gid('MF:txtAmdLogAddl').value;
				    }
				    else if(amdFor=="49M"){
				    	gid('MF:txtAmdLogSplBene').value=value;
				    	gid('MF:amdlogtemp4').value=value2;
				    }
				     else if(amdFor=="49N"){
				     	gid('MF:txtAmdLogSplRecev').value=value;
				     	gid('MF:amdlogtemp5').value=value2;
				    }
			    }
			    
			}
			
			
			
			
			function LoadCompleteDetailInModify(amdFor){
				var objXMLApplet5=new xmlHTTPValidator();
				 var value="";
				 var gridName="";
			    if(amdFor=="45B"){
			    	value=gid('MF:txtcompAmdDetails').value;
			    	gridName=gridAlloc;
			    }
			    else if(amdFor=="46B"){
			    	value=gid('MF:txtcompAmdDetailsDoc').value;
			    	gridName=gridAllocDoc;
			    }
			    else if(amdFor=="47B"){
			    	value=gid('MF:txtcompAmdDetailsAddl').value;
			    	gridName=gridAllocAddl;
			    }
			    else if(amdFor=="49M"){
			    	value=gid('MF:txtcompAmdDetailsSplBene').value;
			    	gridName=gridAllocSplBene;
			    }
			     else if(amdFor=="49N"){
			     	value=gid('MF:txtcompAmdDetailsSplRecev').value;
			     	gridName=gridAllocSplRecev;
			    }
			    
				objXMLApplet5.clearMap();
				objXMLApplet5.setValue("Package","panacea.OLCaction.eolcamdval");
				objXMLApplet5.setValue("Method","LoadComplMod");
	            objXMLApplet5.setValue("ValidateToken","true");
	            objXMLApplet5.setValue("OLC_BRN_CODE",trim(gid('MF:txtBranchCode').value));
	            objXMLApplet5.setValue("OLC_TYPE",trim(gid('MF:txtReferenceType').value));
	            objXMLApplet5.setValue("OLC_YEAR",trim(gid('MF:txtReferenceYear').value));
	            objXMLApplet5.setValue("OLC_LC_SL",trim(gid('MF:txtReferenceSl').value));
	            objXMLApplet5.setValue("OLC_AMD_SL",trim(gid('MF:txtAmendmentSerial').value));
	            objXMLApplet5.setValue("AMDFOR",trim(amdFor));
	            objXMLApplet5.setValue("MODE",trim(gid('MF:seluseroption').value));
	            
	           	objXMLApplet5.sendAndReceive();
	           	if(objXMLApplet5.getValue("ErrorMsg") != "")
				{
					setMsg(objXMLApplet5.getValue("ErrorMsg"));
					gid('MF:txtApplInsOrRepl').focus();
					return;  
				}
				else
				{
				if (objXMLApplet5.getValue("Result") == "RowPresent"  && objXMLApplet5.getValue("OLCAT_TEXT").length>0) 
	   				 {	
					var arr = [];
					arr=objXMLApplet5.getValue("OLCAT_TEXT").split("/");
					var logvalueLength = objXMLApplet5.getValue("OLCAT_TEXT").split("/").length;
				    for(var i=1; i<=logvalueLength; i++) {
				    	if(value==""){
				    		value=value+arr[i-1];
				    	}
				    	else{
				    		value=value+"\n"+arr[i-1];
				    	}
					 }
					var splitResults = value.split("\n").length;
				    var arr = [];
				    for(var i=1; i<=splitResults; i++) {
				    	var rows =gridName.getRowsNum();
				    	gridName.addRow(rows+1,"");
	   					arr.push(value.split("\n")[i-1]);
	   					gridName.cells(i,0).setValue(i);
	   					gridName.cells(i,1).setValue(arr[i-1]);
					}
					}
				}
				
				
				
				
				
			if (objXMLApplet5.getValue("Result") == "RowPresent" && objXMLApplet5.getValue("OLCAT_TEXT").length>0) 
	   				 {		
					if(amdFor=="45B"){
				    	gid('MF:txtcompAmdDetails').value=value;
				    }
				    else if(amdFor=="46B"){
				    	gid('MF:txtcompAmdDetailsDoc').value=value;
				    }
				    else if(amdFor=="47B"){
				    	gid('MF:txtcompAmdDetailsAddl').value=value;
				    
				    }
				    else if(amdFor=="49M"){
				    	gid('MF:txtcompAmdDetailsSplBene').value=value;
				    }
				     else if(amdFor=="49N"){
				     	gid('MF:txtcompAmdDetailsSplRecev').value=value;
				    }
			    }
				
			}
			
		//ADDED BY PRASHANTH ON 23 FEB 2019 FOR FETCHING NEW FIELDS IN MODIFY MODE




	function FetchClobData()
	{
			objXMLApplet3.clearMap();
			objXMLApplet3.setValue("Package","panacea.OLCaction.eolcamdval");
			objXMLApplet3.setValue("Method","Split_clob_Data");
			objXMLApplet3.setValue("ValidateToken", "true");
			objXMLApplet3.setValue("OLC_YEAR",trim(gid('MF:txtReferenceYear').value));
			objXMLApplet3.setValue("OLC_SL",gid("MF:txtReferenceSl").value);
			objXMLApplet3.setValue("OLC_BRN_CODE",trim(gid('MF:txtBranchCode').value)); 
			objXMLApplet3.setValue("OLC_TYPE",trim(gid('MF:txtReferenceType').value));
			objXMLApplet3.setValue("AMEND_SL",trim(gid('MF:txtAmendmentSerial').value));
			objXMLApplet3.sendAndReceive();
			if (objXMLApplet3.getValue("ErrorMsg") != "")
			{	
				setMsg(objXMLApplet3.getValue("ErrorMsg"));
				gid('MF:txtAmendmentSerial').focus();
				return;
			}
			else
			{
			    gid('MF:txtDesGood1').value=objXMLApplet3.getValue("LC_DESC_GOODS_SER1");
				gid('MF:txtDesGood2').value=objXMLApplet3.getValue("LC_DESC_GOODS_SER2");
				gid('MF:txtDesGood3').value=objXMLApplet3.getValue("LC_DESC_GOODS_SER3");
				gid('MF:txtDocRequired1').value=objXMLApplet3.getValue("LC_DOC_REQ1");
				gid('MF:txtDocRequired2').value=objXMLApplet3.getValue("LC_DOC_REQ2");
				gid('MF:txtDocRequired3').value=objXMLApplet3.getValue("LC_DOC_REQ3");
				gid('MF:txtAddCond1').value=objXMLApplet3.getValue("LC_ADD_CONDITION1");
				gid('MF:txtAddCond2').value=objXMLApplet3.getValue("LC_ADD_CONDITION2");
				gid('MF:txtAddCond3').value=objXMLApplet3.getValue("LC_ADD_CONDITION3");
			}		
	}

	function selectItemEvents(fldobj)
	       {
	       switch(fldobj.name){
	       
	     case "MF:lstIssueBICdtl" :
								IssueBicList();
							break;
			//Changes Sanjay1 18-07-2019 Begin
			case "MF:lstConfInst"				:	validateConfInst();break;
			//Changes Sanjay1 18-07-2019 End
		}
	}
	//Changes Sanjay1 18-07-2019 Begin
	function validateDeferPaydtl()
	{
		if(!checkOldValueDrawee())
		{
		  return false;
		}
		if(gid('MF:chkCgDrawee').checked==true)
		{			
			if((gid('MF:chkDrawee').checked==false) && (trim(gid('MF:txtMixedPaydtl').value)=="") && (trim(gid('MF:txtDeferPaydtl').value)=="")) 
			{
				setMsg("Atleast One Of The Details In Drawee/Payment Details Should Be Given When Change in Drawee / Payment Flag Is Checked");
				gid('MF:txtDeferPaydtl').focus();
				return false;
			}
			else
			{
				gid('MF:lstparShip').focus();
				return true;
			}
		}
		else
		{
			gid('MF:lstparShip').focus();
			return true;
		}
	}
	//Changes Sanjay1 18-07-2019 End
	function validateTakCharge()
	{
		setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent2");
		focusTextArea('MF:txtPortLoad') ; 
	}
	function validatePortLoad()
	{
		setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent2");
		focusTextArea('MF:txtPortDis') ;
	}
	function validatePortDis()
	{
		setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent2");
		focusTextArea('MF:txtPortDest') ;
	}
	function validatePortDest()
	{
		setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent3");
		//Changes Sanjay1 18-07-2019 Begin
		//focusTextArea('MF:txtNarrative') ;
		focusTextArea('MF:txtSendInfo') ;
		
	}
	/*function validateNarrative()
	{
		
		if((trim(gid('MF:txtNarrative').value) == "") && (trim(gid('MF:txtReferenceType').value) == "OLC" ))
		{
			setMsg(BLANK_CHECK);
			gid("MF:txtNarrative").focus();
			return;
		}
		else
		{
		setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent3");
		focusTextArea('MF:txtSendInfo');
		}
	}*/
	
	function validateSendInfo()
	{
		/*if(trim(gid('MF:txtSendInfo').value) == "" && (trim(gid('MF:txtReferenceType').value) == "OLC" ))
		{
			setMsg(BLANK_CHECK);
			gid("MF:txtSendInfo").focus();
			return;
		}
		else*/
		{
			settingCommonFocus('');
		}
	  }
	//Changes Sanjay1 18-07-2019 End
	
	//prashanth
	function settingCommonFocus(flag){
	if(gid('MF:chkChgDesc').checked==true && parseInt(flag)!='7')
			{
			setTabfocus("maintab","tcontent10");
			setTabfocus("subtab","tsubcontent4");
			gid('MF:txtfrmRange').focus();
			return;
			}
			
			else if(gid('MF:chkChgDoc').checked==true &&  parseInt(flag)!='7')
			{
			setTabfocus("maintab","tcontent10");
			setTabfocus("subtab","tsubcontent5");
			gid('MF:txtfrmRangeDoc').focus();
						return;
			}
			
			
			else if(gid('MF:chkChgAddCond').checked==true &&  parseInt(flag)!='7')
			{
			setTabfocus("maintab","tcontent10");
			setTabfocus("subtab","tsubcontent6");
			gid('MF:txtfrmRangeAddl').focus();
						return;
			}
			
			else if(gid('MF:chkChgFormDc').checked==true &&  parseInt(flag)!='7')
			{
			setTabfocus("maintab","tcontent10");
			setTabfocus("subtab","tsubcontent7");
			gid('MF:lstcredit').focus();
						return;
			}
			
			else if(gid('MF:chkChgAppl').checked==true &&  parseInt(flag)!='7')
			{
			setTabfocus("maintab","tcontent10");
			setTabfocus("subtab","tsubcontent7");
			gid('MF:txtApplName').focus();
						return;
			}
			
			
			else if(gid('MF:chkChgApplRules').checked==true &&  parseInt(flag)!='7')
			{
			setTabfocus("maintab","tcontent10");
			setTabfocus("subtab","tsubcontent7");
			gid('MF:lstAppRule').focus();
						return;
			}
			
			else if(gid('MF:chkChgAvlWith').checked==true &&  parseInt(flag)!='8')
			{
			setTabfocus("maintab","tcontent10");
			setTabfocus("subtab","tsubcontent8");
			gid('MF:lstAvl').focus();
						return;
			}
			
			else if(gid('MF:chkCgDrawee').checked==true)
			{
			setTabfocus("maintab","tcontent10");
			setTabfocus("subtab","tsubcontent9");
			gid('MF:chkDrawee').focus();
						return;
			}
			else if(gid('MF:chkChgReimbus').checked==true)
			{
			setTabfocus("maintab","tcontent10");
			setTabfocus("subtab","tsubcontent10");
			gid('MF:lstConfInst').focus();
						return;
			}
			else if(gid('MF:chkCgAdvBk').checked==true)
			{
			setTabfocus("maintab","tcontent10");
			setTabfocus("subtab","tsubcontent11");
			gid('MF:chkAdvise').focus();
						return;
			}
			else{
			setTabfocus("maintab","tcontent10");
			setTabfocus("subtab","tsubcontent12");
			gid('MF:txtfrmRangeSplBene').focus();
						return;
			}
	return true;
	}
	
	
	
	function checkIssueBank()
	{
	if(gid('MF:chkIssueBank').checked==true)
		{
			gid('MF:outlblIssueBank').innerText="Yes";
			gid('MF:lstIssueBICdtl').disabled=false;
			gid('MF:txtIssueBicCode').readOnly=false;
			gid('MF:txtIssueBicBank').readOnly=false;
			gid('MF:txtIssueBicBrn').readOnly=false;
			gid('MF:txtIssueBankName').readOnly=false;
			gid('MF:txtIssueAcnt').readOnly=false;
			gid('MF:txtIssueAddress').readOnly=false;
			gid('MF:txtIssueCntry').readOnly=false;
		}
		else
		{
			gid('MF:outlblIssueBank').innerText="No";
			gid('MF:lstIssueBICdtl').value ="";
			gid('MF:lstIssueBICdtl').disabled=true;
			gid('MF:txtIssueBicCode').readOnly=true;
			gid('MF:txtIssueBicBank').readOnly=true;
			gid('MF:txtIssueBicBrn').readOnly=true;
			gid('MF:txtIssueBankName').readOnly=true;
			gid('MF:txtIssueAcnt').readOnly=true;
			gid('MF:txtIssueAddress').readOnly=true;
			gid('MF:txtIssueCntry').readOnly=true;
		}
		if(gid('MF:seluseroption').value=="A" && (gid('MF:chkIssueBank').checked==true) && gid('MF:lstIssueBICdtl').value == "" )
			{
		clearIssueBic();
		clearIssueAddr();
		}
	}
	
	function nextTab()
	{
		if(gid('MF:txtReferenceType').value=='OLC')
		{
			setTabfocus("maintab","tcontent10");
			setTabfocus("subtab","tsubcontent1");
			gid('MF:txtReceRef').focus();
		}
			else
		{
			gid('MF:Submit').focus();
		}
	}
	
	function checkExpiryDate()
	{
	if(gid('MF:chkExpiryDate').checked==true)
		{
			gid('MF:outlblExpiryDate').innerText="Yes";
			gid('MF:txtLastDateforNegotiation').disabled=false;
		}
		else
		{
			gid('MF:outlblExpiryDate').innerText="No";
			gid('MF:txtLastDateforNegotiation').disabled=true;
			gid('MF:txtLastDateforNegotiation').value ="";
		}
		/*if(gid('MF:seluseroption').value=="A")
		{
			if(gid('MF:txtLastDateforNegotiation').value == "")
			gid('MF:txtLastDateforNegotiation').value ="";
		}*/
	}
	
	function checkIncrDecr()
	{
	if(gid('MF:chkIncDec').checked==true)
		{
			gid('MF:outlblIncDec').innerText="Yes";
			gid('MF:txtEnhancementReductionAmount1').disabled=false;
		}
		else
		{
			gid('MF:outlblIncDec').innerText="No";
			gid('MF:txtEnhancementReductionAmount1').disabled=true;
			gid('MF:txtLCEnhancementReductionNochange').value="";
		    gid('MF:txtLCAmount').value="";
		    gid('MF:txtLCAmount1').value="";
		    //gid('MF:txtEnhancementReductionAmount').value="";
		    gid('MF:txtEnhancementReductionAmount1').value="";
		    gid('MF:txtAmendedLCAmount').value="";
		    gid('MF:txtAmendedLCAmount1').value="";
			
		}
			/*if(gid('MF:seluseroption').value=="A")
		{
			gid('MF:txtEnhancementReductionAmount').value ="";
		}*/
	}
	
	function checkPerTolr()
	{
		if(gid('MF:chkPerTolr').checked==true)
		{
			gid("MF:outlblPerTolr").innerText="Yes"
			gid('MF:txtDeviationAllowed').disabled=false;
			gid('MF:txtDeviationAllowed1').disabled=false;
			gid('MF:txtDeviationAmount').disabled=false;
		}
		else
		{
			gid("MF:outlblPerTolr").innerText="No"
			gid('MF:txtDeviationAllowed').disabled=true;
			gid('MF:txtDeviationAllowed1').disabled=true;
			gid('MF:txtDeviationAmount').disabled=true;
			
			gid('MF:txtDeviationAllowed').value="0.00";
			gid('MF:txtDeviationAllowed1').value="0.00";
			gid('MF:txtDeviationAmount').value="0.00";
			
			oldDevAmt1=gid('MF:txtDeviationAllowed').value;
			oldDevAmt2=gid('MF:txtDeviationAllowed1').value;
		}
			/*if(gid('MF:seluseroption').value=="A")
		{
			gid('MF:txtDeviationAllowed').value="";
			gid('MF:txtDeviationAllowed1').value="";
			gid('MF:txtDeviationAmount').value="";
		}*/
	}
	
	function checkPlacePort()
	{
		if(gid('MF:chkPlacePort').checked==true)
		{
			gid('MF:outlblPlacePort').innerText="Yes";
			gid('MF:txtTakCharge').disabled=false;
			gid('MF:txtPortLoad').disabled=false;
			gid('MF:txtPortDis').disabled=false;
			gid('MF:txtPortDest').disabled=false; 
			if(gid("MF:txtReferenceType").value=="OLC" && gid('MF:seluseroption').value=="A")
			{
					 gid('MF:txtTakCharge').value=placeTake;
					 gid('MF:txtPortLoad').value=placeload;
					 gid('MF:txtPortDis').value=placeDis;
					 gid('MF:txtPortDest').valueplaceFinal;
			}
		}
		else
		{
			gid('MF:outlblPlacePort').innerText="No";
			gid('MF:txtTakCharge').disabled=true;
			gid('MF:txtPortLoad').disabled=true;
			gid('MF:txtPortDis').disabled=true;
			gid('MF:txtPortDest').disabled=true;
			
			gid('MF:txtTakCharge').value="";
			gid('MF:txtPortLoad').value="";
			gid('MF:txtPortDis').value="";
			gid('MF:txtPortDest').value="";
		}
			/*if(gid('MF:seluseroption').value=="A")
		{
			gid('MF:txtTakCharge').value="";
			gid('MF:txtPortLoad').value="";
			gid('MF:txtPortDis').value="";
			gid('MF:txtPortDest').value="";
		}*/
	}
	
	function checkShipPeriod()
	{
		if(gid('MF:chkShipPeriod').checked==true)
		{
			gid('MF:outlblShipPeriod').innerText="Yes";
			gid('MF:txtLatestDateofShipment').disabled=false; 
			gid('MF:txtShipmentPeriodSchedule').disabled=false;
			if(gid("MF:txtReferenceType").value=="OLC" && gid('MF:seluseroption').value=="A")
			{
					 gid('MF:txtShipmentPeriodSchedule').value=shipSch;
					 shipPer=trim(gid('MF:txtShipmentPeriodSchedule').value);
		 	}
		}
		else
		{
			gid('MF:outlblShipPeriod').innerText="No";
			gid('MF:txtLatestDateofShipment').disabled=true; 
			gid('MF:txtShipmentPeriodSchedule').disabled=true;
			gid('MF:txtLatestDateofShipment').value="";
			gid('MF:txtShipmentPeriodSchedule').value="";
		}
		
		/*if(gid('MF:seluseroption').value=="A")
		{
			gid('MF:txtLatestDateofShipment').value="";
			gid('MF:txtShipmentPeriodSchedule').value="";
		}*/
	}
	
	
	// ADDED BY PRASHANTH ON 06 FEB 2019
	function checkChangeDesc()
	{
		 clearGoodsTab();
		gid('MF:amdGoodsValue').value="";
	   
	         gid('MF:amdlogtemp1').value="";
      	     gid('MF:amdlogtemp2').value="";
      	     gid('MF:amdlogtemp3').value="";
		
    	     
	  if(gid('MF:seluseroption').value=="A") 
		{
		   if(gid("MF:txtAmendmentSerial").value=="1")
		   {
			
			objXMLApplet.clearMap();
			objXMLApplet.setValue("Package","panacea.OLCaction.eolcamdval");
			objXMLApplet.setValue("Method","getOLCGoodsDescn");
            objXMLApplet.setValue("ValidateToken","true");
            objXMLApplet.setValue("OLC_BRN_CODE",trim(gid('MF:txtBranchCode').value));
            objXMLApplet.setValue("OLC_TYPE",trim(gid('MF:txtReferenceType').value));
            objXMLApplet.setValue("OLC_YEAR",trim(gid('MF:txtReferenceYear').value));
            objXMLApplet.setValue("OLC_SL",trim(gid('MF:txtReferenceSl').value));
           	objXMLApplet.sendAndReceive();
           	if(objXMLApplet.getValue("ErrorMsg") != "")
			{
				setMsg(objXMLApplet.getValue("ErrorMsg"));
				gid('MF:chkChgDesc').focus();
				return;  
			}
			else
			{
			    var value=trim(objXMLApplet.getValue("LC_DESC_GOODS_SER1"));
			    var value2=trim(objXMLApplet.getValue("LC_DESC_GOODS_SER2"));
			    var value3=trim(objXMLApplet.getValue("LC_DESC_GOODS_SER3"));
			    
			    var splitResultsGoods = value.split("\n").length+value2.split("\n").length+value3.split("\n").length;
			    
			  /*  if(value=="" &&  value2=="" &&  value3=="")
			    {
			    		if (gid('MF:chkChgDesc').checked==true){
			    		   setMsg("Cannot Be Checked When there is no data entered in OLC Entry");
		          		   gid("MF:chkChgDesc").focus();
						   return;
			    		}
			    }
			    
			    */
			    
			    if(trim(value2)!="")
			    {
			      value=value+"\n"+trim(value2);
			    }
			    if(trim(value3)!="")
			    {
			      value=value+"\n"+trim(value3);
			    }
			    
			    
			    var arr = [];
			    for(var i=1; i<=splitResultsGoods; i++) {
			    	var rows =gridAlloc.getRowsNum();
			    	gridAlloc.addRow(rows+1,"");
   					arr.push(value.split("\n")[i-1]);
   					gridAlloc.cells(i,0).setValue(i);
   					gridAlloc.cells(i,1).setValue(arr[i-1]);
				}
				
				 gid('MF:txtcompAmdDetails').value=value+"\n"+value2+"\n"+value3;
		      }
			}
			/*else{
			
				loadLogInModify("45B");
			    LoadCompleteDetailInModify("45B");
			    loadAmdChoiceMod("45B");
			}*/
		}
		//if (gid('MF:chkChgDesc').checked==true){
				loadLogInModify("45B");
			    LoadCompleteDetailInModify("45B");
			    loadAmdChoiceMod("45B");
			  //  }
		if (gid('MF:chkChgDesc').checked==false){
			gid('MF:outlblChgDesc').innerText="No";
			// clearGoodsTab();
		}
		else{
			gid('MF:outlblChgDesc').innerText="Yes";
		}
		//else if (gid('MF:chkChgDesc').checked==false && gid('MF:seluseroption').value=="A"){
			//clearGoodsTab();
		//}
		
	  
	  
	   gid('MF:amdSpl1Value').value="";
       gid('MF:amdSpl2Value').value="";
	   
		  /*  loadLogInModify("49M");
		    LoadCompleteDetailInModify("49M");
		    loadAmdChoiceMod("49M");
		    
		    
		    loadLogInModify("49N");
		    LoadCompleteDetailInModify("49N");
		    loadAmdChoiceMod("49N");
			    */
			    
			    
		gid('MF:chkChgDoc').focus();
		return true;
	}
           function doOnRowSelectedGrid1(id){
		 	     grid1SelectedValue=gridAlloc.cells(id,1).getValue();
		 		return true;
          }
          
           function doOnRowSelectedGrid2(id){
		 		 grid2SelectedValue=gridAllocDoc.cells(id,1).getValue();
		 		return true;
          }
          
           function doOnRowSelectedGrid3(id){
		 		 grid3SelectedValue=gridAllocAddl.cells(id,1).getValue();
		 		return true;
          }
          
           function doOnRowSelectedGrid4(id){
		 		 grid4SelectedValue=gridAllocSplBene.cells(id,1).getValue();
		 		return true;
          }
          
          function doOnRowSelectedGrid5(id){
		 		 grid5SelectedValue=gridAllocSplRecev.cells(id,1).getValue();
		 		return true;
          }
          
          
          function validateFromRange(){
	          if(trim(gid('MF:txtfrmRange').value)!="")
	          {
		          if(trim(gid('MF:txtfrmRange').value) ==0)
		          {
		          	setMsg(ZERO_CHECK);
		          	gid("MF:txtfrmRange").focus();
					return;
		          }
		       }
         	 gid('MF:uptoRange').focus();
			 return true;
          }
          
          function validateUpToRange(){
          
          if(trim(gid('MF:uptoRange').value)!="")
          {
           if(trim(gid('MF:uptoRange').value) ==0)
	          {
	          	setMsg(ZERO_CHECK);
	          	gid("MF:uptoRange").focus();
				return;
	          }
          
          
          if(trim(gid('MF:txtfrmRange').value) =="" && trim(gid('MF:uptoRange').value) =="")
	          {
	          	setMsg("Enter From Range Value");
	          	gid("MF:uptoRange").focus();
				return;
	          }
	          
	          
	          if(trim(gid('MF:txtfrmRange').value) !="")
	          {
	          
	           if(trim(gid('MF:uptoRange').value)<trim(gid('MF:txtfrmRange').value))
	            {
	            setMsg("Upto Range Value Should Be Greater Than From Range Value");
	          	gid("MF:uptoRange").focus();
				return;
	            }
	          }
	        }
	          gid("MF:lstamdChoice").focus();
				return;
          }
          
           function validateFromRangeDoc(){
	          if(trim(gid('MF:txtfrmRangeDoc').value)!="")
	          {
		          if(trim(gid('MF:txtfrmRangeDoc').value) ==0)
		          {
		          	setMsg(ZERO_CHECK);
		          	gid("MF:txtfrmRangeDoc").focus();
					return;
		          }
		       }
         	 gid('MF:uptoRangeDoc').focus();
			 return true;
          }
          
          function validateUpToRangeDoc(){
          
          if(trim(gid('MF:uptoRangeDoc').value)!="")
          {
           if(trim(gid('MF:uptoRangeDoc').value) ==0)
	          {
	          	setMsg(ZERO_CHECK);
	          	gid("MF:uptoRangeDoc").focus();
				return;
	          }
          
          
          if(trim(gid('MF:txtfrmRangeDoc').value) =="" && trim(gid('MF:uptoRangeDoc').value) =="")
	          {
	          	setMsg("Enter From Range Value");
	          	gid("MF:uptoRangeDoc").focus();
				return;
	          }
	          
	          
	          if(trim(gid('MF:txtfrmRangeDoc').value) !="")
	          {
	          
	           if(trim(gid('MF:uptoRangeDoc').value)<trim(gid('MF:txtfrmRangeDoc').value))
	            {
	            setMsg("Upto Range Value Should Be Greater Than From Range Value");
	          	gid("MF:uptoRangeDoc").focus();
				return;
	            }
	          }
	        }
	          gid("MF:lstamdChoiceDoc").focus();
				return;
          }
          
          
          
          
          function validateFromRangeAddl(){
	          if(trim(gid('MF:txtfrmRangeAddl').value)!="")
	          {
		          if(trim(gid('MF:txtfrmRangeAddl').value) ==0)
		          {
		          	setMsg(ZERO_CHECK);
		          	gid("MF:txtfrmRangeAddl").focus();
					return;
		          }
		       }
         	 gid('MF:uptoRangeAddl').focus();
			 return true;
          }
          
          function validateUpToRangeAddl(){
          
          if(trim(gid('MF:uptoRangeAddl').value)!="")
          {
           if(trim(gid('MF:uptoRangeAddl').value) ==0)
	          {
	          	setMsg(ZERO_CHECK);
	          	gid("MF:uptoRangeAddl").focus();
				return;
	          }
          
          
          if(trim(gid('MF:txtfrmRangeAddl').value) =="" && trim(gid('MF:uptoRangeAddl').value) =="")
	          {
	          	setMsg("Enter From Range Value");
	          	gid("MF:uptoRangeAddl").focus();
				return;
	          }
	          
	          
	          if(trim(gid('MF:txtfrmRangeAddl').value) !="")
	          {
	          
	           if(trim(gid('MF:uptoRangeAddl').value)<trim(gid('MF:txtfrmRangeAddl').value))
	            {
	            setMsg("Upto Range Value Should Be Greater Than From Range Value");
	          	gid("MF:uptoRangeAddl").focus();
				return;
	            }
	          }
	        }
	          gid("MF:lstamdChoiceAddl").focus();
				return;
          }
          
          
          
          
          function validateFromRangeSplBene(){
	          if(trim(gid('MF:txtfrmRangeSplBene').value)!="")
	          {
		          if(trim(gid('MF:txtfrmRangeSplBene').value) ==0)
		          {
		          	setMsg(ZERO_CHECK);
		          	gid("MF:txtfrmRangeSplBene").focus();
					return;
		          }
		       }
         	 gid('MF:uptoRangeSplBene').focus();
			 return true;
          }
          
          function validateUpToRangeSplBene(){
          
          if(trim(gid('MF:uptoRangeSplBene').value)!="")
          {
           if(trim(gid('MF:uptoRangeSplBene').value) ==0)
	          {
	          	setMsg(ZERO_CHECK);
	          	gid("MF:uptoRangeSplBene").focus();
				return;
	          }
          
          
          if(trim(gid('MF:txtfrmRangeSplBene').value) =="" && trim(gid('MF:uptoRangeSplBene').value) =="")
	          {
	          	setMsg("Enter From Range Value");
	          	gid("MF:uptoRangeSplBene").focus();
				return;
	          }
	          
	          
	          if(trim(gid('MF:txtfrmRangeSplBene').value) !="")
	          {
	          
	           if(trim(gid('MF:uptoRangeSplBene').value)<trim(gid('MF:txtfrmRangeSplBene').value))
	            {
	            setMsg("Upto Range Value Should Be Greater Than From Range Value");
	          	gid("MF:uptoRangeSplBene").focus();
				return;
	            }
	          }
	        }
	          gid("MF:lstamdChoiceSplBene").focus();
				return;
          }
          
          
          
          
            function validateFromRangeSplRecv(){
	          if(trim(gid('MF:txtfrmRangeSplRecev').value)!="")
	          {
		          if(trim(gid('MF:txtfrmRangeSplRecev').value) ==0)
		          {
		          	setMsg(ZERO_CHECK);
		          	gid("MF:txtfrmRangeSplRecev").focus();
					return;
		          }
		       }
         	 gid('MF:uptoRangeSplRecev').focus();
			 return true;
          }
          
          function validateUpToRangeSplRecv(){
          
          if(trim(gid('MF:uptoRangeSplRecev').value)!="")
          {
           if(trim(gid('MF:uptoRangeSplRecev').value) ==0)
	          {
	          	setMsg(ZERO_CHECK);
	          	gid("MF:uptoRangeSplRecev").focus();
				return;
	          }
          
          
          if(trim(gid('MF:txtfrmRangeSplRecev').value) =="" && trim(gid('MF:uptoRangeSplRecev').value) =="")
	          {
	          	setMsg("Enter From Range Value");
	          	gid("MF:uptoRangeSplRecev").focus();
				return;
	          }
	          
	          
	          if(trim(gid('MF:txtfrmRangeSplRecev').value) !="")
	          {
	          
	           if(trim(gid('MF:uptoRangeSplRecev').value)<trim(gid('MF:txtfrmRangeSplRecev').value))
	            {
	            setMsg("Upto Range Value Should Be Greater Than From Range Value");
	          	gid("MF:uptoRangeSplRecev").focus();
				return;
	            }
	          }
	        }
	          gid("MF:lstamdChoiceSplRecev").focus();
				return;
          }
          
          function validateDraft()
          {
          	if(!checkOldValueAvailable())
			{
			  return false;
			}
			if(gid('MF:chkCgDrawee').checked==true)
			{
			setTabfocus("maintab","tcontent10");
			setTabfocus("subtab","tsubcontent9");
			gid('MF:chkDrawee').focus();
						return;
			}
			else if(gid('MF:chkChgReimbus').checked==true)
			{
			setTabfocus("maintab","tcontent10");
			setTabfocus("subtab","tsubcontent10");
			gid('MF:lstConfInst').focus();
						return;
			}
			else if(gid('MF:chkCgAdvBk').checked==true)
			{
			setTabfocus("maintab","tcontent10");
			setTabfocus("subtab","tsubcontent11");
			gid('MF:chkAdvise').focus();
						return;
			}
			else{
			setTabfocus("maintab","tcontent10");
			setTabfocus("subtab","tsubcontent12");
			gid('MF:txtfrmRangeSplBene').focus();
						return;
			}
          }
          
          
          function validateConfInst()
{
		checkcfmReimb();
		if(gid("MF:lstConfInst").value=="")
		{
			setMsg(BLANK_CHECK);
			gid("MF:lstConfInst").focus();
			return;
		}
		else
		{
			setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent10");
			//ADDED BY PRASHANTH ON 29 JANUARY 2018
			//Changes Sanjay1 18-07-2019 Begin
			if((gid("MF:lstConfInst").value=="1")||(gid("MF:lstConfInst").value=="2"))
		{
			gid('MF:lstReimbcfmBank').focus();
		}
		else
		{
			//gid('MF:txtConfirmedByBank').value="";
			//gid('MF:txtConfirmedBYBranch').value="";
			//gid('MF:txtConfirmedBYBranchname').value="";
			//gid('MF:outlblConfirmedByBank').innerText="";
			gid('MF:chkReimb').focus();  
		}

			//Changes Sanjay1 18-07-2019 End
			//ADDED BY PRASHANTH ON 29 JANUARY 2018
		}
}
        
          
    //Changes Sanjay1 18-07-2019 Begin
/*          function validateConfirmedByBank()
	{
	gid('MF:outlblConfirmedByBank').innerText ="";
			if(trim(gid('MF:txtConfirmedByBank').value) == "")
	    	{
	    		if(gid('MF:lstConfInst').value == "1")
	 	 		{
		 	 		setMsg(BLANK_CHECK);
	 	 			gid('MF:txtConfirmedByBank').focus();
	 	 		}
	    	}
	    	else
	    	{
	    	   objXMLApplet.clearMap();
		       objXMLApplet.setValue("Package", "panacea.OLCaction.eolcval");
			   objXMLApplet.setValue("ValidateToken", "true");  
			   objXMLApplet.setValue("Method", "olcAdvBankCodekeypress");
		       objXMLApplet.setValue("OLC_ADV_BANK_CODE",trim(gid('MF:txtConfirmedByBank').value));
		       objXMLApplet.sendAndReceive();
		        if (objXMLApplet.getValue("ErrorMsg") != "")
			 	{
					setMsg(objXMLApplet.getValue("ErrorMsg"));
					gid('MF:txtConfirmedByBank').focus();
					return;
				}
				else
				{
					gid('MF:outlblConfirmedByBank').innerText = objXMLApplet.getValue("BANKCD_NAME");
					gid('MF:txtConfirmedBYBranch').focus();
				}
	    	}
	}
	
	
	
	function validateConfirmedByBranch()
	{
	    	if(trim(gid('MF:txtConfirmedBYBranch').value) == "")
	    	{
	    		if(gid('MF:lstConfInst').value == "1")
	 	 		{
		 	 		setMsg(BLANK_CHECK);
	 	 			gid('MF:txtConfirmedBYBranch').focus();
	 	 		}
	    	}
	    	
	    	else
	    	{
	    	   objXMLApplet.clearMap();
		       objXMLApplet.setValue("Package", "panacea.OLCaction.eolcval");
			   objXMLApplet.setValue("ValidateToken", "true");  
			   objXMLApplet.setValue("Method", "olcAdvBranchCodekeypress");
		       objXMLApplet.setValue("OLC_ADV_BRNCH_CODE",trim(gid('MF:txtConfirmedBYBranch').value));
   		       objXMLApplet.setValue("OLC_ADV_BANK_CODE",trim(gid('MF:txtConfirmedByBank').value));
		       objXMLApplet.sendAndReceive();
		        if (objXMLApplet.getValue("ErrorMsg") != "")
			 	{
					setMsg(objXMLApplet.getValue("ErrorMsg"));
					gid('MF:txtConfirmedBYBranch').focus();
					return;
				}
				else
				{
					gid('MF:txtConfirmedBYBranchname').value = objXMLApplet.getValue("MBKBRN_NAME");
					gid('MF:chkReimb').focus();
				}
	    	}
	}
	function validateConfirmedByBranchName()
	{
			if(trim(gid('MF:txtConfirmedBYBranchname').value) == "")
	    	{
	    	if(gid('MF:lstConfInst').value == "1")
	 	 		{
	    		setMsg(BLANK_CHECK);
	    		gid('MF:txtConfirmedBYBranchname').focus();
	    		}
	    	}
	    	else
	    	{
 		    	// rerturnFlag2 = "C";
		    	// gid('div2').style.visibility = "visible";
    		    // gid('MF:txtaddress2').readOnly = false;
				// focusTextArea('MF:txtaddress2');
	    		gid('MF:chkReimb').focus();
	    	}
	}
          
     */     
       //Changes Sanjay1 18-07-2019 End   
          
	function checkChangeDoc()
	{
				 clearDocumentsTab();
				 gid('MF:amdDocsValue').value="";
				 gid('MF:amdlogtemp2').value="";
				 setMsg("");
    	    
    	     
    	     
	  if(gid('MF:seluseroption').value=="A") 
		{
		   if(gid("MF:txtAmendmentSerial").value=="1")
		   {
			
			objXMLApplet.clearMap();
			objXMLApplet.setValue("Package","panacea.OLCaction.eolcamdval");
			objXMLApplet.setValue("Method","getOLCDocsDescn");
            objXMLApplet.setValue("ValidateToken","true");
            objXMLApplet.setValue("OLC_BRN_CODE",trim(gid('MF:txtBranchCode').value));
            objXMLApplet.setValue("OLC_TYPE",trim(gid('MF:txtReferenceType').value));
            objXMLApplet.setValue("OLC_YEAR",trim(gid('MF:txtReferenceYear').value));
            objXMLApplet.setValue("OLC_SL",trim(gid('MF:txtReferenceSl').value));
           	objXMLApplet.sendAndReceive();
           	if(objXMLApplet.getValue("ErrorMsg") != "")
			{
				setMsg(objXMLApplet.getValue("ErrorMsg"));
				gid('MF:chkChgDoc').focus();
				return;  
			}
			else
			{
			    var value=trim(objXMLApplet.getValue("LC_DOC_REQ1"));
			    var value2=trim(objXMLApplet.getValue("LC_DOC_REQ2"));
			    var value3=trim(objXMLApplet.getValue("LC_DOC_REQ3"));
			    
			    
			    var splitResultsGoods = value.split("\n").length+value2.split("\n").length+value3.split("\n").length;
			    
			   /* if(value=="" &&  value2=="" &&  value3=="")
			    {
			    		if (gid('MF:chkChgDoc').checked==true){
			    		   setMsg("Cannot Be Checked When there is no data entered in OLC Entry");
		          		   gid("MF:chkChgDoc").focus();
						   return;
			    		}
			    }
			    */
			    
			    
			    if(trim(value2)!="")
			    {
			      value=value+"\n"+trim(value2);
			    }
			    if(trim(value3)!="")
			    {
			      value=value+"\n"+trim(value3);
			    }
			    
			    var arr = [];
			    for(var i=1; i<=splitResultsGoods; i++) {
			    	var rows =gridAllocDoc.getRowsNum();
			    	gridAllocDoc.addRow(rows+1,"");
   					arr.push(value.split("\n")[i-1]);
   					gridAllocDoc.cells(i,0).setValue(i);
   					gridAllocDoc.cells(i,1).setValue(arr[i-1]);
				}
				
				 gid('MF:txtcompAmdDetailsDoc').value=value+"\n"+value2+"\n"+value3;
		      }
			}
		}
		
		//if (gid('MF:chkChgDoc').checked==true){
					loadLogInModify("46B");
			    	LoadCompleteDetailInModify("46B");
			    	loadAmdChoiceMod("46B");
			//    }
	    if (gid('MF:chkChgDoc').checked==false){
			gid('MF:outlblchkChgDoc').innerText="No";
			//clearDocumentsTab();
		}
		else{
			gid('MF:outlblchkChgDoc').innerText="Yes";
		}
	//	else if (gid('MF:chkChgDoc').checked==false && gid('MF:seluseroption').value=="A"){
	//		clearDocumentsTab();
	//	}
		gid('MF:chkChgAddCond').focus();
		return true;
	}
	function checkChangeAddCond()
	{
	 clearAdditionalDetailsTab();
	 gid('MF:amdAddlValue').value="";
     gid('MF:amdlogtemp3').value="";
      	     
      	     
	 if(gid('MF:seluseroption').value=="A")
		{
		
		if(gid("MF:txtAmendmentSerial").value=="1")
		   {
			gid('MF:outlblChgAddCond').innerText="Yes";
			objXMLApplet.clearMap();
			objXMLApplet.setValue("Package","panacea.OLCaction.eolcamdval");
			objXMLApplet.setValue("Method","getOLCAddlDescn");
            objXMLApplet.setValue("ValidateToken","true");
            objXMLApplet.setValue("OLC_BRN_CODE",trim(gid('MF:txtBranchCode').value));
            objXMLApplet.setValue("OLC_TYPE",trim(gid('MF:txtReferenceType').value));
            objXMLApplet.setValue("OLC_YEAR",trim(gid('MF:txtReferenceYear').value));
            objXMLApplet.setValue("OLC_SL",trim(gid('MF:txtReferenceSl').value));
           	objXMLApplet.sendAndReceive();
           	if(objXMLApplet.getValue("ErrorMsg") != "")
			{
				setMsg(objXMLApplet.getValue("ErrorMsg"));
				gid('MF:chkChgAddCond').focus();
				return;  
			}
			else
			{
			    
			    var value=objXMLApplet.getValue("LC_ADD_CONDITION1");
			    var value2=trim(objXMLApplet.getValue("LC_ADD_CONDITION2"));
			    var value3=trim(objXMLApplet.getValue("LC_ADD_CONDITION3"));
			    
				var splitResultsGoods = value.split("\n").length+value2.split("\n").length+value3.split("\n").length;
			    
			  /*  if(value=="" &&  value2=="" &&  value3=="")
			    {
			    		if (gid('MF:chkChgAddCond').checked==true){
			    		   setMsg("Cannot Be Checked When there is no data entered in OLC Entry");
		          		   gid("MF:chkChgAddCond").focus();
						   return;
			    		}
			    }
			    */
			    
			    if(trim(value2)!="")
			    {
			      value=value+"\n"+trim(value2);
			    }
			    if(trim(value3)!="")
			    {
			      value=value+"\n"+trim(value3);
			    }
			    
			    
			    
			    
			    
			    var arr = [];
			    for(var i=1; i<=splitResultsGoods; i++) {
			    	var rows =gridAllocAddl.getRowsNum();
			    	gridAllocAddl.addRow(rows+1,"");
   					arr.push(value.split("\n")[i-1]);
   					gridAllocAddl.cells(i,0).setValue(i);
   					gridAllocAddl.cells(i,1).setValue(arr[i-1]);
				}
				
				 gid('MF:txtcompAmdDetailsAddl').value=value+"\n"+value2+"\n"+value3;
		      }
			}
		}
				loadLogInModify("47B");
			    LoadCompleteDetailInModify("47B");
			    loadAmdChoiceMod("47B");
			    
		 if (gid('MF:chkChgAddCond').checked==false){
			gid('MF:outlblChgAddCond').innerText="No";
			//clearAdditionalDetailsTab();
		}
		else{
		   gid('MF:outlblChgAddCond').innerText="Yes";
		}
		if(gid('MF:chkChangeofBeneficiary').checked==true)
	  	{
	  		gid("MF:outlblChangeofBeneficiary").innerText="Yes";
     		gid("MF:txtBeneficiaryCode").disabled=false; 
			gid("MF:txtBeneficiaryName").disabled=false; 
			gid("MF:txtAddress1").disabled=false; 
			gid("MF:txtBeneficiaryCountryCode").disabled=false; 
			setTabfocus("maintab","tcontent2");
			gid('MF:chkReqForCancel').focus();
		}
		else{
	  		gid("MF:outlblChangeofBeneficiary").innerText="No";
		    gid("MF:txtBeneficiaryCode").disabled=true; 
			gid("MF:txtBeneficiaryName").disabled=true; 
			gid("MF:txtAddress1").disabled=true; 
			gid("MF:txtBeneficiaryCountryCode").disabled=true; 
			if(newbenef == "0")
			{
			gid("MF:txtBeneficiaryCode").value="";
			gid("MF:txtBeneficiaryName").value="";
			gid("MF:txtAddress1").value="";
			gid("MF:txtBeneficiaryCountryCode").value="";
			gid("MF:outputlblBeneficiaryCountryCode").innerText="";
			}
	  		//setTabfocus("maintab","tcontent3");
			// gid('MF:txtLCEnhancementReductionNochange').focus();
			setTabfocus("maintab","tcontent2");
		    gid('MF:chkReqForCancel').focus();
	  	  }
	}
	
	
	//ADDED BY PRASHANTH ON 20 FEB 2019
	function checkChangeReqForCancel(){
	if(gid('MF:chkReqForCancel').checked==true)
	  	{
	  	   gid("MF:outlblchkReqForCancel").innerText="Yes";
	  	}
	  	else{
	  	
	  	
	  		 gid("MF:outlblchkReqForCancel").innerText="No";
	  	}
			setTabfocus("maintab","tcontent2");
		    gid('MF:chkChgAppl').focus();
	}
	
	
	
	function checkChangeAppl(){
	
			gid('MF:txtApplCode').value="";
		  	gid('MF:txtApplName').value="";
		  	gid('MF:txtApplAddress').value="";
	  		 gid("MF:outlblchkChgAppl").innerText="No";
	  		 
	if(gid('MF:chkChgAppl').checked==true)
	  	{
	  	   gid("MF:outlblchkChgAppl").innerText="Yes";
	  	   
	  	   	objXMLApplet.clearMap();
			objXMLApplet.setValue("Package","panacea.OLCaction.eolcamdval");
			objXMLApplet.setValue("Method","LoadClientDetails");
	        objXMLApplet.setValue("ValidateToken", "true");
	        objXMLApplet.setValue("CLIENT_NUM",trim(gid('MF:txtCustomerNumber').value));
	       	objXMLApplet.sendAndReceive();
			if(objXMLApplet.getValue("ErrorMsg") != "")
			{
				setMsg(objXMLApplet.getValue("ErrorMsg"));
				gid('MF:chkChgAppl').focus();
				return;  
			}
	  	   else{
	  	        gid('MF:txtApplCode').value=gid('MF:txtCustomerNumber').value;
	  	        
	  	        oldApplCode=gid('MF:txtApplCode').value;
	  	  	    gid("MF:txtApplName").innerText=objXMLApplet.getValue("CLIENTS_NAME");
				var a=objXMLApplet.getValue("CLIENTS_ADDR1");
				var b=objXMLApplet.getValue("CLIENTS_ADDR2");
				var c=objXMLApplet.getValue("CLIENTS_ADDR3");
				var d=objXMLApplet.getValue("CLIENTS_ADDR4");
				var e=objXMLApplet.getValue("CLIENTS_ADDR5");
				gid("MF:txtApplAddress").value=a+"\r\n"+"" +b+"\r\n"+"" +c+"\r\n"+"" +d+"\r\n"+"" +e;
	  	   }
	  	   
	  	}
	  	else{
	  		gid('MF:txtApplCode').value="";
		  	gid('MF:txtApplName').value="";
		  	gid('MF:txtApplAddress').value="";
	  		 gid("MF:outlblchkChgAppl").innerText="No";
	  	}
			setTabfocus("maintab","tcontent2");
		    gid('MF:chkChgFormDc').focus();
	}
	
	function checkChangeFormDoc(){
	if(gid('MF:chkChgFormDc').checked==true)
	  	{
	  	   gid("MF:outlblchkChgFormDc").innerText="Yes";
	  	   gid('MF:lstcredit').disabled=false;
	  	}
	  	else{
	  		gid('MF:lstcredit').disabled=true;
	  		gid('MF:lstcredit').value=lstcredit_backup;
	  		gid("MF:outlblchkChgFormDc").innerText="No";
	  	}
			setTabfocus("maintab","tcontent2");
		    gid('MF:chkChgApplRules').focus();
	}
	
	
	function checkChangeApplRules(){
	if(gid('MF:chkChgApplRules').checked==true)
	  	{
	  	   gid("MF:outlblchkChgApplRules").innerText="Yes";
	  	   gid('MF:lstAppRule').disabled=false;
	  	   gid('MF:changeinapplicablerules').value="1";
	  	}
	  	else{
	  		gid('MF:lstAppRule').disabled=true;
	  		gid('MF:lstAppRule').value=lstAppRule_backup;
	  		gid("MF:outlblchkChgApplRules").innerText="No";
	  		gid('MF:changeinapplicablerules').value="0";
	  	}
			setTabfocus("maintab","tcontent2");
		    gid('MF:chkChgAvlWith').focus();
	}
	
	function checkChangeAvlWith()
	{
	
		if(gid('MF:chkChgAvlWith').checked==true)
	  	{
	  	   gid("MF:outlblchkChgAvlWith").innerText="Yes";
	  	   gid('MF:lstAvl').disabled=false;
	  		gid('MF:lstAvlBICdtl').disabled=false;
	  		gid('MF:txtAvlBicCode').disabled=false;
	  		gid('MF:txtAvlBicBank').disabled=false;
	  		gid('MF:txtAvlBicBrn').disabled=false;
	  		gid('MF:txtAvlAcnt').disabled=false;
	  		gid('MF:txtAvlBankName').disabled=false;
	  		gid("MF:txtAvlAddress").disabled=false;
	  		gid("MF:txtAvlCntry").disabled=false;
	  	    gid("MF:txtDraft").disabled=false;
	  	    gid('MF:changeinavailablewith').value="1";
	  	}
	  	else{
	  		gid("MF:outlblchkChgAvlWith").innerText="No";
	  		gid('MF:lstAvl').disabled=true;
	  		gid('MF:lstAvlBICdtl').disabled=true;
	  		gid('MF:txtAvlBicCode').disabled=true;
	  		gid('MF:txtAvlBicBank').disabled=true;
	  		gid('MF:txtAvlBicBrn').disabled=true;
	  		gid('MF:txtAvlAcnt').disabled=true;
	  		gid('MF:txtAvlBankName').disabled=true;
	  		gid("MF:txtAvlAddress").disabled=true;
	  		gid("MF:txtAvlCntry").disabled=true;
	  	    gid("MF:txtDraft").disabled=true;
	  	    gid('MF:lstAvl').value=lstAvl_backup;
	  	    gid('MF:lstAvlBICdtl').value=lstAvlBICdtl_backup;
	  	    gid('MF:txtAvlBicCode').value=txtAvlBicCode_backup;
	  	    gid('MF:txtAvlBicBank').value="";
	  	    gid('MF:txtAvlBicBrn').value=txtAvlBicBrn_backup;
	  	    gid('MF:txtAvlAcnt').value=txtAvlAcnt_backup;
	  	    gid('MF:txtAvlBankName').value=txtAvlBankName_backup;
	  	    gid('MF:txtAvlAddress').value=txtAvlAddress_backup;
	  	    gid('MF:txtAvlCntry').value=txtAvlCntry_backup;
	  	    gid('MF:txtDraft').value=txtDraft_backup;
	  	    gid('MF:changeinavailablewith').value="0";
	  	    
	  	}
	  		setTabfocus("maintab","tcontent2");
		    gid('MF:chkCgDrawee').focus();
	}
	
	
	function checkChangeDrawee()
	{
	
		if(gid('MF:chkCgDrawee').checked==true)
	  	{
	  	   gid("MF:outlblchkCgDrawee").innerText="Yes";
	  	   gid('MF:chkDrawee').disabled=false;    		
	  		gid("MF:lstDrwBICdtl").disabled=false;
	  		gid("MF:txtDrwBicCode").disabled=false;
	  		gid("MF:txtDrwBicBank").disabled=false;
	  		gid("MF:txtDrwBicBrn").disabled=false;
	  		gid("MF:txtDrwAcnt").disabled=false;
	  		gid("MF:txtDrwBankName").disabled=false;
	  		gid("MF:txtDrwAddress").disabled=false;
	  		gid("MF:txtDrwCntry").disabled=false;
	  		
	  		gid("MF:txtMixedPaydtl").disabled=false;
	  		gid("MF:txtDeferPaydtl").disabled=false;
	  		gid("MF:lstparShip").disabled=false;
	  		gid("MF:lsttranShip").disabled=false;
	  		gid('MF:changeindrawee').value="1";
	  	}
	  	else{
	  	 gid("MF:outlblchkCgDrawee").innerText="No";
	  		gid('MF:chkDrawee').disabled=true;    		
	  		gid("MF:lstDrwBICdtl").disabled=true;
	  		gid("MF:txtDrwBicCode").disabled=true;
	  		gid("MF:txtDrwBicBank").disabled=true;
	  		gid("MF:txtDrwBicBrn").disabled=true;
	  		gid("MF:txtDrwAcnt").disabled=true;
	  		gid("MF:txtDrwBankName").disabled=true;
	  		gid("MF:txtDrwAddress").disabled=true;
	  		gid("MF:txtDrwCntry").disabled=true;
	  		
	  		gid("MF:txtMixedPaydtl").disabled=true;
	  		gid("MF:txtDeferPaydtl").disabled=true;
	  		gid("MF:lstparShip").disabled=true;
	  		gid("MF:lsttranShip").disabled=true;
	  		if(chkDrawee_backup == "0")
			{
				gid('MF:chkDrawee').checked=false;
	   			gid('MF:outlblDrawee').innerText="No";	
	   		}
	   		else
	   		{
	   			gid('MF:chkDrawee').checked=true;
	   			gid('MF:outlblDrawee').innerText="Yes";	
	   		}
	  		gid('MF:lstDrwBICdtl').value=lstDrwBICdtl_backup;
	  		gid('MF:txtDrwBicCode').value=txtDrwBicCode_backup;
	  		gid('MF:txtDrwBicBank').value="";
	  		gid('MF:txtDrwBicBrn').value=txtDrwBicBrn_backup;
	  		gid('MF:txtDrwAcnt').value=txtDrwAcnt_backup;
	  		gid('MF:txtDrwBankName').value=txtDrwBankName_backup;
	  		gid('MF:txtDrwAddress').value=txtDrwAddress_backup;
	  		gid('MF:txtDrwCntry').value=txtDrwCntry_backup;
	  		gid('MF:txtMixedPaydtl').value=txtMixedPaydtl_backup;
	  		gid('MF:txtDeferPaydtl').value=txtDeferPaydtl_backup;
	  		gid('MF:lstparShip').value=lstparShip_backup;
	  		gid('MF:lsttranShip').value=lsttranShip_backup;
	  		gid('MF:changeindrawee').value="0";
	  	}
	  		setTabfocus("maintab","tcontent2");
		    gid('MF:chkChgReimbus').focus();
	}
	
	
	function checkChangeReimbus()
	{
	if(gid('MF:chkChgReimbus').checked==true)
	  	{
	  	   gid("MF:outlblchkChgReimbus").innerText="Yes";
	  	   gid("MF:lstConfInst").disabled=false;
			gid('MF:lstReimbcfmBank').disabled=false;
			gid('MF:txtReimcfmBicCode').disabled=false;
			gid('MF:txtReimcfmBicBank').disabled=false;
			gid('MF:txtReimcfmBicBrn').disabled=false;
			gid('MF:txtcfmReimAcnt').disabled=false;
			gid('MF:txtcfmReimBankName').disabled=false;
			gid('MF:txtcfmReimAddress').disabled=false;
			gid('MF:txtcfmReimCntry').disabled=false;
			//Changes Sanjay1 18-07-2019 End
			gid('MF:chkReimb').disabled=false;
	    	gid('MF:lstReimbBank').disabled=false;
			gid('MF:txtReimBicCode').disabled=false;
			gid('MF:txtReimBicBank').disabled=false;
			gid('MF:txtReimBicBrn').disabled=false;
			gid('MF:txtReimBankName').disabled=false;
			gid('MF:txtReimAcnt').disabled=false;
			gid('MF:txtReimAddress').disabled=false;
			gid('MF:txtReimCntry').disabled=false;
		    gid('MF:txtInstPay').disabled=false;
		    gid('MF:changeinreimbursement').value="1";
	  	}
	  	else{
    		gid('MF:outlblchkChgReimbus').innerText="No";	
	  		gid("MF:lstConfInst").disabled=true;
	  		//Changes Sanjay1 18-07-2019 Begin
			gid('MF:lstReimbcfmBank').disabled=true;
			gid('MF:txtReimcfmBicCode').disabled=true;
			gid('MF:txtReimcfmBicBank').disabled=true;
			gid('MF:txtReimcfmBicBrn').disabled=true;
			gid('MF:txtcfmReimAcnt').disabled=true;
			gid('MF:txtcfmReimBankName').disabled=true;
			gid('MF:txtcfmReimAddress').disabled=true;
			gid('MF:txtcfmReimCntry').disabled=true;
			//Changes Sanjay1 18-07-2019 End
			gid('MF:chkReimb').disabled=true;
	    	gid('MF:lstReimbBank').disabled=true;
			gid('MF:txtReimBicCode').disabled=true;
			gid('MF:txtReimBicBank').disabled=true;
			gid('MF:txtReimBicBrn').disabled=true;
			gid('MF:txtReimBankName').disabled=true;
			gid('MF:txtReimAcnt').disabled=true;
			gid('MF:txtReimAddress').disabled=true;
			gid('MF:txtReimCntry').disabled=true;
		    gid('MF:txtInstPay').disabled=true;
		    gid('MF:lstConfInst').value=lstConfInst_backup;
	  		gid('MF:lstReimbcfmBank').value=lstReimbcfmBank_backup;
	  		gid('MF:txtReimcfmBicCode').value=txtReimcfmBicCode_backup;
	  		gid('MF:txtReimcfmBicBank').value="";
	  		gid('MF:txtReimcfmBicBrn').value=txtReimcfmBicBrn_backup;
	  		gid('MF:txtcfmReimAcnt').value=txtcfmReimAcnt_backup;
	  		gid('MF:txtcfmReimBankName').value=txtcfmReimBankName_backup;
	  		gid('MF:txtcfmReimAddress').value=txtcfmReimAddress_backup;
	  		gid('MF:txtcfmReimCntry').value=txtcfmReimCntry_backup;
	  		if(chkReimb_backup == "0")
			{
				gid('MF:chkReimb').checked=false;
	   			gid('MF:outlblReimb').innerText="No";	
	   		}
	   		else
	   		{
	   			gid('MF:chkReimb').checked=true;
	   			gid('MF:outlblReimb').innerText="Yes";	
	   		}
	  		gid('MF:lstReimbBank').value=lstReimbBank_backup;
	  		gid('MF:txtReimBicCode').value=txtReimBicCode_backup;
	  		gid('MF:txtReimBicBank').value="";
	  		gid('MF:txtReimBicBrn').value=txtReimBicBrn_backup;
	  		gid('MF:txtReimBankName').value=txtReimBankName_backup;
	  		gid('MF:txtReimAcnt').value=txtReimAcnt_backup;
	  		gid('MF:txtReimAddress').value=txtReimAddress_backup;
	  		gid('MF:txtReimCntry').value=txtReimCntry_backup;
	  		gid('MF:txtInstPay').value=txtInstPay_backup;
	  		gid('MF:changeinreimbursement').value="0";
	  		
	  	}
	  		setTabfocus("maintab","tcontent2");
		    gid('MF:chkCgAdvBk').focus();
	
	}
	
	
	
	function checkChangeAdvBk()
	{
	if(gid('MF:chkCgAdvBk').checked==true)
	  	{
	  	   gid("MF:outlblchkCgAdvBk").innerText="Yes";
	  	   gid('MF:chkAdvise').disabled=false;
 	        gid('MF:lstAdviseBank').disabled=false;
 	        gid('MF:txtAdviseBicCode').disabled=false;
 	        gid('MF:txtAdviseBicBank').disabled=false;
 	        gid('MF:txtAdviseBicBrn').disabled=false;
 	        gid('MF:txtAdviseAcnt').disabled=false;
 	        gid('MF:txtAdviseBankName').disabled=false;
 	        gid('MF:txtAdviseAddress').disabled=false;
 	        gid('MF:txtAdviseCntry').disabled=false;
 	        gid('MF:changeinadvisingbank').value="1";
	  	}
	  	else{
    		gid('MF:outlblchkCgAdvBk').innerText="No";	
    		gid('MF:chkAdvise').disabled=true;
 	        gid('MF:lstAdviseBank').disabled=true;
 	        gid('MF:txtAdviseBicCode').disabled=true;
 	        gid('MF:txtAdviseBicBank').disabled=true;
 	        gid('MF:txtAdviseBicBrn').disabled=true;
 	        gid('MF:txtAdviseAcnt').disabled=true;
 	        gid('MF:txtAdviseBankName').disabled=true;
 	        gid('MF:txtAdviseAddress').disabled=true;
 	        gid('MF:txtAdviseCntry').disabled=true;
 	        if(chkAdvise_backup == "0")
			{
				gid('MF:chkAdvise').checked=false;
	   			gid('MF:outlblAdvise').innerText="No";	
	   		}
	   		else
	   		{
	   			gid('MF:chkAdvise').checked=true;
	   			gid('MF:outlblAdvise').innerText="Yes";	
	   		}
	  		gid('MF:lstAdviseBank').value=lstAdviseBank_backup;
	  		gid('MF:txtAdviseBicCode').value=txtAdviseBicCode_backup;
	  		gid('MF:txtAdviseBicBank').value="";
	  		gid('MF:txtAdviseBicBrn').value=txtAdviseBicBrn_backup;
	  		gid('MF:txtAdviseAcnt').value=txtAdviseAcnt_backup;
	  		gid('MF:txtAdviseBankName').value=txtAdviseBankName_backup;
	  		gid('MF:txtAdviseAddress').value=txtAdviseAddress_backup;
	  		gid('MF:txtAdviseCntry').value=txtAdviseCntry_backup;
	  		gid('MF:changeinadvisingbank').value="0";
	  	}
	  	
	  	
	  	if(gid("MF:chkChangeofBeneficiary").checked==true)
   		{
   		  	setTabfocus("maintab","tcontent2");
		    gid('MF:txtBeneficiaryCode').focus();
   		}
   		else{
   			setTabfocus("maintab","tcontent3");
		    gid('MF:lstAmdPayableBy').focus();
   		}
	  		
	}
	
	
	
	function validateAmdPayBy()
	{
	  gid('MF:txtperiodOfPres').focus();
	}
	
	function validatePeriod()
	{
		var value=gid('MF:txtperiodOfPres').value;
		
		
		var valueLength = value.length;
		if(valueLength>65){
			setMsg("Cannot Enter more than 35 Characters");
			gid("MF:txtperiodOfPres").focus();
			return;
	     }
	  	gid('MF:txtLCEnhancementReductionNochange').focus();
	}
	
	function validateFormOfDocCredit(){
	
		 if(!checkOldValueFormOfDC()){
		    return false;
		 }
	 
	 
		if(gid('MF:chkChgFormDc').checked==true)
		{
		 if(gid('MF:lstcredit').value=="")
		 {
		  		setMsg("Cannot Be Blank when Change in Form of DC is Checked");
				gid("MF:lstcredit").focus();
				return;
		 }
		}
		else{
		if(gid('MF:lstcredit').value!="")
		 {
		  		setMsg("Should Be Blank when Change in Form of DC is Not Checked");
				gid("MF:lstcredit").focus();
				return;
		 }
		}
		/*if(gid('MF:chkChgAppl').checked==true)
		{
				gid("MF:txtApplName").focus();
				return;
		}
		else  if(gid('MF:chkChgApplRules').checked==true)
		{
				gid("MF:lstAppRule").focus();
				return;
		}
		else{
		settingCommonFocus('7'); 
		}
		*/
		gid("MF:txtCharge").focus();
		return;
	}
	
	//added by navya 27/06/19 begin
	
	function validateCharges()
    { 
    if(gid('MF:chkChgAppl').checked==true)
		{
				gid("MF:txtApplName").focus();
				return;
		}
		else  if(gid('MF:chkChgApplRules').checked==true)
		{
				gid("MF:lstAppRule").focus();
				return;
		}
		else{
		settingCommonFocus('7'); 
		}
     }
// end


	function validateApplName(){
	if(gid('MF:chkChgAppl').checked==true)
		{
		 if(gid('MF:txtApplName').value=="")
		 {
		  		setMsg("Cannot Be Blank when Change in Applicant Name is Checked");
				gid("MF:lstcredit").focus();
				return;
		 }
		}
		else{
		if(gid('MF:txtApplName').value!="")
		 {
		  		setMsg("Should Be Blank when Change in Applicant Name is Not Checked");
				gid("MF:lstcredit").focus();
				return;
		 }
		}
	
	if(gid('MF:chkChgApplRules').checked==true)
			{
				setTabfocus("maintab","tcontent10");
				setTabfocus("subtab","tsubcontent7");
				gid('MF:lstAppRule').focus();
			    return true;
			}
			else{
			settingCommonFocus('7');
			return;
			}
	    return true;
	}
	
	
	function validateApplAddress(){
	
	if(!checkOldValuApplicant())
	{
	  return false;
	}
	if(gid('MF:chkChgAppl').checked==true)
		{
		 if(gid('MF:txtApplAddress').value=="")
		 {
		  		setMsg("Cannot Be Blank when Change in Applicant Name is Checked");
				gid("MF:txtApplAddress").focus();
				return;
		 }
		}
		else{
		if(gid('MF:txtApplAddress').value!="")
		 {
		  		setMsg("Should Be Blank when Change in Applicant Name is Not Checked");
				gid("MF:txtApplAddress").focus();
				return;
		 }
		}
	
	
	if(gid('MF:chkChgApplRules').checked==true)
		{
				gid("MF:lstAppRule").focus();
				return;
		}
		else{
		settingCommonFocus('7'); 
		}
	    return;
	}
	
	
	
	function validateApplRules(){
	  if(!checkOldValueApplRules()){
	    return false;
	  }
	if(gid('MF:chkChgApplRules').checked==true)
		{
		 if(gid('MF:lstAppRule').value=="")
		 {
		  		setMsg("Cannot Be Blank when Change in Applicant Rules is Checked");
				gid("MF:lstAppRule").focus();
				return;
		 }
		}
		else{
		if(gid('MF:lstAppRule').value!="")
		 {
		  		setMsg("Should Be Blank when Change in Applicant Rules is Not Checked");
				gid("MF:lstAppRule").focus();
				return;
		 }
		}
	
	
		settingCommonFocus('7'); 
	    return;
	}
	
	function validateAvlWith(){
	
	if(gid('MF:chkChgAvlWith').checked==true)
		{
		 if(gid('MF:lstAvl').value=="")
		 {
		  		setMsg("Cannot Be Blank when Change in Available with is Checked");
				gid("MF:lstAvl").focus();
				return;
		 }
		 else{
		 		gid("MF:lstAvlBICdtl").focus();
				return;
		 }
		}
		else{
		if(gid('MF:lstAvl').value!="")
		 {
		  		setMsg("Should Be Blank when Change in Available with is Not Checked");
				gid("MF:lstAvl").focus();
				return;
		 }
		}
	
	
		settingCommonFocus('7'); 
	    return;
	}
	
	function validateAvlWithBicNameOrAddress(banklst,txtlst){
	if(txtlst == "2")
		{
			avlBicList();
			setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent8");
			if(banklst == "")
			{
				setMsg(BLANK_CHECK);
				gid('MF:lstAvlBICdtl').focus();
				return;
			}
			else if(banklst == "1")
			{
				gid('MF:txtAvlBicCode').focus();
			}
			else if(banklst == "2")
			{
				gid('MF:txtAvlAcnt').focus();
			}
		}
	}
	
	
	
	
	function draweeBicList()
	{
		if(trim(gid('MF:lstDrwBICdtl').value) == "")
	  	{   
	  		clearDraweeBic();
			clearDraweeAddr();
	  		document.getElementById('DRWBICBANK').style.display = 'none';
			document.getElementById('DRWBIC').style.display = 'block';
		}
	 	else if(trim(gid('MF:lstDrwBICdtl').value) == "1")
	 	{
	 		clearDraweeAddr();
	 		document.getElementById('DRWBICBANK').style.display = 'none';
	 		document.getElementById('DRWBIC').style.display = 'block';
	 	}
	 	else if(trim(gid('MF:lstDrwBICdtl').value) == "2")
	 	{
	 		clearDraweeBic();
	 		document.getElementById('DRWBICBANK').style.display = 'block';
	 		document.getElementById('DRWBIC').style.display = 'none';
	 	}
	}
	
	function reimbBiclist()
	{
		if(trim(gid('MF:lstReimbBank').value) == "")
	  	{   
	  		clearReimbBic();
			clearReimbAddr();
	  		document.getElementById('REIMNAMEADDR').style.display = 'none';
			document.getElementById('REIMBIC').style.display = 'block';
		}
	 	else if(trim(gid('MF:lstReimbBank').value) == "1")
	 	{
	 		clearReimbAddr();
	 		document.getElementById('REIMNAMEADDR').style.display = 'none';
	 		document.getElementById('REIMBIC').style.display = 'block';
	 	}
	 	else if(trim(gid('MF:lstReimbBank').value) == "2")
	 	{
	 		clearReimbBic();
	 		document.getElementById('REIMNAMEADDR').style.display = 'block';
	 		document.getElementById('REIMBIC').style.display = 'none';
	 	}
	}
	

	//Changes Sanjay1 18-07-2019 Begin
	function reimbcfmBiclist()
	{
		if(trim(gid('MF:lstReimbcfmBank').value) == "")
	  	{   
	  		clearReimbCfmBic();
		    clearReimbCfmAddr();
	  		document.getElementById('REIMCFMNAMEADDR').style.display = 'none';
			document.getElementById('REIMCFMBIC').style.display = 'block';
		}
	 	else if(trim(gid('MF:lstReimbcfmBank').value) == "1")
	 	{
	 		clearReimbCfmAddr();
	 		document.getElementById('REIMCFMNAMEADDR').style.display = 'none';
	 		document.getElementById('REIMCFMBIC').style.display = 'block';
	 	}
	 	else if(trim(gid('MF:lstReimbcfmBank').value) == "2")
	 	{
	 		clearReimbCfmBic();
	 		document.getElementById('REIMCFMNAMEADDR').style.display = 'block';
	 		document.getElementById('REIMCFMBIC').style.display = 'none';
	 	}
	}
	//Changes Sanjay1 18-07-2019 End
	
	function avlBicList()
	{
		if(trim(gid('MF:lstAvlBICdtl').value) == "")
	  	{      
	    	clearAVLBic();
			clearAVLAddr();
	    	document.getElementById('AVLNAMEADDR').style.display = 'none';
			document.getElementById('AVLBIC').style.display = 'block';
	 	}
	 	else if(trim(gid('MF:lstAvlBICdtl').value) == "1")
	 	{
	 		clearAVLAddr();
	 		document.getElementById('AVLNAMEADDR').style.display = 'none';
	 		document.getElementById('AVLBIC').style.display = 'block';
	 	}
	 	else if(trim(gid('MF:lstAvlBICdtl').value) == "2")
	 	{
		 	clearAVLBic();
		 	document.getElementById('AVLNAMEADDR').style.display = 'block';
		 	document.getElementById('AVLBIC').style.display = 'none';
	 	}
	}
	
	
	function checkReimb()
{
	//setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent6");
	if(gid('MF:chkReimb').checked==true)
		{
			gid('MF:outlblReimb').innerText="Yes";
			//gid('MF:lstReimbBank').value ="";
			gid('MF:lstReimbBank').disabled=false;
			gid('MF:txtReimBicCode').disabled=false;
			gid('MF:txtReimBicBank').readOnly=false;
			gid('MF:txtReimBicBrn').readOnly=false;
			gid('MF:txtReimBankName').readOnly=false;
			gid('MF:txtReimAcnt').readOnly=false;
			gid('MF:txtReimAddress').readOnly=false;
			gid('MF:txtReimCntry').readOnly=false;
		}
		else
		{
			gid('MF:outlblReimb').innerText="No";
			gid('MF:lstReimbBank').value ="";
			gid('MF:lstReimbBank').disabled=true;
			gid('MF:txtReimBicCode').disabled=true;
			gid('MF:txtReimBicBank').readOnly=true;
			gid('MF:txtReimBicBrn').readOnly=true;
			gid('MF:txtReimBankName').readOnly=true;
			gid('MF:txtReimAcnt').readOnly=true;
			gid('MF:txtReimAddress').readOnly=true;
			gid('MF:txtReimCntry').readOnly=true;
			clearReimbBic();
			clearReimbAddr();
		}
		
		if(gid('MF:seluseroption').value=="A" && (gid('MF:chkReimb').checked==true) && gid('MF:lstReimbBank').value == "")//CHANGED ADDED ON 11/10/2018
		{
		clearReimbBic();
		clearReimbAddr();
		}
}

		//Changes Sanjay1 18-07-2019 Begin
        function  checkcfmReimb()
        {
        	if((gid("MF:lstConfInst").value=="1")||(gid("MF:lstConfInst").value=="2"))
			{
				gid('MF:lstReimbcfmBank').disabled=false;
				gid('MF:txtReimcfmBicCode').disabled=false;
				gid('MF:txtReimcfmBicBank').readOnly=false;
				gid('MF:txtReimcfmBicBrn').readOnly=false;
				gid('MF:txtcfmReimAcnt').readOnly=false;
				gid('MF:txtcfmReimBankName').readOnly=false;
				gid('MF:txtcfmReimAddress').readOnly=false;
				gid('MF:txtcfmReimCntry').readOnly=false;
			}
			else
			{
				gid('MF:lstReimbcfmBank').value ="";
				gid('MF:lstReimbcfmBank').disabled=true;
				gid('MF:txtReimcfmBicCode').disabled=true;
				gid('MF:txtReimcfmBicBank').readOnly=true;
				gid('MF:txtReimcfmBicBrn').readOnly=true;
				gid('MF:txtcfmReimAcnt').readOnly=true;
				gid('MF:txtcfmReimBankName').readOnly=true;
				gid('MF:txtcfmReimAddress').readOnly=true;
				gid('MF:txtcfmReimCntry').readOnly=true;
				clearReimbCfmBic();
			    clearReimbCfmAddr();
			}
			
			if(gid('MF:seluseroption').value=="A" && ((gid("MF:lstConfInst").value=="1")||(gid("MF:lstConfInst").value=="2")) && gid('MF:lstReimbcfmBank').value == "")//CHANGED ADDED ON 11/10/2018
			{
				clearReimbCfmBic();
			    clearReimbCfmAddr();
			}
        }
        //Changes Sanjay1 18-07-2019 End
	
	function checkAdvise()
{
	if(gid('MF:chkAdvise').checked==true)
		{
			gid('MF:outlblAdvise').innerText="Yes";
			//gid('MF:lstAdviseBank').value ="";
			gid('MF:lstAdviseBank').disabled=false;
			gid('MF:txtAdviseBicCode').disabled=false;
			gid('MF:txtAdviseBicBank').readOnly=false;
			gid('MF:txtAdviseBicBrn').readOnly=false;
			gid('MF:txtAdviseBankName').readOnly=false;
			gid('MF:txtAdviseAddress').readOnly=false;
			gid('MF:txtAdviseCntry').readOnly=false;
			gid('MF:txtAdviseAcnt').readOnly=false;
			
		}
		else
		{
			gid('MF:outlblAdvise').innerText="No";
			gid('MF:lstAdviseBank').value ="";
			gid('MF:lstAdviseBank').disabled=true;
			gid('MF:txtAdviseBicCode').disabled=true;
			gid('MF:txtAdviseBicBank').readOnly=true;
			gid('MF:txtAdviseBicBrn').readOnly=true;
			gid('MF:txtAdviseBankName').readOnly=true;
			gid('MF:txtAdviseAddress').readOnly=true;
			gid('MF:txtAdviseCntry').readOnly=true;
			gid('MF:txtAdviseAcnt').readOnly=true;
			clearAdvThrBic();
			clearAdvThrAddr();
		}
		if(gid('MF:seluseroption').value=="A" && (gid('MF:chkAdvise').checked==true) && gid('MF:lstAdviseBank').value == "")//ADDED ON 11/10/2018
		{
		clearAdvThrBic();
		clearAdvThrAddr();
		}
}
	
	
	function AvlThrBiclist()
	{
		if(trim(gid('MF:lstAdviseBank').value) == "")
	  	{   
	  		clearAdvThrBic();
			clearAdvThrAddr();
	  		document.getElementById('ADVISENAMEADDR').style.display = 'none';
			document.getElementById('ADVISEBIC').style.display = 'block';
		}
	 	else if(trim(gid('MF:lstAdviseBank').value) == "1")
	 	{
	 		clearAdvThrAddr();
	 		document.getElementById('ADVISENAMEADDR').style.display = 'none';
	 		document.getElementById('ADVISEBIC').style.display = 'block';
	 	}
	 	else if(trim(gid('MF:lstAdviseBank').value) == "2")
	 	{
	 		clearAdvThrBic();
	 		document.getElementById('ADVISENAMEADDR').style.display = 'block';
	 		document.getElementById('ADVISEBIC').style.display = 'none';
	 	}
	}
	
	
	function PushData1()
	{
	  var deletedData="";
	  var delvalue="";
	/*1-insert,2-insertbefore,3-insertafter,4-delete,5-Replace*/
	   if(gid('MF:chkChgDesc').checked==false)
	   {
	   if(gid('MF:txtApplInsOrRepl').value!="")
		  {
		  	setMsg("Cannot Enter When Change in Description of Goods and / or Services is not checked");
			gid("MF:txtApplInsOrRepl").focus();
			return;
		  }
	   }
		var selectedChoice="";
		var value=gid('MF:txtApplInsOrRepl').value;
		
		
		var valueLength = value.length;
		if(valueLength>65){
			setMsg("Cannot Enter more than 65 Characters");
			gid("MF:txtApplInsOrRepl").focus();
			return;
	     }
		
		
	  if(gid('MF:lstamdChoice').value=="1")
	  {/*1-insert*/
	      selectedChoice="Insert:";
		  if(gid('MF:txtApplInsOrRepl').value=="")
		  {
		  	setMsg("Insertion/Replace Value Cannot Be Blank");
			gid("MF:txtApplInsOrRepl").focus();
			return;
		  }
		  if(gid('MF:txtcompAmdDetails').value=="")
		  {
		  	gid('MF:txtcompAmdDetails').value=gid('MF:txtApplInsOrRepl').value;
		  }
		  else{
		   gid('MF:txtcompAmdDetails').value=gid('MF:txtcompAmdDetails').value+"\n"+gid('MF:txtApplInsOrRepl').value;
		  }
	  }
	  else if(gid('MF:lstamdChoice').value=="4")
	  {
	  /*4-Delete*/ 
	   if(gid('MF:txtfrmRange').value=="" && gid('MF:uptoRange').value=="")
		  {
		  	setMsg("From Range & UpTo Range Cannot Be Blank");
			gid("MF:txtfrmRange").focus();
			return;
		  }
	  value=grid1SelectedValue;
	  	 selectedChoice="Delete:";
		  var grid1SelectedIndexArray=[];
		  var CompleteAmdArray=[];
		  var tempArray=[];
	 	  CompleteAmdArray=gid('MF:txtcompAmdDetails').value.split("\n");
       var result="";
		for(var i=1; i<=CompleteAmdArray.length; i++) {
			    	if(!inRange(i,gid('MF:txtfrmRange').value,gid('MF:uptoRange').value))
			    	{
			            {
			            result=result+CompleteAmdArray[i-1]+"\n";
	   					//tempArray.push(CompleteAmdArray[i-1]); 
	   					}
					}
					else{
					/*ADDED BY PRASHANTH ON 28 MARCH 2019*/	 
				    delvalue=CompleteAmdArray[i-1].replace(/[\r\n]/g, '')+"|"+gid('MF:lstamdChoice').value+"\n";
					if(gid('MF:amdlogtemp1').value==""){
				      gid('MF:amdlogtemp1').value=delvalue;
				      gid('MF:amdlogtemp1').value=trim(gid('MF:amdlogtemp1').value);
			          }
			 	else{ 
			 	 gid('MF:amdlogtemp1').value=gid('MF:amdlogtemp1').value+"\n"+delvalue;
			  		}
	   				/*ADDED BY PRASHANTH ON 28 MARCH 2019*/	
					deletedData=deletedData+CompleteAmdArray[i-1];
					value=deletedData;
					}
				}
	      
		  gid('MF:txtcompAmdDetails').value=result;
	  }
	  
	    else if(gid('MF:lstamdChoice').value=="5")
	  {/*5-Replace*/
	 	  // value=grid1SelectedValue;
	  	 selectedChoice="Replace:";
		  var grid1SelectedIndexArray=[];
		  var CompleteAmdArray=[];
		  var tempArray=[];
	 	  CompleteAmdArray=gid('MF:txtcompAmdDetails').value.split("\n");
       var result="";
       
       if(gid('MF:txtApplInsOrRepl').value=="")
		  {
		  	setMsg("Insertion/Replace Value Cannot Be Blank");
			gid("MF:txtApplInsOrRepl").focus();
			return;
		  }
		  
		for(var i=1; i<=CompleteAmdArray.length; i++) {
		    	if(inRange(i,gid('MF:txtfrmRange').value,gid('MF:uptoRange').value))
		    	{
		    	   if(i==gid('MF:uptoRange').value){
		            {
		            result=result+gid('MF:txtApplInsOrRepl').value+"\n";
   					//tempArray.push(CompleteAmdArray[i-1]); 
   					}
   					}
				}
				else{
		            result=result+CompleteAmdArray[i-1]+"\n";
				}
				}
	      
		  gid('MF:txtcompAmdDetails').value=result;
	  }
	  
	   if(gid('MF:lstamdChoice').value=="2")
	  {/*2-insert before*/
	  
	   selectedChoice="Insert:";
		  var grid1SelectedIndexArray=[];
		  var CompleteAmdArray=[];
		  var tempArray=[];
	 	  CompleteAmdArray=gid('MF:txtcompAmdDetails').value.split("\n");
       var result="";
       
       
	    if(gid('MF:txtApplInsOrRepl').value=="")
		  {
		  	setMsg("Insertion/Replace Value Cannot Be Blank");
			gid("MF:txtApplInsOrRepl").focus();
			return;
		  }
		  
		  if(trim(gid('MF:txtfrmRange').value) =="")
	          {
	          	setMsg("From Range Cannot Be Blank");
	          	gid("MF:txtApplInsOrRepl").focus();
				return;
	          }

		   if(trim(gid('MF:uptoRange').value) =="")
	          {
	          	setMsg("UpTo Range Cannot Be Blank");
	          	gid("MF:txtApplInsOrRepl").focus();
				return;
	          }
	          
	       if(trim(gid('MF:txtfrmRange').value) !=trim(gid('MF:uptoRange').value))
            {
	            setMsg("Both From Range and Upto Range Should Be Same for Inset Before/Insert After Selection");
	          	gid("MF:txtApplInsOrRepl").focus();
				return;
            }
            
            var inside=0;
            for(var i=1; i<=CompleteAmdArray.length;i++) {
		    	if(i==parseInt(gid('MF:uptoRange').value) && inside==0){
		            {
		            	result=result+gid('MF:txtApplInsOrRepl').value+"\n";
   						//tempArray.push(CompleteAmdArray[i-1]);
   						result=result+CompleteAmdArray[i-1]+"\n";
   						i=i--;
   						inside="1";
   					}
   					}
				else{
		            result=result+CompleteAmdArray[i-1]+"\n";
				}
			}
	      
		  gid('MF:txtcompAmdDetails').value=result;
	  }
	  
	   if(gid('MF:lstamdChoice').value=="3")
	  {/*3-insert after*/
	  
	    selectedChoice="Insert:";
		  var grid1SelectedIndexArray=[];
		  var CompleteAmdArray=[];
		  var tempArray=[];
	 	  CompleteAmdArray=gid('MF:txtcompAmdDetails').value.split("\n");
       var result="";
       
	  if(gid('MF:txtApplInsOrRepl').value=="")
		  {
		  	setMsg("Insertion/Replace Value Cannot Be Blank");
			gid("MF:txtApplInsOrRepl").focus();
			return;
		  }
		  
		  if(trim(gid('MF:txtfrmRange').value) =="")
	          {
	          	setMsg("From Range Cannot Be Blank");
	          	gid("MF:txtApplInsOrRepl").focus();
				return;
	          }

		   if(trim(gid('MF:uptoRange').value) =="")
	          {
	          	setMsg("UpTo Range Cannot Be Blank");
	          	gid("MF:txtApplInsOrRepl").focus();
				return;
	          }
	          
	       if(trim(gid('MF:txtfrmRange').value) !=trim(gid('MF:uptoRange').value))
            {
	            setMsg("Both From Range and Upto Range Should Be Same for Inset Before/Insert After Selection");
	          	gid("MF:txtApplInsOrRepl").focus();
				return;
            }
            
            for(var i=1; i<=CompleteAmdArray.length; i++) {
		    	   if(i==parseInt(gid('MF:uptoRange').value)+parseInt(1)){
		            {
		            result=result+gid('MF:txtApplInsOrRepl').value+"\n";
		            result=result+CompleteAmdArray[i-1]+"\n";
   					//tempArray.push(CompleteAmdArray[i-1]); 
   					}
   					}
					else{
			            result=result+CompleteAmdArray[i-1]+"\n";
					}
				}
				
	  		gid('MF:txtcompAmdDetails').value=result;
	  } 
	         
	         
	 		 var Arr=[gid('MF:txtfrmRange').value,gid('MF:uptoRange').value,gid('MF:lstamdChoice').value];
		      addValueToKey(choiceSlforGrid1,Arr);
		      
		      if(gid('MF:amdGoodsValue').value=="")
		      {
		      		  gid('MF:amdGoodsValue').value=gid('MF:txtChoiceSl').value+","+gid('MF:txtfrmRange').value+","+gid('MF:uptoRange').value+","+gid('MF:lstamdChoice').value;
		      }
		      else{
		      		   gid('MF:amdGoodsValue').value=gid('MF:amdGoodsValue').value+"|"+gid('MF:txtChoiceSl').value+","+gid('MF:txtfrmRange').value+","+gid('MF:uptoRange').value+","+gid('MF:lstamdChoice').value;
		      }
		      
	  		  	 gid('MF:txtApplInsOrRepl').value=="";
	  
	  
	 		
	  
	   		if(gid('MF:txtAmdLog').value==""){
			      gid('MF:txtAmdLog').value=value;
				     if(gid('MF:lstamdChoice').value!="4"){ /*CONDITION ADDED BY PRASHANTH ON 28 MARCH 2019 FOR DELETE*/	
				     	gid('MF:amdlogtemp1').value=value+"|"+gid('MF:lstamdChoice').value;
				     }
			      }
				 else{
				      gid('MF:txtAmdLog').value=gid('MF:txtAmdLog').value+"\n"+value;
				   	 if(gid('MF:lstamdChoice').value!="4"){ /*CONDITION ADDED BY PRASHANTH ON 28 MARCH 2019 FOR DELETE*/
					   	    gid('MF:amdlogtemp1').value=trim(gid('MF:amdlogtemp1').value)+"\n"+value+"|"+gid('MF:lstamdChoice').value;
				      }
				   }
			   choiceSlforGrid1=choiceSlforGrid1+1;
		       gid('MF:txtChoiceSl').value=choiceSlforGrid1;
   			   gid('MF:txtApplInsOrRepl').value="";
	  return;
	}
	
	function inRange(x, min, max) {
    return ((x-min)*(x-max) <= 0);
}

/*ARRAY MAPS FOR 5 TABS */
	
	function addValueToKey(key, value) {
				    aMap[key] = aMap[key] || [];
				    aMap[key].push(value);
				}
	function addValueToKey2(key, value) {
				    aMap2[key] = aMap2[key] || [];
				    aMap2[key].push(value);
				}
	function addValueToKey3(key, value) {
				    aMap3[key] = aMap3[key] || [];
				    aMap3[key].push(value);
				}
	function addValueToKey4(key, value) {
				    aMap4[key] = aMap4[key] || [];
				    aMap4[key].push(value);
				}
	function addValueToKey5(key, value) {
				    aMap5[key] = aMap5[key] || [];
				    aMap5[key].push(value);
				}												
	
	function CopyText1()
	{
	   gid('MF:txtApplInsOrRepl').value=grid1SelectedValue;
	}
	
	function PushData2()
	{
	var deletedData="";
	  var delvalue="";
	/*1-insert,2-insertbefore,3-insertafter,4-delete,5-Replace*/
	   if(gid('MF:chkChgDoc').checked==false)
	   {
	   if(gid('MF:txtApplInsOrReplDoc').value!="")
		  {
		  	setMsg("Cannot Enter When Change in Change in Documents is not checked");
			gid("MF:txtApplInsOrReplDoc").focus();
			return;
		  }
	   }
		var selectedChoice="";
		var value=gid('MF:txtApplInsOrReplDoc').value;
		
		var valueLength = value.length;
		if(valueLength>65){
			setMsg("Cannot Enter more than 65 Characters");
			gid("MF:txtApplInsOrReplDoc").focus();
			return;
	     }
	     
		
	  if(gid('MF:lstamdChoiceDoc').value=="1")
	  {/*1-insert*/
	      selectedChoice="Insert:";
		  if(gid('MF:txtApplInsOrReplDoc').value=="")
		  {
		  	setMsg("Insertion/Replace Value Cannot Be Blank");
			gid("MF:txtApplInsOrReplDoc").focus();
			return;
		  }
		  
		  
		  if(gid('MF:txtcompAmdDetailsDoc').value=="")
		  {
		  	gid('MF:txtcompAmdDetailsDoc').value=gid('MF:txtApplInsOrReplDoc').value;
		  }
		  else{
		      gid('MF:txtcompAmdDetailsDoc').value=gid('MF:txtcompAmdDetailsDoc').value+"\n"+gid('MF:txtApplInsOrReplDoc').value;
		  }
	  }
	  else if(gid('MF:lstamdChoiceDoc').value=="4")
	  {
	  /*4-Delete*/
	  
	  
	    if(gid('MF:txtfrmRangeDoc').value=="" && gid('MF:uptoRangeDoc').value=="")
		  {
		  	setMsg("From Range & UpTo Range Cannot Be Blank");
			gid("MF:txtfrmRangeDoc").focus();
			return;
		  }
		  
	  value=grid2SelectedValue;
	  	 selectedChoice="Delete:";
		  var grid1SelectedIndexArray=[];
		  var CompleteAmdArray=[];
		  var tempArray=[];
	 	  CompleteAmdArray=gid('MF:txtcompAmdDetailsDoc').value.split("\n");
       var result="";
		for(var i=1; i<=CompleteAmdArray.length; i++) {
		    	if(!inRange(i,gid('MF:txtfrmRangeDoc').value,gid('MF:uptoRangeDoc').value))
		    	{
		            {
		            result=result+CompleteAmdArray[i-1]+"\n";
   					//tempArray.push(CompleteAmdArray[i-1]); 
   					}
				}
				
				else{
					/*ADDED BY PRASHANTH ON 28 MARCH 2019*/	 
				    delvalue=CompleteAmdArray[i-1].replace(/[\r\n]/g, '')+"|"+gid('MF:lstamdChoiceDoc').value+"\n";
					if(gid('MF:amdlogtemp2').value==""){
				      gid('MF:amdlogtemp2').value=delvalue;
				      gid('MF:amdlogtemp2').value=trim(gid('MF:amdlogtemp2').value);
			          }
			 	else{ 
			 	 gid('MF:amdlogtemp2').value=gid('MF:amdlogtemp2').value+"\n"+delvalue;
			  		}
	   				/*ADDED BY PRASHANTH ON 28 MARCH 2019*/	
					deletedData=deletedData+CompleteAmdArray[i-1];
					value=deletedData;
					}
					
				}
	      
		  gid('MF:txtcompAmdDetailsDoc').value=result;
		 // 	choiceSlforGrid2=choiceSlforGrid2+1;
		  //	 gid('MF:txtChoiceSlDoc').value=choiceSlforGrid2;
	  }
	  
	    else if(gid('MF:lstamdChoiceDoc').value=="5")
	  {/*5-Replace*/
	 	  // value=grid2SelectedValue;
	  	 selectedChoice="Replace:";
		  var grid1SelectedIndexArray=[];
		  var CompleteAmdArray=[];
		  var tempArray=[];
	 	  CompleteAmdArray=gid('MF:txtcompAmdDetailsDoc').value.split("\n");
       var result=gid('MF:txtApplInsOrReplDoc').value;
       
       if(gid('MF:txtApplInsOrReplDoc').value=="")
		  {
		  	setMsg("Insertion/Replace Value Cannot Be Blank");
			gid("MF:txtApplInsOrReplDoc").focus();
			return;
		  }
		  
		for(var i=1; i<=CompleteAmdArray.length; i++) {
		    	if(inRange(i,gid('MF:txtfrmRangeDoc').value,gid('MF:uptoRangeDoc').value))
		    	{
		    	   if(i==gid('MF:uptoRangeDoc').value){
		            {
		            result=result+gid('MF:txtApplInsOrReplDoc').value+"\n";
   					//tempArray.push(CompleteAmdArray[i-1]); 
   					}
   					}
				}
				else{
		            result=result+CompleteAmdArray[i-1]+"\n";
				}
				}
	      
		  gid('MF:txtcompAmdDetailsDoc').value=result;
	  }
	  
	   if(gid('MF:lstamdChoiceDoc').value=="2")
	  {/*2-insert before*/
	  	 selectedChoice="Insert:";
		  var grid1SelectedIndexArray=[];
		  var CompleteAmdArray=[];
		  var tempArray=[];
	 	  CompleteAmdArray=gid('MF:txtcompAmdDetailsDoc').value.split("\n");
       var result="";
       
       
	    if(gid('MF:txtApplInsOrReplDoc').value=="")
		  {
		  	setMsg("Insertion/Replace Value Cannot Be Blank");
			gid("MF:txtApplInsOrReplDoc").focus();
			return;
		  }
		  
		  if(trim(gid('MF:txtfrmRangeDoc').value) =="")
	          {
	          	setMsg("From Range Cannot Be Blank");
	          	gid("MF:txtApplInsOrReplDoc").focus();
				return;
	          }

		   if(trim(gid('MF:uptoRangeDoc').value) =="")
	          {
	          	setMsg("UpTo Range Cannot Be Blank");
	          	gid("MF:txtApplInsOrReplDoc").focus();
				return;
	          }
	          
	       if(trim(gid('MF:txtfrmRangeDoc').value) !=trim(gid('MF:uptoRangeDoc').value))
            {
	            setMsg("Both From Range and Upto Range Should Be Same for Insert Before/Insert After Selection");
	          	gid("MF:txtApplInsOrReplDoc").focus();
				return;
            }
            
            for(var i=1; i<=CompleteAmdArray.length;i++) {
		    	if(i==parseInt(gid('MF:uptoRangeDoc').value)){
		            {
		            	result=result+gid('MF:txtApplInsOrReplDoc').value+"\n";
		                result=result+CompleteAmdArray[i-1]+"\n";
   						//tempArray.push(CompleteAmdArray[i-1]);
   					}
   				}
				else{
		            result=result+CompleteAmdArray[i-1]+"\n";
				}
			}
	      
		  gid('MF:txtcompAmdDetailsDoc').value=result;
            
            
	  }
	  
	   if(gid('MF:lstamdChoiceDoc').value=="3")
	  {/*3-insert after*/
	  	 selectedChoice="Insert:";
		  var grid1SelectedIndexArray=[];
		  var CompleteAmdArray=[];
		  var tempArray=[];
	 	  CompleteAmdArray=gid('MF:txtcompAmdDetailsDoc').value.split("\n");
       var result="";
       
	  if(gid('MF:txtApplInsOrReplDoc').value=="")
		  {
		  	setMsg("Insertion/Replace Value Cannot Be Blank");
			gid("MF:txtApplInsOrReplDoc").focus();
			return;
		  }
		  
		  if(trim(gid('MF:txtfrmRangeDoc').value) =="")
	          {
	          	setMsg("From Range Cannot Be Blank");
	          	gid("MF:txtApplInsOrReplDoc").focus();
				return;
	          }

		   if(trim(gid('MF:uptoRangeDoc').value) =="")
	          {
	          	setMsg("UpTo Range Cannot Be Blank");
	          	gid("MF:txtApplInsOrReplDoc").focus();
				return;
	          }
	          
	       if(trim(gid('MF:txtfrmRangeDoc').value) !=trim(gid('MF:uptoRangeDoc').value))
            {
	            setMsg("Both From Range and Upto Range Should Be Same for Inset Before/Insert After Selection");
	          	gid("MF:txtApplInsOrReplDoc").focus();
				return;
            }
            
            
             for(var i=1; i<=CompleteAmdArray.length; i++) {
		    	   if(i==parseInt(gid('MF:uptoRangeDoc').value)+parseInt(1)){
		            {
		            result=result+gid('MF:txtApplInsOrReplDoc').value+"\n";
		            result=result+CompleteAmdArray[i-1]+"\n";
   					//tempArray.push(CompleteAmdArray[i-1]); 
   					}
   					}
					else{
			            result=result+CompleteAmdArray[i-1]+"\n";
					}
				}
				
	  		gid('MF:txtcompAmdDetailsDoc').value=result;
	  
	  }
	 		 var Arr=[gid('MF:txtfrmRangeDoc').value,gid('MF:uptoRangeDoc').value,gid('MF:lstamdChoiceDoc').value];
		      addValueToKey2(choiceSlforGrid2,Arr);
		      
		      if(gid('MF:amdDocsValue').value=="")
		      {
		      		  gid('MF:amdDocsValue').value=gid('MF:txtChoiceSlDoc').value+","+gid('MF:txtfrmRangeDoc').value+","+gid('MF:uptoRangeDoc').value+","+gid('MF:lstamdChoiceDoc').value;
		      }
		      else{
		      		   gid('MF:amdDocsValue').value=gid('MF:amdDocsValue').value+"|"+gid('MF:txtChoiceSlDoc').value+","+gid('MF:txtfrmRangeDoc').value+","+gid('MF:uptoRangeDoc').value+","+gid('MF:lstamdChoiceDoc').value;
		      }
		      
	  		  	 gid('MF:txtApplInsOrReplDoc').value=="";
	  
	   		if(gid('MF:txtAmdLogDoc').value==""){
			      gid('MF:txtAmdLogDoc').value=value;
			       if(gid('MF:lstamdChoiceDoc').value!="4"){ /*CONDITION ADDED BY PRASHANTH ON 28 MARCH 2019 FOR DELETE*/	
			    	  gid('MF:amdlogtemp2').value=value+"|"+gid('MF:lstamdChoiceDoc').value;
				     }
				     
				     
			      }
			 else{
			      gid('MF:txtAmdLogDoc').value=gid('MF:txtAmdLogDoc').value+"\n"+value;
			     if(gid('MF:lstamdChoiceDoc').value!="4"){ /*CONDITION ADDED BY PRASHANTH ON 28 MARCH 2019 FOR DELETE*/
			     		gid('MF:amdlogtemp2').value=gid('MF:amdlogtemp2').value+"\n"+value+"|"+gid('MF:lstamdChoiceDoc').value;
				      }
			   }
			   choiceSlforGrid2=choiceSlforGrid2+1;
		       gid('MF:txtChoiceSlDoc').value=choiceSlforGrid2;
   			   gid('MF:txtApplInsOrReplDoc').value="";
	  return;
	}
	
	function CopyText2()
	{
		   gid('MF:txtApplInsOrReplDoc').value=grid2SelectedValue;
	}
	
	function PushData3()
	{
	  var deletedData="";
	  var delvalue="";
	/*1-insert,2-insertbefore,3-insertafter,4-delete,5-Replace*/
	   if(gid('MF:chkChgAddCond').checked==false)
	   {
	   if(gid('MF:txtApplInsOrReplAddl').value!="")
		  {
		  	setMsg("Cannot Enter When CChange in Additional Conditions is not checked");
			gid("MF:txtApplInsOrReplAddl").focus();
			return;
		  }
	   }
		var selectedChoice="";
		var value=gid('MF:txtApplInsOrReplAddl').value;
		
		
		var valueLength =  value.length;
		if(valueLength>65){
			setMsg("Cannot Enter more than 65 Characters");
			gid("MF:txtApplInsOrReplAddl").focus();
			return;
	     }
	     
		
	  if(gid('MF:lstamdChoiceAddl').value=="1")
	  {/*1-insert*/
	      selectedChoice="Insert:";
		  if(gid('MF:txtApplInsOrReplAddl').value=="")
		  {
		  	setMsg("Insertion/Replace Value Cannot Be Blank");
			gid("MF:txtApplInsOrReplAddl").focus();
			return;
		  }
		  if(gid('MF:txtcompAmdDetailsAddl').value=="")
		  {
		  	gid('MF:txtcompAmdDetailsAddl').value=gid('MF:txtApplInsOrReplAddl').value;
		  }
		  else{
		      gid('MF:txtcompAmdDetailsAddl').value=gid('MF:txtcompAmdDetailsAddl').value+"\n"+gid('MF:txtApplInsOrReplAddl').value;
		  }
	  }
	  else if(gid('MF:lstamdChoiceAddl').value=="4")
	  {
	  /*4-Delete*/
	  
	   if(gid('MF:txtfrmRangeAddl').value=="" && gid('MF:uptoRangeAddl').value=="")
		  {
		  	setMsg("From Range & UpTo Range Cannot Be Blank");
			gid("MF:txtfrmRangeAddl").focus();
			return;
		  }
		  
		  
	  value=grid3SelectedValue;
	  	 selectedChoice="Delete:";
		  var grid1SelectedIndexArray=[];
		  var CompleteAmdArray=[];
		  var tempArray=[];
	 	  CompleteAmdArray=gid('MF:txtcompAmdDetailsAddl').value.split("\n");
       var result="";
		for(var i=1; i<=CompleteAmdArray.length; i++) {
		    	if(!inRange(i,gid('MF:txtfrmRangeAddl').value,gid('MF:uptoRangeAddl').value))
		    	{
		            {
		            result=result+CompleteAmdArray[i-1]+"\n";
   					//tempArray.push(CompleteAmdArray[i-1]); 
   					}
				}
				
				else{
					/*ADDED BY PRASHANTH ON 28 MARCH 2019*/	 
				    delvalue=CompleteAmdArray[i-1].replace(/[\r\n]/g, '')+"|"+gid('MF:lstamdChoiceAddl').value+"\n";
					if(gid('MF:amdlogtemp3').value==""){
				      gid('MF:amdlogtemp3').value=delvalue;
				      gid('MF:amdlogtemp3').value=trim(gid('MF:amdlogtemp3').value);
			          }
			 	else{ 
			 	 gid('MF:amdlogtemp3').value=gid('MF:amdlogtemp3').value+"\n"+delvalue;
			  		}
	   				/*ADDED BY PRASHANTH ON 28 MARCH 2019*/	
					deletedData=deletedData+CompleteAmdArray[i-1];
					value=deletedData;
					}
				}
	      
		  gid('MF:txtcompAmdDetailsAddl').value=result;
		  //	choiceSlforGrid3=choiceSlforGrid3+1;
		  //	 gid('MF:lstamdChoiceAddl').value=choiceSlforGrid3;
	  }
	  
	    else if(gid('MF:lstamdChoiceAddl').value=="5")
	  {/*5-Replace*/
	 	 // value=grid3SelectedValue;
	  	 selectedChoice="Replace:";
		  var grid1SelectedIndexArray=[];
		  var CompleteAmdArray=[];
		  var tempArray=[];
	 	  CompleteAmdArray=gid('MF:txtcompAmdDetailsAddl').value.split("\n");
       var result=gid('MF:txtApplInsOrReplAddl').value;
       
       if(gid('MF:txtApplInsOrReplAddl').value=="")
		  {
		  	setMsg("Insertion/Replace Value Cannot Be Blank");
			gid("MF:txtApplInsOrReplAddl").focus();
			return;
		  }
		  
		for(var i=1; i<=CompleteAmdArray.length; i++) {
		    	if(inRange(i,gid('MF:txtfrmRangeAddl').value,gid('MF:uptoRangeAddl').value))
		    	{
		    	   if(i==gid('MF:uptoRangeAddl').value){
		            {
		            result=result+gid('MF:txtApplInsOrReplAddl').value+"\n";
   					//tempArray.push(CompleteAmdArray[i-1]); 
   					}
   					}
				}
				else{
		            result=result+CompleteAmdArray[i-1]+"\n";
				}
				}
	      
		  gid('MF:txtcompAmdDetailsAddl').value=result;
	  }
	  
	   if(gid('MF:lstamdChoiceAddl').value=="2")
	  {/*2-insert before*/
	  	 selectedChoice="Insert:";
		  var grid1SelectedIndexArray=[];
		  var CompleteAmdArray=[];
		  var tempArray=[];
	 	  CompleteAmdArray=gid('MF:txtcompAmdDetailsAddl').value.split("\n");
       var result="";
	  
	    if(gid('MF:txtApplInsOrReplAddl').value=="")
		  {
		  	setMsg("Insertion/Replace Value Cannot Be Blank");
			gid("MF:txtApplInsOrReplAddl").focus();
			return;
		  }
		  
		  if(trim(gid('MF:txtfrmRangeAddl').value) =="")
	          {
	          	setMsg("From Range Cannot Be Blank");
	          	gid("MF:txtApplInsOrReplAddl").focus();
				return;
	          }

		   if(trim(gid('MF:uptoRangeAddl').value) =="")
	          {
	          	setMsg("UpTo Range Cannot Be Blank");
	          	gid("MF:txtApplInsOrReplAddl").focus();
				return;
	          }
	          
	       if(trim(gid('MF:txtfrmRangeAddl').value) !=trim(gid('MF:uptoRangeAddl').value))
            {
	            setMsg("Both From Range and Upto Range Should Be Same for Insert Before/Insert After Selection");
	          	gid("MF:txtApplInsOrReplAddl").focus();
				return;
            }
            
            
             for(var i=1; i<=CompleteAmdArray.length;i++) {
		    	if(i==parseInt(gid('MF:uptoRangeAddl').value)){
		            {
		            	result=result+gid('MF:txtApplInsOrReplAddl').value+"\n";
		            	result=result+CompleteAmdArray[i-1]+"\n";
   						//tempArray.push(CompleteAmdArray[i-1]);
   					}
   				}
				else{
		            result=result+CompleteAmdArray[i-1]+"\n";
				}
			}
	      
		  gid('MF:txtcompAmdDetailsAddl').value=result;
		  
	  }
	  
	   if(gid('MF:lstamdChoiceAddl').value=="3")
	  {/*3-insert after*/
	  
	  
	  	 selectedChoice="Insert:";
		  var grid1SelectedIndexArray=[];
		  var CompleteAmdArray=[];
		  var tempArray=[];
	 	  CompleteAmdArray=gid('MF:txtcompAmdDetailsAddl').value.split("\n");
       var result="";
       
       
       
	  if(gid('MF:txtApplInsOrReplAddl').value=="")
		  {
		  	setMsg("Insertion/Replace Value Cannot Be Blank");
			gid("MF:txtApplInsOrReplAddl").focus();
			return;
		  }
		  
		  if(trim(gid('MF:txtfrmRangeAddl').value) =="")
	          {
	          	setMsg("From Range Cannot Be Blank");
	          	gid("MF:txtApplInsOrReplAddl").focus();
				return;
	          }

		   if(trim(gid('MF:uptoRangeAddl').value) =="")
	          {
	          	setMsg("UpTo Range Cannot Be Blank");
	          	gid("MF:txtApplInsOrReplAddl").focus();
				return;
	          }
	          
	       if(trim(gid('MF:txtfrmRangeAddl').value) !=trim(gid('MF:uptoRangeAddl').value))
            {
	            setMsg("Both From Range and Upto Range Should Be Same for Inset Before/Insert After Selection");
	          	gid("MF:txtApplInsOrReplAddl").focus();
				return;
            }
            
            
            for(var i=1; i<=CompleteAmdArray.length; i++) {
		    	   if(i==parseInt(gid('MF:uptoRangeAddl').value)+parseInt(1)){
		            {
		            result=result+gid('MF:txtApplInsOrReplAddl').value+"\n";
		            result=result+CompleteAmdArray[i-1]+"\n";
   					//tempArray.push(CompleteAmdArray[i-1]); 
   					}
   					}
					else{
			            result=result+CompleteAmdArray[i-1]+"\n";
					}
				}
				
	  		gid('MF:txtcompAmdDetailsAddl').value=result;
	  
	  }
	 		 var Arr=[gid('MF:txtfrmRangeAddl').value,gid('MF:uptoRangeAddl').value,gid('MF:lstamdChoiceAddl').value];
		      addValueToKey3(choiceSlforGrid3,Arr);
		      
		      if(gid('MF:amdAddlValue').value=="")
		      {
		      		  gid('MF:amdAddlValue').value=gid('MF:txtChoiceSlDoc').value+","+gid('MF:txtfrmRangeDoc').value+","+gid('MF:uptoRangeDoc').value+","+gid('MF:lstamdChoiceDoc').value;
		      }
		      else{
		      		   gid('MF:amdAddlValue').value=gid('MF:amdDocsValue').value+"|"+gid('MF:txtChoiceSlAddl').value+","+gid('MF:txtfrmRangeDoc').value+","+gid('MF:uptoRangeDoc').value+","+gid('MF:lstamdChoiceAddl').value;
		      }
		      
	  		  	 gid('MF:txtApplInsOrReplAddl').value=="";
	  
	   		if(gid('MF:txtAmdLogAddl').value==""){
			      gid('MF:txtAmdLogAddl').value=value;
			           if(gid('MF:lstamdChoiceAddl').value!="4"){ 
			  	     		gid('MF:amdlogtemp3').value=value+"|"+gid('MF:lstamdChoiceAddl').value;
			  	        }
			      }
			 else{
			        gid('MF:txtAmdLogAddl').value=gid('MF:txtAmdLogAddl').value+"\n"+value;
			        if(gid('MF:lstamdChoiceAddl').value!="4"){ 
			    		gid('MF:amdlogtemp3').value=gid('MF:amdlogtemp3').value+"\n"+value+"|"+gid('MF:lstamdChoiceAddl').value;
			    	}
			   }
			   
			   
			   choiceSlforGrid3=choiceSlforGrid3+1;
		       gid('MF:txtChoiceSlAddl').value=choiceSlforGrid3;
   			   gid('MF:txtApplInsOrReplAddl').value="";
	  return;
	}
	
	function CopyText3()
	{
		   gid('MF:txtApplInsOrReplAddl').value=grid3SelectedValue;
	}
	
	function PushData4()
	{
	 var deletedData="";
	  var delvalue="";
	/*1-insert,2-insertbefore,3-insertafter,4-delete,5-Replace*/
		var selectedChoice="";
		var value=gid('MF:txtApplInsOrReplSplBene').value;
		
		
		var valueLength =  value.length;
		if(valueLength>65){
			setMsg("Cannot Enter more than 65 Characters");
			gid("MF:txtApplInsOrReplSplBene").focus();
			return;
	     }
	     
		
	  if(gid('MF:lstamdChoiceSplBene').value=="1")
	  {/*1-insert*/
	      selectedChoice="Insert:";
		  if(gid('MF:txtApplInsOrReplSplBene').value=="")
		  {
		  	setMsg("Insertion/Replace Value Cannot Be Blank");
			gid("MF:txtApplInsOrReplSplBene").focus();
			return;
		  }
		  
		  if(gid('MF:txtcompAmdDetailsSplBene').value=="")
		  {
		  	gid('MF:txtcompAmdDetailsSplBene').value=gid('MF:txtApplInsOrReplSplBene').value;
		  }
		  else{
		      gid('MF:txtcompAmdDetailsSplBene').value=gid('MF:txtcompAmdDetailsSplBene').value+"\n"+gid('MF:txtApplInsOrReplSplBene').value;
		  }
	  }
	  else if(gid('MF:lstamdChoiceSplBene').value=="4")
	  {
	  /*4-Delete*/
	   if(gid('MF:txtfrmRangeSplBene').value=="" && gid('MF:uptoRangeSplBene').value=="")
		  {
		  	setMsg("From Range & UpTo Range Cannot Be Blank");
			gid("MF:txtfrmRangeSplBene").focus();
			return;
		  }
		  
		  
	  value=grid4SelectedValue;
	  	 selectedChoice="Delete:";
		  var grid1SelectedIndexArray=[];
		  var CompleteAmdArray=[];
		  var tempArray=[];
	 	  CompleteAmdArray=gid('MF:txtcompAmdDetailsSplBene').value.split("\n");
       var result="";
		for(var i=1; i<=CompleteAmdArray.length; i++) {
		    	if(!inRange(i,gid('MF:txtfrmRangeSplBene').value,gid('MF:uptoRangeSplBene').value))
		    	{
		            {
		            result=result+CompleteAmdArray[i-1]+"\n";
   					//tempArray.push(CompleteAmdArray[i-1]); 
   					}
				}
				else{
					/*ADDED BY PRASHANTH ON 28 MARCH 2019*/	 
				    delvalue=CompleteAmdArray[i-1].replace(/[\r\n]/g, '')+"|"+gid('MF:lstamdChoiceSplBene').value+"\n";
					if(gid('MF:amdlogtemp4').value==""){
				      gid('MF:amdlogtemp4').value=delvalue;
				      gid('MF:amdlogtemp4').value=trim(gid('MF:amdlogtemp4').value);
			          }
			 	else{ 
			 	 gid('MF:amdlogtemp4').value=gid('MF:amdlogtemp4').value+"\n"+delvalue;
			  		}
	   				/*ADDED BY PRASHANTH ON 28 MARCH 2019*/	
					deletedData=deletedData+CompleteAmdArray[i-1];
					value=deletedData;
					}
				}
	      
		  gid('MF:txtcompAmdDetailsSplBene').value=result;
		 // 	choiceSlforGrid4=choiceSlforGrid4+1;
		  //	 gid('MF:txtChoiceSlSplBene').value=choiceSlforGrid4;
	  }
	  
	    else if(gid('MF:lstamdChoiceSplBene').value=="5")
	  {/*5-Replace*/
	 	  //value=grid4SelectedValue;
	  	 selectedChoice="Replace:";
		  var grid1SelectedIndexArray=[];
		  var CompleteAmdArray=[];
		  var tempArray=[];
	 	  CompleteAmdArray=gid('MF:txtcompAmdDetailsSplBene').value.split("\n");
       var result=gid('MF:txtApplInsOrReplSplBene').value;
       
       if(gid('MF:txtApplInsOrReplSplBene').value=="")
		  {
		  	setMsg("Insertion/Replace Value Cannot Be Blank");
			gid("MF:txtApplInsOrReplSplBene").focus();
			return;
		  }
		  
		for(var i=1; i<=CompleteAmdArray.length; i++) {
		    	if(inRange(i,gid('MF:txtfrmRangeSplBene').value,gid('MF:uptoRangeSplBene').value))
		    	{
		    	   if(i==gid('MF:uptoRangeSplBene').value){
		            {
		            result=result+gid('MF:txtApplInsOrReplSplBene').value+"\n";
   					//tempArray.push(CompleteAmdArray[i-1]); 
   					}
   					}
				}
				else{
		            result=result+CompleteAmdArray[i-1]+"\n";
				}
				}
	      
		  gid('MF:txtcompAmdDetailsSplBene').value=result;
	  }
	  
	   if(gid('MF:lstamdChoiceSplBene').value=="2")
	  {/*2-insert before*/
	  
	  	 selectedChoice="Insert:";
		  var grid1SelectedIndexArray=[];
		  var CompleteAmdArray=[];
		  var tempArray=[];
	 	  CompleteAmdArray=gid('MF:txtcompAmdDetailsSplBene').value.split("\n");
       var result="";
       
	  
	    if(gid('MF:txtApplInsOrReplSplBene').value=="")
		  {
		  	setMsg("Insertion/Replace Value Cannot Be Blank");
			gid("MF:txtApplInsOrReplSplBene").focus();
			return;
		  }
		  
		  if(trim(gid('MF:txtfrmRangeSplBene').value) =="")
	          {
	          	setMsg("From Range Cannot Be Blank");
	          	gid("MF:txtApplInsOrReplSplBene").focus();
				return;
	          }

		   if(trim(gid('MF:uptoRangeSplBene').value) =="")
	          {
	          	setMsg("UpTo Range Cannot Be Blank");
	          	gid("MF:txtApplInsOrReplSplBene").focus();
				return;
	          }
	          
	       if(trim(gid('MF:txtfrmRangeSplBene').value) !=trim(gid('MF:uptoRangeSplBene').value))
            {
	            setMsg("Both From Range and Upto Range Should Be Same for Inset Before/Insert After Selection");
	          	gid("MF:txtApplInsOrReplSplBene").focus();
				return;
            }
            
            
            for(var i=1; i<=CompleteAmdArray.length;i++) {
		    	if(i==parseInt(gid('MF:uptoRangeSplBene').value)){
		            {
		            	result=result+gid('MF:txtApplInsOrReplSplBene').value+"\n";
		            	result=result+CompleteAmdArray[i-1]+"\n";
   						//tempArray.push(CompleteAmdArray[i-1]);
   					}
   				}
				else{
		            result=result+CompleteAmdArray[i-1]+"\n";
				}
			}
	      
		  gid('MF:txtcompAmdDetailsSplBene').value=result;
            
            
	  }
	  
	   if(gid('MF:lstamdChoiceSplBene').value=="3")
	  {/*3-insert after*/
	  
	  
	  	 selectedChoice="Insert:";
		  var grid1SelectedIndexArray=[];
		  var CompleteAmdArray=[];
		  var tempArray=[];
	 	  CompleteAmdArray=gid('MF:txtcompAmdDetailsSplBene').value.split("\n");
       var result="";
       
       
       
	  if(gid('MF:txtApplInsOrReplSplBene').value=="")
		  {
		  	setMsg("Insertion/Replace Value Cannot Be Blank");
			gid("MF:txtApplInsOrReplSplBene").focus();
			return;
		  }
		  
		  if(trim(gid('MF:txtfrmRangeSplBene').value) =="")
	          {
	          	setMsg("From Range Cannot Be Blank");
	          	gid("MF:txtApplInsOrReplSplBene").focus();
				return;
	          }

		   if(trim(gid('MF:uptoRangeSplBene').value) =="")
	          {
	          	setMsg("UpTo Range Cannot Be Blank");
	          	gid("MF:txtApplInsOrReplSplBene").focus();
				return;
	          }
	          
	       if(trim(gid('MF:txtfrmRangeSplBene').value) !=trim(gid('MF:uptoRangeSplBene').value))
            {
	            setMsg("Both From Range and Upto Range Should Be Same for Inset Before/Insert After Selection");
	          	gid("MF:txtApplInsOrReplSplBene").focus();
				return;
            }
            
            
             for(var i=1; i<=CompleteAmdArray.length; i++) {
		    	   if(i==parseInt(gid('MF:uptoRangeSplBene').value)+parseInt(1)){
		            {
		            result=result+gid('MF:txtApplInsOrReplSplBene').value+"\n";
		            result=result+CompleteAmdArray[i-1]+"\n";
   					//tempArray.push(CompleteAmdArray[i-1]); 
   					}
   					}
					else{
			            result=result+CompleteAmdArray[i-1]+"\n";
					}
				}
				
	  		gid('MF:txtcompAmdDetailsSplBene').value=result;
	  		
	  		
	  
	  }
	 		 var Arr=[gid('MF:txtfrmRangeSplBene').value,gid('MF:uptoRangeSplBene').value,gid('MF:lstamdChoiceSplBene').value];
		      addValueToKey4(choiceSlforGrid4,Arr);
		      
		      if(gid('MF:amdSpl1Value').value=="")
		      {
		      		  gid('MF:amdSpl1Value').value=gid('MF:txtChoiceSlSplBene').value+","+gid('MF:txtfrmRangeSplBene').value+","+gid('MF:uptoRangeSplBene').value+","+gid('MF:lstamdChoiceSplBene').value;
		      }
		      else{
		      		   gid('MF:amdSpl1Value').value=gid('MF:amdSpl1Value').value+"|"+gid('MF:txtChoiceSl').value+","+gid('MF:txtfrmRangeSplBene').value+","+gid('MF:uptoRangeSplBene').value+","+gid('MF:lstamdChoiceSplBene').value;
		      }
		      
	  		  	 gid('MF:txtApplInsOrReplSplBene').value=="";
	  
	   		if(gid('MF:txtAmdLogSplBene').value==""){
			      gid('MF:txtAmdLogSplBene').value=value;
			       if(gid('MF:lstamdChoiceSplBene').value!="4"){ /*CONDITION ADDED BY PRASHANTH ON 28 MARCH 2019 FOR DELETE*/	
			       		gid('MF:amdlogtemp4').value=value+"|"+gid('MF:lstamdChoiceSplBene').value;
			       }
			      }
			 else{
			      gid('MF:txtAmdLogSplBene').value=gid('MF:txtAmdLogSplBene').value+"\n"+value;
			        if(gid('MF:lstamdChoiceSplBene').value!="4"){ /*CONDITION ADDED BY PRASHANTH ON 28 MARCH 2019 FOR DELETE*/
				    gid('MF:amdlogtemp4').value=gid('MF:amdlogtemp4').value+"\n"+value+"|"+gid('MF:lstamdChoiceSplBene').value;
				    }
			   }
			   
			   choiceSlforGrid4=choiceSlforGrid4+1;
		       gid('MF:txtChoiceSlSplBene').value=choiceSlforGrid4;
   			   gid('MF:txtApplInsOrReplSplBene').value="";
	  return;
	}
	
	function CopyText4()
	{
			gid('MF:txtApplInsOrReplSplBene').value=grid4SelectedValue;
	
	}
	
	function PushData5()
	{
	var deletedData="";
	var delvalue="";
	/*1-insert,2-insertbefore,3-insertafter,4-delete,5-Replace*/
		var selectedChoice="";
		var value=gid('MF:txtApplInsOrReplSplRecev').value;
		
		var valueLength = value.length;
		if(valueLength>65){
			setMsg("Cannot Enter more than 65 Characters");
			gid("MF:txtApplInsOrReplSplRecev").focus();
			return;
	     }
	     
		
	  if(gid('MF:lstamdChoiceSplRecev').value=="1")
	  {/*1-insert*/
	      selectedChoice="Insert:";
		  if(gid('MF:txtApplInsOrReplSplRecev').value=="")
		  {
		  	setMsg("Insertion/Replace Value Cannot Be Blank");
			gid("MF:txtApplInsOrReplSplRecev").focus();
			return;
		  }
		  
		  if(gid('MF:txtcompAmdDetailsSplBene').value=="")
		  {
		  	gid('MF:txtcompAmdDetailsSplRecev').value=gid('MF:txtApplInsOrReplSplRecev').value;
		  }
		  else{
		      gid('MF:txtcompAmdDetailsSplRecev').value=gid('MF:txtcompAmdDetailsSplRecev').value+"\n"+gid('MF:txtApplInsOrReplSplRecev').value;
		  }
	  }
	  else if(gid('MF:lstamdChoiceSplRecev').value=="4")
	  {
	  /*4-Delete*/
	  
	  if(gid('MF:txtfrmRangeSplRecev').value=="" && gid('MF:uptoRangeSplRecev').value=="")
		  {
		  	setMsg("From Range & UpTo Range Cannot Be Blank");
			gid("MF:txtfrmRangeSplRecev").focus();
			return;
		  }
		  
		  
	  value=grid5SelectedValue;
	  	 selectedChoice="Delete:";
		  var grid1SelectedIndexArray=[];
		  var CompleteAmdArray=[];
		  var tempArray=[];
	 	  CompleteAmdArray=gid('MF:txtcompAmdDetailsSplRecev').value.split("\n");
       var result="";
		for(var i=1; i<=CompleteAmdArray.length; i++) {
		    	if(!inRange(i,gid('MF:txtfrmRangeSplRecev').value,gid('MF:uptoRangeSplRecev').value))
		    	{
		            {
		            result=result+CompleteAmdArray[i-1]+"\n";
   					//tempArray.push(CompleteAmdArray[i-1]); 
   					}
				}
				else{
					/*ADDED BY PRASHANTH ON 28 MARCH 2019*/	 
				    delvalue=CompleteAmdArray[i-1].replace(/[\r\n]/g, '')+"|"+gid('MF:lstamdChoiceSplRecev').value+"\n";
					if(gid('MF:amdlogtemp5').value==""){
				      gid('MF:amdlogtemp5').value=delvalue;
				      gid('MF:amdlogtemp5').value=trim(gid('MF:amdlogtemp5').value);
			          }
			 	else{ 
			 	 gid('MF:amdlogtemp5').value=gid('MF:amdlogtemp5').value+"\n"+delvalue;
			  		}
	   				/*ADDED BY PRASHANTH ON 28 MARCH 2019*/	
					deletedData=deletedData+CompleteAmdArray[i-1];
					value=deletedData;
					}
				}
	      
		  gid('MF:txtcompAmdDetailsSplRecev').value=result;
		//  	choiceSlforGrid5=choiceSlforGrid5+1;
		  //	 gid('MF:txtChoiceSlSplRecev').value=choiceSlforGrid5;
	  }
	  
	    else if(gid('MF:lstamdChoiceSplRecev').value=="5")
	  {/*5-Replace*/
	 	  //value=grid5SelectedValue;
	  	 selectedChoice="Replace:";
		  var grid1SelectedIndexArray=[];
		  var CompleteAmdArray=[];
		  var tempArray=[];
	 	  CompleteAmdArray=gid('MF:txtcompAmdDetailsSplRecev').value.split("\n");
       var result=gid('MF:txtApplInsOrReplSplRecev').value;
       
       if(gid('MF:txtApplInsOrReplSplRecev').value=="")
		  {
		  	setMsg("Insertion/Replace Value Cannot Be Blank");
			gid("MF:txtApplInsOrReplSplRecev").focus();
			return;
		  }
		  
		for(var i=1; i<=CompleteAmdArray.length; i++) {
		    	if(inRange(i,gid('MF:txtfrmRangeSplRecev').value,gid('MF:uptoRangeSplRecev').value))
		    	{
		    	   if(i==gid('MF:uptoRangeSplRecev').value){
		            {
		            result=result+gid('MF:txtApplInsOrReplSplRecev').value+"\n";
   					//tempArray.push(CompleteAmdArray[i-1]); 
   					}
   					}
				}
				else{
		            result=result+CompleteAmdArray[i-1]+"\n";
				}
				}
	      
		  gid('MF:txtcompAmdDetailsSplRecev').value=result;
	  }
	  
	   if(gid('MF:lstamdChoiceSplRecev').value=="2")
	  {/*2-insert before*/
	  
	  	 selectedChoice="Insert:";
		  var grid1SelectedIndexArray=[];
		  var CompleteAmdArray=[];
		  var tempArray=[];
	 	  CompleteAmdArray=gid('MF:txtcompAmdDetailsSplRecev').value.split("\n");
       var result="";
       
       
       
	    if(gid('MF:txtApplInsOrReplSplRecev').value=="")
		  {
		  	setMsg("Insertion/Replace Value Cannot Be Blank");
			gid("MF:txtApplInsOrReplSplRecev").focus();
			return;
		  }
		  
		  if(trim(gid('MF:txtfrmRangeSplRecev').value) =="")
	          {
	          	setMsg("From Range Cannot Be Blank");
	          	gid("MF:txtApplInsOrReplSplRecev").focus();
				return;
	          }

		   if(trim(gid('MF:uptoRangeSplRecev').value) =="")
	          {
	          	setMsg("UpTo Range Cannot Be Blank");
	          	gid("MF:txtApplInsOrReplSplRecev").focus();
				return;
	          }
	          
	       if(trim(gid('MF:txtfrmRangeSplRecev').value) !=trim(gid('MF:uptoRangeSplRecev').value))
            {
	            setMsg("Both From MF:txtApplInsOrReplSplRecev and Upto Range Should Be Same for Inset Before/Insert After Selection");
	          	gid("MF:txtApplInsOrReplSplBene").focus();
				return;
            }
            
            
            
             for(var i=1; i<=CompleteAmdArray.length;i++) {
		    	if(i==parseInt(gid('MF:uptoRangeSplRecev').value)){
		            {
		            	result=result+gid('MF:txtApplInsOrReplSplRecev').value+"\n";
		            	result=result+CompleteAmdArray[i-1]+"\n";
   						//tempArray.push(CompleteAmdArray[i-1]);
   					}
   				}
				else{
		            result=result+CompleteAmdArray[i-1]+"\n";
				}
			}
	      
		  gid('MF:txtcompAmdDetailsSplRecev').value=result;
		  
		  
            
	  }
	  
	   if(gid('MF:lstamdChoiceSplRecev').value=="3")
	  {/*3-insert after*/
	  
	  
	  
	  
	  	 selectedChoice="Insert:";
		  var grid1SelectedIndexArray=[];
		  var CompleteAmdArray=[];
		  var tempArray=[];
	 	  CompleteAmdArray=gid('MF:txtcompAmdDetailsSplRecev').value.split("\n");
       var result="";
       
       
       
	  if(gid('MF:txtApplInsOrReplSplRecev').value=="")
		  {
		  	setMsg("Insertion/Replace Value Cannot Be Blank");
			gid("MF:txtApplInsOrReplSplRecev").focus();
			return;
		  }
		  
		  if(trim(gid('MF:txtfrmRangeSplRecev').value) =="")
	          {
	          	setMsg("From Range Cannot Be Blank");
	          	gid("MF:txtApplInsOrReplSplRecev").focus();
				return;
	          }

		   if(trim(gid('MF:uptoRangeSplRecev').value) =="")
	          {
	          	setMsg("UpTo Range Cannot Be Blank");
	          	gid("MF:txtApplInsOrReplSplRecev").focus();
				return;
	          }
	          
	       if(trim(gid('MF:txtfrmRangeSplRecev').value) !=trim(gid('MF:uptoRangeSplRecev').value))
            {
	            setMsg("Both From Range and Upto Range Should Be Same for Inset Before/Insert After Selection");
	          	gid("MF:txtApplInsOrReplSplRecev").focus();
				return;
            }
            
            
             for(var i=1; i<=CompleteAmdArray.length; i++) {
		    	   if(i==parseInt(gid('MF:uptoRangeSplRecev').value)+parseInt(1)){
		            {
		            result=result+gid('MF:txtApplInsOrReplSplRecev').value+"\n";
		            result=result+CompleteAmdArray[i-1]+"\n";
   					//tempArray.push(CompleteAmdArray[i-1]); 
   					}
   					}
					else{
			            result=result+CompleteAmdArray[i-1]+"\n";
					}
				}
				
	  		gid('MF:txtcompAmdDetailsSplRecev').value=result;
	  
	  }
	 		 var Arr=[gid('MF:txtfrmRangeSplRecev').value,gid('MF:uptoRangeSplRecev').value,gid('MF:lstamdChoiceSplBene').value];
		      addValueToKey5(choiceSlforGrid5,Arr);
		      
		      if(gid('MF:amdSpl2Value').value=="")
		      {
		      		  gid('MF:amdSpl2Value').value=gid('MF:txtChoiceSlSplRecev').value+","+gid('MF:txtfrmRangeSplRecev').value+","+gid('MF:uptoRangeSplRecev').value+","+gid('MF:lstamdChoiceSplBene').value;
		      }
		      else{
		      		   gid('MF:amdSpl2Value').value=gid('MF:amdSpl2Value').value+"|"+gid('MF:txtChoiceSlSplRecev').value+","+gid('MF:txtfrmRangeSplRecev').value+","+gid('MF:uptoRangeSplRecev').value+","+gid('MF:lstamdChoiceSplBene').value;
		      }
		      
	  		  	 gid('MF:txtApplInsOrReplSplRecev').value=="";
	  
	   		if(gid('MF:txtAmdLogSplRecev').value==""){
			      gid('MF:txtAmdLogSplRecev').value=value;
			        if(gid('MF:lstamdChoiceSplRecev').value!="4"){ /*CONDITION ADDED BY PRASHANTH ON 28 MARCH 2019 FOR DELETE*/
			     	gid('MF:amdlogtemp5').value=value+"|"+gid('MF:lstamdChoiceSplRecev').value;
			     	}
			      }
			 else{
			      gid('MF:txtAmdLogSplRecev').value=gid('MF:txtAmdLogSplRecev').value+"\n"+value;
			      if(gid('MF:lstamdChoiceSplRecev').value!="4"){ /*CONDITION ADDED BY PRASHANTH ON 28 MARCH 2019 FOR DELETE*/
			      	gid('MF:amdlogtemp5').value=gid('MF:amdlogtemp5').value+"\n"+value+"|"+gid('MF:lstamdChoiceSplRecev').value;
			      }
			   }
			   
			   choiceSlforGrid5=choiceSlforGrid5+1;
		       gid('MF:txtChoiceSlSplRecev').value=choiceSlforGrid5;
   			   gid('MF:txtApplInsOrReplSplRecev').value="";
	  return;
	}
	
	function CopyText5()
	{
			gid('MF:txtApplInsOrReplSplRecev').value=grid5SelectedValue;
	}
   //ADDED BY PRASHANTH ON 20 FEB 2019
	
	function validateDesGood1()
{
	var _desgoodcount1 = gid('MF:txtDesGood1').value;
	var splitResults1 = _desgoodcount1.split("\n").length;
	
	
	if(gid('MF:chkChgDesc').checked==true)
	{
	  if(_desgoodcount1=="")
	  {
	  		setMsg(BLANK_CHECK);
			gid("MF:txtDesGood1").focus();
			return;
	  }
	}
	else{
	if(_desgoodcount1!="")
	  {
	  		setMsg("Cannot Be Entered When a) Change in Description of Goods and / or Services is not Checked!!");
			gid("MF:txtDesGood1").focus();
			return;
	  }
	}
	
	
	
	if(_desgoodcount1.length == 6500 ||  splitResults1 == 100 )
	{
		gid('MF:txtDesGood2').readOnly = false;
		gid('MF:txtDesGood3').readOnly = true;
		gid('MF:txtDesGood3').value = "";
		setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent4");
		focusTextArea('MF:txtDesGood2') ;
	}
	else if(_desgoodcount1.length < 6500 && splitResults1 < 100)
	{
		gid('MF:txtDesGood2').readOnly = true;
		gid('MF:txtDesGood3').readOnly = true;
		gid('MF:txtDesGood2').value = "";
		gid('MF:txtDesGood3').value = "";
		setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent5");
		focusTextArea('MF:txtDocRequired1') ;
	}
	else if(_desgoodcount1.length > 6500 ||  splitResults1 > 100 )
	{
		setMsg("The Line entered exceeded 6500 character typed " + _desgoodcount1.length + " lines" + splitResults1 );
		gid('MF:txtDesGood1').focus();
		return false;
	}
	
}
function validateDesGood2()
{
	var _desgoodcount2 = gid('MF:txtDesGood2').value;
	var splitResults2 = _desgoodcount2.split("\n").length;
	
	
	if(_desgoodcount2.length == 6500 ||  splitResults2 == 100)
	{
		gid('MF:txtDesGood3').readOnly = false;
		setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent4");
		focusTextArea('MF:txtDesGood3') ;
	}
	else if(_desgoodcount2.length < 6500 && splitResults2 < 100)
	{
		gid('MF:txtDesGood3').readOnly = true;
		gid('MF:txtDesGood3').value = "";
		setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent5");
		focusTextArea('MF:txtDocRequired1') ;
	}
	else if(_desgoodcount2.length > 6500 ||  splitResults2 > 100)
	{
		setMsg("The Line entered exceeded 6500 character typed " + _desgoodcount2.length + " lines" + splitResults2 );
		gid('MF:txtDesGood2').focus();
		return false;
	}
}
function validateDesGood3()
{
	var _desgoodcount3 = gid('MF:txtDesGood3').value;
	var splitResults3 = _desgoodcount3.split("\n").length;
	
	if(_desgoodcount3.length <= 6500 ||  splitResults3 == 100)
	{
		setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent5");
		focusTextArea('MF:txtDocRequired1') ;
	}
	else if(_desgoodcount3.length > 6500 ||  splitResults3 > 100)
	{
		setMsg("The Line entered exceeded 6500 character typed " + _desgoodcount3.length + " lines" + splitResults3);
		gid('MF:txtDesGood3').focus();
		return false;
	}
}





function validateDocRequired1()
{
	var _DocRequired1 = gid('MF:txtDocRequired1').value;
	var splitResults4 = _DocRequired1.split("\n").length;
	
	
	if(gid('MF:chkChgDoc').checked==true)
	{
	  if(_DocRequired1=="")
	  {
	  		setMsg(BLANK_CHECK);
			gid("MF:txtDocRequired1").focus();
			return;
	  }
	}
	else{
	if(_DocRequired1!="")
	  {
	  		setMsg("Cannot Be Entered When Change in Documents not Checked!!");
			gid("MF:txtDocRequired1").focus();
			return;
	  }
	}
	
	
	
	if(_DocRequired1.length == 6500 ||  splitResults4 == 100)
	{
		gid('MF:txtDocRequired2').readOnly = false;
		gid('MF:txtDocRequired3').readOnly = true;
		gid('MF:txtDocRequired3').value ="";
		setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent5");
		focusTextArea('MF:txtDocRequired2') ;
	}
	else if(_DocRequired1.length < 6500 && splitResults4 < 100)
	{
		gid('MF:txtDocRequired2').readOnly = true;
		gid('MF:txtDocRequired3').readOnly = true;
		gid('MF:txtDocRequired2').value ="";
		gid('MF:txtDocRequired3').value ="";
		setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent6");
		focusTextArea('MF:txtAddCond1') ;
	}
	else if(_DocRequired1.length > 6500 || splitResults4 >  100)
	{
		setMsg("The Line entered exceeded 6500 character typed " + _DocRequired1.length + " lines" + splitResults4);
		gid('MF:txtDocRequired1').focus();
		return false;
	}
	
}
function validateDocRequired2()
{
	var _DocRequired2 = gid('MF:txtDocRequired2').value;
	var splitResults5 = _DocRequired2.split("\n").length;
	
	if(_DocRequired2.length == 6500 ||  splitResults5 == 100)
	{
		gid('MF:txtDocRequired3').readOnly = false;
		setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent5");
		focusTextArea('MF:txtDocRequired3')
	}
	else if(_DocRequired2.length < 6500 && splitResults5 < 100)
	{
		gid('MF:txtDocRequired3').readOnly = true;
		gid('MF:txtDocRequired3').value ="";
		setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent6");
		focusTextArea('MF:txtAddCond1') ;
	}
	else if(_DocRequired2.length > 6500 || splitResults5 > 100)
	{
		setMsg("The Line entered exceeded 6500 character typed " + _DocRequired2.length + " lines" + splitResults5);
		gid('MF:txtDocRequired2').focus();
		return false;
	}
}
function validateDocRequired3()
{
	var _DocRequired3 = gid('MF:txtDocRequired3').value;
	var splitResults6 = _DocRequired3.split("\n").length;
	
	if(_DocRequired3.length <= 6500 ||  splitResults6 == 100 )
	{
		setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent6");
		focusTextArea('MF:txtAddCond1');
	}
	else if(_DocRequired3.length > 6500 || splitResults6 > 100)
	{
		setMsg("The Line entered exceeded 6500 character typed " + _DocRequired3.length + " lines" + splitResults6);
		gid('MF:txtDocRequired3').focus();
		return false;
	}
}

function validateAddCond1()
{
	var _AddCond1 = gid('MF:txtAddCond1').value;
	var splitResults7 = _AddCond1.split("\n").length;
	
	
	if(gid('MF:chkChgAddCond').checked==true)
	{
	  if(_AddCond1=="")
	  {
	  		setMsg(BLANK_CHECK);
			gid("MF:txtAddCond1").focus();
			return;
	  }
	}
	else{
	if(_AddCond1!="")
	  {
	  		setMsg("Cannot Be Entered When Change in Additional Conditions!!");
			gid("MF:txtAddCond1").focus();
			return;
	  }
	}
	
	
	if(_AddCond1.length == 6500 ||  splitResults7 == 100)
	{
		gid('MF:txtAddCond2').readOnly = false;
		gid('MF:txtAddCond3').readOnly = true;
		gid('MF:txtAddCond3').value ="";
		setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent6");
		focusTextArea('MF:txtAddCond2') ;
	}
	else if(_AddCond1.length < 6500 && splitResults7 < 100)
	{
		gid('MF:txtAddCond2').readOnly = true;
		gid('MF:txtAddCond3').readOnly = true;
		gid('MF:txtAddCond2').value = "";
		gid('MF:txtAddCond3').value = "";
		setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent6");
		// focusTextArea('MF:txtCharge') ;//changed by prashanth
	  	gid('MF:Submit').focus();
	}
	else if(_AddCond1.length > 6500 || splitResults7 > 100)
	{
		setMsg("The Line entered exceeded 6500 character typed " + _AddCond1.length + " lines" + splitResults7);
		gid('MF:txtAddCond1').focus();
		return false;
	}
}
function validateAddCond2()
{
	var _AddCond2 = gid('MF:txtAddCond2').value;
	var splitResults8 = _AddCond2.split("\n").length;
	
	if(_AddCond2.length == 6500 ||  splitResults8 == 100)
	{
		gid('MF:txtAddCond3').readOnly = false;
		setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent6");
		focusTextArea('MF:txtAddCond3') ;
	}
	else if(_AddCond2.length < 6500 && splitResults8 < 100)
	{
		gid('MF:txtAddCond3').readOnly = true;
		gid('MF:txtAddCond3').value = "";
		setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent6");
		// focusTextArea('MF:txtCharge') ;changed by prashanth
			  	gid('MF:Submit').focus();
	}
	else if(_AddCond2.length > 6500 || splitResults8 > 100)
	{
		setMsg("The Line entered exceeded 6500 character typed " + _AddCond2.length + " lines" + splitResults8);
		gid('MF:txtAddCond2').focus();
		return false;
	}
}
function validateAddCond3()
{
	var _AddCond3 = gid('MF:txtDocRequired3').value;
	var splitResults9 = _AddCond3.split("\n").length;
	
	if(_AddCond3.length <= 6500 ||  splitResults9 <= 100)
	{
		setTabfocus("maintab","tcontent10");setTabfocus("subtab","tsubcontent6");
		// focusTextArea('MF:txtCharge') ;
		gid('MF:Submit').focus();
	}
	else if(_AddCond3.length > 6500 || splitResults9 > 100)
	{
		setMsg("The Line entered exceeded 6500 character typed" + _AddCond3.length + " lines" + splitResults9);
		gid('MF:txtAddCond3').focus();
		return false;
	}
}




function validateInstructPay()
{

	setTabfocus("maintab","tcontent10");
	
	
	if(gid('MF:chkCgAdvBk').checked==true)
			{
			setTabfocus("maintab","tcontent10");
			setTabfocus("subtab","tsubcontent11");
			gid('MF:chkAdvise').focus();
						return;
			}
			else{
			setTabfocus("maintab","tcontent10");
			setTabfocus("subtab","tsubcontent12");
			gid('MF:txtfrmRangeSplBene').focus();
						return;
			}
}




	// ADDED BY PRASHANTH ON 06 FEB 2019
	
	function chkbenficiary()
	{
		if(gid("MF:chkChangeofBeneficiary").checked==true)
   		{
     		gid("MF:outlblChangeofBeneficiary").innerText="Yes";
     		gid("MF:txtBeneficiaryCode").disabled=false; 
			gid("MF:txtBeneficiaryName").disabled=false; 
			gid("MF:txtAddress1").disabled=false; 
			gid("MF:txtBeneficiaryCountryCode").disabled=false; 
     	}
	  	else
	   	{
		    gid("MF:outlblChangeofBeneficiary").innerText="No";
		    gid("MF:txtBeneficiaryCode").disabled=true; 
			gid("MF:txtBeneficiaryName").disabled=true; 
			gid("MF:txtAddress1").disabled=true; 
			gid("MF:txtBeneficiaryCountryCode").disabled=true; 
			
			if(newbenef == "0")
			{
			gid("MF:txtBeneficiaryCode").value="";
			gid("MF:txtBeneficiaryName").value="";
			gid("MF:txtAddress1").value="";
			gid("MF:txtBeneficiaryCountryCode").value="";
			gid("MF:outputlblBeneficiaryCountryCode").innerText="";
			}
		}
		
		/*if(gid('MF:seluseroption').value=="A")
		{
			gid("MF:txtBeneficiaryCode").value="";
			gid("MF:txtBeneficiaryName").value="";
			gid("MF:txtAddress1").value="";
			gid("MF:txtBeneficiaryCountryCode").value="";
			gid("MF:outputlblBeneficiaryCountryCode").innerText="";
		}*/
	
	}
	
	function validatechkExpiryDate()
	{
		checkExpiryDate();
		gid('MF:chkIncDec').focus();
	}
	
	function validatechkIncDec()
	{
		checkIncrDecr();
		gid('MF:chkPerTolr').focus();
	}
	
	function validatechkPerTolr()
	{
		checkPerTolr();
		if(gid('MF:txtReferenceType').value=='LC')
      		gid('MF:chkShipPeriod').focus();
		else
			gid('MF:chkPlacePort').focus();
	}
	
	function validatechkPlacePort()
	{
		checkPlacePort();
		gid('MF:chkShipPeriod').focus();
	}
	
	function validatechkShipPeriod()
	{
		checkShipPeriod();
		gid('MF:chkChangeofBeneficiary').focus();
	}
	
	function disableswiftbox()
	{
	 	gid('MF:txtLastDateforNegotiation').disabled=true;
		gid('MF:txtEnhancementReductionAmount1').disabled=true;
		gid('MF:txtDeviationAllowed').disabled=true;
		gid('MF:txtDeviationAllowed1').disabled=true;
		gid('MF:txtDeviationAmount').disabled=true;
		gid('MF:txtTakCharge').disabled=true;
		gid('MF:txtPortLoad').disabled=true;
		gid('MF:txtPortDis').disabled=true;
		gid('MF:txtPortDest').disabled=true;
		gid('MF:txtLatestDateofShipment').disabled=true; 
	    gid('MF:txtShipmentPeriodSchedule').disabled=true;
		gid("MF:txtBeneficiaryCode").disabled=true; 
		gid("MF:txtBeneficiaryName").disabled=true; 
		gid("MF:txtAddress1").disabled=true; 
		gid("MF:txtBeneficiaryCountryCode").disabled=true; 
	}
	
	function enableswiftbox()
	{
		gid('MF:txtLastDateforNegotiation').disabled=false;
		gid('MF:txtEnhancementReductionAmount1').disabled=false;
		gid('MF:txtDeviationAllowed').disabled=false;
		gid('MF:txtDeviationAllowed1').disabled=false;
		gid('MF:txtDeviationAmount').disabled=false;
		gid('MF:txtTakCharge').disabled=false;
		gid('MF:txtPortLoad').disabled=false;
		gid('MF:txtPortDis').disabled=false;
		gid('MF:txtPortDest').disabled=false;
		gid('MF:txtLatestDateofShipment').disabled=false; 
	    gid('MF:txtShipmentPeriodSchedule').disabled=false;
		gid("MF:txtBeneficiaryCode").disabled=false; 
		gid("MF:txtBeneficiaryName").disabled=false; 
		gid("MF:txtAddress1").disabled=false; 
		gid("MF:txtBeneficiaryCountryCode").disabled=false;
	}
	
	function textboxfocus()
	{
		  setTabfocus("maintab","tcontent3");
		  if(gid('MF:txtDeviationAmount').disabled == false )
   			{
		 		gid("MF:txtDeviationAmount").focus();	
			}
			else if(gid('MF:txtDeviationAllowed1').disabled == false )
			{
				gid("MF:txtDeviationAllowed1").focus();
			}
			else if(gid('MF:txtDeviationAllowed').disabled == false )
			{
				gid("MF:txtDeviationAllowed").focus();
			}
			else if(gid('MF:txtEnhancementReductionAmount').disabled == false )
			{
				gid("MF:txtEnhancementReductionAmount").focus();
			}
			else if(gid('MF:txtLCEnhancementReductionNochange').disabled == false )
			{
				gid("MF:txtLCEnhancementReductionNochange").focus();
			}
			else if(gid('MF:txtBeneficiaryCountryCode').disabled == false )
			{
				setTabfocus("maintab","tcontent2");
				gid("MF:txtBeneficiaryCountryCode").focus();
			}
	}
	
	
	
	function clearIssueBic()
	{
		gid('MF:txtIssueBicCode').value="";
		gid('MF:txtIssueBicBank').value="";
		gid('MF:txtIssueBicBrn').value="";
	}
	
	function clearIssueAddr()
	{
		gid('MF:txtIssueBankName').value="";
		gid('MF:txtIssueAcnt').value="";
		gid('MF:txtIssueAddress').value="";
		gid('MF:txtIssueCntry').value="";
	}
	
	function IssueBicList()
	{
		if(trim(gid('MF:lstIssueBICdtl').value) == "")
	  	{   
	  		clearIssueBic();
			clearIssueAddr();
	  		document.getElementById('ISSBANKNAMEADDR').style.display = 'none';
			document.getElementById('ISSBANKBIC').style.display = 'block';
		}
	 	else if(trim(gid('MF:lstIssueBICdtl').value) == "1")
	 	{
	 		clearIssueAddr();
	 		document.getElementById('ISSBANKNAMEADDR').style.display = 'none';
	 		document.getElementById('ISSBANKBIC').style.display = 'block';
	 	}
	 	else if(trim(gid('MF:lstIssueBICdtl').value) == "2")
	 	{
	 		clearIssueBic();
	 		document.getElementById('ISSBANKNAMEADDR').style.display = 'block';
	 		document.getElementById('ISSBANKBIC').style.display = 'none';
	 	}
	}

//ADDED ON 16/10/2018 END




   		//added by prashanth
   	function ClobChangeEvents(fldobj)
	{
	    switch(fldobj.name)
		   	  {
		   	  	  
			case "MF:txtDesGood1"	:
										var _good1 = gid('MF:txtDesGood1').value;
										
										var splitResults10 = _good1.split("\n").length;
										setMsg("Characters entered " + _good1.length + "Line Entered " +splitResults10);
										if(_good1.length == 6500 || splitResults10 == 100) 
										{
											gid('MF:txtDesGood2').readOnly = false;
											gid('MF:txtDesGood3').readOnly = true;
											gid('MF:txtDesGood3').value = ""; 
											setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent3");
											focusTextArea('MF:txtDesGood2') ;
										}
										else
										{
											gid('MF:txtDesGood2').readOnly = true;
											gid('MF:txtDesGood3').readOnly = true;
											gid('MF:txtDesGood2').value = "";
											gid('MF:txtDesGood3').value = "";
										}
										break;
										
			case "MF:txtDesGood2"	:	
										var _good2 = gid('MF:txtDesGood2').value;
										
										var splitResults11 = _good2.split("\n").length;
										setMsg("Characters entered " + _good2.length + "Line Entered " +splitResults11);
										if(_good2.length == 6500 || splitResults11 == 100) 
										{
											gid('MF:txtDesGood3').readOnly = false;
											setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent3");
											focusTextArea('MF:txtDesGood3') ;
										}
										else
										{
											gid('MF:txtDesGood3').readOnly = true;
											gid('MF:txtDesGood3').value = "";
										}
										break;															  					
  			
  			case "MF:txtDocRequired1"	:
  										var _doc1 = gid('MF:txtDocRequired1').value;										
  										var splitResults12 = _doc1.split("\n").length;
  										setMsg("Characters entered " + _doc1.length + "Line Entered " +splitResults12);
  										
  										if(_doc1.length == 6500 || splitResults12 == 100) 
										{
											gid('MF:txtDocRequired2').readOnly = false;
											gid('MF:txtDocRequired3').readOnly = true;
											gid('MF:txtDocRequired3').value ="";
											setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent4");
											focusTextArea('MF:txtDocRequired2') ;
											
										}
										else
										{
											gid('MF:txtDocRequired2').readOnly = true;
											gid('MF:txtDocRequired3').readOnly = true;
											gid('MF:txtDocRequired2').value ="";
											gid('MF:txtDocRequired3').value ="";
										}
										break;
										
  			case "MF:txtDocRequired2"	:
									  	var _doc2 = gid('MF:txtDocRequired2').value;
									  	var splitResults13 = _doc2.split("\n").length;
									  	setMsg("Characters entered " + _doc2.length + "Line Entered " +splitResults13);
									  	
  										if(_doc2.length == 6500 || splitResults13 == 100) 
										{
											gid('MF:txtDocRequired3').readOnly = false;
											setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent4");
											focusTextArea('MF:txtDocRequired3') ;
										}
										else
										{
											gid('MF:txtDocRequired3').readOnly = true;
											gid('MF:txtDocRequired3').value ="";
										}
  										break;
  										
  			case "MF:txtAddCond1" 		:
									  	var _add1 = gid('MF:txtAddCond1').value;
									  	var splitResults14 = _add1.split("\n").length;
									  	setMsg("Characters entered " + _add1.length + "Line Entered " +splitResults14);
									  	
  										if(_add1.length == 6500 || splitResults14 == 100) 
										{
											gid('MF:txtAddCond2').readOnly = false;
											gid('MF:txtAddCond3').readOnly = true;
											gid('MF:txtAddCond3').value ="";
											setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent5");
											focusTextArea('MF:txtAddCond2') ;
										}
										else
										{
											gid('MF:txtAddCond2').readOnly = true;
											gid('MF:txtAddCond3').readOnly = true;
											gid('MF:txtAddCond2').value = "";
											gid('MF:txtAddCond3').value = "";
										}
  											break;
  											
  			case "MF:txtAddCond2" 		:
  										var _add2 = gid('MF:txtAddCond2').value;
  										var splitResults15 = _add2.split("\n").length;
  										setMsg("Characters entered " + _add2.length + "Line Entered " +splitResults15);
  										
  										if(_add2.length == 6500 || splitResults15 == 100) 
										{
											gid('MF:txtAddCond3').readOnly = false;
											setTabfocus("maintab","tcontent9");setTabfocus("subtab","tsubcontent5");
											focusTextArea('MF:txtAddCond3') ;
										}
										else
										{
											gid('MF:txtAddCond3').readOnly = true;
											gid('MF:txtAddCond3').value = "";
										}
  											break;	
  	    	}
   		} 
   		
   		
        //ADDED BY PRASHANTH
        
        function checkOldValueGoods()
        {
	        //Changes Sanjay 02-07-2019 Begin
			var currentcheckbox=gid("MF:chkChgDesc").checked;
			var oldcheckbox=oldchkChgDesc;
			if(currentcheckbox!=oldcheckbox)
			{
			//Changes Sanjay 02-07-2019 End
	            if(gid('MF:chkChgDesc').checked==true)
				{
				  if(oldAmdLogValueGoods==gid('MF:txtAmdLog').value)
				  {
				  	setMsg("Goods Should be changed when Change in Description of Goods and / or Services is checked");
				  	gid("MF:txtApplInsOrRepl").focus();
				  	return false;
				  }
				}
			}
			return true;
        }
        function checkOldValueDocs()
        {
        	//Changes Sanjay 02-07-2019 Begin
			var currentcheckbox=gid("MF:chkChgDoc").checked;
			var oldcheckbox=oldchkChgDoc;
			if(currentcheckbox!=oldcheckbox)
			{
			//Changes Sanjay 02-07-2019 End
	       		 if(gid('MF:chkChgDoc').checked==true)
				{
				  if(oldAmdLogValueDocs==gid('MF:txtAmdLogDoc').value)
				  {
				  setMsg("Documents  Should be changed when Change in Documents is checked");
				  gid("MF:txtApplInsOrReplDoc").focus();
				  return;
				  }
				}
			}
          return true;
        }
        function checkOldValueAddl()
        {
        	//Changes Sanjay 02-07-2019 Begin
			var currentcheckbox=gid("MF:chkChgAddCond").checked;
			var oldcheckbox=oldchkChgAddCond;
			if(currentcheckbox!=oldcheckbox)
			{
			//Changes Sanjay 02-07-2019 End
	        	if(gid('MF:chkChgAddCond').checked==true)
				{
					if(oldAmdLogValueAddl==gid('MF:txtAmdLogAddl').value)
				    {
				 	 setMsg("Additional Conditions  Should be changed when Change in Additional Conditions is checked");
				 	 gid("MF:txtApplInsOrReplAddl").focus();
				  	 return false;
					}
				}
			}
			 return true;
        }
   		function revalidateDuplicate(){
	   		  if(!checkOldValueExpiryDate())
	   		  {
	   		   return false;
	   		  }
	   		  if(!checkOldValueIncreaseDecDC())
	   		  {
	   		   return false;
	   		  }
	   		  if(!checkMaxCredit())
	   		  {
	   		   return false;
	   		  }
	   		  if(!checkShipPeriodDup())
	   		  {
	   		   return false;
	   		  }
	   		  if(!checkOldValuBen())
	   		  {
	   		   return false;
	   		  }
	   		  if(!checkOldValuApplicant())
	   		  {
	   		   return false;
	   		  }
	   		  if(!checkOldValueFormOfDC())
	   		  {
	   		   return false;
	   		  }
	   		  if(!checkOldValueGoods())
	   		  {
	   		   return false;
	   		  }
	   		  if(!checkOldValueDocs())
	   		  {
	   		   return false;
	   		  }
	   		  if(!checkOldValueAddl())
	   		  {
	   		   return false;
	   		  }
	   		  if(!checkOldValueApplRules())
	   		  {
	   		   return false;
	   		  }
	   		  if(!checkOldValueAvailable())
	   		  {
	   		   return false;
	   		  }
	   		  if(!checkOldValueDrawee())
	   		  {
	   		   return false;
	   		  }
	   		  if(!checkOldValueReimbursement())
	   		  {
	   		   return false;
	   		  }
	   		  if(!checkOldValueAdvise())
	   		  {
	   		   return false;
	   		  }
	   		  submitForm();
   		  return true;
   		}
   		//ADDED BY PRASHANTH
   		
   		//added by prashanth
//-----------------------------------------------------------------------------------------------------------------------------		 	
