package panacea.OLC.Update;

import java.util.Vector;
import java.sql.*;
import panacea.common.JNDINames;
import java.util.LinkedHashMap;
import panacea.Manager.Manager;

/******************SQL2JAVA_IMPORT_BEGIN******************/

/******************SQL2JAVA_IMPORT_END********************/


public class AmendDetailsManager extends Manager
/******************SQL2JAVA_EXTENDS_BEGIN******************/

/******************SQL2JAVA_EXTENDS_END********************/

{

/******************SQL2JAVA_CLASS_BEGIN******************/

/******************SQL2JAVA_CLASS_END********************/


    public static final int AMEND_LC_BRN_CODE = 0;
    public static final int AMEND_LC_TYPE = 1;
    public static final int AMEND_LC_YEAR = 2;
    public static final int AMEND_LC_SERIAL = 3;
    public static final int AMEND_LC_AMD_SL = 4;
    public static final int AMEND_SNDR_REF = 5;
    public static final int AMEND_RCVR_REF = 6;
    public static final int AMEND_DOC_CR_NUM = 7;
    public static final int AMEND_ISSUING_BNK_REQ = 8;
    public static final int AMEND_ISSUING_TYPE = 9;
    public static final int AMEND_ISSUING_BRN_CODE = 10;
    public static final int AMEND_ISSUING_BIC_CODE = 11;
    public static final int AMEND_ISSUING_ROUTID = 12;
    public static final int AMEND_ISSUING_BNK_CODE = 13;
    public static final int AMEND_ISSUING_ADDR1 = 14;
    public static final int AMEND_ISSUING_ADDR2 = 15;
    public static final int AMEND_ISSUING_ADDR3 = 16;
    public static final int AMEND_ISSUING_ADDR4 = 17;
    public static final int AMEND_ISSUING_ADDR5 = 18;
    public static final int AMEND_NON_BNK_ISSUR = 19;
    public static final int AMEND_DATE_OF_ISSUE = 20;
    public static final int AMEND_DATE_OF_AMENDMENT = 21;
    public static final int AMEND_PURPOSE_OF_MSG = 22;
    public static final int AMEND_CANCEL_REQUEST = 23;
    public static final int AMEND_ADVISING_BNK_REQ = 24;
    public static final int AMEND_ADVISING_BNK_TYPE = 25;
    public static final int AMEND_ADVISING_BRN_CODE = 26;
    public static final int AMEND_ADVISING_BIC_CODE = 27;
    public static final int AMEND_ADVISING_ROUTID = 28;
    public static final int AMEND_ADVISING_BNK_CODE = 29;
    public static final int AMEND_ADVISING_ADDR1 = 30;
    public static final int AMEND_ADVISING_ADDR2 = 31;
    public static final int AMEND_ADVISING_ADDR3 = 32;
    public static final int AMEND_ADVISING_ADDR4 = 33;
    public static final int AMEND_ADVISING_ADDR5 = 34;
    public static final int AMEND_SECOND_ADV_REQ = 35;
    public static final int AMEND_SECOND_ADV_TYPE = 36;
    public static final int AMEND_SECOND_ADV_BRN_CODE = 37;
    public static final int AMEND_SECOND_ADV_BIC_CODE = 38;
    public static final int AMEND_SECOND_ADV_ROUTID = 39;
    public static final int AMEND_SECOND_ADV_BNK_CODE = 40;
    public static final int AMEND_SECOND_ADV_ADDR1 = 41;
    public static final int AMEND_SECOND_ADV_ADDR2 = 42;
    public static final int AMEND_SECOND_ADV_ADDR3 = 43;
    public static final int AMEND_SECOND_ADV_ADDR4 = 44;
    public static final int AMEND_SECOND_ADV_ADDR5 = 45;
    public static final int AMEND_NEW_BENEFICIARY = 46;
    public static final int AMEND_NEW_DATE_OF_EXPIRY = 47;
    public static final int AMEND_INCR_DOC_CR_AMT = 48;
    public static final int AMEND_DECR_DOC_CR_AMT = 49;
    public static final int AMEND_NEW_ADDNL_AMT = 50;
    public static final int AMEND_PLACE_TAKIN_IN_CHRG = 51;
    public static final int AMEND_PORT_OF_LOADING = 52;
    public static final int AMEND_PORT_OF_DISCHARGE = 53;
    public static final int AMEND_PLACE_OF_FINAL_DEST = 54;
    public static final int AMEND_DATE_OF_SHIPMENT = 55;
    public static final int AMEND_DESC_GODD_SER1 = 56;
    public static final int AMEND_DOC_REQ1 = 57;
    public static final int AMEND_ADD_CONDITION1 = 58;
    public static final int AMEND_CHRG_PAYABLE1 = 59;
    public static final int AMEND_CHRG_PAYABLE2 = 60;
    public static final int AMEND_CHRG_PAYABLE3 = 61;
    public static final int AMEND_CHRG_PAYABLE4 = 62;
    public static final int AMEND_CHRG_PAYABLE5 = 63;
    public static final int AMEND_CHRG_PAYABLE6 = 64;
    public static final int AMEND_SNDR_REC_INFO1 = 65;
    public static final int AMEND_SNDR_REC_INFO2 = 66;
    public static final int AMEND_SNDR_REC_INFO3 = 67;
    public static final int AMEND_SNDR_REC_INFO4 = 68;
    public static final int AMEND_SNDR_REC_INFO5 = 69;
    public static final int AMEND_SNDR_REC_INFO6 = 70;
    public static final int AMEND_CHKBOX = 71;
    public static final int AMEND_ISSUING_CNTRY = 72;
    public static final int AMEND_ADVISING_CNTRY = 73;
    public static final int AMEND_SECOND_ADV_CNTRY = 74;
    public static final int AMEND_ISSUE_REF = 75;
    public static final int AMEND_FORM_OF_DOC_CREDIT = 76;
    public static final int AMEND_LC_APPLICABLE_RULES = 77;
    public static final int AMEND_LC_APPLICANT_REQ = 78;
    public static final int AMEND_LC_APPLICANT_NAME = 79;
    public static final int AMEND_LC_APPLICANT_ADDR1 = 80;
    public static final int AMEND_LC_APPLICANT_ADDR2 = 81;
    public static final int AMEND_LC_APPLICANT_ADDR3 = 82;
    public static final int AMEND_LC_APPLICANT_ADDR4 = 83;
    public static final int AMEND_LC_APPLICANT_ADDR5 = 84;
    public static final int AMEND_LC_AVL_WITH_TYPE = 85;
    public static final int AMEND_LC_AVL_WITH_BRN_CODE = 86;
    public static final int AMEND_LC_AVL_WITH_BIC_CODE = 87;
    public static final int AMEND_LC_LC_AVL_WITH_ROUTID = 88;
    public static final int AMEND_LC_AVL_WITH_BNK_CODE = 89;
    public static final int AMEND_LC_AVL_WITH_ADDR1 = 90;
    public static final int AMEND_LC_AVL_WITH_ADDR2 = 91;
    public static final int AMEND_LC_AVL_WITH_ADDR3 = 92;
    public static final int AMEND_LC_AVL_WITH_ADDR4 = 93;
    public static final int AMEND_LC_AVL_WITH_ADDR5 = 94;
    public static final int AMEND_LC_AVL_WITH_CNTRY = 95;
    public static final int AMEND_LC_DRAFTS_AT1 = 96;
    public static final int AMEND_LC_DRAFTS_AT2 = 97;
    public static final int AMEND_LC_DRAFTS_AT3 = 98;
    public static final int AMEND_LC_DRAWEE_REQ = 99;
    public static final int AMEND_LC_DRAWEE_TYPE = 100;
    public static final int AMEND_LC_DRAWEE_BRN_CODE = 101;
    public static final int AMEND_LC_DRAWEE_BIC_CODE = 102;
    public static final int AMEND_LC_DRAWEE_ROUTID = 103;
    public static final int AMEND_LC_DRAWEE_BNK_CODE = 104;
    public static final int AMEND_LC_DRAWEE_ADDR1 = 105;
    public static final int AMEND_LC_DRAWEE_ADDR2 = 106;
    public static final int AMEND_LC_DRAWEE_ADDR3 = 107;
    public static final int AMEND_LC_DRAWEE_ADDR4 = 108;
    public static final int AMEND_LC_DRAWEE_ADDR5 = 109;
    public static final int AMEND_DRAWEE_CNTRY_CODE = 110;
    public static final int AMEND_LC_MIXED_PAY_DETAILS1 = 111;
    public static final int AMEND_LC_MIXED_PAY_DETAILS2 = 112;
    public static final int AMEND_LC_MIXED_PAY_DETAILS3 = 113;
    public static final int AMEND_LC_MIXED_PAY_DETAILS4 = 114;
    public static final int AMEND_LC_MIXED_PAY_DETAILS5 = 115;
    public static final int AMEND_LC_DEFERRED_PAY_DETAILS1 = 116;
    public static final int AMEND_LC_DEFERRED_PAY_DETAILS2 = 117;
    public static final int AMEND_LC_DEFERRED_PAY_DETAILS3 = 118;
    public static final int AMEND_LC_DEFERRED_PAY_DETAILS4 = 119;
    public static final int AMEND_LC_DEFERRED_PAY_DETAILS5 = 120;
    public static final int AMEND_LC_PARTIAL_SHIPMENTS = 121;
    public static final int AMEND_LC_TRANSHIPMENT = 122;
    public static final int AMEND_LC_CONFIRMATION_INST = 123;
    public static final int AMEND_LC_REIMB_REQ = 124;
    public static final int AMEND_LC_REIMB_TYPE = 125;
    public static final int AMEND_LC_REIMB_BRN_CODE = 126;
    public static final int AMEND_LC_REIMB_BIC_CODE = 127;
    public static final int AMEND_LC_REIMB_ROUTID = 128;
    public static final int AMEND_LC_REIMB_BNK_CODE = 129;
    public static final int AMEND_LC_REIMB_ADDR1 = 130;
    public static final int AMEND_LC_REIMB_ADDR2 = 131;
    public static final int AMEND_LC_REIMB_ADDR3 = 132;
    public static final int AMEND_LC_REIMB_ADDR4 = 133;
    public static final int AMEND_LC_REIMB_ADDR5 = 134;
    public static final int AMEND_LC_INST_PAYING1 = 135;
    public static final int AMEND_LC_INST_PAYING2 = 136;
    public static final int AMEND_LC_INST_PAYING3 = 137;
    public static final int AMEND_LC_INST_PAYING4 = 138;
    public static final int AMEND_LC_INST_PAYING5 = 139;
    public static final int AMEND_LC_INST_PAYING6 = 140;
    public static final int AMEND_LC_INST_PAYING7 = 141;
    public static final int AMEND_LC_INST_PAYING8 = 142;
    public static final int AMEND_LC_INST_PAYING9 = 143;
    public static final int AMEND_LC_INST_PAYING10 = 144;
    public static final int AMEND_LC_INST_PAYING11 = 145;
    public static final int AMEND_LC_INST_PAYING12 = 146;
    public static final int AMEND_LC_SECOND_ADV_REQ = 147;
    public static final int AMEND_LC_SECOND_ADV_TYPE = 148;
    public static final int AMEND_LC_SECOND_ADV_BRN_CODE = 149;
    public static final int AMEND_LC_SECOND_ADV_BIC_CODE = 150;
    public static final int AMEND_LC_SECOND_ADV_ROUTID = 151;
    public static final int AMEND_LC_SECOND_ADV_BNK_CODE = 152;
    public static final int AMEND_LC_SECOND_ADV_ADDR1 = 153;
    public static final int AMEND_LC_SECOND_ADV_ADDR2 = 154;
    public static final int AMEND_LC_SECOND_ADV_ADDR3 = 155;
    public static final int AMEND_LC_SECOND_ADV_ADDR4 = 156;
    public static final int AMEND_LC_SECOND_ADV_ADDR5 = 157;
    public static final int AMEND_LC_SECOND_ADV_CNTRYCODE = 158;
    public static final int AMEND_LC_AVL_WITH_CODETYP = 159;
    public static final int AMEND_LC_REIMB_CNTRY_CODE = 160;
    public static final int AMEND_LC_CNF_ADV_TYPE = 161;
    public static final int AMEND_LC_CNF_ADV_BRN_CODE = 162;
    public static final int AMEND_LC_CNF_ADV_BIC_CODE = 163;
    public static final int AMEND_LC_CNF_ADV_ROUTID = 164;
    public static final int AMEND_LC_CNF_ADV_BNK_CODE = 165;
    public static final int AMEND_LC_CNF_ADV_ADDR1 = 166;
    public static final int AMEND_LC_CNF_ADV_ADDR2 = 167;
    public static final int AMEND_LC_CNF_ADV_ADDR3 = 168;
    public static final int AMEND_LC_CNF_ADV_ADDR4 = 169;
    public static final int AMEND_LC_CNF_ADV_ADDR5 = 170;
    public static final int AMEND_LC_CNF_ADV_CNTRYCODE = 171;

    private String OldData_Key;
    private String NewData_Key;
    private String DataBlock_Old;
    private String DataBlock_New;
    private LinkedHashMap _COLLECTIONobj;
    private int _Logreq ;
    private int _Logaddreq ;
    public AmendDetailsManager(LinkedHashMap _COLLECTIONobj, int _Log_Req , int _Log_Add_Req ){
        //_COLLECTIONobjManager = _COLLECTIONobj;
        this._COLLECTIONobj 	= _COLLECTIONobj;
        this._Logreq 			= _Log_Req;
        this._Logaddreq 		= _Log_Add_Req;
        //set_pki_enabled(_COLLECTIONobj);
    }
    private static final String[] S2J_FIELD_NAMES = {
        "AMEND_DETAILS.AMEND_LC_BRN_CODE"
        ,"AMEND_DETAILS.AMEND_LC_TYPE"
        ,"AMEND_DETAILS.AMEND_LC_YEAR"
        ,"AMEND_DETAILS.AMEND_LC_SERIAL"
        ,"AMEND_DETAILS.AMEND_LC_AMD_SL"
        ,"AMEND_DETAILS.AMEND_SNDR_REF"
        ,"AMEND_DETAILS.AMEND_RCVR_REF"
        ,"AMEND_DETAILS.AMEND_DOC_CR_NUM"
        ,"AMEND_DETAILS.AMEND_ISSUING_BNK_REQ"
        ,"AMEND_DETAILS.AMEND_ISSUING_TYPE"
        ,"AMEND_DETAILS.AMEND_ISSUING_BRN_CODE"
        ,"AMEND_DETAILS.AMEND_ISSUING_BIC_CODE"
        ,"AMEND_DETAILS.AMEND_ISSUING_ROUTID"
        ,"AMEND_DETAILS.AMEND_ISSUING_BNK_CODE"
        ,"AMEND_DETAILS.AMEND_ISSUING_ADDR1"
        ,"AMEND_DETAILS.AMEND_ISSUING_ADDR2"
        ,"AMEND_DETAILS.AMEND_ISSUING_ADDR3"
        ,"AMEND_DETAILS.AMEND_ISSUING_ADDR4"
        ,"AMEND_DETAILS.AMEND_ISSUING_ADDR5"
        ,"AMEND_DETAILS.AMEND_NON_BNK_ISSUR"
        ,"AMEND_DETAILS.AMEND_DATE_OF_ISSUE"
        ,"AMEND_DETAILS.AMEND_DATE_OF_AMENDMENT"
        ,"AMEND_DETAILS.AMEND_PURPOSE_OF_MSG"
        ,"AMEND_DETAILS.AMEND_CANCEL_REQUEST"
        ,"AMEND_DETAILS.AMEND_ADVISING_BNK_REQ"
        ,"AMEND_DETAILS.AMEND_ADVISING_BNK_TYPE"
        ,"AMEND_DETAILS.AMEND_ADVISING_BRN_CODE"
        ,"AMEND_DETAILS.AMEND_ADVISING_BIC_CODE"
        ,"AMEND_DETAILS.AMEND_ADVISING_ROUTID"
        ,"AMEND_DETAILS.AMEND_ADVISING_BNK_CODE"
        ,"AMEND_DETAILS.AMEND_ADVISING_ADDR1"
        ,"AMEND_DETAILS.AMEND_ADVISING_ADDR2"
        ,"AMEND_DETAILS.AMEND_ADVISING_ADDR3"
        ,"AMEND_DETAILS.AMEND_ADVISING_ADDR4"
        ,"AMEND_DETAILS.AMEND_ADVISING_ADDR5"
        ,"AMEND_DETAILS.AMEND_SECOND_ADV_REQ"
        ,"AMEND_DETAILS.AMEND_SECOND_ADV_TYPE"
        ,"AMEND_DETAILS.AMEND_SECOND_ADV_BRN_CODE"
        ,"AMEND_DETAILS.AMEND_SECOND_ADV_BIC_CODE"
        ,"AMEND_DETAILS.AMEND_SECOND_ADV_ROUTID"
        ,"AMEND_DETAILS.AMEND_SECOND_ADV_BNK_CODE"
        ,"AMEND_DETAILS.AMEND_SECOND_ADV_ADDR1"
        ,"AMEND_DETAILS.AMEND_SECOND_ADV_ADDR2"
        ,"AMEND_DETAILS.AMEND_SECOND_ADV_ADDR3"
        ,"AMEND_DETAILS.AMEND_SECOND_ADV_ADDR4"
        ,"AMEND_DETAILS.AMEND_SECOND_ADV_ADDR5"
        ,"AMEND_DETAILS.AMEND_NEW_BENEFICIARY"
        ,"AMEND_DETAILS.AMEND_NEW_DATE_OF_EXPIRY"
        ,"AMEND_DETAILS.AMEND_INCR_DOC_CR_AMT"
        ,"AMEND_DETAILS.AMEND_DECR_DOC_CR_AMT"
        ,"AMEND_DETAILS.AMEND_NEW_ADDNL_AMT"
        ,"AMEND_DETAILS.AMEND_PLACE_TAKIN_IN_CHRG"
        ,"AMEND_DETAILS.AMEND_PORT_OF_LOADING"
        ,"AMEND_DETAILS.AMEND_PORT_OF_DISCHARGE"
        ,"AMEND_DETAILS.AMEND_PLACE_OF_FINAL_DEST"
        ,"AMEND_DETAILS.AMEND_DATE_OF_SHIPMENT"
        ,"AMEND_DETAILS.AMEND_DESC_GODD_SER1"
        ,"AMEND_DETAILS.AMEND_DOC_REQ1"
        ,"AMEND_DETAILS.AMEND_ADD_CONDITION1"
        ,"AMEND_DETAILS.AMEND_CHRG_PAYABLE1"
        ,"AMEND_DETAILS.AMEND_CHRG_PAYABLE2"
        ,"AMEND_DETAILS.AMEND_CHRG_PAYABLE3"
        ,"AMEND_DETAILS.AMEND_CHRG_PAYABLE4"
        ,"AMEND_DETAILS.AMEND_CHRG_PAYABLE5"
        ,"AMEND_DETAILS.AMEND_CHRG_PAYABLE6"
        ,"AMEND_DETAILS.AMEND_SNDR_REC_INFO1"
        ,"AMEND_DETAILS.AMEND_SNDR_REC_INFO2"
        ,"AMEND_DETAILS.AMEND_SNDR_REC_INFO3"
        ,"AMEND_DETAILS.AMEND_SNDR_REC_INFO4"
        ,"AMEND_DETAILS.AMEND_SNDR_REC_INFO5"
        ,"AMEND_DETAILS.AMEND_SNDR_REC_INFO6"
        ,"AMEND_DETAILS.AMEND_CHKBOX"
        ,"AMEND_DETAILS.AMEND_ISSUING_CNTRY"
        ,"AMEND_DETAILS.AMEND_ADVISING_CNTRY"
        ,"AMEND_DETAILS.AMEND_SECOND_ADV_CNTRY"
        ,"AMEND_DETAILS.AMEND_ISSUE_REF"
        ,"AMEND_DETAILS.AMEND_FORM_OF_DOC_CREDIT"
        ,"AMEND_DETAILS.AMEND_LC_APPLICABLE_RULES"
        ,"AMEND_DETAILS.AMEND_LC_APPLICANT_REQ"
        ,"AMEND_DETAILS.AMEND_LC_APPLICANT_NAME"
        ,"AMEND_DETAILS.AMEND_LC_APPLICANT_ADDR1"
        ,"AMEND_DETAILS.AMEND_LC_APPLICANT_ADDR2"
        ,"AMEND_DETAILS.AMEND_LC_APPLICANT_ADDR3"
        ,"AMEND_DETAILS.AMEND_LC_APPLICANT_ADDR4"
        ,"AMEND_DETAILS.AMEND_LC_APPLICANT_ADDR5"
        ,"AMEND_DETAILS.AMEND_LC_AVL_WITH_TYPE"
        ,"AMEND_DETAILS.AMEND_LC_AVL_WITH_BRN_CODE"
        ,"AMEND_DETAILS.AMEND_LC_AVL_WITH_BIC_CODE"
        ,"AMEND_DETAILS.AMEND_LC_LC_AVL_WITH_ROUTID"
        ,"AMEND_DETAILS.AMEND_LC_AVL_WITH_BNK_CODE"
        ,"AMEND_DETAILS.AMEND_LC_AVL_WITH_ADDR1"
        ,"AMEND_DETAILS.AMEND_LC_AVL_WITH_ADDR2"
        ,"AMEND_DETAILS.AMEND_LC_AVL_WITH_ADDR3"
        ,"AMEND_DETAILS.AMEND_LC_AVL_WITH_ADDR4"
        ,"AMEND_DETAILS.AMEND_LC_AVL_WITH_ADDR5"
        ,"AMEND_DETAILS.AMEND_LC_AVL_WITH_CNTRY"
        ,"AMEND_DETAILS.AMEND_LC_DRAFTS_AT1"
        ,"AMEND_DETAILS.AMEND_LC_DRAFTS_AT2"
        ,"AMEND_DETAILS.AMEND_LC_DRAFTS_AT3"
        ,"AMEND_DETAILS.AMEND_LC_DRAWEE_REQ"
        ,"AMEND_DETAILS.AMEND_LC_DRAWEE_TYPE"
        ,"AMEND_DETAILS.AMEND_LC_DRAWEE_BRN_CODE"
        ,"AMEND_DETAILS.AMEND_LC_DRAWEE_BIC_CODE"
        ,"AMEND_DETAILS.AMEND_LC_DRAWEE_ROUTID"
        ,"AMEND_DETAILS.AMEND_LC_DRAWEE_BNK_CODE"
        ,"AMEND_DETAILS.AMEND_LC_DRAWEE_ADDR1"
        ,"AMEND_DETAILS.AMEND_LC_DRAWEE_ADDR2"
        ,"AMEND_DETAILS.AMEND_LC_DRAWEE_ADDR3"
        ,"AMEND_DETAILS.AMEND_LC_DRAWEE_ADDR4"
        ,"AMEND_DETAILS.AMEND_LC_DRAWEE_ADDR5"
        ,"AMEND_DETAILS.AMEND_DRAWEE_CNTRY_CODE"
        ,"AMEND_DETAILS.AMEND_LC_MIXED_PAY_DETAILS1"
        ,"AMEND_DETAILS.AMEND_LC_MIXED_PAY_DETAILS2"
        ,"AMEND_DETAILS.AMEND_LC_MIXED_PAY_DETAILS3"
        ,"AMEND_DETAILS.AMEND_LC_MIXED_PAY_DETAILS4"
        ,"AMEND_DETAILS.AMEND_LC_MIXED_PAY_DETAILS5"
        ,"AMEND_DETAILS.AMEND_LC_DEFERRED_PAY_DETAILS1"
        ,"AMEND_DETAILS.AMEND_LC_DEFERRED_PAY_DETAILS2"
        ,"AMEND_DETAILS.AMEND_LC_DEFERRED_PAY_DETAILS3"
        ,"AMEND_DETAILS.AMEND_LC_DEFERRED_PAY_DETAILS4"
        ,"AMEND_DETAILS.AMEND_LC_DEFERRED_PAY_DETAILS5"
        ,"AMEND_DETAILS.AMEND_LC_PARTIAL_SHIPMENTS"
        ,"AMEND_DETAILS.AMEND_LC_TRANSHIPMENT"
        ,"AMEND_DETAILS.AMEND_LC_CONFIRMATION_INST"
        ,"AMEND_DETAILS.AMEND_LC_REIMB_REQ"
        ,"AMEND_DETAILS.AMEND_LC_REIMB_TYPE"
        ,"AMEND_DETAILS.AMEND_LC_REIMB_BRN_CODE"
        ,"AMEND_DETAILS.AMEND_LC_REIMB_BIC_CODE"
        ,"AMEND_DETAILS.AMEND_LC_REIMB_ROUTID"
        ,"AMEND_DETAILS.AMEND_LC_REIMB_BNK_CODE"
        ,"AMEND_DETAILS.AMEND_LC_REIMB_ADDR1"
        ,"AMEND_DETAILS.AMEND_LC_REIMB_ADDR2"
        ,"AMEND_DETAILS.AMEND_LC_REIMB_ADDR3"
        ,"AMEND_DETAILS.AMEND_LC_REIMB_ADDR4"
        ,"AMEND_DETAILS.AMEND_LC_REIMB_ADDR5"
        ,"AMEND_DETAILS.AMEND_LC_INST_PAYING1"
        ,"AMEND_DETAILS.AMEND_LC_INST_PAYING2"
        ,"AMEND_DETAILS.AMEND_LC_INST_PAYING3"
        ,"AMEND_DETAILS.AMEND_LC_INST_PAYING4"
        ,"AMEND_DETAILS.AMEND_LC_INST_PAYING5"
        ,"AMEND_DETAILS.AMEND_LC_INST_PAYING6"
        ,"AMEND_DETAILS.AMEND_LC_INST_PAYING7"
        ,"AMEND_DETAILS.AMEND_LC_INST_PAYING8"
        ,"AMEND_DETAILS.AMEND_LC_INST_PAYING9"
        ,"AMEND_DETAILS.AMEND_LC_INST_PAYING10"
        ,"AMEND_DETAILS.AMEND_LC_INST_PAYING11"
        ,"AMEND_DETAILS.AMEND_LC_INST_PAYING12"
        ,"AMEND_DETAILS.AMEND_LC_SECOND_ADV_REQ"
        ,"AMEND_DETAILS.AMEND_LC_SECOND_ADV_TYPE"
        ,"AMEND_DETAILS.AMEND_LC_SECOND_ADV_BRN_CODE"
        ,"AMEND_DETAILS.AMEND_LC_SECOND_ADV_BIC_CODE"
        ,"AMEND_DETAILS.AMEND_LC_SECOND_ADV_ROUTID"
        ,"AMEND_DETAILS.AMEND_LC_SECOND_ADV_BNK_CODE"
        ,"AMEND_DETAILS.AMEND_LC_SECOND_ADV_ADDR1"
        ,"AMEND_DETAILS.AMEND_LC_SECOND_ADV_ADDR2"
        ,"AMEND_DETAILS.AMEND_LC_SECOND_ADV_ADDR3"
        ,"AMEND_DETAILS.AMEND_LC_SECOND_ADV_ADDR4"
        ,"AMEND_DETAILS.AMEND_LC_SECOND_ADV_ADDR5"
        ,"AMEND_DETAILS.AMEND_LC_SECOND_ADV_CNTRYCODE"
        ,"AMEND_DETAILS.AMEND_LC_AVL_WITH_CODETYP"
        ,"AMEND_DETAILS.AMEND_LC_REIMB_CNTRY_CODE"
        ,"AMEND_DETAILS.AMEND_LC_CNF_ADV_TYPE"
        ,"AMEND_DETAILS.AMEND_LC_CNF_ADV_BRN_CODE"
        ,"AMEND_DETAILS.AMEND_LC_CNF_ADV_BIC_CODE"
        ,"AMEND_DETAILS.AMEND_LC_CNF_ADV_ROUTID"
        ,"AMEND_DETAILS.AMEND_LC_CNF_ADV_BNK_CODE"
        ,"AMEND_DETAILS.AMEND_LC_CNF_ADV_ADDR1"
        ,"AMEND_DETAILS.AMEND_LC_CNF_ADV_ADDR2"
        ,"AMEND_DETAILS.AMEND_LC_CNF_ADV_ADDR3"
        ,"AMEND_DETAILS.AMEND_LC_CNF_ADV_ADDR4"
        ,"AMEND_DETAILS.AMEND_LC_CNF_ADV_ADDR5"
        ,"AMEND_DETAILS.AMEND_LC_CNF_ADV_CNTRYCODE"
    };

    private static final String ALL_FIELDS = "AMEND_DETAILS.AMEND_LC_BRN_CODE"
                            + ",AMEND_DETAILS.AMEND_LC_TYPE"
                            + ",AMEND_DETAILS.AMEND_LC_YEAR"
                            + ",AMEND_DETAILS.AMEND_LC_SERIAL"
                            + ",AMEND_DETAILS.AMEND_LC_AMD_SL"
                            + ",AMEND_DETAILS.AMEND_SNDR_REF"
                            + ",AMEND_DETAILS.AMEND_RCVR_REF"
                            + ",AMEND_DETAILS.AMEND_DOC_CR_NUM"
                            + ",AMEND_DETAILS.AMEND_ISSUING_BNK_REQ"
                            + ",AMEND_DETAILS.AMEND_ISSUING_TYPE"
                            + ",AMEND_DETAILS.AMEND_ISSUING_BRN_CODE"
                            + ",AMEND_DETAILS.AMEND_ISSUING_BIC_CODE"
                            + ",AMEND_DETAILS.AMEND_ISSUING_ROUTID"
                            + ",AMEND_DETAILS.AMEND_ISSUING_BNK_CODE"
                            + ",AMEND_DETAILS.AMEND_ISSUING_ADDR1"
                            + ",AMEND_DETAILS.AMEND_ISSUING_ADDR2"
                            + ",AMEND_DETAILS.AMEND_ISSUING_ADDR3"
                            + ",AMEND_DETAILS.AMEND_ISSUING_ADDR4"
                            + ",AMEND_DETAILS.AMEND_ISSUING_ADDR5"
                            + ",AMEND_DETAILS.AMEND_NON_BNK_ISSUR"
                            + ",AMEND_DETAILS.AMEND_DATE_OF_ISSUE"
                            + ",AMEND_DETAILS.AMEND_DATE_OF_AMENDMENT"
                            + ",AMEND_DETAILS.AMEND_PURPOSE_OF_MSG"
                            + ",AMEND_DETAILS.AMEND_CANCEL_REQUEST"
                            + ",AMEND_DETAILS.AMEND_ADVISING_BNK_REQ"
                            + ",AMEND_DETAILS.AMEND_ADVISING_BNK_TYPE"
                            + ",AMEND_DETAILS.AMEND_ADVISING_BRN_CODE"
                            + ",AMEND_DETAILS.AMEND_ADVISING_BIC_CODE"
                            + ",AMEND_DETAILS.AMEND_ADVISING_ROUTID"
                            + ",AMEND_DETAILS.AMEND_ADVISING_BNK_CODE"
                            + ",AMEND_DETAILS.AMEND_ADVISING_ADDR1"
                            + ",AMEND_DETAILS.AMEND_ADVISING_ADDR2"
                            + ",AMEND_DETAILS.AMEND_ADVISING_ADDR3"
                            + ",AMEND_DETAILS.AMEND_ADVISING_ADDR4"
                            + ",AMEND_DETAILS.AMEND_ADVISING_ADDR5"
                            + ",AMEND_DETAILS.AMEND_SECOND_ADV_REQ"
                            + ",AMEND_DETAILS.AMEND_SECOND_ADV_TYPE"
                            + ",AMEND_DETAILS.AMEND_SECOND_ADV_BRN_CODE"
                            + ",AMEND_DETAILS.AMEND_SECOND_ADV_BIC_CODE"
                            + ",AMEND_DETAILS.AMEND_SECOND_ADV_ROUTID"
                            + ",AMEND_DETAILS.AMEND_SECOND_ADV_BNK_CODE"
                            + ",AMEND_DETAILS.AMEND_SECOND_ADV_ADDR1"
                            + ",AMEND_DETAILS.AMEND_SECOND_ADV_ADDR2"
                            + ",AMEND_DETAILS.AMEND_SECOND_ADV_ADDR3"
                            + ",AMEND_DETAILS.AMEND_SECOND_ADV_ADDR4"
                            + ",AMEND_DETAILS.AMEND_SECOND_ADV_ADDR5"
                            + ",AMEND_DETAILS.AMEND_NEW_BENEFICIARY"
                            + ",AMEND_DETAILS.AMEND_NEW_DATE_OF_EXPIRY"
                            + ",AMEND_DETAILS.AMEND_INCR_DOC_CR_AMT"
                            + ",AMEND_DETAILS.AMEND_DECR_DOC_CR_AMT"
                            + ",AMEND_DETAILS.AMEND_NEW_ADDNL_AMT"
                            + ",AMEND_DETAILS.AMEND_PLACE_TAKIN_IN_CHRG"
                            + ",AMEND_DETAILS.AMEND_PORT_OF_LOADING"
                            + ",AMEND_DETAILS.AMEND_PORT_OF_DISCHARGE"
                            + ",AMEND_DETAILS.AMEND_PLACE_OF_FINAL_DEST"
                            + ",AMEND_DETAILS.AMEND_DATE_OF_SHIPMENT"
                            + ",AMEND_DETAILS.AMEND_DESC_GODD_SER1"
                            + ",AMEND_DETAILS.AMEND_DOC_REQ1"
                            + ",AMEND_DETAILS.AMEND_ADD_CONDITION1"
                            + ",AMEND_DETAILS.AMEND_CHRG_PAYABLE1"
                            + ",AMEND_DETAILS.AMEND_CHRG_PAYABLE2"
                            + ",AMEND_DETAILS.AMEND_CHRG_PAYABLE3"
                            + ",AMEND_DETAILS.AMEND_CHRG_PAYABLE4"
                            + ",AMEND_DETAILS.AMEND_CHRG_PAYABLE5"
                            + ",AMEND_DETAILS.AMEND_CHRG_PAYABLE6"
                            + ",AMEND_DETAILS.AMEND_SNDR_REC_INFO1"
                            + ",AMEND_DETAILS.AMEND_SNDR_REC_INFO2"
                            + ",AMEND_DETAILS.AMEND_SNDR_REC_INFO3"
                            + ",AMEND_DETAILS.AMEND_SNDR_REC_INFO4"
                            + ",AMEND_DETAILS.AMEND_SNDR_REC_INFO5"
                            + ",AMEND_DETAILS.AMEND_SNDR_REC_INFO6"
                            + ",AMEND_DETAILS.AMEND_CHKBOX"
                            + ",AMEND_DETAILS.AMEND_ISSUING_CNTRY"
                            + ",AMEND_DETAILS.AMEND_ADVISING_CNTRY"
                            + ",AMEND_DETAILS.AMEND_SECOND_ADV_CNTRY"
                            + ",AMEND_DETAILS.AMEND_ISSUE_REF"
                            + ",AMEND_DETAILS.AMEND_FORM_OF_DOC_CREDIT"
                            + ",AMEND_DETAILS.AMEND_LC_APPLICABLE_RULES"
                            + ",AMEND_DETAILS.AMEND_LC_APPLICANT_REQ"
                            + ",AMEND_DETAILS.AMEND_LC_APPLICANT_NAME"
                            + ",AMEND_DETAILS.AMEND_LC_APPLICANT_ADDR1"
                            + ",AMEND_DETAILS.AMEND_LC_APPLICANT_ADDR2"
                            + ",AMEND_DETAILS.AMEND_LC_APPLICANT_ADDR3"
                            + ",AMEND_DETAILS.AMEND_LC_APPLICANT_ADDR4"
                            + ",AMEND_DETAILS.AMEND_LC_APPLICANT_ADDR5"
                            + ",AMEND_DETAILS.AMEND_LC_AVL_WITH_TYPE"
                            + ",AMEND_DETAILS.AMEND_LC_AVL_WITH_BRN_CODE"
                            + ",AMEND_DETAILS.AMEND_LC_AVL_WITH_BIC_CODE"
                            + ",AMEND_DETAILS.AMEND_LC_LC_AVL_WITH_ROUTID"
                            + ",AMEND_DETAILS.AMEND_LC_AVL_WITH_BNK_CODE"
                            + ",AMEND_DETAILS.AMEND_LC_AVL_WITH_ADDR1"
                            + ",AMEND_DETAILS.AMEND_LC_AVL_WITH_ADDR2"
                            + ",AMEND_DETAILS.AMEND_LC_AVL_WITH_ADDR3"
                            + ",AMEND_DETAILS.AMEND_LC_AVL_WITH_ADDR4"
                            + ",AMEND_DETAILS.AMEND_LC_AVL_WITH_ADDR5"
                            + ",AMEND_DETAILS.AMEND_LC_AVL_WITH_CNTRY"
                            + ",AMEND_DETAILS.AMEND_LC_DRAFTS_AT1"
                            + ",AMEND_DETAILS.AMEND_LC_DRAFTS_AT2"
                            + ",AMEND_DETAILS.AMEND_LC_DRAFTS_AT3"
                            + ",AMEND_DETAILS.AMEND_LC_DRAWEE_REQ"
                            + ",AMEND_DETAILS.AMEND_LC_DRAWEE_TYPE"
                            + ",AMEND_DETAILS.AMEND_LC_DRAWEE_BRN_CODE"
                            + ",AMEND_DETAILS.AMEND_LC_DRAWEE_BIC_CODE"
                            + ",AMEND_DETAILS.AMEND_LC_DRAWEE_ROUTID"
                            + ",AMEND_DETAILS.AMEND_LC_DRAWEE_BNK_CODE"
                            + ",AMEND_DETAILS.AMEND_LC_DRAWEE_ADDR1"
                            + ",AMEND_DETAILS.AMEND_LC_DRAWEE_ADDR2"
                            + ",AMEND_DETAILS.AMEND_LC_DRAWEE_ADDR3"
                            + ",AMEND_DETAILS.AMEND_LC_DRAWEE_ADDR4"
                            + ",AMEND_DETAILS.AMEND_LC_DRAWEE_ADDR5"
                            + ",AMEND_DETAILS.AMEND_DRAWEE_CNTRY_CODE"
                            + ",AMEND_DETAILS.AMEND_LC_MIXED_PAY_DETAILS1"
                            + ",AMEND_DETAILS.AMEND_LC_MIXED_PAY_DETAILS2"
                            + ",AMEND_DETAILS.AMEND_LC_MIXED_PAY_DETAILS3"
                            + ",AMEND_DETAILS.AMEND_LC_MIXED_PAY_DETAILS4"
                            + ",AMEND_DETAILS.AMEND_LC_MIXED_PAY_DETAILS5"
                            + ",AMEND_DETAILS.AMEND_LC_DEFERRED_PAY_DETAILS1"
                            + ",AMEND_DETAILS.AMEND_LC_DEFERRED_PAY_DETAILS2"
                            + ",AMEND_DETAILS.AMEND_LC_DEFERRED_PAY_DETAILS3"
                            + ",AMEND_DETAILS.AMEND_LC_DEFERRED_PAY_DETAILS4"
                            + ",AMEND_DETAILS.AMEND_LC_DEFERRED_PAY_DETAILS5"
                            + ",AMEND_DETAILS.AMEND_LC_PARTIAL_SHIPMENTS"
                            + ",AMEND_DETAILS.AMEND_LC_TRANSHIPMENT"
                            + ",AMEND_DETAILS.AMEND_LC_CONFIRMATION_INST"
                            + ",AMEND_DETAILS.AMEND_LC_REIMB_REQ"
                            + ",AMEND_DETAILS.AMEND_LC_REIMB_TYPE"
                            + ",AMEND_DETAILS.AMEND_LC_REIMB_BRN_CODE"
                            + ",AMEND_DETAILS.AMEND_LC_REIMB_BIC_CODE"
                            + ",AMEND_DETAILS.AMEND_LC_REIMB_ROUTID"
                            + ",AMEND_DETAILS.AMEND_LC_REIMB_BNK_CODE"
                            + ",AMEND_DETAILS.AMEND_LC_REIMB_ADDR1"
                            + ",AMEND_DETAILS.AMEND_LC_REIMB_ADDR2"
                            + ",AMEND_DETAILS.AMEND_LC_REIMB_ADDR3"
                            + ",AMEND_DETAILS.AMEND_LC_REIMB_ADDR4"
                            + ",AMEND_DETAILS.AMEND_LC_REIMB_ADDR5"
                            + ",AMEND_DETAILS.AMEND_LC_INST_PAYING1"
                            + ",AMEND_DETAILS.AMEND_LC_INST_PAYING2"
                            + ",AMEND_DETAILS.AMEND_LC_INST_PAYING3"
                            + ",AMEND_DETAILS.AMEND_LC_INST_PAYING4"
                            + ",AMEND_DETAILS.AMEND_LC_INST_PAYING5"
                            + ",AMEND_DETAILS.AMEND_LC_INST_PAYING6"
                            + ",AMEND_DETAILS.AMEND_LC_INST_PAYING7"
                            + ",AMEND_DETAILS.AMEND_LC_INST_PAYING8"
                            + ",AMEND_DETAILS.AMEND_LC_INST_PAYING9"
                            + ",AMEND_DETAILS.AMEND_LC_INST_PAYING10"
                            + ",AMEND_DETAILS.AMEND_LC_INST_PAYING11"
                            + ",AMEND_DETAILS.AMEND_LC_INST_PAYING12"
                            + ",AMEND_DETAILS.AMEND_LC_SECOND_ADV_REQ"
                            + ",AMEND_DETAILS.AMEND_LC_SECOND_ADV_TYPE"
                            + ",AMEND_DETAILS.AMEND_LC_SECOND_ADV_BRN_CODE"
                            + ",AMEND_DETAILS.AMEND_LC_SECOND_ADV_BIC_CODE"
                            + ",AMEND_DETAILS.AMEND_LC_SECOND_ADV_ROUTID"
                            + ",AMEND_DETAILS.AMEND_LC_SECOND_ADV_BNK_CODE"
                            + ",AMEND_DETAILS.AMEND_LC_SECOND_ADV_ADDR1"
                            + ",AMEND_DETAILS.AMEND_LC_SECOND_ADV_ADDR2"
                            + ",AMEND_DETAILS.AMEND_LC_SECOND_ADV_ADDR3"
                            + ",AMEND_DETAILS.AMEND_LC_SECOND_ADV_ADDR4"
                            + ",AMEND_DETAILS.AMEND_LC_SECOND_ADV_ADDR5"
                            + ",AMEND_DETAILS.AMEND_LC_SECOND_ADV_CNTRYCODE"
                            + ",AMEND_DETAILS.AMEND_LC_AVL_WITH_CODETYP"
                            + ",AMEND_DETAILS.AMEND_LC_REIMB_CNTRY_CODE"
                            + ",AMEND_DETAILS.AMEND_LC_CNF_ADV_TYPE"
                            + ",AMEND_DETAILS.AMEND_LC_CNF_ADV_BRN_CODE"
                            + ",AMEND_DETAILS.AMEND_LC_CNF_ADV_BIC_CODE"
                            + ",AMEND_DETAILS.AMEND_LC_CNF_ADV_ROUTID"
                            + ",AMEND_DETAILS.AMEND_LC_CNF_ADV_BNK_CODE"
                            + ",AMEND_DETAILS.AMEND_LC_CNF_ADV_ADDR1"
                            + ",AMEND_DETAILS.AMEND_LC_CNF_ADV_ADDR2"
                            + ",AMEND_DETAILS.AMEND_LC_CNF_ADV_ADDR3"
                            + ",AMEND_DETAILS.AMEND_LC_CNF_ADV_ADDR4"
                            + ",AMEND_DETAILS.AMEND_LC_CNF_ADV_ADDR5"
                            + ",AMEND_DETAILS.AMEND_LC_CNF_ADV_CNTRYCODE";

    public AmendDetails loadByKey(int _amendLcAmdSl, int _amendLcBrnCode, int _amendLcSerial, String _amendLcType, int _amendLcYear) throws SQLException {
        Connection _conn = null;
        try {
            _conn = openConnection();
            AmendDetails _obj = loadByKey(_amendLcAmdSl, _amendLcBrnCode, _amendLcSerial, _amendLcType, _amendLcYear, _conn);
            if ( _obj != null)
            {
            OldData_Key = "AMEND_DETAILS" + TableValueSep + OldDataChar + _obj.getAmendLcBrnCode() + _obj.getAmendLcType() + _obj.getAmendLcYear() + _obj.getAmendLcSerial() + _obj.getAmendLcAmdSl();
        DataBlock_Old = _obj.getAmendLcBrnCode() + JNDINames.splitchar + _obj.getAmendLcType() + JNDINames.splitchar + _obj.getAmendLcYear() + JNDINames.splitchar + _obj.getAmendLcSerial() + JNDINames.splitchar + _obj.getAmendLcAmdSl() + JNDINames.splitchar + _obj.getAmendSndrRef() + JNDINames.splitchar + _obj.getAmendRcvrRef() + JNDINames.splitchar + _obj.getAmendDocCrNum() + JNDINames.splitchar + _obj.getAmendIssuingBnkReq() + JNDINames.splitchar + _obj.getAmendIssuingType() + JNDINames.splitchar + _obj.getAmendIssuingBrnCode() + JNDINames.splitchar + _obj.getAmendIssuingBicCode() + JNDINames.splitchar + _obj.getAmendIssuingRoutid() + JNDINames.splitchar + _obj.getAmendIssuingBnkCode() + JNDINames.splitchar + _obj.getAmendIssuingAddr1() + JNDINames.splitchar + _obj.getAmendIssuingAddr2() + JNDINames.splitchar + _obj.getAmendIssuingAddr3() + JNDINames.splitchar + _obj.getAmendIssuingAddr4() + JNDINames.splitchar + _obj.getAmendIssuingAddr5() + JNDINames.splitchar + _obj.getAmendNonBnkIssur() + JNDINames.splitchar + _obj.getAmendDateOfIssue() + JNDINames.splitchar + _obj.getAmendDateOfAmendment() + JNDINames.splitchar + _obj.getAmendPurposeOfMsg() + JNDINames.splitchar + _obj.getAmendCancelRequest() + JNDINames.splitchar + _obj.getAmendAdvisingBnkReq() + JNDINames.splitchar + _obj.getAmendAdvisingBnkType() + JNDINames.splitchar + _obj.getAmendAdvisingBrnCode() + JNDINames.splitchar + _obj.getAmendAdvisingBicCode() + JNDINames.splitchar + _obj.getAmendAdvisingRoutid() + JNDINames.splitchar + _obj.getAmendAdvisingBnkCode() + JNDINames.splitchar + _obj.getAmendAdvisingAddr1() + JNDINames.splitchar + _obj.getAmendAdvisingAddr2() + JNDINames.splitchar + _obj.getAmendAdvisingAddr3() + JNDINames.splitchar + _obj.getAmendAdvisingAddr4() + JNDINames.splitchar + _obj.getAmendAdvisingAddr5() + JNDINames.splitchar + _obj.getAmendSecondAdvReq() + JNDINames.splitchar + _obj.getAmendSecondAdvType() + JNDINames.splitchar + _obj.getAmendSecondAdvBrnCode() + JNDINames.splitchar + _obj.getAmendSecondAdvBicCode() + JNDINames.splitchar + _obj.getAmendSecondAdvRoutid() + JNDINames.splitchar + _obj.getAmendSecondAdvBnkCode() + JNDINames.splitchar + _obj.getAmendSecondAdvAddr1() + JNDINames.splitchar + _obj.getAmendSecondAdvAddr2() + JNDINames.splitchar + _obj.getAmendSecondAdvAddr3() + JNDINames.splitchar + _obj.getAmendSecondAdvAddr4() + JNDINames.splitchar + _obj.getAmendSecondAdvAddr5() + JNDINames.splitchar + _obj.getAmendNewBeneficiary() + JNDINames.splitchar + _obj.getAmendNewDateOfExpiry() + JNDINames.splitchar + _obj.getAmendIncrDocCrAmt() + JNDINames.splitchar + _obj.getAmendDecrDocCrAmt() + JNDINames.splitchar + _obj.getAmendNewAddnlAmt() + JNDINames.splitchar + _obj.getAmendPlaceTakinInChrg() + JNDINames.splitchar + _obj.getAmendPortOfLoading() + JNDINames.splitchar + _obj.getAmendPortOfDischarge() + JNDINames.splitchar + _obj.getAmendPlaceOfFinalDest() + JNDINames.splitchar + _obj.getAmendDateOfShipment() + JNDINames.splitchar + _obj.getAmendDescGoddSer1() + JNDINames.splitchar + _obj.getAmendDocReq1() + JNDINames.splitchar + _obj.getAmendAddCondition1() + JNDINames.splitchar + _obj.getAmendChrgPayable1() + JNDINames.splitchar + _obj.getAmendChrgPayable2() + JNDINames.splitchar + _obj.getAmendChrgPayable3() + JNDINames.splitchar + _obj.getAmendChrgPayable4() + JNDINames.splitchar + _obj.getAmendChrgPayable5() + JNDINames.splitchar + _obj.getAmendChrgPayable6() + JNDINames.splitchar + _obj.getAmendSndrRecInfo1() + JNDINames.splitchar + _obj.getAmendSndrRecInfo2() + JNDINames.splitchar + _obj.getAmendSndrRecInfo3() + JNDINames.splitchar + _obj.getAmendSndrRecInfo4() + JNDINames.splitchar + _obj.getAmendSndrRecInfo5() + JNDINames.splitchar + _obj.getAmendSndrRecInfo6() + JNDINames.splitchar + _obj.getAmendChkbox() + JNDINames.splitchar + _obj.getAmendIssuingCntry() + JNDINames.splitchar + _obj.getAmendAdvisingCntry() + JNDINames.splitchar + _obj.getAmendSecondAdvCntry() + JNDINames.splitchar + _obj.getAmendIssueRef() + JNDINames.splitchar + _obj.getAmendFormOfDocCredit() + JNDINames.splitchar + _obj.getAmendLcApplicableRules() + JNDINames.splitchar + _obj.getAmendLcApplicantReq() + JNDINames.splitchar + _obj.getAmendLcApplicantName() + JNDINames.splitchar + _obj.getAmendLcApplicantAddr1() + JNDINames.splitchar + _obj.getAmendLcApplicantAddr2() + JNDINames.splitchar + _obj.getAmendLcApplicantAddr3() + JNDINames.splitchar + _obj.getAmendLcApplicantAddr4() + JNDINames.splitchar + _obj.getAmendLcApplicantAddr5() + JNDINames.splitchar + _obj.getAmendLcAvlWithType() + JNDINames.splitchar + _obj.getAmendLcAvlWithBrnCode() + JNDINames.splitchar + _obj.getAmendLcAvlWithBicCode() + JNDINames.splitchar + _obj.getAmendLcLcAvlWithRoutid() + JNDINames.splitchar + _obj.getAmendLcAvlWithBnkCode() + JNDINames.splitchar + _obj.getAmendLcAvlWithAddr1() + JNDINames.splitchar + _obj.getAmendLcAvlWithAddr2() + JNDINames.splitchar + _obj.getAmendLcAvlWithAddr3() + JNDINames.splitchar + _obj.getAmendLcAvlWithAddr4() + JNDINames.splitchar + _obj.getAmendLcAvlWithAddr5() + JNDINames.splitchar + _obj.getAmendLcAvlWithCntry() + JNDINames.splitchar + _obj.getAmendLcDraftsAt1() + JNDINames.splitchar + _obj.getAmendLcDraftsAt2() + JNDINames.splitchar + _obj.getAmendLcDraftsAt3() + JNDINames.splitchar + _obj.getAmendLcDraweeReq() + JNDINames.splitchar + _obj.getAmendLcDraweeType() + JNDINames.splitchar + _obj.getAmendLcDraweeBrnCode() + JNDINames.splitchar + _obj.getAmendLcDraweeBicCode() + JNDINames.splitchar + _obj.getAmendLcDraweeRoutid() + JNDINames.splitchar + _obj.getAmendLcDraweeBnkCode() + JNDINames.splitchar + _obj.getAmendLcDraweeAddr1() + JNDINames.splitchar + _obj.getAmendLcDraweeAddr2() + JNDINames.splitchar + _obj.getAmendLcDraweeAddr3() + JNDINames.splitchar + _obj.getAmendLcDraweeAddr4() + JNDINames.splitchar + _obj.getAmendLcDraweeAddr5() + JNDINames.splitchar + _obj.getAmendDraweeCntryCode() + JNDINames.splitchar + _obj.getAmendLcMixedPayDetails1() + JNDINames.splitchar + _obj.getAmendLcMixedPayDetails2() + JNDINames.splitchar + _obj.getAmendLcMixedPayDetails3() + JNDINames.splitchar + _obj.getAmendLcMixedPayDetails4() + JNDINames.splitchar + _obj.getAmendLcMixedPayDetails5() + JNDINames.splitchar + _obj.getAmendLcDeferredPayDetails1() + JNDINames.splitchar + _obj.getAmendLcDeferredPayDetails2() + JNDINames.splitchar + _obj.getAmendLcDeferredPayDetails3() + JNDINames.splitchar + _obj.getAmendLcDeferredPayDetails4() + JNDINames.splitchar + _obj.getAmendLcDeferredPayDetails5() + JNDINames.splitchar + _obj.getAmendLcPartialShipments() + JNDINames.splitchar + _obj.getAmendLcTranshipment() + JNDINames.splitchar + _obj.getAmendLcConfirmationInst() + JNDINames.splitchar + _obj.getAmendLcReimbReq() + JNDINames.splitchar + _obj.getAmendLcReimbType() + JNDINames.splitchar + _obj.getAmendLcReimbBrnCode() + JNDINames.splitchar + _obj.getAmendLcReimbBicCode() + JNDINames.splitchar + _obj.getAmendLcReimbRoutid() + JNDINames.splitchar + _obj.getAmendLcReimbBnkCode() + JNDINames.splitchar + _obj.getAmendLcReimbAddr1() + JNDINames.splitchar + _obj.getAmendLcReimbAddr2() + JNDINames.splitchar + _obj.getAmendLcReimbAddr3() + JNDINames.splitchar + _obj.getAmendLcReimbAddr4() + JNDINames.splitchar + _obj.getAmendLcReimbAddr5() + JNDINames.splitchar + _obj.getAmendLcInstPaying1() + JNDINames.splitchar + _obj.getAmendLcInstPaying2() + JNDINames.splitchar + _obj.getAmendLcInstPaying3() + JNDINames.splitchar + _obj.getAmendLcInstPaying4() + JNDINames.splitchar + _obj.getAmendLcInstPaying5() + JNDINames.splitchar + _obj.getAmendLcInstPaying6() + JNDINames.splitchar + _obj.getAmendLcInstPaying7() + JNDINames.splitchar + _obj.getAmendLcInstPaying8() + JNDINames.splitchar + _obj.getAmendLcInstPaying9() + JNDINames.splitchar + _obj.getAmendLcInstPaying10() + JNDINames.splitchar + _obj.getAmendLcInstPaying11() + JNDINames.splitchar + _obj.getAmendLcInstPaying12() + JNDINames.splitchar + _obj.getAmendLcSecondAdvReq() + JNDINames.splitchar + _obj.getAmendLcSecondAdvType() + JNDINames.splitchar + _obj.getAmendLcSecondAdvBrnCode() + JNDINames.splitchar + _obj.getAmendLcSecondAdvBicCode() + JNDINames.splitchar + _obj.getAmendLcSecondAdvRoutid() + JNDINames.splitchar + _obj.getAmendLcSecondAdvBnkCode() + JNDINames.splitchar + _obj.getAmendLcSecondAdvAddr1() + JNDINames.splitchar + _obj.getAmendLcSecondAdvAddr2() + JNDINames.splitchar + _obj.getAmendLcSecondAdvAddr3() + JNDINames.splitchar + _obj.getAmendLcSecondAdvAddr4() + JNDINames.splitchar + _obj.getAmendLcSecondAdvAddr5() + JNDINames.splitchar + _obj.getAmendLcSecondAdvCntrycode() + JNDINames.splitchar + _obj.getAmendLcAvlWithCodetyp() + JNDINames.splitchar + _obj.getAmendLcReimbCntryCode() + JNDINames.splitchar + _obj.getAmendLcCnfAdvType() + JNDINames.splitchar + _obj.getAmendLcCnfAdvBrnCode() + JNDINames.splitchar + _obj.getAmendLcCnfAdvBicCode() + JNDINames.splitchar + _obj.getAmendLcCnfAdvRoutid() + JNDINames.splitchar + _obj.getAmendLcCnfAdvBnkCode() + JNDINames.splitchar + _obj.getAmendLcCnfAdvAddr1() + JNDINames.splitchar + _obj.getAmendLcCnfAdvAddr2() + JNDINames.splitchar + _obj.getAmendLcCnfAdvAddr3() + JNDINames.splitchar + _obj.getAmendLcCnfAdvAddr4() + JNDINames.splitchar + _obj.getAmendLcCnfAdvAddr5() + JNDINames.splitchar + _obj.getAmendLcCnfAdvCntrycode();
        }
            closeConnection(_conn);
            return _obj;
        }
        catch(SQLException e) {
            if(_conn != null)  try { closeConnection(_conn); } catch(SQLException e2) { }
            throw e;
        }
    }

    public AmendDetails loadByKey(int _amendLcAmdSl, int _amendLcBrnCode, int _amendLcSerial, String _amendLcType, int _amendLcYear, Connection _conn) throws SQLException {
        PreparedStatement _pstmt = null;
        try {
            _pstmt = _conn.prepareStatement("SELECT " + ALL_FIELDS + " FROM AMEND_DETAILS WHERE AMEND_DETAILS.AMEND_LC_AMD_SL=? and AMEND_DETAILS.AMEND_LC_BRN_CODE=? and AMEND_DETAILS.AMEND_LC_SERIAL=? and AMEND_DETAILS.AMEND_LC_TYPE=? and AMEND_DETAILS.AMEND_LC_YEAR=?");
            _pstmt.setInt(1, _amendLcAmdSl);
            _pstmt.setInt(2, _amendLcBrnCode);
            _pstmt.setInt(3, _amendLcSerial);
            _pstmt.setString(4, _amendLcType);
            _pstmt.setInt(5, _amendLcYear);
            AmendDetails _list[] = loadByPreparedStatement(_pstmt);
            _pstmt.close();
            if(_list.length < 1) return null;
            else                 return _list[0];
        }
        catch(SQLException e) {
            if(_pstmt != null) try { _pstmt.close(); } catch(SQLException e2) { }
            throw e;
        }
    }

    public AmendDetails[] loadAll() throws SQLException {
        Connection _conn = null;
        try {
            _conn = openConnection();
            AmendDetails _list[] = loadAll(_conn);
            closeConnection(_conn);
            return _list;
        }
        catch(SQLException e) {
            if(_conn != null)  try { closeConnection(_conn); } catch(SQLException e2) { }
            throw e;
        }
    }

    public AmendDetails[] loadAll(Connection _conn) throws SQLException {
        PreparedStatement _pstmt = null;
        try {
            _pstmt = _conn.prepareStatement("SELECT " + ALL_FIELDS + " FROM AMEND_DETAILS");
            AmendDetails _list[] = loadByPreparedStatement(_pstmt);
            _pstmt.close();
            return _list;
        }
        catch(SQLException e) {
            if(_pstmt != null) try { _pstmt.close(); } catch(SQLException e2) { }
            throw e;
        }
    }

    public AmendDetails[] loadByPreparedStatement(PreparedStatement pstmt) throws SQLException {
        return loadByPreparedStatement(pstmt, null, 0);
    }

    public AmendDetails[] loadByPreparedStatement(PreparedStatement pstmt, int maxRows) throws SQLException {
        return loadByPreparedStatement(pstmt, null, maxRows);
    }

    public AmendDetails[] loadByPreparedStatement(PreparedStatement pstmt, int[] fieldList) throws SQLException {
        return loadByPreparedStatement(pstmt, fieldList, 0);
    }

    public AmendDetails[] loadByPreparedStatement(PreparedStatement pstmt, int[] fieldList, int maxRows) throws SQLException {
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            java.util.Vector v = new java.util.Vector();
            while(rs.next() && (maxRows == 0 || v.size() < maxRows)) {
                if(fieldList == null) v.addElement(decodeRow(rs));
                else v.addElement(decodeRow(rs, fieldList));
            }
            rs.close();
            AmendDetails list[] = new AmendDetails[v.size()];
            v.copyInto(list);
            return list;
        }
        catch(SQLException e) {
            if(rs!=null) try { rs.close();} catch(Exception e2) {}
            throw e;
        }
    }

    public AmendDetails[] loadByWhere(String where) throws SQLException {
        return loadByWhere(where, (int[])null, 0);
    }
    public AmendDetails[] loadByWhere(String where, int maxRows) throws SQLException {
        return loadByWhere(where, (int[])null, maxRows);
    }
    public AmendDetails[] loadByWhere(String where, int[] fieldList) throws SQLException {
        return loadByWhere(where, fieldList, 0);
    }
    public AmendDetails[] loadByWhere(String where, int[] fieldList, int maxRows) throws SQLException {
        Connection conn = null;
        try {
            conn = openConnection();
            AmendDetails _list[] = loadByWhere(where, conn, fieldList, maxRows);
            closeConnection(conn);
            return _list;
        }
        catch(SQLException e) {
            if(conn!=null) try { closeConnection(conn);} catch(Exception e2) {}
            throw e;
        }
    }

    public AmendDetails[] loadByWhere(String where, Connection conn) throws SQLException {
        return loadByWhere(where, conn, null, 0);
    }

    public AmendDetails[] loadByWhere(String where, Connection conn, int[] fieldList) throws SQLException {
        return loadByWhere(where, conn, fieldList, 0);
    }

    public AmendDetails[] loadByWhere(String where, Connection conn, int[] fieldList, int maxRows) throws SQLException {
        String sql = null;
        if(fieldList == null) sql = "select " + ALL_FIELDS + " from AMEND_DETAILS " + where;
        else {
            StringBuffer buff = new StringBuffer(128);
            buff.append("select ");
            for(int i = 0; i < fieldList.length; i++) {
                if(i != 0) buff.append(",");
                buff.append(S2J_FIELD_NAMES[fieldList[i]]);
            }
            buff.append(" from AMEND_DETAILS ");
            buff.append(where);
            sql = buff.toString();
        }
        Statement stmt = null;
        ResultSet rs = null;
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            java.util.Vector v = new java.util.Vector();
            while(rs.next() && (maxRows == 0 || v.size() < maxRows)) {
                if(fieldList == null) v.addElement(decodeRow(rs));
                else v.addElement(decodeRow(rs, fieldList));
            }
            rs.close();
            stmt.close();

            AmendDetails _list[] = new AmendDetails[v.size()];
            v.copyInto(_list);
            return _list;
        }
        catch(SQLException e) {
            if(rs!=null) try { rs.close();} catch(Exception e2) {}
            if(stmt!=null) try { stmt.close();} catch(Exception e2) {}
            throw e;
        }
    }

    public int UpdateByQuery(String w_sql) throws SQLException {
        Connection _conn = null;
        PreparedStatement _pstmt = null;
            try {
                _conn = openConnection();
                _pstmt = _conn.prepareStatement(w_sql);
                int _rows = _pstmt.executeUpdate();
                closeConnection(_conn);
                return 1;
            }
            catch(SQLException e) {
                if(_pstmt!=null) try { _pstmt.close();} catch(Exception e2) {}
                if(_conn!=null) try { closeConnection(_conn);} catch(Exception e2) {}
                throw e;
            }
    }
    public int deleteByKey(int _amendLcAmdSl, int _amendLcBrnCode, int _amendLcSerial, String _amendLcType, int _amendLcYear) throws SQLException {
        Connection _conn = null;
        try {
            _conn = openConnection();
            int _rows = deleteByKey(_amendLcAmdSl, _amendLcBrnCode, _amendLcSerial, _amendLcType, _amendLcYear, _conn);
            closeConnection(_conn);
            return _rows;
        }
        catch(SQLException e) {
            if(_conn!=null) try { closeConnection(_conn);} catch(Exception e2) {}
            throw e;
        }
    }

    public int deleteByKey(int _amendLcAmdSl, int _amendLcBrnCode, int _amendLcSerial, String _amendLcType, int _amendLcYear, Connection _conn) throws SQLException {
        PreparedStatement _pstmt = null;
        try {
        AmendDetails _obj  = loadByKey(_amendLcAmdSl, _amendLcBrnCode, _amendLcSerial, _amendLcType, _amendLcYear);
        _obj  = null;
            _pstmt = _conn.prepareStatement("DELETE FROM AMEND_DETAILS WHERE AMEND_DETAILS.AMEND_LC_AMD_SL=? and AMEND_DETAILS.AMEND_LC_BRN_CODE=? and AMEND_DETAILS.AMEND_LC_SERIAL=? and AMEND_DETAILS.AMEND_LC_TYPE=? and AMEND_DETAILS.AMEND_LC_YEAR=?");
            _pstmt.setInt(1, _amendLcAmdSl);
            _pstmt.setInt(2, _amendLcBrnCode);
            _pstmt.setInt(3, _amendLcSerial);
            _pstmt.setString(4, _amendLcType);
            _pstmt.setInt(5, _amendLcYear);
            int _rows = _pstmt.executeUpdate();
            _pstmt.close();
            return _rows;
        }
        catch(SQLException e) {
            if(_pstmt!=null) try { _pstmt.close();} catch(Exception e2) {}
            throw e;
        }
    }

    public void save(AmendDetails obj) throws SQLException {
//        _srcTablePKI = "AMENDDETAILS";
//        _srcKeyPKI = obj.getAmendLcBrnCode() + JNDINames.splitchar + obj.getAmendLcType() + JNDINames.splitchar + obj.getAmendLcYear() + JNDINames.splitchar + obj.getAmendLcSerial() + JNDINames.splitchar + obj.getAmendLcAmdSl();
//        set_pki_values(this._COLLECTIONobj);
        if(!obj.isModifiedS2J()) return;
        Connection _conn = null;
        try {
            _conn = openConnection();
            save(obj, _conn);
            closeConnection(_conn);
        }
        catch(SQLException e) {
            if(_conn!=null) try { closeConnection(_conn);} catch(Exception e2) {}
            throw e;
        }
    }

    public void save(AmendDetails obj, Connection _conn) throws SQLException {
        PreparedStatement _pstmt = null;
        try {
            if(obj.isNew()) {
                int _dirtyCount = 0;
                StringBuffer _sql = new StringBuffer("INSERT into AMEND_DETAILS (");
                if(obj.amendLcBrnCodeIsModifiedS2j()) {  _sql.append("AMEND_LC_BRN_CODE").append(","); _dirtyCount++; }
                if(obj.amendLcTypeIsModifiedS2j()) {  _sql.append("AMEND_LC_TYPE").append(","); _dirtyCount++; }
                if(obj.amendLcYearIsModifiedS2j()) {  _sql.append("AMEND_LC_YEAR").append(","); _dirtyCount++; }
                if(obj.amendLcSerialIsModifiedS2j()) {  _sql.append("AMEND_LC_SERIAL").append(","); _dirtyCount++; }
                if(obj.amendLcAmdSlIsModifiedS2j()) {  _sql.append("AMEND_LC_AMD_SL").append(","); _dirtyCount++; }
                if(obj.amendSndrRefIsModifiedS2j()) {  _sql.append("AMEND_SNDR_REF").append(","); _dirtyCount++; }
                if(obj.amendRcvrRefIsModifiedS2j()) {  _sql.append("AMEND_RCVR_REF").append(","); _dirtyCount++; }
                if(obj.amendDocCrNumIsModifiedS2j()) {  _sql.append("AMEND_DOC_CR_NUM").append(","); _dirtyCount++; }
                if(obj.amendIssuingBnkReqIsModifiedS2j()) {  _sql.append("AMEND_ISSUING_BNK_REQ").append(","); _dirtyCount++; }
                if(obj.amendIssuingTypeIsModifiedS2j()) {  _sql.append("AMEND_ISSUING_TYPE").append(","); _dirtyCount++; }
                if(obj.amendIssuingBrnCodeIsModifiedS2j()) {  _sql.append("AMEND_ISSUING_BRN_CODE").append(","); _dirtyCount++; }
                if(obj.amendIssuingBicCodeIsModifiedS2j()) {  _sql.append("AMEND_ISSUING_BIC_CODE").append(","); _dirtyCount++; }
                if(obj.amendIssuingRoutidIsModifiedS2j()) {  _sql.append("AMEND_ISSUING_ROUTID").append(","); _dirtyCount++; }
                if(obj.amendIssuingBnkCodeIsModifiedS2j()) {  _sql.append("AMEND_ISSUING_BNK_CODE").append(","); _dirtyCount++; }
                if(obj.amendIssuingAddr1IsModifiedS2j()) {  _sql.append("AMEND_ISSUING_ADDR1").append(","); _dirtyCount++; }
                if(obj.amendIssuingAddr2IsModifiedS2j()) {  _sql.append("AMEND_ISSUING_ADDR2").append(","); _dirtyCount++; }
                if(obj.amendIssuingAddr3IsModifiedS2j()) {  _sql.append("AMEND_ISSUING_ADDR3").append(","); _dirtyCount++; }
                if(obj.amendIssuingAddr4IsModifiedS2j()) {  _sql.append("AMEND_ISSUING_ADDR4").append(","); _dirtyCount++; }
                if(obj.amendIssuingAddr5IsModifiedS2j()) {  _sql.append("AMEND_ISSUING_ADDR5").append(","); _dirtyCount++; }
                if(obj.amendNonBnkIssurIsModifiedS2j()) {  _sql.append("AMEND_NON_BNK_ISSUR").append(","); _dirtyCount++; }
                if(obj.amendDateOfIssueIsModifiedS2j()) {  _sql.append("AMEND_DATE_OF_ISSUE").append(","); _dirtyCount++; }
                if(obj.amendDateOfAmendmentIsModifiedS2j()) {  _sql.append("AMEND_DATE_OF_AMENDMENT").append(","); _dirtyCount++; }
                if(obj.amendPurposeOfMsgIsModifiedS2j()) {  _sql.append("AMEND_PURPOSE_OF_MSG").append(","); _dirtyCount++; }
                if(obj.amendCancelRequestIsModifiedS2j()) {  _sql.append("AMEND_CANCEL_REQUEST").append(","); _dirtyCount++; }
                if(obj.amendAdvisingBnkReqIsModifiedS2j()) {  _sql.append("AMEND_ADVISING_BNK_REQ").append(","); _dirtyCount++; }
                if(obj.amendAdvisingBnkTypeIsModifiedS2j()) {  _sql.append("AMEND_ADVISING_BNK_TYPE").append(","); _dirtyCount++; }
                if(obj.amendAdvisingBrnCodeIsModifiedS2j()) {  _sql.append("AMEND_ADVISING_BRN_CODE").append(","); _dirtyCount++; }
                if(obj.amendAdvisingBicCodeIsModifiedS2j()) {  _sql.append("AMEND_ADVISING_BIC_CODE").append(","); _dirtyCount++; }
                if(obj.amendAdvisingRoutidIsModifiedS2j()) {  _sql.append("AMEND_ADVISING_ROUTID").append(","); _dirtyCount++; }
                if(obj.amendAdvisingBnkCodeIsModifiedS2j()) {  _sql.append("AMEND_ADVISING_BNK_CODE").append(","); _dirtyCount++; }
                if(obj.amendAdvisingAddr1IsModifiedS2j()) {  _sql.append("AMEND_ADVISING_ADDR1").append(","); _dirtyCount++; }
                if(obj.amendAdvisingAddr2IsModifiedS2j()) {  _sql.append("AMEND_ADVISING_ADDR2").append(","); _dirtyCount++; }
                if(obj.amendAdvisingAddr3IsModifiedS2j()) {  _sql.append("AMEND_ADVISING_ADDR3").append(","); _dirtyCount++; }
                if(obj.amendAdvisingAddr4IsModifiedS2j()) {  _sql.append("AMEND_ADVISING_ADDR4").append(","); _dirtyCount++; }
                if(obj.amendAdvisingAddr5IsModifiedS2j()) {  _sql.append("AMEND_ADVISING_ADDR5").append(","); _dirtyCount++; }
                if(obj.amendSecondAdvReqIsModifiedS2j()) {  _sql.append("AMEND_SECOND_ADV_REQ").append(","); _dirtyCount++; }
                if(obj.amendSecondAdvTypeIsModifiedS2j()) {  _sql.append("AMEND_SECOND_ADV_TYPE").append(","); _dirtyCount++; }
                if(obj.amendSecondAdvBrnCodeIsModifiedS2j()) {  _sql.append("AMEND_SECOND_ADV_BRN_CODE").append(","); _dirtyCount++; }
                if(obj.amendSecondAdvBicCodeIsModifiedS2j()) {  _sql.append("AMEND_SECOND_ADV_BIC_CODE").append(","); _dirtyCount++; }
                if(obj.amendSecondAdvRoutidIsModifiedS2j()) {  _sql.append("AMEND_SECOND_ADV_ROUTID").append(","); _dirtyCount++; }
                if(obj.amendSecondAdvBnkCodeIsModifiedS2j()) {  _sql.append("AMEND_SECOND_ADV_BNK_CODE").append(","); _dirtyCount++; }
                if(obj.amendSecondAdvAddr1IsModifiedS2j()) {  _sql.append("AMEND_SECOND_ADV_ADDR1").append(","); _dirtyCount++; }
                if(obj.amendSecondAdvAddr2IsModifiedS2j()) {  _sql.append("AMEND_SECOND_ADV_ADDR2").append(","); _dirtyCount++; }
                if(obj.amendSecondAdvAddr3IsModifiedS2j()) {  _sql.append("AMEND_SECOND_ADV_ADDR3").append(","); _dirtyCount++; }
                if(obj.amendSecondAdvAddr4IsModifiedS2j()) {  _sql.append("AMEND_SECOND_ADV_ADDR4").append(","); _dirtyCount++; }
                if(obj.amendSecondAdvAddr5IsModifiedS2j()) {  _sql.append("AMEND_SECOND_ADV_ADDR5").append(","); _dirtyCount++; }
                if(obj.amendNewBeneficiaryIsModifiedS2j()) {  _sql.append("AMEND_NEW_BENEFICIARY").append(","); _dirtyCount++; }
                if(obj.amendNewDateOfExpiryIsModifiedS2j()) {  _sql.append("AMEND_NEW_DATE_OF_EXPIRY").append(","); _dirtyCount++; }
                if(obj.amendIncrDocCrAmtIsModifiedS2j()) {  _sql.append("AMEND_INCR_DOC_CR_AMT").append(","); _dirtyCount++; }
                if(obj.amendDecrDocCrAmtIsModifiedS2j()) {  _sql.append("AMEND_DECR_DOC_CR_AMT").append(","); _dirtyCount++; }
                if(obj.amendNewAddnlAmtIsModifiedS2j()) {  _sql.append("AMEND_NEW_ADDNL_AMT").append(","); _dirtyCount++; }
                if(obj.amendPlaceTakinInChrgIsModifiedS2j()) {  _sql.append("AMEND_PLACE_TAKIN_IN_CHRG").append(","); _dirtyCount++; }
                if(obj.amendPortOfLoadingIsModifiedS2j()) {  _sql.append("AMEND_PORT_OF_LOADING").append(","); _dirtyCount++; }
                if(obj.amendPortOfDischargeIsModifiedS2j()) {  _sql.append("AMEND_PORT_OF_DISCHARGE").append(","); _dirtyCount++; }
                if(obj.amendPlaceOfFinalDestIsModifiedS2j()) {  _sql.append("AMEND_PLACE_OF_FINAL_DEST").append(","); _dirtyCount++; }
                if(obj.amendDateOfShipmentIsModifiedS2j()) {  _sql.append("AMEND_DATE_OF_SHIPMENT").append(","); _dirtyCount++; }
                if(obj.amendDescGoddSer1IsModifiedS2j()) {  _sql.append("AMEND_DESC_GODD_SER1").append(","); _dirtyCount++; }
                if(obj.amendDocReq1IsModifiedS2j()) {  _sql.append("AMEND_DOC_REQ1").append(","); _dirtyCount++; }
                if(obj.amendAddCondition1IsModifiedS2j()) {  _sql.append("AMEND_ADD_CONDITION1").append(","); _dirtyCount++; }
                if(obj.amendChrgPayable1IsModifiedS2j()) {  _sql.append("AMEND_CHRG_PAYABLE1").append(","); _dirtyCount++; }
                if(obj.amendChrgPayable2IsModifiedS2j()) {  _sql.append("AMEND_CHRG_PAYABLE2").append(","); _dirtyCount++; }
                if(obj.amendChrgPayable3IsModifiedS2j()) {  _sql.append("AMEND_CHRG_PAYABLE3").append(","); _dirtyCount++; }
                if(obj.amendChrgPayable4IsModifiedS2j()) {  _sql.append("AMEND_CHRG_PAYABLE4").append(","); _dirtyCount++; }
                if(obj.amendChrgPayable5IsModifiedS2j()) {  _sql.append("AMEND_CHRG_PAYABLE5").append(","); _dirtyCount++; }
                if(obj.amendChrgPayable6IsModifiedS2j()) {  _sql.append("AMEND_CHRG_PAYABLE6").append(","); _dirtyCount++; }
                if(obj.amendSndrRecInfo1IsModifiedS2j()) {  _sql.append("AMEND_SNDR_REC_INFO1").append(","); _dirtyCount++; }
                if(obj.amendSndrRecInfo2IsModifiedS2j()) {  _sql.append("AMEND_SNDR_REC_INFO2").append(","); _dirtyCount++; }
                if(obj.amendSndrRecInfo3IsModifiedS2j()) {  _sql.append("AMEND_SNDR_REC_INFO3").append(","); _dirtyCount++; }
                if(obj.amendSndrRecInfo4IsModifiedS2j()) {  _sql.append("AMEND_SNDR_REC_INFO4").append(","); _dirtyCount++; }
                if(obj.amendSndrRecInfo5IsModifiedS2j()) {  _sql.append("AMEND_SNDR_REC_INFO5").append(","); _dirtyCount++; }
                if(obj.amendSndrRecInfo6IsModifiedS2j()) {  _sql.append("AMEND_SNDR_REC_INFO6").append(","); _dirtyCount++; }
                if(obj.amendChkboxIsModifiedS2j()) {  _sql.append("AMEND_CHKBOX").append(","); _dirtyCount++; }
                if(obj.amendIssuingCntryIsModifiedS2j()) {  _sql.append("AMEND_ISSUING_CNTRY").append(","); _dirtyCount++; }
                if(obj.amendAdvisingCntryIsModifiedS2j()) {  _sql.append("AMEND_ADVISING_CNTRY").append(","); _dirtyCount++; }
                if(obj.amendSecondAdvCntryIsModifiedS2j()) {  _sql.append("AMEND_SECOND_ADV_CNTRY").append(","); _dirtyCount++; }
                if(obj.amendIssueRefIsModifiedS2j()) {  _sql.append("AMEND_ISSUE_REF").append(","); _dirtyCount++; }
                if(obj.amendFormOfDocCreditIsModifiedS2j()) {  _sql.append("AMEND_FORM_OF_DOC_CREDIT").append(","); _dirtyCount++; }
                if(obj.amendLcApplicableRulesIsModifiedS2j()) {  _sql.append("AMEND_LC_APPLICABLE_RULES").append(","); _dirtyCount++; }
                if(obj.amendLcApplicantReqIsModifiedS2j()) {  _sql.append("AMEND_LC_APPLICANT_REQ").append(","); _dirtyCount++; }
                if(obj.amendLcApplicantNameIsModifiedS2j()) {  _sql.append("AMEND_LC_APPLICANT_NAME").append(","); _dirtyCount++; }
                if(obj.amendLcApplicantAddr1IsModifiedS2j()) {  _sql.append("AMEND_LC_APPLICANT_ADDR1").append(","); _dirtyCount++; }
                if(obj.amendLcApplicantAddr2IsModifiedS2j()) {  _sql.append("AMEND_LC_APPLICANT_ADDR2").append(","); _dirtyCount++; }
                if(obj.amendLcApplicantAddr3IsModifiedS2j()) {  _sql.append("AMEND_LC_APPLICANT_ADDR3").append(","); _dirtyCount++; }
                if(obj.amendLcApplicantAddr4IsModifiedS2j()) {  _sql.append("AMEND_LC_APPLICANT_ADDR4").append(","); _dirtyCount++; }
                if(obj.amendLcApplicantAddr5IsModifiedS2j()) {  _sql.append("AMEND_LC_APPLICANT_ADDR5").append(","); _dirtyCount++; }
                if(obj.amendLcAvlWithTypeIsModifiedS2j()) {  _sql.append("AMEND_LC_AVL_WITH_TYPE").append(","); _dirtyCount++; }
                if(obj.amendLcAvlWithBrnCodeIsModifiedS2j()) {  _sql.append("AMEND_LC_AVL_WITH_BRN_CODE").append(","); _dirtyCount++; }
                if(obj.amendLcAvlWithBicCodeIsModifiedS2j()) {  _sql.append("AMEND_LC_AVL_WITH_BIC_CODE").append(","); _dirtyCount++; }
                if(obj.amendLcLcAvlWithRoutidIsModifiedS2j()) {  _sql.append("AMEND_LC_LC_AVL_WITH_ROUTID").append(","); _dirtyCount++; }
                if(obj.amendLcAvlWithBnkCodeIsModifiedS2j()) {  _sql.append("AMEND_LC_AVL_WITH_BNK_CODE").append(","); _dirtyCount++; }
                if(obj.amendLcAvlWithAddr1IsModifiedS2j()) {  _sql.append("AMEND_LC_AVL_WITH_ADDR1").append(","); _dirtyCount++; }
                if(obj.amendLcAvlWithAddr2IsModifiedS2j()) {  _sql.append("AMEND_LC_AVL_WITH_ADDR2").append(","); _dirtyCount++; }
                if(obj.amendLcAvlWithAddr3IsModifiedS2j()) {  _sql.append("AMEND_LC_AVL_WITH_ADDR3").append(","); _dirtyCount++; }
                if(obj.amendLcAvlWithAddr4IsModifiedS2j()) {  _sql.append("AMEND_LC_AVL_WITH_ADDR4").append(","); _dirtyCount++; }
                if(obj.amendLcAvlWithAddr5IsModifiedS2j()) {  _sql.append("AMEND_LC_AVL_WITH_ADDR5").append(","); _dirtyCount++; }
                if(obj.amendLcAvlWithCntryIsModifiedS2j()) {  _sql.append("AMEND_LC_AVL_WITH_CNTRY").append(","); _dirtyCount++; }
                if(obj.amendLcDraftsAt1IsModifiedS2j()) {  _sql.append("AMEND_LC_DRAFTS_AT1").append(","); _dirtyCount++; }
                if(obj.amendLcDraftsAt2IsModifiedS2j()) {  _sql.append("AMEND_LC_DRAFTS_AT2").append(","); _dirtyCount++; }
                if(obj.amendLcDraftsAt3IsModifiedS2j()) {  _sql.append("AMEND_LC_DRAFTS_AT3").append(","); _dirtyCount++; }
                if(obj.amendLcDraweeReqIsModifiedS2j()) {  _sql.append("AMEND_LC_DRAWEE_REQ").append(","); _dirtyCount++; }
                if(obj.amendLcDraweeTypeIsModifiedS2j()) {  _sql.append("AMEND_LC_DRAWEE_TYPE").append(","); _dirtyCount++; }
                if(obj.amendLcDraweeBrnCodeIsModifiedS2j()) {  _sql.append("AMEND_LC_DRAWEE_BRN_CODE").append(","); _dirtyCount++; }
                if(obj.amendLcDraweeBicCodeIsModifiedS2j()) {  _sql.append("AMEND_LC_DRAWEE_BIC_CODE").append(","); _dirtyCount++; }
                if(obj.amendLcDraweeRoutidIsModifiedS2j()) {  _sql.append("AMEND_LC_DRAWEE_ROUTID").append(","); _dirtyCount++; }
                if(obj.amendLcDraweeBnkCodeIsModifiedS2j()) {  _sql.append("AMEND_LC_DRAWEE_BNK_CODE").append(","); _dirtyCount++; }
                if(obj.amendLcDraweeAddr1IsModifiedS2j()) {  _sql.append("AMEND_LC_DRAWEE_ADDR1").append(","); _dirtyCount++; }
                if(obj.amendLcDraweeAddr2IsModifiedS2j()) {  _sql.append("AMEND_LC_DRAWEE_ADDR2").append(","); _dirtyCount++; }
                if(obj.amendLcDraweeAddr3IsModifiedS2j()) {  _sql.append("AMEND_LC_DRAWEE_ADDR3").append(","); _dirtyCount++; }
                if(obj.amendLcDraweeAddr4IsModifiedS2j()) {  _sql.append("AMEND_LC_DRAWEE_ADDR4").append(","); _dirtyCount++; }
                if(obj.amendLcDraweeAddr5IsModifiedS2j()) {  _sql.append("AMEND_LC_DRAWEE_ADDR5").append(","); _dirtyCount++; }
                if(obj.amendDraweeCntryCodeIsModifiedS2j()) {  _sql.append("AMEND_DRAWEE_CNTRY_CODE").append(","); _dirtyCount++; }
                if(obj.amendLcMixedPayDetails1IsModifiedS2j()) {  _sql.append("AMEND_LC_MIXED_PAY_DETAILS1").append(","); _dirtyCount++; }
                if(obj.amendLcMixedPayDetails2IsModifiedS2j()) {  _sql.append("AMEND_LC_MIXED_PAY_DETAILS2").append(","); _dirtyCount++; }
                if(obj.amendLcMixedPayDetails3IsModifiedS2j()) {  _sql.append("AMEND_LC_MIXED_PAY_DETAILS3").append(","); _dirtyCount++; }
                if(obj.amendLcMixedPayDetails4IsModifiedS2j()) {  _sql.append("AMEND_LC_MIXED_PAY_DETAILS4").append(","); _dirtyCount++; }
                if(obj.amendLcMixedPayDetails5IsModifiedS2j()) {  _sql.append("AMEND_LC_MIXED_PAY_DETAILS5").append(","); _dirtyCount++; }
                if(obj.amendLcDeferredPayDetails1IsModifiedS2j()) {  _sql.append("AMEND_LC_DEFERRED_PAY_DETAILS1").append(","); _dirtyCount++; }
                if(obj.amendLcDeferredPayDetails2IsModifiedS2j()) {  _sql.append("AMEND_LC_DEFERRED_PAY_DETAILS2").append(","); _dirtyCount++; }
                if(obj.amendLcDeferredPayDetails3IsModifiedS2j()) {  _sql.append("AMEND_LC_DEFERRED_PAY_DETAILS3").append(","); _dirtyCount++; }
                if(obj.amendLcDeferredPayDetails4IsModifiedS2j()) {  _sql.append("AMEND_LC_DEFERRED_PAY_DETAILS4").append(","); _dirtyCount++; }
                if(obj.amendLcDeferredPayDetails5IsModifiedS2j()) {  _sql.append("AMEND_LC_DEFERRED_PAY_DETAILS5").append(","); _dirtyCount++; }
                if(obj.amendLcPartialShipmentsIsModifiedS2j()) {  _sql.append("AMEND_LC_PARTIAL_SHIPMENTS").append(","); _dirtyCount++; }
                if(obj.amendLcTranshipmentIsModifiedS2j()) {  _sql.append("AMEND_LC_TRANSHIPMENT").append(","); _dirtyCount++; }
                if(obj.amendLcConfirmationInstIsModifiedS2j()) {  _sql.append("AMEND_LC_CONFIRMATION_INST").append(","); _dirtyCount++; }
                if(obj.amendLcReimbReqIsModifiedS2j()) {  _sql.append("AMEND_LC_REIMB_REQ").append(","); _dirtyCount++; }
                if(obj.amendLcReimbTypeIsModifiedS2j()) {  _sql.append("AMEND_LC_REIMB_TYPE").append(","); _dirtyCount++; }
                if(obj.amendLcReimbBrnCodeIsModifiedS2j()) {  _sql.append("AMEND_LC_REIMB_BRN_CODE").append(","); _dirtyCount++; }
                if(obj.amendLcReimbBicCodeIsModifiedS2j()) {  _sql.append("AMEND_LC_REIMB_BIC_CODE").append(","); _dirtyCount++; }
                if(obj.amendLcReimbRoutidIsModifiedS2j()) {  _sql.append("AMEND_LC_REIMB_ROUTID").append(","); _dirtyCount++; }
                if(obj.amendLcReimbBnkCodeIsModifiedS2j()) {  _sql.append("AMEND_LC_REIMB_BNK_CODE").append(","); _dirtyCount++; }
                if(obj.amendLcReimbAddr1IsModifiedS2j()) {  _sql.append("AMEND_LC_REIMB_ADDR1").append(","); _dirtyCount++; }
                if(obj.amendLcReimbAddr2IsModifiedS2j()) {  _sql.append("AMEND_LC_REIMB_ADDR2").append(","); _dirtyCount++; }
                if(obj.amendLcReimbAddr3IsModifiedS2j()) {  _sql.append("AMEND_LC_REIMB_ADDR3").append(","); _dirtyCount++; }
                if(obj.amendLcReimbAddr4IsModifiedS2j()) {  _sql.append("AMEND_LC_REIMB_ADDR4").append(","); _dirtyCount++; }
                if(obj.amendLcReimbAddr5IsModifiedS2j()) {  _sql.append("AMEND_LC_REIMB_ADDR5").append(","); _dirtyCount++; }
                if(obj.amendLcInstPaying1IsModifiedS2j()) {  _sql.append("AMEND_LC_INST_PAYING1").append(","); _dirtyCount++; }
                if(obj.amendLcInstPaying2IsModifiedS2j()) {  _sql.append("AMEND_LC_INST_PAYING2").append(","); _dirtyCount++; }
                if(obj.amendLcInstPaying3IsModifiedS2j()) {  _sql.append("AMEND_LC_INST_PAYING3").append(","); _dirtyCount++; }
                if(obj.amendLcInstPaying4IsModifiedS2j()) {  _sql.append("AMEND_LC_INST_PAYING4").append(","); _dirtyCount++; }
                if(obj.amendLcInstPaying5IsModifiedS2j()) {  _sql.append("AMEND_LC_INST_PAYING5").append(","); _dirtyCount++; }
                if(obj.amendLcInstPaying6IsModifiedS2j()) {  _sql.append("AMEND_LC_INST_PAYING6").append(","); _dirtyCount++; }
                if(obj.amendLcInstPaying7IsModifiedS2j()) {  _sql.append("AMEND_LC_INST_PAYING7").append(","); _dirtyCount++; }
                if(obj.amendLcInstPaying8IsModifiedS2j()) {  _sql.append("AMEND_LC_INST_PAYING8").append(","); _dirtyCount++; }
                if(obj.amendLcInstPaying9IsModifiedS2j()) {  _sql.append("AMEND_LC_INST_PAYING9").append(","); _dirtyCount++; }
                if(obj.amendLcInstPaying10IsModifiedS2j()) {  _sql.append("AMEND_LC_INST_PAYING10").append(","); _dirtyCount++; }
                if(obj.amendLcInstPaying11IsModifiedS2j()) {  _sql.append("AMEND_LC_INST_PAYING11").append(","); _dirtyCount++; }
                if(obj.amendLcInstPaying12IsModifiedS2j()) {  _sql.append("AMEND_LC_INST_PAYING12").append(","); _dirtyCount++; }
                if(obj.amendLcSecondAdvReqIsModifiedS2j()) {  _sql.append("AMEND_LC_SECOND_ADV_REQ").append(","); _dirtyCount++; }
                if(obj.amendLcSecondAdvTypeIsModifiedS2j()) {  _sql.append("AMEND_LC_SECOND_ADV_TYPE").append(","); _dirtyCount++; }
                if(obj.amendLcSecondAdvBrnCodeIsModifiedS2j()) {  _sql.append("AMEND_LC_SECOND_ADV_BRN_CODE").append(","); _dirtyCount++; }
                if(obj.amendLcSecondAdvBicCodeIsModifiedS2j()) {  _sql.append("AMEND_LC_SECOND_ADV_BIC_CODE").append(","); _dirtyCount++; }
                if(obj.amendLcSecondAdvRoutidIsModifiedS2j()) {  _sql.append("AMEND_LC_SECOND_ADV_ROUTID").append(","); _dirtyCount++; }
                if(obj.amendLcSecondAdvBnkCodeIsModifiedS2j()) {  _sql.append("AMEND_LC_SECOND_ADV_BNK_CODE").append(","); _dirtyCount++; }
                if(obj.amendLcSecondAdvAddr1IsModifiedS2j()) {  _sql.append("AMEND_LC_SECOND_ADV_ADDR1").append(","); _dirtyCount++; }
                if(obj.amendLcSecondAdvAddr2IsModifiedS2j()) {  _sql.append("AMEND_LC_SECOND_ADV_ADDR2").append(","); _dirtyCount++; }
                if(obj.amendLcSecondAdvAddr3IsModifiedS2j()) {  _sql.append("AMEND_LC_SECOND_ADV_ADDR3").append(","); _dirtyCount++; }
                if(obj.amendLcSecondAdvAddr4IsModifiedS2j()) {  _sql.append("AMEND_LC_SECOND_ADV_ADDR4").append(","); _dirtyCount++; }
                if(obj.amendLcSecondAdvAddr5IsModifiedS2j()) {  _sql.append("AMEND_LC_SECOND_ADV_ADDR5").append(","); _dirtyCount++; }
                if(obj.amendLcSecondAdvCntrycodeIsModifiedS2j()) {  _sql.append("AMEND_LC_SECOND_ADV_CNTRYCODE").append(","); _dirtyCount++; }
                if(obj.amendLcAvlWithCodetypIsModifiedS2j()) {  _sql.append("AMEND_LC_AVL_WITH_CODETYP").append(","); _dirtyCount++; }
                if(obj.amendLcReimbCntryCodeIsModifiedS2j()) {  _sql.append("AMEND_LC_REIMB_CNTRY_CODE").append(","); _dirtyCount++; }
                if(obj.amendLcCnfAdvTypeIsModifiedS2j()) {  _sql.append("AMEND_LC_CNF_ADV_TYPE").append(","); _dirtyCount++; }
                if(obj.amendLcCnfAdvBrnCodeIsModifiedS2j()) {  _sql.append("AMEND_LC_CNF_ADV_BRN_CODE").append(","); _dirtyCount++; }
                if(obj.amendLcCnfAdvBicCodeIsModifiedS2j()) {  _sql.append("AMEND_LC_CNF_ADV_BIC_CODE").append(","); _dirtyCount++; }
                if(obj.amendLcCnfAdvRoutidIsModifiedS2j()) {  _sql.append("AMEND_LC_CNF_ADV_ROUTID").append(","); _dirtyCount++; }
                if(obj.amendLcCnfAdvBnkCodeIsModifiedS2j()) {  _sql.append("AMEND_LC_CNF_ADV_BNK_CODE").append(","); _dirtyCount++; }
                if(obj.amendLcCnfAdvAddr1IsModifiedS2j()) {  _sql.append("AMEND_LC_CNF_ADV_ADDR1").append(","); _dirtyCount++; }
                if(obj.amendLcCnfAdvAddr2IsModifiedS2j()) {  _sql.append("AMEND_LC_CNF_ADV_ADDR2").append(","); _dirtyCount++; }
                if(obj.amendLcCnfAdvAddr3IsModifiedS2j()) {  _sql.append("AMEND_LC_CNF_ADV_ADDR3").append(","); _dirtyCount++; }
                if(obj.amendLcCnfAdvAddr4IsModifiedS2j()) {  _sql.append("AMEND_LC_CNF_ADV_ADDR4").append(","); _dirtyCount++; }
                if(obj.amendLcCnfAdvAddr5IsModifiedS2j()) {  _sql.append("AMEND_LC_CNF_ADV_ADDR5").append(","); _dirtyCount++; }
                if(obj.amendLcCnfAdvCntrycodeIsModifiedS2j()) {  _sql.append("AMEND_LC_CNF_ADV_CNTRYCODE").append(","); _dirtyCount++; }
                _sql.setLength(_sql.length() - 1);
                _sql.append(") values (" );
                for(int i = 0; i < _dirtyCount; i++) _sql.append("?,");
                _sql.setLength(_sql.length() - 1);
                _sql.append(")");

                _pstmt = _conn.prepareStatement(_sql.toString());
                _dirtyCount = 0;
                if(obj.amendLcBrnCodeIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendLcBrnCode()); } 
                if(obj.amendLcTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcType()); } 
                if(obj.amendLcYearIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendLcYear()); } 
                if(obj.amendLcSerialIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendLcSerial()); } 
                if(obj.amendLcAmdSlIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendLcAmdSl()); } 
                if(obj.amendSndrRefIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendSndrRef()); } 
                if(obj.amendRcvrRefIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendRcvrRef()); } 
                if(obj.amendDocCrNumIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendDocCrNum()); } 
                if(obj.amendIssuingBnkReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendIssuingBnkReq())); } 
                if(obj.amendIssuingTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendIssuingType())); } 
                if(obj.amendIssuingBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendIssuingBrnCode()); } 
                if(obj.amendIssuingBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendIssuingBicCode()); } 
                if(obj.amendIssuingRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendIssuingRoutid()); } 
                if(obj.amendIssuingBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendIssuingBnkCode()); } 
                if(obj.amendIssuingAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendIssuingAddr1()); } 
                if(obj.amendIssuingAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendIssuingAddr2()); } 
                if(obj.amendIssuingAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendIssuingAddr3()); } 
                if(obj.amendIssuingAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendIssuingAddr4()); } 
                if(obj.amendIssuingAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendIssuingAddr5()); } 
                if(obj.amendNonBnkIssurIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendNonBnkIssur()); } 
                if(obj.amendDateOfIssueIsModifiedS2j()) { if (obj.getAmendDateOfIssue() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getAmendDateOfIssue().getTime()));} } 
                if(obj.amendDateOfAmendmentIsModifiedS2j()) { if (obj.getAmendDateOfAmendment() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getAmendDateOfAmendment().getTime()));} } 
                if(obj.amendPurposeOfMsgIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendPurposeOfMsg())); } 
                if(obj.amendCancelRequestIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendCancelRequest()); } 
                if(obj.amendAdvisingBnkReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendAdvisingBnkReq())); } 
                if(obj.amendAdvisingBnkTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendAdvisingBnkType())); } 
                if(obj.amendAdvisingBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendAdvisingBrnCode()); } 
                if(obj.amendAdvisingBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendAdvisingBicCode()); } 
                if(obj.amendAdvisingRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendAdvisingRoutid()); } 
                if(obj.amendAdvisingBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendAdvisingBnkCode()); } 
                if(obj.amendAdvisingAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendAdvisingAddr1()); } 
                if(obj.amendAdvisingAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendAdvisingAddr2()); } 
                if(obj.amendAdvisingAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendAdvisingAddr3()); } 
                if(obj.amendAdvisingAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendAdvisingAddr4()); } 
                if(obj.amendAdvisingAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendAdvisingAddr5()); } 
                if(obj.amendSecondAdvReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendSecondAdvReq())); } 
                if(obj.amendSecondAdvTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendSecondAdvType())); } 
                if(obj.amendSecondAdvBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendSecondAdvBrnCode()); } 
                if(obj.amendSecondAdvBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendSecondAdvBicCode()); } 
                if(obj.amendSecondAdvRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendSecondAdvRoutid()); } 
                if(obj.amendSecondAdvBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendSecondAdvBnkCode()); } 
                if(obj.amendSecondAdvAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendSecondAdvAddr1()); } 
                if(obj.amendSecondAdvAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendSecondAdvAddr2()); } 
                if(obj.amendSecondAdvAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendSecondAdvAddr3()); } 
                if(obj.amendSecondAdvAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendSecondAdvAddr4()); } 
                if(obj.amendSecondAdvAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendSecondAdvAddr5()); } 
                if(obj.amendNewBeneficiaryIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendNewBeneficiary()); } 
                if(obj.amendNewDateOfExpiryIsModifiedS2j()) { if (obj.getAmendNewDateOfExpiry() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getAmendNewDateOfExpiry().getTime()));} } 
                if(obj.amendIncrDocCrAmtIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendIncrDocCrAmt()); } 
                if(obj.amendDecrDocCrAmtIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendDecrDocCrAmt()); } 
                if(obj.amendNewAddnlAmtIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendNewAddnlAmt()); } 
                if(obj.amendPlaceTakinInChrgIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendPlaceTakinInChrg()); } 
                if(obj.amendPortOfLoadingIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendPortOfLoading()); } 
                if(obj.amendPortOfDischargeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendPortOfDischarge()); } 
                if(obj.amendPlaceOfFinalDestIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendPlaceOfFinalDest()); } 
                if(obj.amendDateOfShipmentIsModifiedS2j()) { if (obj.getAmendDateOfShipment() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getAmendDateOfShipment().getTime()));} } 
                if(obj.amendDescGoddSer1IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getAmendDescGoddSer1()); } 
                if(obj.amendDocReq1IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getAmendDocReq1()); } 
                if(obj.amendAddCondition1IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getAmendAddCondition1()); } 
                if(obj.amendChrgPayable1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendChrgPayable1()); } 
                if(obj.amendChrgPayable2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendChrgPayable2()); } 
                if(obj.amendChrgPayable3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendChrgPayable3()); } 
                if(obj.amendChrgPayable4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendChrgPayable4()); } 
                if(obj.amendChrgPayable5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendChrgPayable5()); } 
                if(obj.amendChrgPayable6IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendChrgPayable6()); } 
                if(obj.amendSndrRecInfo1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendSndrRecInfo1()); } 
                if(obj.amendSndrRecInfo2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendSndrRecInfo2()); } 
                if(obj.amendSndrRecInfo3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendSndrRecInfo3()); } 
                if(obj.amendSndrRecInfo4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendSndrRecInfo4()); } 
                if(obj.amendSndrRecInfo5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendSndrRecInfo5()); } 
                if(obj.amendSndrRecInfo6IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendSndrRecInfo6()); } 
                if(obj.amendChkboxIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendChkbox()); } 
                if(obj.amendIssuingCntryIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendIssuingCntry()); } 
                if(obj.amendAdvisingCntryIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendAdvisingCntry()); } 
                if(obj.amendSecondAdvCntryIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendSecondAdvCntry()); } 
                if(obj.amendIssueRefIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendIssueRef()); } 
                if(obj.amendFormOfDocCreditIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendFormOfDocCredit()); } 
                if(obj.amendLcApplicableRulesIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendLcApplicableRules()); } 
                if(obj.amendLcApplicantReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendLcApplicantReq())); } 
                if(obj.amendLcApplicantNameIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcApplicantName()); } 
                if(obj.amendLcApplicantAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcApplicantAddr1()); } 
                if(obj.amendLcApplicantAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcApplicantAddr2()); } 
                if(obj.amendLcApplicantAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcApplicantAddr3()); } 
                if(obj.amendLcApplicantAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcApplicantAddr4()); } 
                if(obj.amendLcApplicantAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcApplicantAddr5()); } 
                if(obj.amendLcAvlWithTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendLcAvlWithType())); } 
                if(obj.amendLcAvlWithBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcAvlWithBrnCode()); } 
                if(obj.amendLcAvlWithBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcAvlWithBicCode()); } 
                if(obj.amendLcLcAvlWithRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcLcAvlWithRoutid()); } 
                if(obj.amendLcAvlWithBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcAvlWithBnkCode()); } 
                if(obj.amendLcAvlWithAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcAvlWithAddr1()); } 
                if(obj.amendLcAvlWithAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcAvlWithAddr2()); } 
                if(obj.amendLcAvlWithAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcAvlWithAddr3()); } 
                if(obj.amendLcAvlWithAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcAvlWithAddr4()); } 
                if(obj.amendLcAvlWithAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcAvlWithAddr5()); } 
                if(obj.amendLcAvlWithCntryIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcAvlWithCntry()); } 
                if(obj.amendLcDraftsAt1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcDraftsAt1()); } 
                if(obj.amendLcDraftsAt2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcDraftsAt2()); } 
                if(obj.amendLcDraftsAt3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcDraftsAt3()); } 
                if(obj.amendLcDraweeReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendLcDraweeReq())); } 
                if(obj.amendLcDraweeTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendLcDraweeType())); } 
                if(obj.amendLcDraweeBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcDraweeBrnCode()); } 
                if(obj.amendLcDraweeBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcDraweeBicCode()); } 
                if(obj.amendLcDraweeRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcDraweeRoutid()); } 
                if(obj.amendLcDraweeBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcDraweeBnkCode()); } 
                if(obj.amendLcDraweeAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcDraweeAddr1()); } 
                if(obj.amendLcDraweeAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcDraweeAddr2()); } 
                if(obj.amendLcDraweeAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcDraweeAddr3()); } 
                if(obj.amendLcDraweeAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcDraweeAddr4()); } 
                if(obj.amendLcDraweeAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcDraweeAddr5()); } 
                if(obj.amendDraweeCntryCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendDraweeCntryCode()); } 
                if(obj.amendLcMixedPayDetails1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcMixedPayDetails1()); } 
                if(obj.amendLcMixedPayDetails2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcMixedPayDetails2()); } 
                if(obj.amendLcMixedPayDetails3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcMixedPayDetails3()); } 
                if(obj.amendLcMixedPayDetails4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcMixedPayDetails4()); } 
                if(obj.amendLcMixedPayDetails5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcMixedPayDetails5()); } 
                if(obj.amendLcDeferredPayDetails1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcDeferredPayDetails1()); } 
                if(obj.amendLcDeferredPayDetails2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcDeferredPayDetails2()); } 
                if(obj.amendLcDeferredPayDetails3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcDeferredPayDetails3()); } 
                if(obj.amendLcDeferredPayDetails4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcDeferredPayDetails4()); } 
                if(obj.amendLcDeferredPayDetails5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcDeferredPayDetails5()); } 
                if(obj.amendLcPartialShipmentsIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendLcPartialShipments()); } 
                if(obj.amendLcTranshipmentIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendLcTranshipment()); } 
                if(obj.amendLcConfirmationInstIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendLcConfirmationInst()); } 
                if(obj.amendLcReimbReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendLcReimbReq())); } 
                if(obj.amendLcReimbTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendLcReimbType())); } 
                if(obj.amendLcReimbBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcReimbBrnCode()); } 
                if(obj.amendLcReimbBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcReimbBicCode()); } 
                if(obj.amendLcReimbRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcReimbRoutid()); } 
                if(obj.amendLcReimbBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcReimbBnkCode()); } 
                if(obj.amendLcReimbAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcReimbAddr1()); } 
                if(obj.amendLcReimbAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcReimbAddr2()); } 
                if(obj.amendLcReimbAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcReimbAddr3()); } 
                if(obj.amendLcReimbAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcReimbAddr4()); } 
                if(obj.amendLcReimbAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcReimbAddr5()); } 
                if(obj.amendLcInstPaying1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcInstPaying1()); } 
                if(obj.amendLcInstPaying2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcInstPaying2()); } 
                if(obj.amendLcInstPaying3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcInstPaying3()); } 
                if(obj.amendLcInstPaying4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcInstPaying4()); } 
                if(obj.amendLcInstPaying5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcInstPaying5()); } 
                if(obj.amendLcInstPaying6IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcInstPaying6()); } 
                if(obj.amendLcInstPaying7IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcInstPaying7()); } 
                if(obj.amendLcInstPaying8IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcInstPaying8()); } 
                if(obj.amendLcInstPaying9IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcInstPaying9()); } 
                if(obj.amendLcInstPaying10IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcInstPaying10()); } 
                if(obj.amendLcInstPaying11IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcInstPaying11()); } 
                if(obj.amendLcInstPaying12IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcInstPaying12()); } 
                if(obj.amendLcSecondAdvReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendLcSecondAdvReq())); } 
                if(obj.amendLcSecondAdvTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendLcSecondAdvType())); } 
                if(obj.amendLcSecondAdvBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcSecondAdvBrnCode()); } 
                if(obj.amendLcSecondAdvBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcSecondAdvBicCode()); } 
                if(obj.amendLcSecondAdvRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcSecondAdvRoutid()); } 
                if(obj.amendLcSecondAdvBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcSecondAdvBnkCode()); } 
                if(obj.amendLcSecondAdvAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcSecondAdvAddr1()); } 
                if(obj.amendLcSecondAdvAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcSecondAdvAddr2()); } 
                if(obj.amendLcSecondAdvAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcSecondAdvAddr3()); } 
                if(obj.amendLcSecondAdvAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcSecondAdvAddr4()); } 
                if(obj.amendLcSecondAdvAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcSecondAdvAddr5()); } 
                if(obj.amendLcSecondAdvCntrycodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcSecondAdvCntrycode()); } 
                if(obj.amendLcAvlWithCodetypIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendLcAvlWithCodetyp())); } 
                if(obj.amendLcReimbCntryCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcReimbCntryCode()); } 
                if(obj.amendLcCnfAdvTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendLcCnfAdvType())); } 
                if(obj.amendLcCnfAdvBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcCnfAdvBrnCode()); } 
                if(obj.amendLcCnfAdvBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcCnfAdvBicCode()); } 
                if(obj.amendLcCnfAdvRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcCnfAdvRoutid()); } 
                if(obj.amendLcCnfAdvBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcCnfAdvBnkCode()); } 
                if(obj.amendLcCnfAdvAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcCnfAdvAddr1()); } 
                if(obj.amendLcCnfAdvAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcCnfAdvAddr2()); } 
                if(obj.amendLcCnfAdvAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcCnfAdvAddr3()); } 
                if(obj.amendLcCnfAdvAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcCnfAdvAddr4()); } 
                if(obj.amendLcCnfAdvAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcCnfAdvAddr5()); } 
                if(obj.amendLcCnfAdvCntrycodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcCnfAdvCntrycode()); } 
                _pstmt.executeUpdate();
                obj.setIsNew(false);
                obj.resetIsModifiedS2J();
            }
            else {
                StringBuffer _sql = new StringBuffer("UPDATE AMEND_DETAILS SET ");
                if(obj.amendLcBrnCodeIsModifiedS2j()) {  _sql.append("AMEND_LC_BRN_CODE").append("=?,"); }
                if(obj.amendLcTypeIsModifiedS2j()) {  _sql.append("AMEND_LC_TYPE").append("=?,"); }
                if(obj.amendLcYearIsModifiedS2j()) {  _sql.append("AMEND_LC_YEAR").append("=?,"); }
                if(obj.amendLcSerialIsModifiedS2j()) {  _sql.append("AMEND_LC_SERIAL").append("=?,"); }
                if(obj.amendLcAmdSlIsModifiedS2j()) {  _sql.append("AMEND_LC_AMD_SL").append("=?,"); }
                if(obj.amendSndrRefIsModifiedS2j()) {  _sql.append("AMEND_SNDR_REF").append("=?,"); }
                if(obj.amendRcvrRefIsModifiedS2j()) {  _sql.append("AMEND_RCVR_REF").append("=?,"); }
                if(obj.amendDocCrNumIsModifiedS2j()) {  _sql.append("AMEND_DOC_CR_NUM").append("=?,"); }
                if(obj.amendIssuingBnkReqIsModifiedS2j()) {  _sql.append("AMEND_ISSUING_BNK_REQ").append("=?,"); }
                if(obj.amendIssuingTypeIsModifiedS2j()) {  _sql.append("AMEND_ISSUING_TYPE").append("=?,"); }
                if(obj.amendIssuingBrnCodeIsModifiedS2j()) {  _sql.append("AMEND_ISSUING_BRN_CODE").append("=?,"); }
                if(obj.amendIssuingBicCodeIsModifiedS2j()) {  _sql.append("AMEND_ISSUING_BIC_CODE").append("=?,"); }
                if(obj.amendIssuingRoutidIsModifiedS2j()) {  _sql.append("AMEND_ISSUING_ROUTID").append("=?,"); }
                if(obj.amendIssuingBnkCodeIsModifiedS2j()) {  _sql.append("AMEND_ISSUING_BNK_CODE").append("=?,"); }
                if(obj.amendIssuingAddr1IsModifiedS2j()) {  _sql.append("AMEND_ISSUING_ADDR1").append("=?,"); }
                if(obj.amendIssuingAddr2IsModifiedS2j()) {  _sql.append("AMEND_ISSUING_ADDR2").append("=?,"); }
                if(obj.amendIssuingAddr3IsModifiedS2j()) {  _sql.append("AMEND_ISSUING_ADDR3").append("=?,"); }
                if(obj.amendIssuingAddr4IsModifiedS2j()) {  _sql.append("AMEND_ISSUING_ADDR4").append("=?,"); }
                if(obj.amendIssuingAddr5IsModifiedS2j()) {  _sql.append("AMEND_ISSUING_ADDR5").append("=?,"); }
                if(obj.amendNonBnkIssurIsModifiedS2j()) {  _sql.append("AMEND_NON_BNK_ISSUR").append("=?,"); }
                if(obj.amendDateOfIssueIsModifiedS2j()) {  _sql.append("AMEND_DATE_OF_ISSUE").append("=?,"); }
                if(obj.amendDateOfAmendmentIsModifiedS2j()) {  _sql.append("AMEND_DATE_OF_AMENDMENT").append("=?,"); }
                if(obj.amendPurposeOfMsgIsModifiedS2j()) {  _sql.append("AMEND_PURPOSE_OF_MSG").append("=?,"); }
                if(obj.amendCancelRequestIsModifiedS2j()) {  _sql.append("AMEND_CANCEL_REQUEST").append("=?,"); }
                if(obj.amendAdvisingBnkReqIsModifiedS2j()) {  _sql.append("AMEND_ADVISING_BNK_REQ").append("=?,"); }
                if(obj.amendAdvisingBnkTypeIsModifiedS2j()) {  _sql.append("AMEND_ADVISING_BNK_TYPE").append("=?,"); }
                if(obj.amendAdvisingBrnCodeIsModifiedS2j()) {  _sql.append("AMEND_ADVISING_BRN_CODE").append("=?,"); }
                if(obj.amendAdvisingBicCodeIsModifiedS2j()) {  _sql.append("AMEND_ADVISING_BIC_CODE").append("=?,"); }
                if(obj.amendAdvisingRoutidIsModifiedS2j()) {  _sql.append("AMEND_ADVISING_ROUTID").append("=?,"); }
                if(obj.amendAdvisingBnkCodeIsModifiedS2j()) {  _sql.append("AMEND_ADVISING_BNK_CODE").append("=?,"); }
                if(obj.amendAdvisingAddr1IsModifiedS2j()) {  _sql.append("AMEND_ADVISING_ADDR1").append("=?,"); }
                if(obj.amendAdvisingAddr2IsModifiedS2j()) {  _sql.append("AMEND_ADVISING_ADDR2").append("=?,"); }
                if(obj.amendAdvisingAddr3IsModifiedS2j()) {  _sql.append("AMEND_ADVISING_ADDR3").append("=?,"); }
                if(obj.amendAdvisingAddr4IsModifiedS2j()) {  _sql.append("AMEND_ADVISING_ADDR4").append("=?,"); }
                if(obj.amendAdvisingAddr5IsModifiedS2j()) {  _sql.append("AMEND_ADVISING_ADDR5").append("=?,"); }
                if(obj.amendSecondAdvReqIsModifiedS2j()) {  _sql.append("AMEND_SECOND_ADV_REQ").append("=?,"); }
                if(obj.amendSecondAdvTypeIsModifiedS2j()) {  _sql.append("AMEND_SECOND_ADV_TYPE").append("=?,"); }
                if(obj.amendSecondAdvBrnCodeIsModifiedS2j()) {  _sql.append("AMEND_SECOND_ADV_BRN_CODE").append("=?,"); }
                if(obj.amendSecondAdvBicCodeIsModifiedS2j()) {  _sql.append("AMEND_SECOND_ADV_BIC_CODE").append("=?,"); }
                if(obj.amendSecondAdvRoutidIsModifiedS2j()) {  _sql.append("AMEND_SECOND_ADV_ROUTID").append("=?,"); }
                if(obj.amendSecondAdvBnkCodeIsModifiedS2j()) {  _sql.append("AMEND_SECOND_ADV_BNK_CODE").append("=?,"); }
                if(obj.amendSecondAdvAddr1IsModifiedS2j()) {  _sql.append("AMEND_SECOND_ADV_ADDR1").append("=?,"); }
                if(obj.amendSecondAdvAddr2IsModifiedS2j()) {  _sql.append("AMEND_SECOND_ADV_ADDR2").append("=?,"); }
                if(obj.amendSecondAdvAddr3IsModifiedS2j()) {  _sql.append("AMEND_SECOND_ADV_ADDR3").append("=?,"); }
                if(obj.amendSecondAdvAddr4IsModifiedS2j()) {  _sql.append("AMEND_SECOND_ADV_ADDR4").append("=?,"); }
                if(obj.amendSecondAdvAddr5IsModifiedS2j()) {  _sql.append("AMEND_SECOND_ADV_ADDR5").append("=?,"); }
                if(obj.amendNewBeneficiaryIsModifiedS2j()) {  _sql.append("AMEND_NEW_BENEFICIARY").append("=?,"); }
                if(obj.amendNewDateOfExpiryIsModifiedS2j()) {  _sql.append("AMEND_NEW_DATE_OF_EXPIRY").append("=?,"); }
                if(obj.amendIncrDocCrAmtIsModifiedS2j()) {  _sql.append("AMEND_INCR_DOC_CR_AMT").append("=?,"); }
                if(obj.amendDecrDocCrAmtIsModifiedS2j()) {  _sql.append("AMEND_DECR_DOC_CR_AMT").append("=?,"); }
                if(obj.amendNewAddnlAmtIsModifiedS2j()) {  _sql.append("AMEND_NEW_ADDNL_AMT").append("=?,"); }
                if(obj.amendPlaceTakinInChrgIsModifiedS2j()) {  _sql.append("AMEND_PLACE_TAKIN_IN_CHRG").append("=?,"); }
                if(obj.amendPortOfLoadingIsModifiedS2j()) {  _sql.append("AMEND_PORT_OF_LOADING").append("=?,"); }
                if(obj.amendPortOfDischargeIsModifiedS2j()) {  _sql.append("AMEND_PORT_OF_DISCHARGE").append("=?,"); }
                if(obj.amendPlaceOfFinalDestIsModifiedS2j()) {  _sql.append("AMEND_PLACE_OF_FINAL_DEST").append("=?,"); }
                if(obj.amendDateOfShipmentIsModifiedS2j()) {  _sql.append("AMEND_DATE_OF_SHIPMENT").append("=?,"); }
                if(obj.amendDescGoddSer1IsModifiedS2j()) {  _sql.append("AMEND_DESC_GODD_SER1").append("=?,"); }
                if(obj.amendDocReq1IsModifiedS2j()) {  _sql.append("AMEND_DOC_REQ1").append("=?,"); }
                if(obj.amendAddCondition1IsModifiedS2j()) {  _sql.append("AMEND_ADD_CONDITION1").append("=?,"); }
                if(obj.amendChrgPayable1IsModifiedS2j()) {  _sql.append("AMEND_CHRG_PAYABLE1").append("=?,"); }
                if(obj.amendChrgPayable2IsModifiedS2j()) {  _sql.append("AMEND_CHRG_PAYABLE2").append("=?,"); }
                if(obj.amendChrgPayable3IsModifiedS2j()) {  _sql.append("AMEND_CHRG_PAYABLE3").append("=?,"); }
                if(obj.amendChrgPayable4IsModifiedS2j()) {  _sql.append("AMEND_CHRG_PAYABLE4").append("=?,"); }
                if(obj.amendChrgPayable5IsModifiedS2j()) {  _sql.append("AMEND_CHRG_PAYABLE5").append("=?,"); }
                if(obj.amendChrgPayable6IsModifiedS2j()) {  _sql.append("AMEND_CHRG_PAYABLE6").append("=?,"); }
                if(obj.amendSndrRecInfo1IsModifiedS2j()) {  _sql.append("AMEND_SNDR_REC_INFO1").append("=?,"); }
                if(obj.amendSndrRecInfo2IsModifiedS2j()) {  _sql.append("AMEND_SNDR_REC_INFO2").append("=?,"); }
                if(obj.amendSndrRecInfo3IsModifiedS2j()) {  _sql.append("AMEND_SNDR_REC_INFO3").append("=?,"); }
                if(obj.amendSndrRecInfo4IsModifiedS2j()) {  _sql.append("AMEND_SNDR_REC_INFO4").append("=?,"); }
                if(obj.amendSndrRecInfo5IsModifiedS2j()) {  _sql.append("AMEND_SNDR_REC_INFO5").append("=?,"); }
                if(obj.amendSndrRecInfo6IsModifiedS2j()) {  _sql.append("AMEND_SNDR_REC_INFO6").append("=?,"); }
                if(obj.amendChkboxIsModifiedS2j()) {  _sql.append("AMEND_CHKBOX").append("=?,"); }
                if(obj.amendIssuingCntryIsModifiedS2j()) {  _sql.append("AMEND_ISSUING_CNTRY").append("=?,"); }
                if(obj.amendAdvisingCntryIsModifiedS2j()) {  _sql.append("AMEND_ADVISING_CNTRY").append("=?,"); }
                if(obj.amendSecondAdvCntryIsModifiedS2j()) {  _sql.append("AMEND_SECOND_ADV_CNTRY").append("=?,"); }
                if(obj.amendIssueRefIsModifiedS2j()) {  _sql.append("AMEND_ISSUE_REF").append("=?,"); }
                if(obj.amendFormOfDocCreditIsModifiedS2j()) {  _sql.append("AMEND_FORM_OF_DOC_CREDIT").append("=?,"); }
                if(obj.amendLcApplicableRulesIsModifiedS2j()) {  _sql.append("AMEND_LC_APPLICABLE_RULES").append("=?,"); }
                if(obj.amendLcApplicantReqIsModifiedS2j()) {  _sql.append("AMEND_LC_APPLICANT_REQ").append("=?,"); }
                if(obj.amendLcApplicantNameIsModifiedS2j()) {  _sql.append("AMEND_LC_APPLICANT_NAME").append("=?,"); }
                if(obj.amendLcApplicantAddr1IsModifiedS2j()) {  _sql.append("AMEND_LC_APPLICANT_ADDR1").append("=?,"); }
                if(obj.amendLcApplicantAddr2IsModifiedS2j()) {  _sql.append("AMEND_LC_APPLICANT_ADDR2").append("=?,"); }
                if(obj.amendLcApplicantAddr3IsModifiedS2j()) {  _sql.append("AMEND_LC_APPLICANT_ADDR3").append("=?,"); }
                if(obj.amendLcApplicantAddr4IsModifiedS2j()) {  _sql.append("AMEND_LC_APPLICANT_ADDR4").append("=?,"); }
                if(obj.amendLcApplicantAddr5IsModifiedS2j()) {  _sql.append("AMEND_LC_APPLICANT_ADDR5").append("=?,"); }
                if(obj.amendLcAvlWithTypeIsModifiedS2j()) {  _sql.append("AMEND_LC_AVL_WITH_TYPE").append("=?,"); }
                if(obj.amendLcAvlWithBrnCodeIsModifiedS2j()) {  _sql.append("AMEND_LC_AVL_WITH_BRN_CODE").append("=?,"); }
                if(obj.amendLcAvlWithBicCodeIsModifiedS2j()) {  _sql.append("AMEND_LC_AVL_WITH_BIC_CODE").append("=?,"); }
                if(obj.amendLcLcAvlWithRoutidIsModifiedS2j()) {  _sql.append("AMEND_LC_LC_AVL_WITH_ROUTID").append("=?,"); }
                if(obj.amendLcAvlWithBnkCodeIsModifiedS2j()) {  _sql.append("AMEND_LC_AVL_WITH_BNK_CODE").append("=?,"); }
                if(obj.amendLcAvlWithAddr1IsModifiedS2j()) {  _sql.append("AMEND_LC_AVL_WITH_ADDR1").append("=?,"); }
                if(obj.amendLcAvlWithAddr2IsModifiedS2j()) {  _sql.append("AMEND_LC_AVL_WITH_ADDR2").append("=?,"); }
                if(obj.amendLcAvlWithAddr3IsModifiedS2j()) {  _sql.append("AMEND_LC_AVL_WITH_ADDR3").append("=?,"); }
                if(obj.amendLcAvlWithAddr4IsModifiedS2j()) {  _sql.append("AMEND_LC_AVL_WITH_ADDR4").append("=?,"); }
                if(obj.amendLcAvlWithAddr5IsModifiedS2j()) {  _sql.append("AMEND_LC_AVL_WITH_ADDR5").append("=?,"); }
                if(obj.amendLcAvlWithCntryIsModifiedS2j()) {  _sql.append("AMEND_LC_AVL_WITH_CNTRY").append("=?,"); }
                if(obj.amendLcDraftsAt1IsModifiedS2j()) {  _sql.append("AMEND_LC_DRAFTS_AT1").append("=?,"); }
                if(obj.amendLcDraftsAt2IsModifiedS2j()) {  _sql.append("AMEND_LC_DRAFTS_AT2").append("=?,"); }
                if(obj.amendLcDraftsAt3IsModifiedS2j()) {  _sql.append("AMEND_LC_DRAFTS_AT3").append("=?,"); }
                if(obj.amendLcDraweeReqIsModifiedS2j()) {  _sql.append("AMEND_LC_DRAWEE_REQ").append("=?,"); }
                if(obj.amendLcDraweeTypeIsModifiedS2j()) {  _sql.append("AMEND_LC_DRAWEE_TYPE").append("=?,"); }
                if(obj.amendLcDraweeBrnCodeIsModifiedS2j()) {  _sql.append("AMEND_LC_DRAWEE_BRN_CODE").append("=?,"); }
                if(obj.amendLcDraweeBicCodeIsModifiedS2j()) {  _sql.append("AMEND_LC_DRAWEE_BIC_CODE").append("=?,"); }
                if(obj.amendLcDraweeRoutidIsModifiedS2j()) {  _sql.append("AMEND_LC_DRAWEE_ROUTID").append("=?,"); }
                if(obj.amendLcDraweeBnkCodeIsModifiedS2j()) {  _sql.append("AMEND_LC_DRAWEE_BNK_CODE").append("=?,"); }
                if(obj.amendLcDraweeAddr1IsModifiedS2j()) {  _sql.append("AMEND_LC_DRAWEE_ADDR1").append("=?,"); }
                if(obj.amendLcDraweeAddr2IsModifiedS2j()) {  _sql.append("AMEND_LC_DRAWEE_ADDR2").append("=?,"); }
                if(obj.amendLcDraweeAddr3IsModifiedS2j()) {  _sql.append("AMEND_LC_DRAWEE_ADDR3").append("=?,"); }
                if(obj.amendLcDraweeAddr4IsModifiedS2j()) {  _sql.append("AMEND_LC_DRAWEE_ADDR4").append("=?,"); }
                if(obj.amendLcDraweeAddr5IsModifiedS2j()) {  _sql.append("AMEND_LC_DRAWEE_ADDR5").append("=?,"); }
                if(obj.amendDraweeCntryCodeIsModifiedS2j()) {  _sql.append("AMEND_DRAWEE_CNTRY_CODE").append("=?,"); }
                if(obj.amendLcMixedPayDetails1IsModifiedS2j()) {  _sql.append("AMEND_LC_MIXED_PAY_DETAILS1").append("=?,"); }
                if(obj.amendLcMixedPayDetails2IsModifiedS2j()) {  _sql.append("AMEND_LC_MIXED_PAY_DETAILS2").append("=?,"); }
                if(obj.amendLcMixedPayDetails3IsModifiedS2j()) {  _sql.append("AMEND_LC_MIXED_PAY_DETAILS3").append("=?,"); }
                if(obj.amendLcMixedPayDetails4IsModifiedS2j()) {  _sql.append("AMEND_LC_MIXED_PAY_DETAILS4").append("=?,"); }
                if(obj.amendLcMixedPayDetails5IsModifiedS2j()) {  _sql.append("AMEND_LC_MIXED_PAY_DETAILS5").append("=?,"); }
                if(obj.amendLcDeferredPayDetails1IsModifiedS2j()) {  _sql.append("AMEND_LC_DEFERRED_PAY_DETAILS1").append("=?,"); }
                if(obj.amendLcDeferredPayDetails2IsModifiedS2j()) {  _sql.append("AMEND_LC_DEFERRED_PAY_DETAILS2").append("=?,"); }
                if(obj.amendLcDeferredPayDetails3IsModifiedS2j()) {  _sql.append("AMEND_LC_DEFERRED_PAY_DETAILS3").append("=?,"); }
                if(obj.amendLcDeferredPayDetails4IsModifiedS2j()) {  _sql.append("AMEND_LC_DEFERRED_PAY_DETAILS4").append("=?,"); }
                if(obj.amendLcDeferredPayDetails5IsModifiedS2j()) {  _sql.append("AMEND_LC_DEFERRED_PAY_DETAILS5").append("=?,"); }
                if(obj.amendLcPartialShipmentsIsModifiedS2j()) {  _sql.append("AMEND_LC_PARTIAL_SHIPMENTS").append("=?,"); }
                if(obj.amendLcTranshipmentIsModifiedS2j()) {  _sql.append("AMEND_LC_TRANSHIPMENT").append("=?,"); }
                if(obj.amendLcConfirmationInstIsModifiedS2j()) {  _sql.append("AMEND_LC_CONFIRMATION_INST").append("=?,"); }
                if(obj.amendLcReimbReqIsModifiedS2j()) {  _sql.append("AMEND_LC_REIMB_REQ").append("=?,"); }
                if(obj.amendLcReimbTypeIsModifiedS2j()) {  _sql.append("AMEND_LC_REIMB_TYPE").append("=?,"); }
                if(obj.amendLcReimbBrnCodeIsModifiedS2j()) {  _sql.append("AMEND_LC_REIMB_BRN_CODE").append("=?,"); }
                if(obj.amendLcReimbBicCodeIsModifiedS2j()) {  _sql.append("AMEND_LC_REIMB_BIC_CODE").append("=?,"); }
                if(obj.amendLcReimbRoutidIsModifiedS2j()) {  _sql.append("AMEND_LC_REIMB_ROUTID").append("=?,"); }
                if(obj.amendLcReimbBnkCodeIsModifiedS2j()) {  _sql.append("AMEND_LC_REIMB_BNK_CODE").append("=?,"); }
                if(obj.amendLcReimbAddr1IsModifiedS2j()) {  _sql.append("AMEND_LC_REIMB_ADDR1").append("=?,"); }
                if(obj.amendLcReimbAddr2IsModifiedS2j()) {  _sql.append("AMEND_LC_REIMB_ADDR2").append("=?,"); }
                if(obj.amendLcReimbAddr3IsModifiedS2j()) {  _sql.append("AMEND_LC_REIMB_ADDR3").append("=?,"); }
                if(obj.amendLcReimbAddr4IsModifiedS2j()) {  _sql.append("AMEND_LC_REIMB_ADDR4").append("=?,"); }
                if(obj.amendLcReimbAddr5IsModifiedS2j()) {  _sql.append("AMEND_LC_REIMB_ADDR5").append("=?,"); }
                if(obj.amendLcInstPaying1IsModifiedS2j()) {  _sql.append("AMEND_LC_INST_PAYING1").append("=?,"); }
                if(obj.amendLcInstPaying2IsModifiedS2j()) {  _sql.append("AMEND_LC_INST_PAYING2").append("=?,"); }
                if(obj.amendLcInstPaying3IsModifiedS2j()) {  _sql.append("AMEND_LC_INST_PAYING3").append("=?,"); }
                if(obj.amendLcInstPaying4IsModifiedS2j()) {  _sql.append("AMEND_LC_INST_PAYING4").append("=?,"); }
                if(obj.amendLcInstPaying5IsModifiedS2j()) {  _sql.append("AMEND_LC_INST_PAYING5").append("=?,"); }
                if(obj.amendLcInstPaying6IsModifiedS2j()) {  _sql.append("AMEND_LC_INST_PAYING6").append("=?,"); }
                if(obj.amendLcInstPaying7IsModifiedS2j()) {  _sql.append("AMEND_LC_INST_PAYING7").append("=?,"); }
                if(obj.amendLcInstPaying8IsModifiedS2j()) {  _sql.append("AMEND_LC_INST_PAYING8").append("=?,"); }
                if(obj.amendLcInstPaying9IsModifiedS2j()) {  _sql.append("AMEND_LC_INST_PAYING9").append("=?,"); }
                if(obj.amendLcInstPaying10IsModifiedS2j()) {  _sql.append("AMEND_LC_INST_PAYING10").append("=?,"); }
                if(obj.amendLcInstPaying11IsModifiedS2j()) {  _sql.append("AMEND_LC_INST_PAYING11").append("=?,"); }
                if(obj.amendLcInstPaying12IsModifiedS2j()) {  _sql.append("AMEND_LC_INST_PAYING12").append("=?,"); }
                if(obj.amendLcSecondAdvReqIsModifiedS2j()) {  _sql.append("AMEND_LC_SECOND_ADV_REQ").append("=?,"); }
                if(obj.amendLcSecondAdvTypeIsModifiedS2j()) {  _sql.append("AMEND_LC_SECOND_ADV_TYPE").append("=?,"); }
                if(obj.amendLcSecondAdvBrnCodeIsModifiedS2j()) {  _sql.append("AMEND_LC_SECOND_ADV_BRN_CODE").append("=?,"); }
                if(obj.amendLcSecondAdvBicCodeIsModifiedS2j()) {  _sql.append("AMEND_LC_SECOND_ADV_BIC_CODE").append("=?,"); }
                if(obj.amendLcSecondAdvRoutidIsModifiedS2j()) {  _sql.append("AMEND_LC_SECOND_ADV_ROUTID").append("=?,"); }
                if(obj.amendLcSecondAdvBnkCodeIsModifiedS2j()) {  _sql.append("AMEND_LC_SECOND_ADV_BNK_CODE").append("=?,"); }
                if(obj.amendLcSecondAdvAddr1IsModifiedS2j()) {  _sql.append("AMEND_LC_SECOND_ADV_ADDR1").append("=?,"); }
                if(obj.amendLcSecondAdvAddr2IsModifiedS2j()) {  _sql.append("AMEND_LC_SECOND_ADV_ADDR2").append("=?,"); }
                if(obj.amendLcSecondAdvAddr3IsModifiedS2j()) {  _sql.append("AMEND_LC_SECOND_ADV_ADDR3").append("=?,"); }
                if(obj.amendLcSecondAdvAddr4IsModifiedS2j()) {  _sql.append("AMEND_LC_SECOND_ADV_ADDR4").append("=?,"); }
                if(obj.amendLcSecondAdvAddr5IsModifiedS2j()) {  _sql.append("AMEND_LC_SECOND_ADV_ADDR5").append("=?,"); }
                if(obj.amendLcSecondAdvCntrycodeIsModifiedS2j()) {  _sql.append("AMEND_LC_SECOND_ADV_CNTRYCODE").append("=?,"); }
                if(obj.amendLcAvlWithCodetypIsModifiedS2j()) {  _sql.append("AMEND_LC_AVL_WITH_CODETYP").append("=?,"); }
                if(obj.amendLcReimbCntryCodeIsModifiedS2j()) {  _sql.append("AMEND_LC_REIMB_CNTRY_CODE").append("=?,"); }
                if(obj.amendLcCnfAdvTypeIsModifiedS2j()) {  _sql.append("AMEND_LC_CNF_ADV_TYPE").append("=?,"); }
                if(obj.amendLcCnfAdvBrnCodeIsModifiedS2j()) {  _sql.append("AMEND_LC_CNF_ADV_BRN_CODE").append("=?,"); }
                if(obj.amendLcCnfAdvBicCodeIsModifiedS2j()) {  _sql.append("AMEND_LC_CNF_ADV_BIC_CODE").append("=?,"); }
                if(obj.amendLcCnfAdvRoutidIsModifiedS2j()) {  _sql.append("AMEND_LC_CNF_ADV_ROUTID").append("=?,"); }
                if(obj.amendLcCnfAdvBnkCodeIsModifiedS2j()) {  _sql.append("AMEND_LC_CNF_ADV_BNK_CODE").append("=?,"); }
                if(obj.amendLcCnfAdvAddr1IsModifiedS2j()) {  _sql.append("AMEND_LC_CNF_ADV_ADDR1").append("=?,"); }
                if(obj.amendLcCnfAdvAddr2IsModifiedS2j()) {  _sql.append("AMEND_LC_CNF_ADV_ADDR2").append("=?,"); }
                if(obj.amendLcCnfAdvAddr3IsModifiedS2j()) {  _sql.append("AMEND_LC_CNF_ADV_ADDR3").append("=?,"); }
                if(obj.amendLcCnfAdvAddr4IsModifiedS2j()) {  _sql.append("AMEND_LC_CNF_ADV_ADDR4").append("=?,"); }
                if(obj.amendLcCnfAdvAddr5IsModifiedS2j()) {  _sql.append("AMEND_LC_CNF_ADV_ADDR5").append("=?,"); }
                if(obj.amendLcCnfAdvCntrycodeIsModifiedS2j()) {  _sql.append("AMEND_LC_CNF_ADV_CNTRYCODE").append("=?,"); }
                _sql.setLength(_sql.length() - 1);
                _sql.append(" WHERE ");
                _sql.append("AMEND_DETAILS.AMEND_LC_AMD_SL=? and AMEND_DETAILS.AMEND_LC_BRN_CODE=? and AMEND_DETAILS.AMEND_LC_SERIAL=? and AMEND_DETAILS.AMEND_LC_TYPE=? and AMEND_DETAILS.AMEND_LC_YEAR=?");
                _pstmt = _conn.prepareStatement(_sql.toString());
                int _dirtyCount = 0;
                if(obj.amendLcBrnCodeIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendLcBrnCode()); } 
                if(obj.amendLcTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcType()); } 
                if(obj.amendLcYearIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendLcYear()); } 
                if(obj.amendLcSerialIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendLcSerial()); } 
                if(obj.amendLcAmdSlIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendLcAmdSl()); } 
                if(obj.amendSndrRefIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendSndrRef()); } 
                if(obj.amendRcvrRefIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendRcvrRef()); } 
                if(obj.amendDocCrNumIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendDocCrNum()); } 
                if(obj.amendIssuingBnkReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendIssuingBnkReq())); } 
                if(obj.amendIssuingTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendIssuingType())); } 
                if(obj.amendIssuingBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendIssuingBrnCode()); } 
                if(obj.amendIssuingBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendIssuingBicCode()); } 
                if(obj.amendIssuingRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendIssuingRoutid()); } 
                if(obj.amendIssuingBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendIssuingBnkCode()); } 
                if(obj.amendIssuingAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendIssuingAddr1()); } 
                if(obj.amendIssuingAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendIssuingAddr2()); } 
                if(obj.amendIssuingAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendIssuingAddr3()); } 
                if(obj.amendIssuingAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendIssuingAddr4()); } 
                if(obj.amendIssuingAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendIssuingAddr5()); } 
                if(obj.amendNonBnkIssurIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendNonBnkIssur()); } 
                if(obj.amendDateOfIssueIsModifiedS2j()) { if (obj.getAmendDateOfIssue() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getAmendDateOfIssue().getTime()));} } 
                if(obj.amendDateOfAmendmentIsModifiedS2j()) { if (obj.getAmendDateOfAmendment() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getAmendDateOfAmendment().getTime()));} } 
                if(obj.amendPurposeOfMsgIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendPurposeOfMsg())); } 
                if(obj.amendCancelRequestIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendCancelRequest()); } 
                if(obj.amendAdvisingBnkReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendAdvisingBnkReq())); } 
                if(obj.amendAdvisingBnkTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendAdvisingBnkType())); } 
                if(obj.amendAdvisingBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendAdvisingBrnCode()); } 
                if(obj.amendAdvisingBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendAdvisingBicCode()); } 
                if(obj.amendAdvisingRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendAdvisingRoutid()); } 
                if(obj.amendAdvisingBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendAdvisingBnkCode()); } 
                if(obj.amendAdvisingAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendAdvisingAddr1()); } 
                if(obj.amendAdvisingAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendAdvisingAddr2()); } 
                if(obj.amendAdvisingAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendAdvisingAddr3()); } 
                if(obj.amendAdvisingAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendAdvisingAddr4()); } 
                if(obj.amendAdvisingAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendAdvisingAddr5()); } 
                if(obj.amendSecondAdvReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendSecondAdvReq())); } 
                if(obj.amendSecondAdvTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendSecondAdvType())); } 
                if(obj.amendSecondAdvBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendSecondAdvBrnCode()); } 
                if(obj.amendSecondAdvBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendSecondAdvBicCode()); } 
                if(obj.amendSecondAdvRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendSecondAdvRoutid()); } 
                if(obj.amendSecondAdvBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendSecondAdvBnkCode()); } 
                if(obj.amendSecondAdvAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendSecondAdvAddr1()); } 
                if(obj.amendSecondAdvAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendSecondAdvAddr2()); } 
                if(obj.amendSecondAdvAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendSecondAdvAddr3()); } 
                if(obj.amendSecondAdvAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendSecondAdvAddr4()); } 
                if(obj.amendSecondAdvAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendSecondAdvAddr5()); } 
                if(obj.amendNewBeneficiaryIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendNewBeneficiary()); } 
                if(obj.amendNewDateOfExpiryIsModifiedS2j()) { if (obj.getAmendNewDateOfExpiry() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getAmendNewDateOfExpiry().getTime()));} } 
                if(obj.amendIncrDocCrAmtIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendIncrDocCrAmt()); } 
                if(obj.amendDecrDocCrAmtIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendDecrDocCrAmt()); } 
                if(obj.amendNewAddnlAmtIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendNewAddnlAmt()); } 
                if(obj.amendPlaceTakinInChrgIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendPlaceTakinInChrg()); } 
                if(obj.amendPortOfLoadingIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendPortOfLoading()); } 
                if(obj.amendPortOfDischargeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendPortOfDischarge()); } 
                if(obj.amendPlaceOfFinalDestIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendPlaceOfFinalDest()); } 
                if(obj.amendDateOfShipmentIsModifiedS2j()) { if (obj.getAmendDateOfShipment() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getAmendDateOfShipment().getTime()));} } 
                if(obj.amendDescGoddSer1IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getAmendDescGoddSer1()); } 
                if(obj.amendDocReq1IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getAmendDocReq1()); } 
                if(obj.amendAddCondition1IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getAmendAddCondition1()); } 
                if(obj.amendChrgPayable1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendChrgPayable1()); } 
                if(obj.amendChrgPayable2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendChrgPayable2()); } 
                if(obj.amendChrgPayable3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendChrgPayable3()); } 
                if(obj.amendChrgPayable4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendChrgPayable4()); } 
                if(obj.amendChrgPayable5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendChrgPayable5()); } 
                if(obj.amendChrgPayable6IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendChrgPayable6()); } 
                if(obj.amendSndrRecInfo1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendSndrRecInfo1()); } 
                if(obj.amendSndrRecInfo2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendSndrRecInfo2()); } 
                if(obj.amendSndrRecInfo3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendSndrRecInfo3()); } 
                if(obj.amendSndrRecInfo4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendSndrRecInfo4()); } 
                if(obj.amendSndrRecInfo5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendSndrRecInfo5()); } 
                if(obj.amendSndrRecInfo6IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendSndrRecInfo6()); } 
                if(obj.amendChkboxIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendChkbox()); } 
                if(obj.amendIssuingCntryIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendIssuingCntry()); } 
                if(obj.amendAdvisingCntryIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendAdvisingCntry()); } 
                if(obj.amendSecondAdvCntryIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendSecondAdvCntry()); } 
                if(obj.amendIssueRefIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendIssueRef()); } 
                if(obj.amendFormOfDocCreditIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendFormOfDocCredit()); } 
                if(obj.amendLcApplicableRulesIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendLcApplicableRules()); } 
                if(obj.amendLcApplicantReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendLcApplicantReq())); } 
                if(obj.amendLcApplicantNameIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcApplicantName()); } 
                if(obj.amendLcApplicantAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcApplicantAddr1()); } 
                if(obj.amendLcApplicantAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcApplicantAddr2()); } 
                if(obj.amendLcApplicantAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcApplicantAddr3()); } 
                if(obj.amendLcApplicantAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcApplicantAddr4()); } 
                if(obj.amendLcApplicantAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcApplicantAddr5()); } 
                if(obj.amendLcAvlWithTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendLcAvlWithType())); } 
                if(obj.amendLcAvlWithBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcAvlWithBrnCode()); } 
                if(obj.amendLcAvlWithBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcAvlWithBicCode()); } 
                if(obj.amendLcLcAvlWithRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcLcAvlWithRoutid()); } 
                if(obj.amendLcAvlWithBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcAvlWithBnkCode()); } 
                if(obj.amendLcAvlWithAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcAvlWithAddr1()); } 
                if(obj.amendLcAvlWithAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcAvlWithAddr2()); } 
                if(obj.amendLcAvlWithAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcAvlWithAddr3()); } 
                if(obj.amendLcAvlWithAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcAvlWithAddr4()); } 
                if(obj.amendLcAvlWithAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcAvlWithAddr5()); } 
                if(obj.amendLcAvlWithCntryIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcAvlWithCntry()); } 
                if(obj.amendLcDraftsAt1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcDraftsAt1()); } 
                if(obj.amendLcDraftsAt2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcDraftsAt2()); } 
                if(obj.amendLcDraftsAt3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcDraftsAt3()); } 
                if(obj.amendLcDraweeReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendLcDraweeReq())); } 
                if(obj.amendLcDraweeTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendLcDraweeType())); } 
                if(obj.amendLcDraweeBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcDraweeBrnCode()); } 
                if(obj.amendLcDraweeBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcDraweeBicCode()); } 
                if(obj.amendLcDraweeRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcDraweeRoutid()); } 
                if(obj.amendLcDraweeBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcDraweeBnkCode()); } 
                if(obj.amendLcDraweeAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcDraweeAddr1()); } 
                if(obj.amendLcDraweeAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcDraweeAddr2()); } 
                if(obj.amendLcDraweeAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcDraweeAddr3()); } 
                if(obj.amendLcDraweeAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcDraweeAddr4()); } 
                if(obj.amendLcDraweeAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcDraweeAddr5()); } 
                if(obj.amendDraweeCntryCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendDraweeCntryCode()); } 
                if(obj.amendLcMixedPayDetails1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcMixedPayDetails1()); } 
                if(obj.amendLcMixedPayDetails2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcMixedPayDetails2()); } 
                if(obj.amendLcMixedPayDetails3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcMixedPayDetails3()); } 
                if(obj.amendLcMixedPayDetails4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcMixedPayDetails4()); } 
                if(obj.amendLcMixedPayDetails5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcMixedPayDetails5()); } 
                if(obj.amendLcDeferredPayDetails1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcDeferredPayDetails1()); } 
                if(obj.amendLcDeferredPayDetails2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcDeferredPayDetails2()); } 
                if(obj.amendLcDeferredPayDetails3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcDeferredPayDetails3()); } 
                if(obj.amendLcDeferredPayDetails4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcDeferredPayDetails4()); } 
                if(obj.amendLcDeferredPayDetails5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcDeferredPayDetails5()); } 
                if(obj.amendLcPartialShipmentsIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendLcPartialShipments()); } 
                if(obj.amendLcTranshipmentIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendLcTranshipment()); } 
                if(obj.amendLcConfirmationInstIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendLcConfirmationInst()); } 
                if(obj.amendLcReimbReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendLcReimbReq())); } 
                if(obj.amendLcReimbTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendLcReimbType())); } 
                if(obj.amendLcReimbBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcReimbBrnCode()); } 
                if(obj.amendLcReimbBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcReimbBicCode()); } 
                if(obj.amendLcReimbRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcReimbRoutid()); } 
                if(obj.amendLcReimbBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcReimbBnkCode()); } 
                if(obj.amendLcReimbAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcReimbAddr1()); } 
                if(obj.amendLcReimbAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcReimbAddr2()); } 
                if(obj.amendLcReimbAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcReimbAddr3()); } 
                if(obj.amendLcReimbAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcReimbAddr4()); } 
                if(obj.amendLcReimbAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcReimbAddr5()); } 
                if(obj.amendLcInstPaying1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcInstPaying1()); } 
                if(obj.amendLcInstPaying2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcInstPaying2()); } 
                if(obj.amendLcInstPaying3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcInstPaying3()); } 
                if(obj.amendLcInstPaying4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcInstPaying4()); } 
                if(obj.amendLcInstPaying5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcInstPaying5()); } 
                if(obj.amendLcInstPaying6IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcInstPaying6()); } 
                if(obj.amendLcInstPaying7IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcInstPaying7()); } 
                if(obj.amendLcInstPaying8IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcInstPaying8()); } 
                if(obj.amendLcInstPaying9IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcInstPaying9()); } 
                if(obj.amendLcInstPaying10IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcInstPaying10()); } 
                if(obj.amendLcInstPaying11IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcInstPaying11()); } 
                if(obj.amendLcInstPaying12IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcInstPaying12()); } 
                if(obj.amendLcSecondAdvReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendLcSecondAdvReq())); } 
                if(obj.amendLcSecondAdvTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendLcSecondAdvType())); } 
                if(obj.amendLcSecondAdvBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcSecondAdvBrnCode()); } 
                if(obj.amendLcSecondAdvBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcSecondAdvBicCode()); } 
                if(obj.amendLcSecondAdvRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcSecondAdvRoutid()); } 
                if(obj.amendLcSecondAdvBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcSecondAdvBnkCode()); } 
                if(obj.amendLcSecondAdvAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcSecondAdvAddr1()); } 
                if(obj.amendLcSecondAdvAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcSecondAdvAddr2()); } 
                if(obj.amendLcSecondAdvAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcSecondAdvAddr3()); } 
                if(obj.amendLcSecondAdvAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcSecondAdvAddr4()); } 
                if(obj.amendLcSecondAdvAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcSecondAdvAddr5()); } 
                if(obj.amendLcSecondAdvCntrycodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcSecondAdvCntrycode()); } 
                if(obj.amendLcAvlWithCodetypIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendLcAvlWithCodetyp())); } 
                if(obj.amendLcReimbCntryCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcReimbCntryCode()); } 
                if(obj.amendLcCnfAdvTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendLcCnfAdvType())); } 
                if(obj.amendLcCnfAdvBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcCnfAdvBrnCode()); } 
                if(obj.amendLcCnfAdvBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcCnfAdvBicCode()); } 
                if(obj.amendLcCnfAdvRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcCnfAdvRoutid()); } 
                if(obj.amendLcCnfAdvBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcCnfAdvBnkCode()); } 
                if(obj.amendLcCnfAdvAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcCnfAdvAddr1()); } 
                if(obj.amendLcCnfAdvAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcCnfAdvAddr2()); } 
                if(obj.amendLcCnfAdvAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcCnfAdvAddr3()); } 
                if(obj.amendLcCnfAdvAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcCnfAdvAddr4()); } 
                if(obj.amendLcCnfAdvAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcCnfAdvAddr5()); } 
                if(obj.amendLcCnfAdvCntrycodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendLcCnfAdvCntrycode()); } 
                _pstmt.setDouble(++_dirtyCount, obj.getAmendLcAmdSl());
                _pstmt.setDouble(++_dirtyCount, obj.getAmendLcBrnCode());
                _pstmt.setDouble(++_dirtyCount, obj.getAmendLcSerial());
                _pstmt.setString(++_dirtyCount, obj.getAmendLcType());
                _pstmt.setDouble(++_dirtyCount, obj.getAmendLcYear());
                _pstmt.executeUpdate();
                obj.resetIsModifiedS2J();
            }
            _pstmt.close();
        }
        catch(SQLException e) {
            if(_pstmt!=null) try { _pstmt.close();} catch(Exception e2) {}
            throw e;
        }
    }

    private AmendDetails decodeRow(ResultSet rs) throws SQLException {
        AmendDetails obj = new AmendDetails();
        obj.setAmendLcBrnCode(rs.getInt(1));
        obj.setAmendLcType(rs.getString(2));
        obj.setAmendLcYear(rs.getInt(3));
        obj.setAmendLcSerial(rs.getInt(4));
        obj.setAmendLcAmdSl(rs.getInt(5));
        obj.setAmendSndrRef(rs.getString(6));
        obj.setAmendRcvrRef(rs.getString(7));
        obj.setAmendDocCrNum(rs.getString(8));
        obj.setAmendIssuingBnkReq(stringToChar(rs.getString(9)));
        obj.setAmendIssuingType(stringToChar(rs.getString(10)));
        obj.setAmendIssuingBrnCode(rs.getString(11));
        obj.setAmendIssuingBicCode(rs.getString(12));
        obj.setAmendIssuingRoutid(rs.getString(13));
        obj.setAmendIssuingBnkCode(rs.getString(14));
        obj.setAmendIssuingAddr1(rs.getString(15));
        obj.setAmendIssuingAddr2(rs.getString(16));
        obj.setAmendIssuingAddr3(rs.getString(17));
        obj.setAmendIssuingAddr4(rs.getString(18));
        obj.setAmendIssuingAddr5(rs.getString(19));
        obj.setAmendNonBnkIssur(rs.getString(20));
        obj.setAmendDateOfIssue(rs.getDate(21));
        obj.setAmendDateOfAmendment(rs.getDate(22));
        obj.setAmendPurposeOfMsg(stringToChar(rs.getString(23)));
        obj.setAmendCancelRequest(rs.getString(24));
        obj.setAmendAdvisingBnkReq(stringToChar(rs.getString(25)));
        obj.setAmendAdvisingBnkType(stringToChar(rs.getString(26)));
        obj.setAmendAdvisingBrnCode(rs.getString(27));
        obj.setAmendAdvisingBicCode(rs.getString(28));
        obj.setAmendAdvisingRoutid(rs.getString(29));
        obj.setAmendAdvisingBnkCode(rs.getString(30));
        obj.setAmendAdvisingAddr1(rs.getString(31));
        obj.setAmendAdvisingAddr2(rs.getString(32));
        obj.setAmendAdvisingAddr3(rs.getString(33));
        obj.setAmendAdvisingAddr4(rs.getString(34));
        obj.setAmendAdvisingAddr5(rs.getString(35));
        obj.setAmendSecondAdvReq(stringToChar(rs.getString(36)));
        obj.setAmendSecondAdvType(stringToChar(rs.getString(37)));
        obj.setAmendSecondAdvBrnCode(rs.getString(38));
        obj.setAmendSecondAdvBicCode(rs.getString(39));
        obj.setAmendSecondAdvRoutid(rs.getString(40));
        obj.setAmendSecondAdvBnkCode(rs.getString(41));
        obj.setAmendSecondAdvAddr1(rs.getString(42));
        obj.setAmendSecondAdvAddr2(rs.getString(43));
        obj.setAmendSecondAdvAddr3(rs.getString(44));
        obj.setAmendSecondAdvAddr4(rs.getString(45));
        obj.setAmendSecondAdvAddr5(rs.getString(46));
        obj.setAmendNewBeneficiary(rs.getString(47));
        obj.setAmendNewDateOfExpiry(rs.getDate(48));
        obj.setAmendIncrDocCrAmt(rs.getDouble(49));
        obj.setAmendDecrDocCrAmt(rs.getDouble(50));
        obj.setAmendNewAddnlAmt(rs.getDouble(51));
        obj.setAmendPlaceTakinInChrg(rs.getString(52));
        obj.setAmendPortOfLoading(rs.getString(53));
        obj.setAmendPortOfDischarge(rs.getString(54));
        obj.setAmendPlaceOfFinalDest(rs.getString(55));
        obj.setAmendDateOfShipment(rs.getDate(56));
        obj.setAmendDescGoddSer1(rs.getObject(57));
        obj.setAmendDocReq1(rs.getObject(58));
        obj.setAmendAddCondition1(rs.getObject(59));
        obj.setAmendChrgPayable1(rs.getString(60));
        obj.setAmendChrgPayable2(rs.getString(61));
        obj.setAmendChrgPayable3(rs.getString(62));
        obj.setAmendChrgPayable4(rs.getString(63));
        obj.setAmendChrgPayable5(rs.getString(64));
        obj.setAmendChrgPayable6(rs.getString(65));
        obj.setAmendSndrRecInfo1(rs.getString(66));
        obj.setAmendSndrRecInfo2(rs.getString(67));
        obj.setAmendSndrRecInfo3(rs.getString(68));
        obj.setAmendSndrRecInfo4(rs.getString(69));
        obj.setAmendSndrRecInfo5(rs.getString(70));
        obj.setAmendSndrRecInfo6(rs.getString(71));
        obj.setAmendChkbox(rs.getString(72));
        obj.setAmendIssuingCntry(rs.getString(73));
        obj.setAmendAdvisingCntry(rs.getString(74));
        obj.setAmendSecondAdvCntry(rs.getString(75));
        obj.setAmendIssueRef(rs.getString(76));
        obj.setAmendFormOfDocCredit(rs.getInt(77));
        obj.setAmendLcApplicableRules(rs.getInt(78));
        obj.setAmendLcApplicantReq(stringToChar(rs.getString(79)));
        obj.setAmendLcApplicantName(rs.getString(80));
        obj.setAmendLcApplicantAddr1(rs.getString(81));
        obj.setAmendLcApplicantAddr2(rs.getString(82));
        obj.setAmendLcApplicantAddr3(rs.getString(83));
        obj.setAmendLcApplicantAddr4(rs.getString(84));
        obj.setAmendLcApplicantAddr5(rs.getString(85));
        obj.setAmendLcAvlWithType(stringToChar(rs.getString(86)));
        obj.setAmendLcAvlWithBrnCode(rs.getString(87));
        obj.setAmendLcAvlWithBicCode(rs.getString(88));
        obj.setAmendLcLcAvlWithRoutid(rs.getString(89));
        obj.setAmendLcAvlWithBnkCode(rs.getString(90));
        obj.setAmendLcAvlWithAddr1(rs.getString(91));
        obj.setAmendLcAvlWithAddr2(rs.getString(92));
        obj.setAmendLcAvlWithAddr3(rs.getString(93));
        obj.setAmendLcAvlWithAddr4(rs.getString(94));
        obj.setAmendLcAvlWithAddr5(rs.getString(95));
        obj.setAmendLcAvlWithCntry(rs.getString(96));
        obj.setAmendLcDraftsAt1(rs.getString(97));
        obj.setAmendLcDraftsAt2(rs.getString(98));
        obj.setAmendLcDraftsAt3(rs.getString(99));
        obj.setAmendLcDraweeReq(stringToChar(rs.getString(100)));
        obj.setAmendLcDraweeType(stringToChar(rs.getString(101)));
        obj.setAmendLcDraweeBrnCode(rs.getString(102));
        obj.setAmendLcDraweeBicCode(rs.getString(103));
        obj.setAmendLcDraweeRoutid(rs.getString(104));
        obj.setAmendLcDraweeBnkCode(rs.getString(105));
        obj.setAmendLcDraweeAddr1(rs.getString(106));
        obj.setAmendLcDraweeAddr2(rs.getString(107));
        obj.setAmendLcDraweeAddr3(rs.getString(108));
        obj.setAmendLcDraweeAddr4(rs.getString(109));
        obj.setAmendLcDraweeAddr5(rs.getString(110));
        obj.setAmendDraweeCntryCode(rs.getString(111));
        obj.setAmendLcMixedPayDetails1(rs.getString(112));
        obj.setAmendLcMixedPayDetails2(rs.getString(113));
        obj.setAmendLcMixedPayDetails3(rs.getString(114));
        obj.setAmendLcMixedPayDetails4(rs.getString(115));
        obj.setAmendLcMixedPayDetails5(rs.getString(116));
        obj.setAmendLcDeferredPayDetails1(rs.getString(117));
        obj.setAmendLcDeferredPayDetails2(rs.getString(118));
        obj.setAmendLcDeferredPayDetails3(rs.getString(119));
        obj.setAmendLcDeferredPayDetails4(rs.getString(120));
        obj.setAmendLcDeferredPayDetails5(rs.getString(121));
        obj.setAmendLcPartialShipments(rs.getInt(122));
        obj.setAmendLcTranshipment(rs.getInt(123));
        obj.setAmendLcConfirmationInst(rs.getInt(124));
        obj.setAmendLcReimbReq(stringToChar(rs.getString(125)));
        obj.setAmendLcReimbType(stringToChar(rs.getString(126)));
        obj.setAmendLcReimbBrnCode(rs.getString(127));
        obj.setAmendLcReimbBicCode(rs.getString(128));
        obj.setAmendLcReimbRoutid(rs.getString(129));
        obj.setAmendLcReimbBnkCode(rs.getString(130));
        obj.setAmendLcReimbAddr1(rs.getString(131));
        obj.setAmendLcReimbAddr2(rs.getString(132));
        obj.setAmendLcReimbAddr3(rs.getString(133));
        obj.setAmendLcReimbAddr4(rs.getString(134));
        obj.setAmendLcReimbAddr5(rs.getString(135));
        obj.setAmendLcInstPaying1(rs.getString(136));
        obj.setAmendLcInstPaying2(rs.getString(137));
        obj.setAmendLcInstPaying3(rs.getString(138));
        obj.setAmendLcInstPaying4(rs.getString(139));
        obj.setAmendLcInstPaying5(rs.getString(140));
        obj.setAmendLcInstPaying6(rs.getString(141));
        obj.setAmendLcInstPaying7(rs.getString(142));
        obj.setAmendLcInstPaying8(rs.getString(143));
        obj.setAmendLcInstPaying9(rs.getString(144));
        obj.setAmendLcInstPaying10(rs.getString(145));
        obj.setAmendLcInstPaying11(rs.getString(146));
        obj.setAmendLcInstPaying12(rs.getString(147));
        obj.setAmendLcSecondAdvReq(stringToChar(rs.getString(148)));
        obj.setAmendLcSecondAdvType(stringToChar(rs.getString(149)));
        obj.setAmendLcSecondAdvBrnCode(rs.getString(150));
        obj.setAmendLcSecondAdvBicCode(rs.getString(151));
        obj.setAmendLcSecondAdvRoutid(rs.getString(152));
        obj.setAmendLcSecondAdvBnkCode(rs.getString(153));
        obj.setAmendLcSecondAdvAddr1(rs.getString(154));
        obj.setAmendLcSecondAdvAddr2(rs.getString(155));
        obj.setAmendLcSecondAdvAddr3(rs.getString(156));
        obj.setAmendLcSecondAdvAddr4(rs.getString(157));
        obj.setAmendLcSecondAdvAddr5(rs.getString(158));
        obj.setAmendLcSecondAdvCntrycode(rs.getString(159));
        obj.setAmendLcAvlWithCodetyp(stringToChar(rs.getString(160)));
        obj.setAmendLcReimbCntryCode(rs.getString(161));
        obj.setAmendLcCnfAdvType(stringToChar(rs.getString(162)));
        obj.setAmendLcCnfAdvBrnCode(rs.getString(163));
        obj.setAmendLcCnfAdvBicCode(rs.getString(164));
        obj.setAmendLcCnfAdvRoutid(rs.getString(165));
        obj.setAmendLcCnfAdvBnkCode(rs.getString(166));
        obj.setAmendLcCnfAdvAddr1(rs.getString(167));
        obj.setAmendLcCnfAdvAddr2(rs.getString(168));
        obj.setAmendLcCnfAdvAddr3(rs.getString(169));
        obj.setAmendLcCnfAdvAddr4(rs.getString(170));
        obj.setAmendLcCnfAdvAddr5(rs.getString(171));
        obj.setAmendLcCnfAdvCntrycode(rs.getString(172));
        obj.setIsNew(false);
        obj.resetIsModifiedS2J();

        return obj;
    }

    private AmendDetails decodeRow(ResultSet rs, int[] fieldList) throws SQLException {
        AmendDetails obj = new AmendDetails();
        int pos = 0;
        for(int i = 0; i < fieldList.length; i++) {
            switch(fieldList[i]) {
                case AMEND_LC_BRN_CODE: obj.setAmendLcBrnCode(rs.getInt(++pos));
                    break;
                case AMEND_LC_TYPE: obj.setAmendLcType(rs.getString(++pos));
                    break;
                case AMEND_LC_YEAR: obj.setAmendLcYear(rs.getInt(++pos));
                    break;
                case AMEND_LC_SERIAL: obj.setAmendLcSerial(rs.getInt(++pos));
                    break;
                case AMEND_LC_AMD_SL: obj.setAmendLcAmdSl(rs.getInt(++pos));
                    break;
                case AMEND_SNDR_REF: obj.setAmendSndrRef(rs.getString(++pos));
                    break;
                case AMEND_RCVR_REF: obj.setAmendRcvrRef(rs.getString(++pos));
                    break;
                case AMEND_DOC_CR_NUM: obj.setAmendDocCrNum(rs.getString(++pos));
                    break;
                case AMEND_ISSUING_BNK_REQ: obj.setAmendIssuingBnkReq(stringToChar(rs.getString(++pos)));
                    break;
                case AMEND_ISSUING_TYPE: obj.setAmendIssuingType(stringToChar(rs.getString(++pos)));
                    break;
                case AMEND_ISSUING_BRN_CODE: obj.setAmendIssuingBrnCode(rs.getString(++pos));
                    break;
                case AMEND_ISSUING_BIC_CODE: obj.setAmendIssuingBicCode(rs.getString(++pos));
                    break;
                case AMEND_ISSUING_ROUTID: obj.setAmendIssuingRoutid(rs.getString(++pos));
                    break;
                case AMEND_ISSUING_BNK_CODE: obj.setAmendIssuingBnkCode(rs.getString(++pos));
                    break;
                case AMEND_ISSUING_ADDR1: obj.setAmendIssuingAddr1(rs.getString(++pos));
                    break;
                case AMEND_ISSUING_ADDR2: obj.setAmendIssuingAddr2(rs.getString(++pos));
                    break;
                case AMEND_ISSUING_ADDR3: obj.setAmendIssuingAddr3(rs.getString(++pos));
                    break;
                case AMEND_ISSUING_ADDR4: obj.setAmendIssuingAddr4(rs.getString(++pos));
                    break;
                case AMEND_ISSUING_ADDR5: obj.setAmendIssuingAddr5(rs.getString(++pos));
                    break;
                case AMEND_NON_BNK_ISSUR: obj.setAmendNonBnkIssur(rs.getString(++pos));
                    break;
                case AMEND_DATE_OF_ISSUE: obj.setAmendDateOfIssue(rs.getDate(++pos));
                    break;
                case AMEND_DATE_OF_AMENDMENT: obj.setAmendDateOfAmendment(rs.getDate(++pos));
                    break;
                case AMEND_PURPOSE_OF_MSG: obj.setAmendPurposeOfMsg(stringToChar(rs.getString(++pos)));
                    break;
                case AMEND_CANCEL_REQUEST: obj.setAmendCancelRequest(rs.getString(++pos));
                    break;
                case AMEND_ADVISING_BNK_REQ: obj.setAmendAdvisingBnkReq(stringToChar(rs.getString(++pos)));
                    break;
                case AMEND_ADVISING_BNK_TYPE: obj.setAmendAdvisingBnkType(stringToChar(rs.getString(++pos)));
                    break;
                case AMEND_ADVISING_BRN_CODE: obj.setAmendAdvisingBrnCode(rs.getString(++pos));
                    break;
                case AMEND_ADVISING_BIC_CODE: obj.setAmendAdvisingBicCode(rs.getString(++pos));
                    break;
                case AMEND_ADVISING_ROUTID: obj.setAmendAdvisingRoutid(rs.getString(++pos));
                    break;
                case AMEND_ADVISING_BNK_CODE: obj.setAmendAdvisingBnkCode(rs.getString(++pos));
                    break;
                case AMEND_ADVISING_ADDR1: obj.setAmendAdvisingAddr1(rs.getString(++pos));
                    break;
                case AMEND_ADVISING_ADDR2: obj.setAmendAdvisingAddr2(rs.getString(++pos));
                    break;
                case AMEND_ADVISING_ADDR3: obj.setAmendAdvisingAddr3(rs.getString(++pos));
                    break;
                case AMEND_ADVISING_ADDR4: obj.setAmendAdvisingAddr4(rs.getString(++pos));
                    break;
                case AMEND_ADVISING_ADDR5: obj.setAmendAdvisingAddr5(rs.getString(++pos));
                    break;
                case AMEND_SECOND_ADV_REQ: obj.setAmendSecondAdvReq(stringToChar(rs.getString(++pos)));
                    break;
                case AMEND_SECOND_ADV_TYPE: obj.setAmendSecondAdvType(stringToChar(rs.getString(++pos)));
                    break;
                case AMEND_SECOND_ADV_BRN_CODE: obj.setAmendSecondAdvBrnCode(rs.getString(++pos));
                    break;
                case AMEND_SECOND_ADV_BIC_CODE: obj.setAmendSecondAdvBicCode(rs.getString(++pos));
                    break;
                case AMEND_SECOND_ADV_ROUTID: obj.setAmendSecondAdvRoutid(rs.getString(++pos));
                    break;
                case AMEND_SECOND_ADV_BNK_CODE: obj.setAmendSecondAdvBnkCode(rs.getString(++pos));
                    break;
                case AMEND_SECOND_ADV_ADDR1: obj.setAmendSecondAdvAddr1(rs.getString(++pos));
                    break;
                case AMEND_SECOND_ADV_ADDR2: obj.setAmendSecondAdvAddr2(rs.getString(++pos));
                    break;
                case AMEND_SECOND_ADV_ADDR3: obj.setAmendSecondAdvAddr3(rs.getString(++pos));
                    break;
                case AMEND_SECOND_ADV_ADDR4: obj.setAmendSecondAdvAddr4(rs.getString(++pos));
                    break;
                case AMEND_SECOND_ADV_ADDR5: obj.setAmendSecondAdvAddr5(rs.getString(++pos));
                    break;
                case AMEND_NEW_BENEFICIARY: obj.setAmendNewBeneficiary(rs.getString(++pos));
                    break;
                case AMEND_NEW_DATE_OF_EXPIRY: obj.setAmendNewDateOfExpiry(rs.getDate(++pos));
                    break;
                case AMEND_INCR_DOC_CR_AMT: obj.setAmendIncrDocCrAmt(rs.getDouble(++pos));
                    break;
                case AMEND_DECR_DOC_CR_AMT: obj.setAmendDecrDocCrAmt(rs.getDouble(++pos));
                    break;
                case AMEND_NEW_ADDNL_AMT: obj.setAmendNewAddnlAmt(rs.getDouble(++pos));
                    break;
                case AMEND_PLACE_TAKIN_IN_CHRG: obj.setAmendPlaceTakinInChrg(rs.getString(++pos));
                    break;
                case AMEND_PORT_OF_LOADING: obj.setAmendPortOfLoading(rs.getString(++pos));
                    break;
                case AMEND_PORT_OF_DISCHARGE: obj.setAmendPortOfDischarge(rs.getString(++pos));
                    break;
                case AMEND_PLACE_OF_FINAL_DEST: obj.setAmendPlaceOfFinalDest(rs.getString(++pos));
                    break;
                case AMEND_DATE_OF_SHIPMENT: obj.setAmendDateOfShipment(rs.getDate(++pos));
                    break;
                case AMEND_DESC_GODD_SER1: obj.setAmendDescGoddSer1(rs.getObject(++pos));
                    break;
                case AMEND_DOC_REQ1: obj.setAmendDocReq1(rs.getObject(++pos));
                    break;
                case AMEND_ADD_CONDITION1: obj.setAmendAddCondition1(rs.getObject(++pos));
                    break;
                case AMEND_CHRG_PAYABLE1: obj.setAmendChrgPayable1(rs.getString(++pos));
                    break;
                case AMEND_CHRG_PAYABLE2: obj.setAmendChrgPayable2(rs.getString(++pos));
                    break;
                case AMEND_CHRG_PAYABLE3: obj.setAmendChrgPayable3(rs.getString(++pos));
                    break;
                case AMEND_CHRG_PAYABLE4: obj.setAmendChrgPayable4(rs.getString(++pos));
                    break;
                case AMEND_CHRG_PAYABLE5: obj.setAmendChrgPayable5(rs.getString(++pos));
                    break;
                case AMEND_CHRG_PAYABLE6: obj.setAmendChrgPayable6(rs.getString(++pos));
                    break;
                case AMEND_SNDR_REC_INFO1: obj.setAmendSndrRecInfo1(rs.getString(++pos));
                    break;
                case AMEND_SNDR_REC_INFO2: obj.setAmendSndrRecInfo2(rs.getString(++pos));
                    break;
                case AMEND_SNDR_REC_INFO3: obj.setAmendSndrRecInfo3(rs.getString(++pos));
                    break;
                case AMEND_SNDR_REC_INFO4: obj.setAmendSndrRecInfo4(rs.getString(++pos));
                    break;
                case AMEND_SNDR_REC_INFO5: obj.setAmendSndrRecInfo5(rs.getString(++pos));
                    break;
                case AMEND_SNDR_REC_INFO6: obj.setAmendSndrRecInfo6(rs.getString(++pos));
                    break;
                case AMEND_CHKBOX: obj.setAmendChkbox(rs.getString(++pos));
                    break;
                case AMEND_ISSUING_CNTRY: obj.setAmendIssuingCntry(rs.getString(++pos));
                    break;
                case AMEND_ADVISING_CNTRY: obj.setAmendAdvisingCntry(rs.getString(++pos));
                    break;
                case AMEND_SECOND_ADV_CNTRY: obj.setAmendSecondAdvCntry(rs.getString(++pos));
                    break;
                case AMEND_ISSUE_REF: obj.setAmendIssueRef(rs.getString(++pos));
                    break;
                case AMEND_FORM_OF_DOC_CREDIT: obj.setAmendFormOfDocCredit(rs.getInt(++pos));
                    break;
                case AMEND_LC_APPLICABLE_RULES: obj.setAmendLcApplicableRules(rs.getInt(++pos));
                    break;
                case AMEND_LC_APPLICANT_REQ: obj.setAmendLcApplicantReq(stringToChar(rs.getString(++pos)));
                    break;
                case AMEND_LC_APPLICANT_NAME: obj.setAmendLcApplicantName(rs.getString(++pos));
                    break;
                case AMEND_LC_APPLICANT_ADDR1: obj.setAmendLcApplicantAddr1(rs.getString(++pos));
                    break;
                case AMEND_LC_APPLICANT_ADDR2: obj.setAmendLcApplicantAddr2(rs.getString(++pos));
                    break;
                case AMEND_LC_APPLICANT_ADDR3: obj.setAmendLcApplicantAddr3(rs.getString(++pos));
                    break;
                case AMEND_LC_APPLICANT_ADDR4: obj.setAmendLcApplicantAddr4(rs.getString(++pos));
                    break;
                case AMEND_LC_APPLICANT_ADDR5: obj.setAmendLcApplicantAddr5(rs.getString(++pos));
                    break;
                case AMEND_LC_AVL_WITH_TYPE: obj.setAmendLcAvlWithType(stringToChar(rs.getString(++pos)));
                    break;
                case AMEND_LC_AVL_WITH_BRN_CODE: obj.setAmendLcAvlWithBrnCode(rs.getString(++pos));
                    break;
                case AMEND_LC_AVL_WITH_BIC_CODE: obj.setAmendLcAvlWithBicCode(rs.getString(++pos));
                    break;
                case AMEND_LC_LC_AVL_WITH_ROUTID: obj.setAmendLcLcAvlWithRoutid(rs.getString(++pos));
                    break;
                case AMEND_LC_AVL_WITH_BNK_CODE: obj.setAmendLcAvlWithBnkCode(rs.getString(++pos));
                    break;
                case AMEND_LC_AVL_WITH_ADDR1: obj.setAmendLcAvlWithAddr1(rs.getString(++pos));
                    break;
                case AMEND_LC_AVL_WITH_ADDR2: obj.setAmendLcAvlWithAddr2(rs.getString(++pos));
                    break;
                case AMEND_LC_AVL_WITH_ADDR3: obj.setAmendLcAvlWithAddr3(rs.getString(++pos));
                    break;
                case AMEND_LC_AVL_WITH_ADDR4: obj.setAmendLcAvlWithAddr4(rs.getString(++pos));
                    break;
                case AMEND_LC_AVL_WITH_ADDR5: obj.setAmendLcAvlWithAddr5(rs.getString(++pos));
                    break;
                case AMEND_LC_AVL_WITH_CNTRY: obj.setAmendLcAvlWithCntry(rs.getString(++pos));
                    break;
                case AMEND_LC_DRAFTS_AT1: obj.setAmendLcDraftsAt1(rs.getString(++pos));
                    break;
                case AMEND_LC_DRAFTS_AT2: obj.setAmendLcDraftsAt2(rs.getString(++pos));
                    break;
                case AMEND_LC_DRAFTS_AT3: obj.setAmendLcDraftsAt3(rs.getString(++pos));
                    break;
                case AMEND_LC_DRAWEE_REQ: obj.setAmendLcDraweeReq(stringToChar(rs.getString(++pos)));
                    break;
                case AMEND_LC_DRAWEE_TYPE: obj.setAmendLcDraweeType(stringToChar(rs.getString(++pos)));
                    break;
                case AMEND_LC_DRAWEE_BRN_CODE: obj.setAmendLcDraweeBrnCode(rs.getString(++pos));
                    break;
                case AMEND_LC_DRAWEE_BIC_CODE: obj.setAmendLcDraweeBicCode(rs.getString(++pos));
                    break;
                case AMEND_LC_DRAWEE_ROUTID: obj.setAmendLcDraweeRoutid(rs.getString(++pos));
                    break;
                case AMEND_LC_DRAWEE_BNK_CODE: obj.setAmendLcDraweeBnkCode(rs.getString(++pos));
                    break;
                case AMEND_LC_DRAWEE_ADDR1: obj.setAmendLcDraweeAddr1(rs.getString(++pos));
                    break;
                case AMEND_LC_DRAWEE_ADDR2: obj.setAmendLcDraweeAddr2(rs.getString(++pos));
                    break;
                case AMEND_LC_DRAWEE_ADDR3: obj.setAmendLcDraweeAddr3(rs.getString(++pos));
                    break;
                case AMEND_LC_DRAWEE_ADDR4: obj.setAmendLcDraweeAddr4(rs.getString(++pos));
                    break;
                case AMEND_LC_DRAWEE_ADDR5: obj.setAmendLcDraweeAddr5(rs.getString(++pos));
                    break;
                case AMEND_DRAWEE_CNTRY_CODE: obj.setAmendDraweeCntryCode(rs.getString(++pos));
                    break;
                case AMEND_LC_MIXED_PAY_DETAILS1: obj.setAmendLcMixedPayDetails1(rs.getString(++pos));
                    break;
                case AMEND_LC_MIXED_PAY_DETAILS2: obj.setAmendLcMixedPayDetails2(rs.getString(++pos));
                    break;
                case AMEND_LC_MIXED_PAY_DETAILS3: obj.setAmendLcMixedPayDetails3(rs.getString(++pos));
                    break;
                case AMEND_LC_MIXED_PAY_DETAILS4: obj.setAmendLcMixedPayDetails4(rs.getString(++pos));
                    break;
                case AMEND_LC_MIXED_PAY_DETAILS5: obj.setAmendLcMixedPayDetails5(rs.getString(++pos));
                    break;
                case AMEND_LC_DEFERRED_PAY_DETAILS1: obj.setAmendLcDeferredPayDetails1(rs.getString(++pos));
                    break;
                case AMEND_LC_DEFERRED_PAY_DETAILS2: obj.setAmendLcDeferredPayDetails2(rs.getString(++pos));
                    break;
                case AMEND_LC_DEFERRED_PAY_DETAILS3: obj.setAmendLcDeferredPayDetails3(rs.getString(++pos));
                    break;
                case AMEND_LC_DEFERRED_PAY_DETAILS4: obj.setAmendLcDeferredPayDetails4(rs.getString(++pos));
                    break;
                case AMEND_LC_DEFERRED_PAY_DETAILS5: obj.setAmendLcDeferredPayDetails5(rs.getString(++pos));
                    break;
                case AMEND_LC_PARTIAL_SHIPMENTS: obj.setAmendLcPartialShipments(rs.getInt(++pos));
                    break;
                case AMEND_LC_TRANSHIPMENT: obj.setAmendLcTranshipment(rs.getInt(++pos));
                    break;
                case AMEND_LC_CONFIRMATION_INST: obj.setAmendLcConfirmationInst(rs.getInt(++pos));
                    break;
                case AMEND_LC_REIMB_REQ: obj.setAmendLcReimbReq(stringToChar(rs.getString(++pos)));
                    break;
                case AMEND_LC_REIMB_TYPE: obj.setAmendLcReimbType(stringToChar(rs.getString(++pos)));
                    break;
                case AMEND_LC_REIMB_BRN_CODE: obj.setAmendLcReimbBrnCode(rs.getString(++pos));
                    break;
                case AMEND_LC_REIMB_BIC_CODE: obj.setAmendLcReimbBicCode(rs.getString(++pos));
                    break;
                case AMEND_LC_REIMB_ROUTID: obj.setAmendLcReimbRoutid(rs.getString(++pos));
                    break;
                case AMEND_LC_REIMB_BNK_CODE: obj.setAmendLcReimbBnkCode(rs.getString(++pos));
                    break;
                case AMEND_LC_REIMB_ADDR1: obj.setAmendLcReimbAddr1(rs.getString(++pos));
                    break;
                case AMEND_LC_REIMB_ADDR2: obj.setAmendLcReimbAddr2(rs.getString(++pos));
                    break;
                case AMEND_LC_REIMB_ADDR3: obj.setAmendLcReimbAddr3(rs.getString(++pos));
                    break;
                case AMEND_LC_REIMB_ADDR4: obj.setAmendLcReimbAddr4(rs.getString(++pos));
                    break;
                case AMEND_LC_REIMB_ADDR5: obj.setAmendLcReimbAddr5(rs.getString(++pos));
                    break;
                case AMEND_LC_INST_PAYING1: obj.setAmendLcInstPaying1(rs.getString(++pos));
                    break;
                case AMEND_LC_INST_PAYING2: obj.setAmendLcInstPaying2(rs.getString(++pos));
                    break;
                case AMEND_LC_INST_PAYING3: obj.setAmendLcInstPaying3(rs.getString(++pos));
                    break;
                case AMEND_LC_INST_PAYING4: obj.setAmendLcInstPaying4(rs.getString(++pos));
                    break;
                case AMEND_LC_INST_PAYING5: obj.setAmendLcInstPaying5(rs.getString(++pos));
                    break;
                case AMEND_LC_INST_PAYING6: obj.setAmendLcInstPaying6(rs.getString(++pos));
                    break;
                case AMEND_LC_INST_PAYING7: obj.setAmendLcInstPaying7(rs.getString(++pos));
                    break;
                case AMEND_LC_INST_PAYING8: obj.setAmendLcInstPaying8(rs.getString(++pos));
                    break;
                case AMEND_LC_INST_PAYING9: obj.setAmendLcInstPaying9(rs.getString(++pos));
                    break;
                case AMEND_LC_INST_PAYING10: obj.setAmendLcInstPaying10(rs.getString(++pos));
                    break;
                case AMEND_LC_INST_PAYING11: obj.setAmendLcInstPaying11(rs.getString(++pos));
                    break;
                case AMEND_LC_INST_PAYING12: obj.setAmendLcInstPaying12(rs.getString(++pos));
                    break;
                case AMEND_LC_SECOND_ADV_REQ: obj.setAmendLcSecondAdvReq(stringToChar(rs.getString(++pos)));
                    break;
                case AMEND_LC_SECOND_ADV_TYPE: obj.setAmendLcSecondAdvType(stringToChar(rs.getString(++pos)));
                    break;
                case AMEND_LC_SECOND_ADV_BRN_CODE: obj.setAmendLcSecondAdvBrnCode(rs.getString(++pos));
                    break;
                case AMEND_LC_SECOND_ADV_BIC_CODE: obj.setAmendLcSecondAdvBicCode(rs.getString(++pos));
                    break;
                case AMEND_LC_SECOND_ADV_ROUTID: obj.setAmendLcSecondAdvRoutid(rs.getString(++pos));
                    break;
                case AMEND_LC_SECOND_ADV_BNK_CODE: obj.setAmendLcSecondAdvBnkCode(rs.getString(++pos));
                    break;
                case AMEND_LC_SECOND_ADV_ADDR1: obj.setAmendLcSecondAdvAddr1(rs.getString(++pos));
                    break;
                case AMEND_LC_SECOND_ADV_ADDR2: obj.setAmendLcSecondAdvAddr2(rs.getString(++pos));
                    break;
                case AMEND_LC_SECOND_ADV_ADDR3: obj.setAmendLcSecondAdvAddr3(rs.getString(++pos));
                    break;
                case AMEND_LC_SECOND_ADV_ADDR4: obj.setAmendLcSecondAdvAddr4(rs.getString(++pos));
                    break;
                case AMEND_LC_SECOND_ADV_ADDR5: obj.setAmendLcSecondAdvAddr5(rs.getString(++pos));
                    break;
                case AMEND_LC_SECOND_ADV_CNTRYCODE: obj.setAmendLcSecondAdvCntrycode(rs.getString(++pos));
                    break;
                case AMEND_LC_AVL_WITH_CODETYP: obj.setAmendLcAvlWithCodetyp(stringToChar(rs.getString(++pos)));
                    break;
                case AMEND_LC_REIMB_CNTRY_CODE: obj.setAmendLcReimbCntryCode(rs.getString(++pos));
                    break;
                case AMEND_LC_CNF_ADV_TYPE: obj.setAmendLcCnfAdvType(stringToChar(rs.getString(++pos)));
                    break;
                case AMEND_LC_CNF_ADV_BRN_CODE: obj.setAmendLcCnfAdvBrnCode(rs.getString(++pos));
                    break;
                case AMEND_LC_CNF_ADV_BIC_CODE: obj.setAmendLcCnfAdvBicCode(rs.getString(++pos));
                    break;
                case AMEND_LC_CNF_ADV_ROUTID: obj.setAmendLcCnfAdvRoutid(rs.getString(++pos));
                    break;
                case AMEND_LC_CNF_ADV_BNK_CODE: obj.setAmendLcCnfAdvBnkCode(rs.getString(++pos));
                    break;
                case AMEND_LC_CNF_ADV_ADDR1: obj.setAmendLcCnfAdvAddr1(rs.getString(++pos));
                    break;
                case AMEND_LC_CNF_ADV_ADDR2: obj.setAmendLcCnfAdvAddr2(rs.getString(++pos));
                    break;
                case AMEND_LC_CNF_ADV_ADDR3: obj.setAmendLcCnfAdvAddr3(rs.getString(++pos));
                    break;
                case AMEND_LC_CNF_ADV_ADDR4: obj.setAmendLcCnfAdvAddr4(rs.getString(++pos));
                    break;
                case AMEND_LC_CNF_ADV_ADDR5: obj.setAmendLcCnfAdvAddr5(rs.getString(++pos));
                    break;
                case AMEND_LC_CNF_ADV_CNTRYCODE: obj.setAmendLcCnfAdvCntrycode(rs.getString(++pos));
                    break;
            }
        }
        obj.setIsNew(false);
        obj.resetIsModifiedS2J();

        return obj;
    }
    public void save(AmendDetails obj, String tba_main_key, Timestamp tba_entry_date, long tab_dtl_sl ) throws SQLException {
            NewData_Key = "AMEND_DETAILS" + TableValueSep + NewDataChar + obj.getAmendLcBrnCode() + obj.getAmendLcType() + obj.getAmendLcYear() + obj.getAmendLcSerial() + obj.getAmendLcAmdSl();
            DataBlock_New = obj.getAmendLcBrnCode() + JNDINames.splitchar + obj.getAmendLcType() + JNDINames.splitchar + obj.getAmendLcYear() + JNDINames.splitchar + obj.getAmendLcSerial() + JNDINames.splitchar + obj.getAmendLcAmdSl() + JNDINames.splitchar + obj.getAmendSndrRef() + JNDINames.splitchar + obj.getAmendRcvrRef() + JNDINames.splitchar + obj.getAmendDocCrNum() + JNDINames.splitchar + obj.getAmendIssuingBnkReq() + JNDINames.splitchar + obj.getAmendIssuingType() + JNDINames.splitchar + obj.getAmendIssuingBrnCode() + JNDINames.splitchar + obj.getAmendIssuingBicCode() + JNDINames.splitchar + obj.getAmendIssuingRoutid() + JNDINames.splitchar + obj.getAmendIssuingBnkCode() + JNDINames.splitchar + obj.getAmendIssuingAddr1() + JNDINames.splitchar + obj.getAmendIssuingAddr2() + JNDINames.splitchar + obj.getAmendIssuingAddr3() + JNDINames.splitchar + obj.getAmendIssuingAddr4() + JNDINames.splitchar + obj.getAmendIssuingAddr5() + JNDINames.splitchar + obj.getAmendNonBnkIssur() + JNDINames.splitchar + obj.getAmendDateOfIssue() + JNDINames.splitchar + obj.getAmendDateOfAmendment() + JNDINames.splitchar + obj.getAmendPurposeOfMsg() + JNDINames.splitchar + obj.getAmendCancelRequest() + JNDINames.splitchar + obj.getAmendAdvisingBnkReq() + JNDINames.splitchar + obj.getAmendAdvisingBnkType() + JNDINames.splitchar + obj.getAmendAdvisingBrnCode() + JNDINames.splitchar + obj.getAmendAdvisingBicCode() + JNDINames.splitchar + obj.getAmendAdvisingRoutid() + JNDINames.splitchar + obj.getAmendAdvisingBnkCode() + JNDINames.splitchar + obj.getAmendAdvisingAddr1() + JNDINames.splitchar + obj.getAmendAdvisingAddr2() + JNDINames.splitchar + obj.getAmendAdvisingAddr3() + JNDINames.splitchar + obj.getAmendAdvisingAddr4() + JNDINames.splitchar + obj.getAmendAdvisingAddr5() + JNDINames.splitchar + obj.getAmendSecondAdvReq() + JNDINames.splitchar + obj.getAmendSecondAdvType() + JNDINames.splitchar + obj.getAmendSecondAdvBrnCode() + JNDINames.splitchar + obj.getAmendSecondAdvBicCode() + JNDINames.splitchar + obj.getAmendSecondAdvRoutid() + JNDINames.splitchar + obj.getAmendSecondAdvBnkCode() + JNDINames.splitchar + obj.getAmendSecondAdvAddr1() + JNDINames.splitchar + obj.getAmendSecondAdvAddr2() + JNDINames.splitchar + obj.getAmendSecondAdvAddr3() + JNDINames.splitchar + obj.getAmendSecondAdvAddr4() + JNDINames.splitchar + obj.getAmendSecondAdvAddr5() + JNDINames.splitchar + obj.getAmendNewBeneficiary() + JNDINames.splitchar + obj.getAmendNewDateOfExpiry() + JNDINames.splitchar + obj.getAmendIncrDocCrAmt() + JNDINames.splitchar + obj.getAmendDecrDocCrAmt() + JNDINames.splitchar + obj.getAmendNewAddnlAmt() + JNDINames.splitchar + obj.getAmendPlaceTakinInChrg() + JNDINames.splitchar + obj.getAmendPortOfLoading() + JNDINames.splitchar + obj.getAmendPortOfDischarge() + JNDINames.splitchar + obj.getAmendPlaceOfFinalDest() + JNDINames.splitchar + obj.getAmendDateOfShipment() + JNDINames.splitchar + obj.getAmendDescGoddSer1() + JNDINames.splitchar + obj.getAmendDocReq1() + JNDINames.splitchar + obj.getAmendAddCondition1() + JNDINames.splitchar + obj.getAmendChrgPayable1() + JNDINames.splitchar + obj.getAmendChrgPayable2() + JNDINames.splitchar + obj.getAmendChrgPayable3() + JNDINames.splitchar + obj.getAmendChrgPayable4() + JNDINames.splitchar + obj.getAmendChrgPayable5() + JNDINames.splitchar + obj.getAmendChrgPayable6() + JNDINames.splitchar + obj.getAmendSndrRecInfo1() + JNDINames.splitchar + obj.getAmendSndrRecInfo2() + JNDINames.splitchar + obj.getAmendSndrRecInfo3() + JNDINames.splitchar + obj.getAmendSndrRecInfo4() + JNDINames.splitchar + obj.getAmendSndrRecInfo5() + JNDINames.splitchar + obj.getAmendSndrRecInfo6() + JNDINames.splitchar + obj.getAmendChkbox() + JNDINames.splitchar + obj.getAmendIssuingCntry() + JNDINames.splitchar + obj.getAmendAdvisingCntry() + JNDINames.splitchar + obj.getAmendSecondAdvCntry() + JNDINames.splitchar + obj.getAmendIssueRef() + JNDINames.splitchar + obj.getAmendFormOfDocCredit() + JNDINames.splitchar + obj.getAmendLcApplicableRules() + JNDINames.splitchar + obj.getAmendLcApplicantReq() + JNDINames.splitchar + obj.getAmendLcApplicantName() + JNDINames.splitchar + obj.getAmendLcApplicantAddr1() + JNDINames.splitchar + obj.getAmendLcApplicantAddr2() + JNDINames.splitchar + obj.getAmendLcApplicantAddr3() + JNDINames.splitchar + obj.getAmendLcApplicantAddr4() + JNDINames.splitchar + obj.getAmendLcApplicantAddr5() + JNDINames.splitchar + obj.getAmendLcAvlWithType() + JNDINames.splitchar + obj.getAmendLcAvlWithBrnCode() + JNDINames.splitchar + obj.getAmendLcAvlWithBicCode() + JNDINames.splitchar + obj.getAmendLcLcAvlWithRoutid() + JNDINames.splitchar + obj.getAmendLcAvlWithBnkCode() + JNDINames.splitchar + obj.getAmendLcAvlWithAddr1() + JNDINames.splitchar + obj.getAmendLcAvlWithAddr2() + JNDINames.splitchar + obj.getAmendLcAvlWithAddr3() + JNDINames.splitchar + obj.getAmendLcAvlWithAddr4() + JNDINames.splitchar + obj.getAmendLcAvlWithAddr5() + JNDINames.splitchar + obj.getAmendLcAvlWithCntry() + JNDINames.splitchar + obj.getAmendLcDraftsAt1() + JNDINames.splitchar + obj.getAmendLcDraftsAt2() + JNDINames.splitchar + obj.getAmendLcDraftsAt3() + JNDINames.splitchar + obj.getAmendLcDraweeReq() + JNDINames.splitchar + obj.getAmendLcDraweeType() + JNDINames.splitchar + obj.getAmendLcDraweeBrnCode() + JNDINames.splitchar + obj.getAmendLcDraweeBicCode() + JNDINames.splitchar + obj.getAmendLcDraweeRoutid() + JNDINames.splitchar + obj.getAmendLcDraweeBnkCode() + JNDINames.splitchar + obj.getAmendLcDraweeAddr1() + JNDINames.splitchar + obj.getAmendLcDraweeAddr2() + JNDINames.splitchar + obj.getAmendLcDraweeAddr3() + JNDINames.splitchar + obj.getAmendLcDraweeAddr4() + JNDINames.splitchar + obj.getAmendLcDraweeAddr5() + JNDINames.splitchar + obj.getAmendDraweeCntryCode() + JNDINames.splitchar + obj.getAmendLcMixedPayDetails1() + JNDINames.splitchar + obj.getAmendLcMixedPayDetails2() + JNDINames.splitchar + obj.getAmendLcMixedPayDetails3() + JNDINames.splitchar + obj.getAmendLcMixedPayDetails4() + JNDINames.splitchar + obj.getAmendLcMixedPayDetails5() + JNDINames.splitchar + obj.getAmendLcDeferredPayDetails1() + JNDINames.splitchar + obj.getAmendLcDeferredPayDetails2() + JNDINames.splitchar + obj.getAmendLcDeferredPayDetails3() + JNDINames.splitchar + obj.getAmendLcDeferredPayDetails4() + JNDINames.splitchar + obj.getAmendLcDeferredPayDetails5() + JNDINames.splitchar + obj.getAmendLcPartialShipments() + JNDINames.splitchar + obj.getAmendLcTranshipment() + JNDINames.splitchar + obj.getAmendLcConfirmationInst() + JNDINames.splitchar + obj.getAmendLcReimbReq() + JNDINames.splitchar + obj.getAmendLcReimbType() + JNDINames.splitchar + obj.getAmendLcReimbBrnCode() + JNDINames.splitchar + obj.getAmendLcReimbBicCode() + JNDINames.splitchar + obj.getAmendLcReimbRoutid() + JNDINames.splitchar + obj.getAmendLcReimbBnkCode() + JNDINames.splitchar + obj.getAmendLcReimbAddr1() + JNDINames.splitchar + obj.getAmendLcReimbAddr2() + JNDINames.splitchar + obj.getAmendLcReimbAddr3() + JNDINames.splitchar + obj.getAmendLcReimbAddr4() + JNDINames.splitchar + obj.getAmendLcReimbAddr5() + JNDINames.splitchar + obj.getAmendLcInstPaying1() + JNDINames.splitchar + obj.getAmendLcInstPaying2() + JNDINames.splitchar + obj.getAmendLcInstPaying3() + JNDINames.splitchar + obj.getAmendLcInstPaying4() + JNDINames.splitchar + obj.getAmendLcInstPaying5() + JNDINames.splitchar + obj.getAmendLcInstPaying6() + JNDINames.splitchar + obj.getAmendLcInstPaying7() + JNDINames.splitchar + obj.getAmendLcInstPaying8() + JNDINames.splitchar + obj.getAmendLcInstPaying9() + JNDINames.splitchar + obj.getAmendLcInstPaying10() + JNDINames.splitchar + obj.getAmendLcInstPaying11() + JNDINames.splitchar + obj.getAmendLcInstPaying12() + JNDINames.splitchar + obj.getAmendLcSecondAdvReq() + JNDINames.splitchar + obj.getAmendLcSecondAdvType() + JNDINames.splitchar + obj.getAmendLcSecondAdvBrnCode() + JNDINames.splitchar + obj.getAmendLcSecondAdvBicCode() + JNDINames.splitchar + obj.getAmendLcSecondAdvRoutid() + JNDINames.splitchar + obj.getAmendLcSecondAdvBnkCode() + JNDINames.splitchar + obj.getAmendLcSecondAdvAddr1() + JNDINames.splitchar + obj.getAmendLcSecondAdvAddr2() + JNDINames.splitchar + obj.getAmendLcSecondAdvAddr3() + JNDINames.splitchar + obj.getAmendLcSecondAdvAddr4() + JNDINames.splitchar + obj.getAmendLcSecondAdvAddr5() + JNDINames.splitchar + obj.getAmendLcSecondAdvCntrycode() + JNDINames.splitchar + obj.getAmendLcAvlWithCodetyp() + JNDINames.splitchar + obj.getAmendLcReimbCntryCode() + JNDINames.splitchar + obj.getAmendLcCnfAdvType() + JNDINames.splitchar + obj.getAmendLcCnfAdvBrnCode() + JNDINames.splitchar + obj.getAmendLcCnfAdvBicCode() + JNDINames.splitchar + obj.getAmendLcCnfAdvRoutid() + JNDINames.splitchar + obj.getAmendLcCnfAdvBnkCode() + JNDINames.splitchar + obj.getAmendLcCnfAdvAddr1() + JNDINames.splitchar + obj.getAmendLcCnfAdvAddr2() + JNDINames.splitchar + obj.getAmendLcCnfAdvAddr3() + JNDINames.splitchar + obj.getAmendLcCnfAdvAddr4() + JNDINames.splitchar + obj.getAmendLcCnfAdvAddr5() + JNDINames.splitchar + obj.getAmendLcCnfAdvCntrycode();
                if (_Logreq == 1)
                {
                    if (obj.isNew() == false)
                    {
                        if (OldData_Key != null) this._COLLECTIONobj.put(OldData_Key , DataBlock_Old );
                        if (NewData_Key != null) this._COLLECTIONobj.put(NewData_Key , DataBlock_New );
                    }else if ((_Logaddreq == 1) && obj.isNew() == true)
                    {
                        if (NewData_Key != null) this._COLLECTIONobj.put(NewData_Key , DataBlock_New );
                    }
                }
            OldData_Key ="";
            DataBlock_Old = "";
            DataBlock_New = "";
            NewData_Key = "";
        {
    // This is for main table Updation
            save(obj);
        }
    }

}
