package panacea.OLC.Update;


/******************SQL2JAVA_IMPORT_BEGIN******************/

/******************SQL2JAVA_IMPORT_END********************/


public class LcDetailsHist
/******************SQL2JAVA_EXTENDS_BEGIN******************/

/******************SQL2JAVA_EXTENDS_END********************/

{

/******************SQL2JAVA_CLASS_BEGIN******************/

/******************SQL2JAVA_CLASS_END********************/


    private int _lchistBrnCode;
    private boolean __lchistBrnCode_is_modified;
    private String _lchistLcType;
    private boolean __lchistLcType_is_modified;
    private int _lchistLcYear;
    private boolean __lchistLcYear_is_modified;
    private int _lchistLcSl;
    private boolean __lchistLcSl_is_modified;
    private long _lchistLcHistsl;
    private boolean __lchistLcHistsl_is_modified;
    private java.util.Date _lchistLcHistdate;
    private boolean __lchistLcHistdate_is_modified;
    private int _lchistFormOfDocCredit;
    private boolean __lchistFormOfDocCredit_is_modified;
    private String _lchistReferenceToPreadvice;
    private boolean __lchistReferenceToPreadvice_is_modified;
    private int _lchistApplicableRules;
    private boolean __lchistApplicableRules_is_modified;
    private char _lchistApplicantReq;
    private boolean __lchistApplicantReq_is_modified;
    private char _lchistApplicantType;
    private boolean __lchistApplicantType_is_modified;
    private String _lchistApplicantBrnCode;
    private boolean __lchistApplicantBrnCode_is_modified;
    private String _lchistApplicantBicCode;
    private boolean __lchistApplicantBicCode_is_modified;
    private String _lchistApplicantRoutid;
    private boolean __lchistApplicantRoutid_is_modified;
    private String _lchistApplicantBnkCode;
    private boolean __lchistApplicantBnkCode_is_modified;
    private String _lchistApplicantAddr1;
    private boolean __lchistApplicantAddr1_is_modified;
    private String _lchistApplicantAddr2;
    private boolean __lchistApplicantAddr2_is_modified;
    private String _lchistApplicantAddr3;
    private boolean __lchistApplicantAddr3_is_modified;
    private String _lchistApplicantAddr4;
    private boolean __lchistApplicantAddr4_is_modified;
    private String _lchistApplicantAddr5;
    private boolean __lchistApplicantAddr5_is_modified;
    private char _lchistAvailableWithType;
    private boolean __lchistAvailableWithType_is_modified;
    private String _lchistAvailableWithBrnCode;
    private boolean __lchistAvailableWithBrnCode_is_modified;
    private String _lchistAvailableWithCode;
    private boolean __lchistAvailableWithCode_is_modified;
    private String _lchistAvailableWithRoutid;
    private boolean __lchistAvailableWithRoutid_is_modified;
    private String _lchistAvailableWithBnkCode;
    private boolean __lchistAvailableWithBnkCode_is_modified;
    private String _lchistAvailableWithAddr1;
    private boolean __lchistAvailableWithAddr1_is_modified;
    private String _lchistAvailableWithAddr2;
    private boolean __lchistAvailableWithAddr2_is_modified;
    private String _lchistAvailableWithAddr3;
    private boolean __lchistAvailableWithAddr3_is_modified;
    private String _lchistAvailableWithAddr4;
    private boolean __lchistAvailableWithAddr4_is_modified;
    private String _lchistAvailableWithAddr5;
    private boolean __lchistAvailableWithAddr5_is_modified;
    private String _lchistDraftsAt1;
    private boolean __lchistDraftsAt1_is_modified;
    private String _lchistDraftsAt2;
    private boolean __lchistDraftsAt2_is_modified;
    private String _lchistDraftsAt3;
    private boolean __lchistDraftsAt3_is_modified;
    private char _lchistDraweeReq;
    private boolean __lchistDraweeReq_is_modified;
    private char _lchistDraweeType;
    private boolean __lchistDraweeType_is_modified;
    private String _lchistDraweeBrnCode;
    private boolean __lchistDraweeBrnCode_is_modified;
    private String _lchistDraweeBicCode;
    private boolean __lchistDraweeBicCode_is_modified;
    private String _lchistDraweeRoutid;
    private boolean __lchistDraweeRoutid_is_modified;
    private String _lchistDraweeBnkCode;
    private boolean __lchistDraweeBnkCode_is_modified;
    private String _lchistDraweeAddr1;
    private boolean __lchistDraweeAddr1_is_modified;
    private String _lchistDraweeAddr2;
    private boolean __lchistDraweeAddr2_is_modified;
    private String _lchistDraweeAddr3;
    private boolean __lchistDraweeAddr3_is_modified;
    private String _lchistDraweeAddr4;
    private boolean __lchistDraweeAddr4_is_modified;
    private String _lchistDraweeAddr5;
    private boolean __lchistDraweeAddr5_is_modified;
    private String _lchistMixedPayDetails1;
    private boolean __lchistMixedPayDetails1_is_modified;
    private String _lchistMixedPayDetails2;
    private boolean __lchistMixedPayDetails2_is_modified;
    private String _lchistMixedPayDetails3;
    private boolean __lchistMixedPayDetails3_is_modified;
    private String _lchistMixedPayDetails4;
    private boolean __lchistMixedPayDetails4_is_modified;
    private String _lchistDeferredPayDetails1;
    private boolean __lchistDeferredPayDetails1_is_modified;
    private String _lchistDeferredPayDetails2;
    private boolean __lchistDeferredPayDetails2_is_modified;
    private String _lchistDeferredPayDetails3;
    private boolean __lchistDeferredPayDetails3_is_modified;
    private String _lchistDeferredPayDetails4;
    private boolean __lchistDeferredPayDetails4_is_modified;
    private int _lchistPartialShipments;
    private boolean __lchistPartialShipments_is_modified;
    private int _lchistTranshipment;
    private boolean __lchistTranshipment_is_modified;
    private String _lchistPlaceInCharge;
    private boolean __lchistPlaceInCharge_is_modified;
    private String _lchistPortOfLoading;
    private boolean __lchistPortOfLoading_is_modified;
    private String _lchistPortOfDischarge;
    private boolean __lchistPortOfDischarge_is_modified;
    private String _lchistPlaceOfFinalDest;
    private boolean __lchistPlaceOfFinalDest_is_modified;
    private Object _lchistDescGoodsSer1;
    private boolean __lchistDescGoodsSer1_is_modified;
    private Object _lchistDescGoodsSer2;
    private boolean __lchistDescGoodsSer2_is_modified;
    private Object _lchistDescGoodsSer3;
    private boolean __lchistDescGoodsSer3_is_modified;
    private Object _lchistDocReq1;
    private boolean __lchistDocReq1_is_modified;
    private Object _lchistDocReq2;
    private boolean __lchistDocReq2_is_modified;
    private Object _lchistDocReq3;
    private boolean __lchistDocReq3_is_modified;
    private Object _lchistAddCondition1;
    private boolean __lchistAddCondition1_is_modified;
    private Object _lchistAddCondition2;
    private boolean __lchistAddCondition2_is_modified;
    private Object _lchistAddCondition3;
    private boolean __lchistAddCondition3_is_modified;
    private String _lchistCharges1;
    private boolean __lchistCharges1_is_modified;
    private String _lchistCharges2;
    private boolean __lchistCharges2_is_modified;
    private String _lchistCharges3;
    private boolean __lchistCharges3_is_modified;
    private String _lchistCharges4;
    private boolean __lchistCharges4_is_modified;
    private String _lchistCharges5;
    private boolean __lchistCharges5_is_modified;
    private String _lchistCharges6;
    private boolean __lchistCharges6_is_modified;
    private int _lchistPerPresentationDay;
    private boolean __lchistPerPresentationDay_is_modified;
    private int _lchistConfirmationInst;
    private boolean __lchistConfirmationInst_is_modified;
    private char _lchistReimbReq;
    private boolean __lchistReimbReq_is_modified;
    private char _lchistReimbType;
    private boolean __lchistReimbType_is_modified;
    private String _lchistReimbBrnCode;
    private boolean __lchistReimbBrnCode_is_modified;
    private String _lchistReimbBicCode;
    private boolean __lchistReimbBicCode_is_modified;
    private String _lchistReimbRoutid;
    private boolean __lchistReimbRoutid_is_modified;
    private String _lchistReimbBnkCode;
    private boolean __lchistReimbBnkCode_is_modified;
    private String _lchistReimbAddr1;
    private boolean __lchistReimbAddr1_is_modified;
    private String _lchistReimbAddr2;
    private boolean __lchistReimbAddr2_is_modified;
    private String _lchistReimbAddr3;
    private boolean __lchistReimbAddr3_is_modified;
    private String _lchistReimbAddr4;
    private boolean __lchistReimbAddr4_is_modified;
    private String _lchistReimbAddr5;
    private boolean __lchistReimbAddr5_is_modified;
    private String _lchistInstPaying1;
    private boolean __lchistInstPaying1_is_modified;
    private String _lchistInstPaying2;
    private boolean __lchistInstPaying2_is_modified;
    private String _lchistInstPaying3;
    private boolean __lchistInstPaying3_is_modified;
    private String _lchistInstPaying4;
    private boolean __lchistInstPaying4_is_modified;
    private String _lchistInstPaying5;
    private boolean __lchistInstPaying5_is_modified;
    private String _lchistInstPaying6;
    private boolean __lchistInstPaying6_is_modified;
    private String _lchistInstPaying7;
    private boolean __lchistInstPaying7_is_modified;
    private String _lchistInstPaying8;
    private boolean __lchistInstPaying8_is_modified;
    private String _lchistInstPaying9;
    private boolean __lchistInstPaying9_is_modified;
    private String _lchistInstPaying10;
    private boolean __lchistInstPaying10_is_modified;
    private String _lchistInstPaying11;
    private boolean __lchistInstPaying11_is_modified;
    private String _lchistInstPaying12;
    private boolean __lchistInstPaying12_is_modified;
    private char _lchistSecondAdvReq;
    private boolean __lchistSecondAdvReq_is_modified;
    private char _lchistSecondAdvType;
    private boolean __lchistSecondAdvType_is_modified;
    private String _lchistSecondAdvBrnCode;
    private boolean __lchistSecondAdvBrnCode_is_modified;
    private String _lchistSecondAdvBicCode;
    private boolean __lchistSecondAdvBicCode_is_modified;
    private String _lchistSecondAdvRoutid;
    private boolean __lchistSecondAdvRoutid_is_modified;
    private String _lchistSecondAdvBnkCode;
    private boolean __lchistSecondAdvBnkCode_is_modified;
    private String _lchistSecondAdvAddr1;
    private boolean __lchistSecondAdvAddr1_is_modified;
    private String _lchistSecondAdvAddr2;
    private boolean __lchistSecondAdvAddr2_is_modified;
    private String _lchistSecondAdvAddr3;
    private boolean __lchistSecondAdvAddr3_is_modified;
    private String _lchistSecondAdvAddr4;
    private boolean __lchistSecondAdvAddr4_is_modified;
    private String _lchistSecondAdvAddr5;
    private boolean __lchistSecondAdvAddr5_is_modified;
    private String _lchistSndrRecInfo1;
    private boolean __lchistSndrRecInfo1_is_modified;
    private String _lchistSndrRecInfo2;
    private boolean __lchistSndrRecInfo2_is_modified;
    private String _lchistSndrRecInfo3;
    private boolean __lchistSndrRecInfo3_is_modified;
    private String _lchistSndrRecInfo4;
    private boolean __lchistSndrRecInfo4_is_modified;
    private String _lchistSndrRecInfo5;
    private boolean __lchistSndrRecInfo5_is_modified;
    private String _lchistSndrRecInfo6;
    private boolean __lchistSndrRecInfo6_is_modified;
    private String _lchistApplicantCntryCode;
    private boolean __lchistApplicantCntryCode_is_modified;
    private String _lchistAvailableWithCntry;
    private boolean __lchistAvailableWithCntry_is_modified;
    private int _lchistAvailableWithCodetyp;
    private boolean __lchistAvailableWithCodetyp_is_modified;
    private String _lchistDraweeCntryCode;
    private boolean __lchistDraweeCntryCode_is_modified;
    private char _lchistConfirmInstType;
    private boolean __lchistConfirmInstType_is_modified;
    private String _lchistReimbCntryCode;
    private boolean __lchistReimbCntryCode_is_modified;
    private String _lchistSecondAdvCntrycode;
    private boolean __lchistSecondAdvCntrycode_is_modified;
    private String _lchistShipmentPeriod1;
    private boolean __lchistShipmentPeriod1_is_modified;
    private String _lchistShipmentPeriod2;
    private boolean __lchistShipmentPeriod2_is_modified;
    private String _lchistShipmentPeriod3;
    private boolean __lchistShipmentPeriod3_is_modified;
    private String _lchistShipmentPeriod4;
    private boolean __lchistShipmentPeriod4_is_modified;
    private String _lchistShipmentPeriod5;
    private boolean __lchistShipmentPeriod5_is_modified;
    private String _lchistShipmentPeriod6;
    private boolean __lchistShipmentPeriod6_is_modified;
    private String _lchistPerPresntRemarks;
    private boolean __lchistPerPresntRemarks_is_modified;
    private String _lchistRecBicCode;
    private boolean __lchistRecBicCode_is_modified;
    private char _lchistCfmReimbType;
    private boolean __lchistCfmReimbType_is_modified;
    private String _lchistCfmReimbBrnCode;
    private boolean __lchistCfmReimbBrnCode_is_modified;
    private String _lchistCfmReimbBicCode;
    private boolean __lchistCfmReimbBicCode_is_modified;
    private String _lchistCfmReimbRoutid;
    private boolean __lchistCfmReimbRoutid_is_modified;
    private String _lchistCfmReimbBnkCode;
    private boolean __lchistCfmReimbBnkCode_is_modified;
    private String _lchistCfmReimbAddr1;
    private boolean __lchistCfmReimbAddr1_is_modified;
    private String _lchistCfmReimbAddr2;
    private boolean __lchistCfmReimbAddr2_is_modified;
    private String _lchistCfmReimbAddr3;
    private boolean __lchistCfmReimbAddr3_is_modified;
    private String _lchistCfmReimbAddr4;
    private boolean __lchistCfmReimbAddr4_is_modified;
    private String _lchistCfmReimbAddr5;
    private boolean __lchistCfmReimbAddr5_is_modified;
    private String _lchistCfmReimbCntryCode;
    private boolean __lchistCfmReimbCntryCode_is_modified;
    private boolean _isNew = true;

    public int getLchistBrnCode() { return _lchistBrnCode; }
    public void setLchistBrnCode(int newVal) { this._lchistBrnCode = newVal; __lchistBrnCode_is_modified = true; }
    public boolean lchistBrnCodeIsModifiedS2j() { return __lchistBrnCode_is_modified; }
    public String getLchistLcType() { return _lchistLcType; }
    public void setLchistLcType(String newVal) { this._lchistLcType = newVal; __lchistLcType_is_modified = true; }
    public boolean lchistLcTypeIsModifiedS2j() { return __lchistLcType_is_modified; }
    public int getLchistLcYear() { return _lchistLcYear; }
    public void setLchistLcYear(int newVal) { this._lchistLcYear = newVal; __lchistLcYear_is_modified = true; }
    public boolean lchistLcYearIsModifiedS2j() { return __lchistLcYear_is_modified; }
    public int getLchistLcSl() { return _lchistLcSl; }
    public void setLchistLcSl(int newVal) { this._lchistLcSl = newVal; __lchistLcSl_is_modified = true; }
    public boolean lchistLcSlIsModifiedS2j() { return __lchistLcSl_is_modified; }
    public long getLchistLcHistsl() { return _lchistLcHistsl; }
    public void setLchistLcHistsl(long newVal) { this._lchistLcHistsl = newVal; __lchistLcHistsl_is_modified = true; }
    public boolean lchistLcHistslIsModifiedS2j() { return __lchistLcHistsl_is_modified; }
    public java.util.Date getLchistLcHistdate() { return _lchistLcHistdate; }
    public void setLchistLcHistdate(java.util.Date newVal) { this._lchistLcHistdate = newVal; __lchistLcHistdate_is_modified = true; }
    public boolean lchistLcHistdateIsModifiedS2j() { return __lchistLcHistdate_is_modified; }
    public int getLchistFormOfDocCredit() { return _lchistFormOfDocCredit; }
    public void setLchistFormOfDocCredit(int newVal) { this._lchistFormOfDocCredit = newVal; __lchistFormOfDocCredit_is_modified = true; }
    public boolean lchistFormOfDocCreditIsModifiedS2j() { return __lchistFormOfDocCredit_is_modified; }
    public String getLchistReferenceToPreadvice() { return _lchistReferenceToPreadvice == null ? "" : _lchistReferenceToPreadvice.trim(); }
    public void setLchistReferenceToPreadvice(String newVal) { this._lchistReferenceToPreadvice = newVal; __lchistReferenceToPreadvice_is_modified = true; }
    public boolean lchistReferenceToPreadviceIsModifiedS2j() { return __lchistReferenceToPreadvice_is_modified; }
    public int getLchistApplicableRules() { return _lchistApplicableRules; }
    public void setLchistApplicableRules(int newVal) { this._lchistApplicableRules = newVal; __lchistApplicableRules_is_modified = true; }
    public boolean lchistApplicableRulesIsModifiedS2j() { return __lchistApplicableRules_is_modified; }
    public char getLchistApplicantReq() { return _lchistApplicantReq; }
    public void setLchistApplicantReq(char newVal) { this._lchistApplicantReq = newVal; __lchistApplicantReq_is_modified = true; }
    public boolean lchistApplicantReqIsModifiedS2j() { return __lchistApplicantReq_is_modified; }
    public char getLchistApplicantType() { return _lchistApplicantType; }
    public void setLchistApplicantType(char newVal) { this._lchistApplicantType = newVal; __lchistApplicantType_is_modified = true; }
    public boolean lchistApplicantTypeIsModifiedS2j() { return __lchistApplicantType_is_modified; }
    public String getLchistApplicantBrnCode() { return _lchistApplicantBrnCode == null ? "" : _lchistApplicantBrnCode.trim(); }
    public void setLchistApplicantBrnCode(String newVal) { this._lchistApplicantBrnCode = newVal; __lchistApplicantBrnCode_is_modified = true; }
    public boolean lchistApplicantBrnCodeIsModifiedS2j() { return __lchistApplicantBrnCode_is_modified; }
    public String getLchistApplicantBicCode() { return _lchistApplicantBicCode == null ? "" : _lchistApplicantBicCode.trim(); }
    public void setLchistApplicantBicCode(String newVal) { this._lchistApplicantBicCode = newVal; __lchistApplicantBicCode_is_modified = true; }
    public boolean lchistApplicantBicCodeIsModifiedS2j() { return __lchistApplicantBicCode_is_modified; }
    public String getLchistApplicantRoutid() { return _lchistApplicantRoutid == null ? "" : _lchistApplicantRoutid.trim(); }
    public void setLchistApplicantRoutid(String newVal) { this._lchistApplicantRoutid = newVal; __lchistApplicantRoutid_is_modified = true; }
    public boolean lchistApplicantRoutidIsModifiedS2j() { return __lchistApplicantRoutid_is_modified; }
    public String getLchistApplicantBnkCode() { return _lchistApplicantBnkCode == null ? "" : _lchistApplicantBnkCode.trim(); }
    public void setLchistApplicantBnkCode(String newVal) { this._lchistApplicantBnkCode = newVal; __lchistApplicantBnkCode_is_modified = true; }
    public boolean lchistApplicantBnkCodeIsModifiedS2j() { return __lchistApplicantBnkCode_is_modified; }
    public String getLchistApplicantAddr1() { return _lchistApplicantAddr1 == null ? "" : _lchistApplicantAddr1.trim(); }
    public void setLchistApplicantAddr1(String newVal) { this._lchistApplicantAddr1 = newVal; __lchistApplicantAddr1_is_modified = true; }
    public boolean lchistApplicantAddr1IsModifiedS2j() { return __lchistApplicantAddr1_is_modified; }
    public String getLchistApplicantAddr2() { return _lchistApplicantAddr2 == null ? "" : _lchistApplicantAddr2.trim(); }
    public void setLchistApplicantAddr2(String newVal) { this._lchistApplicantAddr2 = newVal; __lchistApplicantAddr2_is_modified = true; }
    public boolean lchistApplicantAddr2IsModifiedS2j() { return __lchistApplicantAddr2_is_modified; }
    public String getLchistApplicantAddr3() { return _lchistApplicantAddr3 == null ? "" : _lchistApplicantAddr3.trim(); }
    public void setLchistApplicantAddr3(String newVal) { this._lchistApplicantAddr3 = newVal; __lchistApplicantAddr3_is_modified = true; }
    public boolean lchistApplicantAddr3IsModifiedS2j() { return __lchistApplicantAddr3_is_modified; }
    public String getLchistApplicantAddr4() { return _lchistApplicantAddr4 == null ? "" : _lchistApplicantAddr4.trim(); }
    public void setLchistApplicantAddr4(String newVal) { this._lchistApplicantAddr4 = newVal; __lchistApplicantAddr4_is_modified = true; }
    public boolean lchistApplicantAddr4IsModifiedS2j() { return __lchistApplicantAddr4_is_modified; }
    public String getLchistApplicantAddr5() { return _lchistApplicantAddr5 == null ? "" : _lchistApplicantAddr5.trim(); }
    public void setLchistApplicantAddr5(String newVal) { this._lchistApplicantAddr5 = newVal; __lchistApplicantAddr5_is_modified = true; }
    public boolean lchistApplicantAddr5IsModifiedS2j() { return __lchistApplicantAddr5_is_modified; }
    public char getLchistAvailableWithType() { return _lchistAvailableWithType; }
    public void setLchistAvailableWithType(char newVal) { this._lchistAvailableWithType = newVal; __lchistAvailableWithType_is_modified = true; }
    public boolean lchistAvailableWithTypeIsModifiedS2j() { return __lchistAvailableWithType_is_modified; }
    public String getLchistAvailableWithBrnCode() { return _lchistAvailableWithBrnCode == null ? "" : _lchistAvailableWithBrnCode.trim(); }
    public void setLchistAvailableWithBrnCode(String newVal) { this._lchistAvailableWithBrnCode = newVal; __lchistAvailableWithBrnCode_is_modified = true; }
    public boolean lchistAvailableWithBrnCodeIsModifiedS2j() { return __lchistAvailableWithBrnCode_is_modified; }
    public String getLchistAvailableWithCode() { return _lchistAvailableWithCode == null ? "" : _lchistAvailableWithCode.trim(); }
    public void setLchistAvailableWithCode(String newVal) { this._lchistAvailableWithCode = newVal; __lchistAvailableWithCode_is_modified = true; }
    public boolean lchistAvailableWithCodeIsModifiedS2j() { return __lchistAvailableWithCode_is_modified; }
    public String getLchistAvailableWithRoutid() { return _lchistAvailableWithRoutid == null ? "" : _lchistAvailableWithRoutid.trim(); }
    public void setLchistAvailableWithRoutid(String newVal) { this._lchistAvailableWithRoutid = newVal; __lchistAvailableWithRoutid_is_modified = true; }
    public boolean lchistAvailableWithRoutidIsModifiedS2j() { return __lchistAvailableWithRoutid_is_modified; }
    public String getLchistAvailableWithBnkCode() { return _lchistAvailableWithBnkCode == null ? "" : _lchistAvailableWithBnkCode.trim(); }
    public void setLchistAvailableWithBnkCode(String newVal) { this._lchistAvailableWithBnkCode = newVal; __lchistAvailableWithBnkCode_is_modified = true; }
    public boolean lchistAvailableWithBnkCodeIsModifiedS2j() { return __lchistAvailableWithBnkCode_is_modified; }
    public String getLchistAvailableWithAddr1() { return _lchistAvailableWithAddr1 == null ? "" : _lchistAvailableWithAddr1.trim(); }
    public void setLchistAvailableWithAddr1(String newVal) { this._lchistAvailableWithAddr1 = newVal; __lchistAvailableWithAddr1_is_modified = true; }
    public boolean lchistAvailableWithAddr1IsModifiedS2j() { return __lchistAvailableWithAddr1_is_modified; }
    public String getLchistAvailableWithAddr2() { return _lchistAvailableWithAddr2 == null ? "" : _lchistAvailableWithAddr2.trim(); }
    public void setLchistAvailableWithAddr2(String newVal) { this._lchistAvailableWithAddr2 = newVal; __lchistAvailableWithAddr2_is_modified = true; }
    public boolean lchistAvailableWithAddr2IsModifiedS2j() { return __lchistAvailableWithAddr2_is_modified; }
    public String getLchistAvailableWithAddr3() { return _lchistAvailableWithAddr3 == null ? "" : _lchistAvailableWithAddr3.trim(); }
    public void setLchistAvailableWithAddr3(String newVal) { this._lchistAvailableWithAddr3 = newVal; __lchistAvailableWithAddr3_is_modified = true; }
    public boolean lchistAvailableWithAddr3IsModifiedS2j() { return __lchistAvailableWithAddr3_is_modified; }
    public String getLchistAvailableWithAddr4() { return _lchistAvailableWithAddr4 == null ? "" : _lchistAvailableWithAddr4.trim(); }
    public void setLchistAvailableWithAddr4(String newVal) { this._lchistAvailableWithAddr4 = newVal; __lchistAvailableWithAddr4_is_modified = true; }
    public boolean lchistAvailableWithAddr4IsModifiedS2j() { return __lchistAvailableWithAddr4_is_modified; }
    public String getLchistAvailableWithAddr5() { return _lchistAvailableWithAddr5 == null ? "" : _lchistAvailableWithAddr5.trim(); }
    public void setLchistAvailableWithAddr5(String newVal) { this._lchistAvailableWithAddr5 = newVal; __lchistAvailableWithAddr5_is_modified = true; }
    public boolean lchistAvailableWithAddr5IsModifiedS2j() { return __lchistAvailableWithAddr5_is_modified; }
    public String getLchistDraftsAt1() { return _lchistDraftsAt1 == null ? "" : _lchistDraftsAt1.trim(); }
    public void setLchistDraftsAt1(String newVal) { this._lchistDraftsAt1 = newVal; __lchistDraftsAt1_is_modified = true; }
    public boolean lchistDraftsAt1IsModifiedS2j() { return __lchistDraftsAt1_is_modified; }
    public String getLchistDraftsAt2() { return _lchistDraftsAt2 == null ? "" : _lchistDraftsAt2.trim(); }
    public void setLchistDraftsAt2(String newVal) { this._lchistDraftsAt2 = newVal; __lchistDraftsAt2_is_modified = true; }
    public boolean lchistDraftsAt2IsModifiedS2j() { return __lchistDraftsAt2_is_modified; }
    public String getLchistDraftsAt3() { return _lchistDraftsAt3 == null ? "" : _lchistDraftsAt3.trim(); }
    public void setLchistDraftsAt3(String newVal) { this._lchistDraftsAt3 = newVal; __lchistDraftsAt3_is_modified = true; }
    public boolean lchistDraftsAt3IsModifiedS2j() { return __lchistDraftsAt3_is_modified; }
    public char getLchistDraweeReq() { return _lchistDraweeReq; }
    public void setLchistDraweeReq(char newVal) { this._lchistDraweeReq = newVal; __lchistDraweeReq_is_modified = true; }
    public boolean lchistDraweeReqIsModifiedS2j() { return __lchistDraweeReq_is_modified; }
    public char getLchistDraweeType() { return _lchistDraweeType; }
    public void setLchistDraweeType(char newVal) { this._lchistDraweeType = newVal; __lchistDraweeType_is_modified = true; }
    public boolean lchistDraweeTypeIsModifiedS2j() { return __lchistDraweeType_is_modified; }
    public String getLchistDraweeBrnCode() { return _lchistDraweeBrnCode == null ? "" : _lchistDraweeBrnCode.trim(); }
    public void setLchistDraweeBrnCode(String newVal) { this._lchistDraweeBrnCode = newVal; __lchistDraweeBrnCode_is_modified = true; }
    public boolean lchistDraweeBrnCodeIsModifiedS2j() { return __lchistDraweeBrnCode_is_modified; }
    public String getLchistDraweeBicCode() { return _lchistDraweeBicCode == null ? "" : _lchistDraweeBicCode.trim(); }
    public void setLchistDraweeBicCode(String newVal) { this._lchistDraweeBicCode = newVal; __lchistDraweeBicCode_is_modified = true; }
    public boolean lchistDraweeBicCodeIsModifiedS2j() { return __lchistDraweeBicCode_is_modified; }
    public String getLchistDraweeRoutid() { return _lchistDraweeRoutid == null ? "" : _lchistDraweeRoutid.trim(); }
    public void setLchistDraweeRoutid(String newVal) { this._lchistDraweeRoutid = newVal; __lchistDraweeRoutid_is_modified = true; }
    public boolean lchistDraweeRoutidIsModifiedS2j() { return __lchistDraweeRoutid_is_modified; }
    public String getLchistDraweeBnkCode() { return _lchistDraweeBnkCode == null ? "" : _lchistDraweeBnkCode.trim(); }
    public void setLchistDraweeBnkCode(String newVal) { this._lchistDraweeBnkCode = newVal; __lchistDraweeBnkCode_is_modified = true; }
    public boolean lchistDraweeBnkCodeIsModifiedS2j() { return __lchistDraweeBnkCode_is_modified; }
    public String getLchistDraweeAddr1() { return _lchistDraweeAddr1 == null ? "" : _lchistDraweeAddr1.trim(); }
    public void setLchistDraweeAddr1(String newVal) { this._lchistDraweeAddr1 = newVal; __lchistDraweeAddr1_is_modified = true; }
    public boolean lchistDraweeAddr1IsModifiedS2j() { return __lchistDraweeAddr1_is_modified; }
    public String getLchistDraweeAddr2() { return _lchistDraweeAddr2 == null ? "" : _lchistDraweeAddr2.trim(); }
    public void setLchistDraweeAddr2(String newVal) { this._lchistDraweeAddr2 = newVal; __lchistDraweeAddr2_is_modified = true; }
    public boolean lchistDraweeAddr2IsModifiedS2j() { return __lchistDraweeAddr2_is_modified; }
    public String getLchistDraweeAddr3() { return _lchistDraweeAddr3 == null ? "" : _lchistDraweeAddr3.trim(); }
    public void setLchistDraweeAddr3(String newVal) { this._lchistDraweeAddr3 = newVal; __lchistDraweeAddr3_is_modified = true; }
    public boolean lchistDraweeAddr3IsModifiedS2j() { return __lchistDraweeAddr3_is_modified; }
    public String getLchistDraweeAddr4() { return _lchistDraweeAddr4 == null ? "" : _lchistDraweeAddr4.trim(); }
    public void setLchistDraweeAddr4(String newVal) { this._lchistDraweeAddr4 = newVal; __lchistDraweeAddr4_is_modified = true; }
    public boolean lchistDraweeAddr4IsModifiedS2j() { return __lchistDraweeAddr4_is_modified; }
    public String getLchistDraweeAddr5() { return _lchistDraweeAddr5 == null ? "" : _lchistDraweeAddr5.trim(); }
    public void setLchistDraweeAddr5(String newVal) { this._lchistDraweeAddr5 = newVal; __lchistDraweeAddr5_is_modified = true; }
    public boolean lchistDraweeAddr5IsModifiedS2j() { return __lchistDraweeAddr5_is_modified; }
    public String getLchistMixedPayDetails1() { return _lchistMixedPayDetails1 == null ? "" : _lchistMixedPayDetails1.trim(); }
    public void setLchistMixedPayDetails1(String newVal) { this._lchistMixedPayDetails1 = newVal; __lchistMixedPayDetails1_is_modified = true; }
    public boolean lchistMixedPayDetails1IsModifiedS2j() { return __lchistMixedPayDetails1_is_modified; }
    public String getLchistMixedPayDetails2() { return _lchistMixedPayDetails2 == null ? "" : _lchistMixedPayDetails2.trim(); }
    public void setLchistMixedPayDetails2(String newVal) { this._lchistMixedPayDetails2 = newVal; __lchistMixedPayDetails2_is_modified = true; }
    public boolean lchistMixedPayDetails2IsModifiedS2j() { return __lchistMixedPayDetails2_is_modified; }
    public String getLchistMixedPayDetails3() { return _lchistMixedPayDetails3 == null ? "" : _lchistMixedPayDetails3.trim(); }
    public void setLchistMixedPayDetails3(String newVal) { this._lchistMixedPayDetails3 = newVal; __lchistMixedPayDetails3_is_modified = true; }
    public boolean lchistMixedPayDetails3IsModifiedS2j() { return __lchistMixedPayDetails3_is_modified; }
    public String getLchistMixedPayDetails4() { return _lchistMixedPayDetails4 == null ? "" : _lchistMixedPayDetails4.trim(); }
    public void setLchistMixedPayDetails4(String newVal) { this._lchistMixedPayDetails4 = newVal; __lchistMixedPayDetails4_is_modified = true; }
    public boolean lchistMixedPayDetails4IsModifiedS2j() { return __lchistMixedPayDetails4_is_modified; }
    public String getLchistDeferredPayDetails1() { return _lchistDeferredPayDetails1 == null ? "" : _lchistDeferredPayDetails1.trim(); }
    public void setLchistDeferredPayDetails1(String newVal) { this._lchistDeferredPayDetails1 = newVal; __lchistDeferredPayDetails1_is_modified = true; }
    public boolean lchistDeferredPayDetails1IsModifiedS2j() { return __lchistDeferredPayDetails1_is_modified; }
    public String getLchistDeferredPayDetails2() { return _lchistDeferredPayDetails2 == null ? "" : _lchistDeferredPayDetails2.trim(); }
    public void setLchistDeferredPayDetails2(String newVal) { this._lchistDeferredPayDetails2 = newVal; __lchistDeferredPayDetails2_is_modified = true; }
    public boolean lchistDeferredPayDetails2IsModifiedS2j() { return __lchistDeferredPayDetails2_is_modified; }
    public String getLchistDeferredPayDetails3() { return _lchistDeferredPayDetails3 == null ? "" : _lchistDeferredPayDetails3.trim(); }
    public void setLchistDeferredPayDetails3(String newVal) { this._lchistDeferredPayDetails3 = newVal; __lchistDeferredPayDetails3_is_modified = true; }
    public boolean lchistDeferredPayDetails3IsModifiedS2j() { return __lchistDeferredPayDetails3_is_modified; }
    public String getLchistDeferredPayDetails4() { return _lchistDeferredPayDetails4 == null ? "" : _lchistDeferredPayDetails4.trim(); }
    public void setLchistDeferredPayDetails4(String newVal) { this._lchistDeferredPayDetails4 = newVal; __lchistDeferredPayDetails4_is_modified = true; }
    public boolean lchistDeferredPayDetails4IsModifiedS2j() { return __lchistDeferredPayDetails4_is_modified; }
    public int getLchistPartialShipments() { return _lchistPartialShipments; }
    public void setLchistPartialShipments(int newVal) { this._lchistPartialShipments = newVal; __lchistPartialShipments_is_modified = true; }
    public boolean lchistPartialShipmentsIsModifiedS2j() { return __lchistPartialShipments_is_modified; }
    public int getLchistTranshipment() { return _lchistTranshipment; }
    public void setLchistTranshipment(int newVal) { this._lchistTranshipment = newVal; __lchistTranshipment_is_modified = true; }
    public boolean lchistTranshipmentIsModifiedS2j() { return __lchistTranshipment_is_modified; }
    public String getLchistPlaceInCharge() { return _lchistPlaceInCharge == null ? "" : _lchistPlaceInCharge.trim(); }
    public void setLchistPlaceInCharge(String newVal) { this._lchistPlaceInCharge = newVal; __lchistPlaceInCharge_is_modified = true; }
    public boolean lchistPlaceInChargeIsModifiedS2j() { return __lchistPlaceInCharge_is_modified; }
    public String getLchistPortOfLoading() { return _lchistPortOfLoading == null ? "" : _lchistPortOfLoading.trim(); }
    public void setLchistPortOfLoading(String newVal) { this._lchistPortOfLoading = newVal; __lchistPortOfLoading_is_modified = true; }
    public boolean lchistPortOfLoadingIsModifiedS2j() { return __lchistPortOfLoading_is_modified; }
    public String getLchistPortOfDischarge() { return _lchistPortOfDischarge == null ? "" : _lchistPortOfDischarge.trim(); }
    public void setLchistPortOfDischarge(String newVal) { this._lchistPortOfDischarge = newVal; __lchistPortOfDischarge_is_modified = true; }
    public boolean lchistPortOfDischargeIsModifiedS2j() { return __lchistPortOfDischarge_is_modified; }
    public String getLchistPlaceOfFinalDest() { return _lchistPlaceOfFinalDest == null ? "" : _lchistPlaceOfFinalDest.trim(); }
    public void setLchistPlaceOfFinalDest(String newVal) { this._lchistPlaceOfFinalDest = newVal; __lchistPlaceOfFinalDest_is_modified = true; }
    public boolean lchistPlaceOfFinalDestIsModifiedS2j() { return __lchistPlaceOfFinalDest_is_modified; }
    public Object getLchistDescGoodsSer1() { return _lchistDescGoodsSer1; }
    public void setLchistDescGoodsSer1(Object newVal) { this._lchistDescGoodsSer1 = newVal; __lchistDescGoodsSer1_is_modified = true; }
    public boolean lchistDescGoodsSer1IsModifiedS2j() { return __lchistDescGoodsSer1_is_modified; }
    public Object getLchistDescGoodsSer2() { return _lchistDescGoodsSer2; }
    public void setLchistDescGoodsSer2(Object newVal) { this._lchistDescGoodsSer2 = newVal; __lchistDescGoodsSer2_is_modified = true; }
    public boolean lchistDescGoodsSer2IsModifiedS2j() { return __lchistDescGoodsSer2_is_modified; }
    public Object getLchistDescGoodsSer3() { return _lchistDescGoodsSer3; }
    public void setLchistDescGoodsSer3(Object newVal) { this._lchistDescGoodsSer3 = newVal; __lchistDescGoodsSer3_is_modified = true; }
    public boolean lchistDescGoodsSer3IsModifiedS2j() { return __lchistDescGoodsSer3_is_modified; }
    public Object getLchistDocReq1() { return _lchistDocReq1; }
    public void setLchistDocReq1(Object newVal) { this._lchistDocReq1 = newVal; __lchistDocReq1_is_modified = true; }
    public boolean lchistDocReq1IsModifiedS2j() { return __lchistDocReq1_is_modified; }
    public Object getLchistDocReq2() { return _lchistDocReq2; }
    public void setLchistDocReq2(Object newVal) { this._lchistDocReq2 = newVal; __lchistDocReq2_is_modified = true; }
    public boolean lchistDocReq2IsModifiedS2j() { return __lchistDocReq2_is_modified; }
    public Object getLchistDocReq3() { return _lchistDocReq3; }
    public void setLchistDocReq3(Object newVal) { this._lchistDocReq3 = newVal; __lchistDocReq3_is_modified = true; }
    public boolean lchistDocReq3IsModifiedS2j() { return __lchistDocReq3_is_modified; }
    public Object getLchistAddCondition1() { return _lchistAddCondition1; }
    public void setLchistAddCondition1(Object newVal) { this._lchistAddCondition1 = newVal; __lchistAddCondition1_is_modified = true; }
    public boolean lchistAddCondition1IsModifiedS2j() { return __lchistAddCondition1_is_modified; }
    public Object getLchistAddCondition2() { return _lchistAddCondition2; }
    public void setLchistAddCondition2(Object newVal) { this._lchistAddCondition2 = newVal; __lchistAddCondition2_is_modified = true; }
    public boolean lchistAddCondition2IsModifiedS2j() { return __lchistAddCondition2_is_modified; }
    public Object getLchistAddCondition3() { return _lchistAddCondition3; }
    public void setLchistAddCondition3(Object newVal) { this._lchistAddCondition3 = newVal; __lchistAddCondition3_is_modified = true; }
    public boolean lchistAddCondition3IsModifiedS2j() { return __lchistAddCondition3_is_modified; }
    public String getLchistCharges1() { return _lchistCharges1 == null ? "" : _lchistCharges1.trim(); }
    public void setLchistCharges1(String newVal) { this._lchistCharges1 = newVal; __lchistCharges1_is_modified = true; }
    public boolean lchistCharges1IsModifiedS2j() { return __lchistCharges1_is_modified; }
    public String getLchistCharges2() { return _lchistCharges2 == null ? "" : _lchistCharges2.trim(); }
    public void setLchistCharges2(String newVal) { this._lchistCharges2 = newVal; __lchistCharges2_is_modified = true; }
    public boolean lchistCharges2IsModifiedS2j() { return __lchistCharges2_is_modified; }
    public String getLchistCharges3() { return _lchistCharges3 == null ? "" : _lchistCharges3.trim(); }
    public void setLchistCharges3(String newVal) { this._lchistCharges3 = newVal; __lchistCharges3_is_modified = true; }
    public boolean lchistCharges3IsModifiedS2j() { return __lchistCharges3_is_modified; }
    public String getLchistCharges4() { return _lchistCharges4 == null ? "" : _lchistCharges4.trim(); }
    public void setLchistCharges4(String newVal) { this._lchistCharges4 = newVal; __lchistCharges4_is_modified = true; }
    public boolean lchistCharges4IsModifiedS2j() { return __lchistCharges4_is_modified; }
    public String getLchistCharges5() { return _lchistCharges5 == null ? "" : _lchistCharges5.trim(); }
    public void setLchistCharges5(String newVal) { this._lchistCharges5 = newVal; __lchistCharges5_is_modified = true; }
    public boolean lchistCharges5IsModifiedS2j() { return __lchistCharges5_is_modified; }
    public String getLchistCharges6() { return _lchistCharges6 == null ? "" : _lchistCharges6.trim(); }
    public void setLchistCharges6(String newVal) { this._lchistCharges6 = newVal; __lchistCharges6_is_modified = true; }
    public boolean lchistCharges6IsModifiedS2j() { return __lchistCharges6_is_modified; }
    public int getLchistPerPresentationDay() { return _lchistPerPresentationDay; }
    public void setLchistPerPresentationDay(int newVal) { this._lchistPerPresentationDay = newVal; __lchistPerPresentationDay_is_modified = true; }
    public boolean lchistPerPresentationDayIsModifiedS2j() { return __lchistPerPresentationDay_is_modified; }
    public int getLchistConfirmationInst() { return _lchistConfirmationInst; }
    public void setLchistConfirmationInst(int newVal) { this._lchistConfirmationInst = newVal; __lchistConfirmationInst_is_modified = true; }
    public boolean lchistConfirmationInstIsModifiedS2j() { return __lchistConfirmationInst_is_modified; }
    public char getLchistReimbReq() { return _lchistReimbReq; }
    public void setLchistReimbReq(char newVal) { this._lchistReimbReq = newVal; __lchistReimbReq_is_modified = true; }
    public boolean lchistReimbReqIsModifiedS2j() { return __lchistReimbReq_is_modified; }
    public char getLchistReimbType() { return _lchistReimbType; }
    public void setLchistReimbType(char newVal) { this._lchistReimbType = newVal; __lchistReimbType_is_modified = true; }
    public boolean lchistReimbTypeIsModifiedS2j() { return __lchistReimbType_is_modified; }
    public String getLchistReimbBrnCode() { return _lchistReimbBrnCode == null ? "" : _lchistReimbBrnCode.trim(); }
    public void setLchistReimbBrnCode(String newVal) { this._lchistReimbBrnCode = newVal; __lchistReimbBrnCode_is_modified = true; }
    public boolean lchistReimbBrnCodeIsModifiedS2j() { return __lchistReimbBrnCode_is_modified; }
    public String getLchistReimbBicCode() { return _lchistReimbBicCode == null ? "" : _lchistReimbBicCode.trim(); }
    public void setLchistReimbBicCode(String newVal) { this._lchistReimbBicCode = newVal; __lchistReimbBicCode_is_modified = true; }
    public boolean lchistReimbBicCodeIsModifiedS2j() { return __lchistReimbBicCode_is_modified; }
    public String getLchistReimbRoutid() { return _lchistReimbRoutid == null ? "" : _lchistReimbRoutid.trim(); }
    public void setLchistReimbRoutid(String newVal) { this._lchistReimbRoutid = newVal; __lchistReimbRoutid_is_modified = true; }
    public boolean lchistReimbRoutidIsModifiedS2j() { return __lchistReimbRoutid_is_modified; }
    public String getLchistReimbBnkCode() { return _lchistReimbBnkCode == null ? "" : _lchistReimbBnkCode.trim(); }
    public void setLchistReimbBnkCode(String newVal) { this._lchistReimbBnkCode = newVal; __lchistReimbBnkCode_is_modified = true; }
    public boolean lchistReimbBnkCodeIsModifiedS2j() { return __lchistReimbBnkCode_is_modified; }
    public String getLchistReimbAddr1() { return _lchistReimbAddr1 == null ? "" : _lchistReimbAddr1.trim(); }
    public void setLchistReimbAddr1(String newVal) { this._lchistReimbAddr1 = newVal; __lchistReimbAddr1_is_modified = true; }
    public boolean lchistReimbAddr1IsModifiedS2j() { return __lchistReimbAddr1_is_modified; }
    public String getLchistReimbAddr2() { return _lchistReimbAddr2 == null ? "" : _lchistReimbAddr2.trim(); }
    public void setLchistReimbAddr2(String newVal) { this._lchistReimbAddr2 = newVal; __lchistReimbAddr2_is_modified = true; }
    public boolean lchistReimbAddr2IsModifiedS2j() { return __lchistReimbAddr2_is_modified; }
    public String getLchistReimbAddr3() { return _lchistReimbAddr3 == null ? "" : _lchistReimbAddr3.trim(); }
    public void setLchistReimbAddr3(String newVal) { this._lchistReimbAddr3 = newVal; __lchistReimbAddr3_is_modified = true; }
    public boolean lchistReimbAddr3IsModifiedS2j() { return __lchistReimbAddr3_is_modified; }
    public String getLchistReimbAddr4() { return _lchistReimbAddr4 == null ? "" : _lchistReimbAddr4.trim(); }
    public void setLchistReimbAddr4(String newVal) { this._lchistReimbAddr4 = newVal; __lchistReimbAddr4_is_modified = true; }
    public boolean lchistReimbAddr4IsModifiedS2j() { return __lchistReimbAddr4_is_modified; }
    public String getLchistReimbAddr5() { return _lchistReimbAddr5 == null ? "" : _lchistReimbAddr5.trim(); }
    public void setLchistReimbAddr5(String newVal) { this._lchistReimbAddr5 = newVal; __lchistReimbAddr5_is_modified = true; }
    public boolean lchistReimbAddr5IsModifiedS2j() { return __lchistReimbAddr5_is_modified; }
    public String getLchistInstPaying1() { return _lchistInstPaying1 == null ? "" : _lchistInstPaying1.trim(); }
    public void setLchistInstPaying1(String newVal) { this._lchistInstPaying1 = newVal; __lchistInstPaying1_is_modified = true; }
    public boolean lchistInstPaying1IsModifiedS2j() { return __lchistInstPaying1_is_modified; }
    public String getLchistInstPaying2() { return _lchistInstPaying2 == null ? "" : _lchistInstPaying2.trim(); }
    public void setLchistInstPaying2(String newVal) { this._lchistInstPaying2 = newVal; __lchistInstPaying2_is_modified = true; }
    public boolean lchistInstPaying2IsModifiedS2j() { return __lchistInstPaying2_is_modified; }
    public String getLchistInstPaying3() { return _lchistInstPaying3 == null ? "" : _lchistInstPaying3.trim(); }
    public void setLchistInstPaying3(String newVal) { this._lchistInstPaying3 = newVal; __lchistInstPaying3_is_modified = true; }
    public boolean lchistInstPaying3IsModifiedS2j() { return __lchistInstPaying3_is_modified; }
    public String getLchistInstPaying4() { return _lchistInstPaying4 == null ? "" : _lchistInstPaying4.trim(); }
    public void setLchistInstPaying4(String newVal) { this._lchistInstPaying4 = newVal; __lchistInstPaying4_is_modified = true; }
    public boolean lchistInstPaying4IsModifiedS2j() { return __lchistInstPaying4_is_modified; }
    public String getLchistInstPaying5() { return _lchistInstPaying5 == null ? "" : _lchistInstPaying5.trim(); }
    public void setLchistInstPaying5(String newVal) { this._lchistInstPaying5 = newVal; __lchistInstPaying5_is_modified = true; }
    public boolean lchistInstPaying5IsModifiedS2j() { return __lchistInstPaying5_is_modified; }
    public String getLchistInstPaying6() { return _lchistInstPaying6 == null ? "" : _lchistInstPaying6.trim(); }
    public void setLchistInstPaying6(String newVal) { this._lchistInstPaying6 = newVal; __lchistInstPaying6_is_modified = true; }
    public boolean lchistInstPaying6IsModifiedS2j() { return __lchistInstPaying6_is_modified; }
    public String getLchistInstPaying7() { return _lchistInstPaying7 == null ? "" : _lchistInstPaying7.trim(); }
    public void setLchistInstPaying7(String newVal) { this._lchistInstPaying7 = newVal; __lchistInstPaying7_is_modified = true; }
    public boolean lchistInstPaying7IsModifiedS2j() { return __lchistInstPaying7_is_modified; }
    public String getLchistInstPaying8() { return _lchistInstPaying8 == null ? "" : _lchistInstPaying8.trim(); }
    public void setLchistInstPaying8(String newVal) { this._lchistInstPaying8 = newVal; __lchistInstPaying8_is_modified = true; }
    public boolean lchistInstPaying8IsModifiedS2j() { return __lchistInstPaying8_is_modified; }
    public String getLchistInstPaying9() { return _lchistInstPaying9 == null ? "" : _lchistInstPaying9.trim(); }
    public void setLchistInstPaying9(String newVal) { this._lchistInstPaying9 = newVal; __lchistInstPaying9_is_modified = true; }
    public boolean lchistInstPaying9IsModifiedS2j() { return __lchistInstPaying9_is_modified; }
    public String getLchistInstPaying10() { return _lchistInstPaying10 == null ? "" : _lchistInstPaying10.trim(); }
    public void setLchistInstPaying10(String newVal) { this._lchistInstPaying10 = newVal; __lchistInstPaying10_is_modified = true; }
    public boolean lchistInstPaying10IsModifiedS2j() { return __lchistInstPaying10_is_modified; }
    public String getLchistInstPaying11() { return _lchistInstPaying11 == null ? "" : _lchistInstPaying11.trim(); }
    public void setLchistInstPaying11(String newVal) { this._lchistInstPaying11 = newVal; __lchistInstPaying11_is_modified = true; }
    public boolean lchistInstPaying11IsModifiedS2j() { return __lchistInstPaying11_is_modified; }
    public String getLchistInstPaying12() { return _lchistInstPaying12 == null ? "" : _lchistInstPaying12.trim(); }
    public void setLchistInstPaying12(String newVal) { this._lchistInstPaying12 = newVal; __lchistInstPaying12_is_modified = true; }
    public boolean lchistInstPaying12IsModifiedS2j() { return __lchistInstPaying12_is_modified; }
    public char getLchistSecondAdvReq() { return _lchistSecondAdvReq; }
    public void setLchistSecondAdvReq(char newVal) { this._lchistSecondAdvReq = newVal; __lchistSecondAdvReq_is_modified = true; }
    public boolean lchistSecondAdvReqIsModifiedS2j() { return __lchistSecondAdvReq_is_modified; }
    public char getLchistSecondAdvType() { return _lchistSecondAdvType; }
    public void setLchistSecondAdvType(char newVal) { this._lchistSecondAdvType = newVal; __lchistSecondAdvType_is_modified = true; }
    public boolean lchistSecondAdvTypeIsModifiedS2j() { return __lchistSecondAdvType_is_modified; }
    public String getLchistSecondAdvBrnCode() { return _lchistSecondAdvBrnCode == null ? "" : _lchistSecondAdvBrnCode.trim(); }
    public void setLchistSecondAdvBrnCode(String newVal) { this._lchistSecondAdvBrnCode = newVal; __lchistSecondAdvBrnCode_is_modified = true; }
    public boolean lchistSecondAdvBrnCodeIsModifiedS2j() { return __lchistSecondAdvBrnCode_is_modified; }
    public String getLchistSecondAdvBicCode() { return _lchistSecondAdvBicCode == null ? "" : _lchistSecondAdvBicCode.trim(); }
    public void setLchistSecondAdvBicCode(String newVal) { this._lchistSecondAdvBicCode = newVal; __lchistSecondAdvBicCode_is_modified = true; }
    public boolean lchistSecondAdvBicCodeIsModifiedS2j() { return __lchistSecondAdvBicCode_is_modified; }
    public String getLchistSecondAdvRoutid() { return _lchistSecondAdvRoutid == null ? "" : _lchistSecondAdvRoutid.trim(); }
    public void setLchistSecondAdvRoutid(String newVal) { this._lchistSecondAdvRoutid = newVal; __lchistSecondAdvRoutid_is_modified = true; }
    public boolean lchistSecondAdvRoutidIsModifiedS2j() { return __lchistSecondAdvRoutid_is_modified; }
    public String getLchistSecondAdvBnkCode() { return _lchistSecondAdvBnkCode == null ? "" : _lchistSecondAdvBnkCode.trim(); }
    public void setLchistSecondAdvBnkCode(String newVal) { this._lchistSecondAdvBnkCode = newVal; __lchistSecondAdvBnkCode_is_modified = true; }
    public boolean lchistSecondAdvBnkCodeIsModifiedS2j() { return __lchistSecondAdvBnkCode_is_modified; }
    public String getLchistSecondAdvAddr1() { return _lchistSecondAdvAddr1 == null ? "" : _lchistSecondAdvAddr1.trim(); }
    public void setLchistSecondAdvAddr1(String newVal) { this._lchistSecondAdvAddr1 = newVal; __lchistSecondAdvAddr1_is_modified = true; }
    public boolean lchistSecondAdvAddr1IsModifiedS2j() { return __lchistSecondAdvAddr1_is_modified; }
    public String getLchistSecondAdvAddr2() { return _lchistSecondAdvAddr2 == null ? "" : _lchistSecondAdvAddr2.trim(); }
    public void setLchistSecondAdvAddr2(String newVal) { this._lchistSecondAdvAddr2 = newVal; __lchistSecondAdvAddr2_is_modified = true; }
    public boolean lchistSecondAdvAddr2IsModifiedS2j() { return __lchistSecondAdvAddr2_is_modified; }
    public String getLchistSecondAdvAddr3() { return _lchistSecondAdvAddr3 == null ? "" : _lchistSecondAdvAddr3.trim(); }
    public void setLchistSecondAdvAddr3(String newVal) { this._lchistSecondAdvAddr3 = newVal; __lchistSecondAdvAddr3_is_modified = true; }
    public boolean lchistSecondAdvAddr3IsModifiedS2j() { return __lchistSecondAdvAddr3_is_modified; }
    public String getLchistSecondAdvAddr4() { return _lchistSecondAdvAddr4 == null ? "" : _lchistSecondAdvAddr4.trim(); }
    public void setLchistSecondAdvAddr4(String newVal) { this._lchistSecondAdvAddr4 = newVal; __lchistSecondAdvAddr4_is_modified = true; }
    public boolean lchistSecondAdvAddr4IsModifiedS2j() { return __lchistSecondAdvAddr4_is_modified; }
    public String getLchistSecondAdvAddr5() { return _lchistSecondAdvAddr5 == null ? "" : _lchistSecondAdvAddr5.trim(); }
    public void setLchistSecondAdvAddr5(String newVal) { this._lchistSecondAdvAddr5 = newVal; __lchistSecondAdvAddr5_is_modified = true; }
    public boolean lchistSecondAdvAddr5IsModifiedS2j() { return __lchistSecondAdvAddr5_is_modified; }
    public String getLchistSndrRecInfo1() { return _lchistSndrRecInfo1 == null ? "" : _lchistSndrRecInfo1.trim(); }
    public void setLchistSndrRecInfo1(String newVal) { this._lchistSndrRecInfo1 = newVal; __lchistSndrRecInfo1_is_modified = true; }
    public boolean lchistSndrRecInfo1IsModifiedS2j() { return __lchistSndrRecInfo1_is_modified; }
    public String getLchistSndrRecInfo2() { return _lchistSndrRecInfo2 == null ? "" : _lchistSndrRecInfo2.trim(); }
    public void setLchistSndrRecInfo2(String newVal) { this._lchistSndrRecInfo2 = newVal; __lchistSndrRecInfo2_is_modified = true; }
    public boolean lchistSndrRecInfo2IsModifiedS2j() { return __lchistSndrRecInfo2_is_modified; }
    public String getLchistSndrRecInfo3() { return _lchistSndrRecInfo3 == null ? "" : _lchistSndrRecInfo3.trim(); }
    public void setLchistSndrRecInfo3(String newVal) { this._lchistSndrRecInfo3 = newVal; __lchistSndrRecInfo3_is_modified = true; }
    public boolean lchistSndrRecInfo3IsModifiedS2j() { return __lchistSndrRecInfo3_is_modified; }
    public String getLchistSndrRecInfo4() { return _lchistSndrRecInfo4 == null ? "" : _lchistSndrRecInfo4.trim(); }
    public void setLchistSndrRecInfo4(String newVal) { this._lchistSndrRecInfo4 = newVal; __lchistSndrRecInfo4_is_modified = true; }
    public boolean lchistSndrRecInfo4IsModifiedS2j() { return __lchistSndrRecInfo4_is_modified; }
    public String getLchistSndrRecInfo5() { return _lchistSndrRecInfo5 == null ? "" : _lchistSndrRecInfo5.trim(); }
    public void setLchistSndrRecInfo5(String newVal) { this._lchistSndrRecInfo5 = newVal; __lchistSndrRecInfo5_is_modified = true; }
    public boolean lchistSndrRecInfo5IsModifiedS2j() { return __lchistSndrRecInfo5_is_modified; }
    public String getLchistSndrRecInfo6() { return _lchistSndrRecInfo6 == null ? "" : _lchistSndrRecInfo6.trim(); }
    public void setLchistSndrRecInfo6(String newVal) { this._lchistSndrRecInfo6 = newVal; __lchistSndrRecInfo6_is_modified = true; }
    public boolean lchistSndrRecInfo6IsModifiedS2j() { return __lchistSndrRecInfo6_is_modified; }
    public String getLchistApplicantCntryCode() { return _lchistApplicantCntryCode == null ? "" : _lchistApplicantCntryCode.trim(); }
    public void setLchistApplicantCntryCode(String newVal) { this._lchistApplicantCntryCode = newVal; __lchistApplicantCntryCode_is_modified = true; }
    public boolean lchistApplicantCntryCodeIsModifiedS2j() { return __lchistApplicantCntryCode_is_modified; }
    public String getLchistAvailableWithCntry() { return _lchistAvailableWithCntry == null ? "" : _lchistAvailableWithCntry.trim(); }
    public void setLchistAvailableWithCntry(String newVal) { this._lchistAvailableWithCntry = newVal; __lchistAvailableWithCntry_is_modified = true; }
    public boolean lchistAvailableWithCntryIsModifiedS2j() { return __lchistAvailableWithCntry_is_modified; }
    public int getLchistAvailableWithCodetyp() { return _lchistAvailableWithCodetyp; }
    public void setLchistAvailableWithCodetyp(int newVal) { this._lchistAvailableWithCodetyp = newVal; __lchistAvailableWithCodetyp_is_modified = true; }
    public boolean lchistAvailableWithCodetypIsModifiedS2j() { return __lchistAvailableWithCodetyp_is_modified; }
    public String getLchistDraweeCntryCode() { return _lchistDraweeCntryCode == null ? "" : _lchistDraweeCntryCode.trim(); }
    public void setLchistDraweeCntryCode(String newVal) { this._lchistDraweeCntryCode = newVal; __lchistDraweeCntryCode_is_modified = true; }
    public boolean lchistDraweeCntryCodeIsModifiedS2j() { return __lchistDraweeCntryCode_is_modified; }
    public char getLchistConfirmInstType() { return _lchistConfirmInstType; }
    public void setLchistConfirmInstType(char newVal) { this._lchistConfirmInstType = newVal; __lchistConfirmInstType_is_modified = true; }
    public boolean lchistConfirmInstTypeIsModifiedS2j() { return __lchistConfirmInstType_is_modified; }
    public String getLchistReimbCntryCode() { return _lchistReimbCntryCode == null ? "" : _lchistReimbCntryCode.trim(); }
    public void setLchistReimbCntryCode(String newVal) { this._lchistReimbCntryCode = newVal; __lchistReimbCntryCode_is_modified = true; }
    public boolean lchistReimbCntryCodeIsModifiedS2j() { return __lchistReimbCntryCode_is_modified; }
    public String getLchistSecondAdvCntrycode() { return _lchistSecondAdvCntrycode == null ? "" : _lchistSecondAdvCntrycode.trim(); }
    public void setLchistSecondAdvCntrycode(String newVal) { this._lchistSecondAdvCntrycode = newVal; __lchistSecondAdvCntrycode_is_modified = true; }
    public boolean lchistSecondAdvCntrycodeIsModifiedS2j() { return __lchistSecondAdvCntrycode_is_modified; }
    public String getLchistShipmentPeriod1() { return _lchistShipmentPeriod1 == null ? "" : _lchistShipmentPeriod1.trim(); }
    public void setLchistShipmentPeriod1(String newVal) { this._lchistShipmentPeriod1 = newVal; __lchistShipmentPeriod1_is_modified = true; }
    public boolean lchistShipmentPeriod1IsModifiedS2j() { return __lchistShipmentPeriod1_is_modified; }
    public String getLchistShipmentPeriod2() { return _lchistShipmentPeriod2 == null ? "" : _lchistShipmentPeriod2.trim(); }
    public void setLchistShipmentPeriod2(String newVal) { this._lchistShipmentPeriod2 = newVal; __lchistShipmentPeriod2_is_modified = true; }
    public boolean lchistShipmentPeriod2IsModifiedS2j() { return __lchistShipmentPeriod2_is_modified; }
    public String getLchistShipmentPeriod3() { return _lchistShipmentPeriod3 == null ? "" : _lchistShipmentPeriod3.trim(); }
    public void setLchistShipmentPeriod3(String newVal) { this._lchistShipmentPeriod3 = newVal; __lchistShipmentPeriod3_is_modified = true; }
    public boolean lchistShipmentPeriod3IsModifiedS2j() { return __lchistShipmentPeriod3_is_modified; }
    public String getLchistShipmentPeriod4() { return _lchistShipmentPeriod4 == null ? "" : _lchistShipmentPeriod4.trim(); }
    public void setLchistShipmentPeriod4(String newVal) { this._lchistShipmentPeriod4 = newVal; __lchistShipmentPeriod4_is_modified = true; }
    public boolean lchistShipmentPeriod4IsModifiedS2j() { return __lchistShipmentPeriod4_is_modified; }
    public String getLchistShipmentPeriod5() { return _lchistShipmentPeriod5 == null ? "" : _lchistShipmentPeriod5.trim(); }
    public void setLchistShipmentPeriod5(String newVal) { this._lchistShipmentPeriod5 = newVal; __lchistShipmentPeriod5_is_modified = true; }
    public boolean lchistShipmentPeriod5IsModifiedS2j() { return __lchistShipmentPeriod5_is_modified; }
    public String getLchistShipmentPeriod6() { return _lchistShipmentPeriod6 == null ? "" : _lchistShipmentPeriod6.trim(); }
    public void setLchistShipmentPeriod6(String newVal) { this._lchistShipmentPeriod6 = newVal; __lchistShipmentPeriod6_is_modified = true; }
    public boolean lchistShipmentPeriod6IsModifiedS2j() { return __lchistShipmentPeriod6_is_modified; }
    public String getLchistPerPresntRemarks() { return _lchistPerPresntRemarks == null ? "" : _lchistPerPresntRemarks.trim(); }
    public void setLchistPerPresntRemarks(String newVal) { this._lchistPerPresntRemarks = newVal; __lchistPerPresntRemarks_is_modified = true; }
    public boolean lchistPerPresntRemarksIsModifiedS2j() { return __lchistPerPresntRemarks_is_modified; }
    public String getLchistRecBicCode() { return _lchistRecBicCode == null ? "" : _lchistRecBicCode.trim(); }
    public void setLchistRecBicCode(String newVal) { this._lchistRecBicCode = newVal; __lchistRecBicCode_is_modified = true; }
    public boolean lchistRecBicCodeIsModifiedS2j() { return __lchistRecBicCode_is_modified; }
    public char getLchistCfmReimbType() { return _lchistCfmReimbType; }
    public void setLchistCfmReimbType(char newVal) { this._lchistCfmReimbType = newVal; __lchistCfmReimbType_is_modified = true; }
    public boolean lchistCfmReimbTypeIsModifiedS2j() { return __lchistCfmReimbType_is_modified; }
    public String getLchistCfmReimbBrnCode() { return _lchistCfmReimbBrnCode == null ? "" : _lchistCfmReimbBrnCode.trim(); }
    public void setLchistCfmReimbBrnCode(String newVal) { this._lchistCfmReimbBrnCode = newVal; __lchistCfmReimbBrnCode_is_modified = true; }
    public boolean lchistCfmReimbBrnCodeIsModifiedS2j() { return __lchistCfmReimbBrnCode_is_modified; }
    public String getLchistCfmReimbBicCode() { return _lchistCfmReimbBicCode == null ? "" : _lchistCfmReimbBicCode.trim(); }
    public void setLchistCfmReimbBicCode(String newVal) { this._lchistCfmReimbBicCode = newVal; __lchistCfmReimbBicCode_is_modified = true; }
    public boolean lchistCfmReimbBicCodeIsModifiedS2j() { return __lchistCfmReimbBicCode_is_modified; }
    public String getLchistCfmReimbRoutid() { return _lchistCfmReimbRoutid == null ? "" : _lchistCfmReimbRoutid.trim(); }
    public void setLchistCfmReimbRoutid(String newVal) { this._lchistCfmReimbRoutid = newVal; __lchistCfmReimbRoutid_is_modified = true; }
    public boolean lchistCfmReimbRoutidIsModifiedS2j() { return __lchistCfmReimbRoutid_is_modified; }
    public String getLchistCfmReimbBnkCode() { return _lchistCfmReimbBnkCode == null ? "" : _lchistCfmReimbBnkCode.trim(); }
    public void setLchistCfmReimbBnkCode(String newVal) { this._lchistCfmReimbBnkCode = newVal; __lchistCfmReimbBnkCode_is_modified = true; }
    public boolean lchistCfmReimbBnkCodeIsModifiedS2j() { return __lchistCfmReimbBnkCode_is_modified; }
    public String getLchistCfmReimbAddr1() { return _lchistCfmReimbAddr1 == null ? "" : _lchistCfmReimbAddr1.trim(); }
    public void setLchistCfmReimbAddr1(String newVal) { this._lchistCfmReimbAddr1 = newVal; __lchistCfmReimbAddr1_is_modified = true; }
    public boolean lchistCfmReimbAddr1IsModifiedS2j() { return __lchistCfmReimbAddr1_is_modified; }
    public String getLchistCfmReimbAddr2() { return _lchistCfmReimbAddr2 == null ? "" : _lchistCfmReimbAddr2.trim(); }
    public void setLchistCfmReimbAddr2(String newVal) { this._lchistCfmReimbAddr2 = newVal; __lchistCfmReimbAddr2_is_modified = true; }
    public boolean lchistCfmReimbAddr2IsModifiedS2j() { return __lchistCfmReimbAddr2_is_modified; }
    public String getLchistCfmReimbAddr3() { return _lchistCfmReimbAddr3 == null ? "" : _lchistCfmReimbAddr3.trim(); }
    public void setLchistCfmReimbAddr3(String newVal) { this._lchistCfmReimbAddr3 = newVal; __lchistCfmReimbAddr3_is_modified = true; }
    public boolean lchistCfmReimbAddr3IsModifiedS2j() { return __lchistCfmReimbAddr3_is_modified; }
    public String getLchistCfmReimbAddr4() { return _lchistCfmReimbAddr4 == null ? "" : _lchistCfmReimbAddr4.trim(); }
    public void setLchistCfmReimbAddr4(String newVal) { this._lchistCfmReimbAddr4 = newVal; __lchistCfmReimbAddr4_is_modified = true; }
    public boolean lchistCfmReimbAddr4IsModifiedS2j() { return __lchistCfmReimbAddr4_is_modified; }
    public String getLchistCfmReimbAddr5() { return _lchistCfmReimbAddr5 == null ? "" : _lchistCfmReimbAddr5.trim(); }
    public void setLchistCfmReimbAddr5(String newVal) { this._lchistCfmReimbAddr5 = newVal; __lchistCfmReimbAddr5_is_modified = true; }
    public boolean lchistCfmReimbAddr5IsModifiedS2j() { return __lchistCfmReimbAddr5_is_modified; }
    public String getLchistCfmReimbCntryCode() { return _lchistCfmReimbCntryCode == null ? "" : _lchistCfmReimbCntryCode.trim(); }
    public void setLchistCfmReimbCntryCode(String newVal) { this._lchistCfmReimbCntryCode = newVal; __lchistCfmReimbCntryCode_is_modified = true; }
    public boolean lchistCfmReimbCntryCodeIsModifiedS2j() { return __lchistCfmReimbCntryCode_is_modified; }
    public boolean isNew() { return _isNew; }
    public void setIsNew(boolean isNew) { this._isNew = isNew; }

    public boolean isModifiedS2J() {
        return __lchistBrnCode_is_modified || 
        __lchistLcType_is_modified || 
        __lchistLcYear_is_modified || 
        __lchistLcSl_is_modified || 
        __lchistLcHistsl_is_modified || 
        __lchistLcHistdate_is_modified || 
        __lchistFormOfDocCredit_is_modified || 
        __lchistReferenceToPreadvice_is_modified || 
        __lchistApplicableRules_is_modified || 
        __lchistApplicantReq_is_modified || 
        __lchistApplicantType_is_modified || 
        __lchistApplicantBrnCode_is_modified || 
        __lchistApplicantBicCode_is_modified || 
        __lchistApplicantRoutid_is_modified || 
        __lchistApplicantBnkCode_is_modified || 
        __lchistApplicantAddr1_is_modified || 
        __lchistApplicantAddr2_is_modified || 
        __lchistApplicantAddr3_is_modified || 
        __lchistApplicantAddr4_is_modified || 
        __lchistApplicantAddr5_is_modified || 
        __lchistAvailableWithType_is_modified || 
        __lchistAvailableWithBrnCode_is_modified || 
        __lchistAvailableWithCode_is_modified || 
        __lchistAvailableWithRoutid_is_modified || 
        __lchistAvailableWithBnkCode_is_modified || 
        __lchistAvailableWithAddr1_is_modified || 
        __lchistAvailableWithAddr2_is_modified || 
        __lchistAvailableWithAddr3_is_modified || 
        __lchistAvailableWithAddr4_is_modified || 
        __lchistAvailableWithAddr5_is_modified || 
        __lchistDraftsAt1_is_modified || 
        __lchistDraftsAt2_is_modified || 
        __lchistDraftsAt3_is_modified || 
        __lchistDraweeReq_is_modified || 
        __lchistDraweeType_is_modified || 
        __lchistDraweeBrnCode_is_modified || 
        __lchistDraweeBicCode_is_modified || 
        __lchistDraweeRoutid_is_modified || 
        __lchistDraweeBnkCode_is_modified || 
        __lchistDraweeAddr1_is_modified || 
        __lchistDraweeAddr2_is_modified || 
        __lchistDraweeAddr3_is_modified || 
        __lchistDraweeAddr4_is_modified || 
        __lchistDraweeAddr5_is_modified || 
        __lchistMixedPayDetails1_is_modified || 
        __lchistMixedPayDetails2_is_modified || 
        __lchistMixedPayDetails3_is_modified || 
        __lchistMixedPayDetails4_is_modified || 
        __lchistDeferredPayDetails1_is_modified || 
        __lchistDeferredPayDetails2_is_modified || 
        __lchistDeferredPayDetails3_is_modified || 
        __lchistDeferredPayDetails4_is_modified || 
        __lchistPartialShipments_is_modified || 
        __lchistTranshipment_is_modified || 
        __lchistPlaceInCharge_is_modified || 
        __lchistPortOfLoading_is_modified || 
        __lchistPortOfDischarge_is_modified || 
        __lchistPlaceOfFinalDest_is_modified || 
        __lchistDescGoodsSer1_is_modified || 
        __lchistDescGoodsSer2_is_modified || 
        __lchistDescGoodsSer3_is_modified || 
        __lchistDocReq1_is_modified || 
        __lchistDocReq2_is_modified || 
        __lchistDocReq3_is_modified || 
        __lchistAddCondition1_is_modified || 
        __lchistAddCondition2_is_modified || 
        __lchistAddCondition3_is_modified || 
        __lchistCharges1_is_modified || 
        __lchistCharges2_is_modified || 
        __lchistCharges3_is_modified || 
        __lchistCharges4_is_modified || 
        __lchistCharges5_is_modified || 
        __lchistCharges6_is_modified || 
        __lchistPerPresentationDay_is_modified || 
        __lchistConfirmationInst_is_modified || 
        __lchistReimbReq_is_modified || 
        __lchistReimbType_is_modified || 
        __lchistReimbBrnCode_is_modified || 
        __lchistReimbBicCode_is_modified || 
        __lchistReimbRoutid_is_modified || 
        __lchistReimbBnkCode_is_modified || 
        __lchistReimbAddr1_is_modified || 
        __lchistReimbAddr2_is_modified || 
        __lchistReimbAddr3_is_modified || 
        __lchistReimbAddr4_is_modified || 
        __lchistReimbAddr5_is_modified || 
        __lchistInstPaying1_is_modified || 
        __lchistInstPaying2_is_modified || 
        __lchistInstPaying3_is_modified || 
        __lchistInstPaying4_is_modified || 
        __lchistInstPaying5_is_modified || 
        __lchistInstPaying6_is_modified || 
        __lchistInstPaying7_is_modified || 
        __lchistInstPaying8_is_modified || 
        __lchistInstPaying9_is_modified || 
        __lchistInstPaying10_is_modified || 
        __lchistInstPaying11_is_modified || 
        __lchistInstPaying12_is_modified || 
        __lchistSecondAdvReq_is_modified || 
        __lchistSecondAdvType_is_modified || 
        __lchistSecondAdvBrnCode_is_modified || 
        __lchistSecondAdvBicCode_is_modified || 
        __lchistSecondAdvRoutid_is_modified || 
        __lchistSecondAdvBnkCode_is_modified || 
        __lchistSecondAdvAddr1_is_modified || 
        __lchistSecondAdvAddr2_is_modified || 
        __lchistSecondAdvAddr3_is_modified || 
        __lchistSecondAdvAddr4_is_modified || 
        __lchistSecondAdvAddr5_is_modified || 
        __lchistSndrRecInfo1_is_modified || 
        __lchistSndrRecInfo2_is_modified || 
        __lchistSndrRecInfo3_is_modified || 
        __lchistSndrRecInfo4_is_modified || 
        __lchistSndrRecInfo5_is_modified || 
        __lchistSndrRecInfo6_is_modified || 
        __lchistApplicantCntryCode_is_modified || 
        __lchistAvailableWithCntry_is_modified || 
        __lchistAvailableWithCodetyp_is_modified || 
        __lchistDraweeCntryCode_is_modified || 
        __lchistConfirmInstType_is_modified || 
        __lchistReimbCntryCode_is_modified || 
        __lchistSecondAdvCntrycode_is_modified || 
        __lchistShipmentPeriod1_is_modified || 
        __lchistShipmentPeriod2_is_modified || 
        __lchistShipmentPeriod3_is_modified || 
        __lchistShipmentPeriod4_is_modified || 
        __lchistShipmentPeriod5_is_modified || 
        __lchistShipmentPeriod6_is_modified || 
        __lchistPerPresntRemarks_is_modified || 
        __lchistRecBicCode_is_modified || 
        __lchistCfmReimbType_is_modified || 
        __lchistCfmReimbBrnCode_is_modified || 
        __lchistCfmReimbBicCode_is_modified || 
        __lchistCfmReimbRoutid_is_modified || 
        __lchistCfmReimbBnkCode_is_modified || 
        __lchistCfmReimbAddr1_is_modified || 
        __lchistCfmReimbAddr2_is_modified || 
        __lchistCfmReimbAddr3_is_modified || 
        __lchistCfmReimbAddr4_is_modified || 
        __lchistCfmReimbAddr5_is_modified || 
        __lchistCfmReimbCntryCode_is_modified;
    }

    public void resetIsModifiedS2J() {
        __lchistBrnCode_is_modified = false;
        __lchistLcType_is_modified = false;
        __lchistLcYear_is_modified = false;
        __lchistLcSl_is_modified = false;
        __lchistLcHistsl_is_modified = false;
        __lchistLcHistdate_is_modified = false;
        __lchistFormOfDocCredit_is_modified = false;
        __lchistReferenceToPreadvice_is_modified = false;
        __lchistApplicableRules_is_modified = false;
        __lchistApplicantReq_is_modified = false;
        __lchistApplicantType_is_modified = false;
        __lchistApplicantBrnCode_is_modified = false;
        __lchistApplicantBicCode_is_modified = false;
        __lchistApplicantRoutid_is_modified = false;
        __lchistApplicantBnkCode_is_modified = false;
        __lchistApplicantAddr1_is_modified = false;
        __lchistApplicantAddr2_is_modified = false;
        __lchistApplicantAddr3_is_modified = false;
        __lchistApplicantAddr4_is_modified = false;
        __lchistApplicantAddr5_is_modified = false;
        __lchistAvailableWithType_is_modified = false;
        __lchistAvailableWithBrnCode_is_modified = false;
        __lchistAvailableWithCode_is_modified = false;
        __lchistAvailableWithRoutid_is_modified = false;
        __lchistAvailableWithBnkCode_is_modified = false;
        __lchistAvailableWithAddr1_is_modified = false;
        __lchistAvailableWithAddr2_is_modified = false;
        __lchistAvailableWithAddr3_is_modified = false;
        __lchistAvailableWithAddr4_is_modified = false;
        __lchistAvailableWithAddr5_is_modified = false;
        __lchistDraftsAt1_is_modified = false;
        __lchistDraftsAt2_is_modified = false;
        __lchistDraftsAt3_is_modified = false;
        __lchistDraweeReq_is_modified = false;
        __lchistDraweeType_is_modified = false;
        __lchistDraweeBrnCode_is_modified = false;
        __lchistDraweeBicCode_is_modified = false;
        __lchistDraweeRoutid_is_modified = false;
        __lchistDraweeBnkCode_is_modified = false;
        __lchistDraweeAddr1_is_modified = false;
        __lchistDraweeAddr2_is_modified = false;
        __lchistDraweeAddr3_is_modified = false;
        __lchistDraweeAddr4_is_modified = false;
        __lchistDraweeAddr5_is_modified = false;
        __lchistMixedPayDetails1_is_modified = false;
        __lchistMixedPayDetails2_is_modified = false;
        __lchistMixedPayDetails3_is_modified = false;
        __lchistMixedPayDetails4_is_modified = false;
        __lchistDeferredPayDetails1_is_modified = false;
        __lchistDeferredPayDetails2_is_modified = false;
        __lchistDeferredPayDetails3_is_modified = false;
        __lchistDeferredPayDetails4_is_modified = false;
        __lchistPartialShipments_is_modified = false;
        __lchistTranshipment_is_modified = false;
        __lchistPlaceInCharge_is_modified = false;
        __lchistPortOfLoading_is_modified = false;
        __lchistPortOfDischarge_is_modified = false;
        __lchistPlaceOfFinalDest_is_modified = false;
        __lchistDescGoodsSer1_is_modified = false;
        __lchistDescGoodsSer2_is_modified = false;
        __lchistDescGoodsSer3_is_modified = false;
        __lchistDocReq1_is_modified = false;
        __lchistDocReq2_is_modified = false;
        __lchistDocReq3_is_modified = false;
        __lchistAddCondition1_is_modified = false;
        __lchistAddCondition2_is_modified = false;
        __lchistAddCondition3_is_modified = false;
        __lchistCharges1_is_modified = false;
        __lchistCharges2_is_modified = false;
        __lchistCharges3_is_modified = false;
        __lchistCharges4_is_modified = false;
        __lchistCharges5_is_modified = false;
        __lchistCharges6_is_modified = false;
        __lchistPerPresentationDay_is_modified = false;
        __lchistConfirmationInst_is_modified = false;
        __lchistReimbReq_is_modified = false;
        __lchistReimbType_is_modified = false;
        __lchistReimbBrnCode_is_modified = false;
        __lchistReimbBicCode_is_modified = false;
        __lchistReimbRoutid_is_modified = false;
        __lchistReimbBnkCode_is_modified = false;
        __lchistReimbAddr1_is_modified = false;
        __lchistReimbAddr2_is_modified = false;
        __lchistReimbAddr3_is_modified = false;
        __lchistReimbAddr4_is_modified = false;
        __lchistReimbAddr5_is_modified = false;
        __lchistInstPaying1_is_modified = false;
        __lchistInstPaying2_is_modified = false;
        __lchistInstPaying3_is_modified = false;
        __lchistInstPaying4_is_modified = false;
        __lchistInstPaying5_is_modified = false;
        __lchistInstPaying6_is_modified = false;
        __lchistInstPaying7_is_modified = false;
        __lchistInstPaying8_is_modified = false;
        __lchistInstPaying9_is_modified = false;
        __lchistInstPaying10_is_modified = false;
        __lchistInstPaying11_is_modified = false;
        __lchistInstPaying12_is_modified = false;
        __lchistSecondAdvReq_is_modified = false;
        __lchistSecondAdvType_is_modified = false;
        __lchistSecondAdvBrnCode_is_modified = false;
        __lchistSecondAdvBicCode_is_modified = false;
        __lchistSecondAdvRoutid_is_modified = false;
        __lchistSecondAdvBnkCode_is_modified = false;
        __lchistSecondAdvAddr1_is_modified = false;
        __lchistSecondAdvAddr2_is_modified = false;
        __lchistSecondAdvAddr3_is_modified = false;
        __lchistSecondAdvAddr4_is_modified = false;
        __lchistSecondAdvAddr5_is_modified = false;
        __lchistSndrRecInfo1_is_modified = false;
        __lchistSndrRecInfo2_is_modified = false;
        __lchistSndrRecInfo3_is_modified = false;
        __lchistSndrRecInfo4_is_modified = false;
        __lchistSndrRecInfo5_is_modified = false;
        __lchistSndrRecInfo6_is_modified = false;
        __lchistApplicantCntryCode_is_modified = false;
        __lchistAvailableWithCntry_is_modified = false;
        __lchistAvailableWithCodetyp_is_modified = false;
        __lchistDraweeCntryCode_is_modified = false;
        __lchistConfirmInstType_is_modified = false;
        __lchistReimbCntryCode_is_modified = false;
        __lchistSecondAdvCntrycode_is_modified = false;
        __lchistShipmentPeriod1_is_modified = false;
        __lchistShipmentPeriod2_is_modified = false;
        __lchistShipmentPeriod3_is_modified = false;
        __lchistShipmentPeriod4_is_modified = false;
        __lchistShipmentPeriod5_is_modified = false;
        __lchistShipmentPeriod6_is_modified = false;
        __lchistPerPresntRemarks_is_modified = false;
        __lchistRecBicCode_is_modified = false;
        __lchistCfmReimbType_is_modified = false;
        __lchistCfmReimbBrnCode_is_modified = false;
        __lchistCfmReimbBicCode_is_modified = false;
        __lchistCfmReimbRoutid_is_modified = false;
        __lchistCfmReimbBnkCode_is_modified = false;
        __lchistCfmReimbAddr1_is_modified = false;
        __lchistCfmReimbAddr2_is_modified = false;
        __lchistCfmReimbAddr3_is_modified = false;
        __lchistCfmReimbAddr4_is_modified = false;
        __lchistCfmReimbAddr5_is_modified = false;
        __lchistCfmReimbCntryCode_is_modified = false;
    }
    public LcDetailsHist() {
        _initialize();
    }

    public void _initialize() {
        _lchistBrnCode = 0 ;
        _lchistLcType = "" ;
        _lchistLcYear = 0 ;
        _lchistLcSl = 0 ;
        _lchistLcHistsl = 0 ;
        _lchistLcHistdate = null ;
        _lchistFormOfDocCredit = 0 ;
        _lchistReferenceToPreadvice = "" ;
        _lchistApplicableRules = 0 ;
        _lchistApplicantReq = ' ';
        _lchistApplicantType = ' ';
        _lchistApplicantBrnCode = "" ;
        _lchistApplicantBicCode = "" ;
        _lchistApplicantRoutid = "" ;
        _lchistApplicantBnkCode = "" ;
        _lchistApplicantAddr1 = "" ;
        _lchistApplicantAddr2 = "" ;
        _lchistApplicantAddr3 = "" ;
        _lchistApplicantAddr4 = "" ;
        _lchistApplicantAddr5 = "" ;
        _lchistAvailableWithType = ' ';
        _lchistAvailableWithBrnCode = "" ;
        _lchistAvailableWithCode = "" ;
        _lchistAvailableWithRoutid = "" ;
        _lchistAvailableWithBnkCode = "" ;
        _lchistAvailableWithAddr1 = "" ;
        _lchistAvailableWithAddr2 = "" ;
        _lchistAvailableWithAddr3 = "" ;
        _lchistAvailableWithAddr4 = "" ;
        _lchistAvailableWithAddr5 = "" ;
        _lchistDraftsAt1 = "" ;
        _lchistDraftsAt2 = "" ;
        _lchistDraftsAt3 = "" ;
        _lchistDraweeReq = ' ';
        _lchistDraweeType = ' ';
        _lchistDraweeBrnCode = "" ;
        _lchistDraweeBicCode = "" ;
        _lchistDraweeRoutid = "" ;
        _lchistDraweeBnkCode = "" ;
        _lchistDraweeAddr1 = "" ;
        _lchistDraweeAddr2 = "" ;
        _lchistDraweeAddr3 = "" ;
        _lchistDraweeAddr4 = "" ;
        _lchistDraweeAddr5 = "" ;
        _lchistMixedPayDetails1 = "" ;
        _lchistMixedPayDetails2 = "" ;
        _lchistMixedPayDetails3 = "" ;
        _lchistMixedPayDetails4 = "" ;
        _lchistDeferredPayDetails1 = "" ;
        _lchistDeferredPayDetails2 = "" ;
        _lchistDeferredPayDetails3 = "" ;
        _lchistDeferredPayDetails4 = "" ;
        _lchistPartialShipments = 0 ;
        _lchistTranshipment = 0 ;
        _lchistPlaceInCharge = "" ;
        _lchistPortOfLoading = "" ;
        _lchistPortOfDischarge = "" ;
        _lchistPlaceOfFinalDest = "" ;
        _lchistDescGoodsSer1 = "" ;
        _lchistDescGoodsSer2 = "" ;
        _lchistDescGoodsSer3 = "" ;
        _lchistDocReq1 = "" ;
        _lchistDocReq2 = "" ;
        _lchistDocReq3 = "" ;
        _lchistAddCondition1 = "" ;
        _lchistAddCondition2 = "" ;
        _lchistAddCondition3 = "" ;
        _lchistCharges1 = "" ;
        _lchistCharges2 = "" ;
        _lchistCharges3 = "" ;
        _lchistCharges4 = "" ;
        _lchistCharges5 = "" ;
        _lchistCharges6 = "" ;
        _lchistPerPresentationDay = 0 ;
        _lchistConfirmationInst = 0 ;
        _lchistReimbReq = ' ';
        _lchistReimbType = ' ';
        _lchistReimbBrnCode = "" ;
        _lchistReimbBicCode = "" ;
        _lchistReimbRoutid = "" ;
        _lchistReimbBnkCode = "" ;
        _lchistReimbAddr1 = "" ;
        _lchistReimbAddr2 = "" ;
        _lchistReimbAddr3 = "" ;
        _lchistReimbAddr4 = "" ;
        _lchistReimbAddr5 = "" ;
        _lchistInstPaying1 = "" ;
        _lchistInstPaying2 = "" ;
        _lchistInstPaying3 = "" ;
        _lchistInstPaying4 = "" ;
        _lchistInstPaying5 = "" ;
        _lchistInstPaying6 = "" ;
        _lchistInstPaying7 = "" ;
        _lchistInstPaying8 = "" ;
        _lchistInstPaying9 = "" ;
        _lchistInstPaying10 = "" ;
        _lchistInstPaying11 = "" ;
        _lchistInstPaying12 = "" ;
        _lchistSecondAdvReq = ' ';
        _lchistSecondAdvType = ' ';
        _lchistSecondAdvBrnCode = "" ;
        _lchistSecondAdvBicCode = "" ;
        _lchistSecondAdvRoutid = "" ;
        _lchistSecondAdvBnkCode = "" ;
        _lchistSecondAdvAddr1 = "" ;
        _lchistSecondAdvAddr2 = "" ;
        _lchistSecondAdvAddr3 = "" ;
        _lchistSecondAdvAddr4 = "" ;
        _lchistSecondAdvAddr5 = "" ;
        _lchistSndrRecInfo1 = "" ;
        _lchistSndrRecInfo2 = "" ;
        _lchistSndrRecInfo3 = "" ;
        _lchistSndrRecInfo4 = "" ;
        _lchistSndrRecInfo5 = "" ;
        _lchistSndrRecInfo6 = "" ;
        _lchistApplicantCntryCode = "" ;
        _lchistAvailableWithCntry = "" ;
        _lchistAvailableWithCodetyp = 0 ;
        _lchistDraweeCntryCode = "" ;
        _lchistConfirmInstType = ' ';
        _lchistReimbCntryCode = "" ;
        _lchistSecondAdvCntrycode = "" ;
        _lchistShipmentPeriod1 = "" ;
        _lchistShipmentPeriod2 = "" ;
        _lchistShipmentPeriod3 = "" ;
        _lchistShipmentPeriod4 = "" ;
        _lchistShipmentPeriod5 = "" ;
        _lchistShipmentPeriod6 = "" ;
        _lchistPerPresntRemarks = "" ;
        _lchistRecBicCode = "" ;
        _lchistCfmReimbType = ' ';
        _lchistCfmReimbBrnCode = "" ;
        _lchistCfmReimbBicCode = "" ;
        _lchistCfmReimbRoutid = "" ;
        _lchistCfmReimbBnkCode = "" ;
        _lchistCfmReimbAddr1 = "" ;
        _lchistCfmReimbAddr2 = "" ;
        _lchistCfmReimbAddr3 = "" ;
        _lchistCfmReimbAddr4 = "" ;
        _lchistCfmReimbAddr5 = "" ;
        _lchistCfmReimbCntryCode = "" ;
    }

}
