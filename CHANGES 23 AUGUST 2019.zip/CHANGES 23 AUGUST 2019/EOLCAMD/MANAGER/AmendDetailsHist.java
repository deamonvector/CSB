package panacea.OLC.Update;


/******************SQL2JAVA_IMPORT_BEGIN******************/

/******************SQL2JAVA_IMPORT_END********************/


public class AmendDetailsHist
/******************SQL2JAVA_EXTENDS_BEGIN******************/

/******************SQL2JAVA_EXTENDS_END********************/

{

/******************SQL2JAVA_CLASS_BEGIN******************/

/******************SQL2JAVA_CLASS_END********************/


    private int _amendhistLcBrnCode;
    private boolean __amendhistLcBrnCode_is_modified;
    private String _amendhistLcType;
    private boolean __amendhistLcType_is_modified;
    private int _amendhistLcYear;
    private boolean __amendhistLcYear_is_modified;
    private int _amendhistLcSerial;
    private boolean __amendhistLcSerial_is_modified;
    private int _amendhistLcAmdSl;
    private boolean __amendhistLcAmdSl_is_modified;
    private int _amendhistHistSl;
    private boolean __amendhistHistSl_is_modified;
    private java.util.Date _amendhistHistDate;
    private boolean __amendhistHistDate_is_modified;
    private String _amendhistSndrRef;
    private boolean __amendhistSndrRef_is_modified;
    private String _amendhistRcvrRef;
    private boolean __amendhistRcvrRef_is_modified;
    private String _amendhistDocCrNum;
    private boolean __amendhistDocCrNum_is_modified;
    private char _amendhistIssuingBnkReq;
    private boolean __amendhistIssuingBnkReq_is_modified;
    private char _amendhistIssuingType;
    private boolean __amendhistIssuingType_is_modified;
    private String _amendhistIssuingBrnCode;
    private boolean __amendhistIssuingBrnCode_is_modified;
    private String _amendhistIssuingBicCode;
    private boolean __amendhistIssuingBicCode_is_modified;
    private String _amendhistIssuingRoutid;
    private boolean __amendhistIssuingRoutid_is_modified;
    private String _amendhistIssuingBnkCode;
    private boolean __amendhistIssuingBnkCode_is_modified;
    private String _amendhistIssuingAddr1;
    private boolean __amendhistIssuingAddr1_is_modified;
    private String _amendhistIssuingAddr2;
    private boolean __amendhistIssuingAddr2_is_modified;
    private String _amendhistIssuingAddr3;
    private boolean __amendhistIssuingAddr3_is_modified;
    private String _amendhistIssuingAddr4;
    private boolean __amendhistIssuingAddr4_is_modified;
    private String _amendhistIssuingAddr5;
    private boolean __amendhistIssuingAddr5_is_modified;
    private String _amendhistNonBnkIssur;
    private boolean __amendhistNonBnkIssur_is_modified;
    private java.util.Date _amendhistDateOfIssue;
    private boolean __amendhistDateOfIssue_is_modified;
    private java.util.Date _amendhistDateOfAmendmnt;
    private boolean __amendhistDateOfAmendmnt_is_modified;
    private char _amendhistPurposeOfMsg;
    private boolean __amendhistPurposeOfMsg_is_modified;
    private String _amendhistCancelRequest;
    private boolean __amendhistCancelRequest_is_modified;
    private char _amendhistAdvisingBnkReq;
    private boolean __amendhistAdvisingBnkReq_is_modified;
    private char _amendhistAdvisingBnkType;
    private boolean __amendhistAdvisingBnkType_is_modified;
    private String _amendhistAdvisingBrnCode;
    private boolean __amendhistAdvisingBrnCode_is_modified;
    private String _amendhistAdvisingBicCode;
    private boolean __amendhistAdvisingBicCode_is_modified;
    private String _amendhistAdvisingRoutid;
    private boolean __amendhistAdvisingRoutid_is_modified;
    private String _amendhistAdvisingBnkCode;
    private boolean __amendhistAdvisingBnkCode_is_modified;
    private String _amendhistAdvisingAddr1;
    private boolean __amendhistAdvisingAddr1_is_modified;
    private String _amendhistAdvisingAddr2;
    private boolean __amendhistAdvisingAddr2_is_modified;
    private String _amendhistAdvisingAddr3;
    private boolean __amendhistAdvisingAddr3_is_modified;
    private String _amendhistAdvisingAddr4;
    private boolean __amendhistAdvisingAddr4_is_modified;
    private String _amendhistAdvisingAddr5;
    private boolean __amendhistAdvisingAddr5_is_modified;
    private char _amendhistSecondAdvReq;
    private boolean __amendhistSecondAdvReq_is_modified;
    private char _amendhistSecondAdvType;
    private boolean __amendhistSecondAdvType_is_modified;
    private String _amendhistSecondAdvBrnCode;
    private boolean __amendhistSecondAdvBrnCode_is_modified;
    private String _amendhistSecondAdvBicCode;
    private boolean __amendhistSecondAdvBicCode_is_modified;
    private String _amendhistSecondAdvRoutid;
    private boolean __amendhistSecondAdvRoutid_is_modified;
    private String _amendhistSecondAdvBnkCode;
    private boolean __amendhistSecondAdvBnkCode_is_modified;
    private String _amendhistSecondAdvAddr1;
    private boolean __amendhistSecondAdvAddr1_is_modified;
    private String _amendhistSecondAdvAddr2;
    private boolean __amendhistSecondAdvAddr2_is_modified;
    private String _amendhistSecondAdvAddr3;
    private boolean __amendhistSecondAdvAddr3_is_modified;
    private String _amendhistSecondAdvAddr4;
    private boolean __amendhistSecondAdvAddr4_is_modified;
    private String _amendhistSecondAdvAddr5;
    private boolean __amendhistSecondAdvAddr5_is_modified;
    private String _amendhistNewBeneficiary;
    private boolean __amendhistNewBeneficiary_is_modified;
    private java.util.Date _amendhistNewDateOfExpiry;
    private boolean __amendhistNewDateOfExpiry_is_modified;
    private double _amendhistIncrDocCrAmt;
    private boolean __amendhistIncrDocCrAmt_is_modified;
    private double _amendhistDecrDocCrAmt;
    private boolean __amendhistDecrDocCrAmt_is_modified;
    private double _amendhistNewAddnlAmt;
    private boolean __amendhistNewAddnlAmt_is_modified;
    private String _amendhistPlaceTakinInChrg;
    private boolean __amendhistPlaceTakinInChrg_is_modified;
    private String _amendhistPortOfLoading;
    private boolean __amendhistPortOfLoading_is_modified;
    private String _amendhistPortOfDischarge;
    private boolean __amendhistPortOfDischarge_is_modified;
    private String _amendhistPlaceOfFinalDest;
    private boolean __amendhistPlaceOfFinalDest_is_modified;
    private java.util.Date _amendhistDateOfShipment;
    private boolean __amendhistDateOfShipment_is_modified;
    private Object _amendhistDescGoddSer1;
    private boolean __amendhistDescGoddSer1_is_modified;
    private Object _amendhistDocReq1;
    private boolean __amendhistDocReq1_is_modified;
    private Object _amendhistAddCondition1;
    private boolean __amendhistAddCondition1_is_modified;
    private String _amendhistChrgPayable1;
    private boolean __amendhistChrgPayable1_is_modified;
    private String _amendhistChrgPayable2;
    private boolean __amendhistChrgPayable2_is_modified;
    private String _amendhistChrgPayable3;
    private boolean __amendhistChrgPayable3_is_modified;
    private String _amendhistChrgPayable4;
    private boolean __amendhistChrgPayable4_is_modified;
    private String _amendhistChrgPayable5;
    private boolean __amendhistChrgPayable5_is_modified;
    private String _amendhistChrgPayable6;
    private boolean __amendhistChrgPayable6_is_modified;
    private String _amendhistSndrRecInfo1;
    private boolean __amendhistSndrRecInfo1_is_modified;
    private String _amendhistSndrRecInfo2;
    private boolean __amendhistSndrRecInfo2_is_modified;
    private String _amendhistSndrRecInfo3;
    private boolean __amendhistSndrRecInfo3_is_modified;
    private String _amendhistSndrRecInfo4;
    private boolean __amendhistSndrRecInfo4_is_modified;
    private String _amendhistSndrRecInfo5;
    private boolean __amendhistSndrRecInfo5_is_modified;
    private String _amendhistSndrRecInfo6;
    private boolean __amendhistSndrRecInfo6_is_modified;
    private String _amendhistChkbox;
    private boolean __amendhistChkbox_is_modified;
    private String _amendhistIssuingCntry;
    private boolean __amendhistIssuingCntry_is_modified;
    private String _amendhistAdvisingCntry;
    private boolean __amendhistAdvisingCntry_is_modified;
    private String _amendhistSecondAdvCntry;
    private boolean __amendhistSecondAdvCntry_is_modified;
    private String _amendhistIssueRef;
    private boolean __amendhistIssueRef_is_modified;
    private int _amdhistFormOfDocCredit;
    private boolean __amdhistFormOfDocCredit_is_modified;
    private int _amdhistLcApplicableRules;
    private boolean __amdhistLcApplicableRules_is_modified;
    private char _amdhistLcApplReq;
    private boolean __amdhistLcApplReq_is_modified;
    private String _amdhistLcApplName;
    private boolean __amdhistLcApplName_is_modified;
    private String _amdhistLcApplAddr1;
    private boolean __amdhistLcApplAddr1_is_modified;
    private String _amdhistLcApplAddr2;
    private boolean __amdhistLcApplAddr2_is_modified;
    private String _amdhistLcApplAddr3;
    private boolean __amdhistLcApplAddr3_is_modified;
    private String _amdhistLcApplAddr4;
    private boolean __amdhistLcApplAddr4_is_modified;
    private String _amdhistLcApplAddr5;
    private boolean __amdhistLcApplAddr5_is_modified;
    private char _amdhistLcAvlWithType;
    private boolean __amdhistLcAvlWithType_is_modified;
    private String _amdhistLcAvlWithBrnCode;
    private boolean __amdhistLcAvlWithBrnCode_is_modified;
    private String _amdhistLcAvlWithBicCode;
    private boolean __amdhistLcAvlWithBicCode_is_modified;
    private String _amdhistLcLcAvlWithRoutid;
    private boolean __amdhistLcLcAvlWithRoutid_is_modified;
    private String _amdhistLcAvlWithBnkCode;
    private boolean __amdhistLcAvlWithBnkCode_is_modified;
    private String _amdhistLcAvlWithAddr1;
    private boolean __amdhistLcAvlWithAddr1_is_modified;
    private String _amdhistLcAvlWithAddr2;
    private boolean __amdhistLcAvlWithAddr2_is_modified;
    private String _amdhistLcAvlWithAddr3;
    private boolean __amdhistLcAvlWithAddr3_is_modified;
    private String _amdhistLcAvlWithAddr4;
    private boolean __amdhistLcAvlWithAddr4_is_modified;
    private String _amdhistLcAvlWithAddr5;
    private boolean __amdhistLcAvlWithAddr5_is_modified;
    private String _amdhistLcAvlWithCntry;
    private boolean __amdhistLcAvlWithCntry_is_modified;
    private String _amdhistLcDraftsAt1;
    private boolean __amdhistLcDraftsAt1_is_modified;
    private String _amdhistLcDraftsAt2;
    private boolean __amdhistLcDraftsAt2_is_modified;
    private String _amdhistLcDraftsAt3;
    private boolean __amdhistLcDraftsAt3_is_modified;
    private char _amdhistLcDraweeReq;
    private boolean __amdhistLcDraweeReq_is_modified;
    private char _amdhistLcDraweeType;
    private boolean __amdhistLcDraweeType_is_modified;
    private String _amdhistLcDraweeBrnCode;
    private boolean __amdhistLcDraweeBrnCode_is_modified;
    private String _amdhistLcDraweeBicCode;
    private boolean __amdhistLcDraweeBicCode_is_modified;
    private String _amdhistLcDraweeRoutid;
    private boolean __amdhistLcDraweeRoutid_is_modified;
    private String _amdhistLcDraweeBnkCode;
    private boolean __amdhistLcDraweeBnkCode_is_modified;
    private String _amdhistLcDraweeAddr1;
    private boolean __amdhistLcDraweeAddr1_is_modified;
    private String _amdhistLcDraweeAddr2;
    private boolean __amdhistLcDraweeAddr2_is_modified;
    private String _amdhistLcDraweeAddr3;
    private boolean __amdhistLcDraweeAddr3_is_modified;
    private String _amdhistLcDraweeAddr4;
    private boolean __amdhistLcDraweeAddr4_is_modified;
    private String _amdhistLcDraweeAddr5;
    private boolean __amdhistLcDraweeAddr5_is_modified;
    private String _amdhistDraweeCntryCode;
    private boolean __amdhistDraweeCntryCode_is_modified;
    private String _amdhistLcMixedPayDetails1;
    private boolean __amdhistLcMixedPayDetails1_is_modified;
    private String _amdhistLcMixedPayDetails2;
    private boolean __amdhistLcMixedPayDetails2_is_modified;
    private String _amdhistLcMixedPayDetails3;
    private boolean __amdhistLcMixedPayDetails3_is_modified;
    private String _amdhistLcMixedPayDetails4;
    private boolean __amdhistLcMixedPayDetails4_is_modified;
    private String _amdhistLcMixedPayDetails5;
    private boolean __amdhistLcMixedPayDetails5_is_modified;
    private String _amdhistLcDefPayDetails1;
    private boolean __amdhistLcDefPayDetails1_is_modified;
    private String _amdhistLcDefPayDetails2;
    private boolean __amdhistLcDefPayDetails2_is_modified;
    private String _amdhistLcDefPayDetails3;
    private boolean __amdhistLcDefPayDetails3_is_modified;
    private String _amdhistLcDefPayDetails4;
    private boolean __amdhistLcDefPayDetails4_is_modified;
    private String _amdhistLcDefPayDetails5;
    private boolean __amdhistLcDefPayDetails5_is_modified;
    private int _amdhistLcPartialShipments;
    private boolean __amdhistLcPartialShipments_is_modified;
    private int _amdhistLcTranshipment;
    private boolean __amdhistLcTranshipment_is_modified;
    private int _amdhistLcConfirmationInst;
    private boolean __amdhistLcConfirmationInst_is_modified;
    private char _amdhistLcReimbReq;
    private boolean __amdhistLcReimbReq_is_modified;
    private char _amdhistLcReimbType;
    private boolean __amdhistLcReimbType_is_modified;
    private String _amdhistLcReimbBrnCode;
    private boolean __amdhistLcReimbBrnCode_is_modified;
    private String _amdhistLcReimbBicCode;
    private boolean __amdhistLcReimbBicCode_is_modified;
    private String _amdhistLcReimbRoutid;
    private boolean __amdhistLcReimbRoutid_is_modified;
    private String _amdhistLcReimbBnkCode;
    private boolean __amdhistLcReimbBnkCode_is_modified;
    private String _amdhistLcReimbAddr1;
    private boolean __amdhistLcReimbAddr1_is_modified;
    private String _amdhistLcReimbAddr2;
    private boolean __amdhistLcReimbAddr2_is_modified;
    private String _amdhistLcReimbAddr3;
    private boolean __amdhistLcReimbAddr3_is_modified;
    private String _amdhistLcReimbAddr4;
    private boolean __amdhistLcReimbAddr4_is_modified;
    private String _amdhistLcReimbAddr5;
    private boolean __amdhistLcReimbAddr5_is_modified;
    private String _amdhistLcInstPaying1;
    private boolean __amdhistLcInstPaying1_is_modified;
    private String _amdhistLcInstPaying2;
    private boolean __amdhistLcInstPaying2_is_modified;
    private String _amdhistLcInstPaying3;
    private boolean __amdhistLcInstPaying3_is_modified;
    private String _amdhistLcInstPaying4;
    private boolean __amdhistLcInstPaying4_is_modified;
    private String _amdhistLcInstPaying5;
    private boolean __amdhistLcInstPaying5_is_modified;
    private String _amdhistLcInstPaying6;
    private boolean __amdhistLcInstPaying6_is_modified;
    private String _amdhistLcInstPaying7;
    private boolean __amdhistLcInstPaying7_is_modified;
    private String _amdhistLcInstPaying8;
    private boolean __amdhistLcInstPaying8_is_modified;
    private String _amdhistLcInstPaying9;
    private boolean __amdhistLcInstPaying9_is_modified;
    private String _amdhistLcInstPaying10;
    private boolean __amdhistLcInstPaying10_is_modified;
    private String _amdhistLcInstPaying11;
    private boolean __amdhistLcInstPaying11_is_modified;
    private String _amdhistLcInstPaying12;
    private boolean __amdhistLcInstPaying12_is_modified;
    private char _amdhistLcSecondAdvReq;
    private boolean __amdhistLcSecondAdvReq_is_modified;
    private char _amdhistLcSecondAdvType;
    private boolean __amdhistLcSecondAdvType_is_modified;
    private String _amdhistLcSecondAdvBrnCode;
    private boolean __amdhistLcSecondAdvBrnCode_is_modified;
    private String _amdhistLcSecondAdvBicCode;
    private boolean __amdhistLcSecondAdvBicCode_is_modified;
    private String _amdhistLcSecondAdvRoutid;
    private boolean __amdhistLcSecondAdvRoutid_is_modified;
    private String _amdhistLcSecondAdvBnkCode;
    private boolean __amdhistLcSecondAdvBnkCode_is_modified;
    private String _amdhistLcSecondAdvAddr1;
    private boolean __amdhistLcSecondAdvAddr1_is_modified;
    private String _amdhistLcSecondAdvAddr2;
    private boolean __amdhistLcSecondAdvAddr2_is_modified;
    private String _amdhistLcSecondAdvAddr3;
    private boolean __amdhistLcSecondAdvAddr3_is_modified;
    private String _amdhistLcSecondAdvAddr4;
    private boolean __amdhistLcSecondAdvAddr4_is_modified;
    private String _amdhistLcSecondAdvAddr5;
    private boolean __amdhistLcSecondAdvAddr5_is_modified;
    private String _amdhistLcSecAdvCntrycode;
    private boolean __amdhistLcSecAdvCntrycode_is_modified;
    private char _amendHistLcAvlWithCodetyp;
    private boolean __amendHistLcAvlWithCodetyp_is_modified;
    private String _amendhistLcReimbCntryCode;
    private boolean __amendhistLcReimbCntryCode_is_modified;
    private char _amendhistLcCnfAdvType;
    private boolean __amendhistLcCnfAdvType_is_modified;
    private String _amendhistLcCnfAdvBrnCode;
    private boolean __amendhistLcCnfAdvBrnCode_is_modified;
    private String _amendhistLcCnfAdvBicCode;
    private boolean __amendhistLcCnfAdvBicCode_is_modified;
    private String _amendhistLcCnfAdvRoutid;
    private boolean __amendhistLcCnfAdvRoutid_is_modified;
    private String _amendhistLcCnfAdvBnkCode;
    private boolean __amendhistLcCnfAdvBnkCode_is_modified;
    private String _amendhistLcCnfAdvAddr1;
    private boolean __amendhistLcCnfAdvAddr1_is_modified;
    private String _amendhistLcCnfAdvAddr2;
    private boolean __amendhistLcCnfAdvAddr2_is_modified;
    private String _amendhistLcCnfAdvAddr3;
    private boolean __amendhistLcCnfAdvAddr3_is_modified;
    private String _amendhistLcCnfAdvAddr4;
    private boolean __amendhistLcCnfAdvAddr4_is_modified;
    private String _amendhistLcCnfAdvAddr5;
    private boolean __amendhistLcCnfAdvAddr5_is_modified;
    private String _amendhistLcCnfAdvCntrycode;
    private boolean __amendhistLcCnfAdvCntrycode_is_modified;
    private boolean _isNew = true;

    public int getAmendhistLcBrnCode() { return _amendhistLcBrnCode; }
    public void setAmendhistLcBrnCode(int newVal) { this._amendhistLcBrnCode = newVal; __amendhistLcBrnCode_is_modified = true; }
    public boolean amendhistLcBrnCodeIsModifiedS2j() { return __amendhistLcBrnCode_is_modified; }
    public String getAmendhistLcType() { return _amendhistLcType; }
    public void setAmendhistLcType(String newVal) { this._amendhistLcType = newVal; __amendhistLcType_is_modified = true; }
    public boolean amendhistLcTypeIsModifiedS2j() { return __amendhistLcType_is_modified; }
    public int getAmendhistLcYear() { return _amendhistLcYear; }
    public void setAmendhistLcYear(int newVal) { this._amendhistLcYear = newVal; __amendhistLcYear_is_modified = true; }
    public boolean amendhistLcYearIsModifiedS2j() { return __amendhistLcYear_is_modified; }
    public int getAmendhistLcSerial() { return _amendhistLcSerial; }
    public void setAmendhistLcSerial(int newVal) { this._amendhistLcSerial = newVal; __amendhistLcSerial_is_modified = true; }
    public boolean amendhistLcSerialIsModifiedS2j() { return __amendhistLcSerial_is_modified; }
    public int getAmendhistLcAmdSl() { return _amendhistLcAmdSl; }
    public void setAmendhistLcAmdSl(int newVal) { this._amendhistLcAmdSl = newVal; __amendhistLcAmdSl_is_modified = true; }
    public boolean amendhistLcAmdSlIsModifiedS2j() { return __amendhistLcAmdSl_is_modified; }
    public int getAmendhistHistSl() { return _amendhistHistSl; }
    public void setAmendhistHistSl(int newVal) { this._amendhistHistSl = newVal; __amendhistHistSl_is_modified = true; }
    public boolean amendhistHistSlIsModifiedS2j() { return __amendhistHistSl_is_modified; }
    public java.util.Date getAmendhistHistDate() { return _amendhistHistDate; }
    public void setAmendhistHistDate(java.util.Date newVal) { this._amendhistHistDate = newVal; __amendhistHistDate_is_modified = true; }
    public boolean amendhistHistDateIsModifiedS2j() { return __amendhistHistDate_is_modified; }
    public String getAmendhistSndrRef() { return _amendhistSndrRef == null ? "" : _amendhistSndrRef.trim(); }
    public void setAmendhistSndrRef(String newVal) { this._amendhistSndrRef = newVal; __amendhistSndrRef_is_modified = true; }
    public boolean amendhistSndrRefIsModifiedS2j() { return __amendhistSndrRef_is_modified; }
    public String getAmendhistRcvrRef() { return _amendhistRcvrRef == null ? "" : _amendhistRcvrRef.trim(); }
    public void setAmendhistRcvrRef(String newVal) { this._amendhistRcvrRef = newVal; __amendhistRcvrRef_is_modified = true; }
    public boolean amendhistRcvrRefIsModifiedS2j() { return __amendhistRcvrRef_is_modified; }
    public String getAmendhistDocCrNum() { return _amendhistDocCrNum == null ? "" : _amendhistDocCrNum.trim(); }
    public void setAmendhistDocCrNum(String newVal) { this._amendhistDocCrNum = newVal; __amendhistDocCrNum_is_modified = true; }
    public boolean amendhistDocCrNumIsModifiedS2j() { return __amendhistDocCrNum_is_modified; }
    public char getAmendhistIssuingBnkReq() { return _amendhistIssuingBnkReq; }
    public void setAmendhistIssuingBnkReq(char newVal) { this._amendhistIssuingBnkReq = newVal; __amendhistIssuingBnkReq_is_modified = true; }
    public boolean amendhistIssuingBnkReqIsModifiedS2j() { return __amendhistIssuingBnkReq_is_modified; }
    public char getAmendhistIssuingType() { return _amendhistIssuingType; }
    public void setAmendhistIssuingType(char newVal) { this._amendhistIssuingType = newVal; __amendhistIssuingType_is_modified = true; }
    public boolean amendhistIssuingTypeIsModifiedS2j() { return __amendhistIssuingType_is_modified; }
    public String getAmendhistIssuingBrnCode() { return _amendhistIssuingBrnCode == null ? "" : _amendhistIssuingBrnCode.trim(); }
    public void setAmendhistIssuingBrnCode(String newVal) { this._amendhistIssuingBrnCode = newVal; __amendhistIssuingBrnCode_is_modified = true; }
    public boolean amendhistIssuingBrnCodeIsModifiedS2j() { return __amendhistIssuingBrnCode_is_modified; }
    public String getAmendhistIssuingBicCode() { return _amendhistIssuingBicCode == null ? "" : _amendhistIssuingBicCode.trim(); }
    public void setAmendhistIssuingBicCode(String newVal) { this._amendhistIssuingBicCode = newVal; __amendhistIssuingBicCode_is_modified = true; }
    public boolean amendhistIssuingBicCodeIsModifiedS2j() { return __amendhistIssuingBicCode_is_modified; }
    public String getAmendhistIssuingRoutid() { return _amendhistIssuingRoutid == null ? "" : _amendhistIssuingRoutid.trim(); }
    public void setAmendhistIssuingRoutid(String newVal) { this._amendhistIssuingRoutid = newVal; __amendhistIssuingRoutid_is_modified = true; }
    public boolean amendhistIssuingRoutidIsModifiedS2j() { return __amendhistIssuingRoutid_is_modified; }
    public String getAmendhistIssuingBnkCode() { return _amendhistIssuingBnkCode == null ? "" : _amendhistIssuingBnkCode.trim(); }
    public void setAmendhistIssuingBnkCode(String newVal) { this._amendhistIssuingBnkCode = newVal; __amendhistIssuingBnkCode_is_modified = true; }
    public boolean amendhistIssuingBnkCodeIsModifiedS2j() { return __amendhistIssuingBnkCode_is_modified; }
    public String getAmendhistIssuingAddr1() { return _amendhistIssuingAddr1 == null ? "" : _amendhistIssuingAddr1.trim(); }
    public void setAmendhistIssuingAddr1(String newVal) { this._amendhistIssuingAddr1 = newVal; __amendhistIssuingAddr1_is_modified = true; }
    public boolean amendhistIssuingAddr1IsModifiedS2j() { return __amendhistIssuingAddr1_is_modified; }
    public String getAmendhistIssuingAddr2() { return _amendhistIssuingAddr2 == null ? "" : _amendhistIssuingAddr2.trim(); }
    public void setAmendhistIssuingAddr2(String newVal) { this._amendhistIssuingAddr2 = newVal; __amendhistIssuingAddr2_is_modified = true; }
    public boolean amendhistIssuingAddr2IsModifiedS2j() { return __amendhistIssuingAddr2_is_modified; }
    public String getAmendhistIssuingAddr3() { return _amendhistIssuingAddr3 == null ? "" : _amendhistIssuingAddr3.trim(); }
    public void setAmendhistIssuingAddr3(String newVal) { this._amendhistIssuingAddr3 = newVal; __amendhistIssuingAddr3_is_modified = true; }
    public boolean amendhistIssuingAddr3IsModifiedS2j() { return __amendhistIssuingAddr3_is_modified; }
    public String getAmendhistIssuingAddr4() { return _amendhistIssuingAddr4 == null ? "" : _amendhistIssuingAddr4.trim(); }
    public void setAmendhistIssuingAddr4(String newVal) { this._amendhistIssuingAddr4 = newVal; __amendhistIssuingAddr4_is_modified = true; }
    public boolean amendhistIssuingAddr4IsModifiedS2j() { return __amendhistIssuingAddr4_is_modified; }
    public String getAmendhistIssuingAddr5() { return _amendhistIssuingAddr5 == null ? "" : _amendhistIssuingAddr5.trim(); }
    public void setAmendhistIssuingAddr5(String newVal) { this._amendhistIssuingAddr5 = newVal; __amendhistIssuingAddr5_is_modified = true; }
    public boolean amendhistIssuingAddr5IsModifiedS2j() { return __amendhistIssuingAddr5_is_modified; }
    public String getAmendhistNonBnkIssur() { return _amendhistNonBnkIssur == null ? "" : _amendhistNonBnkIssur.trim(); }
    public void setAmendhistNonBnkIssur(String newVal) { this._amendhistNonBnkIssur = newVal; __amendhistNonBnkIssur_is_modified = true; }
    public boolean amendhistNonBnkIssurIsModifiedS2j() { return __amendhistNonBnkIssur_is_modified; }
    public java.util.Date getAmendhistDateOfIssue() { return _amendhistDateOfIssue; }
    public void setAmendhistDateOfIssue(java.util.Date newVal) { this._amendhistDateOfIssue = newVal; __amendhistDateOfIssue_is_modified = true; }
    public boolean amendhistDateOfIssueIsModifiedS2j() { return __amendhistDateOfIssue_is_modified; }
    public java.util.Date getAmendhistDateOfAmendmnt() { return _amendhistDateOfAmendmnt; }
    public void setAmendhistDateOfAmendmnt(java.util.Date newVal) { this._amendhistDateOfAmendmnt = newVal; __amendhistDateOfAmendmnt_is_modified = true; }
    public boolean amendhistDateOfAmendmntIsModifiedS2j() { return __amendhistDateOfAmendmnt_is_modified; }
    public char getAmendhistPurposeOfMsg() { return _amendhistPurposeOfMsg; }
    public void setAmendhistPurposeOfMsg(char newVal) { this._amendhistPurposeOfMsg = newVal; __amendhistPurposeOfMsg_is_modified = true; }
    public boolean amendhistPurposeOfMsgIsModifiedS2j() { return __amendhistPurposeOfMsg_is_modified; }
    public String getAmendhistCancelRequest() { return _amendhistCancelRequest == null ? "" : _amendhistCancelRequest.trim(); }
    public void setAmendhistCancelRequest(String newVal) { this._amendhistCancelRequest = newVal; __amendhistCancelRequest_is_modified = true; }
    public boolean amendhistCancelRequestIsModifiedS2j() { return __amendhistCancelRequest_is_modified; }
    public char getAmendhistAdvisingBnkReq() { return _amendhistAdvisingBnkReq; }
    public void setAmendhistAdvisingBnkReq(char newVal) { this._amendhistAdvisingBnkReq = newVal; __amendhistAdvisingBnkReq_is_modified = true; }
    public boolean amendhistAdvisingBnkReqIsModifiedS2j() { return __amendhistAdvisingBnkReq_is_modified; }
    public char getAmendhistAdvisingBnkType() { return _amendhistAdvisingBnkType; }
    public void setAmendhistAdvisingBnkType(char newVal) { this._amendhistAdvisingBnkType = newVal; __amendhistAdvisingBnkType_is_modified = true; }
    public boolean amendhistAdvisingBnkTypeIsModifiedS2j() { return __amendhistAdvisingBnkType_is_modified; }
    public String getAmendhistAdvisingBrnCode() { return _amendhistAdvisingBrnCode == null ? "" : _amendhistAdvisingBrnCode.trim(); }
    public void setAmendhistAdvisingBrnCode(String newVal) { this._amendhistAdvisingBrnCode = newVal; __amendhistAdvisingBrnCode_is_modified = true; }
    public boolean amendhistAdvisingBrnCodeIsModifiedS2j() { return __amendhistAdvisingBrnCode_is_modified; }
    public String getAmendhistAdvisingBicCode() { return _amendhistAdvisingBicCode == null ? "" : _amendhistAdvisingBicCode.trim(); }
    public void setAmendhistAdvisingBicCode(String newVal) { this._amendhistAdvisingBicCode = newVal; __amendhistAdvisingBicCode_is_modified = true; }
    public boolean amendhistAdvisingBicCodeIsModifiedS2j() { return __amendhistAdvisingBicCode_is_modified; }
    public String getAmendhistAdvisingRoutid() { return _amendhistAdvisingRoutid == null ? "" : _amendhistAdvisingRoutid.trim(); }
    public void setAmendhistAdvisingRoutid(String newVal) { this._amendhistAdvisingRoutid = newVal; __amendhistAdvisingRoutid_is_modified = true; }
    public boolean amendhistAdvisingRoutidIsModifiedS2j() { return __amendhistAdvisingRoutid_is_modified; }
    public String getAmendhistAdvisingBnkCode() { return _amendhistAdvisingBnkCode == null ? "" : _amendhistAdvisingBnkCode.trim(); }
    public void setAmendhistAdvisingBnkCode(String newVal) { this._amendhistAdvisingBnkCode = newVal; __amendhistAdvisingBnkCode_is_modified = true; }
    public boolean amendhistAdvisingBnkCodeIsModifiedS2j() { return __amendhistAdvisingBnkCode_is_modified; }
    public String getAmendhistAdvisingAddr1() { return _amendhistAdvisingAddr1 == null ? "" : _amendhistAdvisingAddr1.trim(); }
    public void setAmendhistAdvisingAddr1(String newVal) { this._amendhistAdvisingAddr1 = newVal; __amendhistAdvisingAddr1_is_modified = true; }
    public boolean amendhistAdvisingAddr1IsModifiedS2j() { return __amendhistAdvisingAddr1_is_modified; }
    public String getAmendhistAdvisingAddr2() { return _amendhistAdvisingAddr2 == null ? "" : _amendhistAdvisingAddr2.trim(); }
    public void setAmendhistAdvisingAddr2(String newVal) { this._amendhistAdvisingAddr2 = newVal; __amendhistAdvisingAddr2_is_modified = true; }
    public boolean amendhistAdvisingAddr2IsModifiedS2j() { return __amendhistAdvisingAddr2_is_modified; }
    public String getAmendhistAdvisingAddr3() { return _amendhistAdvisingAddr3 == null ? "" : _amendhistAdvisingAddr3.trim(); }
    public void setAmendhistAdvisingAddr3(String newVal) { this._amendhistAdvisingAddr3 = newVal; __amendhistAdvisingAddr3_is_modified = true; }
    public boolean amendhistAdvisingAddr3IsModifiedS2j() { return __amendhistAdvisingAddr3_is_modified; }
    public String getAmendhistAdvisingAddr4() { return _amendhistAdvisingAddr4 == null ? "" : _amendhistAdvisingAddr4.trim(); }
    public void setAmendhistAdvisingAddr4(String newVal) { this._amendhistAdvisingAddr4 = newVal; __amendhistAdvisingAddr4_is_modified = true; }
    public boolean amendhistAdvisingAddr4IsModifiedS2j() { return __amendhistAdvisingAddr4_is_modified; }
    public String getAmendhistAdvisingAddr5() { return _amendhistAdvisingAddr5 == null ? "" : _amendhistAdvisingAddr5.trim(); }
    public void setAmendhistAdvisingAddr5(String newVal) { this._amendhistAdvisingAddr5 = newVal; __amendhistAdvisingAddr5_is_modified = true; }
    public boolean amendhistAdvisingAddr5IsModifiedS2j() { return __amendhistAdvisingAddr5_is_modified; }
    public char getAmendhistSecondAdvReq() { return _amendhistSecondAdvReq; }
    public void setAmendhistSecondAdvReq(char newVal) { this._amendhistSecondAdvReq = newVal; __amendhistSecondAdvReq_is_modified = true; }
    public boolean amendhistSecondAdvReqIsModifiedS2j() { return __amendhistSecondAdvReq_is_modified; }
    public char getAmendhistSecondAdvType() { return _amendhistSecondAdvType; }
    public void setAmendhistSecondAdvType(char newVal) { this._amendhistSecondAdvType = newVal; __amendhistSecondAdvType_is_modified = true; }
    public boolean amendhistSecondAdvTypeIsModifiedS2j() { return __amendhistSecondAdvType_is_modified; }
    public String getAmendhistSecondAdvBrnCode() { return _amendhistSecondAdvBrnCode == null ? "" : _amendhistSecondAdvBrnCode.trim(); }
    public void setAmendhistSecondAdvBrnCode(String newVal) { this._amendhistSecondAdvBrnCode = newVal; __amendhistSecondAdvBrnCode_is_modified = true; }
    public boolean amendhistSecondAdvBrnCodeIsModifiedS2j() { return __amendhistSecondAdvBrnCode_is_modified; }
    public String getAmendhistSecondAdvBicCode() { return _amendhistSecondAdvBicCode == null ? "" : _amendhistSecondAdvBicCode.trim(); }
    public void setAmendhistSecondAdvBicCode(String newVal) { this._amendhistSecondAdvBicCode = newVal; __amendhistSecondAdvBicCode_is_modified = true; }
    public boolean amendhistSecondAdvBicCodeIsModifiedS2j() { return __amendhistSecondAdvBicCode_is_modified; }
    public String getAmendhistSecondAdvRoutid() { return _amendhistSecondAdvRoutid == null ? "" : _amendhistSecondAdvRoutid.trim(); }
    public void setAmendhistSecondAdvRoutid(String newVal) { this._amendhistSecondAdvRoutid = newVal; __amendhistSecondAdvRoutid_is_modified = true; }
    public boolean amendhistSecondAdvRoutidIsModifiedS2j() { return __amendhistSecondAdvRoutid_is_modified; }
    public String getAmendhistSecondAdvBnkCode() { return _amendhistSecondAdvBnkCode == null ? "" : _amendhistSecondAdvBnkCode.trim(); }
    public void setAmendhistSecondAdvBnkCode(String newVal) { this._amendhistSecondAdvBnkCode = newVal; __amendhistSecondAdvBnkCode_is_modified = true; }
    public boolean amendhistSecondAdvBnkCodeIsModifiedS2j() { return __amendhistSecondAdvBnkCode_is_modified; }
    public String getAmendhistSecondAdvAddr1() { return _amendhistSecondAdvAddr1 == null ? "" : _amendhistSecondAdvAddr1.trim(); }
    public void setAmendhistSecondAdvAddr1(String newVal) { this._amendhistSecondAdvAddr1 = newVal; __amendhistSecondAdvAddr1_is_modified = true; }
    public boolean amendhistSecondAdvAddr1IsModifiedS2j() { return __amendhistSecondAdvAddr1_is_modified; }
    public String getAmendhistSecondAdvAddr2() { return _amendhistSecondAdvAddr2 == null ? "" : _amendhistSecondAdvAddr2.trim(); }
    public void setAmendhistSecondAdvAddr2(String newVal) { this._amendhistSecondAdvAddr2 = newVal; __amendhistSecondAdvAddr2_is_modified = true; }
    public boolean amendhistSecondAdvAddr2IsModifiedS2j() { return __amendhistSecondAdvAddr2_is_modified; }
    public String getAmendhistSecondAdvAddr3() { return _amendhistSecondAdvAddr3 == null ? "" : _amendhistSecondAdvAddr3.trim(); }
    public void setAmendhistSecondAdvAddr3(String newVal) { this._amendhistSecondAdvAddr3 = newVal; __amendhistSecondAdvAddr3_is_modified = true; }
    public boolean amendhistSecondAdvAddr3IsModifiedS2j() { return __amendhistSecondAdvAddr3_is_modified; }
    public String getAmendhistSecondAdvAddr4() { return _amendhistSecondAdvAddr4 == null ? "" : _amendhistSecondAdvAddr4.trim(); }
    public void setAmendhistSecondAdvAddr4(String newVal) { this._amendhistSecondAdvAddr4 = newVal; __amendhistSecondAdvAddr4_is_modified = true; }
    public boolean amendhistSecondAdvAddr4IsModifiedS2j() { return __amendhistSecondAdvAddr4_is_modified; }
    public String getAmendhistSecondAdvAddr5() { return _amendhistSecondAdvAddr5 == null ? "" : _amendhistSecondAdvAddr5.trim(); }
    public void setAmendhistSecondAdvAddr5(String newVal) { this._amendhistSecondAdvAddr5 = newVal; __amendhistSecondAdvAddr5_is_modified = true; }
    public boolean amendhistSecondAdvAddr5IsModifiedS2j() { return __amendhistSecondAdvAddr5_is_modified; }
    public String getAmendhistNewBeneficiary() { return _amendhistNewBeneficiary == null ? "" : _amendhistNewBeneficiary.trim(); }
    public void setAmendhistNewBeneficiary(String newVal) { this._amendhistNewBeneficiary = newVal; __amendhistNewBeneficiary_is_modified = true; }
    public boolean amendhistNewBeneficiaryIsModifiedS2j() { return __amendhistNewBeneficiary_is_modified; }
    public java.util.Date getAmendhistNewDateOfExpiry() { return _amendhistNewDateOfExpiry; }
    public void setAmendhistNewDateOfExpiry(java.util.Date newVal) { this._amendhistNewDateOfExpiry = newVal; __amendhistNewDateOfExpiry_is_modified = true; }
    public boolean amendhistNewDateOfExpiryIsModifiedS2j() { return __amendhistNewDateOfExpiry_is_modified; }
    public double getAmendhistIncrDocCrAmt() { return _amendhistIncrDocCrAmt; }
    public void setAmendhistIncrDocCrAmt(double newVal) { this._amendhistIncrDocCrAmt = newVal; __amendhistIncrDocCrAmt_is_modified = true; }
    public boolean amendhistIncrDocCrAmtIsModifiedS2j() { return __amendhistIncrDocCrAmt_is_modified; }
    public double getAmendhistDecrDocCrAmt() { return _amendhistDecrDocCrAmt; }
    public void setAmendhistDecrDocCrAmt(double newVal) { this._amendhistDecrDocCrAmt = newVal; __amendhistDecrDocCrAmt_is_modified = true; }
    public boolean amendhistDecrDocCrAmtIsModifiedS2j() { return __amendhistDecrDocCrAmt_is_modified; }
    public double getAmendhistNewAddnlAmt() { return _amendhistNewAddnlAmt; }
    public void setAmendhistNewAddnlAmt(double newVal) { this._amendhistNewAddnlAmt = newVal; __amendhistNewAddnlAmt_is_modified = true; }
    public boolean amendhistNewAddnlAmtIsModifiedS2j() { return __amendhistNewAddnlAmt_is_modified; }
    public String getAmendhistPlaceTakinInChrg() { return _amendhistPlaceTakinInChrg == null ? "" : _amendhistPlaceTakinInChrg.trim(); }
    public void setAmendhistPlaceTakinInChrg(String newVal) { this._amendhistPlaceTakinInChrg = newVal; __amendhistPlaceTakinInChrg_is_modified = true; }
    public boolean amendhistPlaceTakinInChrgIsModifiedS2j() { return __amendhistPlaceTakinInChrg_is_modified; }
    public String getAmendhistPortOfLoading() { return _amendhistPortOfLoading == null ? "" : _amendhistPortOfLoading.trim(); }
    public void setAmendhistPortOfLoading(String newVal) { this._amendhistPortOfLoading = newVal; __amendhistPortOfLoading_is_modified = true; }
    public boolean amendhistPortOfLoadingIsModifiedS2j() { return __amendhistPortOfLoading_is_modified; }
    public String getAmendhistPortOfDischarge() { return _amendhistPortOfDischarge == null ? "" : _amendhistPortOfDischarge.trim(); }
    public void setAmendhistPortOfDischarge(String newVal) { this._amendhistPortOfDischarge = newVal; __amendhistPortOfDischarge_is_modified = true; }
    public boolean amendhistPortOfDischargeIsModifiedS2j() { return __amendhistPortOfDischarge_is_modified; }
    public String getAmendhistPlaceOfFinalDest() { return _amendhistPlaceOfFinalDest == null ? "" : _amendhistPlaceOfFinalDest.trim(); }
    public void setAmendhistPlaceOfFinalDest(String newVal) { this._amendhistPlaceOfFinalDest = newVal; __amendhistPlaceOfFinalDest_is_modified = true; }
    public boolean amendhistPlaceOfFinalDestIsModifiedS2j() { return __amendhistPlaceOfFinalDest_is_modified; }
    public java.util.Date getAmendhistDateOfShipment() { return _amendhistDateOfShipment; }
    public void setAmendhistDateOfShipment(java.util.Date newVal) { this._amendhistDateOfShipment = newVal; __amendhistDateOfShipment_is_modified = true; }
    public boolean amendhistDateOfShipmentIsModifiedS2j() { return __amendhistDateOfShipment_is_modified; }
    public Object getAmendhistDescGoddSer1() { return _amendhistDescGoddSer1; }
    public void setAmendhistDescGoddSer1(Object newVal) { this._amendhistDescGoddSer1 = newVal; __amendhistDescGoddSer1_is_modified = true; }
    public boolean amendhistDescGoddSer1IsModifiedS2j() { return __amendhistDescGoddSer1_is_modified; }
    public Object getAmendhistDocReq1() { return _amendhistDocReq1; }
    public void setAmendhistDocReq1(Object newVal) { this._amendhistDocReq1 = newVal; __amendhistDocReq1_is_modified = true; }
    public boolean amendhistDocReq1IsModifiedS2j() { return __amendhistDocReq1_is_modified; }
    public Object getAmendhistAddCondition1() { return _amendhistAddCondition1; }
    public void setAmendhistAddCondition1(Object newVal) { this._amendhistAddCondition1 = newVal; __amendhistAddCondition1_is_modified = true; }
    public boolean amendhistAddCondition1IsModifiedS2j() { return __amendhistAddCondition1_is_modified; }
    public String getAmendhistChrgPayable1() { return _amendhistChrgPayable1 == null ? "" : _amendhistChrgPayable1.trim(); }
    public void setAmendhistChrgPayable1(String newVal) { this._amendhistChrgPayable1 = newVal; __amendhistChrgPayable1_is_modified = true; }
    public boolean amendhistChrgPayable1IsModifiedS2j() { return __amendhistChrgPayable1_is_modified; }
    public String getAmendhistChrgPayable2() { return _amendhistChrgPayable2 == null ? "" : _amendhistChrgPayable2.trim(); }
    public void setAmendhistChrgPayable2(String newVal) { this._amendhistChrgPayable2 = newVal; __amendhistChrgPayable2_is_modified = true; }
    public boolean amendhistChrgPayable2IsModifiedS2j() { return __amendhistChrgPayable2_is_modified; }
    public String getAmendhistChrgPayable3() { return _amendhistChrgPayable3 == null ? "" : _amendhistChrgPayable3.trim(); }
    public void setAmendhistChrgPayable3(String newVal) { this._amendhistChrgPayable3 = newVal; __amendhistChrgPayable3_is_modified = true; }
    public boolean amendhistChrgPayable3IsModifiedS2j() { return __amendhistChrgPayable3_is_modified; }
    public String getAmendhistChrgPayable4() { return _amendhistChrgPayable4 == null ? "" : _amendhistChrgPayable4.trim(); }
    public void setAmendhistChrgPayable4(String newVal) { this._amendhistChrgPayable4 = newVal; __amendhistChrgPayable4_is_modified = true; }
    public boolean amendhistChrgPayable4IsModifiedS2j() { return __amendhistChrgPayable4_is_modified; }
    public String getAmendhistChrgPayable5() { return _amendhistChrgPayable5 == null ? "" : _amendhistChrgPayable5.trim(); }
    public void setAmendhistChrgPayable5(String newVal) { this._amendhistChrgPayable5 = newVal; __amendhistChrgPayable5_is_modified = true; }
    public boolean amendhistChrgPayable5IsModifiedS2j() { return __amendhistChrgPayable5_is_modified; }
    public String getAmendhistChrgPayable6() { return _amendhistChrgPayable6 == null ? "" : _amendhistChrgPayable6.trim(); }
    public void setAmendhistChrgPayable6(String newVal) { this._amendhistChrgPayable6 = newVal; __amendhistChrgPayable6_is_modified = true; }
    public boolean amendhistChrgPayable6IsModifiedS2j() { return __amendhistChrgPayable6_is_modified; }
    public String getAmendhistSndrRecInfo1() { return _amendhistSndrRecInfo1 == null ? "" : _amendhistSndrRecInfo1.trim(); }
    public void setAmendhistSndrRecInfo1(String newVal) { this._amendhistSndrRecInfo1 = newVal; __amendhistSndrRecInfo1_is_modified = true; }
    public boolean amendhistSndrRecInfo1IsModifiedS2j() { return __amendhistSndrRecInfo1_is_modified; }
    public String getAmendhistSndrRecInfo2() { return _amendhistSndrRecInfo2 == null ? "" : _amendhistSndrRecInfo2.trim(); }
    public void setAmendhistSndrRecInfo2(String newVal) { this._amendhistSndrRecInfo2 = newVal; __amendhistSndrRecInfo2_is_modified = true; }
    public boolean amendhistSndrRecInfo2IsModifiedS2j() { return __amendhistSndrRecInfo2_is_modified; }
    public String getAmendhistSndrRecInfo3() { return _amendhistSndrRecInfo3 == null ? "" : _amendhistSndrRecInfo3.trim(); }
    public void setAmendhistSndrRecInfo3(String newVal) { this._amendhistSndrRecInfo3 = newVal; __amendhistSndrRecInfo3_is_modified = true; }
    public boolean amendhistSndrRecInfo3IsModifiedS2j() { return __amendhistSndrRecInfo3_is_modified; }
    public String getAmendhistSndrRecInfo4() { return _amendhistSndrRecInfo4 == null ? "" : _amendhistSndrRecInfo4.trim(); }
    public void setAmendhistSndrRecInfo4(String newVal) { this._amendhistSndrRecInfo4 = newVal; __amendhistSndrRecInfo4_is_modified = true; }
    public boolean amendhistSndrRecInfo4IsModifiedS2j() { return __amendhistSndrRecInfo4_is_modified; }
    public String getAmendhistSndrRecInfo5() { return _amendhistSndrRecInfo5 == null ? "" : _amendhistSndrRecInfo5.trim(); }
    public void setAmendhistSndrRecInfo5(String newVal) { this._amendhistSndrRecInfo5 = newVal; __amendhistSndrRecInfo5_is_modified = true; }
    public boolean amendhistSndrRecInfo5IsModifiedS2j() { return __amendhistSndrRecInfo5_is_modified; }
    public String getAmendhistSndrRecInfo6() { return _amendhistSndrRecInfo6 == null ? "" : _amendhistSndrRecInfo6.trim(); }
    public void setAmendhistSndrRecInfo6(String newVal) { this._amendhistSndrRecInfo6 = newVal; __amendhistSndrRecInfo6_is_modified = true; }
    public boolean amendhistSndrRecInfo6IsModifiedS2j() { return __amendhistSndrRecInfo6_is_modified; }
    public String getAmendhistChkbox() { return _amendhistChkbox == null ? "" : _amendhistChkbox.trim(); }
    public void setAmendhistChkbox(String newVal) { this._amendhistChkbox = newVal; __amendhistChkbox_is_modified = true; }
    public boolean amendhistChkboxIsModifiedS2j() { return __amendhistChkbox_is_modified; }
    public String getAmendhistIssuingCntry() { return _amendhistIssuingCntry == null ? "" : _amendhistIssuingCntry.trim(); }
    public void setAmendhistIssuingCntry(String newVal) { this._amendhistIssuingCntry = newVal; __amendhistIssuingCntry_is_modified = true; }
    public boolean amendhistIssuingCntryIsModifiedS2j() { return __amendhistIssuingCntry_is_modified; }
    public String getAmendhistAdvisingCntry() { return _amendhistAdvisingCntry == null ? "" : _amendhistAdvisingCntry.trim(); }
    public void setAmendhistAdvisingCntry(String newVal) { this._amendhistAdvisingCntry = newVal; __amendhistAdvisingCntry_is_modified = true; }
    public boolean amendhistAdvisingCntryIsModifiedS2j() { return __amendhistAdvisingCntry_is_modified; }
    public String getAmendhistSecondAdvCntry() { return _amendhistSecondAdvCntry == null ? "" : _amendhistSecondAdvCntry.trim(); }
    public void setAmendhistSecondAdvCntry(String newVal) { this._amendhistSecondAdvCntry = newVal; __amendhistSecondAdvCntry_is_modified = true; }
    public boolean amendhistSecondAdvCntryIsModifiedS2j() { return __amendhistSecondAdvCntry_is_modified; }
    public String getAmendhistIssueRef() { return _amendhistIssueRef == null ? "" : _amendhistIssueRef.trim(); }
    public void setAmendhistIssueRef(String newVal) { this._amendhistIssueRef = newVal; __amendhistIssueRef_is_modified = true; }
    public boolean amendhistIssueRefIsModifiedS2j() { return __amendhistIssueRef_is_modified; }
    public int getAmdhistFormOfDocCredit() { return _amdhistFormOfDocCredit; }
    public void setAmdhistFormOfDocCredit(int newVal) { this._amdhistFormOfDocCredit = newVal; __amdhistFormOfDocCredit_is_modified = true; }
    public boolean amdhistFormOfDocCreditIsModifiedS2j() { return __amdhistFormOfDocCredit_is_modified; }
    public int getAmdhistLcApplicableRules() { return _amdhistLcApplicableRules; }
    public void setAmdhistLcApplicableRules(int newVal) { this._amdhistLcApplicableRules = newVal; __amdhistLcApplicableRules_is_modified = true; }
    public boolean amdhistLcApplicableRulesIsModifiedS2j() { return __amdhistLcApplicableRules_is_modified; }
    public char getAmdhistLcApplReq() { return _amdhistLcApplReq; }
    public void setAmdhistLcApplReq(char newVal) { this._amdhistLcApplReq = newVal; __amdhistLcApplReq_is_modified = true; }
    public boolean amdhistLcApplReqIsModifiedS2j() { return __amdhistLcApplReq_is_modified; }
    public String getAmdhistLcApplName() { return _amdhistLcApplName == null ? "" : _amdhistLcApplName.trim(); }
    public void setAmdhistLcApplName(String newVal) { this._amdhistLcApplName = newVal; __amdhistLcApplName_is_modified = true; }
    public boolean amdhistLcApplNameIsModifiedS2j() { return __amdhistLcApplName_is_modified; }
    public String getAmdhistLcApplAddr1() { return _amdhistLcApplAddr1 == null ? "" : _amdhistLcApplAddr1.trim(); }
    public void setAmdhistLcApplAddr1(String newVal) { this._amdhistLcApplAddr1 = newVal; __amdhistLcApplAddr1_is_modified = true; }
    public boolean amdhistLcApplAddr1IsModifiedS2j() { return __amdhistLcApplAddr1_is_modified; }
    public String getAmdhistLcApplAddr2() { return _amdhistLcApplAddr2 == null ? "" : _amdhistLcApplAddr2.trim(); }
    public void setAmdhistLcApplAddr2(String newVal) { this._amdhistLcApplAddr2 = newVal; __amdhistLcApplAddr2_is_modified = true; }
    public boolean amdhistLcApplAddr2IsModifiedS2j() { return __amdhistLcApplAddr2_is_modified; }
    public String getAmdhistLcApplAddr3() { return _amdhistLcApplAddr3 == null ? "" : _amdhistLcApplAddr3.trim(); }
    public void setAmdhistLcApplAddr3(String newVal) { this._amdhistLcApplAddr3 = newVal; __amdhistLcApplAddr3_is_modified = true; }
    public boolean amdhistLcApplAddr3IsModifiedS2j() { return __amdhistLcApplAddr3_is_modified; }
    public String getAmdhistLcApplAddr4() { return _amdhistLcApplAddr4 == null ? "" : _amdhistLcApplAddr4.trim(); }
    public void setAmdhistLcApplAddr4(String newVal) { this._amdhistLcApplAddr4 = newVal; __amdhistLcApplAddr4_is_modified = true; }
    public boolean amdhistLcApplAddr4IsModifiedS2j() { return __amdhistLcApplAddr4_is_modified; }
    public String getAmdhistLcApplAddr5() { return _amdhistLcApplAddr5 == null ? "" : _amdhistLcApplAddr5.trim(); }
    public void setAmdhistLcApplAddr5(String newVal) { this._amdhistLcApplAddr5 = newVal; __amdhistLcApplAddr5_is_modified = true; }
    public boolean amdhistLcApplAddr5IsModifiedS2j() { return __amdhistLcApplAddr5_is_modified; }
    public char getAmdhistLcAvlWithType() { return _amdhistLcAvlWithType; }
    public void setAmdhistLcAvlWithType(char newVal) { this._amdhistLcAvlWithType = newVal; __amdhistLcAvlWithType_is_modified = true; }
    public boolean amdhistLcAvlWithTypeIsModifiedS2j() { return __amdhistLcAvlWithType_is_modified; }
    public String getAmdhistLcAvlWithBrnCode() { return _amdhistLcAvlWithBrnCode == null ? "" : _amdhistLcAvlWithBrnCode.trim(); }
    public void setAmdhistLcAvlWithBrnCode(String newVal) { this._amdhistLcAvlWithBrnCode = newVal; __amdhistLcAvlWithBrnCode_is_modified = true; }
    public boolean amdhistLcAvlWithBrnCodeIsModifiedS2j() { return __amdhistLcAvlWithBrnCode_is_modified; }
    public String getAmdhistLcAvlWithBicCode() { return _amdhistLcAvlWithBicCode == null ? "" : _amdhistLcAvlWithBicCode.trim(); }
    public void setAmdhistLcAvlWithBicCode(String newVal) { this._amdhistLcAvlWithBicCode = newVal; __amdhistLcAvlWithBicCode_is_modified = true; }
    public boolean amdhistLcAvlWithBicCodeIsModifiedS2j() { return __amdhistLcAvlWithBicCode_is_modified; }
    public String getAmdhistLcLcAvlWithRoutid() { return _amdhistLcLcAvlWithRoutid == null ? "" : _amdhistLcLcAvlWithRoutid.trim(); }
    public void setAmdhistLcLcAvlWithRoutid(String newVal) { this._amdhistLcLcAvlWithRoutid = newVal; __amdhistLcLcAvlWithRoutid_is_modified = true; }
    public boolean amdhistLcLcAvlWithRoutidIsModifiedS2j() { return __amdhistLcLcAvlWithRoutid_is_modified; }
    public String getAmdhistLcAvlWithBnkCode() { return _amdhistLcAvlWithBnkCode == null ? "" : _amdhistLcAvlWithBnkCode.trim(); }
    public void setAmdhistLcAvlWithBnkCode(String newVal) { this._amdhistLcAvlWithBnkCode = newVal; __amdhistLcAvlWithBnkCode_is_modified = true; }
    public boolean amdhistLcAvlWithBnkCodeIsModifiedS2j() { return __amdhistLcAvlWithBnkCode_is_modified; }
    public String getAmdhistLcAvlWithAddr1() { return _amdhistLcAvlWithAddr1 == null ? "" : _amdhistLcAvlWithAddr1.trim(); }
    public void setAmdhistLcAvlWithAddr1(String newVal) { this._amdhistLcAvlWithAddr1 = newVal; __amdhistLcAvlWithAddr1_is_modified = true; }
    public boolean amdhistLcAvlWithAddr1IsModifiedS2j() { return __amdhistLcAvlWithAddr1_is_modified; }
    public String getAmdhistLcAvlWithAddr2() { return _amdhistLcAvlWithAddr2 == null ? "" : _amdhistLcAvlWithAddr2.trim(); }
    public void setAmdhistLcAvlWithAddr2(String newVal) { this._amdhistLcAvlWithAddr2 = newVal; __amdhistLcAvlWithAddr2_is_modified = true; }
    public boolean amdhistLcAvlWithAddr2IsModifiedS2j() { return __amdhistLcAvlWithAddr2_is_modified; }
    public String getAmdhistLcAvlWithAddr3() { return _amdhistLcAvlWithAddr3 == null ? "" : _amdhistLcAvlWithAddr3.trim(); }
    public void setAmdhistLcAvlWithAddr3(String newVal) { this._amdhistLcAvlWithAddr3 = newVal; __amdhistLcAvlWithAddr3_is_modified = true; }
    public boolean amdhistLcAvlWithAddr3IsModifiedS2j() { return __amdhistLcAvlWithAddr3_is_modified; }
    public String getAmdhistLcAvlWithAddr4() { return _amdhistLcAvlWithAddr4 == null ? "" : _amdhistLcAvlWithAddr4.trim(); }
    public void setAmdhistLcAvlWithAddr4(String newVal) { this._amdhistLcAvlWithAddr4 = newVal; __amdhistLcAvlWithAddr4_is_modified = true; }
    public boolean amdhistLcAvlWithAddr4IsModifiedS2j() { return __amdhistLcAvlWithAddr4_is_modified; }
    public String getAmdhistLcAvlWithAddr5() { return _amdhistLcAvlWithAddr5 == null ? "" : _amdhistLcAvlWithAddr5.trim(); }
    public void setAmdhistLcAvlWithAddr5(String newVal) { this._amdhistLcAvlWithAddr5 = newVal; __amdhistLcAvlWithAddr5_is_modified = true; }
    public boolean amdhistLcAvlWithAddr5IsModifiedS2j() { return __amdhistLcAvlWithAddr5_is_modified; }
    public String getAmdhistLcAvlWithCntry() { return _amdhistLcAvlWithCntry == null ? "" : _amdhistLcAvlWithCntry.trim(); }
    public void setAmdhistLcAvlWithCntry(String newVal) { this._amdhistLcAvlWithCntry = newVal; __amdhistLcAvlWithCntry_is_modified = true; }
    public boolean amdhistLcAvlWithCntryIsModifiedS2j() { return __amdhistLcAvlWithCntry_is_modified; }
    public String getAmdhistLcDraftsAt1() { return _amdhistLcDraftsAt1 == null ? "" : _amdhistLcDraftsAt1.trim(); }
    public void setAmdhistLcDraftsAt1(String newVal) { this._amdhistLcDraftsAt1 = newVal; __amdhistLcDraftsAt1_is_modified = true; }
    public boolean amdhistLcDraftsAt1IsModifiedS2j() { return __amdhistLcDraftsAt1_is_modified; }
    public String getAmdhistLcDraftsAt2() { return _amdhistLcDraftsAt2 == null ? "" : _amdhistLcDraftsAt2.trim(); }
    public void setAmdhistLcDraftsAt2(String newVal) { this._amdhistLcDraftsAt2 = newVal; __amdhistLcDraftsAt2_is_modified = true; }
    public boolean amdhistLcDraftsAt2IsModifiedS2j() { return __amdhistLcDraftsAt2_is_modified; }
    public String getAmdhistLcDraftsAt3() { return _amdhistLcDraftsAt3 == null ? "" : _amdhistLcDraftsAt3.trim(); }
    public void setAmdhistLcDraftsAt3(String newVal) { this._amdhistLcDraftsAt3 = newVal; __amdhistLcDraftsAt3_is_modified = true; }
    public boolean amdhistLcDraftsAt3IsModifiedS2j() { return __amdhistLcDraftsAt3_is_modified; }
    public char getAmdhistLcDraweeReq() { return _amdhistLcDraweeReq; }
    public void setAmdhistLcDraweeReq(char newVal) { this._amdhistLcDraweeReq = newVal; __amdhistLcDraweeReq_is_modified = true; }
    public boolean amdhistLcDraweeReqIsModifiedS2j() { return __amdhistLcDraweeReq_is_modified; }
    public char getAmdhistLcDraweeType() { return _amdhistLcDraweeType; }
    public void setAmdhistLcDraweeType(char newVal) { this._amdhistLcDraweeType = newVal; __amdhistLcDraweeType_is_modified = true; }
    public boolean amdhistLcDraweeTypeIsModifiedS2j() { return __amdhistLcDraweeType_is_modified; }
    public String getAmdhistLcDraweeBrnCode() { return _amdhistLcDraweeBrnCode == null ? "" : _amdhistLcDraweeBrnCode.trim(); }
    public void setAmdhistLcDraweeBrnCode(String newVal) { this._amdhistLcDraweeBrnCode = newVal; __amdhistLcDraweeBrnCode_is_modified = true; }
    public boolean amdhistLcDraweeBrnCodeIsModifiedS2j() { return __amdhistLcDraweeBrnCode_is_modified; }
    public String getAmdhistLcDraweeBicCode() { return _amdhistLcDraweeBicCode == null ? "" : _amdhistLcDraweeBicCode.trim(); }
    public void setAmdhistLcDraweeBicCode(String newVal) { this._amdhistLcDraweeBicCode = newVal; __amdhistLcDraweeBicCode_is_modified = true; }
    public boolean amdhistLcDraweeBicCodeIsModifiedS2j() { return __amdhistLcDraweeBicCode_is_modified; }
    public String getAmdhistLcDraweeRoutid() { return _amdhistLcDraweeRoutid == null ? "" : _amdhistLcDraweeRoutid.trim(); }
    public void setAmdhistLcDraweeRoutid(String newVal) { this._amdhistLcDraweeRoutid = newVal; __amdhistLcDraweeRoutid_is_modified = true; }
    public boolean amdhistLcDraweeRoutidIsModifiedS2j() { return __amdhistLcDraweeRoutid_is_modified; }
    public String getAmdhistLcDraweeBnkCode() { return _amdhistLcDraweeBnkCode == null ? "" : _amdhistLcDraweeBnkCode.trim(); }
    public void setAmdhistLcDraweeBnkCode(String newVal) { this._amdhistLcDraweeBnkCode = newVal; __amdhistLcDraweeBnkCode_is_modified = true; }
    public boolean amdhistLcDraweeBnkCodeIsModifiedS2j() { return __amdhistLcDraweeBnkCode_is_modified; }
    public String getAmdhistLcDraweeAddr1() { return _amdhistLcDraweeAddr1 == null ? "" : _amdhistLcDraweeAddr1.trim(); }
    public void setAmdhistLcDraweeAddr1(String newVal) { this._amdhistLcDraweeAddr1 = newVal; __amdhistLcDraweeAddr1_is_modified = true; }
    public boolean amdhistLcDraweeAddr1IsModifiedS2j() { return __amdhistLcDraweeAddr1_is_modified; }
    public String getAmdhistLcDraweeAddr2() { return _amdhistLcDraweeAddr2 == null ? "" : _amdhistLcDraweeAddr2.trim(); }
    public void setAmdhistLcDraweeAddr2(String newVal) { this._amdhistLcDraweeAddr2 = newVal; __amdhistLcDraweeAddr2_is_modified = true; }
    public boolean amdhistLcDraweeAddr2IsModifiedS2j() { return __amdhistLcDraweeAddr2_is_modified; }
    public String getAmdhistLcDraweeAddr3() { return _amdhistLcDraweeAddr3 == null ? "" : _amdhistLcDraweeAddr3.trim(); }
    public void setAmdhistLcDraweeAddr3(String newVal) { this._amdhistLcDraweeAddr3 = newVal; __amdhistLcDraweeAddr3_is_modified = true; }
    public boolean amdhistLcDraweeAddr3IsModifiedS2j() { return __amdhistLcDraweeAddr3_is_modified; }
    public String getAmdhistLcDraweeAddr4() { return _amdhistLcDraweeAddr4 == null ? "" : _amdhistLcDraweeAddr4.trim(); }
    public void setAmdhistLcDraweeAddr4(String newVal) { this._amdhistLcDraweeAddr4 = newVal; __amdhistLcDraweeAddr4_is_modified = true; }
    public boolean amdhistLcDraweeAddr4IsModifiedS2j() { return __amdhistLcDraweeAddr4_is_modified; }
    public String getAmdhistLcDraweeAddr5() { return _amdhistLcDraweeAddr5 == null ? "" : _amdhistLcDraweeAddr5.trim(); }
    public void setAmdhistLcDraweeAddr5(String newVal) { this._amdhistLcDraweeAddr5 = newVal; __amdhistLcDraweeAddr5_is_modified = true; }
    public boolean amdhistLcDraweeAddr5IsModifiedS2j() { return __amdhistLcDraweeAddr5_is_modified; }
    public String getAmdhistDraweeCntryCode() { return _amdhistDraweeCntryCode == null ? "" : _amdhistDraweeCntryCode.trim(); }
    public void setAmdhistDraweeCntryCode(String newVal) { this._amdhistDraweeCntryCode = newVal; __amdhistDraweeCntryCode_is_modified = true; }
    public boolean amdhistDraweeCntryCodeIsModifiedS2j() { return __amdhistDraweeCntryCode_is_modified; }
    public String getAmdhistLcMixedPayDetails1() { return _amdhistLcMixedPayDetails1 == null ? "" : _amdhistLcMixedPayDetails1.trim(); }
    public void setAmdhistLcMixedPayDetails1(String newVal) { this._amdhistLcMixedPayDetails1 = newVal; __amdhistLcMixedPayDetails1_is_modified = true; }
    public boolean amdhistLcMixedPayDetails1IsModifiedS2j() { return __amdhistLcMixedPayDetails1_is_modified; }
    public String getAmdhistLcMixedPayDetails2() { return _amdhistLcMixedPayDetails2 == null ? "" : _amdhistLcMixedPayDetails2.trim(); }
    public void setAmdhistLcMixedPayDetails2(String newVal) { this._amdhistLcMixedPayDetails2 = newVal; __amdhistLcMixedPayDetails2_is_modified = true; }
    public boolean amdhistLcMixedPayDetails2IsModifiedS2j() { return __amdhistLcMixedPayDetails2_is_modified; }
    public String getAmdhistLcMixedPayDetails3() { return _amdhistLcMixedPayDetails3 == null ? "" : _amdhistLcMixedPayDetails3.trim(); }
    public void setAmdhistLcMixedPayDetails3(String newVal) { this._amdhistLcMixedPayDetails3 = newVal; __amdhistLcMixedPayDetails3_is_modified = true; }
    public boolean amdhistLcMixedPayDetails3IsModifiedS2j() { return __amdhistLcMixedPayDetails3_is_modified; }
    public String getAmdhistLcMixedPayDetails4() { return _amdhistLcMixedPayDetails4 == null ? "" : _amdhistLcMixedPayDetails4.trim(); }
    public void setAmdhistLcMixedPayDetails4(String newVal) { this._amdhistLcMixedPayDetails4 = newVal; __amdhistLcMixedPayDetails4_is_modified = true; }
    public boolean amdhistLcMixedPayDetails4IsModifiedS2j() { return __amdhistLcMixedPayDetails4_is_modified; }
    public String getAmdhistLcMixedPayDetails5() { return _amdhistLcMixedPayDetails5 == null ? "" : _amdhistLcMixedPayDetails5.trim(); }
    public void setAmdhistLcMixedPayDetails5(String newVal) { this._amdhistLcMixedPayDetails5 = newVal; __amdhistLcMixedPayDetails5_is_modified = true; }
    public boolean amdhistLcMixedPayDetails5IsModifiedS2j() { return __amdhistLcMixedPayDetails5_is_modified; }
    public String getAmdhistLcDefPayDetails1() { return _amdhistLcDefPayDetails1 == null ? "" : _amdhistLcDefPayDetails1.trim(); }
    public void setAmdhistLcDefPayDetails1(String newVal) { this._amdhistLcDefPayDetails1 = newVal; __amdhistLcDefPayDetails1_is_modified = true; }
    public boolean amdhistLcDefPayDetails1IsModifiedS2j() { return __amdhistLcDefPayDetails1_is_modified; }
    public String getAmdhistLcDefPayDetails2() { return _amdhistLcDefPayDetails2 == null ? "" : _amdhistLcDefPayDetails2.trim(); }
    public void setAmdhistLcDefPayDetails2(String newVal) { this._amdhistLcDefPayDetails2 = newVal; __amdhistLcDefPayDetails2_is_modified = true; }
    public boolean amdhistLcDefPayDetails2IsModifiedS2j() { return __amdhistLcDefPayDetails2_is_modified; }
    public String getAmdhistLcDefPayDetails3() { return _amdhistLcDefPayDetails3 == null ? "" : _amdhistLcDefPayDetails3.trim(); }
    public void setAmdhistLcDefPayDetails3(String newVal) { this._amdhistLcDefPayDetails3 = newVal; __amdhistLcDefPayDetails3_is_modified = true; }
    public boolean amdhistLcDefPayDetails3IsModifiedS2j() { return __amdhistLcDefPayDetails3_is_modified; }
    public String getAmdhistLcDefPayDetails4() { return _amdhistLcDefPayDetails4 == null ? "" : _amdhistLcDefPayDetails4.trim(); }
    public void setAmdhistLcDefPayDetails4(String newVal) { this._amdhistLcDefPayDetails4 = newVal; __amdhistLcDefPayDetails4_is_modified = true; }
    public boolean amdhistLcDefPayDetails4IsModifiedS2j() { return __amdhistLcDefPayDetails4_is_modified; }
    public String getAmdhistLcDefPayDetails5() { return _amdhistLcDefPayDetails5 == null ? "" : _amdhistLcDefPayDetails5.trim(); }
    public void setAmdhistLcDefPayDetails5(String newVal) { this._amdhistLcDefPayDetails5 = newVal; __amdhistLcDefPayDetails5_is_modified = true; }
    public boolean amdhistLcDefPayDetails5IsModifiedS2j() { return __amdhistLcDefPayDetails5_is_modified; }
    public int getAmdhistLcPartialShipments() { return _amdhistLcPartialShipments; }
    public void setAmdhistLcPartialShipments(int newVal) { this._amdhistLcPartialShipments = newVal; __amdhistLcPartialShipments_is_modified = true; }
    public boolean amdhistLcPartialShipmentsIsModifiedS2j() { return __amdhistLcPartialShipments_is_modified; }
    public int getAmdhistLcTranshipment() { return _amdhistLcTranshipment; }
    public void setAmdhistLcTranshipment(int newVal) { this._amdhistLcTranshipment = newVal; __amdhistLcTranshipment_is_modified = true; }
    public boolean amdhistLcTranshipmentIsModifiedS2j() { return __amdhistLcTranshipment_is_modified; }
    public int getAmdhistLcConfirmationInst() { return _amdhistLcConfirmationInst; }
    public void setAmdhistLcConfirmationInst(int newVal) { this._amdhistLcConfirmationInst = newVal; __amdhistLcConfirmationInst_is_modified = true; }
    public boolean amdhistLcConfirmationInstIsModifiedS2j() { return __amdhistLcConfirmationInst_is_modified; }
    public char getAmdhistLcReimbReq() { return _amdhistLcReimbReq; }
    public void setAmdhistLcReimbReq(char newVal) { this._amdhistLcReimbReq = newVal; __amdhistLcReimbReq_is_modified = true; }
    public boolean amdhistLcReimbReqIsModifiedS2j() { return __amdhistLcReimbReq_is_modified; }
    public char getAmdhistLcReimbType() { return _amdhistLcReimbType; }
    public void setAmdhistLcReimbType(char newVal) { this._amdhistLcReimbType = newVal; __amdhistLcReimbType_is_modified = true; }
    public boolean amdhistLcReimbTypeIsModifiedS2j() { return __amdhistLcReimbType_is_modified; }
    public String getAmdhistLcReimbBrnCode() { return _amdhistLcReimbBrnCode == null ? "" : _amdhistLcReimbBrnCode.trim(); }
    public void setAmdhistLcReimbBrnCode(String newVal) { this._amdhistLcReimbBrnCode = newVal; __amdhistLcReimbBrnCode_is_modified = true; }
    public boolean amdhistLcReimbBrnCodeIsModifiedS2j() { return __amdhistLcReimbBrnCode_is_modified; }
    public String getAmdhistLcReimbBicCode() { return _amdhistLcReimbBicCode == null ? "" : _amdhistLcReimbBicCode.trim(); }
    public void setAmdhistLcReimbBicCode(String newVal) { this._amdhistLcReimbBicCode = newVal; __amdhistLcReimbBicCode_is_modified = true; }
    public boolean amdhistLcReimbBicCodeIsModifiedS2j() { return __amdhistLcReimbBicCode_is_modified; }
    public String getAmdhistLcReimbRoutid() { return _amdhistLcReimbRoutid == null ? "" : _amdhistLcReimbRoutid.trim(); }
    public void setAmdhistLcReimbRoutid(String newVal) { this._amdhistLcReimbRoutid = newVal; __amdhistLcReimbRoutid_is_modified = true; }
    public boolean amdhistLcReimbRoutidIsModifiedS2j() { return __amdhistLcReimbRoutid_is_modified; }
    public String getAmdhistLcReimbBnkCode() { return _amdhistLcReimbBnkCode == null ? "" : _amdhistLcReimbBnkCode.trim(); }
    public void setAmdhistLcReimbBnkCode(String newVal) { this._amdhistLcReimbBnkCode = newVal; __amdhistLcReimbBnkCode_is_modified = true; }
    public boolean amdhistLcReimbBnkCodeIsModifiedS2j() { return __amdhistLcReimbBnkCode_is_modified; }
    public String getAmdhistLcReimbAddr1() { return _amdhistLcReimbAddr1 == null ? "" : _amdhistLcReimbAddr1.trim(); }
    public void setAmdhistLcReimbAddr1(String newVal) { this._amdhistLcReimbAddr1 = newVal; __amdhistLcReimbAddr1_is_modified = true; }
    public boolean amdhistLcReimbAddr1IsModifiedS2j() { return __amdhistLcReimbAddr1_is_modified; }
    public String getAmdhistLcReimbAddr2() { return _amdhistLcReimbAddr2 == null ? "" : _amdhistLcReimbAddr2.trim(); }
    public void setAmdhistLcReimbAddr2(String newVal) { this._amdhistLcReimbAddr2 = newVal; __amdhistLcReimbAddr2_is_modified = true; }
    public boolean amdhistLcReimbAddr2IsModifiedS2j() { return __amdhistLcReimbAddr2_is_modified; }
    public String getAmdhistLcReimbAddr3() { return _amdhistLcReimbAddr3 == null ? "" : _amdhistLcReimbAddr3.trim(); }
    public void setAmdhistLcReimbAddr3(String newVal) { this._amdhistLcReimbAddr3 = newVal; __amdhistLcReimbAddr3_is_modified = true; }
    public boolean amdhistLcReimbAddr3IsModifiedS2j() { return __amdhistLcReimbAddr3_is_modified; }
    public String getAmdhistLcReimbAddr4() { return _amdhistLcReimbAddr4 == null ? "" : _amdhistLcReimbAddr4.trim(); }
    public void setAmdhistLcReimbAddr4(String newVal) { this._amdhistLcReimbAddr4 = newVal; __amdhistLcReimbAddr4_is_modified = true; }
    public boolean amdhistLcReimbAddr4IsModifiedS2j() { return __amdhistLcReimbAddr4_is_modified; }
    public String getAmdhistLcReimbAddr5() { return _amdhistLcReimbAddr5 == null ? "" : _amdhistLcReimbAddr5.trim(); }
    public void setAmdhistLcReimbAddr5(String newVal) { this._amdhistLcReimbAddr5 = newVal; __amdhistLcReimbAddr5_is_modified = true; }
    public boolean amdhistLcReimbAddr5IsModifiedS2j() { return __amdhistLcReimbAddr5_is_modified; }
    public String getAmdhistLcInstPaying1() { return _amdhistLcInstPaying1 == null ? "" : _amdhistLcInstPaying1.trim(); }
    public void setAmdhistLcInstPaying1(String newVal) { this._amdhistLcInstPaying1 = newVal; __amdhistLcInstPaying1_is_modified = true; }
    public boolean amdhistLcInstPaying1IsModifiedS2j() { return __amdhistLcInstPaying1_is_modified; }
    public String getAmdhistLcInstPaying2() { return _amdhistLcInstPaying2 == null ? "" : _amdhistLcInstPaying2.trim(); }
    public void setAmdhistLcInstPaying2(String newVal) { this._amdhistLcInstPaying2 = newVal; __amdhistLcInstPaying2_is_modified = true; }
    public boolean amdhistLcInstPaying2IsModifiedS2j() { return __amdhistLcInstPaying2_is_modified; }
    public String getAmdhistLcInstPaying3() { return _amdhistLcInstPaying3 == null ? "" : _amdhistLcInstPaying3.trim(); }
    public void setAmdhistLcInstPaying3(String newVal) { this._amdhistLcInstPaying3 = newVal; __amdhistLcInstPaying3_is_modified = true; }
    public boolean amdhistLcInstPaying3IsModifiedS2j() { return __amdhistLcInstPaying3_is_modified; }
    public String getAmdhistLcInstPaying4() { return _amdhistLcInstPaying4 == null ? "" : _amdhistLcInstPaying4.trim(); }
    public void setAmdhistLcInstPaying4(String newVal) { this._amdhistLcInstPaying4 = newVal; __amdhistLcInstPaying4_is_modified = true; }
    public boolean amdhistLcInstPaying4IsModifiedS2j() { return __amdhistLcInstPaying4_is_modified; }
    public String getAmdhistLcInstPaying5() { return _amdhistLcInstPaying5 == null ? "" : _amdhistLcInstPaying5.trim(); }
    public void setAmdhistLcInstPaying5(String newVal) { this._amdhistLcInstPaying5 = newVal; __amdhistLcInstPaying5_is_modified = true; }
    public boolean amdhistLcInstPaying5IsModifiedS2j() { return __amdhistLcInstPaying5_is_modified; }
    public String getAmdhistLcInstPaying6() { return _amdhistLcInstPaying6 == null ? "" : _amdhistLcInstPaying6.trim(); }
    public void setAmdhistLcInstPaying6(String newVal) { this._amdhistLcInstPaying6 = newVal; __amdhistLcInstPaying6_is_modified = true; }
    public boolean amdhistLcInstPaying6IsModifiedS2j() { return __amdhistLcInstPaying6_is_modified; }
    public String getAmdhistLcInstPaying7() { return _amdhistLcInstPaying7 == null ? "" : _amdhistLcInstPaying7.trim(); }
    public void setAmdhistLcInstPaying7(String newVal) { this._amdhistLcInstPaying7 = newVal; __amdhistLcInstPaying7_is_modified = true; }
    public boolean amdhistLcInstPaying7IsModifiedS2j() { return __amdhistLcInstPaying7_is_modified; }
    public String getAmdhistLcInstPaying8() { return _amdhistLcInstPaying8 == null ? "" : _amdhistLcInstPaying8.trim(); }
    public void setAmdhistLcInstPaying8(String newVal) { this._amdhistLcInstPaying8 = newVal; __amdhistLcInstPaying8_is_modified = true; }
    public boolean amdhistLcInstPaying8IsModifiedS2j() { return __amdhistLcInstPaying8_is_modified; }
    public String getAmdhistLcInstPaying9() { return _amdhistLcInstPaying9 == null ? "" : _amdhistLcInstPaying9.trim(); }
    public void setAmdhistLcInstPaying9(String newVal) { this._amdhistLcInstPaying9 = newVal; __amdhistLcInstPaying9_is_modified = true; }
    public boolean amdhistLcInstPaying9IsModifiedS2j() { return __amdhistLcInstPaying9_is_modified; }
    public String getAmdhistLcInstPaying10() { return _amdhistLcInstPaying10 == null ? "" : _amdhistLcInstPaying10.trim(); }
    public void setAmdhistLcInstPaying10(String newVal) { this._amdhistLcInstPaying10 = newVal; __amdhistLcInstPaying10_is_modified = true; }
    public boolean amdhistLcInstPaying10IsModifiedS2j() { return __amdhistLcInstPaying10_is_modified; }
    public String getAmdhistLcInstPaying11() { return _amdhistLcInstPaying11 == null ? "" : _amdhistLcInstPaying11.trim(); }
    public void setAmdhistLcInstPaying11(String newVal) { this._amdhistLcInstPaying11 = newVal; __amdhistLcInstPaying11_is_modified = true; }
    public boolean amdhistLcInstPaying11IsModifiedS2j() { return __amdhistLcInstPaying11_is_modified; }
    public String getAmdhistLcInstPaying12() { return _amdhistLcInstPaying12 == null ? "" : _amdhistLcInstPaying12.trim(); }
    public void setAmdhistLcInstPaying12(String newVal) { this._amdhistLcInstPaying12 = newVal; __amdhistLcInstPaying12_is_modified = true; }
    public boolean amdhistLcInstPaying12IsModifiedS2j() { return __amdhistLcInstPaying12_is_modified; }
    public char getAmdhistLcSecondAdvReq() { return _amdhistLcSecondAdvReq; }
    public void setAmdhistLcSecondAdvReq(char newVal) { this._amdhistLcSecondAdvReq = newVal; __amdhistLcSecondAdvReq_is_modified = true; }
    public boolean amdhistLcSecondAdvReqIsModifiedS2j() { return __amdhistLcSecondAdvReq_is_modified; }
    public char getAmdhistLcSecondAdvType() { return _amdhistLcSecondAdvType; }
    public void setAmdhistLcSecondAdvType(char newVal) { this._amdhistLcSecondAdvType = newVal; __amdhistLcSecondAdvType_is_modified = true; }
    public boolean amdhistLcSecondAdvTypeIsModifiedS2j() { return __amdhistLcSecondAdvType_is_modified; }
    public String getAmdhistLcSecondAdvBrnCode() { return _amdhistLcSecondAdvBrnCode == null ? "" : _amdhistLcSecondAdvBrnCode.trim(); }
    public void setAmdhistLcSecondAdvBrnCode(String newVal) { this._amdhistLcSecondAdvBrnCode = newVal; __amdhistLcSecondAdvBrnCode_is_modified = true; }
    public boolean amdhistLcSecondAdvBrnCodeIsModifiedS2j() { return __amdhistLcSecondAdvBrnCode_is_modified; }
    public String getAmdhistLcSecondAdvBicCode() { return _amdhistLcSecondAdvBicCode == null ? "" : _amdhistLcSecondAdvBicCode.trim(); }
    public void setAmdhistLcSecondAdvBicCode(String newVal) { this._amdhistLcSecondAdvBicCode = newVal; __amdhistLcSecondAdvBicCode_is_modified = true; }
    public boolean amdhistLcSecondAdvBicCodeIsModifiedS2j() { return __amdhistLcSecondAdvBicCode_is_modified; }
    public String getAmdhistLcSecondAdvRoutid() { return _amdhistLcSecondAdvRoutid == null ? "" : _amdhistLcSecondAdvRoutid.trim(); }
    public void setAmdhistLcSecondAdvRoutid(String newVal) { this._amdhistLcSecondAdvRoutid = newVal; __amdhistLcSecondAdvRoutid_is_modified = true; }
    public boolean amdhistLcSecondAdvRoutidIsModifiedS2j() { return __amdhistLcSecondAdvRoutid_is_modified; }
    public String getAmdhistLcSecondAdvBnkCode() { return _amdhistLcSecondAdvBnkCode == null ? "" : _amdhistLcSecondAdvBnkCode.trim(); }
    public void setAmdhistLcSecondAdvBnkCode(String newVal) { this._amdhistLcSecondAdvBnkCode = newVal; __amdhistLcSecondAdvBnkCode_is_modified = true; }
    public boolean amdhistLcSecondAdvBnkCodeIsModifiedS2j() { return __amdhistLcSecondAdvBnkCode_is_modified; }
    public String getAmdhistLcSecondAdvAddr1() { return _amdhistLcSecondAdvAddr1 == null ? "" : _amdhistLcSecondAdvAddr1.trim(); }
    public void setAmdhistLcSecondAdvAddr1(String newVal) { this._amdhistLcSecondAdvAddr1 = newVal; __amdhistLcSecondAdvAddr1_is_modified = true; }
    public boolean amdhistLcSecondAdvAddr1IsModifiedS2j() { return __amdhistLcSecondAdvAddr1_is_modified; }
    public String getAmdhistLcSecondAdvAddr2() { return _amdhistLcSecondAdvAddr2 == null ? "" : _amdhistLcSecondAdvAddr2.trim(); }
    public void setAmdhistLcSecondAdvAddr2(String newVal) { this._amdhistLcSecondAdvAddr2 = newVal; __amdhistLcSecondAdvAddr2_is_modified = true; }
    public boolean amdhistLcSecondAdvAddr2IsModifiedS2j() { return __amdhistLcSecondAdvAddr2_is_modified; }
    public String getAmdhistLcSecondAdvAddr3() { return _amdhistLcSecondAdvAddr3 == null ? "" : _amdhistLcSecondAdvAddr3.trim(); }
    public void setAmdhistLcSecondAdvAddr3(String newVal) { this._amdhistLcSecondAdvAddr3 = newVal; __amdhistLcSecondAdvAddr3_is_modified = true; }
    public boolean amdhistLcSecondAdvAddr3IsModifiedS2j() { return __amdhistLcSecondAdvAddr3_is_modified; }
    public String getAmdhistLcSecondAdvAddr4() { return _amdhistLcSecondAdvAddr4 == null ? "" : _amdhistLcSecondAdvAddr4.trim(); }
    public void setAmdhistLcSecondAdvAddr4(String newVal) { this._amdhistLcSecondAdvAddr4 = newVal; __amdhistLcSecondAdvAddr4_is_modified = true; }
    public boolean amdhistLcSecondAdvAddr4IsModifiedS2j() { return __amdhistLcSecondAdvAddr4_is_modified; }
    public String getAmdhistLcSecondAdvAddr5() { return _amdhistLcSecondAdvAddr5 == null ? "" : _amdhistLcSecondAdvAddr5.trim(); }
    public void setAmdhistLcSecondAdvAddr5(String newVal) { this._amdhistLcSecondAdvAddr5 = newVal; __amdhistLcSecondAdvAddr5_is_modified = true; }
    public boolean amdhistLcSecondAdvAddr5IsModifiedS2j() { return __amdhistLcSecondAdvAddr5_is_modified; }
    public String getAmdhistLcSecAdvCntrycode() { return _amdhistLcSecAdvCntrycode == null ? "" : _amdhistLcSecAdvCntrycode.trim(); }
    public void setAmdhistLcSecAdvCntrycode(String newVal) { this._amdhistLcSecAdvCntrycode = newVal; __amdhistLcSecAdvCntrycode_is_modified = true; }
    public boolean amdhistLcSecAdvCntrycodeIsModifiedS2j() { return __amdhistLcSecAdvCntrycode_is_modified; }
    public char getAmendHistLcAvlWithCodetyp() { return _amendHistLcAvlWithCodetyp; }
    public void setAmendHistLcAvlWithCodetyp(char newVal) { this._amendHistLcAvlWithCodetyp = newVal; __amendHistLcAvlWithCodetyp_is_modified = true; }
    public boolean amendHistLcAvlWithCodetypIsModifiedS2j() { return __amendHistLcAvlWithCodetyp_is_modified; }
    public String getAmendhistLcReimbCntryCode() { return _amendhistLcReimbCntryCode == null ? "" : _amendhistLcReimbCntryCode.trim(); }
    public void setAmendhistLcReimbCntryCode(String newVal) { this._amendhistLcReimbCntryCode = newVal; __amendhistLcReimbCntryCode_is_modified = true; }
    public boolean amendhistLcReimbCntryCodeIsModifiedS2j() { return __amendhistLcReimbCntryCode_is_modified; }
    public char getAmendhistLcCnfAdvType() { return _amendhistLcCnfAdvType; }
    public void setAmendhistLcCnfAdvType(char newVal) { this._amendhistLcCnfAdvType = newVal; __amendhistLcCnfAdvType_is_modified = true; }
    public boolean amendhistLcCnfAdvTypeIsModifiedS2j() { return __amendhistLcCnfAdvType_is_modified; }
    public String getAmendhistLcCnfAdvBrnCode() { return _amendhistLcCnfAdvBrnCode == null ? "" : _amendhistLcCnfAdvBrnCode.trim(); }
    public void setAmendhistLcCnfAdvBrnCode(String newVal) { this._amendhistLcCnfAdvBrnCode = newVal; __amendhistLcCnfAdvBrnCode_is_modified = true; }
    public boolean amendhistLcCnfAdvBrnCodeIsModifiedS2j() { return __amendhistLcCnfAdvBrnCode_is_modified; }
    public String getAmendhistLcCnfAdvBicCode() { return _amendhistLcCnfAdvBicCode == null ? "" : _amendhistLcCnfAdvBicCode.trim(); }
    public void setAmendhistLcCnfAdvBicCode(String newVal) { this._amendhistLcCnfAdvBicCode = newVal; __amendhistLcCnfAdvBicCode_is_modified = true; }
    public boolean amendhistLcCnfAdvBicCodeIsModifiedS2j() { return __amendhistLcCnfAdvBicCode_is_modified; }
    public String getAmendhistLcCnfAdvRoutid() { return _amendhistLcCnfAdvRoutid == null ? "" : _amendhistLcCnfAdvRoutid.trim(); }
    public void setAmendhistLcCnfAdvRoutid(String newVal) { this._amendhistLcCnfAdvRoutid = newVal; __amendhistLcCnfAdvRoutid_is_modified = true; }
    public boolean amendhistLcCnfAdvRoutidIsModifiedS2j() { return __amendhistLcCnfAdvRoutid_is_modified; }
    public String getAmendhistLcCnfAdvBnkCode() { return _amendhistLcCnfAdvBnkCode == null ? "" : _amendhistLcCnfAdvBnkCode.trim(); }
    public void setAmendhistLcCnfAdvBnkCode(String newVal) { this._amendhistLcCnfAdvBnkCode = newVal; __amendhistLcCnfAdvBnkCode_is_modified = true; }
    public boolean amendhistLcCnfAdvBnkCodeIsModifiedS2j() { return __amendhistLcCnfAdvBnkCode_is_modified; }
    public String getAmendhistLcCnfAdvAddr1() { return _amendhistLcCnfAdvAddr1 == null ? "" : _amendhistLcCnfAdvAddr1.trim(); }
    public void setAmendhistLcCnfAdvAddr1(String newVal) { this._amendhistLcCnfAdvAddr1 = newVal; __amendhistLcCnfAdvAddr1_is_modified = true; }
    public boolean amendhistLcCnfAdvAddr1IsModifiedS2j() { return __amendhistLcCnfAdvAddr1_is_modified; }
    public String getAmendhistLcCnfAdvAddr2() { return _amendhistLcCnfAdvAddr2 == null ? "" : _amendhistLcCnfAdvAddr2.trim(); }
    public void setAmendhistLcCnfAdvAddr2(String newVal) { this._amendhistLcCnfAdvAddr2 = newVal; __amendhistLcCnfAdvAddr2_is_modified = true; }
    public boolean amendhistLcCnfAdvAddr2IsModifiedS2j() { return __amendhistLcCnfAdvAddr2_is_modified; }
    public String getAmendhistLcCnfAdvAddr3() { return _amendhistLcCnfAdvAddr3 == null ? "" : _amendhistLcCnfAdvAddr3.trim(); }
    public void setAmendhistLcCnfAdvAddr3(String newVal) { this._amendhistLcCnfAdvAddr3 = newVal; __amendhistLcCnfAdvAddr3_is_modified = true; }
    public boolean amendhistLcCnfAdvAddr3IsModifiedS2j() { return __amendhistLcCnfAdvAddr3_is_modified; }
    public String getAmendhistLcCnfAdvAddr4() { return _amendhistLcCnfAdvAddr4 == null ? "" : _amendhistLcCnfAdvAddr4.trim(); }
    public void setAmendhistLcCnfAdvAddr4(String newVal) { this._amendhistLcCnfAdvAddr4 = newVal; __amendhistLcCnfAdvAddr4_is_modified = true; }
    public boolean amendhistLcCnfAdvAddr4IsModifiedS2j() { return __amendhistLcCnfAdvAddr4_is_modified; }
    public String getAmendhistLcCnfAdvAddr5() { return _amendhistLcCnfAdvAddr5 == null ? "" : _amendhistLcCnfAdvAddr5.trim(); }
    public void setAmendhistLcCnfAdvAddr5(String newVal) { this._amendhistLcCnfAdvAddr5 = newVal; __amendhistLcCnfAdvAddr5_is_modified = true; }
    public boolean amendhistLcCnfAdvAddr5IsModifiedS2j() { return __amendhistLcCnfAdvAddr5_is_modified; }
    public String getAmendhistLcCnfAdvCntrycode() { return _amendhistLcCnfAdvCntrycode == null ? "" : _amendhistLcCnfAdvCntrycode.trim(); }
    public void setAmendhistLcCnfAdvCntrycode(String newVal) { this._amendhistLcCnfAdvCntrycode = newVal; __amendhistLcCnfAdvCntrycode_is_modified = true; }
    public boolean amendhistLcCnfAdvCntrycodeIsModifiedS2j() { return __amendhistLcCnfAdvCntrycode_is_modified; }
    public boolean isNew() { return _isNew; }
    public void setIsNew(boolean isNew) { this._isNew = isNew; }

    public boolean isModifiedS2J() {
        return __amendhistLcBrnCode_is_modified || 
        __amendhistLcType_is_modified || 
        __amendhistLcYear_is_modified || 
        __amendhistLcSerial_is_modified || 
        __amendhistLcAmdSl_is_modified || 
        __amendhistHistSl_is_modified || 
        __amendhistHistDate_is_modified || 
        __amendhistSndrRef_is_modified || 
        __amendhistRcvrRef_is_modified || 
        __amendhistDocCrNum_is_modified || 
        __amendhistIssuingBnkReq_is_modified || 
        __amendhistIssuingType_is_modified || 
        __amendhistIssuingBrnCode_is_modified || 
        __amendhistIssuingBicCode_is_modified || 
        __amendhistIssuingRoutid_is_modified || 
        __amendhistIssuingBnkCode_is_modified || 
        __amendhistIssuingAddr1_is_modified || 
        __amendhistIssuingAddr2_is_modified || 
        __amendhistIssuingAddr3_is_modified || 
        __amendhistIssuingAddr4_is_modified || 
        __amendhistIssuingAddr5_is_modified || 
        __amendhistNonBnkIssur_is_modified || 
        __amendhistDateOfIssue_is_modified || 
        __amendhistDateOfAmendmnt_is_modified || 
        __amendhistPurposeOfMsg_is_modified || 
        __amendhistCancelRequest_is_modified || 
        __amendhistAdvisingBnkReq_is_modified || 
        __amendhistAdvisingBnkType_is_modified || 
        __amendhistAdvisingBrnCode_is_modified || 
        __amendhistAdvisingBicCode_is_modified || 
        __amendhistAdvisingRoutid_is_modified || 
        __amendhistAdvisingBnkCode_is_modified || 
        __amendhistAdvisingAddr1_is_modified || 
        __amendhistAdvisingAddr2_is_modified || 
        __amendhistAdvisingAddr3_is_modified || 
        __amendhistAdvisingAddr4_is_modified || 
        __amendhistAdvisingAddr5_is_modified || 
        __amendhistSecondAdvReq_is_modified || 
        __amendhistSecondAdvType_is_modified || 
        __amendhistSecondAdvBrnCode_is_modified || 
        __amendhistSecondAdvBicCode_is_modified || 
        __amendhistSecondAdvRoutid_is_modified || 
        __amendhistSecondAdvBnkCode_is_modified || 
        __amendhistSecondAdvAddr1_is_modified || 
        __amendhistSecondAdvAddr2_is_modified || 
        __amendhistSecondAdvAddr3_is_modified || 
        __amendhistSecondAdvAddr4_is_modified || 
        __amendhistSecondAdvAddr5_is_modified || 
        __amendhistNewBeneficiary_is_modified || 
        __amendhistNewDateOfExpiry_is_modified || 
        __amendhistIncrDocCrAmt_is_modified || 
        __amendhistDecrDocCrAmt_is_modified || 
        __amendhistNewAddnlAmt_is_modified || 
        __amendhistPlaceTakinInChrg_is_modified || 
        __amendhistPortOfLoading_is_modified || 
        __amendhistPortOfDischarge_is_modified || 
        __amendhistPlaceOfFinalDest_is_modified || 
        __amendhistDateOfShipment_is_modified || 
        __amendhistDescGoddSer1_is_modified || 
        __amendhistDocReq1_is_modified || 
        __amendhistAddCondition1_is_modified || 
        __amendhistChrgPayable1_is_modified || 
        __amendhistChrgPayable2_is_modified || 
        __amendhistChrgPayable3_is_modified || 
        __amendhistChrgPayable4_is_modified || 
        __amendhistChrgPayable5_is_modified || 
        __amendhistChrgPayable6_is_modified || 
        __amendhistSndrRecInfo1_is_modified || 
        __amendhistSndrRecInfo2_is_modified || 
        __amendhistSndrRecInfo3_is_modified || 
        __amendhistSndrRecInfo4_is_modified || 
        __amendhistSndrRecInfo5_is_modified || 
        __amendhistSndrRecInfo6_is_modified || 
        __amendhistChkbox_is_modified || 
        __amendhistIssuingCntry_is_modified || 
        __amendhistAdvisingCntry_is_modified || 
        __amendhistSecondAdvCntry_is_modified || 
        __amendhistIssueRef_is_modified || 
        __amdhistFormOfDocCredit_is_modified || 
        __amdhistLcApplicableRules_is_modified || 
        __amdhistLcApplReq_is_modified || 
        __amdhistLcApplName_is_modified || 
        __amdhistLcApplAddr1_is_modified || 
        __amdhistLcApplAddr2_is_modified || 
        __amdhistLcApplAddr3_is_modified || 
        __amdhistLcApplAddr4_is_modified || 
        __amdhistLcApplAddr5_is_modified || 
        __amdhistLcAvlWithType_is_modified || 
        __amdhistLcAvlWithBrnCode_is_modified || 
        __amdhistLcAvlWithBicCode_is_modified || 
        __amdhistLcLcAvlWithRoutid_is_modified || 
        __amdhistLcAvlWithBnkCode_is_modified || 
        __amdhistLcAvlWithAddr1_is_modified || 
        __amdhistLcAvlWithAddr2_is_modified || 
        __amdhistLcAvlWithAddr3_is_modified || 
        __amdhistLcAvlWithAddr4_is_modified || 
        __amdhistLcAvlWithAddr5_is_modified || 
        __amdhistLcAvlWithCntry_is_modified || 
        __amdhistLcDraftsAt1_is_modified || 
        __amdhistLcDraftsAt2_is_modified || 
        __amdhistLcDraftsAt3_is_modified || 
        __amdhistLcDraweeReq_is_modified || 
        __amdhistLcDraweeType_is_modified || 
        __amdhistLcDraweeBrnCode_is_modified || 
        __amdhistLcDraweeBicCode_is_modified || 
        __amdhistLcDraweeRoutid_is_modified || 
        __amdhistLcDraweeBnkCode_is_modified || 
        __amdhistLcDraweeAddr1_is_modified || 
        __amdhistLcDraweeAddr2_is_modified || 
        __amdhistLcDraweeAddr3_is_modified || 
        __amdhistLcDraweeAddr4_is_modified || 
        __amdhistLcDraweeAddr5_is_modified || 
        __amdhistDraweeCntryCode_is_modified || 
        __amdhistLcMixedPayDetails1_is_modified || 
        __amdhistLcMixedPayDetails2_is_modified || 
        __amdhistLcMixedPayDetails3_is_modified || 
        __amdhistLcMixedPayDetails4_is_modified || 
        __amdhistLcMixedPayDetails5_is_modified || 
        __amdhistLcDefPayDetails1_is_modified || 
        __amdhistLcDefPayDetails2_is_modified || 
        __amdhistLcDefPayDetails3_is_modified || 
        __amdhistLcDefPayDetails4_is_modified || 
        __amdhistLcDefPayDetails5_is_modified || 
        __amdhistLcPartialShipments_is_modified || 
        __amdhistLcTranshipment_is_modified || 
        __amdhistLcConfirmationInst_is_modified || 
        __amdhistLcReimbReq_is_modified || 
        __amdhistLcReimbType_is_modified || 
        __amdhistLcReimbBrnCode_is_modified || 
        __amdhistLcReimbBicCode_is_modified || 
        __amdhistLcReimbRoutid_is_modified || 
        __amdhistLcReimbBnkCode_is_modified || 
        __amdhistLcReimbAddr1_is_modified || 
        __amdhistLcReimbAddr2_is_modified || 
        __amdhistLcReimbAddr3_is_modified || 
        __amdhistLcReimbAddr4_is_modified || 
        __amdhistLcReimbAddr5_is_modified || 
        __amdhistLcInstPaying1_is_modified || 
        __amdhistLcInstPaying2_is_modified || 
        __amdhistLcInstPaying3_is_modified || 
        __amdhistLcInstPaying4_is_modified || 
        __amdhistLcInstPaying5_is_modified || 
        __amdhistLcInstPaying6_is_modified || 
        __amdhistLcInstPaying7_is_modified || 
        __amdhistLcInstPaying8_is_modified || 
        __amdhistLcInstPaying9_is_modified || 
        __amdhistLcInstPaying10_is_modified || 
        __amdhistLcInstPaying11_is_modified || 
        __amdhistLcInstPaying12_is_modified || 
        __amdhistLcSecondAdvReq_is_modified || 
        __amdhistLcSecondAdvType_is_modified || 
        __amdhistLcSecondAdvBrnCode_is_modified || 
        __amdhistLcSecondAdvBicCode_is_modified || 
        __amdhistLcSecondAdvRoutid_is_modified || 
        __amdhistLcSecondAdvBnkCode_is_modified || 
        __amdhistLcSecondAdvAddr1_is_modified || 
        __amdhistLcSecondAdvAddr2_is_modified || 
        __amdhistLcSecondAdvAddr3_is_modified || 
        __amdhistLcSecondAdvAddr4_is_modified || 
        __amdhistLcSecondAdvAddr5_is_modified || 
        __amdhistLcSecAdvCntrycode_is_modified || 
        __amendHistLcAvlWithCodetyp_is_modified || 
        __amendhistLcReimbCntryCode_is_modified || 
        __amendhistLcCnfAdvType_is_modified || 
        __amendhistLcCnfAdvBrnCode_is_modified || 
        __amendhistLcCnfAdvBicCode_is_modified || 
        __amendhistLcCnfAdvRoutid_is_modified || 
        __amendhistLcCnfAdvBnkCode_is_modified || 
        __amendhistLcCnfAdvAddr1_is_modified || 
        __amendhistLcCnfAdvAddr2_is_modified || 
        __amendhistLcCnfAdvAddr3_is_modified || 
        __amendhistLcCnfAdvAddr4_is_modified || 
        __amendhistLcCnfAdvAddr5_is_modified || 
        __amendhistLcCnfAdvCntrycode_is_modified;
    }

    public void resetIsModifiedS2J() {
        __amendhistLcBrnCode_is_modified = false;
        __amendhistLcType_is_modified = false;
        __amendhistLcYear_is_modified = false;
        __amendhistLcSerial_is_modified = false;
        __amendhistLcAmdSl_is_modified = false;
        __amendhistHistSl_is_modified = false;
        __amendhistHistDate_is_modified = false;
        __amendhistSndrRef_is_modified = false;
        __amendhistRcvrRef_is_modified = false;
        __amendhistDocCrNum_is_modified = false;
        __amendhistIssuingBnkReq_is_modified = false;
        __amendhistIssuingType_is_modified = false;
        __amendhistIssuingBrnCode_is_modified = false;
        __amendhistIssuingBicCode_is_modified = false;
        __amendhistIssuingRoutid_is_modified = false;
        __amendhistIssuingBnkCode_is_modified = false;
        __amendhistIssuingAddr1_is_modified = false;
        __amendhistIssuingAddr2_is_modified = false;
        __amendhistIssuingAddr3_is_modified = false;
        __amendhistIssuingAddr4_is_modified = false;
        __amendhistIssuingAddr5_is_modified = false;
        __amendhistNonBnkIssur_is_modified = false;
        __amendhistDateOfIssue_is_modified = false;
        __amendhistDateOfAmendmnt_is_modified = false;
        __amendhistPurposeOfMsg_is_modified = false;
        __amendhistCancelRequest_is_modified = false;
        __amendhistAdvisingBnkReq_is_modified = false;
        __amendhistAdvisingBnkType_is_modified = false;
        __amendhistAdvisingBrnCode_is_modified = false;
        __amendhistAdvisingBicCode_is_modified = false;
        __amendhistAdvisingRoutid_is_modified = false;
        __amendhistAdvisingBnkCode_is_modified = false;
        __amendhistAdvisingAddr1_is_modified = false;
        __amendhistAdvisingAddr2_is_modified = false;
        __amendhistAdvisingAddr3_is_modified = false;
        __amendhistAdvisingAddr4_is_modified = false;
        __amendhistAdvisingAddr5_is_modified = false;
        __amendhistSecondAdvReq_is_modified = false;
        __amendhistSecondAdvType_is_modified = false;
        __amendhistSecondAdvBrnCode_is_modified = false;
        __amendhistSecondAdvBicCode_is_modified = false;
        __amendhistSecondAdvRoutid_is_modified = false;
        __amendhistSecondAdvBnkCode_is_modified = false;
        __amendhistSecondAdvAddr1_is_modified = false;
        __amendhistSecondAdvAddr2_is_modified = false;
        __amendhistSecondAdvAddr3_is_modified = false;
        __amendhistSecondAdvAddr4_is_modified = false;
        __amendhistSecondAdvAddr5_is_modified = false;
        __amendhistNewBeneficiary_is_modified = false;
        __amendhistNewDateOfExpiry_is_modified = false;
        __amendhistIncrDocCrAmt_is_modified = false;
        __amendhistDecrDocCrAmt_is_modified = false;
        __amendhistNewAddnlAmt_is_modified = false;
        __amendhistPlaceTakinInChrg_is_modified = false;
        __amendhistPortOfLoading_is_modified = false;
        __amendhistPortOfDischarge_is_modified = false;
        __amendhistPlaceOfFinalDest_is_modified = false;
        __amendhistDateOfShipment_is_modified = false;
        __amendhistDescGoddSer1_is_modified = false;
        __amendhistDocReq1_is_modified = false;
        __amendhistAddCondition1_is_modified = false;
        __amendhistChrgPayable1_is_modified = false;
        __amendhistChrgPayable2_is_modified = false;
        __amendhistChrgPayable3_is_modified = false;
        __amendhistChrgPayable4_is_modified = false;
        __amendhistChrgPayable5_is_modified = false;
        __amendhistChrgPayable6_is_modified = false;
        __amendhistSndrRecInfo1_is_modified = false;
        __amendhistSndrRecInfo2_is_modified = false;
        __amendhistSndrRecInfo3_is_modified = false;
        __amendhistSndrRecInfo4_is_modified = false;
        __amendhistSndrRecInfo5_is_modified = false;
        __amendhistSndrRecInfo6_is_modified = false;
        __amendhistChkbox_is_modified = false;
        __amendhistIssuingCntry_is_modified = false;
        __amendhistAdvisingCntry_is_modified = false;
        __amendhistSecondAdvCntry_is_modified = false;
        __amendhistIssueRef_is_modified = false;
        __amdhistFormOfDocCredit_is_modified = false;
        __amdhistLcApplicableRules_is_modified = false;
        __amdhistLcApplReq_is_modified = false;
        __amdhistLcApplName_is_modified = false;
        __amdhistLcApplAddr1_is_modified = false;
        __amdhistLcApplAddr2_is_modified = false;
        __amdhistLcApplAddr3_is_modified = false;
        __amdhistLcApplAddr4_is_modified = false;
        __amdhistLcApplAddr5_is_modified = false;
        __amdhistLcAvlWithType_is_modified = false;
        __amdhistLcAvlWithBrnCode_is_modified = false;
        __amdhistLcAvlWithBicCode_is_modified = false;
        __amdhistLcLcAvlWithRoutid_is_modified = false;
        __amdhistLcAvlWithBnkCode_is_modified = false;
        __amdhistLcAvlWithAddr1_is_modified = false;
        __amdhistLcAvlWithAddr2_is_modified = false;
        __amdhistLcAvlWithAddr3_is_modified = false;
        __amdhistLcAvlWithAddr4_is_modified = false;
        __amdhistLcAvlWithAddr5_is_modified = false;
        __amdhistLcAvlWithCntry_is_modified = false;
        __amdhistLcDraftsAt1_is_modified = false;
        __amdhistLcDraftsAt2_is_modified = false;
        __amdhistLcDraftsAt3_is_modified = false;
        __amdhistLcDraweeReq_is_modified = false;
        __amdhistLcDraweeType_is_modified = false;
        __amdhistLcDraweeBrnCode_is_modified = false;
        __amdhistLcDraweeBicCode_is_modified = false;
        __amdhistLcDraweeRoutid_is_modified = false;
        __amdhistLcDraweeBnkCode_is_modified = false;
        __amdhistLcDraweeAddr1_is_modified = false;
        __amdhistLcDraweeAddr2_is_modified = false;
        __amdhistLcDraweeAddr3_is_modified = false;
        __amdhistLcDraweeAddr4_is_modified = false;
        __amdhistLcDraweeAddr5_is_modified = false;
        __amdhistDraweeCntryCode_is_modified = false;
        __amdhistLcMixedPayDetails1_is_modified = false;
        __amdhistLcMixedPayDetails2_is_modified = false;
        __amdhistLcMixedPayDetails3_is_modified = false;
        __amdhistLcMixedPayDetails4_is_modified = false;
        __amdhistLcMixedPayDetails5_is_modified = false;
        __amdhistLcDefPayDetails1_is_modified = false;
        __amdhistLcDefPayDetails2_is_modified = false;
        __amdhistLcDefPayDetails3_is_modified = false;
        __amdhistLcDefPayDetails4_is_modified = false;
        __amdhistLcDefPayDetails5_is_modified = false;
        __amdhistLcPartialShipments_is_modified = false;
        __amdhistLcTranshipment_is_modified = false;
        __amdhistLcConfirmationInst_is_modified = false;
        __amdhistLcReimbReq_is_modified = false;
        __amdhistLcReimbType_is_modified = false;
        __amdhistLcReimbBrnCode_is_modified = false;
        __amdhistLcReimbBicCode_is_modified = false;
        __amdhistLcReimbRoutid_is_modified = false;
        __amdhistLcReimbBnkCode_is_modified = false;
        __amdhistLcReimbAddr1_is_modified = false;
        __amdhistLcReimbAddr2_is_modified = false;
        __amdhistLcReimbAddr3_is_modified = false;
        __amdhistLcReimbAddr4_is_modified = false;
        __amdhistLcReimbAddr5_is_modified = false;
        __amdhistLcInstPaying1_is_modified = false;
        __amdhistLcInstPaying2_is_modified = false;
        __amdhistLcInstPaying3_is_modified = false;
        __amdhistLcInstPaying4_is_modified = false;
        __amdhistLcInstPaying5_is_modified = false;
        __amdhistLcInstPaying6_is_modified = false;
        __amdhistLcInstPaying7_is_modified = false;
        __amdhistLcInstPaying8_is_modified = false;
        __amdhistLcInstPaying9_is_modified = false;
        __amdhistLcInstPaying10_is_modified = false;
        __amdhistLcInstPaying11_is_modified = false;
        __amdhistLcInstPaying12_is_modified = false;
        __amdhistLcSecondAdvReq_is_modified = false;
        __amdhistLcSecondAdvType_is_modified = false;
        __amdhistLcSecondAdvBrnCode_is_modified = false;
        __amdhistLcSecondAdvBicCode_is_modified = false;
        __amdhistLcSecondAdvRoutid_is_modified = false;
        __amdhistLcSecondAdvBnkCode_is_modified = false;
        __amdhistLcSecondAdvAddr1_is_modified = false;
        __amdhistLcSecondAdvAddr2_is_modified = false;
        __amdhistLcSecondAdvAddr3_is_modified = false;
        __amdhistLcSecondAdvAddr4_is_modified = false;
        __amdhistLcSecondAdvAddr5_is_modified = false;
        __amdhistLcSecAdvCntrycode_is_modified = false;
        __amendHistLcAvlWithCodetyp_is_modified = false;
        __amendhistLcReimbCntryCode_is_modified = false;
        __amendhistLcCnfAdvType_is_modified = false;
        __amendhistLcCnfAdvBrnCode_is_modified = false;
        __amendhistLcCnfAdvBicCode_is_modified = false;
        __amendhistLcCnfAdvRoutid_is_modified = false;
        __amendhistLcCnfAdvBnkCode_is_modified = false;
        __amendhistLcCnfAdvAddr1_is_modified = false;
        __amendhistLcCnfAdvAddr2_is_modified = false;
        __amendhistLcCnfAdvAddr3_is_modified = false;
        __amendhistLcCnfAdvAddr4_is_modified = false;
        __amendhistLcCnfAdvAddr5_is_modified = false;
        __amendhistLcCnfAdvCntrycode_is_modified = false;
    }
    public AmendDetailsHist() {
        _initialize();
    }

    public void _initialize() {
        _amendhistLcBrnCode = 0 ;
        _amendhistLcType = "" ;
        _amendhistLcYear = 0 ;
        _amendhistLcSerial = 0 ;
        _amendhistLcAmdSl = 0 ;
        _amendhistHistSl = 0 ;
        _amendhistHistDate = null ;
        _amendhistSndrRef = "" ;
        _amendhistRcvrRef = "" ;
        _amendhistDocCrNum = "" ;
        _amendhistIssuingBnkReq = ' ';
        _amendhistIssuingType = ' ';
        _amendhistIssuingBrnCode = "" ;
        _amendhistIssuingBicCode = "" ;
        _amendhistIssuingRoutid = "" ;
        _amendhistIssuingBnkCode = "" ;
        _amendhistIssuingAddr1 = "" ;
        _amendhistIssuingAddr2 = "" ;
        _amendhistIssuingAddr3 = "" ;
        _amendhistIssuingAddr4 = "" ;
        _amendhistIssuingAddr5 = "" ;
        _amendhistNonBnkIssur = "" ;
        _amendhistDateOfIssue = null ;
        _amendhistDateOfAmendmnt = null ;
        _amendhistPurposeOfMsg = ' ';
        _amendhistCancelRequest = "" ;
        _amendhistAdvisingBnkReq = ' ';
        _amendhistAdvisingBnkType = ' ';
        _amendhistAdvisingBrnCode = "" ;
        _amendhistAdvisingBicCode = "" ;
        _amendhistAdvisingRoutid = "" ;
        _amendhistAdvisingBnkCode = "" ;
        _amendhistAdvisingAddr1 = "" ;
        _amendhistAdvisingAddr2 = "" ;
        _amendhistAdvisingAddr3 = "" ;
        _amendhistAdvisingAddr4 = "" ;
        _amendhistAdvisingAddr5 = "" ;
        _amendhistSecondAdvReq = ' ';
        _amendhistSecondAdvType = ' ';
        _amendhistSecondAdvBrnCode = "" ;
        _amendhistSecondAdvBicCode = "" ;
        _amendhistSecondAdvRoutid = "" ;
        _amendhistSecondAdvBnkCode = "" ;
        _amendhistSecondAdvAddr1 = "" ;
        _amendhistSecondAdvAddr2 = "" ;
        _amendhistSecondAdvAddr3 = "" ;
        _amendhistSecondAdvAddr4 = "" ;
        _amendhistSecondAdvAddr5 = "" ;
        _amendhistNewBeneficiary = "" ;
        _amendhistNewDateOfExpiry = null ;
        _amendhistIncrDocCrAmt = 0 ;
        _amendhistDecrDocCrAmt = 0 ;
        _amendhistNewAddnlAmt = 0 ;
        _amendhistPlaceTakinInChrg = "" ;
        _amendhistPortOfLoading = "" ;
        _amendhistPortOfDischarge = "" ;
        _amendhistPlaceOfFinalDest = "" ;
        _amendhistDateOfShipment = null ;
        _amendhistDescGoddSer1 = "" ;
        _amendhistDocReq1 = "" ;
        _amendhistAddCondition1 = "" ;
        _amendhistChrgPayable1 = "" ;
        _amendhistChrgPayable2 = "" ;
        _amendhistChrgPayable3 = "" ;
        _amendhistChrgPayable4 = "" ;
        _amendhistChrgPayable5 = "" ;
        _amendhistChrgPayable6 = "" ;
        _amendhistSndrRecInfo1 = "" ;
        _amendhistSndrRecInfo2 = "" ;
        _amendhistSndrRecInfo3 = "" ;
        _amendhistSndrRecInfo4 = "" ;
        _amendhistSndrRecInfo5 = "" ;
        _amendhistSndrRecInfo6 = "" ;
        _amendhistChkbox = "" ;
        _amendhistIssuingCntry = "" ;
        _amendhistAdvisingCntry = "" ;
        _amendhistSecondAdvCntry = "" ;
        _amendhistIssueRef = "" ;
        _amdhistFormOfDocCredit = 0 ;
        _amdhistLcApplicableRules = 0 ;
        _amdhistLcApplReq = ' ';
        _amdhistLcApplName = "" ;
        _amdhistLcApplAddr1 = "" ;
        _amdhistLcApplAddr2 = "" ;
        _amdhistLcApplAddr3 = "" ;
        _amdhistLcApplAddr4 = "" ;
        _amdhistLcApplAddr5 = "" ;
        _amdhistLcAvlWithType = ' ';
        _amdhistLcAvlWithBrnCode = "" ;
        _amdhistLcAvlWithBicCode = "" ;
        _amdhistLcLcAvlWithRoutid = "" ;
        _amdhistLcAvlWithBnkCode = "" ;
        _amdhistLcAvlWithAddr1 = "" ;
        _amdhistLcAvlWithAddr2 = "" ;
        _amdhistLcAvlWithAddr3 = "" ;
        _amdhistLcAvlWithAddr4 = "" ;
        _amdhistLcAvlWithAddr5 = "" ;
        _amdhistLcAvlWithCntry = "" ;
        _amdhistLcDraftsAt1 = "" ;
        _amdhistLcDraftsAt2 = "" ;
        _amdhistLcDraftsAt3 = "" ;
        _amdhistLcDraweeReq = ' ';
        _amdhistLcDraweeType = ' ';
        _amdhistLcDraweeBrnCode = "" ;
        _amdhistLcDraweeBicCode = "" ;
        _amdhistLcDraweeRoutid = "" ;
        _amdhistLcDraweeBnkCode = "" ;
        _amdhistLcDraweeAddr1 = "" ;
        _amdhistLcDraweeAddr2 = "" ;
        _amdhistLcDraweeAddr3 = "" ;
        _amdhistLcDraweeAddr4 = "" ;
        _amdhistLcDraweeAddr5 = "" ;
        _amdhistDraweeCntryCode = "" ;
        _amdhistLcMixedPayDetails1 = "" ;
        _amdhistLcMixedPayDetails2 = "" ;
        _amdhistLcMixedPayDetails3 = "" ;
        _amdhistLcMixedPayDetails4 = "" ;
        _amdhistLcMixedPayDetails5 = "" ;
        _amdhistLcDefPayDetails1 = "" ;
        _amdhistLcDefPayDetails2 = "" ;
        _amdhistLcDefPayDetails3 = "" ;
        _amdhistLcDefPayDetails4 = "" ;
        _amdhistLcDefPayDetails5 = "" ;
        _amdhistLcPartialShipments = 0 ;
        _amdhistLcTranshipment = 0 ;
        _amdhistLcConfirmationInst = 0 ;
        _amdhistLcReimbReq = ' ';
        _amdhistLcReimbType = ' ';
        _amdhistLcReimbBrnCode = "" ;
        _amdhistLcReimbBicCode = "" ;
        _amdhistLcReimbRoutid = "" ;
        _amdhistLcReimbBnkCode = "" ;
        _amdhistLcReimbAddr1 = "" ;
        _amdhistLcReimbAddr2 = "" ;
        _amdhistLcReimbAddr3 = "" ;
        _amdhistLcReimbAddr4 = "" ;
        _amdhistLcReimbAddr5 = "" ;
        _amdhistLcInstPaying1 = "" ;
        _amdhistLcInstPaying2 = "" ;
        _amdhistLcInstPaying3 = "" ;
        _amdhistLcInstPaying4 = "" ;
        _amdhistLcInstPaying5 = "" ;
        _amdhistLcInstPaying6 = "" ;
        _amdhistLcInstPaying7 = "" ;
        _amdhistLcInstPaying8 = "" ;
        _amdhistLcInstPaying9 = "" ;
        _amdhistLcInstPaying10 = "" ;
        _amdhistLcInstPaying11 = "" ;
        _amdhistLcInstPaying12 = "" ;
        _amdhistLcSecondAdvReq = ' ';
        _amdhistLcSecondAdvType = ' ';
        _amdhistLcSecondAdvBrnCode = "" ;
        _amdhistLcSecondAdvBicCode = "" ;
        _amdhistLcSecondAdvRoutid = "" ;
        _amdhistLcSecondAdvBnkCode = "" ;
        _amdhistLcSecondAdvAddr1 = "" ;
        _amdhistLcSecondAdvAddr2 = "" ;
        _amdhistLcSecondAdvAddr3 = "" ;
        _amdhistLcSecondAdvAddr4 = "" ;
        _amdhistLcSecondAdvAddr5 = "" ;
        _amdhistLcSecAdvCntrycode = "" ;
        _amendHistLcAvlWithCodetyp = ' ';
        _amendhistLcReimbCntryCode = "" ;
        _amendhistLcCnfAdvType = ' ';
        _amendhistLcCnfAdvBrnCode = "" ;
        _amendhistLcCnfAdvBicCode = "" ;
        _amendhistLcCnfAdvRoutid = "" ;
        _amendhistLcCnfAdvBnkCode = "" ;
        _amendhistLcCnfAdvAddr1 = "" ;
        _amendhistLcCnfAdvAddr2 = "" ;
        _amendhistLcCnfAdvAddr3 = "" ;
        _amendhistLcCnfAdvAddr4 = "" ;
        _amendhistLcCnfAdvAddr5 = "" ;
        _amendhistLcCnfAdvCntrycode = "" ;
    }

}
