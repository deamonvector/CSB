package panacea.OLC.Update;

import java.util.Vector;
import java.sql.*;
import panacea.common.JNDINames;
import java.util.LinkedHashMap;
import panacea.Manager.Manager;

/******************SQL2JAVA_IMPORT_BEGIN******************/

/******************SQL2JAVA_IMPORT_END********************/


public class OlcamdManager extends Manager
/******************SQL2JAVA_EXTENDS_BEGIN******************/

/******************SQL2JAVA_EXTENDS_END********************/

{

/******************SQL2JAVA_CLASS_BEGIN******************/

/******************SQL2JAVA_CLASS_END********************/


    public static final int OLCA_BRN_CODE = 0;
    public static final int OLCA_LC_TYPE = 1;
    public static final int OLCA_LC_YEAR = 2;
    public static final int OLCA_LC_SL = 3;
    public static final int OLCA_AMD_SL = 4;
    public static final int OLCA_ENTRY_DATE = 5;
    public static final int OLCA_CUST_LETTER_NUM = 6;
    public static final int OLCA_CUST_LTR_DATE = 7;
    public static final int OLCA_RSN_FOR_AMD = 8;
    public static final int OLCA_CHANGE_OF_BENEF = 9;
    public static final int OLCA_BENEF_CODE = 10;
    public static final int OLCA_BENEF_NAME = 11;
    public static final int OLCA_BENEF_ADDR1 = 12;
    public static final int OLCA_BENEF_ADDR2 = 13;
    public static final int OLCA_BENEF_ADDR3 = 14;
    public static final int OLCA_BENEF_ADDR4 = 15;
    public static final int OLCA_BENEF_ADDR5 = 16;
    public static final int OLCA_BENEF_CNTRY_CODE = 17;
    public static final int OLCA_ENHANCEMNT_REDUCN = 18;
    public static final int OLCA_LC_CURR_CODE = 19;
    public static final int OLCA_AMENDED_AMT = 20;
    public static final int OLCA_POS_DEV_ALLWD = 21;
    public static final int OLCA_NEG_DEV_ALLWD = 22;
    public static final int OLCA_DEV_AMT = 23;
    public static final int OLCA_AMT_QUALFR = 24;
    public static final int OLCA_PRICE_TERMS = 25;
    public static final int OLCA_LAST_DATE_OF_NEG = 26;
    public static final int OLCA_PLACE_OF_EXPIRY = 27;
    public static final int OLCA_LATEST_DATE_OF_SHPMNT = 28;
    public static final int OLCA_WITHIN_VALIDATE_LC = 29;
    public static final int OLCA_LC_UI_BORNE_BY_APPLCNT = 30;
    public static final int OLCA_NOF_TENORS = 31;
    public static final int OLCA_ADD_LIAB_LC_CURR = 32;
    public static final int OLCA_CONV_RATE_BASE_CURR = 33;
    public static final int OLCA_ADD_LIAB_BASE_CURR = 34;
    public static final int OLCA_CONV_RATE_LIM_CURR = 35;
    public static final int OLCA_TOT_LIAB_LIM_CURR = 36;
    public static final int OLCA_TOT_LIAB_LC_CURR = 37;
    public static final int OLCA_TOT_LIAB_BASE_CURR = 38;
    public static final int OLCA_REIMB_CHRGS_BY = 39;
    public static final int OLCA_PERC_RC_PAID_BY_APPLCNT = 40;
    public static final int OLCA_NOSTRO_ALPHA_CODE = 41;
    public static final int OLCA_ADV_THRU_BK = 42;
    public static final int OLCA_ADV_THRU_BRN = 43;
    public static final int OLCA_LC_TO_BE_CNFRMD = 44;
    public static final int OLCA_LC_TO_BE_CNFRMD_BY_BK = 45;
    public static final int OLCA_LC_TO_BE_CNFRMD_BY_BRN = 46;
    public static final int OLCA_RESTRICTED = 47;
    public static final int OLCA_RESTRICTED_TO_US = 48;
    public static final int OLCA_RESTRICTED_BK_CODE = 49;
    public static final int OLCA_RESTRICTED_BRN_CODE = 50;
    public static final int OLCA_CR_AVLBL_BY = 51;
    public static final int OLCA_IRREVOCABLE = 52;
    public static final int OLCA_PART_SHPMNT = 53;
    public static final int OLCA_TRAN_SHPMNT = 54;
    public static final int OLCA_LC_TRANSFRBL = 55;
    public static final int OLCA_DFT_DTLS = 56;
    public static final int OLCA_PERC_DFT_VALUE = 57;
    public static final int OLCA_DFT_TO_BE_DRAWN_ON = 58;
    public static final int OLCA_DFT_ON_BK = 59;
    public static final int OLCA_DFT_ON_BRN = 60;
    public static final int OLCA_SPEC_TEXT1 = 61;
    public static final int OLCA_SPEC_TEXT2 = 62;
    public static final int OLCA_SPEC_TEXT3 = 63;
    public static final int OLCA_SPEC_TEXT4 = 64;
    public static final int OLCA_PRIME_RATE_CLAUSE_REQ = 65;
    public static final int OLCA_SHPMNT_MODE = 66;
    public static final int OLCA_LLOYDS_CLAUSE_REQ = 67;
    public static final int OLCA_MAX_SHIP_AGE = 68;
    public static final int OLCA_SHORT_FORM_OF_BL = 69;
    public static final int OLCA_LASH_TRANS_DOCS_ALLWD = 70;
    public static final int OLCA_PERC_OF_INS_VALUE_CVRD = 71;
    public static final int OLCA_INS_POLICY_NUM = 72;
    public static final int OLCA_INS_DATE = 73;
    public static final int OLCA_INS_CURR = 74;
    public static final int OLCA_INS_AMT = 75;
    public static final int OLCA_PREMIUM_CURR = 76;
    public static final int OLCA_PREMIUM_AMT = 77;
    public static final int OLCA_INS_COMPANY = 78;
    public static final int OLCA_INS_COMPANY_NAME = 79;
    public static final int OLCA_COO_ISS_BY = 80;
    public static final int OLCA_OTHER_COMP_AUTH = 81;
    public static final int OLCA_INTERMEDIARY_TRADE = 82;
    public static final int OLCA_INSP_TEST_CERT_REQ = 83;
    public static final int OLCA_CERT_BY = 84;
    public static final int OLCA_IMP_UNDER = 85;
    public static final int OLCA_IMP_POLICY_DET = 86;
    public static final int OLCA_IMP_REF = 87;
    public static final int OLCA_CONTRA_AMT = 88;
    public static final int OLCA_USANCE_CHARGES = 89;
    public static final int OLCA_USN_CHG_TAKEN_DAYS = 90;
    public static final int OLCA_COMMITMENT_CHARGES = 91;
    public static final int OLCA_COMMIT_CHG_TAKEN_DAYS = 92;
    public static final int TRANCHGS_CHGS_SL = 93;
    public static final int TRANSTLMNT_INV_NUM = 94;
    public static final int POST_TRAN_BRN = 95;
    public static final int POST_TRAN_DATE = 96;
    public static final int POST_TRAN_BATCH_NUM = 97;
    public static final int OLCA_ENTD_BY = 98;
    public static final int OLCA_ENTD_ON = 99;
    public static final int OLCA_LASTMOD_BY = 100;
    public static final int OLCA_LASTMOD_ON = 101;
    public static final int OLCA_AUTH_BY = 102;
    public static final int OLCA_AUTH_ON = 103;
    public static final int OLCA_REJ_BY = 104;
    public static final int OLCA_REJ_ON = 105;
    public static final int OLCA_AMD_CHG_PAY_BY = 106;
    public static final int OLCA_PER_OF_PRES_DAYS = 107;
    public static final int OLCA_CHG_IN_DESC_GOODS = 108;
    public static final int OLCA_CHG_IN_DOC = 109;
    public static final int OLCA_CHG_IN_ADDL_COND = 110;
    public static final int OLCA_REQ_FOR_CANCEL = 111;
    public static final int OLCA_CHG_OF_APPL = 112;
    public static final int OLCA_CHG_IN_AVL_WITH = 113;
    public static final int OLCA_CHG_IN_DRAWEE_PAY = 114;
    public static final int OLCA_CHG_IN_REIMB = 115;
    public static final int OLCA_CHG_IN_ADV_BK = 116;
    public static final int OLCA_CHG_IN_FORM_OF_DC = 117;
    public static final int OLCA_CHG_IN_APPL_RULES = 118;

    private String OldData_Key;
    private String NewData_Key;
    private String DataBlock_Old;
    private String DataBlock_New;
    private LinkedHashMap _COLLECTIONobj;
    private int _Logreq ;
    private int _Logaddreq ;
    public OlcamdManager(LinkedHashMap _COLLECTIONobj, int _Log_Req , int _Log_Add_Req ){
      //  _COLLECTIONobjManager = _COLLECTIONobj;
        this._COLLECTIONobj 	= _COLLECTIONobj;
        this._Logreq 			= _Log_Req;
        this._Logaddreq 		= _Log_Add_Req;
       // set_pki_enabled(_COLLECTIONobj);
    }
    private static final String[] S2J_FIELD_NAMES = {
        "OLCAMD.OLCA_BRN_CODE"
        ,"OLCAMD.OLCA_LC_TYPE"
        ,"OLCAMD.OLCA_LC_YEAR"
        ,"OLCAMD.OLCA_LC_SL"
        ,"OLCAMD.OLCA_AMD_SL"
        ,"OLCAMD.OLCA_ENTRY_DATE"
        ,"OLCAMD.OLCA_CUST_LETTER_NUM"
        ,"OLCAMD.OLCA_CUST_LTR_DATE"
        ,"OLCAMD.OLCA_RSN_FOR_AMD"
        ,"OLCAMD.OLCA_CHANGE_OF_BENEF"
        ,"OLCAMD.OLCA_BENEF_CODE"
        ,"OLCAMD.OLCA_BENEF_NAME"
        ,"OLCAMD.OLCA_BENEF_ADDR1"
        ,"OLCAMD.OLCA_BENEF_ADDR2"
        ,"OLCAMD.OLCA_BENEF_ADDR3"
        ,"OLCAMD.OLCA_BENEF_ADDR4"
        ,"OLCAMD.OLCA_BENEF_ADDR5"
        ,"OLCAMD.OLCA_BENEF_CNTRY_CODE"
        ,"OLCAMD.OLCA_ENHANCEMNT_REDUCN"
        ,"OLCAMD.OLCA_LC_CURR_CODE"
        ,"OLCAMD.OLCA_AMENDED_AMT"
        ,"OLCAMD.OLCA_POS_DEV_ALLWD"
        ,"OLCAMD.OLCA_NEG_DEV_ALLWD"
        ,"OLCAMD.OLCA_DEV_AMT"
        ,"OLCAMD.OLCA_AMT_QUALFR"
        ,"OLCAMD.OLCA_PRICE_TERMS"
        ,"OLCAMD.OLCA_LAST_DATE_OF_NEG"
        ,"OLCAMD.OLCA_PLACE_OF_EXPIRY"
        ,"OLCAMD.OLCA_LATEST_DATE_OF_SHPMNT"
        ,"OLCAMD.OLCA_WITHIN_VALIDATE_LC"
        ,"OLCAMD.OLCA_LC_UI_BORNE_BY_APPLCNT"
        ,"OLCAMD.OLCA_NOF_TENORS"
        ,"OLCAMD.OLCA_ADD_LIAB_LC_CURR"
        ,"OLCAMD.OLCA_CONV_RATE_BASE_CURR"
        ,"OLCAMD.OLCA_ADD_LIAB_BASE_CURR"
        ,"OLCAMD.OLCA_CONV_RATE_LIM_CURR"
        ,"OLCAMD.OLCA_TOT_LIAB_LIM_CURR"
        ,"OLCAMD.OLCA_TOT_LIAB_LC_CURR"
        ,"OLCAMD.OLCA_TOT_LIAB_BASE_CURR"
        ,"OLCAMD.OLCA_REIMB_CHRGS_BY"
        ,"OLCAMD.OLCA_PERC_RC_PAID_BY_APPLCNT"
        ,"OLCAMD.OLCA_NOSTRO_ALPHA_CODE"
        ,"OLCAMD.OLCA_ADV_THRU_BK"
        ,"OLCAMD.OLCA_ADV_THRU_BRN"
        ,"OLCAMD.OLCA_LC_TO_BE_CNFRMD"
        ,"OLCAMD.OLCA_LC_TO_BE_CNFRMD_BY_BK"
        ,"OLCAMD.OLCA_LC_TO_BE_CNFRMD_BY_BRN"
        ,"OLCAMD.OLCA_RESTRICTED"
        ,"OLCAMD.OLCA_RESTRICTED_TO_US"
        ,"OLCAMD.OLCA_RESTRICTED_BK_CODE"
        ,"OLCAMD.OLCA_RESTRICTED_BRN_CODE"
        ,"OLCAMD.OLCA_CR_AVLBL_BY"
        ,"OLCAMD.OLCA_IRREVOCABLE"
        ,"OLCAMD.OLCA_PART_SHPMNT"
        ,"OLCAMD.OLCA_TRAN_SHPMNT"
        ,"OLCAMD.OLCA_LC_TRANSFRBL"
        ,"OLCAMD.OLCA_DFT_DTLS"
        ,"OLCAMD.OLCA_PERC_DFT_VALUE"
        ,"OLCAMD.OLCA_DFT_TO_BE_DRAWN_ON"
        ,"OLCAMD.OLCA_DFT_ON_BK"
        ,"OLCAMD.OLCA_DFT_ON_BRN"
        ,"OLCAMD.OLCA_SPEC_TEXT1"
        ,"OLCAMD.OLCA_SPEC_TEXT2"
        ,"OLCAMD.OLCA_SPEC_TEXT3"
        ,"OLCAMD.OLCA_SPEC_TEXT4"
        ,"OLCAMD.OLCA_PRIME_RATE_CLAUSE_REQ"
        ,"OLCAMD.OLCA_SHPMNT_MODE"
        ,"OLCAMD.OLCA_LLOYDS_CLAUSE_REQ"
        ,"OLCAMD.OLCA_MAX_SHIP_AGE"
        ,"OLCAMD.OLCA_SHORT_FORM_OF_BL"
        ,"OLCAMD.OLCA_LASH_TRANS_DOCS_ALLWD"
        ,"OLCAMD.OLCA_PERC_OF_INS_VALUE_CVRD"
        ,"OLCAMD.OLCA_INS_POLICY_NUM"
        ,"OLCAMD.OLCA_INS_DATE"
        ,"OLCAMD.OLCA_INS_CURR"
        ,"OLCAMD.OLCA_INS_AMT"
        ,"OLCAMD.OLCA_PREMIUM_CURR"
        ,"OLCAMD.OLCA_PREMIUM_AMT"
        ,"OLCAMD.OLCA_INS_COMPANY"
        ,"OLCAMD.OLCA_INS_COMPANY_NAME"
        ,"OLCAMD.OLCA_COO_ISS_BY"
        ,"OLCAMD.OLCA_OTHER_COMP_AUTH"
        ,"OLCAMD.OLCA_INTERMEDIARY_TRADE"
        ,"OLCAMD.OLCA_INSP_TEST_CERT_REQ"
        ,"OLCAMD.OLCA_CERT_BY"
        ,"OLCAMD.OLCA_IMP_UNDER"
        ,"OLCAMD.OLCA_IMP_POLICY_DET"
        ,"OLCAMD.OLCA_IMP_REF"
        ,"OLCAMD.OLCA_CONTRA_AMT"
        ,"OLCAMD.OLCA_USANCE_CHARGES"
        ,"OLCAMD.OLCA_USN_CHG_TAKEN_DAYS"
        ,"OLCAMD.OLCA_COMMITMENT_CHARGES"
        ,"OLCAMD.OLCA_COMMIT_CHG_TAKEN_DAYS"
        ,"OLCAMD.TRANCHGS_CHGS_SL"
        ,"OLCAMD.TRANSTLMNT_INV_NUM"
        ,"OLCAMD.POST_TRAN_BRN"
        ,"OLCAMD.POST_TRAN_DATE"
        ,"OLCAMD.POST_TRAN_BATCH_NUM"
        ,"OLCAMD.OLCA_ENTD_BY"
        ,"OLCAMD.OLCA_ENTD_ON"
        ,"OLCAMD.OLCA_LASTMOD_BY"
        ,"OLCAMD.OLCA_LASTMOD_ON"
        ,"OLCAMD.OLCA_AUTH_BY"
        ,"OLCAMD.OLCA_AUTH_ON"
        ,"OLCAMD.OLCA_REJ_BY"
        ,"OLCAMD.OLCA_REJ_ON"
        ,"OLCAMD.OLCA_AMD_CHG_PAY_BY"
        ,"OLCAMD.OLCA_PER_OF_PRES_DAYS"
        ,"OLCAMD.OLCA_CHG_IN_DESC_GOODS"
        ,"OLCAMD.OLCA_CHG_IN_DOC"
        ,"OLCAMD.OLCA_CHG_IN_ADDL_COND"
        ,"OLCAMD.OLCA_REQ_FOR_CANCEL"
        ,"OLCAMD.OLCA_CHG_OF_APPL"
        ,"OLCAMD.OLCA_CHG_IN_AVL_WITH"
        ,"OLCAMD.OLCA_CHG_IN_DRAWEE_PAY"
        ,"OLCAMD.OLCA_CHG_IN_REIMB"
        ,"OLCAMD.OLCA_CHG_IN_ADV_BK"
        ,"OLCAMD.OLCA_CHG_IN_FORM_OF_DC"
        ,"OLCAMD.OLCA_CHG_IN_APPL_RULES"
    };

    private static final String ALL_FIELDS = "OLCAMD.OLCA_BRN_CODE"
                            + ",OLCAMD.OLCA_LC_TYPE"
                            + ",OLCAMD.OLCA_LC_YEAR"
                            + ",OLCAMD.OLCA_LC_SL"
                            + ",OLCAMD.OLCA_AMD_SL"
                            + ",OLCAMD.OLCA_ENTRY_DATE"
                            + ",OLCAMD.OLCA_CUST_LETTER_NUM"
                            + ",OLCAMD.OLCA_CUST_LTR_DATE"
                            + ",OLCAMD.OLCA_RSN_FOR_AMD"
                            + ",OLCAMD.OLCA_CHANGE_OF_BENEF"
                            + ",OLCAMD.OLCA_BENEF_CODE"
                            + ",OLCAMD.OLCA_BENEF_NAME"
                            + ",OLCAMD.OLCA_BENEF_ADDR1"
                            + ",OLCAMD.OLCA_BENEF_ADDR2"
                            + ",OLCAMD.OLCA_BENEF_ADDR3"
                            + ",OLCAMD.OLCA_BENEF_ADDR4"
                            + ",OLCAMD.OLCA_BENEF_ADDR5"
                            + ",OLCAMD.OLCA_BENEF_CNTRY_CODE"
                            + ",OLCAMD.OLCA_ENHANCEMNT_REDUCN"
                            + ",OLCAMD.OLCA_LC_CURR_CODE"
                            + ",OLCAMD.OLCA_AMENDED_AMT"
                            + ",OLCAMD.OLCA_POS_DEV_ALLWD"
                            + ",OLCAMD.OLCA_NEG_DEV_ALLWD"
                            + ",OLCAMD.OLCA_DEV_AMT"
                            + ",OLCAMD.OLCA_AMT_QUALFR"
                            + ",OLCAMD.OLCA_PRICE_TERMS"
                            + ",OLCAMD.OLCA_LAST_DATE_OF_NEG"
                            + ",OLCAMD.OLCA_PLACE_OF_EXPIRY"
                            + ",OLCAMD.OLCA_LATEST_DATE_OF_SHPMNT"
                            + ",OLCAMD.OLCA_WITHIN_VALIDATE_LC"
                            + ",OLCAMD.OLCA_LC_UI_BORNE_BY_APPLCNT"
                            + ",OLCAMD.OLCA_NOF_TENORS"
                            + ",OLCAMD.OLCA_ADD_LIAB_LC_CURR"
                            + ",OLCAMD.OLCA_CONV_RATE_BASE_CURR"
                            + ",OLCAMD.OLCA_ADD_LIAB_BASE_CURR"
                            + ",OLCAMD.OLCA_CONV_RATE_LIM_CURR"
                            + ",OLCAMD.OLCA_TOT_LIAB_LIM_CURR"
                            + ",OLCAMD.OLCA_TOT_LIAB_LC_CURR"
                            + ",OLCAMD.OLCA_TOT_LIAB_BASE_CURR"
                            + ",OLCAMD.OLCA_REIMB_CHRGS_BY"
                            + ",OLCAMD.OLCA_PERC_RC_PAID_BY_APPLCNT"
                            + ",OLCAMD.OLCA_NOSTRO_ALPHA_CODE"
                            + ",OLCAMD.OLCA_ADV_THRU_BK"
                            + ",OLCAMD.OLCA_ADV_THRU_BRN"
                            + ",OLCAMD.OLCA_LC_TO_BE_CNFRMD"
                            + ",OLCAMD.OLCA_LC_TO_BE_CNFRMD_BY_BK"
                            + ",OLCAMD.OLCA_LC_TO_BE_CNFRMD_BY_BRN"
                            + ",OLCAMD.OLCA_RESTRICTED"
                            + ",OLCAMD.OLCA_RESTRICTED_TO_US"
                            + ",OLCAMD.OLCA_RESTRICTED_BK_CODE"
                            + ",OLCAMD.OLCA_RESTRICTED_BRN_CODE"
                            + ",OLCAMD.OLCA_CR_AVLBL_BY"
                            + ",OLCAMD.OLCA_IRREVOCABLE"
                            + ",OLCAMD.OLCA_PART_SHPMNT"
                            + ",OLCAMD.OLCA_TRAN_SHPMNT"
                            + ",OLCAMD.OLCA_LC_TRANSFRBL"
                            + ",OLCAMD.OLCA_DFT_DTLS"
                            + ",OLCAMD.OLCA_PERC_DFT_VALUE"
                            + ",OLCAMD.OLCA_DFT_TO_BE_DRAWN_ON"
                            + ",OLCAMD.OLCA_DFT_ON_BK"
                            + ",OLCAMD.OLCA_DFT_ON_BRN"
                            + ",OLCAMD.OLCA_SPEC_TEXT1"
                            + ",OLCAMD.OLCA_SPEC_TEXT2"
                            + ",OLCAMD.OLCA_SPEC_TEXT3"
                            + ",OLCAMD.OLCA_SPEC_TEXT4"
                            + ",OLCAMD.OLCA_PRIME_RATE_CLAUSE_REQ"
                            + ",OLCAMD.OLCA_SHPMNT_MODE"
                            + ",OLCAMD.OLCA_LLOYDS_CLAUSE_REQ"
                            + ",OLCAMD.OLCA_MAX_SHIP_AGE"
                            + ",OLCAMD.OLCA_SHORT_FORM_OF_BL"
                            + ",OLCAMD.OLCA_LASH_TRANS_DOCS_ALLWD"
                            + ",OLCAMD.OLCA_PERC_OF_INS_VALUE_CVRD"
                            + ",OLCAMD.OLCA_INS_POLICY_NUM"
                            + ",OLCAMD.OLCA_INS_DATE"
                            + ",OLCAMD.OLCA_INS_CURR"
                            + ",OLCAMD.OLCA_INS_AMT"
                            + ",OLCAMD.OLCA_PREMIUM_CURR"
                            + ",OLCAMD.OLCA_PREMIUM_AMT"
                            + ",OLCAMD.OLCA_INS_COMPANY"
                            + ",OLCAMD.OLCA_INS_COMPANY_NAME"
                            + ",OLCAMD.OLCA_COO_ISS_BY"
                            + ",OLCAMD.OLCA_OTHER_COMP_AUTH"
                            + ",OLCAMD.OLCA_INTERMEDIARY_TRADE"
                            + ",OLCAMD.OLCA_INSP_TEST_CERT_REQ"
                            + ",OLCAMD.OLCA_CERT_BY"
                            + ",OLCAMD.OLCA_IMP_UNDER"
                            + ",OLCAMD.OLCA_IMP_POLICY_DET"
                            + ",OLCAMD.OLCA_IMP_REF"
                            + ",OLCAMD.OLCA_CONTRA_AMT"
                            + ",OLCAMD.OLCA_USANCE_CHARGES"
                            + ",OLCAMD.OLCA_USN_CHG_TAKEN_DAYS"
                            + ",OLCAMD.OLCA_COMMITMENT_CHARGES"
                            + ",OLCAMD.OLCA_COMMIT_CHG_TAKEN_DAYS"
                            + ",OLCAMD.TRANCHGS_CHGS_SL"
                            + ",OLCAMD.TRANSTLMNT_INV_NUM"
                            + ",OLCAMD.POST_TRAN_BRN"
                            + ",OLCAMD.POST_TRAN_DATE"
                            + ",OLCAMD.POST_TRAN_BATCH_NUM"
                            + ",OLCAMD.OLCA_ENTD_BY"
                            + ",OLCAMD.OLCA_ENTD_ON"
                            + ",OLCAMD.OLCA_LASTMOD_BY"
                            + ",OLCAMD.OLCA_LASTMOD_ON"
                            + ",OLCAMD.OLCA_AUTH_BY"
                            + ",OLCAMD.OLCA_AUTH_ON"
                            + ",OLCAMD.OLCA_REJ_BY"
                            + ",OLCAMD.OLCA_REJ_ON"
                            + ",OLCAMD.OLCA_AMD_CHG_PAY_BY"
                            + ",OLCAMD.OLCA_PER_OF_PRES_DAYS"
                            + ",OLCAMD.OLCA_CHG_IN_DESC_GOODS"
                            + ",OLCAMD.OLCA_CHG_IN_DOC"
                            + ",OLCAMD.OLCA_CHG_IN_ADDL_COND"
                            + ",OLCAMD.OLCA_REQ_FOR_CANCEL"
                            + ",OLCAMD.OLCA_CHG_OF_APPL"
                            + ",OLCAMD.OLCA_CHG_IN_AVL_WITH"
                            + ",OLCAMD.OLCA_CHG_IN_DRAWEE_PAY"
                            + ",OLCAMD.OLCA_CHG_IN_REIMB"
                            + ",OLCAMD.OLCA_CHG_IN_ADV_BK"
                            + ",OLCAMD.OLCA_CHG_IN_FORM_OF_DC"
                            + ",OLCAMD.OLCA_CHG_IN_APPL_RULES";

    public Olcamd loadByKey(int _olcaAmdSl, int _olcaBrnCode, int _olcaLcSl, String _olcaLcType, int _olcaLcYear) throws SQLException {
        Connection _conn = null;
        try {
            _conn = openConnection();
            Olcamd _obj = loadByKey(_olcaAmdSl, _olcaBrnCode, _olcaLcSl, _olcaLcType, _olcaLcYear, _conn);
            if ( _obj != null)
            {
            OldData_Key = "OLCAMD" + TableValueSep + OldDataChar + _obj.getOlcaBrnCode() + _obj.getOlcaLcType() + _obj.getOlcaLcYear() + _obj.getOlcaLcSl() + _obj.getOlcaAmdSl();
        DataBlock_Old = _obj.getOlcaBrnCode() + JNDINames.splitchar + _obj.getOlcaLcType() + JNDINames.splitchar + _obj.getOlcaLcYear() + JNDINames.splitchar + _obj.getOlcaLcSl() + JNDINames.splitchar + _obj.getOlcaAmdSl() + JNDINames.splitchar + _obj.getOlcaEntryDate() + JNDINames.splitchar + _obj.getOlcaCustLetterNum() + JNDINames.splitchar + _obj.getOlcaCustLtrDate() + JNDINames.splitchar + _obj.getOlcaRsnForAmd() + JNDINames.splitchar + _obj.getOlcaChangeOfBenef() + JNDINames.splitchar + _obj.getOlcaBenefCode() + JNDINames.splitchar + _obj.getOlcaBenefName() + JNDINames.splitchar + _obj.getOlcaBenefAddr1() + JNDINames.splitchar + _obj.getOlcaBenefAddr2() + JNDINames.splitchar + _obj.getOlcaBenefAddr3() + JNDINames.splitchar + _obj.getOlcaBenefAddr4() + JNDINames.splitchar + _obj.getOlcaBenefAddr5() + JNDINames.splitchar + _obj.getOlcaBenefCntryCode() + JNDINames.splitchar + _obj.getOlcaEnhancemntReducn() + JNDINames.splitchar + _obj.getOlcaLcCurrCode() + JNDINames.splitchar + _obj.getOlcaAmendedAmt() + JNDINames.splitchar + _obj.getOlcaPosDevAllwd() + JNDINames.splitchar + _obj.getOlcaNegDevAllwd() + JNDINames.splitchar + _obj.getOlcaDevAmt() + JNDINames.splitchar + _obj.getOlcaAmtQualfr() + JNDINames.splitchar + _obj.getOlcaPriceTerms() + JNDINames.splitchar + _obj.getOlcaLastDateOfNeg() + JNDINames.splitchar + _obj.getOlcaPlaceOfExpiry() + JNDINames.splitchar + _obj.getOlcaLatestDateOfShpmnt() + JNDINames.splitchar + _obj.getOlcaWithinValidateLc() + JNDINames.splitchar + _obj.getOlcaLcUiBorneByApplcnt() + JNDINames.splitchar + _obj.getOlcaNofTenors() + JNDINames.splitchar + _obj.getOlcaAddLiabLcCurr() + JNDINames.splitchar + _obj.getOlcaConvRateBaseCurr() + JNDINames.splitchar + _obj.getOlcaAddLiabBaseCurr() + JNDINames.splitchar + _obj.getOlcaConvRateLimCurr() + JNDINames.splitchar + _obj.getOlcaTotLiabLimCurr() + JNDINames.splitchar + _obj.getOlcaTotLiabLcCurr() + JNDINames.splitchar + _obj.getOlcaTotLiabBaseCurr() + JNDINames.splitchar + _obj.getOlcaReimbChrgsBy() + JNDINames.splitchar + _obj.getOlcaPercRcPaidByApplcnt() + JNDINames.splitchar + _obj.getOlcaNostroAlphaCode() + JNDINames.splitchar + _obj.getOlcaAdvThruBk() + JNDINames.splitchar + _obj.getOlcaAdvThruBrn() + JNDINames.splitchar + _obj.getOlcaLcToBeCnfrmd() + JNDINames.splitchar + _obj.getOlcaLcToBeCnfrmdByBk() + JNDINames.splitchar + _obj.getOlcaLcToBeCnfrmdByBrn() + JNDINames.splitchar + _obj.getOlcaRestricted() + JNDINames.splitchar + _obj.getOlcaRestrictedToUs() + JNDINames.splitchar + _obj.getOlcaRestrictedBkCode() + JNDINames.splitchar + _obj.getOlcaRestrictedBrnCode() + JNDINames.splitchar + _obj.getOlcaCrAvlblBy() + JNDINames.splitchar + _obj.getOlcaIrrevocable() + JNDINames.splitchar + _obj.getOlcaPartShpmnt() + JNDINames.splitchar + _obj.getOlcaTranShpmnt() + JNDINames.splitchar + _obj.getOlcaLcTransfrbl() + JNDINames.splitchar + _obj.getOlcaDftDtls() + JNDINames.splitchar + _obj.getOlcaPercDftValue() + JNDINames.splitchar + _obj.getOlcaDftToBeDrawnOn() + JNDINames.splitchar + _obj.getOlcaDftOnBk() + JNDINames.splitchar + _obj.getOlcaDftOnBrn() + JNDINames.splitchar + _obj.getOlcaSpecText1() + JNDINames.splitchar + _obj.getOlcaSpecText2() + JNDINames.splitchar + _obj.getOlcaSpecText3() + JNDINames.splitchar + _obj.getOlcaSpecText4() + JNDINames.splitchar + _obj.getOlcaPrimeRateClauseReq() + JNDINames.splitchar + _obj.getOlcaShpmntMode() + JNDINames.splitchar + _obj.getOlcaLloydsClauseReq() + JNDINames.splitchar + _obj.getOlcaMaxShipAge() + JNDINames.splitchar + _obj.getOlcaShortFormOfBl() + JNDINames.splitchar + _obj.getOlcaLashTransDocsAllwd() + JNDINames.splitchar + _obj.getOlcaPercOfInsValueCvrd() + JNDINames.splitchar + _obj.getOlcaInsPolicyNum() + JNDINames.splitchar + _obj.getOlcaInsDate() + JNDINames.splitchar + _obj.getOlcaInsCurr() + JNDINames.splitchar + _obj.getOlcaInsAmt() + JNDINames.splitchar + _obj.getOlcaPremiumCurr() + JNDINames.splitchar + _obj.getOlcaPremiumAmt() + JNDINames.splitchar + _obj.getOlcaInsCompany() + JNDINames.splitchar + _obj.getOlcaInsCompanyName() + JNDINames.splitchar + _obj.getOlcaCooIssBy() + JNDINames.splitchar + _obj.getOlcaOtherCompAuth() + JNDINames.splitchar + _obj.getOlcaIntermediaryTrade() + JNDINames.splitchar + _obj.getOlcaInspTestCertReq() + JNDINames.splitchar + _obj.getOlcaCertBy() + JNDINames.splitchar + _obj.getOlcaImpUnder() + JNDINames.splitchar + _obj.getOlcaImpPolicyDet() + JNDINames.splitchar + _obj.getOlcaImpRef() + JNDINames.splitchar + _obj.getOlcaContraAmt() + JNDINames.splitchar + _obj.getOlcaUsanceCharges() + JNDINames.splitchar + _obj.getOlcaUsnChgTakenDays() + JNDINames.splitchar + _obj.getOlcaCommitmentCharges() + JNDINames.splitchar + _obj.getOlcaCommitChgTakenDays() + JNDINames.splitchar + _obj.getTranchgsChgsSl() + JNDINames.splitchar + _obj.getTranstlmntInvNum() + JNDINames.splitchar + _obj.getPostTranBrn() + JNDINames.splitchar + _obj.getPostTranDate() + JNDINames.splitchar + _obj.getPostTranBatchNum() + JNDINames.splitchar + _obj.getOlcaEntdBy() + JNDINames.splitchar + _obj.getOlcaEntdOn() + JNDINames.splitchar + _obj.getOlcaLastmodBy() + JNDINames.splitchar + _obj.getOlcaLastmodOn() + JNDINames.splitchar + _obj.getOlcaAuthBy() + JNDINames.splitchar + _obj.getOlcaAuthOn() + JNDINames.splitchar + _obj.getOlcaRejBy() + JNDINames.splitchar + _obj.getOlcaRejOn() + JNDINames.splitchar + _obj.getOlcaAmdChgPayBy() + JNDINames.splitchar + _obj.getOlcaPerOfPresDays() + JNDINames.splitchar + _obj.getOlcaChgInDescGoods() + JNDINames.splitchar + _obj.getOlcaChgInDoc() + JNDINames.splitchar + _obj.getOlcaChgInAddlCond() + JNDINames.splitchar + _obj.getOlcaReqForCancel() + JNDINames.splitchar + _obj.getOlcaChgOfAppl() + JNDINames.splitchar + _obj.getOlcaChgInAvlWith() + JNDINames.splitchar + _obj.getOlcaChgInDraweePay() + JNDINames.splitchar + _obj.getOlcaChgInReimb() + JNDINames.splitchar + _obj.getOlcaChgInAdvBk() + JNDINames.splitchar + _obj.getOlcaChgInFormOfDc() + JNDINames.splitchar + _obj.getOlcaChgInApplRules();
        }
            closeConnection(_conn);
            return _obj;
        }
        catch(SQLException e) {
            if(_conn != null)  try { closeConnection(_conn); } catch(SQLException e2) { }
            throw e;
        }
    }

    public Olcamd loadByKey(int _olcaAmdSl, int _olcaBrnCode, int _olcaLcSl, String _olcaLcType, int _olcaLcYear, Connection _conn) throws SQLException {
        PreparedStatement _pstmt = null;
        try {
            _pstmt = _conn.prepareStatement("SELECT " + ALL_FIELDS + " FROM OLCAMD WHERE OLCAMD.OLCA_AMD_SL=? and OLCAMD.OLCA_BRN_CODE=? and OLCAMD.OLCA_LC_SL=? and OLCAMD.OLCA_LC_TYPE=? and OLCAMD.OLCA_LC_YEAR=?");
            _pstmt.setInt(1, _olcaAmdSl);
            _pstmt.setInt(2, _olcaBrnCode);
            _pstmt.setInt(3, _olcaLcSl);
            _pstmt.setString(4, _olcaLcType);
            _pstmt.setInt(5, _olcaLcYear);
            Olcamd _list[] = loadByPreparedStatement(_pstmt);
            _pstmt.close();
            if(_list.length < 1) return null;
            else                 return _list[0];
        }
        catch(SQLException e) {
            if(_pstmt != null) try { _pstmt.close(); } catch(SQLException e2) { }
            throw e;
        }
    }

    public Olcamd[] loadAll() throws SQLException {
        Connection _conn = null;
        try {
            _conn = openConnection();
            Olcamd _list[] = loadAll(_conn);
            closeConnection(_conn);
            return _list;
        }
        catch(SQLException e) {
            if(_conn != null)  try { closeConnection(_conn); } catch(SQLException e2) { }
            throw e;
        }
    }

    public Olcamd[] loadAll(Connection _conn) throws SQLException {
        PreparedStatement _pstmt = null;
        try {
            _pstmt = _conn.prepareStatement("SELECT " + ALL_FIELDS + " FROM OLCAMD");
            Olcamd _list[] = loadByPreparedStatement(_pstmt);
            _pstmt.close();
            return _list;
        }
        catch(SQLException e) {
            if(_pstmt != null) try { _pstmt.close(); } catch(SQLException e2) { }
            throw e;
        }
    }

    public Olcamd[] loadByPreparedStatement(PreparedStatement pstmt) throws SQLException {
        return loadByPreparedStatement(pstmt, null, 0);
    }

    public Olcamd[] loadByPreparedStatement(PreparedStatement pstmt, int maxRows) throws SQLException {
        return loadByPreparedStatement(pstmt, null, maxRows);
    }

    public Olcamd[] loadByPreparedStatement(PreparedStatement pstmt, int[] fieldList) throws SQLException {
        return loadByPreparedStatement(pstmt, fieldList, 0);
    }

    public Olcamd[] loadByPreparedStatement(PreparedStatement pstmt, int[] fieldList, int maxRows) throws SQLException {
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            java.util.Vector v = new java.util.Vector();
            while(rs.next() && (maxRows == 0 || v.size() < maxRows)) {
                if(fieldList == null) v.addElement(decodeRow(rs));
                else v.addElement(decodeRow(rs, fieldList));
            }
            rs.close();
            Olcamd list[] = new Olcamd[v.size()];
            v.copyInto(list);
            return list;
        }
        catch(SQLException e) {
            if(rs!=null) try { rs.close();} catch(Exception e2) {}
            throw e;
        }
    }

    public Olcamd[] loadByWhere(String where) throws SQLException {
        return loadByWhere(where, (int[])null, 0);
    }
    public Olcamd[] loadByWhere(String where, int maxRows) throws SQLException {
        return loadByWhere(where, (int[])null, maxRows);
    }
    public Olcamd[] loadByWhere(String where, int[] fieldList) throws SQLException {
        return loadByWhere(where, fieldList, 0);
    }
    public Olcamd[] loadByWhere(String where, int[] fieldList, int maxRows) throws SQLException {
        Connection conn = null;
        try {
            conn = openConnection();
            Olcamd _list[] = loadByWhere(where, conn, fieldList, maxRows);
            closeConnection(conn);
            return _list;
        }
        catch(SQLException e) {
            if(conn!=null) try { closeConnection(conn);} catch(Exception e2) {}
            throw e;
        }
    }

    public Olcamd[] loadByWhere(String where, Connection conn) throws SQLException {
        return loadByWhere(where, conn, null, 0);
    }

    public Olcamd[] loadByWhere(String where, Connection conn, int[] fieldList) throws SQLException {
        return loadByWhere(where, conn, fieldList, 0);
    }

    public Olcamd[] loadByWhere(String where, Connection conn, int[] fieldList, int maxRows) throws SQLException {
        String sql = null;
        if(fieldList == null) sql = "select " + ALL_FIELDS + " from OLCAMD " + where;
        else {
            StringBuffer buff = new StringBuffer(128);
            buff.append("select ");
            for(int i = 0; i < fieldList.length; i++) {
                if(i != 0) buff.append(",");
                buff.append(S2J_FIELD_NAMES[fieldList[i]]);
            }
            buff.append(" from OLCAMD ");
            buff.append(where);
            sql = buff.toString();
        }
        Statement stmt = null;
        ResultSet rs = null;
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            java.util.Vector v = new java.util.Vector();
            while(rs.next() && (maxRows == 0 || v.size() < maxRows)) {
                if(fieldList == null) v.addElement(decodeRow(rs));
                else v.addElement(decodeRow(rs, fieldList));
            }
            rs.close();
            stmt.close();

            Olcamd _list[] = new Olcamd[v.size()];
            v.copyInto(_list);
            return _list;
        }
        catch(SQLException e) {
            if(rs!=null) try { rs.close();} catch(Exception e2) {}
            if(stmt!=null) try { stmt.close();} catch(Exception e2) {}
            throw e;
        }
    }

    public int UpdateByQuery(String w_sql) throws SQLException {
        Connection _conn = null;
        PreparedStatement _pstmt = null;
            try {
                _conn = openConnection();
                _pstmt = _conn.prepareStatement(w_sql);
                int _rows = _pstmt.executeUpdate();
                closeConnection(_conn);
                return 1;
            }
            catch(SQLException e) {
                if(_pstmt!=null) try { _pstmt.close();} catch(Exception e2) {}
                if(_conn!=null) try { closeConnection(_conn);} catch(Exception e2) {}
                throw e;
            }
    }
    public int deleteByKey(int _olcaAmdSl, int _olcaBrnCode, int _olcaLcSl, String _olcaLcType, int _olcaLcYear) throws SQLException {
        Connection _conn = null;
        try {
            _conn = openConnection();
            int _rows = deleteByKey(_olcaAmdSl, _olcaBrnCode, _olcaLcSl, _olcaLcType, _olcaLcYear, _conn);
            closeConnection(_conn);
            return _rows;
        }
        catch(SQLException e) {
            if(_conn!=null) try { closeConnection(_conn);} catch(Exception e2) {}
            throw e;
        }
    }

    public int deleteByKey(int _olcaAmdSl, int _olcaBrnCode, int _olcaLcSl, String _olcaLcType, int _olcaLcYear, Connection _conn) throws SQLException {
        PreparedStatement _pstmt = null;
        try {
        Olcamd _obj  = loadByKey(_olcaAmdSl, _olcaBrnCode, _olcaLcSl, _olcaLcType, _olcaLcYear);
        _obj  = null;
            _pstmt = _conn.prepareStatement("DELETE FROM OLCAMD WHERE OLCAMD.OLCA_AMD_SL=? and OLCAMD.OLCA_BRN_CODE=? and OLCAMD.OLCA_LC_SL=? and OLCAMD.OLCA_LC_TYPE=? and OLCAMD.OLCA_LC_YEAR=?");
            _pstmt.setInt(1, _olcaAmdSl);
            _pstmt.setInt(2, _olcaBrnCode);
            _pstmt.setInt(3, _olcaLcSl);
            _pstmt.setString(4, _olcaLcType);
            _pstmt.setInt(5, _olcaLcYear);
            int _rows = _pstmt.executeUpdate();
            _pstmt.close();
            return _rows;
        }
        catch(SQLException e) {
            if(_pstmt!=null) try { _pstmt.close();} catch(Exception e2) {}
            throw e;
        }
    }

    public void save(Olcamd obj) throws SQLException {
        //_srcTablePKI = "OLCAMD";
      // _srcKeyPKI = obj.getOlcaBrnCode() + JNDINames.splitchar + obj.getOlcaLcType() + JNDINames.splitchar + obj.getOlcaLcYear() + JNDINames.splitchar + obj.getOlcaLcSl() + JNDINames.splitchar + obj.getOlcaAmdSl();
       // set_pki_values(this._COLLECTIONobj);
        if(!obj.isModifiedS2J()) return;
        Connection _conn = null;
        try {
            _conn = openConnection();
            save(obj, _conn);
            closeConnection(_conn);
        }
        catch(SQLException e) {
            if(_conn!=null) try { closeConnection(_conn);} catch(Exception e2) {}
            throw e;
        }
    }

    public void save(Olcamd obj, Connection _conn) throws SQLException {
        PreparedStatement _pstmt = null;
        try {
            if(obj.isNew()) {
                int _dirtyCount = 0;
                StringBuffer _sql = new StringBuffer("INSERT into OLCAMD (");
                if(obj.olcaBrnCodeIsModifiedS2j()) {  _sql.append("OLCA_BRN_CODE").append(","); _dirtyCount++; }
                if(obj.olcaLcTypeIsModifiedS2j()) {  _sql.append("OLCA_LC_TYPE").append(","); _dirtyCount++; }
                if(obj.olcaLcYearIsModifiedS2j()) {  _sql.append("OLCA_LC_YEAR").append(","); _dirtyCount++; }
                if(obj.olcaLcSlIsModifiedS2j()) {  _sql.append("OLCA_LC_SL").append(","); _dirtyCount++; }
                if(obj.olcaAmdSlIsModifiedS2j()) {  _sql.append("OLCA_AMD_SL").append(","); _dirtyCount++; }
                if(obj.olcaEntryDateIsModifiedS2j()) {  _sql.append("OLCA_ENTRY_DATE").append(","); _dirtyCount++; }
                if(obj.olcaCustLetterNumIsModifiedS2j()) {  _sql.append("OLCA_CUST_LETTER_NUM").append(","); _dirtyCount++; }
                if(obj.olcaCustLtrDateIsModifiedS2j()) {  _sql.append("OLCA_CUST_LTR_DATE").append(","); _dirtyCount++; }
                if(obj.olcaRsnForAmdIsModifiedS2j()) {  _sql.append("OLCA_RSN_FOR_AMD").append(","); _dirtyCount++; }
                if(obj.olcaChangeOfBenefIsModifiedS2j()) {  _sql.append("OLCA_CHANGE_OF_BENEF").append(","); _dirtyCount++; }
                if(obj.olcaBenefCodeIsModifiedS2j()) {  _sql.append("OLCA_BENEF_CODE").append(","); _dirtyCount++; }
                if(obj.olcaBenefNameIsModifiedS2j()) {  _sql.append("OLCA_BENEF_NAME").append(","); _dirtyCount++; }
                if(obj.olcaBenefAddr1IsModifiedS2j()) {  _sql.append("OLCA_BENEF_ADDR1").append(","); _dirtyCount++; }
                if(obj.olcaBenefAddr2IsModifiedS2j()) {  _sql.append("OLCA_BENEF_ADDR2").append(","); _dirtyCount++; }
                if(obj.olcaBenefAddr3IsModifiedS2j()) {  _sql.append("OLCA_BENEF_ADDR3").append(","); _dirtyCount++; }
                if(obj.olcaBenefAddr4IsModifiedS2j()) {  _sql.append("OLCA_BENEF_ADDR4").append(","); _dirtyCount++; }
                if(obj.olcaBenefAddr5IsModifiedS2j()) {  _sql.append("OLCA_BENEF_ADDR5").append(","); _dirtyCount++; }
                if(obj.olcaBenefCntryCodeIsModifiedS2j()) {  _sql.append("OLCA_BENEF_CNTRY_CODE").append(","); _dirtyCount++; }
                if(obj.olcaEnhancemntReducnIsModifiedS2j()) {  _sql.append("OLCA_ENHANCEMNT_REDUCN").append(","); _dirtyCount++; }
                if(obj.olcaLcCurrCodeIsModifiedS2j()) {  _sql.append("OLCA_LC_CURR_CODE").append(","); _dirtyCount++; }
                if(obj.olcaAmendedAmtIsModifiedS2j()) {  _sql.append("OLCA_AMENDED_AMT").append(","); _dirtyCount++; }
                if(obj.olcaPosDevAllwdIsModifiedS2j()) {  _sql.append("OLCA_POS_DEV_ALLWD").append(","); _dirtyCount++; }
                if(obj.olcaNegDevAllwdIsModifiedS2j()) {  _sql.append("OLCA_NEG_DEV_ALLWD").append(","); _dirtyCount++; }
                if(obj.olcaDevAmtIsModifiedS2j()) {  _sql.append("OLCA_DEV_AMT").append(","); _dirtyCount++; }
                if(obj.olcaAmtQualfrIsModifiedS2j()) {  _sql.append("OLCA_AMT_QUALFR").append(","); _dirtyCount++; }
                if(obj.olcaPriceTermsIsModifiedS2j()) {  _sql.append("OLCA_PRICE_TERMS").append(","); _dirtyCount++; }
                if(obj.olcaLastDateOfNegIsModifiedS2j()) {  _sql.append("OLCA_LAST_DATE_OF_NEG").append(","); _dirtyCount++; }
                if(obj.olcaPlaceOfExpiryIsModifiedS2j()) {  _sql.append("OLCA_PLACE_OF_EXPIRY").append(","); _dirtyCount++; }
                if(obj.olcaLatestDateOfShpmntIsModifiedS2j()) {  _sql.append("OLCA_LATEST_DATE_OF_SHPMNT").append(","); _dirtyCount++; }
                if(obj.olcaWithinValidateLcIsModifiedS2j()) {  _sql.append("OLCA_WITHIN_VALIDATE_LC").append(","); _dirtyCount++; }
                if(obj.olcaLcUiBorneByApplcntIsModifiedS2j()) {  _sql.append("OLCA_LC_UI_BORNE_BY_APPLCNT").append(","); _dirtyCount++; }
                if(obj.olcaNofTenorsIsModifiedS2j()) {  _sql.append("OLCA_NOF_TENORS").append(","); _dirtyCount++; }
                if(obj.olcaAddLiabLcCurrIsModifiedS2j()) {  _sql.append("OLCA_ADD_LIAB_LC_CURR").append(","); _dirtyCount++; }
                if(obj.olcaConvRateBaseCurrIsModifiedS2j()) {  _sql.append("OLCA_CONV_RATE_BASE_CURR").append(","); _dirtyCount++; }
                if(obj.olcaAddLiabBaseCurrIsModifiedS2j()) {  _sql.append("OLCA_ADD_LIAB_BASE_CURR").append(","); _dirtyCount++; }
                if(obj.olcaConvRateLimCurrIsModifiedS2j()) {  _sql.append("OLCA_CONV_RATE_LIM_CURR").append(","); _dirtyCount++; }
                if(obj.olcaTotLiabLimCurrIsModifiedS2j()) {  _sql.append("OLCA_TOT_LIAB_LIM_CURR").append(","); _dirtyCount++; }
                if(obj.olcaTotLiabLcCurrIsModifiedS2j()) {  _sql.append("OLCA_TOT_LIAB_LC_CURR").append(","); _dirtyCount++; }
                if(obj.olcaTotLiabBaseCurrIsModifiedS2j()) {  _sql.append("OLCA_TOT_LIAB_BASE_CURR").append(","); _dirtyCount++; }
                if(obj.olcaReimbChrgsByIsModifiedS2j()) {  _sql.append("OLCA_REIMB_CHRGS_BY").append(","); _dirtyCount++; }
                if(obj.olcaPercRcPaidByApplcntIsModifiedS2j()) {  _sql.append("OLCA_PERC_RC_PAID_BY_APPLCNT").append(","); _dirtyCount++; }
                if(obj.olcaNostroAlphaCodeIsModifiedS2j()) {  _sql.append("OLCA_NOSTRO_ALPHA_CODE").append(","); _dirtyCount++; }
                if(obj.olcaAdvThruBkIsModifiedS2j()) {  _sql.append("OLCA_ADV_THRU_BK").append(","); _dirtyCount++; }
                if(obj.olcaAdvThruBrnIsModifiedS2j()) {  _sql.append("OLCA_ADV_THRU_BRN").append(","); _dirtyCount++; }
                if(obj.olcaLcToBeCnfrmdIsModifiedS2j()) {  _sql.append("OLCA_LC_TO_BE_CNFRMD").append(","); _dirtyCount++; }
                if(obj.olcaLcToBeCnfrmdByBkIsModifiedS2j()) {  _sql.append("OLCA_LC_TO_BE_CNFRMD_BY_BK").append(","); _dirtyCount++; }
                if(obj.olcaLcToBeCnfrmdByBrnIsModifiedS2j()) {  _sql.append("OLCA_LC_TO_BE_CNFRMD_BY_BRN").append(","); _dirtyCount++; }
                if(obj.olcaRestrictedIsModifiedS2j()) {  _sql.append("OLCA_RESTRICTED").append(","); _dirtyCount++; }
                if(obj.olcaRestrictedToUsIsModifiedS2j()) {  _sql.append("OLCA_RESTRICTED_TO_US").append(","); _dirtyCount++; }
                if(obj.olcaRestrictedBkCodeIsModifiedS2j()) {  _sql.append("OLCA_RESTRICTED_BK_CODE").append(","); _dirtyCount++; }
                if(obj.olcaRestrictedBrnCodeIsModifiedS2j()) {  _sql.append("OLCA_RESTRICTED_BRN_CODE").append(","); _dirtyCount++; }
                if(obj.olcaCrAvlblByIsModifiedS2j()) {  _sql.append("OLCA_CR_AVLBL_BY").append(","); _dirtyCount++; }
                if(obj.olcaIrrevocableIsModifiedS2j()) {  _sql.append("OLCA_IRREVOCABLE").append(","); _dirtyCount++; }
                if(obj.olcaPartShpmntIsModifiedS2j()) {  _sql.append("OLCA_PART_SHPMNT").append(","); _dirtyCount++; }
                if(obj.olcaTranShpmntIsModifiedS2j()) {  _sql.append("OLCA_TRAN_SHPMNT").append(","); _dirtyCount++; }
                if(obj.olcaLcTransfrblIsModifiedS2j()) {  _sql.append("OLCA_LC_TRANSFRBL").append(","); _dirtyCount++; }
                if(obj.olcaDftDtlsIsModifiedS2j()) {  _sql.append("OLCA_DFT_DTLS").append(","); _dirtyCount++; }
                if(obj.olcaPercDftValueIsModifiedS2j()) {  _sql.append("OLCA_PERC_DFT_VALUE").append(","); _dirtyCount++; }
                if(obj.olcaDftToBeDrawnOnIsModifiedS2j()) {  _sql.append("OLCA_DFT_TO_BE_DRAWN_ON").append(","); _dirtyCount++; }
                if(obj.olcaDftOnBkIsModifiedS2j()) {  _sql.append("OLCA_DFT_ON_BK").append(","); _dirtyCount++; }
                if(obj.olcaDftOnBrnIsModifiedS2j()) {  _sql.append("OLCA_DFT_ON_BRN").append(","); _dirtyCount++; }
                if(obj.olcaSpecText1IsModifiedS2j()) {  _sql.append("OLCA_SPEC_TEXT1").append(","); _dirtyCount++; }
                if(obj.olcaSpecText2IsModifiedS2j()) {  _sql.append("OLCA_SPEC_TEXT2").append(","); _dirtyCount++; }
                if(obj.olcaSpecText3IsModifiedS2j()) {  _sql.append("OLCA_SPEC_TEXT3").append(","); _dirtyCount++; }
                if(obj.olcaSpecText4IsModifiedS2j()) {  _sql.append("OLCA_SPEC_TEXT4").append(","); _dirtyCount++; }
                if(obj.olcaPrimeRateClauseReqIsModifiedS2j()) {  _sql.append("OLCA_PRIME_RATE_CLAUSE_REQ").append(","); _dirtyCount++; }
                if(obj.olcaShpmntModeIsModifiedS2j()) {  _sql.append("OLCA_SHPMNT_MODE").append(","); _dirtyCount++; }
                if(obj.olcaLloydsClauseReqIsModifiedS2j()) {  _sql.append("OLCA_LLOYDS_CLAUSE_REQ").append(","); _dirtyCount++; }
                if(obj.olcaMaxShipAgeIsModifiedS2j()) {  _sql.append("OLCA_MAX_SHIP_AGE").append(","); _dirtyCount++; }
                if(obj.olcaShortFormOfBlIsModifiedS2j()) {  _sql.append("OLCA_SHORT_FORM_OF_BL").append(","); _dirtyCount++; }
                if(obj.olcaLashTransDocsAllwdIsModifiedS2j()) {  _sql.append("OLCA_LASH_TRANS_DOCS_ALLWD").append(","); _dirtyCount++; }
                if(obj.olcaPercOfInsValueCvrdIsModifiedS2j()) {  _sql.append("OLCA_PERC_OF_INS_VALUE_CVRD").append(","); _dirtyCount++; }
                if(obj.olcaInsPolicyNumIsModifiedS2j()) {  _sql.append("OLCA_INS_POLICY_NUM").append(","); _dirtyCount++; }
                if(obj.olcaInsDateIsModifiedS2j()) {  _sql.append("OLCA_INS_DATE").append(","); _dirtyCount++; }
                if(obj.olcaInsCurrIsModifiedS2j()) {  _sql.append("OLCA_INS_CURR").append(","); _dirtyCount++; }
                if(obj.olcaInsAmtIsModifiedS2j()) {  _sql.append("OLCA_INS_AMT").append(","); _dirtyCount++; }
                if(obj.olcaPremiumCurrIsModifiedS2j()) {  _sql.append("OLCA_PREMIUM_CURR").append(","); _dirtyCount++; }
                if(obj.olcaPremiumAmtIsModifiedS2j()) {  _sql.append("OLCA_PREMIUM_AMT").append(","); _dirtyCount++; }
                if(obj.olcaInsCompanyIsModifiedS2j()) {  _sql.append("OLCA_INS_COMPANY").append(","); _dirtyCount++; }
                if(obj.olcaInsCompanyNameIsModifiedS2j()) {  _sql.append("OLCA_INS_COMPANY_NAME").append(","); _dirtyCount++; }
                if(obj.olcaCooIssByIsModifiedS2j()) {  _sql.append("OLCA_COO_ISS_BY").append(","); _dirtyCount++; }
                if(obj.olcaOtherCompAuthIsModifiedS2j()) {  _sql.append("OLCA_OTHER_COMP_AUTH").append(","); _dirtyCount++; }
                if(obj.olcaIntermediaryTradeIsModifiedS2j()) {  _sql.append("OLCA_INTERMEDIARY_TRADE").append(","); _dirtyCount++; }
                if(obj.olcaInspTestCertReqIsModifiedS2j()) {  _sql.append("OLCA_INSP_TEST_CERT_REQ").append(","); _dirtyCount++; }
                if(obj.olcaCertByIsModifiedS2j()) {  _sql.append("OLCA_CERT_BY").append(","); _dirtyCount++; }
                if(obj.olcaImpUnderIsModifiedS2j()) {  _sql.append("OLCA_IMP_UNDER").append(","); _dirtyCount++; }
                if(obj.olcaImpPolicyDetIsModifiedS2j()) {  _sql.append("OLCA_IMP_POLICY_DET").append(","); _dirtyCount++; }
                if(obj.olcaImpRefIsModifiedS2j()) {  _sql.append("OLCA_IMP_REF").append(","); _dirtyCount++; }
                if(obj.olcaContraAmtIsModifiedS2j()) {  _sql.append("OLCA_CONTRA_AMT").append(","); _dirtyCount++; }
                if(obj.olcaUsanceChargesIsModifiedS2j()) {  _sql.append("OLCA_USANCE_CHARGES").append(","); _dirtyCount++; }
                if(obj.olcaUsnChgTakenDaysIsModifiedS2j()) {  _sql.append("OLCA_USN_CHG_TAKEN_DAYS").append(","); _dirtyCount++; }
                if(obj.olcaCommitmentChargesIsModifiedS2j()) {  _sql.append("OLCA_COMMITMENT_CHARGES").append(","); _dirtyCount++; }
                if(obj.olcaCommitChgTakenDaysIsModifiedS2j()) {  _sql.append("OLCA_COMMIT_CHG_TAKEN_DAYS").append(","); _dirtyCount++; }
                if(obj.tranchgsChgsSlIsModifiedS2j()) {  _sql.append("TRANCHGS_CHGS_SL").append(","); _dirtyCount++; }
                if(obj.transtlmntInvNumIsModifiedS2j()) {  _sql.append("TRANSTLMNT_INV_NUM").append(","); _dirtyCount++; }
                if(obj.postTranBrnIsModifiedS2j()) {  _sql.append("POST_TRAN_BRN").append(","); _dirtyCount++; }
                if(obj.postTranDateIsModifiedS2j()) {  _sql.append("POST_TRAN_DATE").append(","); _dirtyCount++; }
                if(obj.postTranBatchNumIsModifiedS2j()) {  _sql.append("POST_TRAN_BATCH_NUM").append(","); _dirtyCount++; }
                if(obj.olcaEntdByIsModifiedS2j()) {  _sql.append("OLCA_ENTD_BY").append(","); _dirtyCount++; }
                if(obj.olcaEntdOnIsModifiedS2j()) {  _sql.append("OLCA_ENTD_ON").append(","); _dirtyCount++; }
                if(obj.olcaLastmodByIsModifiedS2j()) {  _sql.append("OLCA_LASTMOD_BY").append(","); _dirtyCount++; }
                if(obj.olcaLastmodOnIsModifiedS2j()) {  _sql.append("OLCA_LASTMOD_ON").append(","); _dirtyCount++; }
                if(obj.olcaAuthByIsModifiedS2j()) {  _sql.append("OLCA_AUTH_BY").append(","); _dirtyCount++; }
                if(obj.olcaAuthOnIsModifiedS2j()) {  _sql.append("OLCA_AUTH_ON").append(","); _dirtyCount++; }
                if(obj.olcaRejByIsModifiedS2j()) {  _sql.append("OLCA_REJ_BY").append(","); _dirtyCount++; }
                if(obj.olcaRejOnIsModifiedS2j()) {  _sql.append("OLCA_REJ_ON").append(","); _dirtyCount++; }
                if(obj.olcaAmdChgPayByIsModifiedS2j()) {  _sql.append("OLCA_AMD_CHG_PAY_BY").append(","); _dirtyCount++; }
                if(obj.olcaPerOfPresDaysIsModifiedS2j()) {  _sql.append("OLCA_PER_OF_PRES_DAYS").append(","); _dirtyCount++; }
                if(obj.olcaChgInDescGoodsIsModifiedS2j()) {  _sql.append("OLCA_CHG_IN_DESC_GOODS").append(","); _dirtyCount++; }
                if(obj.olcaChgInDocIsModifiedS2j()) {  _sql.append("OLCA_CHG_IN_DOC").append(","); _dirtyCount++; }
                if(obj.olcaChgInAddlCondIsModifiedS2j()) {  _sql.append("OLCA_CHG_IN_ADDL_COND").append(","); _dirtyCount++; }
                if(obj.olcaReqForCancelIsModifiedS2j()) {  _sql.append("OLCA_REQ_FOR_CANCEL").append(","); _dirtyCount++; }
                if(obj.olcaChgOfApplIsModifiedS2j()) {  _sql.append("OLCA_CHG_OF_APPL").append(","); _dirtyCount++; }
                if(obj.olcaChgInAvlWithIsModifiedS2j()) {  _sql.append("OLCA_CHG_IN_AVL_WITH").append(","); _dirtyCount++; }
                if(obj.olcaChgInDraweePayIsModifiedS2j()) {  _sql.append("OLCA_CHG_IN_DRAWEE_PAY").append(","); _dirtyCount++; }
                if(obj.olcaChgInReimbIsModifiedS2j()) {  _sql.append("OLCA_CHG_IN_REIMB").append(","); _dirtyCount++; }
                if(obj.olcaChgInAdvBkIsModifiedS2j()) {  _sql.append("OLCA_CHG_IN_ADV_BK").append(","); _dirtyCount++; }
                if(obj.olcaChgInFormOfDcIsModifiedS2j()) {  _sql.append("OLCA_CHG_IN_FORM_OF_DC").append(","); _dirtyCount++; }
                if(obj.olcaChgInApplRulesIsModifiedS2j()) {  _sql.append("OLCA_CHG_IN_APPL_RULES").append(","); _dirtyCount++; }
                _sql.setLength(_sql.length() - 1);
                _sql.append(") values (" );
                for(int i = 0; i < _dirtyCount; i++) _sql.append("?,");
                _sql.setLength(_sql.length() - 1);
                _sql.append(")");

                _pstmt = _conn.prepareStatement(_sql.toString());
                _dirtyCount = 0;
                if(obj.olcaBrnCodeIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaBrnCode()); } 
                if(obj.olcaLcTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaLcType()); } 
                if(obj.olcaLcYearIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaLcYear()); } 
                if(obj.olcaLcSlIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaLcSl()); } 
                if(obj.olcaAmdSlIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaAmdSl()); } 
                if(obj.olcaEntryDateIsModifiedS2j()) { if (obj.getOlcaEntryDate() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcaEntryDate().getTime()));} } 
                if(obj.olcaCustLetterNumIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaCustLetterNum()); } 
                if(obj.olcaCustLtrDateIsModifiedS2j()) { if (obj.getOlcaCustLtrDate() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcaCustLtrDate().getTime()));} } 
                if(obj.olcaRsnForAmdIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaRsnForAmd())); } 
                if(obj.olcaChangeOfBenefIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaChangeOfBenef())); } 
                if(obj.olcaBenefCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaBenefCode()); } 
                if(obj.olcaBenefNameIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaBenefName()); } 
                if(obj.olcaBenefAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaBenefAddr1()); } 
                if(obj.olcaBenefAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaBenefAddr2()); } 
                if(obj.olcaBenefAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaBenefAddr3()); } 
                if(obj.olcaBenefAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaBenefAddr4()); } 
                if(obj.olcaBenefAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaBenefAddr5()); } 
                if(obj.olcaBenefCntryCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaBenefCntryCode()); } 
                if(obj.olcaEnhancemntReducnIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaEnhancemntReducn())); } 
                if(obj.olcaLcCurrCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaLcCurrCode()); } 
                if(obj.olcaAmendedAmtIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaAmendedAmt()); } 
                if(obj.olcaPosDevAllwdIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaPosDevAllwd()); } 
                if(obj.olcaNegDevAllwdIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaNegDevAllwd()); } 
                if(obj.olcaDevAmtIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaDevAmt()); } 
                if(obj.olcaAmtQualfrIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaAmtQualfr())); } 
                if(obj.olcaPriceTermsIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaPriceTerms()); } 
                if(obj.olcaLastDateOfNegIsModifiedS2j()) { if (obj.getOlcaLastDateOfNeg() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcaLastDateOfNeg().getTime()));} } 
                if(obj.olcaPlaceOfExpiryIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaPlaceOfExpiry()); } 
                if(obj.olcaLatestDateOfShpmntIsModifiedS2j()) { if (obj.getOlcaLatestDateOfShpmnt() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcaLatestDateOfShpmnt().getTime()));} } 
                if(obj.olcaWithinValidateLcIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaWithinValidateLc())); } 
                if(obj.olcaLcUiBorneByApplcntIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaLcUiBorneByApplcnt())); } 
                if(obj.olcaNofTenorsIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaNofTenors()); } 
                if(obj.olcaAddLiabLcCurrIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaAddLiabLcCurr()); } 
                if(obj.olcaConvRateBaseCurrIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaConvRateBaseCurr()); } 
                if(obj.olcaAddLiabBaseCurrIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaAddLiabBaseCurr()); } 
                if(obj.olcaConvRateLimCurrIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaConvRateLimCurr()); } 
                if(obj.olcaTotLiabLimCurrIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaTotLiabLimCurr()); } 
                if(obj.olcaTotLiabLcCurrIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaTotLiabLcCurr()); } 
                if(obj.olcaTotLiabBaseCurrIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaTotLiabBaseCurr()); } 
                if(obj.olcaReimbChrgsByIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaReimbChrgsBy())); } 
                if(obj.olcaPercRcPaidByApplcntIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaPercRcPaidByApplcnt()); } 
                if(obj.olcaNostroAlphaCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaNostroAlphaCode()); } 
                if(obj.olcaAdvThruBkIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaAdvThruBk()); } 
                if(obj.olcaAdvThruBrnIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaAdvThruBrn()); } 
                if(obj.olcaLcToBeCnfrmdIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaLcToBeCnfrmd())); } 
                if(obj.olcaLcToBeCnfrmdByBkIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaLcToBeCnfrmdByBk()); } 
                if(obj.olcaLcToBeCnfrmdByBrnIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaLcToBeCnfrmdByBrn()); } 
                if(obj.olcaRestrictedIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaRestricted())); } 
                if(obj.olcaRestrictedToUsIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaRestrictedToUs())); } 
                if(obj.olcaRestrictedBkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaRestrictedBkCode()); } 
                if(obj.olcaRestrictedBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaRestrictedBrnCode()); } 
                if(obj.olcaCrAvlblByIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaCrAvlblBy())); } 
                if(obj.olcaIrrevocableIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaIrrevocable())); } 
                if(obj.olcaPartShpmntIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaPartShpmnt())); } 
                if(obj.olcaTranShpmntIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaTranShpmnt())); } 
                if(obj.olcaLcTransfrblIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaLcTransfrbl())); } 
                if(obj.olcaDftDtlsIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaDftDtls())); } 
                if(obj.olcaPercDftValueIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaPercDftValue()); } 
                if(obj.olcaDftToBeDrawnOnIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaDftToBeDrawnOn())); } 
                if(obj.olcaDftOnBkIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaDftOnBk()); } 
                if(obj.olcaDftOnBrnIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaDftOnBrn()); } 
                if(obj.olcaSpecText1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaSpecText1()); } 
                if(obj.olcaSpecText2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaSpecText2()); } 
                if(obj.olcaSpecText3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaSpecText3()); } 
                if(obj.olcaSpecText4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaSpecText4()); } 
                if(obj.olcaPrimeRateClauseReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaPrimeRateClauseReq())); } 
                if(obj.olcaShpmntModeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaShpmntMode())); } 
                if(obj.olcaLloydsClauseReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaLloydsClauseReq())); } 
                if(obj.olcaMaxShipAgeIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaMaxShipAge()); } 
                if(obj.olcaShortFormOfBlIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaShortFormOfBl())); } 
                if(obj.olcaLashTransDocsAllwdIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaLashTransDocsAllwd())); } 
                if(obj.olcaPercOfInsValueCvrdIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaPercOfInsValueCvrd()); } 
                if(obj.olcaInsPolicyNumIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaInsPolicyNum()); } 
                if(obj.olcaInsDateIsModifiedS2j()) { if (obj.getOlcaInsDate() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcaInsDate().getTime()));} } 
                if(obj.olcaInsCurrIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaInsCurr()); } 
                if(obj.olcaInsAmtIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaInsAmt()); } 
                if(obj.olcaPremiumCurrIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaPremiumCurr()); } 
                if(obj.olcaPremiumAmtIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaPremiumAmt()); } 
                if(obj.olcaInsCompanyIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaInsCompany()); } 
                if(obj.olcaInsCompanyNameIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaInsCompanyName()); } 
                if(obj.olcaCooIssByIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaCooIssBy()); } 
                if(obj.olcaOtherCompAuthIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaOtherCompAuth()); } 
                if(obj.olcaIntermediaryTradeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaIntermediaryTrade())); } 
                if(obj.olcaInspTestCertReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaInspTestCertReq())); } 
                if(obj.olcaCertByIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaCertBy()); } 
                if(obj.olcaImpUnderIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaImpUnder())); } 
                if(obj.olcaImpPolicyDetIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaImpPolicyDet()); } 
                if(obj.olcaImpRefIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaImpRef()); } 
                if(obj.olcaContraAmtIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaContraAmt()); } 
                if(obj.olcaUsanceChargesIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaUsanceCharges()); } 
                if(obj.olcaUsnChgTakenDaysIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaUsnChgTakenDays()); } 
                if(obj.olcaCommitmentChargesIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaCommitmentCharges()); } 
                if(obj.olcaCommitChgTakenDaysIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaCommitChgTakenDays()); } 
                if(obj.tranchgsChgsSlIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getTranchgsChgsSl()); } 
                if(obj.transtlmntInvNumIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getTranstlmntInvNum()); } 
                if(obj.postTranBrnIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getPostTranBrn()); } 
                if(obj.postTranDateIsModifiedS2j()) { if (obj.getPostTranDate() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getPostTranDate().getTime()));} } 
                if(obj.postTranBatchNumIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getPostTranBatchNum()); } 
                if(obj.olcaEntdByIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaEntdBy()); } 
                if(obj.olcaEntdOnIsModifiedS2j()) { if (obj.getOlcaEntdOn() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcaEntdOn().getTime()));} } 
                if(obj.olcaLastmodByIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaLastmodBy()); } 
                if(obj.olcaLastmodOnIsModifiedS2j()) { if (obj.getOlcaLastmodOn() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcaLastmodOn().getTime()));} } 
                if(obj.olcaAuthByIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaAuthBy()); } 
                if(obj.olcaAuthOnIsModifiedS2j()) { if (obj.getOlcaAuthOn() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcaAuthOn().getTime()));} } 
                if(obj.olcaRejByIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaRejBy()); } 
                if(obj.olcaRejOnIsModifiedS2j()) { if (obj.getOlcaRejOn() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcaRejOn().getTime()));} } 
                if(obj.olcaAmdChgPayByIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaAmdChgPayBy())); } 
                if(obj.olcaPerOfPresDaysIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaPerOfPresDays()); } 
                if(obj.olcaChgInDescGoodsIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaChgInDescGoods())); } 
                if(obj.olcaChgInDocIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaChgInDoc())); } 
                if(obj.olcaChgInAddlCondIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaChgInAddlCond())); } 
                if(obj.olcaReqForCancelIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaReqForCancel())); } 
                if(obj.olcaChgOfApplIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaChgOfAppl())); } 
                if(obj.olcaChgInAvlWithIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaChgInAvlWith())); } 
                if(obj.olcaChgInDraweePayIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaChgInDraweePay())); } 
                if(obj.olcaChgInReimbIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaChgInReimb())); } 
                if(obj.olcaChgInAdvBkIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaChgInAdvBk())); } 
                if(obj.olcaChgInFormOfDcIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaChgInFormOfDc())); } 
                if(obj.olcaChgInApplRulesIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaChgInApplRules())); } 
                _pstmt.executeUpdate();
                obj.setIsNew(false);
                obj.resetIsModifiedS2J();
            }
            else {
                StringBuffer _sql = new StringBuffer("UPDATE OLCAMD SET ");
                if(obj.olcaBrnCodeIsModifiedS2j()) {  _sql.append("OLCA_BRN_CODE").append("=?,"); }
                if(obj.olcaLcTypeIsModifiedS2j()) {  _sql.append("OLCA_LC_TYPE").append("=?,"); }
                if(obj.olcaLcYearIsModifiedS2j()) {  _sql.append("OLCA_LC_YEAR").append("=?,"); }
                if(obj.olcaLcSlIsModifiedS2j()) {  _sql.append("OLCA_LC_SL").append("=?,"); }
                if(obj.olcaAmdSlIsModifiedS2j()) {  _sql.append("OLCA_AMD_SL").append("=?,"); }
                if(obj.olcaEntryDateIsModifiedS2j()) {  _sql.append("OLCA_ENTRY_DATE").append("=?,"); }
                if(obj.olcaCustLetterNumIsModifiedS2j()) {  _sql.append("OLCA_CUST_LETTER_NUM").append("=?,"); }
                if(obj.olcaCustLtrDateIsModifiedS2j()) {  _sql.append("OLCA_CUST_LTR_DATE").append("=?,"); }
                if(obj.olcaRsnForAmdIsModifiedS2j()) {  _sql.append("OLCA_RSN_FOR_AMD").append("=?,"); }
                if(obj.olcaChangeOfBenefIsModifiedS2j()) {  _sql.append("OLCA_CHANGE_OF_BENEF").append("=?,"); }
                if(obj.olcaBenefCodeIsModifiedS2j()) {  _sql.append("OLCA_BENEF_CODE").append("=?,"); }
                if(obj.olcaBenefNameIsModifiedS2j()) {  _sql.append("OLCA_BENEF_NAME").append("=?,"); }
                if(obj.olcaBenefAddr1IsModifiedS2j()) {  _sql.append("OLCA_BENEF_ADDR1").append("=?,"); }
                if(obj.olcaBenefAddr2IsModifiedS2j()) {  _sql.append("OLCA_BENEF_ADDR2").append("=?,"); }
                if(obj.olcaBenefAddr3IsModifiedS2j()) {  _sql.append("OLCA_BENEF_ADDR3").append("=?,"); }
                if(obj.olcaBenefAddr4IsModifiedS2j()) {  _sql.append("OLCA_BENEF_ADDR4").append("=?,"); }
                if(obj.olcaBenefAddr5IsModifiedS2j()) {  _sql.append("OLCA_BENEF_ADDR5").append("=?,"); }
                if(obj.olcaBenefCntryCodeIsModifiedS2j()) {  _sql.append("OLCA_BENEF_CNTRY_CODE").append("=?,"); }
                if(obj.olcaEnhancemntReducnIsModifiedS2j()) {  _sql.append("OLCA_ENHANCEMNT_REDUCN").append("=?,"); }
                if(obj.olcaLcCurrCodeIsModifiedS2j()) {  _sql.append("OLCA_LC_CURR_CODE").append("=?,"); }
                if(obj.olcaAmendedAmtIsModifiedS2j()) {  _sql.append("OLCA_AMENDED_AMT").append("=?,"); }
                if(obj.olcaPosDevAllwdIsModifiedS2j()) {  _sql.append("OLCA_POS_DEV_ALLWD").append("=?,"); }
                if(obj.olcaNegDevAllwdIsModifiedS2j()) {  _sql.append("OLCA_NEG_DEV_ALLWD").append("=?,"); }
                if(obj.olcaDevAmtIsModifiedS2j()) {  _sql.append("OLCA_DEV_AMT").append("=?,"); }
                if(obj.olcaAmtQualfrIsModifiedS2j()) {  _sql.append("OLCA_AMT_QUALFR").append("=?,"); }
                if(obj.olcaPriceTermsIsModifiedS2j()) {  _sql.append("OLCA_PRICE_TERMS").append("=?,"); }
                if(obj.olcaLastDateOfNegIsModifiedS2j()) {  _sql.append("OLCA_LAST_DATE_OF_NEG").append("=?,"); }
                if(obj.olcaPlaceOfExpiryIsModifiedS2j()) {  _sql.append("OLCA_PLACE_OF_EXPIRY").append("=?,"); }
                if(obj.olcaLatestDateOfShpmntIsModifiedS2j()) {  _sql.append("OLCA_LATEST_DATE_OF_SHPMNT").append("=?,"); }
                if(obj.olcaWithinValidateLcIsModifiedS2j()) {  _sql.append("OLCA_WITHIN_VALIDATE_LC").append("=?,"); }
                if(obj.olcaLcUiBorneByApplcntIsModifiedS2j()) {  _sql.append("OLCA_LC_UI_BORNE_BY_APPLCNT").append("=?,"); }
                if(obj.olcaNofTenorsIsModifiedS2j()) {  _sql.append("OLCA_NOF_TENORS").append("=?,"); }
                if(obj.olcaAddLiabLcCurrIsModifiedS2j()) {  _sql.append("OLCA_ADD_LIAB_LC_CURR").append("=?,"); }
                if(obj.olcaConvRateBaseCurrIsModifiedS2j()) {  _sql.append("OLCA_CONV_RATE_BASE_CURR").append("=?,"); }
                if(obj.olcaAddLiabBaseCurrIsModifiedS2j()) {  _sql.append("OLCA_ADD_LIAB_BASE_CURR").append("=?,"); }
                if(obj.olcaConvRateLimCurrIsModifiedS2j()) {  _sql.append("OLCA_CONV_RATE_LIM_CURR").append("=?,"); }
                if(obj.olcaTotLiabLimCurrIsModifiedS2j()) {  _sql.append("OLCA_TOT_LIAB_LIM_CURR").append("=?,"); }
                if(obj.olcaTotLiabLcCurrIsModifiedS2j()) {  _sql.append("OLCA_TOT_LIAB_LC_CURR").append("=?,"); }
                if(obj.olcaTotLiabBaseCurrIsModifiedS2j()) {  _sql.append("OLCA_TOT_LIAB_BASE_CURR").append("=?,"); }
                if(obj.olcaReimbChrgsByIsModifiedS2j()) {  _sql.append("OLCA_REIMB_CHRGS_BY").append("=?,"); }
                if(obj.olcaPercRcPaidByApplcntIsModifiedS2j()) {  _sql.append("OLCA_PERC_RC_PAID_BY_APPLCNT").append("=?,"); }
                if(obj.olcaNostroAlphaCodeIsModifiedS2j()) {  _sql.append("OLCA_NOSTRO_ALPHA_CODE").append("=?,"); }
                if(obj.olcaAdvThruBkIsModifiedS2j()) {  _sql.append("OLCA_ADV_THRU_BK").append("=?,"); }
                if(obj.olcaAdvThruBrnIsModifiedS2j()) {  _sql.append("OLCA_ADV_THRU_BRN").append("=?,"); }
                if(obj.olcaLcToBeCnfrmdIsModifiedS2j()) {  _sql.append("OLCA_LC_TO_BE_CNFRMD").append("=?,"); }
                if(obj.olcaLcToBeCnfrmdByBkIsModifiedS2j()) {  _sql.append("OLCA_LC_TO_BE_CNFRMD_BY_BK").append("=?,"); }
                if(obj.olcaLcToBeCnfrmdByBrnIsModifiedS2j()) {  _sql.append("OLCA_LC_TO_BE_CNFRMD_BY_BRN").append("=?,"); }
                if(obj.olcaRestrictedIsModifiedS2j()) {  _sql.append("OLCA_RESTRICTED").append("=?,"); }
                if(obj.olcaRestrictedToUsIsModifiedS2j()) {  _sql.append("OLCA_RESTRICTED_TO_US").append("=?,"); }
                if(obj.olcaRestrictedBkCodeIsModifiedS2j()) {  _sql.append("OLCA_RESTRICTED_BK_CODE").append("=?,"); }
                if(obj.olcaRestrictedBrnCodeIsModifiedS2j()) {  _sql.append("OLCA_RESTRICTED_BRN_CODE").append("=?,"); }
                if(obj.olcaCrAvlblByIsModifiedS2j()) {  _sql.append("OLCA_CR_AVLBL_BY").append("=?,"); }
                if(obj.olcaIrrevocableIsModifiedS2j()) {  _sql.append("OLCA_IRREVOCABLE").append("=?,"); }
                if(obj.olcaPartShpmntIsModifiedS2j()) {  _sql.append("OLCA_PART_SHPMNT").append("=?,"); }
                if(obj.olcaTranShpmntIsModifiedS2j()) {  _sql.append("OLCA_TRAN_SHPMNT").append("=?,"); }
                if(obj.olcaLcTransfrblIsModifiedS2j()) {  _sql.append("OLCA_LC_TRANSFRBL").append("=?,"); }
                if(obj.olcaDftDtlsIsModifiedS2j()) {  _sql.append("OLCA_DFT_DTLS").append("=?,"); }
                if(obj.olcaPercDftValueIsModifiedS2j()) {  _sql.append("OLCA_PERC_DFT_VALUE").append("=?,"); }
                if(obj.olcaDftToBeDrawnOnIsModifiedS2j()) {  _sql.append("OLCA_DFT_TO_BE_DRAWN_ON").append("=?,"); }
                if(obj.olcaDftOnBkIsModifiedS2j()) {  _sql.append("OLCA_DFT_ON_BK").append("=?,"); }
                if(obj.olcaDftOnBrnIsModifiedS2j()) {  _sql.append("OLCA_DFT_ON_BRN").append("=?,"); }
                if(obj.olcaSpecText1IsModifiedS2j()) {  _sql.append("OLCA_SPEC_TEXT1").append("=?,"); }
                if(obj.olcaSpecText2IsModifiedS2j()) {  _sql.append("OLCA_SPEC_TEXT2").append("=?,"); }
                if(obj.olcaSpecText3IsModifiedS2j()) {  _sql.append("OLCA_SPEC_TEXT3").append("=?,"); }
                if(obj.olcaSpecText4IsModifiedS2j()) {  _sql.append("OLCA_SPEC_TEXT4").append("=?,"); }
                if(obj.olcaPrimeRateClauseReqIsModifiedS2j()) {  _sql.append("OLCA_PRIME_RATE_CLAUSE_REQ").append("=?,"); }
                if(obj.olcaShpmntModeIsModifiedS2j()) {  _sql.append("OLCA_SHPMNT_MODE").append("=?,"); }
                if(obj.olcaLloydsClauseReqIsModifiedS2j()) {  _sql.append("OLCA_LLOYDS_CLAUSE_REQ").append("=?,"); }
                if(obj.olcaMaxShipAgeIsModifiedS2j()) {  _sql.append("OLCA_MAX_SHIP_AGE").append("=?,"); }
                if(obj.olcaShortFormOfBlIsModifiedS2j()) {  _sql.append("OLCA_SHORT_FORM_OF_BL").append("=?,"); }
                if(obj.olcaLashTransDocsAllwdIsModifiedS2j()) {  _sql.append("OLCA_LASH_TRANS_DOCS_ALLWD").append("=?,"); }
                if(obj.olcaPercOfInsValueCvrdIsModifiedS2j()) {  _sql.append("OLCA_PERC_OF_INS_VALUE_CVRD").append("=?,"); }
                if(obj.olcaInsPolicyNumIsModifiedS2j()) {  _sql.append("OLCA_INS_POLICY_NUM").append("=?,"); }
                if(obj.olcaInsDateIsModifiedS2j()) {  _sql.append("OLCA_INS_DATE").append("=?,"); }
                if(obj.olcaInsCurrIsModifiedS2j()) {  _sql.append("OLCA_INS_CURR").append("=?,"); }
                if(obj.olcaInsAmtIsModifiedS2j()) {  _sql.append("OLCA_INS_AMT").append("=?,"); }
                if(obj.olcaPremiumCurrIsModifiedS2j()) {  _sql.append("OLCA_PREMIUM_CURR").append("=?,"); }
                if(obj.olcaPremiumAmtIsModifiedS2j()) {  _sql.append("OLCA_PREMIUM_AMT").append("=?,"); }
                if(obj.olcaInsCompanyIsModifiedS2j()) {  _sql.append("OLCA_INS_COMPANY").append("=?,"); }
                if(obj.olcaInsCompanyNameIsModifiedS2j()) {  _sql.append("OLCA_INS_COMPANY_NAME").append("=?,"); }
                if(obj.olcaCooIssByIsModifiedS2j()) {  _sql.append("OLCA_COO_ISS_BY").append("=?,"); }
                if(obj.olcaOtherCompAuthIsModifiedS2j()) {  _sql.append("OLCA_OTHER_COMP_AUTH").append("=?,"); }
                if(obj.olcaIntermediaryTradeIsModifiedS2j()) {  _sql.append("OLCA_INTERMEDIARY_TRADE").append("=?,"); }
                if(obj.olcaInspTestCertReqIsModifiedS2j()) {  _sql.append("OLCA_INSP_TEST_CERT_REQ").append("=?,"); }
                if(obj.olcaCertByIsModifiedS2j()) {  _sql.append("OLCA_CERT_BY").append("=?,"); }
                if(obj.olcaImpUnderIsModifiedS2j()) {  _sql.append("OLCA_IMP_UNDER").append("=?,"); }
                if(obj.olcaImpPolicyDetIsModifiedS2j()) {  _sql.append("OLCA_IMP_POLICY_DET").append("=?,"); }
                if(obj.olcaImpRefIsModifiedS2j()) {  _sql.append("OLCA_IMP_REF").append("=?,"); }
                if(obj.olcaContraAmtIsModifiedS2j()) {  _sql.append("OLCA_CONTRA_AMT").append("=?,"); }
                if(obj.olcaUsanceChargesIsModifiedS2j()) {  _sql.append("OLCA_USANCE_CHARGES").append("=?,"); }
                if(obj.olcaUsnChgTakenDaysIsModifiedS2j()) {  _sql.append("OLCA_USN_CHG_TAKEN_DAYS").append("=?,"); }
                if(obj.olcaCommitmentChargesIsModifiedS2j()) {  _sql.append("OLCA_COMMITMENT_CHARGES").append("=?,"); }
                if(obj.olcaCommitChgTakenDaysIsModifiedS2j()) {  _sql.append("OLCA_COMMIT_CHG_TAKEN_DAYS").append("=?,"); }
                if(obj.tranchgsChgsSlIsModifiedS2j()) {  _sql.append("TRANCHGS_CHGS_SL").append("=?,"); }
                if(obj.transtlmntInvNumIsModifiedS2j()) {  _sql.append("TRANSTLMNT_INV_NUM").append("=?,"); }
                if(obj.postTranBrnIsModifiedS2j()) {  _sql.append("POST_TRAN_BRN").append("=?,"); }
                if(obj.postTranDateIsModifiedS2j()) {  _sql.append("POST_TRAN_DATE").append("=?,"); }
                if(obj.postTranBatchNumIsModifiedS2j()) {  _sql.append("POST_TRAN_BATCH_NUM").append("=?,"); }
                if(obj.olcaEntdByIsModifiedS2j()) {  _sql.append("OLCA_ENTD_BY").append("=?,"); }
                if(obj.olcaEntdOnIsModifiedS2j()) {  _sql.append("OLCA_ENTD_ON").append("=?,"); }
                if(obj.olcaLastmodByIsModifiedS2j()) {  _sql.append("OLCA_LASTMOD_BY").append("=?,"); }
                if(obj.olcaLastmodOnIsModifiedS2j()) {  _sql.append("OLCA_LASTMOD_ON").append("=?,"); }
                if(obj.olcaAuthByIsModifiedS2j()) {  _sql.append("OLCA_AUTH_BY").append("=?,"); }
                if(obj.olcaAuthOnIsModifiedS2j()) {  _sql.append("OLCA_AUTH_ON").append("=?,"); }
                if(obj.olcaRejByIsModifiedS2j()) {  _sql.append("OLCA_REJ_BY").append("=?,"); }
                if(obj.olcaRejOnIsModifiedS2j()) {  _sql.append("OLCA_REJ_ON").append("=?,"); }
                if(obj.olcaAmdChgPayByIsModifiedS2j()) {  _sql.append("OLCA_AMD_CHG_PAY_BY").append("=?,"); }
                if(obj.olcaPerOfPresDaysIsModifiedS2j()) {  _sql.append("OLCA_PER_OF_PRES_DAYS").append("=?,"); }
                if(obj.olcaChgInDescGoodsIsModifiedS2j()) {  _sql.append("OLCA_CHG_IN_DESC_GOODS").append("=?,"); }
                if(obj.olcaChgInDocIsModifiedS2j()) {  _sql.append("OLCA_CHG_IN_DOC").append("=?,"); }
                if(obj.olcaChgInAddlCondIsModifiedS2j()) {  _sql.append("OLCA_CHG_IN_ADDL_COND").append("=?,"); }
                if(obj.olcaReqForCancelIsModifiedS2j()) {  _sql.append("OLCA_REQ_FOR_CANCEL").append("=?,"); }
                if(obj.olcaChgOfApplIsModifiedS2j()) {  _sql.append("OLCA_CHG_OF_APPL").append("=?,"); }
                if(obj.olcaChgInAvlWithIsModifiedS2j()) {  _sql.append("OLCA_CHG_IN_AVL_WITH").append("=?,"); }
                if(obj.olcaChgInDraweePayIsModifiedS2j()) {  _sql.append("OLCA_CHG_IN_DRAWEE_PAY").append("=?,"); }
                if(obj.olcaChgInReimbIsModifiedS2j()) {  _sql.append("OLCA_CHG_IN_REIMB").append("=?,"); }
                if(obj.olcaChgInAdvBkIsModifiedS2j()) {  _sql.append("OLCA_CHG_IN_ADV_BK").append("=?,"); }
                if(obj.olcaChgInFormOfDcIsModifiedS2j()) {  _sql.append("OLCA_CHG_IN_FORM_OF_DC").append("=?,"); }
                if(obj.olcaChgInApplRulesIsModifiedS2j()) {  _sql.append("OLCA_CHG_IN_APPL_RULES").append("=?,"); }
                _sql.setLength(_sql.length() - 1);
                _sql.append(" WHERE ");
                _sql.append("OLCAMD.OLCA_AMD_SL=? and OLCAMD.OLCA_BRN_CODE=? and OLCAMD.OLCA_LC_SL=? and OLCAMD.OLCA_LC_TYPE=? and OLCAMD.OLCA_LC_YEAR=?");
                _pstmt = _conn.prepareStatement(_sql.toString());
                int _dirtyCount = 0;
                if(obj.olcaBrnCodeIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaBrnCode()); } 
                if(obj.olcaLcTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaLcType()); } 
                if(obj.olcaLcYearIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaLcYear()); } 
                if(obj.olcaLcSlIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaLcSl()); } 
                if(obj.olcaAmdSlIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaAmdSl()); } 
                if(obj.olcaEntryDateIsModifiedS2j()) { if (obj.getOlcaEntryDate() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcaEntryDate().getTime()));} } 
                if(obj.olcaCustLetterNumIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaCustLetterNum()); } 
                if(obj.olcaCustLtrDateIsModifiedS2j()) { if (obj.getOlcaCustLtrDate() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcaCustLtrDate().getTime()));} } 
                if(obj.olcaRsnForAmdIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaRsnForAmd())); } 
                if(obj.olcaChangeOfBenefIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaChangeOfBenef())); } 
                if(obj.olcaBenefCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaBenefCode()); } 
                if(obj.olcaBenefNameIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaBenefName()); } 
                if(obj.olcaBenefAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaBenefAddr1()); } 
                if(obj.olcaBenefAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaBenefAddr2()); } 
                if(obj.olcaBenefAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaBenefAddr3()); } 
                if(obj.olcaBenefAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaBenefAddr4()); } 
                if(obj.olcaBenefAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaBenefAddr5()); } 
                if(obj.olcaBenefCntryCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaBenefCntryCode()); } 
                if(obj.olcaEnhancemntReducnIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaEnhancemntReducn())); } 
                if(obj.olcaLcCurrCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaLcCurrCode()); } 
                if(obj.olcaAmendedAmtIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaAmendedAmt()); } 
                if(obj.olcaPosDevAllwdIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaPosDevAllwd()); } 
                if(obj.olcaNegDevAllwdIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaNegDevAllwd()); } 
                if(obj.olcaDevAmtIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaDevAmt()); } 
                if(obj.olcaAmtQualfrIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaAmtQualfr())); } 
                if(obj.olcaPriceTermsIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaPriceTerms()); } 
                if(obj.olcaLastDateOfNegIsModifiedS2j()) { if (obj.getOlcaLastDateOfNeg() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcaLastDateOfNeg().getTime()));} } 
                if(obj.olcaPlaceOfExpiryIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaPlaceOfExpiry()); } 
                if(obj.olcaLatestDateOfShpmntIsModifiedS2j()) { if (obj.getOlcaLatestDateOfShpmnt() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcaLatestDateOfShpmnt().getTime()));} } 
                if(obj.olcaWithinValidateLcIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaWithinValidateLc())); } 
                if(obj.olcaLcUiBorneByApplcntIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaLcUiBorneByApplcnt())); } 
                if(obj.olcaNofTenorsIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaNofTenors()); } 
                if(obj.olcaAddLiabLcCurrIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaAddLiabLcCurr()); } 
                if(obj.olcaConvRateBaseCurrIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaConvRateBaseCurr()); } 
                if(obj.olcaAddLiabBaseCurrIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaAddLiabBaseCurr()); } 
                if(obj.olcaConvRateLimCurrIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaConvRateLimCurr()); } 
                if(obj.olcaTotLiabLimCurrIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaTotLiabLimCurr()); } 
                if(obj.olcaTotLiabLcCurrIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaTotLiabLcCurr()); } 
                if(obj.olcaTotLiabBaseCurrIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaTotLiabBaseCurr()); } 
                if(obj.olcaReimbChrgsByIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaReimbChrgsBy())); } 
                if(obj.olcaPercRcPaidByApplcntIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaPercRcPaidByApplcnt()); } 
                if(obj.olcaNostroAlphaCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaNostroAlphaCode()); } 
                if(obj.olcaAdvThruBkIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaAdvThruBk()); } 
                if(obj.olcaAdvThruBrnIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaAdvThruBrn()); } 
                if(obj.olcaLcToBeCnfrmdIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaLcToBeCnfrmd())); } 
                if(obj.olcaLcToBeCnfrmdByBkIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaLcToBeCnfrmdByBk()); } 
                if(obj.olcaLcToBeCnfrmdByBrnIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaLcToBeCnfrmdByBrn()); } 
                if(obj.olcaRestrictedIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaRestricted())); } 
                if(obj.olcaRestrictedToUsIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaRestrictedToUs())); } 
                if(obj.olcaRestrictedBkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaRestrictedBkCode()); } 
                if(obj.olcaRestrictedBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaRestrictedBrnCode()); } 
                if(obj.olcaCrAvlblByIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaCrAvlblBy())); } 
                if(obj.olcaIrrevocableIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaIrrevocable())); } 
                if(obj.olcaPartShpmntIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaPartShpmnt())); } 
                if(obj.olcaTranShpmntIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaTranShpmnt())); } 
                if(obj.olcaLcTransfrblIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaLcTransfrbl())); } 
                if(obj.olcaDftDtlsIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaDftDtls())); } 
                if(obj.olcaPercDftValueIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaPercDftValue()); } 
                if(obj.olcaDftToBeDrawnOnIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaDftToBeDrawnOn())); } 
                if(obj.olcaDftOnBkIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaDftOnBk()); } 
                if(obj.olcaDftOnBrnIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaDftOnBrn()); } 
                if(obj.olcaSpecText1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaSpecText1()); } 
                if(obj.olcaSpecText2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaSpecText2()); } 
                if(obj.olcaSpecText3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaSpecText3()); } 
                if(obj.olcaSpecText4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaSpecText4()); } 
                if(obj.olcaPrimeRateClauseReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaPrimeRateClauseReq())); } 
                if(obj.olcaShpmntModeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaShpmntMode())); } 
                if(obj.olcaLloydsClauseReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaLloydsClauseReq())); } 
                if(obj.olcaMaxShipAgeIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaMaxShipAge()); } 
                if(obj.olcaShortFormOfBlIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaShortFormOfBl())); } 
                if(obj.olcaLashTransDocsAllwdIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaLashTransDocsAllwd())); } 
                if(obj.olcaPercOfInsValueCvrdIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaPercOfInsValueCvrd()); } 
                if(obj.olcaInsPolicyNumIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaInsPolicyNum()); } 
                if(obj.olcaInsDateIsModifiedS2j()) { if (obj.getOlcaInsDate() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcaInsDate().getTime()));} } 
                if(obj.olcaInsCurrIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaInsCurr()); } 
                if(obj.olcaInsAmtIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaInsAmt()); } 
                if(obj.olcaPremiumCurrIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaPremiumCurr()); } 
                if(obj.olcaPremiumAmtIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaPremiumAmt()); } 
                if(obj.olcaInsCompanyIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaInsCompany()); } 
                if(obj.olcaInsCompanyNameIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaInsCompanyName()); } 
                if(obj.olcaCooIssByIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaCooIssBy()); } 
                if(obj.olcaOtherCompAuthIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaOtherCompAuth()); } 
                if(obj.olcaIntermediaryTradeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaIntermediaryTrade())); } 
                if(obj.olcaInspTestCertReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaInspTestCertReq())); } 
                if(obj.olcaCertByIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaCertBy()); } 
                if(obj.olcaImpUnderIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaImpUnder())); } 
                if(obj.olcaImpPolicyDetIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaImpPolicyDet()); } 
                if(obj.olcaImpRefIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaImpRef()); } 
                if(obj.olcaContraAmtIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaContraAmt()); } 
                if(obj.olcaUsanceChargesIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaUsanceCharges()); } 
                if(obj.olcaUsnChgTakenDaysIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaUsnChgTakenDays()); } 
                if(obj.olcaCommitmentChargesIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaCommitmentCharges()); } 
                if(obj.olcaCommitChgTakenDaysIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getOlcaCommitChgTakenDays()); } 
                if(obj.tranchgsChgsSlIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getTranchgsChgsSl()); } 
                if(obj.transtlmntInvNumIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getTranstlmntInvNum()); } 
                if(obj.postTranBrnIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getPostTranBrn()); } 
                if(obj.postTranDateIsModifiedS2j()) { if (obj.getPostTranDate() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getPostTranDate().getTime()));} } 
                if(obj.postTranBatchNumIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getPostTranBatchNum()); } 
                if(obj.olcaEntdByIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaEntdBy()); } 
                if(obj.olcaEntdOnIsModifiedS2j()) { if (obj.getOlcaEntdOn() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcaEntdOn().getTime()));} } 
                if(obj.olcaLastmodByIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaLastmodBy()); } 
                if(obj.olcaLastmodOnIsModifiedS2j()) { if (obj.getOlcaLastmodOn() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcaLastmodOn().getTime()));} } 
                if(obj.olcaAuthByIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaAuthBy()); } 
                if(obj.olcaAuthOnIsModifiedS2j()) { if (obj.getOlcaAuthOn() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcaAuthOn().getTime()));} } 
                if(obj.olcaRejByIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaRejBy()); } 
                if(obj.olcaRejOnIsModifiedS2j()) { if (obj.getOlcaRejOn() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getOlcaRejOn().getTime()));} } 
                if(obj.olcaAmdChgPayByIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaAmdChgPayBy())); } 
                if(obj.olcaPerOfPresDaysIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getOlcaPerOfPresDays()); } 
                if(obj.olcaChgInDescGoodsIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaChgInDescGoods())); } 
                if(obj.olcaChgInDocIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaChgInDoc())); } 
                if(obj.olcaChgInAddlCondIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaChgInAddlCond())); } 
                if(obj.olcaReqForCancelIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaReqForCancel())); } 
                if(obj.olcaChgOfApplIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaChgOfAppl())); } 
                if(obj.olcaChgInAvlWithIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaChgInAvlWith())); } 
                if(obj.olcaChgInDraweePayIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaChgInDraweePay())); } 
                if(obj.olcaChgInReimbIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaChgInReimb())); } 
                if(obj.olcaChgInAdvBkIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaChgInAdvBk())); } 
                if(obj.olcaChgInFormOfDcIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaChgInFormOfDc())); } 
                if(obj.olcaChgInApplRulesIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getOlcaChgInApplRules())); } 
                _pstmt.setDouble(++_dirtyCount, obj.getOlcaAmdSl());
                _pstmt.setDouble(++_dirtyCount, obj.getOlcaBrnCode());
                _pstmt.setDouble(++_dirtyCount, obj.getOlcaLcSl());
                _pstmt.setString(++_dirtyCount, obj.getOlcaLcType());
                _pstmt.setDouble(++_dirtyCount, obj.getOlcaLcYear());
                _pstmt.executeUpdate();
                obj.resetIsModifiedS2J();
            }
            _pstmt.close();
        }
        catch(SQLException e) {
            if(_pstmt!=null) try { _pstmt.close();} catch(Exception e2) {}
            throw e;
        }
    }

    private Olcamd decodeRow(ResultSet rs) throws SQLException {
        Olcamd obj = new Olcamd();
        obj.setOlcaBrnCode(rs.getInt(1));
        obj.setOlcaLcType(rs.getString(2));
        obj.setOlcaLcYear(rs.getInt(3));
        obj.setOlcaLcSl(rs.getInt(4));
        obj.setOlcaAmdSl(rs.getInt(5));
        obj.setOlcaEntryDate(rs.getDate(6));
        obj.setOlcaCustLetterNum(rs.getString(7));
        obj.setOlcaCustLtrDate(rs.getDate(8));
        obj.setOlcaRsnForAmd(stringToChar(rs.getString(9)));
        obj.setOlcaChangeOfBenef(stringToChar(rs.getString(10)));
        obj.setOlcaBenefCode(rs.getString(11));
        obj.setOlcaBenefName(rs.getString(12));
        obj.setOlcaBenefAddr1(rs.getString(13));
        obj.setOlcaBenefAddr2(rs.getString(14));
        obj.setOlcaBenefAddr3(rs.getString(15));
        obj.setOlcaBenefAddr4(rs.getString(16));
        obj.setOlcaBenefAddr5(rs.getString(17));
        obj.setOlcaBenefCntryCode(rs.getString(18));
        obj.setOlcaEnhancemntReducn(stringToChar(rs.getString(19)));
        obj.setOlcaLcCurrCode(rs.getString(20));
        obj.setOlcaAmendedAmt(rs.getDouble(21));
        obj.setOlcaPosDevAllwd(rs.getDouble(22));
        obj.setOlcaNegDevAllwd(rs.getDouble(23));
        obj.setOlcaDevAmt(rs.getDouble(24));
        obj.setOlcaAmtQualfr(stringToChar(rs.getString(25)));
        obj.setOlcaPriceTerms(rs.getString(26));
        obj.setOlcaLastDateOfNeg(rs.getDate(27));
        obj.setOlcaPlaceOfExpiry(rs.getString(28));
        obj.setOlcaLatestDateOfShpmnt(rs.getDate(29));
        obj.setOlcaWithinValidateLc(stringToChar(rs.getString(30)));
        obj.setOlcaLcUiBorneByApplcnt(stringToChar(rs.getString(31)));
        obj.setOlcaNofTenors(rs.getInt(32));
        obj.setOlcaAddLiabLcCurr(rs.getDouble(33));
        obj.setOlcaConvRateBaseCurr(rs.getDouble(34));
        obj.setOlcaAddLiabBaseCurr(rs.getDouble(35));
        obj.setOlcaConvRateLimCurr(rs.getDouble(36));
        obj.setOlcaTotLiabLimCurr(rs.getDouble(37));
        obj.setOlcaTotLiabLcCurr(rs.getDouble(38));
        obj.setOlcaTotLiabBaseCurr(rs.getDouble(39));
        obj.setOlcaReimbChrgsBy(stringToChar(rs.getString(40)));
        obj.setOlcaPercRcPaidByApplcnt(rs.getDouble(41));
        obj.setOlcaNostroAlphaCode(rs.getString(42));
        obj.setOlcaAdvThruBk(rs.getString(43));
        obj.setOlcaAdvThruBrn(rs.getString(44));
        obj.setOlcaLcToBeCnfrmd(stringToChar(rs.getString(45)));
        obj.setOlcaLcToBeCnfrmdByBk(rs.getString(46));
        obj.setOlcaLcToBeCnfrmdByBrn(rs.getString(47));
        obj.setOlcaRestricted(stringToChar(rs.getString(48)));
        obj.setOlcaRestrictedToUs(stringToChar(rs.getString(49)));
        obj.setOlcaRestrictedBkCode(rs.getString(50));
        obj.setOlcaRestrictedBrnCode(rs.getString(51));
        obj.setOlcaCrAvlblBy(stringToChar(rs.getString(52)));
        obj.setOlcaIrrevocable(stringToChar(rs.getString(53)));
        obj.setOlcaPartShpmnt(stringToChar(rs.getString(54)));
        obj.setOlcaTranShpmnt(stringToChar(rs.getString(55)));
        obj.setOlcaLcTransfrbl(stringToChar(rs.getString(56)));
        obj.setOlcaDftDtls(stringToChar(rs.getString(57)));
        obj.setOlcaPercDftValue(rs.getDouble(58));
        obj.setOlcaDftToBeDrawnOn(stringToChar(rs.getString(59)));
        obj.setOlcaDftOnBk(rs.getString(60));
        obj.setOlcaDftOnBrn(rs.getString(61));
        obj.setOlcaSpecText1(rs.getString(62));
        obj.setOlcaSpecText2(rs.getString(63));
        obj.setOlcaSpecText3(rs.getString(64));
        obj.setOlcaSpecText4(rs.getString(65));
        obj.setOlcaPrimeRateClauseReq(stringToChar(rs.getString(66)));
        obj.setOlcaShpmntMode(stringToChar(rs.getString(67)));
        obj.setOlcaLloydsClauseReq(stringToChar(rs.getString(68)));
        obj.setOlcaMaxShipAge(rs.getInt(69));
        obj.setOlcaShortFormOfBl(stringToChar(rs.getString(70)));
        obj.setOlcaLashTransDocsAllwd(stringToChar(rs.getString(71)));
        obj.setOlcaPercOfInsValueCvrd(rs.getDouble(72));
        obj.setOlcaInsPolicyNum(rs.getString(73));
        obj.setOlcaInsDate(rs.getDate(74));
        obj.setOlcaInsCurr(rs.getString(75));
        obj.setOlcaInsAmt(rs.getDouble(76));
        obj.setOlcaPremiumCurr(rs.getString(77));
        obj.setOlcaPremiumAmt(rs.getDouble(78));
        obj.setOlcaInsCompany(rs.getString(79));
        obj.setOlcaInsCompanyName(rs.getString(80));
        obj.setOlcaCooIssBy(rs.getString(81));
        obj.setOlcaOtherCompAuth(rs.getString(82));
        obj.setOlcaIntermediaryTrade(stringToChar(rs.getString(83)));
        obj.setOlcaInspTestCertReq(stringToChar(rs.getString(84)));
        obj.setOlcaCertBy(rs.getString(85));
        obj.setOlcaImpUnder(stringToChar(rs.getString(86)));
        obj.setOlcaImpPolicyDet(rs.getString(87));
        obj.setOlcaImpRef(rs.getString(88));
        obj.setOlcaContraAmt(rs.getDouble(89));
        obj.setOlcaUsanceCharges(rs.getDouble(90));
        obj.setOlcaUsnChgTakenDays(rs.getInt(91));
        obj.setOlcaCommitmentCharges(rs.getDouble(92));
        obj.setOlcaCommitChgTakenDays(rs.getInt(93));
        obj.setTranchgsChgsSl(rs.getLong(94));
        obj.setTranstlmntInvNum(rs.getLong(95));
        obj.setPostTranBrn(rs.getInt(96));
        obj.setPostTranDate(rs.getDate(97));
        obj.setPostTranBatchNum(rs.getInt(98));
        obj.setOlcaEntdBy(rs.getString(99));
        obj.setOlcaEntdOn(rs.getTimestamp(100));
        obj.setOlcaLastmodBy(rs.getString(101));
        obj.setOlcaLastmodOn(rs.getDate(102));
        obj.setOlcaAuthBy(rs.getString(103));
        obj.setOlcaAuthOn(rs.getDate(104));
        obj.setOlcaRejBy(rs.getString(105));
        obj.setOlcaRejOn(rs.getDate(106));
        obj.setOlcaAmdChgPayBy(stringToChar(rs.getString(107)));
        obj.setOlcaPerOfPresDays(rs.getString(108));
        obj.setOlcaChgInDescGoods(stringToChar(rs.getString(109)));
        obj.setOlcaChgInDoc(stringToChar(rs.getString(110)));
        obj.setOlcaChgInAddlCond(stringToChar(rs.getString(111)));
        obj.setOlcaReqForCancel(stringToChar(rs.getString(112)));
        obj.setOlcaChgOfAppl(stringToChar(rs.getString(113)));
        obj.setOlcaChgInAvlWith(stringToChar(rs.getString(114)));
        obj.setOlcaChgInDraweePay(stringToChar(rs.getString(115)));
        obj.setOlcaChgInReimb(stringToChar(rs.getString(116)));
        obj.setOlcaChgInAdvBk(stringToChar(rs.getString(117)));
        obj.setOlcaChgInFormOfDc(stringToChar(rs.getString(118)));
        obj.setOlcaChgInApplRules(stringToChar(rs.getString(119)));
        obj.setIsNew(false);
        obj.resetIsModifiedS2J();

        return obj;
    }

    private Olcamd decodeRow(ResultSet rs, int[] fieldList) throws SQLException {
        Olcamd obj = new Olcamd();
        int pos = 0;
        for(int i = 0; i < fieldList.length; i++) {
            switch(fieldList[i]) {
                case OLCA_BRN_CODE: obj.setOlcaBrnCode(rs.getInt(++pos));
                    break;
                case OLCA_LC_TYPE: obj.setOlcaLcType(rs.getString(++pos));
                    break;
                case OLCA_LC_YEAR: obj.setOlcaLcYear(rs.getInt(++pos));
                    break;
                case OLCA_LC_SL: obj.setOlcaLcSl(rs.getInt(++pos));
                    break;
                case OLCA_AMD_SL: obj.setOlcaAmdSl(rs.getInt(++pos));
                    break;
                case OLCA_ENTRY_DATE: obj.setOlcaEntryDate(rs.getDate(++pos));
                    break;
                case OLCA_CUST_LETTER_NUM: obj.setOlcaCustLetterNum(rs.getString(++pos));
                    break;
                case OLCA_CUST_LTR_DATE: obj.setOlcaCustLtrDate(rs.getDate(++pos));
                    break;
                case OLCA_RSN_FOR_AMD: obj.setOlcaRsnForAmd(stringToChar(rs.getString(++pos)));
                    break;
                case OLCA_CHANGE_OF_BENEF: obj.setOlcaChangeOfBenef(stringToChar(rs.getString(++pos)));
                    break;
                case OLCA_BENEF_CODE: obj.setOlcaBenefCode(rs.getString(++pos));
                    break;
                case OLCA_BENEF_NAME: obj.setOlcaBenefName(rs.getString(++pos));
                    break;
                case OLCA_BENEF_ADDR1: obj.setOlcaBenefAddr1(rs.getString(++pos));
                    break;
                case OLCA_BENEF_ADDR2: obj.setOlcaBenefAddr2(rs.getString(++pos));
                    break;
                case OLCA_BENEF_ADDR3: obj.setOlcaBenefAddr3(rs.getString(++pos));
                    break;
                case OLCA_BENEF_ADDR4: obj.setOlcaBenefAddr4(rs.getString(++pos));
                    break;
                case OLCA_BENEF_ADDR5: obj.setOlcaBenefAddr5(rs.getString(++pos));
                    break;
                case OLCA_BENEF_CNTRY_CODE: obj.setOlcaBenefCntryCode(rs.getString(++pos));
                    break;
                case OLCA_ENHANCEMNT_REDUCN: obj.setOlcaEnhancemntReducn(stringToChar(rs.getString(++pos)));
                    break;
                case OLCA_LC_CURR_CODE: obj.setOlcaLcCurrCode(rs.getString(++pos));
                    break;
                case OLCA_AMENDED_AMT: obj.setOlcaAmendedAmt(rs.getDouble(++pos));
                    break;
                case OLCA_POS_DEV_ALLWD: obj.setOlcaPosDevAllwd(rs.getDouble(++pos));
                    break;
                case OLCA_NEG_DEV_ALLWD: obj.setOlcaNegDevAllwd(rs.getDouble(++pos));
                    break;
                case OLCA_DEV_AMT: obj.setOlcaDevAmt(rs.getDouble(++pos));
                    break;
                case OLCA_AMT_QUALFR: obj.setOlcaAmtQualfr(stringToChar(rs.getString(++pos)));
                    break;
                case OLCA_PRICE_TERMS: obj.setOlcaPriceTerms(rs.getString(++pos));
                    break;
                case OLCA_LAST_DATE_OF_NEG: obj.setOlcaLastDateOfNeg(rs.getDate(++pos));
                    break;
                case OLCA_PLACE_OF_EXPIRY: obj.setOlcaPlaceOfExpiry(rs.getString(++pos));
                    break;
                case OLCA_LATEST_DATE_OF_SHPMNT: obj.setOlcaLatestDateOfShpmnt(rs.getDate(++pos));
                    break;
                case OLCA_WITHIN_VALIDATE_LC: obj.setOlcaWithinValidateLc(stringToChar(rs.getString(++pos)));
                    break;
                case OLCA_LC_UI_BORNE_BY_APPLCNT: obj.setOlcaLcUiBorneByApplcnt(stringToChar(rs.getString(++pos)));
                    break;
                case OLCA_NOF_TENORS: obj.setOlcaNofTenors(rs.getInt(++pos));
                    break;
                case OLCA_ADD_LIAB_LC_CURR: obj.setOlcaAddLiabLcCurr(rs.getDouble(++pos));
                    break;
                case OLCA_CONV_RATE_BASE_CURR: obj.setOlcaConvRateBaseCurr(rs.getDouble(++pos));
                    break;
                case OLCA_ADD_LIAB_BASE_CURR: obj.setOlcaAddLiabBaseCurr(rs.getDouble(++pos));
                    break;
                case OLCA_CONV_RATE_LIM_CURR: obj.setOlcaConvRateLimCurr(rs.getDouble(++pos));
                    break;
                case OLCA_TOT_LIAB_LIM_CURR: obj.setOlcaTotLiabLimCurr(rs.getDouble(++pos));
                    break;
                case OLCA_TOT_LIAB_LC_CURR: obj.setOlcaTotLiabLcCurr(rs.getDouble(++pos));
                    break;
                case OLCA_TOT_LIAB_BASE_CURR: obj.setOlcaTotLiabBaseCurr(rs.getDouble(++pos));
                    break;
                case OLCA_REIMB_CHRGS_BY: obj.setOlcaReimbChrgsBy(stringToChar(rs.getString(++pos)));
                    break;
                case OLCA_PERC_RC_PAID_BY_APPLCNT: obj.setOlcaPercRcPaidByApplcnt(rs.getDouble(++pos));
                    break;
                case OLCA_NOSTRO_ALPHA_CODE: obj.setOlcaNostroAlphaCode(rs.getString(++pos));
                    break;
                case OLCA_ADV_THRU_BK: obj.setOlcaAdvThruBk(rs.getString(++pos));
                    break;
                case OLCA_ADV_THRU_BRN: obj.setOlcaAdvThruBrn(rs.getString(++pos));
                    break;
                case OLCA_LC_TO_BE_CNFRMD: obj.setOlcaLcToBeCnfrmd(stringToChar(rs.getString(++pos)));
                    break;
                case OLCA_LC_TO_BE_CNFRMD_BY_BK: obj.setOlcaLcToBeCnfrmdByBk(rs.getString(++pos));
                    break;
                case OLCA_LC_TO_BE_CNFRMD_BY_BRN: obj.setOlcaLcToBeCnfrmdByBrn(rs.getString(++pos));
                    break;
                case OLCA_RESTRICTED: obj.setOlcaRestricted(stringToChar(rs.getString(++pos)));
                    break;
                case OLCA_RESTRICTED_TO_US: obj.setOlcaRestrictedToUs(stringToChar(rs.getString(++pos)));
                    break;
                case OLCA_RESTRICTED_BK_CODE: obj.setOlcaRestrictedBkCode(rs.getString(++pos));
                    break;
                case OLCA_RESTRICTED_BRN_CODE: obj.setOlcaRestrictedBrnCode(rs.getString(++pos));
                    break;
                case OLCA_CR_AVLBL_BY: obj.setOlcaCrAvlblBy(stringToChar(rs.getString(++pos)));
                    break;
                case OLCA_IRREVOCABLE: obj.setOlcaIrrevocable(stringToChar(rs.getString(++pos)));
                    break;
                case OLCA_PART_SHPMNT: obj.setOlcaPartShpmnt(stringToChar(rs.getString(++pos)));
                    break;
                case OLCA_TRAN_SHPMNT: obj.setOlcaTranShpmnt(stringToChar(rs.getString(++pos)));
                    break;
                case OLCA_LC_TRANSFRBL: obj.setOlcaLcTransfrbl(stringToChar(rs.getString(++pos)));
                    break;
                case OLCA_DFT_DTLS: obj.setOlcaDftDtls(stringToChar(rs.getString(++pos)));
                    break;
                case OLCA_PERC_DFT_VALUE: obj.setOlcaPercDftValue(rs.getDouble(++pos));
                    break;
                case OLCA_DFT_TO_BE_DRAWN_ON: obj.setOlcaDftToBeDrawnOn(stringToChar(rs.getString(++pos)));
                    break;
                case OLCA_DFT_ON_BK: obj.setOlcaDftOnBk(rs.getString(++pos));
                    break;
                case OLCA_DFT_ON_BRN: obj.setOlcaDftOnBrn(rs.getString(++pos));
                    break;
                case OLCA_SPEC_TEXT1: obj.setOlcaSpecText1(rs.getString(++pos));
                    break;
                case OLCA_SPEC_TEXT2: obj.setOlcaSpecText2(rs.getString(++pos));
                    break;
                case OLCA_SPEC_TEXT3: obj.setOlcaSpecText3(rs.getString(++pos));
                    break;
                case OLCA_SPEC_TEXT4: obj.setOlcaSpecText4(rs.getString(++pos));
                    break;
                case OLCA_PRIME_RATE_CLAUSE_REQ: obj.setOlcaPrimeRateClauseReq(stringToChar(rs.getString(++pos)));
                    break;
                case OLCA_SHPMNT_MODE: obj.setOlcaShpmntMode(stringToChar(rs.getString(++pos)));
                    break;
                case OLCA_LLOYDS_CLAUSE_REQ: obj.setOlcaLloydsClauseReq(stringToChar(rs.getString(++pos)));
                    break;
                case OLCA_MAX_SHIP_AGE: obj.setOlcaMaxShipAge(rs.getInt(++pos));
                    break;
                case OLCA_SHORT_FORM_OF_BL: obj.setOlcaShortFormOfBl(stringToChar(rs.getString(++pos)));
                    break;
                case OLCA_LASH_TRANS_DOCS_ALLWD: obj.setOlcaLashTransDocsAllwd(stringToChar(rs.getString(++pos)));
                    break;
                case OLCA_PERC_OF_INS_VALUE_CVRD: obj.setOlcaPercOfInsValueCvrd(rs.getDouble(++pos));
                    break;
                case OLCA_INS_POLICY_NUM: obj.setOlcaInsPolicyNum(rs.getString(++pos));
                    break;
                case OLCA_INS_DATE: obj.setOlcaInsDate(rs.getDate(++pos));
                    break;
                case OLCA_INS_CURR: obj.setOlcaInsCurr(rs.getString(++pos));
                    break;
                case OLCA_INS_AMT: obj.setOlcaInsAmt(rs.getDouble(++pos));
                    break;
                case OLCA_PREMIUM_CURR: obj.setOlcaPremiumCurr(rs.getString(++pos));
                    break;
                case OLCA_PREMIUM_AMT: obj.setOlcaPremiumAmt(rs.getDouble(++pos));
                    break;
                case OLCA_INS_COMPANY: obj.setOlcaInsCompany(rs.getString(++pos));
                    break;
                case OLCA_INS_COMPANY_NAME: obj.setOlcaInsCompanyName(rs.getString(++pos));
                    break;
                case OLCA_COO_ISS_BY: obj.setOlcaCooIssBy(rs.getString(++pos));
                    break;
                case OLCA_OTHER_COMP_AUTH: obj.setOlcaOtherCompAuth(rs.getString(++pos));
                    break;
                case OLCA_INTERMEDIARY_TRADE: obj.setOlcaIntermediaryTrade(stringToChar(rs.getString(++pos)));
                    break;
                case OLCA_INSP_TEST_CERT_REQ: obj.setOlcaInspTestCertReq(stringToChar(rs.getString(++pos)));
                    break;
                case OLCA_CERT_BY: obj.setOlcaCertBy(rs.getString(++pos));
                    break;
                case OLCA_IMP_UNDER: obj.setOlcaImpUnder(stringToChar(rs.getString(++pos)));
                    break;
                case OLCA_IMP_POLICY_DET: obj.setOlcaImpPolicyDet(rs.getString(++pos));
                    break;
                case OLCA_IMP_REF: obj.setOlcaImpRef(rs.getString(++pos));
                    break;
                case OLCA_CONTRA_AMT: obj.setOlcaContraAmt(rs.getDouble(++pos));
                    break;
                case OLCA_USANCE_CHARGES: obj.setOlcaUsanceCharges(rs.getDouble(++pos));
                    break;
                case OLCA_USN_CHG_TAKEN_DAYS: obj.setOlcaUsnChgTakenDays(rs.getInt(++pos));
                    break;
                case OLCA_COMMITMENT_CHARGES: obj.setOlcaCommitmentCharges(rs.getDouble(++pos));
                    break;
                case OLCA_COMMIT_CHG_TAKEN_DAYS: obj.setOlcaCommitChgTakenDays(rs.getInt(++pos));
                    break;
                case TRANCHGS_CHGS_SL: obj.setTranchgsChgsSl(rs.getLong(++pos));
                    break;
                case TRANSTLMNT_INV_NUM: obj.setTranstlmntInvNum(rs.getLong(++pos));
                    break;
                case POST_TRAN_BRN: obj.setPostTranBrn(rs.getInt(++pos));
                    break;
                case POST_TRAN_DATE: obj.setPostTranDate(rs.getDate(++pos));
                    break;
                case POST_TRAN_BATCH_NUM: obj.setPostTranBatchNum(rs.getInt(++pos));
                    break;
                case OLCA_ENTD_BY: obj.setOlcaEntdBy(rs.getString(++pos));
                    break;
                case OLCA_ENTD_ON: obj.setOlcaEntdOn(rs.getTimestamp(++pos));
                    break;
                case OLCA_LASTMOD_BY: obj.setOlcaLastmodBy(rs.getString(++pos));
                    break;
                case OLCA_LASTMOD_ON: obj.setOlcaLastmodOn(rs.getDate(++pos));
                    break;
                case OLCA_AUTH_BY: obj.setOlcaAuthBy(rs.getString(++pos));
                    break;
                case OLCA_AUTH_ON: obj.setOlcaAuthOn(rs.getDate(++pos));
                    break;
                case OLCA_REJ_BY: obj.setOlcaRejBy(rs.getString(++pos));
                    break;
                case OLCA_REJ_ON: obj.setOlcaRejOn(rs.getDate(++pos));
                    break;
                case OLCA_AMD_CHG_PAY_BY: obj.setOlcaAmdChgPayBy(stringToChar(rs.getString(++pos)));
                    break;
                case OLCA_PER_OF_PRES_DAYS: obj.setOlcaPerOfPresDays(rs.getString(++pos));
                    break;
                case OLCA_CHG_IN_DESC_GOODS: obj.setOlcaChgInDescGoods(stringToChar(rs.getString(++pos)));
                    break;
                case OLCA_CHG_IN_DOC: obj.setOlcaChgInDoc(stringToChar(rs.getString(++pos)));
                    break;
                case OLCA_CHG_IN_ADDL_COND: obj.setOlcaChgInAddlCond(stringToChar(rs.getString(++pos)));
                    break;
                case OLCA_REQ_FOR_CANCEL: obj.setOlcaReqForCancel(stringToChar(rs.getString(++pos)));
                    break;
                case OLCA_CHG_OF_APPL: obj.setOlcaChgOfAppl(stringToChar(rs.getString(++pos)));
                    break;
                case OLCA_CHG_IN_AVL_WITH: obj.setOlcaChgInAvlWith(stringToChar(rs.getString(++pos)));
                    break;
                case OLCA_CHG_IN_DRAWEE_PAY: obj.setOlcaChgInDraweePay(stringToChar(rs.getString(++pos)));
                    break;
                case OLCA_CHG_IN_REIMB: obj.setOlcaChgInReimb(stringToChar(rs.getString(++pos)));
                    break;
                case OLCA_CHG_IN_ADV_BK: obj.setOlcaChgInAdvBk(stringToChar(rs.getString(++pos)));
                    break;
                case OLCA_CHG_IN_FORM_OF_DC: obj.setOlcaChgInFormOfDc(stringToChar(rs.getString(++pos)));
                    break;
                case OLCA_CHG_IN_APPL_RULES: obj.setOlcaChgInApplRules(stringToChar(rs.getString(++pos)));
                    break;
            }
        }
        obj.setIsNew(false);
        obj.resetIsModifiedS2J();

        return obj;
    }
    public void save(Olcamd obj, String tba_main_key, Timestamp tba_entry_date, long tab_dtl_sl ) throws SQLException {
            NewData_Key = "OLCAMD" + TableValueSep + NewDataChar + obj.getOlcaBrnCode() + obj.getOlcaLcType() + obj.getOlcaLcYear() + obj.getOlcaLcSl() + obj.getOlcaAmdSl();
            DataBlock_New = obj.getOlcaBrnCode() + JNDINames.splitchar + obj.getOlcaLcType() + JNDINames.splitchar + obj.getOlcaLcYear() + JNDINames.splitchar + obj.getOlcaLcSl() + JNDINames.splitchar + obj.getOlcaAmdSl() + JNDINames.splitchar + obj.getOlcaEntryDate() + JNDINames.splitchar + obj.getOlcaCustLetterNum() + JNDINames.splitchar + obj.getOlcaCustLtrDate() + JNDINames.splitchar + obj.getOlcaRsnForAmd() + JNDINames.splitchar + obj.getOlcaChangeOfBenef() + JNDINames.splitchar + obj.getOlcaBenefCode() + JNDINames.splitchar + obj.getOlcaBenefName() + JNDINames.splitchar + obj.getOlcaBenefAddr1() + JNDINames.splitchar + obj.getOlcaBenefAddr2() + JNDINames.splitchar + obj.getOlcaBenefAddr3() + JNDINames.splitchar + obj.getOlcaBenefAddr4() + JNDINames.splitchar + obj.getOlcaBenefAddr5() + JNDINames.splitchar + obj.getOlcaBenefCntryCode() + JNDINames.splitchar + obj.getOlcaEnhancemntReducn() + JNDINames.splitchar + obj.getOlcaLcCurrCode() + JNDINames.splitchar + obj.getOlcaAmendedAmt() + JNDINames.splitchar + obj.getOlcaPosDevAllwd() + JNDINames.splitchar + obj.getOlcaNegDevAllwd() + JNDINames.splitchar + obj.getOlcaDevAmt() + JNDINames.splitchar + obj.getOlcaAmtQualfr() + JNDINames.splitchar + obj.getOlcaPriceTerms() + JNDINames.splitchar + obj.getOlcaLastDateOfNeg() + JNDINames.splitchar + obj.getOlcaPlaceOfExpiry() + JNDINames.splitchar + obj.getOlcaLatestDateOfShpmnt() + JNDINames.splitchar + obj.getOlcaWithinValidateLc() + JNDINames.splitchar + obj.getOlcaLcUiBorneByApplcnt() + JNDINames.splitchar + obj.getOlcaNofTenors() + JNDINames.splitchar + obj.getOlcaAddLiabLcCurr() + JNDINames.splitchar + obj.getOlcaConvRateBaseCurr() + JNDINames.splitchar + obj.getOlcaAddLiabBaseCurr() + JNDINames.splitchar + obj.getOlcaConvRateLimCurr() + JNDINames.splitchar + obj.getOlcaTotLiabLimCurr() + JNDINames.splitchar + obj.getOlcaTotLiabLcCurr() + JNDINames.splitchar + obj.getOlcaTotLiabBaseCurr() + JNDINames.splitchar + obj.getOlcaReimbChrgsBy() + JNDINames.splitchar + obj.getOlcaPercRcPaidByApplcnt() + JNDINames.splitchar + obj.getOlcaNostroAlphaCode() + JNDINames.splitchar + obj.getOlcaAdvThruBk() + JNDINames.splitchar + obj.getOlcaAdvThruBrn() + JNDINames.splitchar + obj.getOlcaLcToBeCnfrmd() + JNDINames.splitchar + obj.getOlcaLcToBeCnfrmdByBk() + JNDINames.splitchar + obj.getOlcaLcToBeCnfrmdByBrn() + JNDINames.splitchar + obj.getOlcaRestricted() + JNDINames.splitchar + obj.getOlcaRestrictedToUs() + JNDINames.splitchar + obj.getOlcaRestrictedBkCode() + JNDINames.splitchar + obj.getOlcaRestrictedBrnCode() + JNDINames.splitchar + obj.getOlcaCrAvlblBy() + JNDINames.splitchar + obj.getOlcaIrrevocable() + JNDINames.splitchar + obj.getOlcaPartShpmnt() + JNDINames.splitchar + obj.getOlcaTranShpmnt() + JNDINames.splitchar + obj.getOlcaLcTransfrbl() + JNDINames.splitchar + obj.getOlcaDftDtls() + JNDINames.splitchar + obj.getOlcaPercDftValue() + JNDINames.splitchar + obj.getOlcaDftToBeDrawnOn() + JNDINames.splitchar + obj.getOlcaDftOnBk() + JNDINames.splitchar + obj.getOlcaDftOnBrn() + JNDINames.splitchar + obj.getOlcaSpecText1() + JNDINames.splitchar + obj.getOlcaSpecText2() + JNDINames.splitchar + obj.getOlcaSpecText3() + JNDINames.splitchar + obj.getOlcaSpecText4() + JNDINames.splitchar + obj.getOlcaPrimeRateClauseReq() + JNDINames.splitchar + obj.getOlcaShpmntMode() + JNDINames.splitchar + obj.getOlcaLloydsClauseReq() + JNDINames.splitchar + obj.getOlcaMaxShipAge() + JNDINames.splitchar + obj.getOlcaShortFormOfBl() + JNDINames.splitchar + obj.getOlcaLashTransDocsAllwd() + JNDINames.splitchar + obj.getOlcaPercOfInsValueCvrd() + JNDINames.splitchar + obj.getOlcaInsPolicyNum() + JNDINames.splitchar + obj.getOlcaInsDate() + JNDINames.splitchar + obj.getOlcaInsCurr() + JNDINames.splitchar + obj.getOlcaInsAmt() + JNDINames.splitchar + obj.getOlcaPremiumCurr() + JNDINames.splitchar + obj.getOlcaPremiumAmt() + JNDINames.splitchar + obj.getOlcaInsCompany() + JNDINames.splitchar + obj.getOlcaInsCompanyName() + JNDINames.splitchar + obj.getOlcaCooIssBy() + JNDINames.splitchar + obj.getOlcaOtherCompAuth() + JNDINames.splitchar + obj.getOlcaIntermediaryTrade() + JNDINames.splitchar + obj.getOlcaInspTestCertReq() + JNDINames.splitchar + obj.getOlcaCertBy() + JNDINames.splitchar + obj.getOlcaImpUnder() + JNDINames.splitchar + obj.getOlcaImpPolicyDet() + JNDINames.splitchar + obj.getOlcaImpRef() + JNDINames.splitchar + obj.getOlcaContraAmt() + JNDINames.splitchar + obj.getOlcaUsanceCharges() + JNDINames.splitchar + obj.getOlcaUsnChgTakenDays() + JNDINames.splitchar + obj.getOlcaCommitmentCharges() + JNDINames.splitchar + obj.getOlcaCommitChgTakenDays() + JNDINames.splitchar + obj.getTranchgsChgsSl() + JNDINames.splitchar + obj.getTranstlmntInvNum() + JNDINames.splitchar + obj.getPostTranBrn() + JNDINames.splitchar + obj.getPostTranDate() + JNDINames.splitchar + obj.getPostTranBatchNum() + JNDINames.splitchar + obj.getOlcaEntdBy() + JNDINames.splitchar + obj.getOlcaEntdOn() + JNDINames.splitchar + obj.getOlcaLastmodBy() + JNDINames.splitchar + obj.getOlcaLastmodOn() + JNDINames.splitchar + obj.getOlcaAuthBy() + JNDINames.splitchar + obj.getOlcaAuthOn() + JNDINames.splitchar + obj.getOlcaRejBy() + JNDINames.splitchar + obj.getOlcaRejOn() + JNDINames.splitchar + obj.getOlcaAmdChgPayBy() + JNDINames.splitchar + obj.getOlcaPerOfPresDays() + JNDINames.splitchar + obj.getOlcaChgInDescGoods() + JNDINames.splitchar + obj.getOlcaChgInDoc() + JNDINames.splitchar + obj.getOlcaChgInAddlCond() + JNDINames.splitchar + obj.getOlcaReqForCancel() + JNDINames.splitchar + obj.getOlcaChgOfAppl() + JNDINames.splitchar + obj.getOlcaChgInAvlWith() + JNDINames.splitchar + obj.getOlcaChgInDraweePay() + JNDINames.splitchar + obj.getOlcaChgInReimb() + JNDINames.splitchar + obj.getOlcaChgInAdvBk() + JNDINames.splitchar + obj.getOlcaChgInFormOfDc() + JNDINames.splitchar + obj.getOlcaChgInApplRules();
                if (_Logreq == 1)
                {
                    if (obj.isNew() == false)
                    {
                        if (OldData_Key != null) this._COLLECTIONobj.put(OldData_Key , DataBlock_Old );
                        if (NewData_Key != null) this._COLLECTIONobj.put(NewData_Key , DataBlock_New );
                    }else if ((_Logaddreq == 1) && obj.isNew() == true)
                    {
                        if (NewData_Key != null) this._COLLECTIONobj.put(NewData_Key , DataBlock_New );
                    }
                }
            OldData_Key ="";
            DataBlock_Old = "";
            DataBlock_New = "";
            NewData_Key = "";
        {
    // This is for main table Updation
            save(obj);
        }
    }

}
