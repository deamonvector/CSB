package panacea.OLC.Update;

import java.util.Vector;
import java.sql.*;
import panacea.common.JNDINames;
import java.util.LinkedHashMap;
import panacea.Manager.Manager;

/******************SQL2JAVA_IMPORT_BEGIN******************/

/******************SQL2JAVA_IMPORT_END********************/


public class AmendDetailsHistManager extends Manager
/******************SQL2JAVA_EXTENDS_BEGIN******************/

/******************SQL2JAVA_EXTENDS_END********************/

{

/******************SQL2JAVA_CLASS_BEGIN******************/

/******************SQL2JAVA_CLASS_END********************/


    public static final int AMENDHIST_LC_BRN_CODE = 0;
    public static final int AMENDHIST_LC_TYPE = 1;
    public static final int AMENDHIST_LC_YEAR = 2;
    public static final int AMENDHIST_LC_SERIAL = 3;
    public static final int AMENDHIST_LC_AMD_SL = 4;
    public static final int AMENDHIST_HIST_SL = 5;
    public static final int AMENDHIST_HIST_DATE = 6;
    public static final int AMENDHIST_SNDR_REF = 7;
    public static final int AMENDHIST_RCVR_REF = 8;
    public static final int AMENDHIST_DOC_CR_NUM = 9;
    public static final int AMENDHIST_ISSUING_BNK_REQ = 10;
    public static final int AMENDHIST_ISSUING_TYPE = 11;
    public static final int AMENDHIST_ISSUING_BRN_CODE = 12;
    public static final int AMENDHIST_ISSUING_BIC_CODE = 13;
    public static final int AMENDHIST_ISSUING_ROUTID = 14;
    public static final int AMENDHIST_ISSUING_BNK_CODE = 15;
    public static final int AMENDHIST_ISSUING_ADDR1 = 16;
    public static final int AMENDHIST_ISSUING_ADDR2 = 17;
    public static final int AMENDHIST_ISSUING_ADDR3 = 18;
    public static final int AMENDHIST_ISSUING_ADDR4 = 19;
    public static final int AMENDHIST_ISSUING_ADDR5 = 20;
    public static final int AMENDHIST_NON_BNK_ISSUR = 21;
    public static final int AMENDHIST_DATE_OF_ISSUE = 22;
    public static final int AMENDHIST_DATE_OF_AMENDMNT = 23;
    public static final int AMENDHIST_PURPOSE_OF_MSG = 24;
    public static final int AMENDHIST_CANCEL_REQUEST = 25;
    public static final int AMENDHIST_ADVISING_BNK_REQ = 26;
    public static final int AMENDHIST_ADVISING_BNK_TYPE = 27;
    public static final int AMENDHIST_ADVISING_BRN_CODE = 28;
    public static final int AMENDHIST_ADVISING_BIC_CODE = 29;
    public static final int AMENDHIST_ADVISING_ROUTID = 30;
    public static final int AMENDHIST_ADVISING_BNK_CODE = 31;
    public static final int AMENDHIST_ADVISING_ADDR1 = 32;
    public static final int AMENDHIST_ADVISING_ADDR2 = 33;
    public static final int AMENDHIST_ADVISING_ADDR3 = 34;
    public static final int AMENDHIST_ADVISING_ADDR4 = 35;
    public static final int AMENDHIST_ADVISING_ADDR5 = 36;
    public static final int AMENDHIST_SECOND_ADV_REQ = 37;
    public static final int AMENDHIST_SECOND_ADV_TYPE = 38;
    public static final int AMENDHIST_SECOND_ADV_BRN_CODE = 39;
    public static final int AMENDHIST_SECOND_ADV_BIC_CODE = 40;
    public static final int AMENDHIST_SECOND_ADV_ROUTID = 41;
    public static final int AMENDHIST_SECOND_ADV_BNK_CODE = 42;
    public static final int AMENDHIST_SECOND_ADV_ADDR1 = 43;
    public static final int AMENDHIST_SECOND_ADV_ADDR2 = 44;
    public static final int AMENDHIST_SECOND_ADV_ADDR3 = 45;
    public static final int AMENDHIST_SECOND_ADV_ADDR4 = 46;
    public static final int AMENDHIST_SECOND_ADV_ADDR5 = 47;
    public static final int AMENDHIST_NEW_BENEFICIARY = 48;
    public static final int AMENDHIST_NEW_DATE_OF_EXPIRY = 49;
    public static final int AMENDHIST_INCR_DOC_CR_AMT = 50;
    public static final int AMENDHIST_DECR_DOC_CR_AMT = 51;
    public static final int AMENDHIST_NEW_ADDNL_AMT = 52;
    public static final int AMENDHIST_PLACE_TAKIN_IN_CHRG = 53;
    public static final int AMENDHIST_PORT_OF_LOADING = 54;
    public static final int AMENDHIST_PORT_OF_DISCHARGE = 55;
    public static final int AMENDHIST_PLACE_OF_FINAL_DEST = 56;
    public static final int AMENDHIST_DATE_OF_SHIPMENT = 57;
    public static final int AMENDHIST_DESC_GODD_SER1 = 58;
    public static final int AMENDHIST_DOC_REQ1 = 59;
    public static final int AMENDHIST_ADD_CONDITION1 = 60;
    public static final int AMENDHIST_CHRG_PAYABLE1 = 61;
    public static final int AMENDHIST_CHRG_PAYABLE2 = 62;
    public static final int AMENDHIST_CHRG_PAYABLE3 = 63;
    public static final int AMENDHIST_CHRG_PAYABLE4 = 64;
    public static final int AMENDHIST_CHRG_PAYABLE5 = 65;
    public static final int AMENDHIST_CHRG_PAYABLE6 = 66;
    public static final int AMENDHIST_SNDR_REC_INFO1 = 67;
    public static final int AMENDHIST_SNDR_REC_INFO2 = 68;
    public static final int AMENDHIST_SNDR_REC_INFO3 = 69;
    public static final int AMENDHIST_SNDR_REC_INFO4 = 70;
    public static final int AMENDHIST_SNDR_REC_INFO5 = 71;
    public static final int AMENDHIST_SNDR_REC_INFO6 = 72;
    public static final int AMENDHIST_CHKBOX = 73;
    public static final int AMENDHIST_ISSUING_CNTRY = 74;
    public static final int AMENDHIST_ADVISING_CNTRY = 75;
    public static final int AMENDHIST_SECOND_ADV_CNTRY = 76;
    public static final int AMENDHIST_ISSUE_REF = 77;
    public static final int AMDHIST_FORM_OF_DOC_CREDIT = 78;
    public static final int AMDHIST_LC_APPLICABLE_RULES = 79;
    public static final int AMDHIST_LC_APPL_REQ = 80;
    public static final int AMDHIST_LC_APPL_NAME = 81;
    public static final int AMDHIST_LC_APPL_ADDR1 = 82;
    public static final int AMDHIST_LC_APPL_ADDR2 = 83;
    public static final int AMDHIST_LC_APPL_ADDR3 = 84;
    public static final int AMDHIST_LC_APPL_ADDR4 = 85;
    public static final int AMDHIST_LC_APPL_ADDR5 = 86;
    public static final int AMDHIST_LC_AVL_WITH_TYPE = 87;
    public static final int AMDHIST_LC_AVL_WITH_BRN_CODE = 88;
    public static final int AMDHIST_LC_AVL_WITH_BIC_CODE = 89;
    public static final int AMDHIST_LC_LC_AVL_WITH_ROUTID = 90;
    public static final int AMDHIST_LC_AVL_WITH_BNK_CODE = 91;
    public static final int AMDHIST_LC_AVL_WITH_ADDR1 = 92;
    public static final int AMDHIST_LC_AVL_WITH_ADDR2 = 93;
    public static final int AMDHIST_LC_AVL_WITH_ADDR3 = 94;
    public static final int AMDHIST_LC_AVL_WITH_ADDR4 = 95;
    public static final int AMDHIST_LC_AVL_WITH_ADDR5 = 96;
    public static final int AMDHIST_LC_AVL_WITH_CNTRY = 97;
    public static final int AMDHIST_LC_DRAFTS_AT1 = 98;
    public static final int AMDHIST_LC_DRAFTS_AT2 = 99;
    public static final int AMDHIST_LC_DRAFTS_AT3 = 100;
    public static final int AMDHIST_LC_DRAWEE_REQ = 101;
    public static final int AMDHIST_LC_DRAWEE_TYPE = 102;
    public static final int AMDHIST_LC_DRAWEE_BRN_CODE = 103;
    public static final int AMDHIST_LC_DRAWEE_BIC_CODE = 104;
    public static final int AMDHIST_LC_DRAWEE_ROUTID = 105;
    public static final int AMDHIST_LC_DRAWEE_BNK_CODE = 106;
    public static final int AMDHIST_LC_DRAWEE_ADDR1 = 107;
    public static final int AMDHIST_LC_DRAWEE_ADDR2 = 108;
    public static final int AMDHIST_LC_DRAWEE_ADDR3 = 109;
    public static final int AMDHIST_LC_DRAWEE_ADDR4 = 110;
    public static final int AMDHIST_LC_DRAWEE_ADDR5 = 111;
    public static final int AMDHIST_DRAWEE_CNTRY_CODE = 112;
    public static final int AMDHIST_LC_MIXED_PAY_DETAILS1 = 113;
    public static final int AMDHIST_LC_MIXED_PAY_DETAILS2 = 114;
    public static final int AMDHIST_LC_MIXED_PAY_DETAILS3 = 115;
    public static final int AMDHIST_LC_MIXED_PAY_DETAILS4 = 116;
    public static final int AMDHIST_LC_MIXED_PAY_DETAILS5 = 117;
    public static final int AMDHIST_LC_DEF_PAY_DETAILS1 = 118;
    public static final int AMDHIST_LC_DEF_PAY_DETAILS2 = 119;
    public static final int AMDHIST_LC_DEF_PAY_DETAILS3 = 120;
    public static final int AMDHIST_LC_DEF_PAY_DETAILS4 = 121;
    public static final int AMDHIST_LC_DEF_PAY_DETAILS5 = 122;
    public static final int AMDHIST_LC_PARTIAL_SHIPMENTS = 123;
    public static final int AMDHIST_LC_TRANSHIPMENT = 124;
    public static final int AMDHIST_LC_CONFIRMATION_INST = 125;
    public static final int AMDHIST_LC_REIMB_REQ = 126;
    public static final int AMDHIST_LC_REIMB_TYPE = 127;
    public static final int AMDHIST_LC_REIMB_BRN_CODE = 128;
    public static final int AMDHIST_LC_REIMB_BIC_CODE = 129;
    public static final int AMDHIST_LC_REIMB_ROUTID = 130;
    public static final int AMDHIST_LC_REIMB_BNK_CODE = 131;
    public static final int AMDHIST_LC_REIMB_ADDR1 = 132;
    public static final int AMDHIST_LC_REIMB_ADDR2 = 133;
    public static final int AMDHIST_LC_REIMB_ADDR3 = 134;
    public static final int AMDHIST_LC_REIMB_ADDR4 = 135;
    public static final int AMDHIST_LC_REIMB_ADDR5 = 136;
    public static final int AMDHIST_LC_INST_PAYING1 = 137;
    public static final int AMDHIST_LC_INST_PAYING2 = 138;
    public static final int AMDHIST_LC_INST_PAYING3 = 139;
    public static final int AMDHIST_LC_INST_PAYING4 = 140;
    public static final int AMDHIST_LC_INST_PAYING5 = 141;
    public static final int AMDHIST_LC_INST_PAYING6 = 142;
    public static final int AMDHIST_LC_INST_PAYING7 = 143;
    public static final int AMDHIST_LC_INST_PAYING8 = 144;
    public static final int AMDHIST_LC_INST_PAYING9 = 145;
    public static final int AMDHIST_LC_INST_PAYING10 = 146;
    public static final int AMDHIST_LC_INST_PAYING11 = 147;
    public static final int AMDHIST_LC_INST_PAYING12 = 148;
    public static final int AMDHIST_LC_SECOND_ADV_REQ = 149;
    public static final int AMDHIST_LC_SECOND_ADV_TYPE = 150;
    public static final int AMDHIST_LC_SECOND_ADV_BRN_CODE = 151;
    public static final int AMDHIST_LC_SECOND_ADV_BIC_CODE = 152;
    public static final int AMDHIST_LC_SECOND_ADV_ROUTID = 153;
    public static final int AMDHIST_LC_SECOND_ADV_BNK_CODE = 154;
    public static final int AMDHIST_LC_SECOND_ADV_ADDR1 = 155;
    public static final int AMDHIST_LC_SECOND_ADV_ADDR2 = 156;
    public static final int AMDHIST_LC_SECOND_ADV_ADDR3 = 157;
    public static final int AMDHIST_LC_SECOND_ADV_ADDR4 = 158;
    public static final int AMDHIST_LC_SECOND_ADV_ADDR5 = 159;
    public static final int AMDHIST_LC_SEC_ADV_CNTRYCODE = 160;
    public static final int AMEND_HIST_LC_AVL_WITH_CODETYP = 161;
    public static final int AMENDHIST_LC_REIMB_CNTRY_CODE = 162;
    public static final int AMENDHIST_LC_CNF_ADV_TYPE = 163;
    public static final int AMENDHIST_LC_CNF_ADV_BRN_CODE = 164;
    public static final int AMENDHIST_LC_CNF_ADV_BIC_CODE = 165;
    public static final int AMENDHIST_LC_CNF_ADV_ROUTID = 166;
    public static final int AMENDHIST_LC_CNF_ADV_BNK_CODE = 167;
    public static final int AMENDHIST_LC_CNF_ADV_ADDR1 = 168;
    public static final int AMENDHIST_LC_CNF_ADV_ADDR2 = 169;
    public static final int AMENDHIST_LC_CNF_ADV_ADDR3 = 170;
    public static final int AMENDHIST_LC_CNF_ADV_ADDR4 = 171;
    public static final int AMENDHIST_LC_CNF_ADV_ADDR5 = 172;
    public static final int AMENDHIST_LC_CNF_ADV_CNTRYCODE = 173;

    private String OldData_Key;
    private String NewData_Key;
    private String DataBlock_Old;
    private String DataBlock_New;
    private LinkedHashMap _COLLECTIONobj;
    private int _Logreq ;
    private int _Logaddreq ;
    public AmendDetailsHistManager(LinkedHashMap _COLLECTIONobj, int _Log_Req , int _Log_Add_Req ){
        //_COLLECTIONobjManager = _COLLECTIONobj;
        this._COLLECTIONobj 	= _COLLECTIONobj;
        this._Logreq 			= _Log_Req;
        this._Logaddreq 		= _Log_Add_Req;
        //set_pki_enabled(_COLLECTIONobj);
    }
    private static final String[] S2J_FIELD_NAMES = {
        "AMEND_DETAILS_HIST.AMENDHIST_LC_BRN_CODE"
        ,"AMEND_DETAILS_HIST.AMENDHIST_LC_TYPE"
        ,"AMEND_DETAILS_HIST.AMENDHIST_LC_YEAR"
        ,"AMEND_DETAILS_HIST.AMENDHIST_LC_SERIAL"
        ,"AMEND_DETAILS_HIST.AMENDHIST_LC_AMD_SL"
        ,"AMEND_DETAILS_HIST.AMENDHIST_HIST_SL"
        ,"AMEND_DETAILS_HIST.AMENDHIST_HIST_DATE"
        ,"AMEND_DETAILS_HIST.AMENDHIST_SNDR_REF"
        ,"AMEND_DETAILS_HIST.AMENDHIST_RCVR_REF"
        ,"AMEND_DETAILS_HIST.AMENDHIST_DOC_CR_NUM"
        ,"AMEND_DETAILS_HIST.AMENDHIST_ISSUING_BNK_REQ"
        ,"AMEND_DETAILS_HIST.AMENDHIST_ISSUING_TYPE"
        ,"AMEND_DETAILS_HIST.AMENDHIST_ISSUING_BRN_CODE"
        ,"AMEND_DETAILS_HIST.AMENDHIST_ISSUING_BIC_CODE"
        ,"AMEND_DETAILS_HIST.AMENDHIST_ISSUING_ROUTID"
        ,"AMEND_DETAILS_HIST.AMENDHIST_ISSUING_BNK_CODE"
        ,"AMEND_DETAILS_HIST.AMENDHIST_ISSUING_ADDR1"
        ,"AMEND_DETAILS_HIST.AMENDHIST_ISSUING_ADDR2"
        ,"AMEND_DETAILS_HIST.AMENDHIST_ISSUING_ADDR3"
        ,"AMEND_DETAILS_HIST.AMENDHIST_ISSUING_ADDR4"
        ,"AMEND_DETAILS_HIST.AMENDHIST_ISSUING_ADDR5"
        ,"AMEND_DETAILS_HIST.AMENDHIST_NON_BNK_ISSUR"
        ,"AMEND_DETAILS_HIST.AMENDHIST_DATE_OF_ISSUE"
        ,"AMEND_DETAILS_HIST.AMENDHIST_DATE_OF_AMENDMNT"
        ,"AMEND_DETAILS_HIST.AMENDHIST_PURPOSE_OF_MSG"
        ,"AMEND_DETAILS_HIST.AMENDHIST_CANCEL_REQUEST"
        ,"AMEND_DETAILS_HIST.AMENDHIST_ADVISING_BNK_REQ"
        ,"AMEND_DETAILS_HIST.AMENDHIST_ADVISING_BNK_TYPE"
        ,"AMEND_DETAILS_HIST.AMENDHIST_ADVISING_BRN_CODE"
        ,"AMEND_DETAILS_HIST.AMENDHIST_ADVISING_BIC_CODE"
        ,"AMEND_DETAILS_HIST.AMENDHIST_ADVISING_ROUTID"
        ,"AMEND_DETAILS_HIST.AMENDHIST_ADVISING_BNK_CODE"
        ,"AMEND_DETAILS_HIST.AMENDHIST_ADVISING_ADDR1"
        ,"AMEND_DETAILS_HIST.AMENDHIST_ADVISING_ADDR2"
        ,"AMEND_DETAILS_HIST.AMENDHIST_ADVISING_ADDR3"
        ,"AMEND_DETAILS_HIST.AMENDHIST_ADVISING_ADDR4"
        ,"AMEND_DETAILS_HIST.AMENDHIST_ADVISING_ADDR5"
        ,"AMEND_DETAILS_HIST.AMENDHIST_SECOND_ADV_REQ"
        ,"AMEND_DETAILS_HIST.AMENDHIST_SECOND_ADV_TYPE"
        ,"AMEND_DETAILS_HIST.AMENDHIST_SECOND_ADV_BRN_CODE"
        ,"AMEND_DETAILS_HIST.AMENDHIST_SECOND_ADV_BIC_CODE"
        ,"AMEND_DETAILS_HIST.AMENDHIST_SECOND_ADV_ROUTID"
        ,"AMEND_DETAILS_HIST.AMENDHIST_SECOND_ADV_BNK_CODE"
        ,"AMEND_DETAILS_HIST.AMENDHIST_SECOND_ADV_ADDR1"
        ,"AMEND_DETAILS_HIST.AMENDHIST_SECOND_ADV_ADDR2"
        ,"AMEND_DETAILS_HIST.AMENDHIST_SECOND_ADV_ADDR3"
        ,"AMEND_DETAILS_HIST.AMENDHIST_SECOND_ADV_ADDR4"
        ,"AMEND_DETAILS_HIST.AMENDHIST_SECOND_ADV_ADDR5"
        ,"AMEND_DETAILS_HIST.AMENDHIST_NEW_BENEFICIARY"
        ,"AMEND_DETAILS_HIST.AMENDHIST_NEW_DATE_OF_EXPIRY"
        ,"AMEND_DETAILS_HIST.AMENDHIST_INCR_DOC_CR_AMT"
        ,"AMEND_DETAILS_HIST.AMENDHIST_DECR_DOC_CR_AMT"
        ,"AMEND_DETAILS_HIST.AMENDHIST_NEW_ADDNL_AMT"
        ,"AMEND_DETAILS_HIST.AMENDHIST_PLACE_TAKIN_IN_CHRG"
        ,"AMEND_DETAILS_HIST.AMENDHIST_PORT_OF_LOADING"
        ,"AMEND_DETAILS_HIST.AMENDHIST_PORT_OF_DISCHARGE"
        ,"AMEND_DETAILS_HIST.AMENDHIST_PLACE_OF_FINAL_DEST"
        ,"AMEND_DETAILS_HIST.AMENDHIST_DATE_OF_SHIPMENT"
        ,"AMEND_DETAILS_HIST.AMENDHIST_DESC_GODD_SER1"
        ,"AMEND_DETAILS_HIST.AMENDHIST_DOC_REQ1"
        ,"AMEND_DETAILS_HIST.AMENDHIST_ADD_CONDITION1"
        ,"AMEND_DETAILS_HIST.AMENDHIST_CHRG_PAYABLE1"
        ,"AMEND_DETAILS_HIST.AMENDHIST_CHRG_PAYABLE2"
        ,"AMEND_DETAILS_HIST.AMENDHIST_CHRG_PAYABLE3"
        ,"AMEND_DETAILS_HIST.AMENDHIST_CHRG_PAYABLE4"
        ,"AMEND_DETAILS_HIST.AMENDHIST_CHRG_PAYABLE5"
        ,"AMEND_DETAILS_HIST.AMENDHIST_CHRG_PAYABLE6"
        ,"AMEND_DETAILS_HIST.AMENDHIST_SNDR_REC_INFO1"
        ,"AMEND_DETAILS_HIST.AMENDHIST_SNDR_REC_INFO2"
        ,"AMEND_DETAILS_HIST.AMENDHIST_SNDR_REC_INFO3"
        ,"AMEND_DETAILS_HIST.AMENDHIST_SNDR_REC_INFO4"
        ,"AMEND_DETAILS_HIST.AMENDHIST_SNDR_REC_INFO5"
        ,"AMEND_DETAILS_HIST.AMENDHIST_SNDR_REC_INFO6"
        ,"AMEND_DETAILS_HIST.AMENDHIST_CHKBOX"
        ,"AMEND_DETAILS_HIST.AMENDHIST_ISSUING_CNTRY"
        ,"AMEND_DETAILS_HIST.AMENDHIST_ADVISING_CNTRY"
        ,"AMEND_DETAILS_HIST.AMENDHIST_SECOND_ADV_CNTRY"
        ,"AMEND_DETAILS_HIST.AMENDHIST_ISSUE_REF"
        ,"AMEND_DETAILS_HIST.AMDHIST_FORM_OF_DOC_CREDIT"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_APPLICABLE_RULES"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_APPL_REQ"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_APPL_NAME"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_APPL_ADDR1"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_APPL_ADDR2"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_APPL_ADDR3"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_APPL_ADDR4"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_APPL_ADDR5"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_AVL_WITH_TYPE"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_AVL_WITH_BRN_CODE"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_AVL_WITH_BIC_CODE"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_LC_AVL_WITH_ROUTID"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_AVL_WITH_BNK_CODE"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_AVL_WITH_ADDR1"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_AVL_WITH_ADDR2"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_AVL_WITH_ADDR3"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_AVL_WITH_ADDR4"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_AVL_WITH_ADDR5"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_AVL_WITH_CNTRY"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_DRAFTS_AT1"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_DRAFTS_AT2"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_DRAFTS_AT3"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_DRAWEE_REQ"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_DRAWEE_TYPE"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_DRAWEE_BRN_CODE"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_DRAWEE_BIC_CODE"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_DRAWEE_ROUTID"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_DRAWEE_BNK_CODE"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_DRAWEE_ADDR1"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_DRAWEE_ADDR2"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_DRAWEE_ADDR3"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_DRAWEE_ADDR4"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_DRAWEE_ADDR5"
        ,"AMEND_DETAILS_HIST.AMDHIST_DRAWEE_CNTRY_CODE"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_MIXED_PAY_DETAILS1"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_MIXED_PAY_DETAILS2"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_MIXED_PAY_DETAILS3"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_MIXED_PAY_DETAILS4"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_MIXED_PAY_DETAILS5"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_DEF_PAY_DETAILS1"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_DEF_PAY_DETAILS2"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_DEF_PAY_DETAILS3"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_DEF_PAY_DETAILS4"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_DEF_PAY_DETAILS5"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_PARTIAL_SHIPMENTS"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_TRANSHIPMENT"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_CONFIRMATION_INST"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_REIMB_REQ"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_REIMB_TYPE"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_REIMB_BRN_CODE"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_REIMB_BIC_CODE"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_REIMB_ROUTID"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_REIMB_BNK_CODE"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_REIMB_ADDR1"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_REIMB_ADDR2"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_REIMB_ADDR3"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_REIMB_ADDR4"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_REIMB_ADDR5"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_INST_PAYING1"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_INST_PAYING2"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_INST_PAYING3"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_INST_PAYING4"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_INST_PAYING5"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_INST_PAYING6"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_INST_PAYING7"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_INST_PAYING8"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_INST_PAYING9"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_INST_PAYING10"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_INST_PAYING11"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_INST_PAYING12"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_SECOND_ADV_REQ"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_SECOND_ADV_TYPE"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_SECOND_ADV_BRN_CODE"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_SECOND_ADV_BIC_CODE"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_SECOND_ADV_ROUTID"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_SECOND_ADV_BNK_CODE"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_SECOND_ADV_ADDR1"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_SECOND_ADV_ADDR2"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_SECOND_ADV_ADDR3"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_SECOND_ADV_ADDR4"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_SECOND_ADV_ADDR5"
        ,"AMEND_DETAILS_HIST.AMDHIST_LC_SEC_ADV_CNTRYCODE"
        ,"AMEND_DETAILS_HIST.AMEND_HIST_LC_AVL_WITH_CODETYP"
        ,"AMEND_DETAILS_HIST.AMENDHIST_LC_REIMB_CNTRY_CODE"
        ,"AMEND_DETAILS_HIST.AMENDHIST_LC_CNF_ADV_TYPE"
        ,"AMEND_DETAILS_HIST.AMENDHIST_LC_CNF_ADV_BRN_CODE"
        ,"AMEND_DETAILS_HIST.AMENDHIST_LC_CNF_ADV_BIC_CODE"
        ,"AMEND_DETAILS_HIST.AMENDHIST_LC_CNF_ADV_ROUTID"
        ,"AMEND_DETAILS_HIST.AMENDHIST_LC_CNF_ADV_BNK_CODE"
        ,"AMEND_DETAILS_HIST.AMENDHIST_LC_CNF_ADV_ADDR1"
        ,"AMEND_DETAILS_HIST.AMENDHIST_LC_CNF_ADV_ADDR2"
        ,"AMEND_DETAILS_HIST.AMENDHIST_LC_CNF_ADV_ADDR3"
        ,"AMEND_DETAILS_HIST.AMENDHIST_LC_CNF_ADV_ADDR4"
        ,"AMEND_DETAILS_HIST.AMENDHIST_LC_CNF_ADV_ADDR5"
        ,"AMEND_DETAILS_HIST.AMENDHIST_LC_CNF_ADV_CNTRYCODE"
    };

    private static final String ALL_FIELDS = "AMEND_DETAILS_HIST.AMENDHIST_LC_BRN_CODE"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_LC_TYPE"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_LC_YEAR"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_LC_SERIAL"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_LC_AMD_SL"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_HIST_SL"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_HIST_DATE"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_SNDR_REF"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_RCVR_REF"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_DOC_CR_NUM"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_ISSUING_BNK_REQ"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_ISSUING_TYPE"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_ISSUING_BRN_CODE"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_ISSUING_BIC_CODE"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_ISSUING_ROUTID"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_ISSUING_BNK_CODE"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_ISSUING_ADDR1"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_ISSUING_ADDR2"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_ISSUING_ADDR3"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_ISSUING_ADDR4"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_ISSUING_ADDR5"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_NON_BNK_ISSUR"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_DATE_OF_ISSUE"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_DATE_OF_AMENDMNT"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_PURPOSE_OF_MSG"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_CANCEL_REQUEST"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_ADVISING_BNK_REQ"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_ADVISING_BNK_TYPE"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_ADVISING_BRN_CODE"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_ADVISING_BIC_CODE"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_ADVISING_ROUTID"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_ADVISING_BNK_CODE"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_ADVISING_ADDR1"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_ADVISING_ADDR2"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_ADVISING_ADDR3"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_ADVISING_ADDR4"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_ADVISING_ADDR5"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_SECOND_ADV_REQ"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_SECOND_ADV_TYPE"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_SECOND_ADV_BRN_CODE"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_SECOND_ADV_BIC_CODE"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_SECOND_ADV_ROUTID"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_SECOND_ADV_BNK_CODE"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_SECOND_ADV_ADDR1"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_SECOND_ADV_ADDR2"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_SECOND_ADV_ADDR3"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_SECOND_ADV_ADDR4"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_SECOND_ADV_ADDR5"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_NEW_BENEFICIARY"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_NEW_DATE_OF_EXPIRY"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_INCR_DOC_CR_AMT"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_DECR_DOC_CR_AMT"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_NEW_ADDNL_AMT"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_PLACE_TAKIN_IN_CHRG"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_PORT_OF_LOADING"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_PORT_OF_DISCHARGE"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_PLACE_OF_FINAL_DEST"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_DATE_OF_SHIPMENT"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_DESC_GODD_SER1"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_DOC_REQ1"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_ADD_CONDITION1"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_CHRG_PAYABLE1"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_CHRG_PAYABLE2"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_CHRG_PAYABLE3"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_CHRG_PAYABLE4"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_CHRG_PAYABLE5"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_CHRG_PAYABLE6"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_SNDR_REC_INFO1"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_SNDR_REC_INFO2"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_SNDR_REC_INFO3"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_SNDR_REC_INFO4"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_SNDR_REC_INFO5"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_SNDR_REC_INFO6"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_CHKBOX"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_ISSUING_CNTRY"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_ADVISING_CNTRY"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_SECOND_ADV_CNTRY"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_ISSUE_REF"
                            + ",AMEND_DETAILS_HIST.AMDHIST_FORM_OF_DOC_CREDIT"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_APPLICABLE_RULES"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_APPL_REQ"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_APPL_NAME"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_APPL_ADDR1"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_APPL_ADDR2"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_APPL_ADDR3"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_APPL_ADDR4"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_APPL_ADDR5"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_AVL_WITH_TYPE"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_AVL_WITH_BRN_CODE"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_AVL_WITH_BIC_CODE"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_LC_AVL_WITH_ROUTID"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_AVL_WITH_BNK_CODE"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_AVL_WITH_ADDR1"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_AVL_WITH_ADDR2"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_AVL_WITH_ADDR3"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_AVL_WITH_ADDR4"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_AVL_WITH_ADDR5"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_AVL_WITH_CNTRY"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_DRAFTS_AT1"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_DRAFTS_AT2"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_DRAFTS_AT3"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_DRAWEE_REQ"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_DRAWEE_TYPE"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_DRAWEE_BRN_CODE"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_DRAWEE_BIC_CODE"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_DRAWEE_ROUTID"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_DRAWEE_BNK_CODE"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_DRAWEE_ADDR1"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_DRAWEE_ADDR2"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_DRAWEE_ADDR3"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_DRAWEE_ADDR4"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_DRAWEE_ADDR5"
                            + ",AMEND_DETAILS_HIST.AMDHIST_DRAWEE_CNTRY_CODE"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_MIXED_PAY_DETAILS1"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_MIXED_PAY_DETAILS2"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_MIXED_PAY_DETAILS3"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_MIXED_PAY_DETAILS4"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_MIXED_PAY_DETAILS5"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_DEF_PAY_DETAILS1"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_DEF_PAY_DETAILS2"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_DEF_PAY_DETAILS3"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_DEF_PAY_DETAILS4"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_DEF_PAY_DETAILS5"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_PARTIAL_SHIPMENTS"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_TRANSHIPMENT"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_CONFIRMATION_INST"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_REIMB_REQ"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_REIMB_TYPE"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_REIMB_BRN_CODE"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_REIMB_BIC_CODE"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_REIMB_ROUTID"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_REIMB_BNK_CODE"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_REIMB_ADDR1"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_REIMB_ADDR2"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_REIMB_ADDR3"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_REIMB_ADDR4"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_REIMB_ADDR5"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_INST_PAYING1"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_INST_PAYING2"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_INST_PAYING3"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_INST_PAYING4"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_INST_PAYING5"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_INST_PAYING6"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_INST_PAYING7"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_INST_PAYING8"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_INST_PAYING9"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_INST_PAYING10"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_INST_PAYING11"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_INST_PAYING12"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_SECOND_ADV_REQ"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_SECOND_ADV_TYPE"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_SECOND_ADV_BRN_CODE"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_SECOND_ADV_BIC_CODE"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_SECOND_ADV_ROUTID"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_SECOND_ADV_BNK_CODE"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_SECOND_ADV_ADDR1"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_SECOND_ADV_ADDR2"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_SECOND_ADV_ADDR3"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_SECOND_ADV_ADDR4"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_SECOND_ADV_ADDR5"
                            + ",AMEND_DETAILS_HIST.AMDHIST_LC_SEC_ADV_CNTRYCODE"
                            + ",AMEND_DETAILS_HIST.AMEND_HIST_LC_AVL_WITH_CODETYP"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_LC_REIMB_CNTRY_CODE"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_LC_CNF_ADV_TYPE"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_LC_CNF_ADV_BRN_CODE"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_LC_CNF_ADV_BIC_CODE"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_LC_CNF_ADV_ROUTID"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_LC_CNF_ADV_BNK_CODE"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_LC_CNF_ADV_ADDR1"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_LC_CNF_ADV_ADDR2"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_LC_CNF_ADV_ADDR3"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_LC_CNF_ADV_ADDR4"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_LC_CNF_ADV_ADDR5"
                            + ",AMEND_DETAILS_HIST.AMENDHIST_LC_CNF_ADV_CNTRYCODE";
    
    public AmendDetailsHist loadByKey(java.util.Date _amendhistHistDate, int _amendhistLcAmdSl, int _amendhistLcBrnCode, int _amendhistLcSerial, String _amendhistLcType, int _amendhistLcYear, Connection _conn) throws SQLException {
        PreparedStatement _pstmt = null;
        try {
            _pstmt = _conn.prepareStatement("SELECT " + ALL_FIELDS + " FROM AMEND_DETAILS_HIST WHERE AMEND_DETAILS_HIST.AMENDHIST_HIST_DATE=?  and AMEND_DETAILS_HIST.AMENDHIST_LC_AMD_SL=? and AMEND_DETAILS_HIST.AMENDHIST_LC_BRN_CODE=? and AMEND_DETAILS_HIST.AMENDHIST_LC_SERIAL=? and AMEND_DETAILS_HIST.AMENDHIST_LC_TYPE=? and AMEND_DETAILS_HIST.AMENDHIST_LC_YEAR=?");
            if (_amendhistHistDate == null) {_pstmt.setTimestamp(1, null);} else {_pstmt.setTimestamp(1, new java.sql.Timestamp(_amendhistHistDate.getTime()));}
            _pstmt.setInt(2, _amendhistLcAmdSl);
            _pstmt.setInt(3, _amendhistLcBrnCode);
            _pstmt.setInt(4, _amendhistLcSerial);
            _pstmt.setString(5, _amendhistLcType);
            _pstmt.setInt(6, _amendhistLcYear);
            AmendDetailsHist _list[] = loadByPreparedStatement(_pstmt);
            _pstmt.close();
            if(_list.length < 1) return null;
            else                 return _list[0];
        }
        catch(SQLException e) {
            if(_pstmt != null) try { _pstmt.close(); } catch(SQLException e2) { }
            throw e;
        }
    }

    public AmendDetailsHist loadByKey(java.util.Date _amendhistHistDate, int _amendhistHistSl, int _amendhistLcAmdSl, int _amendhistLcBrnCode, int _amendhistLcSerial, String _amendhistLcType, int _amendhistLcYear) throws SQLException {
        Connection _conn = null;
        try {
            _conn = openConnection();
            AmendDetailsHist _obj = loadByKey(_amendhistHistDate, _amendhistHistSl, _amendhistLcAmdSl, _amendhistLcBrnCode, _amendhistLcSerial, _amendhistLcType, _amendhistLcYear, _conn);
            if ( _obj != null)
            {
            OldData_Key = "AMEND_DETAILS_HIST" + TableValueSep + OldDataChar + _obj.getAmendhistLcBrnCode() + _obj.getAmendhistLcType() + _obj.getAmendhistLcYear() + _obj.getAmendhistLcSerial() + _obj.getAmendhistLcAmdSl() + _obj.getAmendhistHistSl() + _obj.getAmendhistHistDate();
        DataBlock_Old = _obj.getAmendhistLcBrnCode() + JNDINames.splitchar + _obj.getAmendhistLcType() + JNDINames.splitchar + _obj.getAmendhistLcYear() + JNDINames.splitchar + _obj.getAmendhistLcSerial() + JNDINames.splitchar + _obj.getAmendhistLcAmdSl() + JNDINames.splitchar + _obj.getAmendhistHistSl() + JNDINames.splitchar + _obj.getAmendhistHistDate() + JNDINames.splitchar + _obj.getAmendhistSndrRef() + JNDINames.splitchar + _obj.getAmendhistRcvrRef() + JNDINames.splitchar + _obj.getAmendhistDocCrNum() + JNDINames.splitchar + _obj.getAmendhistIssuingBnkReq() + JNDINames.splitchar + _obj.getAmendhistIssuingType() + JNDINames.splitchar + _obj.getAmendhistIssuingBrnCode() + JNDINames.splitchar + _obj.getAmendhistIssuingBicCode() + JNDINames.splitchar + _obj.getAmendhistIssuingRoutid() + JNDINames.splitchar + _obj.getAmendhistIssuingBnkCode() + JNDINames.splitchar + _obj.getAmendhistIssuingAddr1() + JNDINames.splitchar + _obj.getAmendhistIssuingAddr2() + JNDINames.splitchar + _obj.getAmendhistIssuingAddr3() + JNDINames.splitchar + _obj.getAmendhistIssuingAddr4() + JNDINames.splitchar + _obj.getAmendhistIssuingAddr5() + JNDINames.splitchar + _obj.getAmendhistNonBnkIssur() + JNDINames.splitchar + _obj.getAmendhistDateOfIssue() + JNDINames.splitchar + _obj.getAmendhistDateOfAmendmnt() + JNDINames.splitchar + _obj.getAmendhistPurposeOfMsg() + JNDINames.splitchar + _obj.getAmendhistCancelRequest() + JNDINames.splitchar + _obj.getAmendhistAdvisingBnkReq() + JNDINames.splitchar + _obj.getAmendhistAdvisingBnkType() + JNDINames.splitchar + _obj.getAmendhistAdvisingBrnCode() + JNDINames.splitchar + _obj.getAmendhistAdvisingBicCode() + JNDINames.splitchar + _obj.getAmendhistAdvisingRoutid() + JNDINames.splitchar + _obj.getAmendhistAdvisingBnkCode() + JNDINames.splitchar + _obj.getAmendhistAdvisingAddr1() + JNDINames.splitchar + _obj.getAmendhistAdvisingAddr2() + JNDINames.splitchar + _obj.getAmendhistAdvisingAddr3() + JNDINames.splitchar + _obj.getAmendhistAdvisingAddr4() + JNDINames.splitchar + _obj.getAmendhistAdvisingAddr5() + JNDINames.splitchar + _obj.getAmendhistSecondAdvReq() + JNDINames.splitchar + _obj.getAmendhistSecondAdvType() + JNDINames.splitchar + _obj.getAmendhistSecondAdvBrnCode() + JNDINames.splitchar + _obj.getAmendhistSecondAdvBicCode() + JNDINames.splitchar + _obj.getAmendhistSecondAdvRoutid() + JNDINames.splitchar + _obj.getAmendhistSecondAdvBnkCode() + JNDINames.splitchar + _obj.getAmendhistSecondAdvAddr1() + JNDINames.splitchar + _obj.getAmendhistSecondAdvAddr2() + JNDINames.splitchar + _obj.getAmendhistSecondAdvAddr3() + JNDINames.splitchar + _obj.getAmendhistSecondAdvAddr4() + JNDINames.splitchar + _obj.getAmendhistSecondAdvAddr5() + JNDINames.splitchar + _obj.getAmendhistNewBeneficiary() + JNDINames.splitchar + _obj.getAmendhistNewDateOfExpiry() + JNDINames.splitchar + _obj.getAmendhistIncrDocCrAmt() + JNDINames.splitchar + _obj.getAmendhistDecrDocCrAmt() + JNDINames.splitchar + _obj.getAmendhistNewAddnlAmt() + JNDINames.splitchar + _obj.getAmendhistPlaceTakinInChrg() + JNDINames.splitchar + _obj.getAmendhistPortOfLoading() + JNDINames.splitchar + _obj.getAmendhistPortOfDischarge() + JNDINames.splitchar + _obj.getAmendhistPlaceOfFinalDest() + JNDINames.splitchar + _obj.getAmendhistDateOfShipment() + JNDINames.splitchar + _obj.getAmendhistDescGoddSer1() + JNDINames.splitchar + _obj.getAmendhistDocReq1() + JNDINames.splitchar + _obj.getAmendhistAddCondition1() + JNDINames.splitchar + _obj.getAmendhistChrgPayable1() + JNDINames.splitchar + _obj.getAmendhistChrgPayable2() + JNDINames.splitchar + _obj.getAmendhistChrgPayable3() + JNDINames.splitchar + _obj.getAmendhistChrgPayable4() + JNDINames.splitchar + _obj.getAmendhistChrgPayable5() + JNDINames.splitchar + _obj.getAmendhistChrgPayable6() + JNDINames.splitchar + _obj.getAmendhistSndrRecInfo1() + JNDINames.splitchar + _obj.getAmendhistSndrRecInfo2() + JNDINames.splitchar + _obj.getAmendhistSndrRecInfo3() + JNDINames.splitchar + _obj.getAmendhistSndrRecInfo4() + JNDINames.splitchar + _obj.getAmendhistSndrRecInfo5() + JNDINames.splitchar + _obj.getAmendhistSndrRecInfo6() + JNDINames.splitchar + _obj.getAmendhistChkbox() + JNDINames.splitchar + _obj.getAmendhistIssuingCntry() + JNDINames.splitchar + _obj.getAmendhistAdvisingCntry() + JNDINames.splitchar + _obj.getAmendhistSecondAdvCntry() + JNDINames.splitchar + _obj.getAmendhistIssueRef() + JNDINames.splitchar + _obj.getAmdhistFormOfDocCredit() + JNDINames.splitchar + _obj.getAmdhistLcApplicableRules() + JNDINames.splitchar + _obj.getAmdhistLcApplReq() + JNDINames.splitchar + _obj.getAmdhistLcApplName() + JNDINames.splitchar + _obj.getAmdhistLcApplAddr1() + JNDINames.splitchar + _obj.getAmdhistLcApplAddr2() + JNDINames.splitchar + _obj.getAmdhistLcApplAddr3() + JNDINames.splitchar + _obj.getAmdhistLcApplAddr4() + JNDINames.splitchar + _obj.getAmdhistLcApplAddr5() + JNDINames.splitchar + _obj.getAmdhistLcAvlWithType() + JNDINames.splitchar + _obj.getAmdhistLcAvlWithBrnCode() + JNDINames.splitchar + _obj.getAmdhistLcAvlWithBicCode() + JNDINames.splitchar + _obj.getAmdhistLcLcAvlWithRoutid() + JNDINames.splitchar + _obj.getAmdhistLcAvlWithBnkCode() + JNDINames.splitchar + _obj.getAmdhistLcAvlWithAddr1() + JNDINames.splitchar + _obj.getAmdhistLcAvlWithAddr2() + JNDINames.splitchar + _obj.getAmdhistLcAvlWithAddr3() + JNDINames.splitchar + _obj.getAmdhistLcAvlWithAddr4() + JNDINames.splitchar + _obj.getAmdhistLcAvlWithAddr5() + JNDINames.splitchar + _obj.getAmdhistLcAvlWithCntry() + JNDINames.splitchar + _obj.getAmdhistLcDraftsAt1() + JNDINames.splitchar + _obj.getAmdhistLcDraftsAt2() + JNDINames.splitchar + _obj.getAmdhistLcDraftsAt3() + JNDINames.splitchar + _obj.getAmdhistLcDraweeReq() + JNDINames.splitchar + _obj.getAmdhistLcDraweeType() + JNDINames.splitchar + _obj.getAmdhistLcDraweeBrnCode() + JNDINames.splitchar + _obj.getAmdhistLcDraweeBicCode() + JNDINames.splitchar + _obj.getAmdhistLcDraweeRoutid() + JNDINames.splitchar + _obj.getAmdhistLcDraweeBnkCode() + JNDINames.splitchar + _obj.getAmdhistLcDraweeAddr1() + JNDINames.splitchar + _obj.getAmdhistLcDraweeAddr2() + JNDINames.splitchar + _obj.getAmdhistLcDraweeAddr3() + JNDINames.splitchar + _obj.getAmdhistLcDraweeAddr4() + JNDINames.splitchar + _obj.getAmdhistLcDraweeAddr5() + JNDINames.splitchar + _obj.getAmdhistDraweeCntryCode() + JNDINames.splitchar + _obj.getAmdhistLcMixedPayDetails1() + JNDINames.splitchar + _obj.getAmdhistLcMixedPayDetails2() + JNDINames.splitchar + _obj.getAmdhistLcMixedPayDetails3() + JNDINames.splitchar + _obj.getAmdhistLcMixedPayDetails4() + JNDINames.splitchar + _obj.getAmdhistLcMixedPayDetails5() + JNDINames.splitchar + _obj.getAmdhistLcDefPayDetails1() + JNDINames.splitchar + _obj.getAmdhistLcDefPayDetails2() + JNDINames.splitchar + _obj.getAmdhistLcDefPayDetails3() + JNDINames.splitchar + _obj.getAmdhistLcDefPayDetails4() + JNDINames.splitchar + _obj.getAmdhistLcDefPayDetails5() + JNDINames.splitchar + _obj.getAmdhistLcPartialShipments() + JNDINames.splitchar + _obj.getAmdhistLcTranshipment() + JNDINames.splitchar + _obj.getAmdhistLcConfirmationInst() + JNDINames.splitchar + _obj.getAmdhistLcReimbReq() + JNDINames.splitchar + _obj.getAmdhistLcReimbType() + JNDINames.splitchar + _obj.getAmdhistLcReimbBrnCode() + JNDINames.splitchar + _obj.getAmdhistLcReimbBicCode() + JNDINames.splitchar + _obj.getAmdhistLcReimbRoutid() + JNDINames.splitchar + _obj.getAmdhistLcReimbBnkCode() + JNDINames.splitchar + _obj.getAmdhistLcReimbAddr1() + JNDINames.splitchar + _obj.getAmdhistLcReimbAddr2() + JNDINames.splitchar + _obj.getAmdhistLcReimbAddr3() + JNDINames.splitchar + _obj.getAmdhistLcReimbAddr4() + JNDINames.splitchar + _obj.getAmdhistLcReimbAddr5() + JNDINames.splitchar + _obj.getAmdhistLcInstPaying1() + JNDINames.splitchar + _obj.getAmdhistLcInstPaying2() + JNDINames.splitchar + _obj.getAmdhistLcInstPaying3() + JNDINames.splitchar + _obj.getAmdhistLcInstPaying4() + JNDINames.splitchar + _obj.getAmdhistLcInstPaying5() + JNDINames.splitchar + _obj.getAmdhistLcInstPaying6() + JNDINames.splitchar + _obj.getAmdhistLcInstPaying7() + JNDINames.splitchar + _obj.getAmdhistLcInstPaying8() + JNDINames.splitchar + _obj.getAmdhistLcInstPaying9() + JNDINames.splitchar + _obj.getAmdhistLcInstPaying10() + JNDINames.splitchar + _obj.getAmdhistLcInstPaying11() + JNDINames.splitchar + _obj.getAmdhistLcInstPaying12() + JNDINames.splitchar + _obj.getAmdhistLcSecondAdvReq() + JNDINames.splitchar + _obj.getAmdhistLcSecondAdvType() + JNDINames.splitchar + _obj.getAmdhistLcSecondAdvBrnCode() + JNDINames.splitchar + _obj.getAmdhistLcSecondAdvBicCode() + JNDINames.splitchar + _obj.getAmdhistLcSecondAdvRoutid() + JNDINames.splitchar + _obj.getAmdhistLcSecondAdvBnkCode() + JNDINames.splitchar + _obj.getAmdhistLcSecondAdvAddr1() + JNDINames.splitchar + _obj.getAmdhistLcSecondAdvAddr2() + JNDINames.splitchar + _obj.getAmdhistLcSecondAdvAddr3() + JNDINames.splitchar + _obj.getAmdhistLcSecondAdvAddr4() + JNDINames.splitchar + _obj.getAmdhistLcSecondAdvAddr5() + JNDINames.splitchar + _obj.getAmdhistLcSecAdvCntrycode() + JNDINames.splitchar + _obj.getAmendHistLcAvlWithCodetyp() + JNDINames.splitchar + _obj.getAmendhistLcReimbCntryCode() + JNDINames.splitchar + _obj.getAmendhistLcCnfAdvType() + JNDINames.splitchar + _obj.getAmendhistLcCnfAdvBrnCode() + JNDINames.splitchar + _obj.getAmendhistLcCnfAdvBicCode() + JNDINames.splitchar + _obj.getAmendhistLcCnfAdvRoutid() + JNDINames.splitchar + _obj.getAmendhistLcCnfAdvBnkCode() + JNDINames.splitchar + _obj.getAmendhistLcCnfAdvAddr1() + JNDINames.splitchar + _obj.getAmendhistLcCnfAdvAddr2() + JNDINames.splitchar + _obj.getAmendhistLcCnfAdvAddr3() + JNDINames.splitchar + _obj.getAmendhistLcCnfAdvAddr4() + JNDINames.splitchar + _obj.getAmendhistLcCnfAdvAddr5() + JNDINames.splitchar + _obj.getAmendhistLcCnfAdvCntrycode();
        }
            closeConnection(_conn);
            return _obj;
        }
        catch(SQLException e) {
            if(_conn != null)  try { closeConnection(_conn); } catch(SQLException e2) { }
            throw e;
        }
    }

    public AmendDetailsHist loadByKey(java.util.Date _amendhistHistDate, int _amendhistHistSl, int _amendhistLcAmdSl, int _amendhistLcBrnCode, int _amendhistLcSerial, String _amendhistLcType, int _amendhistLcYear, Connection _conn) throws SQLException {
        PreparedStatement _pstmt = null;
        try {
            _pstmt = _conn.prepareStatement("SELECT " + ALL_FIELDS + " FROM AMEND_DETAILS_HIST WHERE AMEND_DETAILS_HIST.AMENDHIST_HIST_DATE=? and AMEND_DETAILS_HIST.AMENDHIST_HIST_SL=? and AMEND_DETAILS_HIST.AMENDHIST_LC_AMD_SL=? and AMEND_DETAILS_HIST.AMENDHIST_LC_BRN_CODE=? and AMEND_DETAILS_HIST.AMENDHIST_LC_SERIAL=? and AMEND_DETAILS_HIST.AMENDHIST_LC_TYPE=? and AMEND_DETAILS_HIST.AMENDHIST_LC_YEAR=?");
            if (_amendhistHistDate == null) {_pstmt.setTimestamp(1, null);} else {_pstmt.setTimestamp(1, new java.sql.Timestamp(_amendhistHistDate.getTime()));}
            _pstmt.setInt(2, _amendhistHistSl);
            _pstmt.setInt(3, _amendhistLcAmdSl);
            _pstmt.setInt(4, _amendhistLcBrnCode);
            _pstmt.setInt(5, _amendhistLcSerial);
            _pstmt.setString(6, _amendhistLcType);
            _pstmt.setInt(7, _amendhistLcYear);
            AmendDetailsHist _list[] = loadByPreparedStatement(_pstmt);
            _pstmt.close();
            if(_list.length < 1) return null;
            else                 return _list[0];
        }
        catch(SQLException e) {
            if(_pstmt != null) try { _pstmt.close(); } catch(SQLException e2) { }
            throw e;
        }
    }

    public AmendDetailsHist[] loadAll() throws SQLException {
        Connection _conn = null;
        try {
            _conn = openConnection();
            AmendDetailsHist _list[] = loadAll(_conn);
            closeConnection(_conn);
            return _list;
        }
        catch(SQLException e) {
            if(_conn != null)  try { closeConnection(_conn); } catch(SQLException e2) { }
            throw e;
        }
    }

    public AmendDetailsHist[] loadAll(Connection _conn) throws SQLException {
        PreparedStatement _pstmt = null;
        try {
            _pstmt = _conn.prepareStatement("SELECT " + ALL_FIELDS + " FROM AMEND_DETAILS_HIST");
            AmendDetailsHist _list[] = loadByPreparedStatement(_pstmt);
            _pstmt.close();
            return _list;
        }
        catch(SQLException e) {
            if(_pstmt != null) try { _pstmt.close(); } catch(SQLException e2) { }
            throw e;
        }
    }

    public AmendDetailsHist[] loadByPreparedStatement(PreparedStatement pstmt) throws SQLException {
        return loadByPreparedStatement(pstmt, null, 0);
    }

    public AmendDetailsHist[] loadByPreparedStatement(PreparedStatement pstmt, int maxRows) throws SQLException {
        return loadByPreparedStatement(pstmt, null, maxRows);
    }

    public AmendDetailsHist[] loadByPreparedStatement(PreparedStatement pstmt, int[] fieldList) throws SQLException {
        return loadByPreparedStatement(pstmt, fieldList, 0);
    }

    public AmendDetailsHist[] loadByPreparedStatement(PreparedStatement pstmt, int[] fieldList, int maxRows) throws SQLException {
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            java.util.Vector v = new java.util.Vector();
            while(rs.next() && (maxRows == 0 || v.size() < maxRows)) {
                if(fieldList == null) v.addElement(decodeRow(rs));
                else v.addElement(decodeRow(rs, fieldList));
            }
            rs.close();
            AmendDetailsHist list[] = new AmendDetailsHist[v.size()];
            v.copyInto(list);
            return list;
        }
        catch(SQLException e) {
            if(rs!=null) try { rs.close();} catch(Exception e2) {}
            throw e;
        }
    }

    public AmendDetailsHist[] loadByWhere(String where) throws SQLException {
        return loadByWhere(where, (int[])null, 0);
    }
    public AmendDetailsHist[] loadByWhere(String where, int maxRows) throws SQLException {
        return loadByWhere(where, (int[])null, maxRows);
    }
    public AmendDetailsHist[] loadByWhere(String where, int[] fieldList) throws SQLException {
        return loadByWhere(where, fieldList, 0);
    }
    public AmendDetailsHist[] loadByWhere(String where, int[] fieldList, int maxRows) throws SQLException {
        Connection conn = null;
        try {
            conn = openConnection();
            AmendDetailsHist _list[] = loadByWhere(where, conn, fieldList, maxRows);
            closeConnection(conn);
            return _list;
        }
        catch(SQLException e) {
            if(conn!=null) try { closeConnection(conn);} catch(Exception e2) {}
            throw e;
        }
    }

    public AmendDetailsHist[] loadByWhere(String where, Connection conn) throws SQLException {
        return loadByWhere(where, conn, null, 0);
    }

    public AmendDetailsHist[] loadByWhere(String where, Connection conn, int[] fieldList) throws SQLException {
        return loadByWhere(where, conn, fieldList, 0);
    }

    public AmendDetailsHist[] loadByWhere(String where, Connection conn, int[] fieldList, int maxRows) throws SQLException {
        String sql = null;
        if(fieldList == null) sql = "select " + ALL_FIELDS + " from AMEND_DETAILS_HIST " + where;
        else {
            StringBuffer buff = new StringBuffer(128);
            buff.append("select ");
            for(int i = 0; i < fieldList.length; i++) {
                if(i != 0) buff.append(",");
                buff.append(S2J_FIELD_NAMES[fieldList[i]]);
            }
            buff.append(" from AMEND_DETAILS_HIST ");
            buff.append(where);
            sql = buff.toString();
        }
        Statement stmt = null;
        ResultSet rs = null;
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            java.util.Vector v = new java.util.Vector();
            while(rs.next() && (maxRows == 0 || v.size() < maxRows)) {
                if(fieldList == null) v.addElement(decodeRow(rs));
                else v.addElement(decodeRow(rs, fieldList));
            }
            rs.close();
            stmt.close();

            AmendDetailsHist _list[] = new AmendDetailsHist[v.size()];
            v.copyInto(_list);
            return _list;
        }
        catch(SQLException e) {
            if(rs!=null) try { rs.close();} catch(Exception e2) {}
            if(stmt!=null) try { stmt.close();} catch(Exception e2) {}
            throw e;
        }
    }

    public int UpdateByQuery(String w_sql) throws SQLException {
        Connection _conn = null;
        PreparedStatement _pstmt = null;
            try {
                _conn = openConnection();
                _pstmt = _conn.prepareStatement(w_sql);
                int _rows = _pstmt.executeUpdate();
                closeConnection(_conn);
                return 1;
            }
            catch(SQLException e) {
                if(_pstmt!=null) try { _pstmt.close();} catch(Exception e2) {}
                if(_conn!=null) try { closeConnection(_conn);} catch(Exception e2) {}
                throw e;
            }
    }
    public int deleteByKey(java.util.Date _amendhistHistDate, int _amendhistHistSl, int _amendhistLcAmdSl, int _amendhistLcBrnCode, int _amendhistLcSerial, String _amendhistLcType, int _amendhistLcYear) throws SQLException {
        Connection _conn = null;
        try {
            _conn = openConnection();
            int _rows = deleteByKey(_amendhistHistDate, _amendhistHistSl, _amendhistLcAmdSl, _amendhistLcBrnCode, _amendhistLcSerial, _amendhistLcType, _amendhistLcYear, _conn);
            closeConnection(_conn);
            return _rows;
        }
        catch(SQLException e) {
            if(_conn!=null) try { closeConnection(_conn);} catch(Exception e2) {}
            throw e;
        }
    }

    public int deleteByKey(java.util.Date _amendhistHistDate, int _amendhistHistSl, int _amendhistLcAmdSl, int _amendhistLcBrnCode, int _amendhistLcSerial, String _amendhistLcType, int _amendhistLcYear, Connection _conn) throws SQLException {
        PreparedStatement _pstmt = null;
        try {
        AmendDetailsHist _obj  = loadByKey(_amendhistHistDate, _amendhistHistSl, _amendhistLcAmdSl, _amendhistLcBrnCode, _amendhistLcSerial, _amendhistLcType, _amendhistLcYear);
        _obj  = null;
            _pstmt = _conn.prepareStatement("DELETE FROM AMEND_DETAILS_HIST WHERE AMEND_DETAILS_HIST.AMENDHIST_HIST_DATE=? and AMEND_DETAILS_HIST.AMENDHIST_HIST_SL=? and AMEND_DETAILS_HIST.AMENDHIST_LC_AMD_SL=? and AMEND_DETAILS_HIST.AMENDHIST_LC_BRN_CODE=? and AMEND_DETAILS_HIST.AMENDHIST_LC_SERIAL=? and AMEND_DETAILS_HIST.AMENDHIST_LC_TYPE=? and AMEND_DETAILS_HIST.AMENDHIST_LC_YEAR=?");
            if (_amendhistHistDate == null) {_pstmt.setTimestamp(1, null);} else {_pstmt.setTimestamp(1, new java.sql.Timestamp(_amendhistHistDate.getTime()));}
            _pstmt.setInt(2, _amendhistHistSl);
            _pstmt.setInt(3, _amendhistLcAmdSl);
            _pstmt.setInt(4, _amendhistLcBrnCode);
            _pstmt.setInt(5, _amendhistLcSerial);
            _pstmt.setString(6, _amendhistLcType);
            _pstmt.setInt(7, _amendhistLcYear);
            int _rows = _pstmt.executeUpdate();
            _pstmt.close();
            return _rows;
        }
        catch(SQLException e) {
            if(_pstmt!=null) try { _pstmt.close();} catch(Exception e2) {}
            throw e;
        }
    }

    public void save(AmendDetailsHist obj) throws SQLException {
//        _srcTablePKI = "AMENDDETAILSHIST";
//        _srcKeyPKI = obj.getAmendhistLcBrnCode() + JNDINames.splitchar + obj.getAmendhistLcType() + JNDINames.splitchar + obj.getAmendhistLcYear() + JNDINames.splitchar + obj.getAmendhistLcSerial() + JNDINames.splitchar + obj.getAmendhistLcAmdSl() + JNDINames.splitchar + obj.getAmendhistHistSl() + JNDINames.splitchar + obj.getAmendhistHistDate();
//        set_pki_values(this._COLLECTIONobj);
        if(!obj.isModifiedS2J()) return;
        Connection _conn = null;
        try {
            _conn = openConnection();
            save(obj, _conn);
            closeConnection(_conn);
        }
        catch(SQLException e) {
            if(_conn!=null) try { closeConnection(_conn);} catch(Exception e2) {}
            throw e;
        }
    }

    public void save(AmendDetailsHist obj, Connection _conn) throws SQLException {
        PreparedStatement _pstmt = null;
        try {
            if(obj.isNew()) {
                int _dirtyCount = 0;
                StringBuffer _sql = new StringBuffer("INSERT into AMEND_DETAILS_HIST (");
                if(obj.amendhistLcBrnCodeIsModifiedS2j()) {  _sql.append("AMENDHIST_LC_BRN_CODE").append(","); _dirtyCount++; }
                if(obj.amendhistLcTypeIsModifiedS2j()) {  _sql.append("AMENDHIST_LC_TYPE").append(","); _dirtyCount++; }
                if(obj.amendhistLcYearIsModifiedS2j()) {  _sql.append("AMENDHIST_LC_YEAR").append(","); _dirtyCount++; }
                if(obj.amendhistLcSerialIsModifiedS2j()) {  _sql.append("AMENDHIST_LC_SERIAL").append(","); _dirtyCount++; }
                if(obj.amendhistLcAmdSlIsModifiedS2j()) {  _sql.append("AMENDHIST_LC_AMD_SL").append(","); _dirtyCount++; }
                if(obj.amendhistHistSlIsModifiedS2j()) {  _sql.append("AMENDHIST_HIST_SL").append(","); _dirtyCount++; }
                if(obj.amendhistHistDateIsModifiedS2j()) {  _sql.append("AMENDHIST_HIST_DATE").append(","); _dirtyCount++; }
                if(obj.amendhistSndrRefIsModifiedS2j()) {  _sql.append("AMENDHIST_SNDR_REF").append(","); _dirtyCount++; }
                if(obj.amendhistRcvrRefIsModifiedS2j()) {  _sql.append("AMENDHIST_RCVR_REF").append(","); _dirtyCount++; }
                if(obj.amendhistDocCrNumIsModifiedS2j()) {  _sql.append("AMENDHIST_DOC_CR_NUM").append(","); _dirtyCount++; }
                if(obj.amendhistIssuingBnkReqIsModifiedS2j()) {  _sql.append("AMENDHIST_ISSUING_BNK_REQ").append(","); _dirtyCount++; }
                if(obj.amendhistIssuingTypeIsModifiedS2j()) {  _sql.append("AMENDHIST_ISSUING_TYPE").append(","); _dirtyCount++; }
                if(obj.amendhistIssuingBrnCodeIsModifiedS2j()) {  _sql.append("AMENDHIST_ISSUING_BRN_CODE").append(","); _dirtyCount++; }
                if(obj.amendhistIssuingBicCodeIsModifiedS2j()) {  _sql.append("AMENDHIST_ISSUING_BIC_CODE").append(","); _dirtyCount++; }
                if(obj.amendhistIssuingRoutidIsModifiedS2j()) {  _sql.append("AMENDHIST_ISSUING_ROUTID").append(","); _dirtyCount++; }
                if(obj.amendhistIssuingBnkCodeIsModifiedS2j()) {  _sql.append("AMENDHIST_ISSUING_BNK_CODE").append(","); _dirtyCount++; }
                if(obj.amendhistIssuingAddr1IsModifiedS2j()) {  _sql.append("AMENDHIST_ISSUING_ADDR1").append(","); _dirtyCount++; }
                if(obj.amendhistIssuingAddr2IsModifiedS2j()) {  _sql.append("AMENDHIST_ISSUING_ADDR2").append(","); _dirtyCount++; }
                if(obj.amendhistIssuingAddr3IsModifiedS2j()) {  _sql.append("AMENDHIST_ISSUING_ADDR3").append(","); _dirtyCount++; }
                if(obj.amendhistIssuingAddr4IsModifiedS2j()) {  _sql.append("AMENDHIST_ISSUING_ADDR4").append(","); _dirtyCount++; }
                if(obj.amendhistIssuingAddr5IsModifiedS2j()) {  _sql.append("AMENDHIST_ISSUING_ADDR5").append(","); _dirtyCount++; }
                if(obj.amendhistNonBnkIssurIsModifiedS2j()) {  _sql.append("AMENDHIST_NON_BNK_ISSUR").append(","); _dirtyCount++; }
                if(obj.amendhistDateOfIssueIsModifiedS2j()) {  _sql.append("AMENDHIST_DATE_OF_ISSUE").append(","); _dirtyCount++; }
                if(obj.amendhistDateOfAmendmntIsModifiedS2j()) {  _sql.append("AMENDHIST_DATE_OF_AMENDMNT").append(","); _dirtyCount++; }
                if(obj.amendhistPurposeOfMsgIsModifiedS2j()) {  _sql.append("AMENDHIST_PURPOSE_OF_MSG").append(","); _dirtyCount++; }
                if(obj.amendhistCancelRequestIsModifiedS2j()) {  _sql.append("AMENDHIST_CANCEL_REQUEST").append(","); _dirtyCount++; }
                if(obj.amendhistAdvisingBnkReqIsModifiedS2j()) {  _sql.append("AMENDHIST_ADVISING_BNK_REQ").append(","); _dirtyCount++; }
                if(obj.amendhistAdvisingBnkTypeIsModifiedS2j()) {  _sql.append("AMENDHIST_ADVISING_BNK_TYPE").append(","); _dirtyCount++; }
                if(obj.amendhistAdvisingBrnCodeIsModifiedS2j()) {  _sql.append("AMENDHIST_ADVISING_BRN_CODE").append(","); _dirtyCount++; }
                if(obj.amendhistAdvisingBicCodeIsModifiedS2j()) {  _sql.append("AMENDHIST_ADVISING_BIC_CODE").append(","); _dirtyCount++; }
                if(obj.amendhistAdvisingRoutidIsModifiedS2j()) {  _sql.append("AMENDHIST_ADVISING_ROUTID").append(","); _dirtyCount++; }
                if(obj.amendhistAdvisingBnkCodeIsModifiedS2j()) {  _sql.append("AMENDHIST_ADVISING_BNK_CODE").append(","); _dirtyCount++; }
                if(obj.amendhistAdvisingAddr1IsModifiedS2j()) {  _sql.append("AMENDHIST_ADVISING_ADDR1").append(","); _dirtyCount++; }
                if(obj.amendhistAdvisingAddr2IsModifiedS2j()) {  _sql.append("AMENDHIST_ADVISING_ADDR2").append(","); _dirtyCount++; }
                if(obj.amendhistAdvisingAddr3IsModifiedS2j()) {  _sql.append("AMENDHIST_ADVISING_ADDR3").append(","); _dirtyCount++; }
                if(obj.amendhistAdvisingAddr4IsModifiedS2j()) {  _sql.append("AMENDHIST_ADVISING_ADDR4").append(","); _dirtyCount++; }
                if(obj.amendhistAdvisingAddr5IsModifiedS2j()) {  _sql.append("AMENDHIST_ADVISING_ADDR5").append(","); _dirtyCount++; }
                if(obj.amendhistSecondAdvReqIsModifiedS2j()) {  _sql.append("AMENDHIST_SECOND_ADV_REQ").append(","); _dirtyCount++; }
                if(obj.amendhistSecondAdvTypeIsModifiedS2j()) {  _sql.append("AMENDHIST_SECOND_ADV_TYPE").append(","); _dirtyCount++; }
                if(obj.amendhistSecondAdvBrnCodeIsModifiedS2j()) {  _sql.append("AMENDHIST_SECOND_ADV_BRN_CODE").append(","); _dirtyCount++; }
                if(obj.amendhistSecondAdvBicCodeIsModifiedS2j()) {  _sql.append("AMENDHIST_SECOND_ADV_BIC_CODE").append(","); _dirtyCount++; }
                if(obj.amendhistSecondAdvRoutidIsModifiedS2j()) {  _sql.append("AMENDHIST_SECOND_ADV_ROUTID").append(","); _dirtyCount++; }
                if(obj.amendhistSecondAdvBnkCodeIsModifiedS2j()) {  _sql.append("AMENDHIST_SECOND_ADV_BNK_CODE").append(","); _dirtyCount++; }
                if(obj.amendhistSecondAdvAddr1IsModifiedS2j()) {  _sql.append("AMENDHIST_SECOND_ADV_ADDR1").append(","); _dirtyCount++; }
                if(obj.amendhistSecondAdvAddr2IsModifiedS2j()) {  _sql.append("AMENDHIST_SECOND_ADV_ADDR2").append(","); _dirtyCount++; }
                if(obj.amendhistSecondAdvAddr3IsModifiedS2j()) {  _sql.append("AMENDHIST_SECOND_ADV_ADDR3").append(","); _dirtyCount++; }
                if(obj.amendhistSecondAdvAddr4IsModifiedS2j()) {  _sql.append("AMENDHIST_SECOND_ADV_ADDR4").append(","); _dirtyCount++; }
                if(obj.amendhistSecondAdvAddr5IsModifiedS2j()) {  _sql.append("AMENDHIST_SECOND_ADV_ADDR5").append(","); _dirtyCount++; }
                if(obj.amendhistNewBeneficiaryIsModifiedS2j()) {  _sql.append("AMENDHIST_NEW_BENEFICIARY").append(","); _dirtyCount++; }
                if(obj.amendhistNewDateOfExpiryIsModifiedS2j()) {  _sql.append("AMENDHIST_NEW_DATE_OF_EXPIRY").append(","); _dirtyCount++; }
                if(obj.amendhistIncrDocCrAmtIsModifiedS2j()) {  _sql.append("AMENDHIST_INCR_DOC_CR_AMT").append(","); _dirtyCount++; }
                if(obj.amendhistDecrDocCrAmtIsModifiedS2j()) {  _sql.append("AMENDHIST_DECR_DOC_CR_AMT").append(","); _dirtyCount++; }
                if(obj.amendhistNewAddnlAmtIsModifiedS2j()) {  _sql.append("AMENDHIST_NEW_ADDNL_AMT").append(","); _dirtyCount++; }
                if(obj.amendhistPlaceTakinInChrgIsModifiedS2j()) {  _sql.append("AMENDHIST_PLACE_TAKIN_IN_CHRG").append(","); _dirtyCount++; }
                if(obj.amendhistPortOfLoadingIsModifiedS2j()) {  _sql.append("AMENDHIST_PORT_OF_LOADING").append(","); _dirtyCount++; }
                if(obj.amendhistPortOfDischargeIsModifiedS2j()) {  _sql.append("AMENDHIST_PORT_OF_DISCHARGE").append(","); _dirtyCount++; }
                if(obj.amendhistPlaceOfFinalDestIsModifiedS2j()) {  _sql.append("AMENDHIST_PLACE_OF_FINAL_DEST").append(","); _dirtyCount++; }
                if(obj.amendhistDateOfShipmentIsModifiedS2j()) {  _sql.append("AMENDHIST_DATE_OF_SHIPMENT").append(","); _dirtyCount++; }
                if(obj.amendhistDescGoddSer1IsModifiedS2j()) {  _sql.append("AMENDHIST_DESC_GODD_SER1").append(","); _dirtyCount++; }
                if(obj.amendhistDocReq1IsModifiedS2j()) {  _sql.append("AMENDHIST_DOC_REQ1").append(","); _dirtyCount++; }
                if(obj.amendhistAddCondition1IsModifiedS2j()) {  _sql.append("AMENDHIST_ADD_CONDITION1").append(","); _dirtyCount++; }
                if(obj.amendhistChrgPayable1IsModifiedS2j()) {  _sql.append("AMENDHIST_CHRG_PAYABLE1").append(","); _dirtyCount++; }
                if(obj.amendhistChrgPayable2IsModifiedS2j()) {  _sql.append("AMENDHIST_CHRG_PAYABLE2").append(","); _dirtyCount++; }
                if(obj.amendhistChrgPayable3IsModifiedS2j()) {  _sql.append("AMENDHIST_CHRG_PAYABLE3").append(","); _dirtyCount++; }
                if(obj.amendhistChrgPayable4IsModifiedS2j()) {  _sql.append("AMENDHIST_CHRG_PAYABLE4").append(","); _dirtyCount++; }
                if(obj.amendhistChrgPayable5IsModifiedS2j()) {  _sql.append("AMENDHIST_CHRG_PAYABLE5").append(","); _dirtyCount++; }
                if(obj.amendhistChrgPayable6IsModifiedS2j()) {  _sql.append("AMENDHIST_CHRG_PAYABLE6").append(","); _dirtyCount++; }
                if(obj.amendhistSndrRecInfo1IsModifiedS2j()) {  _sql.append("AMENDHIST_SNDR_REC_INFO1").append(","); _dirtyCount++; }
                if(obj.amendhistSndrRecInfo2IsModifiedS2j()) {  _sql.append("AMENDHIST_SNDR_REC_INFO2").append(","); _dirtyCount++; }
                if(obj.amendhistSndrRecInfo3IsModifiedS2j()) {  _sql.append("AMENDHIST_SNDR_REC_INFO3").append(","); _dirtyCount++; }
                if(obj.amendhistSndrRecInfo4IsModifiedS2j()) {  _sql.append("AMENDHIST_SNDR_REC_INFO4").append(","); _dirtyCount++; }
                if(obj.amendhistSndrRecInfo5IsModifiedS2j()) {  _sql.append("AMENDHIST_SNDR_REC_INFO5").append(","); _dirtyCount++; }
                if(obj.amendhistSndrRecInfo6IsModifiedS2j()) {  _sql.append("AMENDHIST_SNDR_REC_INFO6").append(","); _dirtyCount++; }
                if(obj.amendhistChkboxIsModifiedS2j()) {  _sql.append("AMENDHIST_CHKBOX").append(","); _dirtyCount++; }
                if(obj.amendhistIssuingCntryIsModifiedS2j()) {  _sql.append("AMENDHIST_ISSUING_CNTRY").append(","); _dirtyCount++; }
                if(obj.amendhistAdvisingCntryIsModifiedS2j()) {  _sql.append("AMENDHIST_ADVISING_CNTRY").append(","); _dirtyCount++; }
                if(obj.amendhistSecondAdvCntryIsModifiedS2j()) {  _sql.append("AMENDHIST_SECOND_ADV_CNTRY").append(","); _dirtyCount++; }
                if(obj.amendhistIssueRefIsModifiedS2j()) {  _sql.append("AMENDHIST_ISSUE_REF").append(","); _dirtyCount++; }
                if(obj.amdhistFormOfDocCreditIsModifiedS2j()) {  _sql.append("AMDHIST_FORM_OF_DOC_CREDIT").append(","); _dirtyCount++; }
                if(obj.amdhistLcApplicableRulesIsModifiedS2j()) {  _sql.append("AMDHIST_LC_APPLICABLE_RULES").append(","); _dirtyCount++; }
                if(obj.amdhistLcApplReqIsModifiedS2j()) {  _sql.append("AMDHIST_LC_APPL_REQ").append(","); _dirtyCount++; }
                if(obj.amdhistLcApplNameIsModifiedS2j()) {  _sql.append("AMDHIST_LC_APPL_NAME").append(","); _dirtyCount++; }
                if(obj.amdhistLcApplAddr1IsModifiedS2j()) {  _sql.append("AMDHIST_LC_APPL_ADDR1").append(","); _dirtyCount++; }
                if(obj.amdhistLcApplAddr2IsModifiedS2j()) {  _sql.append("AMDHIST_LC_APPL_ADDR2").append(","); _dirtyCount++; }
                if(obj.amdhistLcApplAddr3IsModifiedS2j()) {  _sql.append("AMDHIST_LC_APPL_ADDR3").append(","); _dirtyCount++; }
                if(obj.amdhistLcApplAddr4IsModifiedS2j()) {  _sql.append("AMDHIST_LC_APPL_ADDR4").append(","); _dirtyCount++; }
                if(obj.amdhistLcApplAddr5IsModifiedS2j()) {  _sql.append("AMDHIST_LC_APPL_ADDR5").append(","); _dirtyCount++; }
                if(obj.amdhistLcAvlWithTypeIsModifiedS2j()) {  _sql.append("AMDHIST_LC_AVL_WITH_TYPE").append(","); _dirtyCount++; }
                if(obj.amdhistLcAvlWithBrnCodeIsModifiedS2j()) {  _sql.append("AMDHIST_LC_AVL_WITH_BRN_CODE").append(","); _dirtyCount++; }
                if(obj.amdhistLcAvlWithBicCodeIsModifiedS2j()) {  _sql.append("AMDHIST_LC_AVL_WITH_BIC_CODE").append(","); _dirtyCount++; }
                if(obj.amdhistLcLcAvlWithRoutidIsModifiedS2j()) {  _sql.append("AMDHIST_LC_LC_AVL_WITH_ROUTID").append(","); _dirtyCount++; }
                if(obj.amdhistLcAvlWithBnkCodeIsModifiedS2j()) {  _sql.append("AMDHIST_LC_AVL_WITH_BNK_CODE").append(","); _dirtyCount++; }
                if(obj.amdhistLcAvlWithAddr1IsModifiedS2j()) {  _sql.append("AMDHIST_LC_AVL_WITH_ADDR1").append(","); _dirtyCount++; }
                if(obj.amdhistLcAvlWithAddr2IsModifiedS2j()) {  _sql.append("AMDHIST_LC_AVL_WITH_ADDR2").append(","); _dirtyCount++; }
                if(obj.amdhistLcAvlWithAddr3IsModifiedS2j()) {  _sql.append("AMDHIST_LC_AVL_WITH_ADDR3").append(","); _dirtyCount++; }
                if(obj.amdhistLcAvlWithAddr4IsModifiedS2j()) {  _sql.append("AMDHIST_LC_AVL_WITH_ADDR4").append(","); _dirtyCount++; }
                if(obj.amdhistLcAvlWithAddr5IsModifiedS2j()) {  _sql.append("AMDHIST_LC_AVL_WITH_ADDR5").append(","); _dirtyCount++; }
                if(obj.amdhistLcAvlWithCntryIsModifiedS2j()) {  _sql.append("AMDHIST_LC_AVL_WITH_CNTRY").append(","); _dirtyCount++; }
                if(obj.amdhistLcDraftsAt1IsModifiedS2j()) {  _sql.append("AMDHIST_LC_DRAFTS_AT1").append(","); _dirtyCount++; }
                if(obj.amdhistLcDraftsAt2IsModifiedS2j()) {  _sql.append("AMDHIST_LC_DRAFTS_AT2").append(","); _dirtyCount++; }
                if(obj.amdhistLcDraftsAt3IsModifiedS2j()) {  _sql.append("AMDHIST_LC_DRAFTS_AT3").append(","); _dirtyCount++; }
                if(obj.amdhistLcDraweeReqIsModifiedS2j()) {  _sql.append("AMDHIST_LC_DRAWEE_REQ").append(","); _dirtyCount++; }
                if(obj.amdhistLcDraweeTypeIsModifiedS2j()) {  _sql.append("AMDHIST_LC_DRAWEE_TYPE").append(","); _dirtyCount++; }
                if(obj.amdhistLcDraweeBrnCodeIsModifiedS2j()) {  _sql.append("AMDHIST_LC_DRAWEE_BRN_CODE").append(","); _dirtyCount++; }
                if(obj.amdhistLcDraweeBicCodeIsModifiedS2j()) {  _sql.append("AMDHIST_LC_DRAWEE_BIC_CODE").append(","); _dirtyCount++; }
                if(obj.amdhistLcDraweeRoutidIsModifiedS2j()) {  _sql.append("AMDHIST_LC_DRAWEE_ROUTID").append(","); _dirtyCount++; }
                if(obj.amdhistLcDraweeBnkCodeIsModifiedS2j()) {  _sql.append("AMDHIST_LC_DRAWEE_BNK_CODE").append(","); _dirtyCount++; }
                if(obj.amdhistLcDraweeAddr1IsModifiedS2j()) {  _sql.append("AMDHIST_LC_DRAWEE_ADDR1").append(","); _dirtyCount++; }
                if(obj.amdhistLcDraweeAddr2IsModifiedS2j()) {  _sql.append("AMDHIST_LC_DRAWEE_ADDR2").append(","); _dirtyCount++; }
                if(obj.amdhistLcDraweeAddr3IsModifiedS2j()) {  _sql.append("AMDHIST_LC_DRAWEE_ADDR3").append(","); _dirtyCount++; }
                if(obj.amdhistLcDraweeAddr4IsModifiedS2j()) {  _sql.append("AMDHIST_LC_DRAWEE_ADDR4").append(","); _dirtyCount++; }
                if(obj.amdhistLcDraweeAddr5IsModifiedS2j()) {  _sql.append("AMDHIST_LC_DRAWEE_ADDR5").append(","); _dirtyCount++; }
                if(obj.amdhistDraweeCntryCodeIsModifiedS2j()) {  _sql.append("AMDHIST_DRAWEE_CNTRY_CODE").append(","); _dirtyCount++; }
                if(obj.amdhistLcMixedPayDetails1IsModifiedS2j()) {  _sql.append("AMDHIST_LC_MIXED_PAY_DETAILS1").append(","); _dirtyCount++; }
                if(obj.amdhistLcMixedPayDetails2IsModifiedS2j()) {  _sql.append("AMDHIST_LC_MIXED_PAY_DETAILS2").append(","); _dirtyCount++; }
                if(obj.amdhistLcMixedPayDetails3IsModifiedS2j()) {  _sql.append("AMDHIST_LC_MIXED_PAY_DETAILS3").append(","); _dirtyCount++; }
                if(obj.amdhistLcMixedPayDetails4IsModifiedS2j()) {  _sql.append("AMDHIST_LC_MIXED_PAY_DETAILS4").append(","); _dirtyCount++; }
                if(obj.amdhistLcMixedPayDetails5IsModifiedS2j()) {  _sql.append("AMDHIST_LC_MIXED_PAY_DETAILS5").append(","); _dirtyCount++; }
                if(obj.amdhistLcDefPayDetails1IsModifiedS2j()) {  _sql.append("AMDHIST_LC_DEF_PAY_DETAILS1").append(","); _dirtyCount++; }
                if(obj.amdhistLcDefPayDetails2IsModifiedS2j()) {  _sql.append("AMDHIST_LC_DEF_PAY_DETAILS2").append(","); _dirtyCount++; }
                if(obj.amdhistLcDefPayDetails3IsModifiedS2j()) {  _sql.append("AMDHIST_LC_DEF_PAY_DETAILS3").append(","); _dirtyCount++; }
                if(obj.amdhistLcDefPayDetails4IsModifiedS2j()) {  _sql.append("AMDHIST_LC_DEF_PAY_DETAILS4").append(","); _dirtyCount++; }
                if(obj.amdhistLcDefPayDetails5IsModifiedS2j()) {  _sql.append("AMDHIST_LC_DEF_PAY_DETAILS5").append(","); _dirtyCount++; }
                if(obj.amdhistLcPartialShipmentsIsModifiedS2j()) {  _sql.append("AMDHIST_LC_PARTIAL_SHIPMENTS").append(","); _dirtyCount++; }
                if(obj.amdhistLcTranshipmentIsModifiedS2j()) {  _sql.append("AMDHIST_LC_TRANSHIPMENT").append(","); _dirtyCount++; }
                if(obj.amdhistLcConfirmationInstIsModifiedS2j()) {  _sql.append("AMDHIST_LC_CONFIRMATION_INST").append(","); _dirtyCount++; }
                if(obj.amdhistLcReimbReqIsModifiedS2j()) {  _sql.append("AMDHIST_LC_REIMB_REQ").append(","); _dirtyCount++; }
                if(obj.amdhistLcReimbTypeIsModifiedS2j()) {  _sql.append("AMDHIST_LC_REIMB_TYPE").append(","); _dirtyCount++; }
                if(obj.amdhistLcReimbBrnCodeIsModifiedS2j()) {  _sql.append("AMDHIST_LC_REIMB_BRN_CODE").append(","); _dirtyCount++; }
                if(obj.amdhistLcReimbBicCodeIsModifiedS2j()) {  _sql.append("AMDHIST_LC_REIMB_BIC_CODE").append(","); _dirtyCount++; }
                if(obj.amdhistLcReimbRoutidIsModifiedS2j()) {  _sql.append("AMDHIST_LC_REIMB_ROUTID").append(","); _dirtyCount++; }
                if(obj.amdhistLcReimbBnkCodeIsModifiedS2j()) {  _sql.append("AMDHIST_LC_REIMB_BNK_CODE").append(","); _dirtyCount++; }
                if(obj.amdhistLcReimbAddr1IsModifiedS2j()) {  _sql.append("AMDHIST_LC_REIMB_ADDR1").append(","); _dirtyCount++; }
                if(obj.amdhistLcReimbAddr2IsModifiedS2j()) {  _sql.append("AMDHIST_LC_REIMB_ADDR2").append(","); _dirtyCount++; }
                if(obj.amdhistLcReimbAddr3IsModifiedS2j()) {  _sql.append("AMDHIST_LC_REIMB_ADDR3").append(","); _dirtyCount++; }
                if(obj.amdhistLcReimbAddr4IsModifiedS2j()) {  _sql.append("AMDHIST_LC_REIMB_ADDR4").append(","); _dirtyCount++; }
                if(obj.amdhistLcReimbAddr5IsModifiedS2j()) {  _sql.append("AMDHIST_LC_REIMB_ADDR5").append(","); _dirtyCount++; }
                if(obj.amdhistLcInstPaying1IsModifiedS2j()) {  _sql.append("AMDHIST_LC_INST_PAYING1").append(","); _dirtyCount++; }
                if(obj.amdhistLcInstPaying2IsModifiedS2j()) {  _sql.append("AMDHIST_LC_INST_PAYING2").append(","); _dirtyCount++; }
                if(obj.amdhistLcInstPaying3IsModifiedS2j()) {  _sql.append("AMDHIST_LC_INST_PAYING3").append(","); _dirtyCount++; }
                if(obj.amdhistLcInstPaying4IsModifiedS2j()) {  _sql.append("AMDHIST_LC_INST_PAYING4").append(","); _dirtyCount++; }
                if(obj.amdhistLcInstPaying5IsModifiedS2j()) {  _sql.append("AMDHIST_LC_INST_PAYING5").append(","); _dirtyCount++; }
                if(obj.amdhistLcInstPaying6IsModifiedS2j()) {  _sql.append("AMDHIST_LC_INST_PAYING6").append(","); _dirtyCount++; }
                if(obj.amdhistLcInstPaying7IsModifiedS2j()) {  _sql.append("AMDHIST_LC_INST_PAYING7").append(","); _dirtyCount++; }
                if(obj.amdhistLcInstPaying8IsModifiedS2j()) {  _sql.append("AMDHIST_LC_INST_PAYING8").append(","); _dirtyCount++; }
                if(obj.amdhistLcInstPaying9IsModifiedS2j()) {  _sql.append("AMDHIST_LC_INST_PAYING9").append(","); _dirtyCount++; }
                if(obj.amdhistLcInstPaying10IsModifiedS2j()) {  _sql.append("AMDHIST_LC_INST_PAYING10").append(","); _dirtyCount++; }
                if(obj.amdhistLcInstPaying11IsModifiedS2j()) {  _sql.append("AMDHIST_LC_INST_PAYING11").append(","); _dirtyCount++; }
                if(obj.amdhistLcInstPaying12IsModifiedS2j()) {  _sql.append("AMDHIST_LC_INST_PAYING12").append(","); _dirtyCount++; }
                if(obj.amdhistLcSecondAdvReqIsModifiedS2j()) {  _sql.append("AMDHIST_LC_SECOND_ADV_REQ").append(","); _dirtyCount++; }
                if(obj.amdhistLcSecondAdvTypeIsModifiedS2j()) {  _sql.append("AMDHIST_LC_SECOND_ADV_TYPE").append(","); _dirtyCount++; }
                if(obj.amdhistLcSecondAdvBrnCodeIsModifiedS2j()) {  _sql.append("AMDHIST_LC_SECOND_ADV_BRN_CODE").append(","); _dirtyCount++; }
                if(obj.amdhistLcSecondAdvBicCodeIsModifiedS2j()) {  _sql.append("AMDHIST_LC_SECOND_ADV_BIC_CODE").append(","); _dirtyCount++; }
                if(obj.amdhistLcSecondAdvRoutidIsModifiedS2j()) {  _sql.append("AMDHIST_LC_SECOND_ADV_ROUTID").append(","); _dirtyCount++; }
                if(obj.amdhistLcSecondAdvBnkCodeIsModifiedS2j()) {  _sql.append("AMDHIST_LC_SECOND_ADV_BNK_CODE").append(","); _dirtyCount++; }
                if(obj.amdhistLcSecondAdvAddr1IsModifiedS2j()) {  _sql.append("AMDHIST_LC_SECOND_ADV_ADDR1").append(","); _dirtyCount++; }
                if(obj.amdhistLcSecondAdvAddr2IsModifiedS2j()) {  _sql.append("AMDHIST_LC_SECOND_ADV_ADDR2").append(","); _dirtyCount++; }
                if(obj.amdhistLcSecondAdvAddr3IsModifiedS2j()) {  _sql.append("AMDHIST_LC_SECOND_ADV_ADDR3").append(","); _dirtyCount++; }
                if(obj.amdhistLcSecondAdvAddr4IsModifiedS2j()) {  _sql.append("AMDHIST_LC_SECOND_ADV_ADDR4").append(","); _dirtyCount++; }
                if(obj.amdhistLcSecondAdvAddr5IsModifiedS2j()) {  _sql.append("AMDHIST_LC_SECOND_ADV_ADDR5").append(","); _dirtyCount++; }
                if(obj.amdhistLcSecAdvCntrycodeIsModifiedS2j()) {  _sql.append("AMDHIST_LC_SEC_ADV_CNTRYCODE").append(","); _dirtyCount++; }
                if(obj.amendHistLcAvlWithCodetypIsModifiedS2j()) {  _sql.append("AMEND_HIST_LC_AVL_WITH_CODETYP").append(","); _dirtyCount++; }
                if(obj.amendhistLcReimbCntryCodeIsModifiedS2j()) {  _sql.append("AMENDHIST_LC_REIMB_CNTRY_CODE").append(","); _dirtyCount++; }
                if(obj.amendhistLcCnfAdvTypeIsModifiedS2j()) {  _sql.append("AMENDHIST_LC_CNF_ADV_TYPE").append(","); _dirtyCount++; }
                if(obj.amendhistLcCnfAdvBrnCodeIsModifiedS2j()) {  _sql.append("AMENDHIST_LC_CNF_ADV_BRN_CODE").append(","); _dirtyCount++; }
                if(obj.amendhistLcCnfAdvBicCodeIsModifiedS2j()) {  _sql.append("AMENDHIST_LC_CNF_ADV_BIC_CODE").append(","); _dirtyCount++; }
                if(obj.amendhistLcCnfAdvRoutidIsModifiedS2j()) {  _sql.append("AMENDHIST_LC_CNF_ADV_ROUTID").append(","); _dirtyCount++; }
                if(obj.amendhistLcCnfAdvBnkCodeIsModifiedS2j()) {  _sql.append("AMENDHIST_LC_CNF_ADV_BNK_CODE").append(","); _dirtyCount++; }
                if(obj.amendhistLcCnfAdvAddr1IsModifiedS2j()) {  _sql.append("AMENDHIST_LC_CNF_ADV_ADDR1").append(","); _dirtyCount++; }
                if(obj.amendhistLcCnfAdvAddr2IsModifiedS2j()) {  _sql.append("AMENDHIST_LC_CNF_ADV_ADDR2").append(","); _dirtyCount++; }
                if(obj.amendhistLcCnfAdvAddr3IsModifiedS2j()) {  _sql.append("AMENDHIST_LC_CNF_ADV_ADDR3").append(","); _dirtyCount++; }
                if(obj.amendhistLcCnfAdvAddr4IsModifiedS2j()) {  _sql.append("AMENDHIST_LC_CNF_ADV_ADDR4").append(","); _dirtyCount++; }
                if(obj.amendhistLcCnfAdvAddr5IsModifiedS2j()) {  _sql.append("AMENDHIST_LC_CNF_ADV_ADDR5").append(","); _dirtyCount++; }
                if(obj.amendhistLcCnfAdvCntrycodeIsModifiedS2j()) {  _sql.append("AMENDHIST_LC_CNF_ADV_CNTRYCODE").append(","); _dirtyCount++; }
                _sql.setLength(_sql.length() - 1);
                _sql.append(") values (" );
                for(int i = 0; i < _dirtyCount; i++) _sql.append("?,");
                _sql.setLength(_sql.length() - 1);
                _sql.append(")");

                _pstmt = _conn.prepareStatement(_sql.toString());
                _dirtyCount = 0;
                if(obj.amendhistLcBrnCodeIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendhistLcBrnCode()); } 
                if(obj.amendhistLcTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistLcType()); } 
                if(obj.amendhistLcYearIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendhistLcYear()); } 
                if(obj.amendhistLcSerialIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendhistLcSerial()); } 
                if(obj.amendhistLcAmdSlIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendhistLcAmdSl()); } 
                if(obj.amendhistHistSlIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendhistHistSl()); } 
                if(obj.amendhistHistDateIsModifiedS2j()) { if (obj.getAmendhistHistDate() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getAmendhistHistDate().getTime()));} } 
                if(obj.amendhistSndrRefIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistSndrRef()); } 
                if(obj.amendhistRcvrRefIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistRcvrRef()); } 
                if(obj.amendhistDocCrNumIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistDocCrNum()); } 
                if(obj.amendhistIssuingBnkReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendhistIssuingBnkReq())); } 
                if(obj.amendhistIssuingTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendhistIssuingType())); } 
                if(obj.amendhistIssuingBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistIssuingBrnCode()); } 
                if(obj.amendhistIssuingBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistIssuingBicCode()); } 
                if(obj.amendhistIssuingRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistIssuingRoutid()); } 
                if(obj.amendhistIssuingBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistIssuingBnkCode()); } 
                if(obj.amendhistIssuingAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistIssuingAddr1()); } 
                if(obj.amendhistIssuingAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistIssuingAddr2()); } 
                if(obj.amendhistIssuingAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistIssuingAddr3()); } 
                if(obj.amendhistIssuingAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistIssuingAddr4()); } 
                if(obj.amendhistIssuingAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistIssuingAddr5()); } 
                if(obj.amendhistNonBnkIssurIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistNonBnkIssur()); } 
                if(obj.amendhistDateOfIssueIsModifiedS2j()) { if (obj.getAmendhistDateOfIssue() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getAmendhistDateOfIssue().getTime()));} } 
                if(obj.amendhistDateOfAmendmntIsModifiedS2j()) { if (obj.getAmendhistDateOfAmendmnt() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getAmendhistDateOfAmendmnt().getTime()));} } 
                if(obj.amendhistPurposeOfMsgIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendhistPurposeOfMsg())); } 
                if(obj.amendhistCancelRequestIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistCancelRequest()); } 
                if(obj.amendhistAdvisingBnkReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendhistAdvisingBnkReq())); } 
                if(obj.amendhistAdvisingBnkTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendhistAdvisingBnkType())); } 
                if(obj.amendhistAdvisingBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistAdvisingBrnCode()); } 
                if(obj.amendhistAdvisingBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistAdvisingBicCode()); } 
                if(obj.amendhistAdvisingRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistAdvisingRoutid()); } 
                if(obj.amendhistAdvisingBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistAdvisingBnkCode()); } 
                if(obj.amendhistAdvisingAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistAdvisingAddr1()); } 
                if(obj.amendhistAdvisingAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistAdvisingAddr2()); } 
                if(obj.amendhistAdvisingAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistAdvisingAddr3()); } 
                if(obj.amendhistAdvisingAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistAdvisingAddr4()); } 
                if(obj.amendhistAdvisingAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistAdvisingAddr5()); } 
                if(obj.amendhistSecondAdvReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendhistSecondAdvReq())); } 
                if(obj.amendhistSecondAdvTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendhistSecondAdvType())); } 
                if(obj.amendhistSecondAdvBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistSecondAdvBrnCode()); } 
                if(obj.amendhistSecondAdvBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistSecondAdvBicCode()); } 
                if(obj.amendhistSecondAdvRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistSecondAdvRoutid()); } 
                if(obj.amendhistSecondAdvBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistSecondAdvBnkCode()); } 
                if(obj.amendhistSecondAdvAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistSecondAdvAddr1()); } 
                if(obj.amendhistSecondAdvAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistSecondAdvAddr2()); } 
                if(obj.amendhistSecondAdvAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistSecondAdvAddr3()); } 
                if(obj.amendhistSecondAdvAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistSecondAdvAddr4()); } 
                if(obj.amendhistSecondAdvAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistSecondAdvAddr5()); } 
                if(obj.amendhistNewBeneficiaryIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistNewBeneficiary()); } 
                if(obj.amendhistNewDateOfExpiryIsModifiedS2j()) { if (obj.getAmendhistNewDateOfExpiry() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getAmendhistNewDateOfExpiry().getTime()));} } 
                if(obj.amendhistIncrDocCrAmtIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendhistIncrDocCrAmt()); } 
                if(obj.amendhistDecrDocCrAmtIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendhistDecrDocCrAmt()); } 
                if(obj.amendhistNewAddnlAmtIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendhistNewAddnlAmt()); } 
                if(obj.amendhistPlaceTakinInChrgIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistPlaceTakinInChrg()); } 
                if(obj.amendhistPortOfLoadingIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistPortOfLoading()); } 
                if(obj.amendhistPortOfDischargeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistPortOfDischarge()); } 
                if(obj.amendhistPlaceOfFinalDestIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistPlaceOfFinalDest()); } 
                if(obj.amendhistDateOfShipmentIsModifiedS2j()) { if (obj.getAmendhistDateOfShipment() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getAmendhistDateOfShipment().getTime()));} } 
                if(obj.amendhistDescGoddSer1IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getAmendhistDescGoddSer1()); } 
                if(obj.amendhistDocReq1IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getAmendhistDocReq1()); } 
                if(obj.amendhistAddCondition1IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getAmendhistAddCondition1()); } 
                if(obj.amendhistChrgPayable1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistChrgPayable1()); } 
                if(obj.amendhistChrgPayable2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistChrgPayable2()); } 
                if(obj.amendhistChrgPayable3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistChrgPayable3()); } 
                if(obj.amendhistChrgPayable4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistChrgPayable4()); } 
                if(obj.amendhistChrgPayable5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistChrgPayable5()); } 
                if(obj.amendhistChrgPayable6IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistChrgPayable6()); } 
                if(obj.amendhistSndrRecInfo1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistSndrRecInfo1()); } 
                if(obj.amendhistSndrRecInfo2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistSndrRecInfo2()); } 
                if(obj.amendhistSndrRecInfo3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistSndrRecInfo3()); } 
                if(obj.amendhistSndrRecInfo4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistSndrRecInfo4()); } 
                if(obj.amendhistSndrRecInfo5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistSndrRecInfo5()); } 
                if(obj.amendhistSndrRecInfo6IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistSndrRecInfo6()); } 
                if(obj.amendhistChkboxIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistChkbox()); } 
                if(obj.amendhistIssuingCntryIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistIssuingCntry()); } 
                if(obj.amendhistAdvisingCntryIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistAdvisingCntry()); } 
                if(obj.amendhistSecondAdvCntryIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistSecondAdvCntry()); } 
                if(obj.amendhistIssueRefIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistIssueRef()); } 
                if(obj.amdhistFormOfDocCreditIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmdhistFormOfDocCredit()); } 
                if(obj.amdhistLcApplicableRulesIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmdhistLcApplicableRules()); } 
                if(obj.amdhistLcApplReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmdhistLcApplReq())); } 
                if(obj.amdhistLcApplNameIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcApplName()); } 
                if(obj.amdhistLcApplAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcApplAddr1()); } 
                if(obj.amdhistLcApplAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcApplAddr2()); } 
                if(obj.amdhistLcApplAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcApplAddr3()); } 
                if(obj.amdhistLcApplAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcApplAddr4()); } 
                if(obj.amdhistLcApplAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcApplAddr5()); } 
                if(obj.amdhistLcAvlWithTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmdhistLcAvlWithType())); } 
                if(obj.amdhistLcAvlWithBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcAvlWithBrnCode()); } 
                if(obj.amdhistLcAvlWithBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcAvlWithBicCode()); } 
                if(obj.amdhistLcLcAvlWithRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcLcAvlWithRoutid()); } 
                if(obj.amdhistLcAvlWithBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcAvlWithBnkCode()); } 
                if(obj.amdhistLcAvlWithAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcAvlWithAddr1()); } 
                if(obj.amdhistLcAvlWithAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcAvlWithAddr2()); } 
                if(obj.amdhistLcAvlWithAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcAvlWithAddr3()); } 
                if(obj.amdhistLcAvlWithAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcAvlWithAddr4()); } 
                if(obj.amdhistLcAvlWithAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcAvlWithAddr5()); } 
                if(obj.amdhistLcAvlWithCntryIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcAvlWithCntry()); } 
                if(obj.amdhistLcDraftsAt1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcDraftsAt1()); } 
                if(obj.amdhistLcDraftsAt2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcDraftsAt2()); } 
                if(obj.amdhistLcDraftsAt3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcDraftsAt3()); } 
                if(obj.amdhistLcDraweeReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmdhistLcDraweeReq())); } 
                if(obj.amdhistLcDraweeTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmdhistLcDraweeType())); } 
                if(obj.amdhistLcDraweeBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcDraweeBrnCode()); } 
                if(obj.amdhistLcDraweeBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcDraweeBicCode()); } 
                if(obj.amdhistLcDraweeRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcDraweeRoutid()); } 
                if(obj.amdhistLcDraweeBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcDraweeBnkCode()); } 
                if(obj.amdhistLcDraweeAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcDraweeAddr1()); } 
                if(obj.amdhistLcDraweeAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcDraweeAddr2()); } 
                if(obj.amdhistLcDraweeAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcDraweeAddr3()); } 
                if(obj.amdhistLcDraweeAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcDraweeAddr4()); } 
                if(obj.amdhistLcDraweeAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcDraweeAddr5()); } 
                if(obj.amdhistDraweeCntryCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistDraweeCntryCode()); } 
                if(obj.amdhistLcMixedPayDetails1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcMixedPayDetails1()); } 
                if(obj.amdhistLcMixedPayDetails2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcMixedPayDetails2()); } 
                if(obj.amdhistLcMixedPayDetails3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcMixedPayDetails3()); } 
                if(obj.amdhistLcMixedPayDetails4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcMixedPayDetails4()); } 
                if(obj.amdhistLcMixedPayDetails5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcMixedPayDetails5()); } 
                if(obj.amdhistLcDefPayDetails1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcDefPayDetails1()); } 
                if(obj.amdhistLcDefPayDetails2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcDefPayDetails2()); } 
                if(obj.amdhistLcDefPayDetails3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcDefPayDetails3()); } 
                if(obj.amdhistLcDefPayDetails4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcDefPayDetails4()); } 
                if(obj.amdhistLcDefPayDetails5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcDefPayDetails5()); } 
                if(obj.amdhistLcPartialShipmentsIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmdhistLcPartialShipments()); } 
                if(obj.amdhistLcTranshipmentIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmdhistLcTranshipment()); } 
                if(obj.amdhistLcConfirmationInstIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmdhistLcConfirmationInst()); } 
                if(obj.amdhistLcReimbReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmdhistLcReimbReq())); } 
                if(obj.amdhistLcReimbTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmdhistLcReimbType())); } 
                if(obj.amdhistLcReimbBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcReimbBrnCode()); } 
                if(obj.amdhistLcReimbBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcReimbBicCode()); } 
                if(obj.amdhistLcReimbRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcReimbRoutid()); } 
                if(obj.amdhistLcReimbBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcReimbBnkCode()); } 
                if(obj.amdhistLcReimbAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcReimbAddr1()); } 
                if(obj.amdhistLcReimbAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcReimbAddr2()); } 
                if(obj.amdhistLcReimbAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcReimbAddr3()); } 
                if(obj.amdhistLcReimbAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcReimbAddr4()); } 
                if(obj.amdhistLcReimbAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcReimbAddr5()); } 
                if(obj.amdhistLcInstPaying1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcInstPaying1()); } 
                if(obj.amdhistLcInstPaying2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcInstPaying2()); } 
                if(obj.amdhistLcInstPaying3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcInstPaying3()); } 
                if(obj.amdhistLcInstPaying4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcInstPaying4()); } 
                if(obj.amdhistLcInstPaying5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcInstPaying5()); } 
                if(obj.amdhistLcInstPaying6IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcInstPaying6()); } 
                if(obj.amdhistLcInstPaying7IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcInstPaying7()); } 
                if(obj.amdhistLcInstPaying8IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcInstPaying8()); } 
                if(obj.amdhistLcInstPaying9IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcInstPaying9()); } 
                if(obj.amdhistLcInstPaying10IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcInstPaying10()); } 
                if(obj.amdhistLcInstPaying11IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcInstPaying11()); } 
                if(obj.amdhistLcInstPaying12IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcInstPaying12()); } 
                if(obj.amdhistLcSecondAdvReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmdhistLcSecondAdvReq())); } 
                if(obj.amdhistLcSecondAdvTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmdhistLcSecondAdvType())); } 
                if(obj.amdhistLcSecondAdvBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcSecondAdvBrnCode()); } 
                if(obj.amdhistLcSecondAdvBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcSecondAdvBicCode()); } 
                if(obj.amdhistLcSecondAdvRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcSecondAdvRoutid()); } 
                if(obj.amdhistLcSecondAdvBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcSecondAdvBnkCode()); } 
                if(obj.amdhistLcSecondAdvAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcSecondAdvAddr1()); } 
                if(obj.amdhistLcSecondAdvAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcSecondAdvAddr2()); } 
                if(obj.amdhistLcSecondAdvAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcSecondAdvAddr3()); } 
                if(obj.amdhistLcSecondAdvAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcSecondAdvAddr4()); } 
                if(obj.amdhistLcSecondAdvAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcSecondAdvAddr5()); } 
                if(obj.amdhistLcSecAdvCntrycodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcSecAdvCntrycode()); } 
                if(obj.amendHistLcAvlWithCodetypIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendHistLcAvlWithCodetyp())); } 
                if(obj.amendhistLcReimbCntryCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistLcReimbCntryCode()); } 
                if(obj.amendhistLcCnfAdvTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendhistLcCnfAdvType())); } 
                if(obj.amendhistLcCnfAdvBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistLcCnfAdvBrnCode()); } 
                if(obj.amendhistLcCnfAdvBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistLcCnfAdvBicCode()); } 
                if(obj.amendhistLcCnfAdvRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistLcCnfAdvRoutid()); } 
                if(obj.amendhistLcCnfAdvBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistLcCnfAdvBnkCode()); } 
                if(obj.amendhistLcCnfAdvAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistLcCnfAdvAddr1()); } 
                if(obj.amendhistLcCnfAdvAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistLcCnfAdvAddr2()); } 
                if(obj.amendhistLcCnfAdvAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistLcCnfAdvAddr3()); } 
                if(obj.amendhistLcCnfAdvAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistLcCnfAdvAddr4()); } 
                if(obj.amendhistLcCnfAdvAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistLcCnfAdvAddr5()); } 
                if(obj.amendhistLcCnfAdvCntrycodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistLcCnfAdvCntrycode()); } 
                _pstmt.executeUpdate();
                obj.setIsNew(false);
                obj.resetIsModifiedS2J();
            }
            else {
                StringBuffer _sql = new StringBuffer("UPDATE AMEND_DETAILS_HIST SET ");
                if(obj.amendhistLcBrnCodeIsModifiedS2j()) {  _sql.append("AMENDHIST_LC_BRN_CODE").append("=?,"); }
                if(obj.amendhistLcTypeIsModifiedS2j()) {  _sql.append("AMENDHIST_LC_TYPE").append("=?,"); }
                if(obj.amendhistLcYearIsModifiedS2j()) {  _sql.append("AMENDHIST_LC_YEAR").append("=?,"); }
                if(obj.amendhistLcSerialIsModifiedS2j()) {  _sql.append("AMENDHIST_LC_SERIAL").append("=?,"); }
                if(obj.amendhistLcAmdSlIsModifiedS2j()) {  _sql.append("AMENDHIST_LC_AMD_SL").append("=?,"); }
                if(obj.amendhistHistSlIsModifiedS2j()) {  _sql.append("AMENDHIST_HIST_SL").append("=?,"); }
                if(obj.amendhistHistDateIsModifiedS2j()) {  _sql.append("AMENDHIST_HIST_DATE").append("=?,"); }
                if(obj.amendhistSndrRefIsModifiedS2j()) {  _sql.append("AMENDHIST_SNDR_REF").append("=?,"); }
                if(obj.amendhistRcvrRefIsModifiedS2j()) {  _sql.append("AMENDHIST_RCVR_REF").append("=?,"); }
                if(obj.amendhistDocCrNumIsModifiedS2j()) {  _sql.append("AMENDHIST_DOC_CR_NUM").append("=?,"); }
                if(obj.amendhistIssuingBnkReqIsModifiedS2j()) {  _sql.append("AMENDHIST_ISSUING_BNK_REQ").append("=?,"); }
                if(obj.amendhistIssuingTypeIsModifiedS2j()) {  _sql.append("AMENDHIST_ISSUING_TYPE").append("=?,"); }
                if(obj.amendhistIssuingBrnCodeIsModifiedS2j()) {  _sql.append("AMENDHIST_ISSUING_BRN_CODE").append("=?,"); }
                if(obj.amendhistIssuingBicCodeIsModifiedS2j()) {  _sql.append("AMENDHIST_ISSUING_BIC_CODE").append("=?,"); }
                if(obj.amendhistIssuingRoutidIsModifiedS2j()) {  _sql.append("AMENDHIST_ISSUING_ROUTID").append("=?,"); }
                if(obj.amendhistIssuingBnkCodeIsModifiedS2j()) {  _sql.append("AMENDHIST_ISSUING_BNK_CODE").append("=?,"); }
                if(obj.amendhistIssuingAddr1IsModifiedS2j()) {  _sql.append("AMENDHIST_ISSUING_ADDR1").append("=?,"); }
                if(obj.amendhistIssuingAddr2IsModifiedS2j()) {  _sql.append("AMENDHIST_ISSUING_ADDR2").append("=?,"); }
                if(obj.amendhistIssuingAddr3IsModifiedS2j()) {  _sql.append("AMENDHIST_ISSUING_ADDR3").append("=?,"); }
                if(obj.amendhistIssuingAddr4IsModifiedS2j()) {  _sql.append("AMENDHIST_ISSUING_ADDR4").append("=?,"); }
                if(obj.amendhistIssuingAddr5IsModifiedS2j()) {  _sql.append("AMENDHIST_ISSUING_ADDR5").append("=?,"); }
                if(obj.amendhistNonBnkIssurIsModifiedS2j()) {  _sql.append("AMENDHIST_NON_BNK_ISSUR").append("=?,"); }
                if(obj.amendhistDateOfIssueIsModifiedS2j()) {  _sql.append("AMENDHIST_DATE_OF_ISSUE").append("=?,"); }
                if(obj.amendhistDateOfAmendmntIsModifiedS2j()) {  _sql.append("AMENDHIST_DATE_OF_AMENDMNT").append("=?,"); }
                if(obj.amendhistPurposeOfMsgIsModifiedS2j()) {  _sql.append("AMENDHIST_PURPOSE_OF_MSG").append("=?,"); }
                if(obj.amendhistCancelRequestIsModifiedS2j()) {  _sql.append("AMENDHIST_CANCEL_REQUEST").append("=?,"); }
                if(obj.amendhistAdvisingBnkReqIsModifiedS2j()) {  _sql.append("AMENDHIST_ADVISING_BNK_REQ").append("=?,"); }
                if(obj.amendhistAdvisingBnkTypeIsModifiedS2j()) {  _sql.append("AMENDHIST_ADVISING_BNK_TYPE").append("=?,"); }
                if(obj.amendhistAdvisingBrnCodeIsModifiedS2j()) {  _sql.append("AMENDHIST_ADVISING_BRN_CODE").append("=?,"); }
                if(obj.amendhistAdvisingBicCodeIsModifiedS2j()) {  _sql.append("AMENDHIST_ADVISING_BIC_CODE").append("=?,"); }
                if(obj.amendhistAdvisingRoutidIsModifiedS2j()) {  _sql.append("AMENDHIST_ADVISING_ROUTID").append("=?,"); }
                if(obj.amendhistAdvisingBnkCodeIsModifiedS2j()) {  _sql.append("AMENDHIST_ADVISING_BNK_CODE").append("=?,"); }
                if(obj.amendhistAdvisingAddr1IsModifiedS2j()) {  _sql.append("AMENDHIST_ADVISING_ADDR1").append("=?,"); }
                if(obj.amendhistAdvisingAddr2IsModifiedS2j()) {  _sql.append("AMENDHIST_ADVISING_ADDR2").append("=?,"); }
                if(obj.amendhistAdvisingAddr3IsModifiedS2j()) {  _sql.append("AMENDHIST_ADVISING_ADDR3").append("=?,"); }
                if(obj.amendhistAdvisingAddr4IsModifiedS2j()) {  _sql.append("AMENDHIST_ADVISING_ADDR4").append("=?,"); }
                if(obj.amendhistAdvisingAddr5IsModifiedS2j()) {  _sql.append("AMENDHIST_ADVISING_ADDR5").append("=?,"); }
                if(obj.amendhistSecondAdvReqIsModifiedS2j()) {  _sql.append("AMENDHIST_SECOND_ADV_REQ").append("=?,"); }
                if(obj.amendhistSecondAdvTypeIsModifiedS2j()) {  _sql.append("AMENDHIST_SECOND_ADV_TYPE").append("=?,"); }
                if(obj.amendhistSecondAdvBrnCodeIsModifiedS2j()) {  _sql.append("AMENDHIST_SECOND_ADV_BRN_CODE").append("=?,"); }
                if(obj.amendhistSecondAdvBicCodeIsModifiedS2j()) {  _sql.append("AMENDHIST_SECOND_ADV_BIC_CODE").append("=?,"); }
                if(obj.amendhistSecondAdvRoutidIsModifiedS2j()) {  _sql.append("AMENDHIST_SECOND_ADV_ROUTID").append("=?,"); }
                if(obj.amendhistSecondAdvBnkCodeIsModifiedS2j()) {  _sql.append("AMENDHIST_SECOND_ADV_BNK_CODE").append("=?,"); }
                if(obj.amendhistSecondAdvAddr1IsModifiedS2j()) {  _sql.append("AMENDHIST_SECOND_ADV_ADDR1").append("=?,"); }
                if(obj.amendhistSecondAdvAddr2IsModifiedS2j()) {  _sql.append("AMENDHIST_SECOND_ADV_ADDR2").append("=?,"); }
                if(obj.amendhistSecondAdvAddr3IsModifiedS2j()) {  _sql.append("AMENDHIST_SECOND_ADV_ADDR3").append("=?,"); }
                if(obj.amendhistSecondAdvAddr4IsModifiedS2j()) {  _sql.append("AMENDHIST_SECOND_ADV_ADDR4").append("=?,"); }
                if(obj.amendhistSecondAdvAddr5IsModifiedS2j()) {  _sql.append("AMENDHIST_SECOND_ADV_ADDR5").append("=?,"); }
                if(obj.amendhistNewBeneficiaryIsModifiedS2j()) {  _sql.append("AMENDHIST_NEW_BENEFICIARY").append("=?,"); }
                if(obj.amendhistNewDateOfExpiryIsModifiedS2j()) {  _sql.append("AMENDHIST_NEW_DATE_OF_EXPIRY").append("=?,"); }
                if(obj.amendhistIncrDocCrAmtIsModifiedS2j()) {  _sql.append("AMENDHIST_INCR_DOC_CR_AMT").append("=?,"); }
                if(obj.amendhistDecrDocCrAmtIsModifiedS2j()) {  _sql.append("AMENDHIST_DECR_DOC_CR_AMT").append("=?,"); }
                if(obj.amendhistNewAddnlAmtIsModifiedS2j()) {  _sql.append("AMENDHIST_NEW_ADDNL_AMT").append("=?,"); }
                if(obj.amendhistPlaceTakinInChrgIsModifiedS2j()) {  _sql.append("AMENDHIST_PLACE_TAKIN_IN_CHRG").append("=?,"); }
                if(obj.amendhistPortOfLoadingIsModifiedS2j()) {  _sql.append("AMENDHIST_PORT_OF_LOADING").append("=?,"); }
                if(obj.amendhistPortOfDischargeIsModifiedS2j()) {  _sql.append("AMENDHIST_PORT_OF_DISCHARGE").append("=?,"); }
                if(obj.amendhistPlaceOfFinalDestIsModifiedS2j()) {  _sql.append("AMENDHIST_PLACE_OF_FINAL_DEST").append("=?,"); }
                if(obj.amendhistDateOfShipmentIsModifiedS2j()) {  _sql.append("AMENDHIST_DATE_OF_SHIPMENT").append("=?,"); }
                if(obj.amendhistDescGoddSer1IsModifiedS2j()) {  _sql.append("AMENDHIST_DESC_GODD_SER1").append("=?,"); }
                if(obj.amendhistDocReq1IsModifiedS2j()) {  _sql.append("AMENDHIST_DOC_REQ1").append("=?,"); }
                if(obj.amendhistAddCondition1IsModifiedS2j()) {  _sql.append("AMENDHIST_ADD_CONDITION1").append("=?,"); }
                if(obj.amendhistChrgPayable1IsModifiedS2j()) {  _sql.append("AMENDHIST_CHRG_PAYABLE1").append("=?,"); }
                if(obj.amendhistChrgPayable2IsModifiedS2j()) {  _sql.append("AMENDHIST_CHRG_PAYABLE2").append("=?,"); }
                if(obj.amendhistChrgPayable3IsModifiedS2j()) {  _sql.append("AMENDHIST_CHRG_PAYABLE3").append("=?,"); }
                if(obj.amendhistChrgPayable4IsModifiedS2j()) {  _sql.append("AMENDHIST_CHRG_PAYABLE4").append("=?,"); }
                if(obj.amendhistChrgPayable5IsModifiedS2j()) {  _sql.append("AMENDHIST_CHRG_PAYABLE5").append("=?,"); }
                if(obj.amendhistChrgPayable6IsModifiedS2j()) {  _sql.append("AMENDHIST_CHRG_PAYABLE6").append("=?,"); }
                if(obj.amendhistSndrRecInfo1IsModifiedS2j()) {  _sql.append("AMENDHIST_SNDR_REC_INFO1").append("=?,"); }
                if(obj.amendhistSndrRecInfo2IsModifiedS2j()) {  _sql.append("AMENDHIST_SNDR_REC_INFO2").append("=?,"); }
                if(obj.amendhistSndrRecInfo3IsModifiedS2j()) {  _sql.append("AMENDHIST_SNDR_REC_INFO3").append("=?,"); }
                if(obj.amendhistSndrRecInfo4IsModifiedS2j()) {  _sql.append("AMENDHIST_SNDR_REC_INFO4").append("=?,"); }
                if(obj.amendhistSndrRecInfo5IsModifiedS2j()) {  _sql.append("AMENDHIST_SNDR_REC_INFO5").append("=?,"); }
                if(obj.amendhistSndrRecInfo6IsModifiedS2j()) {  _sql.append("AMENDHIST_SNDR_REC_INFO6").append("=?,"); }
                if(obj.amendhistChkboxIsModifiedS2j()) {  _sql.append("AMENDHIST_CHKBOX").append("=?,"); }
                if(obj.amendhistIssuingCntryIsModifiedS2j()) {  _sql.append("AMENDHIST_ISSUING_CNTRY").append("=?,"); }
                if(obj.amendhistAdvisingCntryIsModifiedS2j()) {  _sql.append("AMENDHIST_ADVISING_CNTRY").append("=?,"); }
                if(obj.amendhistSecondAdvCntryIsModifiedS2j()) {  _sql.append("AMENDHIST_SECOND_ADV_CNTRY").append("=?,"); }
                if(obj.amendhistIssueRefIsModifiedS2j()) {  _sql.append("AMENDHIST_ISSUE_REF").append("=?,"); }
                if(obj.amdhistFormOfDocCreditIsModifiedS2j()) {  _sql.append("AMDHIST_FORM_OF_DOC_CREDIT").append("=?,"); }
                if(obj.amdhistLcApplicableRulesIsModifiedS2j()) {  _sql.append("AMDHIST_LC_APPLICABLE_RULES").append("=?,"); }
                if(obj.amdhistLcApplReqIsModifiedS2j()) {  _sql.append("AMDHIST_LC_APPL_REQ").append("=?,"); }
                if(obj.amdhistLcApplNameIsModifiedS2j()) {  _sql.append("AMDHIST_LC_APPL_NAME").append("=?,"); }
                if(obj.amdhistLcApplAddr1IsModifiedS2j()) {  _sql.append("AMDHIST_LC_APPL_ADDR1").append("=?,"); }
                if(obj.amdhistLcApplAddr2IsModifiedS2j()) {  _sql.append("AMDHIST_LC_APPL_ADDR2").append("=?,"); }
                if(obj.amdhistLcApplAddr3IsModifiedS2j()) {  _sql.append("AMDHIST_LC_APPL_ADDR3").append("=?,"); }
                if(obj.amdhistLcApplAddr4IsModifiedS2j()) {  _sql.append("AMDHIST_LC_APPL_ADDR4").append("=?,"); }
                if(obj.amdhistLcApplAddr5IsModifiedS2j()) {  _sql.append("AMDHIST_LC_APPL_ADDR5").append("=?,"); }
                if(obj.amdhistLcAvlWithTypeIsModifiedS2j()) {  _sql.append("AMDHIST_LC_AVL_WITH_TYPE").append("=?,"); }
                if(obj.amdhistLcAvlWithBrnCodeIsModifiedS2j()) {  _sql.append("AMDHIST_LC_AVL_WITH_BRN_CODE").append("=?,"); }
                if(obj.amdhistLcAvlWithBicCodeIsModifiedS2j()) {  _sql.append("AMDHIST_LC_AVL_WITH_BIC_CODE").append("=?,"); }
                if(obj.amdhistLcLcAvlWithRoutidIsModifiedS2j()) {  _sql.append("AMDHIST_LC_LC_AVL_WITH_ROUTID").append("=?,"); }
                if(obj.amdhistLcAvlWithBnkCodeIsModifiedS2j()) {  _sql.append("AMDHIST_LC_AVL_WITH_BNK_CODE").append("=?,"); }
                if(obj.amdhistLcAvlWithAddr1IsModifiedS2j()) {  _sql.append("AMDHIST_LC_AVL_WITH_ADDR1").append("=?,"); }
                if(obj.amdhistLcAvlWithAddr2IsModifiedS2j()) {  _sql.append("AMDHIST_LC_AVL_WITH_ADDR2").append("=?,"); }
                if(obj.amdhistLcAvlWithAddr3IsModifiedS2j()) {  _sql.append("AMDHIST_LC_AVL_WITH_ADDR3").append("=?,"); }
                if(obj.amdhistLcAvlWithAddr4IsModifiedS2j()) {  _sql.append("AMDHIST_LC_AVL_WITH_ADDR4").append("=?,"); }
                if(obj.amdhistLcAvlWithAddr5IsModifiedS2j()) {  _sql.append("AMDHIST_LC_AVL_WITH_ADDR5").append("=?,"); }
                if(obj.amdhistLcAvlWithCntryIsModifiedS2j()) {  _sql.append("AMDHIST_LC_AVL_WITH_CNTRY").append("=?,"); }
                if(obj.amdhistLcDraftsAt1IsModifiedS2j()) {  _sql.append("AMDHIST_LC_DRAFTS_AT1").append("=?,"); }
                if(obj.amdhistLcDraftsAt2IsModifiedS2j()) {  _sql.append("AMDHIST_LC_DRAFTS_AT2").append("=?,"); }
                if(obj.amdhistLcDraftsAt3IsModifiedS2j()) {  _sql.append("AMDHIST_LC_DRAFTS_AT3").append("=?,"); }
                if(obj.amdhistLcDraweeReqIsModifiedS2j()) {  _sql.append("AMDHIST_LC_DRAWEE_REQ").append("=?,"); }
                if(obj.amdhistLcDraweeTypeIsModifiedS2j()) {  _sql.append("AMDHIST_LC_DRAWEE_TYPE").append("=?,"); }
                if(obj.amdhistLcDraweeBrnCodeIsModifiedS2j()) {  _sql.append("AMDHIST_LC_DRAWEE_BRN_CODE").append("=?,"); }
                if(obj.amdhistLcDraweeBicCodeIsModifiedS2j()) {  _sql.append("AMDHIST_LC_DRAWEE_BIC_CODE").append("=?,"); }
                if(obj.amdhistLcDraweeRoutidIsModifiedS2j()) {  _sql.append("AMDHIST_LC_DRAWEE_ROUTID").append("=?,"); }
                if(obj.amdhistLcDraweeBnkCodeIsModifiedS2j()) {  _sql.append("AMDHIST_LC_DRAWEE_BNK_CODE").append("=?,"); }
                if(obj.amdhistLcDraweeAddr1IsModifiedS2j()) {  _sql.append("AMDHIST_LC_DRAWEE_ADDR1").append("=?,"); }
                if(obj.amdhistLcDraweeAddr2IsModifiedS2j()) {  _sql.append("AMDHIST_LC_DRAWEE_ADDR2").append("=?,"); }
                if(obj.amdhistLcDraweeAddr3IsModifiedS2j()) {  _sql.append("AMDHIST_LC_DRAWEE_ADDR3").append("=?,"); }
                if(obj.amdhistLcDraweeAddr4IsModifiedS2j()) {  _sql.append("AMDHIST_LC_DRAWEE_ADDR4").append("=?,"); }
                if(obj.amdhistLcDraweeAddr5IsModifiedS2j()) {  _sql.append("AMDHIST_LC_DRAWEE_ADDR5").append("=?,"); }
                if(obj.amdhistDraweeCntryCodeIsModifiedS2j()) {  _sql.append("AMDHIST_DRAWEE_CNTRY_CODE").append("=?,"); }
                if(obj.amdhistLcMixedPayDetails1IsModifiedS2j()) {  _sql.append("AMDHIST_LC_MIXED_PAY_DETAILS1").append("=?,"); }
                if(obj.amdhistLcMixedPayDetails2IsModifiedS2j()) {  _sql.append("AMDHIST_LC_MIXED_PAY_DETAILS2").append("=?,"); }
                if(obj.amdhistLcMixedPayDetails3IsModifiedS2j()) {  _sql.append("AMDHIST_LC_MIXED_PAY_DETAILS3").append("=?,"); }
                if(obj.amdhistLcMixedPayDetails4IsModifiedS2j()) {  _sql.append("AMDHIST_LC_MIXED_PAY_DETAILS4").append("=?,"); }
                if(obj.amdhistLcMixedPayDetails5IsModifiedS2j()) {  _sql.append("AMDHIST_LC_MIXED_PAY_DETAILS5").append("=?,"); }
                if(obj.amdhistLcDefPayDetails1IsModifiedS2j()) {  _sql.append("AMDHIST_LC_DEF_PAY_DETAILS1").append("=?,"); }
                if(obj.amdhistLcDefPayDetails2IsModifiedS2j()) {  _sql.append("AMDHIST_LC_DEF_PAY_DETAILS2").append("=?,"); }
                if(obj.amdhistLcDefPayDetails3IsModifiedS2j()) {  _sql.append("AMDHIST_LC_DEF_PAY_DETAILS3").append("=?,"); }
                if(obj.amdhistLcDefPayDetails4IsModifiedS2j()) {  _sql.append("AMDHIST_LC_DEF_PAY_DETAILS4").append("=?,"); }
                if(obj.amdhistLcDefPayDetails5IsModifiedS2j()) {  _sql.append("AMDHIST_LC_DEF_PAY_DETAILS5").append("=?,"); }
                if(obj.amdhistLcPartialShipmentsIsModifiedS2j()) {  _sql.append("AMDHIST_LC_PARTIAL_SHIPMENTS").append("=?,"); }
                if(obj.amdhistLcTranshipmentIsModifiedS2j()) {  _sql.append("AMDHIST_LC_TRANSHIPMENT").append("=?,"); }
                if(obj.amdhistLcConfirmationInstIsModifiedS2j()) {  _sql.append("AMDHIST_LC_CONFIRMATION_INST").append("=?,"); }
                if(obj.amdhistLcReimbReqIsModifiedS2j()) {  _sql.append("AMDHIST_LC_REIMB_REQ").append("=?,"); }
                if(obj.amdhistLcReimbTypeIsModifiedS2j()) {  _sql.append("AMDHIST_LC_REIMB_TYPE").append("=?,"); }
                if(obj.amdhistLcReimbBrnCodeIsModifiedS2j()) {  _sql.append("AMDHIST_LC_REIMB_BRN_CODE").append("=?,"); }
                if(obj.amdhistLcReimbBicCodeIsModifiedS2j()) {  _sql.append("AMDHIST_LC_REIMB_BIC_CODE").append("=?,"); }
                if(obj.amdhistLcReimbRoutidIsModifiedS2j()) {  _sql.append("AMDHIST_LC_REIMB_ROUTID").append("=?,"); }
                if(obj.amdhistLcReimbBnkCodeIsModifiedS2j()) {  _sql.append("AMDHIST_LC_REIMB_BNK_CODE").append("=?,"); }
                if(obj.amdhistLcReimbAddr1IsModifiedS2j()) {  _sql.append("AMDHIST_LC_REIMB_ADDR1").append("=?,"); }
                if(obj.amdhistLcReimbAddr2IsModifiedS2j()) {  _sql.append("AMDHIST_LC_REIMB_ADDR2").append("=?,"); }
                if(obj.amdhistLcReimbAddr3IsModifiedS2j()) {  _sql.append("AMDHIST_LC_REIMB_ADDR3").append("=?,"); }
                if(obj.amdhistLcReimbAddr4IsModifiedS2j()) {  _sql.append("AMDHIST_LC_REIMB_ADDR4").append("=?,"); }
                if(obj.amdhistLcReimbAddr5IsModifiedS2j()) {  _sql.append("AMDHIST_LC_REIMB_ADDR5").append("=?,"); }
                if(obj.amdhistLcInstPaying1IsModifiedS2j()) {  _sql.append("AMDHIST_LC_INST_PAYING1").append("=?,"); }
                if(obj.amdhistLcInstPaying2IsModifiedS2j()) {  _sql.append("AMDHIST_LC_INST_PAYING2").append("=?,"); }
                if(obj.amdhistLcInstPaying3IsModifiedS2j()) {  _sql.append("AMDHIST_LC_INST_PAYING3").append("=?,"); }
                if(obj.amdhistLcInstPaying4IsModifiedS2j()) {  _sql.append("AMDHIST_LC_INST_PAYING4").append("=?,"); }
                if(obj.amdhistLcInstPaying5IsModifiedS2j()) {  _sql.append("AMDHIST_LC_INST_PAYING5").append("=?,"); }
                if(obj.amdhistLcInstPaying6IsModifiedS2j()) {  _sql.append("AMDHIST_LC_INST_PAYING6").append("=?,"); }
                if(obj.amdhistLcInstPaying7IsModifiedS2j()) {  _sql.append("AMDHIST_LC_INST_PAYING7").append("=?,"); }
                if(obj.amdhistLcInstPaying8IsModifiedS2j()) {  _sql.append("AMDHIST_LC_INST_PAYING8").append("=?,"); }
                if(obj.amdhistLcInstPaying9IsModifiedS2j()) {  _sql.append("AMDHIST_LC_INST_PAYING9").append("=?,"); }
                if(obj.amdhistLcInstPaying10IsModifiedS2j()) {  _sql.append("AMDHIST_LC_INST_PAYING10").append("=?,"); }
                if(obj.amdhistLcInstPaying11IsModifiedS2j()) {  _sql.append("AMDHIST_LC_INST_PAYING11").append("=?,"); }
                if(obj.amdhistLcInstPaying12IsModifiedS2j()) {  _sql.append("AMDHIST_LC_INST_PAYING12").append("=?,"); }
                if(obj.amdhistLcSecondAdvReqIsModifiedS2j()) {  _sql.append("AMDHIST_LC_SECOND_ADV_REQ").append("=?,"); }
                if(obj.amdhistLcSecondAdvTypeIsModifiedS2j()) {  _sql.append("AMDHIST_LC_SECOND_ADV_TYPE").append("=?,"); }
                if(obj.amdhistLcSecondAdvBrnCodeIsModifiedS2j()) {  _sql.append("AMDHIST_LC_SECOND_ADV_BRN_CODE").append("=?,"); }
                if(obj.amdhistLcSecondAdvBicCodeIsModifiedS2j()) {  _sql.append("AMDHIST_LC_SECOND_ADV_BIC_CODE").append("=?,"); }
                if(obj.amdhistLcSecondAdvRoutidIsModifiedS2j()) {  _sql.append("AMDHIST_LC_SECOND_ADV_ROUTID").append("=?,"); }
                if(obj.amdhistLcSecondAdvBnkCodeIsModifiedS2j()) {  _sql.append("AMDHIST_LC_SECOND_ADV_BNK_CODE").append("=?,"); }
                if(obj.amdhistLcSecondAdvAddr1IsModifiedS2j()) {  _sql.append("AMDHIST_LC_SECOND_ADV_ADDR1").append("=?,"); }
                if(obj.amdhistLcSecondAdvAddr2IsModifiedS2j()) {  _sql.append("AMDHIST_LC_SECOND_ADV_ADDR2").append("=?,"); }
                if(obj.amdhistLcSecondAdvAddr3IsModifiedS2j()) {  _sql.append("AMDHIST_LC_SECOND_ADV_ADDR3").append("=?,"); }
                if(obj.amdhistLcSecondAdvAddr4IsModifiedS2j()) {  _sql.append("AMDHIST_LC_SECOND_ADV_ADDR4").append("=?,"); }
                if(obj.amdhistLcSecondAdvAddr5IsModifiedS2j()) {  _sql.append("AMDHIST_LC_SECOND_ADV_ADDR5").append("=?,"); }
                if(obj.amdhistLcSecAdvCntrycodeIsModifiedS2j()) {  _sql.append("AMDHIST_LC_SEC_ADV_CNTRYCODE").append("=?,"); }
                if(obj.amendHistLcAvlWithCodetypIsModifiedS2j()) {  _sql.append("AMEND_HIST_LC_AVL_WITH_CODETYP").append("=?,"); }
                if(obj.amendhistLcReimbCntryCodeIsModifiedS2j()) {  _sql.append("AMENDHIST_LC_REIMB_CNTRY_CODE").append("=?,"); }
                if(obj.amendhistLcCnfAdvTypeIsModifiedS2j()) {  _sql.append("AMENDHIST_LC_CNF_ADV_TYPE").append("=?,"); }
                if(obj.amendhistLcCnfAdvBrnCodeIsModifiedS2j()) {  _sql.append("AMENDHIST_LC_CNF_ADV_BRN_CODE").append("=?,"); }
                if(obj.amendhistLcCnfAdvBicCodeIsModifiedS2j()) {  _sql.append("AMENDHIST_LC_CNF_ADV_BIC_CODE").append("=?,"); }
                if(obj.amendhistLcCnfAdvRoutidIsModifiedS2j()) {  _sql.append("AMENDHIST_LC_CNF_ADV_ROUTID").append("=?,"); }
                if(obj.amendhistLcCnfAdvBnkCodeIsModifiedS2j()) {  _sql.append("AMENDHIST_LC_CNF_ADV_BNK_CODE").append("=?,"); }
                if(obj.amendhistLcCnfAdvAddr1IsModifiedS2j()) {  _sql.append("AMENDHIST_LC_CNF_ADV_ADDR1").append("=?,"); }
                if(obj.amendhistLcCnfAdvAddr2IsModifiedS2j()) {  _sql.append("AMENDHIST_LC_CNF_ADV_ADDR2").append("=?,"); }
                if(obj.amendhistLcCnfAdvAddr3IsModifiedS2j()) {  _sql.append("AMENDHIST_LC_CNF_ADV_ADDR3").append("=?,"); }
                if(obj.amendhistLcCnfAdvAddr4IsModifiedS2j()) {  _sql.append("AMENDHIST_LC_CNF_ADV_ADDR4").append("=?,"); }
                if(obj.amendhistLcCnfAdvAddr5IsModifiedS2j()) {  _sql.append("AMENDHIST_LC_CNF_ADV_ADDR5").append("=?,"); }
                if(obj.amendhistLcCnfAdvCntrycodeIsModifiedS2j()) {  _sql.append("AMENDHIST_LC_CNF_ADV_CNTRYCODE").append("=?,"); }
                _sql.setLength(_sql.length() - 1);
                _sql.append(" WHERE ");
                _sql.append("AMEND_DETAILS_HIST.AMENDHIST_HIST_DATE=? and AMEND_DETAILS_HIST.AMENDHIST_HIST_SL=? and AMEND_DETAILS_HIST.AMENDHIST_LC_AMD_SL=? and AMEND_DETAILS_HIST.AMENDHIST_LC_BRN_CODE=? and AMEND_DETAILS_HIST.AMENDHIST_LC_SERIAL=? and AMEND_DETAILS_HIST.AMENDHIST_LC_TYPE=? and AMEND_DETAILS_HIST.AMENDHIST_LC_YEAR=?");
                _pstmt = _conn.prepareStatement(_sql.toString());
                int _dirtyCount = 0;
                if(obj.amendhistLcBrnCodeIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendhistLcBrnCode()); } 
                if(obj.amendhistLcTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistLcType()); } 
                if(obj.amendhistLcYearIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendhistLcYear()); } 
                if(obj.amendhistLcSerialIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendhistLcSerial()); } 
                if(obj.amendhistLcAmdSlIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendhistLcAmdSl()); } 
                if(obj.amendhistHistSlIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendhistHistSl()); } 
                if(obj.amendhistHistDateIsModifiedS2j()) { if (obj.getAmendhistHistDate() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getAmendhistHistDate().getTime()));} } 
                if(obj.amendhistSndrRefIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistSndrRef()); } 
                if(obj.amendhistRcvrRefIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistRcvrRef()); } 
                if(obj.amendhistDocCrNumIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistDocCrNum()); } 
                if(obj.amendhistIssuingBnkReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendhistIssuingBnkReq())); } 
                if(obj.amendhistIssuingTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendhistIssuingType())); } 
                if(obj.amendhistIssuingBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistIssuingBrnCode()); } 
                if(obj.amendhistIssuingBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistIssuingBicCode()); } 
                if(obj.amendhistIssuingRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistIssuingRoutid()); } 
                if(obj.amendhistIssuingBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistIssuingBnkCode()); } 
                if(obj.amendhistIssuingAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistIssuingAddr1()); } 
                if(obj.amendhistIssuingAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistIssuingAddr2()); } 
                if(obj.amendhistIssuingAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistIssuingAddr3()); } 
                if(obj.amendhistIssuingAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistIssuingAddr4()); } 
                if(obj.amendhistIssuingAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistIssuingAddr5()); } 
                if(obj.amendhistNonBnkIssurIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistNonBnkIssur()); } 
                if(obj.amendhistDateOfIssueIsModifiedS2j()) { if (obj.getAmendhistDateOfIssue() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getAmendhistDateOfIssue().getTime()));} } 
                if(obj.amendhistDateOfAmendmntIsModifiedS2j()) { if (obj.getAmendhistDateOfAmendmnt() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getAmendhistDateOfAmendmnt().getTime()));} } 
                if(obj.amendhistPurposeOfMsgIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendhistPurposeOfMsg())); } 
                if(obj.amendhistCancelRequestIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistCancelRequest()); } 
                if(obj.amendhistAdvisingBnkReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendhistAdvisingBnkReq())); } 
                if(obj.amendhistAdvisingBnkTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendhistAdvisingBnkType())); } 
                if(obj.amendhistAdvisingBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistAdvisingBrnCode()); } 
                if(obj.amendhistAdvisingBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistAdvisingBicCode()); } 
                if(obj.amendhistAdvisingRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistAdvisingRoutid()); } 
                if(obj.amendhistAdvisingBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistAdvisingBnkCode()); } 
                if(obj.amendhistAdvisingAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistAdvisingAddr1()); } 
                if(obj.amendhistAdvisingAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistAdvisingAddr2()); } 
                if(obj.amendhistAdvisingAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistAdvisingAddr3()); } 
                if(obj.amendhistAdvisingAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistAdvisingAddr4()); } 
                if(obj.amendhistAdvisingAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistAdvisingAddr5()); } 
                if(obj.amendhistSecondAdvReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendhistSecondAdvReq())); } 
                if(obj.amendhistSecondAdvTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendhistSecondAdvType())); } 
                if(obj.amendhistSecondAdvBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistSecondAdvBrnCode()); } 
                if(obj.amendhistSecondAdvBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistSecondAdvBicCode()); } 
                if(obj.amendhistSecondAdvRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistSecondAdvRoutid()); } 
                if(obj.amendhistSecondAdvBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistSecondAdvBnkCode()); } 
                if(obj.amendhistSecondAdvAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistSecondAdvAddr1()); } 
                if(obj.amendhistSecondAdvAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistSecondAdvAddr2()); } 
                if(obj.amendhistSecondAdvAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistSecondAdvAddr3()); } 
                if(obj.amendhistSecondAdvAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistSecondAdvAddr4()); } 
                if(obj.amendhistSecondAdvAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistSecondAdvAddr5()); } 
                if(obj.amendhistNewBeneficiaryIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistNewBeneficiary()); } 
                if(obj.amendhistNewDateOfExpiryIsModifiedS2j()) { if (obj.getAmendhistNewDateOfExpiry() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getAmendhistNewDateOfExpiry().getTime()));} } 
                if(obj.amendhistIncrDocCrAmtIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendhistIncrDocCrAmt()); } 
                if(obj.amendhistDecrDocCrAmtIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendhistDecrDocCrAmt()); } 
                if(obj.amendhistNewAddnlAmtIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmendhistNewAddnlAmt()); } 
                if(obj.amendhistPlaceTakinInChrgIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistPlaceTakinInChrg()); } 
                if(obj.amendhistPortOfLoadingIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistPortOfLoading()); } 
                if(obj.amendhistPortOfDischargeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistPortOfDischarge()); } 
                if(obj.amendhistPlaceOfFinalDestIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistPlaceOfFinalDest()); } 
                if(obj.amendhistDateOfShipmentIsModifiedS2j()) { if (obj.getAmendhistDateOfShipment() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getAmendhistDateOfShipment().getTime()));} } 
                if(obj.amendhistDescGoddSer1IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getAmendhistDescGoddSer1()); } 
                if(obj.amendhistDocReq1IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getAmendhistDocReq1()); } 
                if(obj.amendhistAddCondition1IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getAmendhistAddCondition1()); } 
                if(obj.amendhistChrgPayable1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistChrgPayable1()); } 
                if(obj.amendhistChrgPayable2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistChrgPayable2()); } 
                if(obj.amendhistChrgPayable3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistChrgPayable3()); } 
                if(obj.amendhistChrgPayable4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistChrgPayable4()); } 
                if(obj.amendhistChrgPayable5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistChrgPayable5()); } 
                if(obj.amendhistChrgPayable6IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistChrgPayable6()); } 
                if(obj.amendhistSndrRecInfo1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistSndrRecInfo1()); } 
                if(obj.amendhistSndrRecInfo2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistSndrRecInfo2()); } 
                if(obj.amendhistSndrRecInfo3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistSndrRecInfo3()); } 
                if(obj.amendhistSndrRecInfo4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistSndrRecInfo4()); } 
                if(obj.amendhistSndrRecInfo5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistSndrRecInfo5()); } 
                if(obj.amendhistSndrRecInfo6IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistSndrRecInfo6()); } 
                if(obj.amendhistChkboxIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistChkbox()); } 
                if(obj.amendhistIssuingCntryIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistIssuingCntry()); } 
                if(obj.amendhistAdvisingCntryIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistAdvisingCntry()); } 
                if(obj.amendhistSecondAdvCntryIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistSecondAdvCntry()); } 
                if(obj.amendhistIssueRefIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistIssueRef()); } 
                if(obj.amdhistFormOfDocCreditIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmdhistFormOfDocCredit()); } 
                if(obj.amdhistLcApplicableRulesIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmdhistLcApplicableRules()); } 
                if(obj.amdhistLcApplReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmdhistLcApplReq())); } 
                if(obj.amdhistLcApplNameIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcApplName()); } 
                if(obj.amdhistLcApplAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcApplAddr1()); } 
                if(obj.amdhistLcApplAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcApplAddr2()); } 
                if(obj.amdhistLcApplAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcApplAddr3()); } 
                if(obj.amdhistLcApplAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcApplAddr4()); } 
                if(obj.amdhistLcApplAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcApplAddr5()); } 
                if(obj.amdhistLcAvlWithTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmdhistLcAvlWithType())); } 
                if(obj.amdhistLcAvlWithBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcAvlWithBrnCode()); } 
                if(obj.amdhistLcAvlWithBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcAvlWithBicCode()); } 
                if(obj.amdhistLcLcAvlWithRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcLcAvlWithRoutid()); } 
                if(obj.amdhistLcAvlWithBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcAvlWithBnkCode()); } 
                if(obj.amdhistLcAvlWithAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcAvlWithAddr1()); } 
                if(obj.amdhistLcAvlWithAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcAvlWithAddr2()); } 
                if(obj.amdhistLcAvlWithAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcAvlWithAddr3()); } 
                if(obj.amdhistLcAvlWithAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcAvlWithAddr4()); } 
                if(obj.amdhistLcAvlWithAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcAvlWithAddr5()); } 
                if(obj.amdhistLcAvlWithCntryIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcAvlWithCntry()); } 
                if(obj.amdhistLcDraftsAt1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcDraftsAt1()); } 
                if(obj.amdhistLcDraftsAt2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcDraftsAt2()); } 
                if(obj.amdhistLcDraftsAt3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcDraftsAt3()); } 
                if(obj.amdhistLcDraweeReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmdhistLcDraweeReq())); } 
                if(obj.amdhistLcDraweeTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmdhistLcDraweeType())); } 
                if(obj.amdhistLcDraweeBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcDraweeBrnCode()); } 
                if(obj.amdhistLcDraweeBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcDraweeBicCode()); } 
                if(obj.amdhistLcDraweeRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcDraweeRoutid()); } 
                if(obj.amdhistLcDraweeBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcDraweeBnkCode()); } 
                if(obj.amdhistLcDraweeAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcDraweeAddr1()); } 
                if(obj.amdhistLcDraweeAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcDraweeAddr2()); } 
                if(obj.amdhistLcDraweeAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcDraweeAddr3()); } 
                if(obj.amdhistLcDraweeAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcDraweeAddr4()); } 
                if(obj.amdhistLcDraweeAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcDraweeAddr5()); } 
                if(obj.amdhistDraweeCntryCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistDraweeCntryCode()); } 
                if(obj.amdhistLcMixedPayDetails1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcMixedPayDetails1()); } 
                if(obj.amdhistLcMixedPayDetails2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcMixedPayDetails2()); } 
                if(obj.amdhistLcMixedPayDetails3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcMixedPayDetails3()); } 
                if(obj.amdhistLcMixedPayDetails4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcMixedPayDetails4()); } 
                if(obj.amdhistLcMixedPayDetails5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcMixedPayDetails5()); } 
                if(obj.amdhistLcDefPayDetails1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcDefPayDetails1()); } 
                if(obj.amdhistLcDefPayDetails2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcDefPayDetails2()); } 
                if(obj.amdhistLcDefPayDetails3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcDefPayDetails3()); } 
                if(obj.amdhistLcDefPayDetails4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcDefPayDetails4()); } 
                if(obj.amdhistLcDefPayDetails5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcDefPayDetails5()); } 
                if(obj.amdhistLcPartialShipmentsIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmdhistLcPartialShipments()); } 
                if(obj.amdhistLcTranshipmentIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmdhistLcTranshipment()); } 
                if(obj.amdhistLcConfirmationInstIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getAmdhistLcConfirmationInst()); } 
                if(obj.amdhistLcReimbReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmdhistLcReimbReq())); } 
                if(obj.amdhistLcReimbTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmdhistLcReimbType())); } 
                if(obj.amdhistLcReimbBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcReimbBrnCode()); } 
                if(obj.amdhistLcReimbBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcReimbBicCode()); } 
                if(obj.amdhistLcReimbRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcReimbRoutid()); } 
                if(obj.amdhistLcReimbBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcReimbBnkCode()); } 
                if(obj.amdhistLcReimbAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcReimbAddr1()); } 
                if(obj.amdhistLcReimbAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcReimbAddr2()); } 
                if(obj.amdhistLcReimbAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcReimbAddr3()); } 
                if(obj.amdhistLcReimbAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcReimbAddr4()); } 
                if(obj.amdhistLcReimbAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcReimbAddr5()); } 
                if(obj.amdhistLcInstPaying1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcInstPaying1()); } 
                if(obj.amdhistLcInstPaying2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcInstPaying2()); } 
                if(obj.amdhistLcInstPaying3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcInstPaying3()); } 
                if(obj.amdhistLcInstPaying4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcInstPaying4()); } 
                if(obj.amdhistLcInstPaying5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcInstPaying5()); } 
                if(obj.amdhistLcInstPaying6IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcInstPaying6()); } 
                if(obj.amdhistLcInstPaying7IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcInstPaying7()); } 
                if(obj.amdhistLcInstPaying8IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcInstPaying8()); } 
                if(obj.amdhistLcInstPaying9IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcInstPaying9()); } 
                if(obj.amdhistLcInstPaying10IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcInstPaying10()); } 
                if(obj.amdhistLcInstPaying11IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcInstPaying11()); } 
                if(obj.amdhistLcInstPaying12IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcInstPaying12()); } 
                if(obj.amdhistLcSecondAdvReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmdhistLcSecondAdvReq())); } 
                if(obj.amdhistLcSecondAdvTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmdhistLcSecondAdvType())); } 
                if(obj.amdhistLcSecondAdvBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcSecondAdvBrnCode()); } 
                if(obj.amdhistLcSecondAdvBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcSecondAdvBicCode()); } 
                if(obj.amdhistLcSecondAdvRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcSecondAdvRoutid()); } 
                if(obj.amdhistLcSecondAdvBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcSecondAdvBnkCode()); } 
                if(obj.amdhistLcSecondAdvAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcSecondAdvAddr1()); } 
                if(obj.amdhistLcSecondAdvAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcSecondAdvAddr2()); } 
                if(obj.amdhistLcSecondAdvAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcSecondAdvAddr3()); } 
                if(obj.amdhistLcSecondAdvAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcSecondAdvAddr4()); } 
                if(obj.amdhistLcSecondAdvAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcSecondAdvAddr5()); } 
                if(obj.amdhistLcSecAdvCntrycodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmdhistLcSecAdvCntrycode()); } 
                if(obj.amendHistLcAvlWithCodetypIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendHistLcAvlWithCodetyp())); } 
                if(obj.amendhistLcReimbCntryCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistLcReimbCntryCode()); } 
                if(obj.amendhistLcCnfAdvTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getAmendhistLcCnfAdvType())); } 
                if(obj.amendhistLcCnfAdvBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistLcCnfAdvBrnCode()); } 
                if(obj.amendhistLcCnfAdvBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistLcCnfAdvBicCode()); } 
                if(obj.amendhistLcCnfAdvRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistLcCnfAdvRoutid()); } 
                if(obj.amendhistLcCnfAdvBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistLcCnfAdvBnkCode()); } 
                if(obj.amendhistLcCnfAdvAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistLcCnfAdvAddr1()); } 
                if(obj.amendhistLcCnfAdvAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistLcCnfAdvAddr2()); } 
                if(obj.amendhistLcCnfAdvAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistLcCnfAdvAddr3()); } 
                if(obj.amendhistLcCnfAdvAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistLcCnfAdvAddr4()); } 
                if(obj.amendhistLcCnfAdvAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistLcCnfAdvAddr5()); } 
                if(obj.amendhistLcCnfAdvCntrycodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getAmendhistLcCnfAdvCntrycode()); } 
                if (obj.getAmendhistHistDate() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getAmendhistHistDate().getTime()));}
                _pstmt.setDouble(++_dirtyCount, obj.getAmendhistHistSl());
                _pstmt.setDouble(++_dirtyCount, obj.getAmendhistLcAmdSl());
                _pstmt.setDouble(++_dirtyCount, obj.getAmendhistLcBrnCode());
                _pstmt.setDouble(++_dirtyCount, obj.getAmendhistLcSerial());
                _pstmt.setString(++_dirtyCount, obj.getAmendhistLcType());
                _pstmt.setDouble(++_dirtyCount, obj.getAmendhistLcYear());
                _pstmt.executeUpdate();
                obj.resetIsModifiedS2J();
            }
            _pstmt.close();
        }
        catch(SQLException e) {
            if(_pstmt!=null) try { _pstmt.close();} catch(Exception e2) {}
            throw e;
        }
    }

    private AmendDetailsHist decodeRow(ResultSet rs) throws SQLException {
        AmendDetailsHist obj = new AmendDetailsHist();
        obj.setAmendhistLcBrnCode(rs.getInt(1));
        obj.setAmendhistLcType(rs.getString(2));
        obj.setAmendhistLcYear(rs.getInt(3));
        obj.setAmendhistLcSerial(rs.getInt(4));
        obj.setAmendhistLcAmdSl(rs.getInt(5));
        obj.setAmendhistHistSl(rs.getInt(6));
        obj.setAmendhistHistDate(rs.getDate(7));
        obj.setAmendhistSndrRef(rs.getString(8));
        obj.setAmendhistRcvrRef(rs.getString(9));
        obj.setAmendhistDocCrNum(rs.getString(10));
        obj.setAmendhistIssuingBnkReq(stringToChar(rs.getString(11)));
        obj.setAmendhistIssuingType(stringToChar(rs.getString(12)));
        obj.setAmendhistIssuingBrnCode(rs.getString(13));
        obj.setAmendhistIssuingBicCode(rs.getString(14));
        obj.setAmendhistIssuingRoutid(rs.getString(15));
        obj.setAmendhistIssuingBnkCode(rs.getString(16));
        obj.setAmendhistIssuingAddr1(rs.getString(17));
        obj.setAmendhistIssuingAddr2(rs.getString(18));
        obj.setAmendhistIssuingAddr3(rs.getString(19));
        obj.setAmendhistIssuingAddr4(rs.getString(20));
        obj.setAmendhistIssuingAddr5(rs.getString(21));
        obj.setAmendhistNonBnkIssur(rs.getString(22));
        obj.setAmendhistDateOfIssue(rs.getDate(23));
        obj.setAmendhistDateOfAmendmnt(rs.getDate(24));
        obj.setAmendhistPurposeOfMsg(stringToChar(rs.getString(25)));
        obj.setAmendhistCancelRequest(rs.getString(26));
        obj.setAmendhistAdvisingBnkReq(stringToChar(rs.getString(27)));
        obj.setAmendhistAdvisingBnkType(stringToChar(rs.getString(28)));
        obj.setAmendhistAdvisingBrnCode(rs.getString(29));
        obj.setAmendhistAdvisingBicCode(rs.getString(30));
        obj.setAmendhistAdvisingRoutid(rs.getString(31));
        obj.setAmendhistAdvisingBnkCode(rs.getString(32));
        obj.setAmendhistAdvisingAddr1(rs.getString(33));
        obj.setAmendhistAdvisingAddr2(rs.getString(34));
        obj.setAmendhistAdvisingAddr3(rs.getString(35));
        obj.setAmendhistAdvisingAddr4(rs.getString(36));
        obj.setAmendhistAdvisingAddr5(rs.getString(37));
        obj.setAmendhistSecondAdvReq(stringToChar(rs.getString(38)));
        obj.setAmendhistSecondAdvType(stringToChar(rs.getString(39)));
        obj.setAmendhistSecondAdvBrnCode(rs.getString(40));
        obj.setAmendhistSecondAdvBicCode(rs.getString(41));
        obj.setAmendhistSecondAdvRoutid(rs.getString(42));
        obj.setAmendhistSecondAdvBnkCode(rs.getString(43));
        obj.setAmendhistSecondAdvAddr1(rs.getString(44));
        obj.setAmendhistSecondAdvAddr2(rs.getString(45));
        obj.setAmendhistSecondAdvAddr3(rs.getString(46));
        obj.setAmendhistSecondAdvAddr4(rs.getString(47));
        obj.setAmendhistSecondAdvAddr5(rs.getString(48));
        obj.setAmendhistNewBeneficiary(rs.getString(49));
        obj.setAmendhistNewDateOfExpiry(rs.getDate(50));
        obj.setAmendhistIncrDocCrAmt(rs.getDouble(51));
        obj.setAmendhistDecrDocCrAmt(rs.getDouble(52));
        obj.setAmendhistNewAddnlAmt(rs.getDouble(53));
        obj.setAmendhistPlaceTakinInChrg(rs.getString(54));
        obj.setAmendhistPortOfLoading(rs.getString(55));
        obj.setAmendhistPortOfDischarge(rs.getString(56));
        obj.setAmendhistPlaceOfFinalDest(rs.getString(57));
        obj.setAmendhistDateOfShipment(rs.getDate(58));
        obj.setAmendhistDescGoddSer1(rs.getObject(59));
        obj.setAmendhistDocReq1(rs.getObject(60));
        obj.setAmendhistAddCondition1(rs.getObject(61));
        obj.setAmendhistChrgPayable1(rs.getString(62));
        obj.setAmendhistChrgPayable2(rs.getString(63));
        obj.setAmendhistChrgPayable3(rs.getString(64));
        obj.setAmendhistChrgPayable4(rs.getString(65));
        obj.setAmendhistChrgPayable5(rs.getString(66));
        obj.setAmendhistChrgPayable6(rs.getString(67));
        obj.setAmendhistSndrRecInfo1(rs.getString(68));
        obj.setAmendhistSndrRecInfo2(rs.getString(69));
        obj.setAmendhistSndrRecInfo3(rs.getString(70));
        obj.setAmendhistSndrRecInfo4(rs.getString(71));
        obj.setAmendhistSndrRecInfo5(rs.getString(72));
        obj.setAmendhistSndrRecInfo6(rs.getString(73));
        obj.setAmendhistChkbox(rs.getString(74));
        obj.setAmendhistIssuingCntry(rs.getString(75));
        obj.setAmendhistAdvisingCntry(rs.getString(76));
        obj.setAmendhistSecondAdvCntry(rs.getString(77));
        obj.setAmendhistIssueRef(rs.getString(78));
        obj.setAmdhistFormOfDocCredit(rs.getInt(79));
        obj.setAmdhistLcApplicableRules(rs.getInt(80));
        obj.setAmdhistLcApplReq(stringToChar(rs.getString(81)));
        obj.setAmdhistLcApplName(rs.getString(82));
        obj.setAmdhistLcApplAddr1(rs.getString(83));
        obj.setAmdhistLcApplAddr2(rs.getString(84));
        obj.setAmdhistLcApplAddr3(rs.getString(85));
        obj.setAmdhistLcApplAddr4(rs.getString(86));
        obj.setAmdhistLcApplAddr5(rs.getString(87));
        obj.setAmdhistLcAvlWithType(stringToChar(rs.getString(88)));
        obj.setAmdhistLcAvlWithBrnCode(rs.getString(89));
        obj.setAmdhistLcAvlWithBicCode(rs.getString(90));
        obj.setAmdhistLcLcAvlWithRoutid(rs.getString(91));
        obj.setAmdhistLcAvlWithBnkCode(rs.getString(92));
        obj.setAmdhistLcAvlWithAddr1(rs.getString(93));
        obj.setAmdhistLcAvlWithAddr2(rs.getString(94));
        obj.setAmdhistLcAvlWithAddr3(rs.getString(95));
        obj.setAmdhistLcAvlWithAddr4(rs.getString(96));
        obj.setAmdhistLcAvlWithAddr5(rs.getString(97));
        obj.setAmdhistLcAvlWithCntry(rs.getString(98));
        obj.setAmdhistLcDraftsAt1(rs.getString(99));
        obj.setAmdhistLcDraftsAt2(rs.getString(100));
        obj.setAmdhistLcDraftsAt3(rs.getString(101));
        obj.setAmdhistLcDraweeReq(stringToChar(rs.getString(102)));
        obj.setAmdhistLcDraweeType(stringToChar(rs.getString(103)));
        obj.setAmdhistLcDraweeBrnCode(rs.getString(104));
        obj.setAmdhistLcDraweeBicCode(rs.getString(105));
        obj.setAmdhistLcDraweeRoutid(rs.getString(106));
        obj.setAmdhistLcDraweeBnkCode(rs.getString(107));
        obj.setAmdhistLcDraweeAddr1(rs.getString(108));
        obj.setAmdhistLcDraweeAddr2(rs.getString(109));
        obj.setAmdhistLcDraweeAddr3(rs.getString(110));
        obj.setAmdhistLcDraweeAddr4(rs.getString(111));
        obj.setAmdhistLcDraweeAddr5(rs.getString(112));
        obj.setAmdhistDraweeCntryCode(rs.getString(113));
        obj.setAmdhistLcMixedPayDetails1(rs.getString(114));
        obj.setAmdhistLcMixedPayDetails2(rs.getString(115));
        obj.setAmdhistLcMixedPayDetails3(rs.getString(116));
        obj.setAmdhistLcMixedPayDetails4(rs.getString(117));
        obj.setAmdhistLcMixedPayDetails5(rs.getString(118));
        obj.setAmdhistLcDefPayDetails1(rs.getString(119));
        obj.setAmdhistLcDefPayDetails2(rs.getString(120));
        obj.setAmdhistLcDefPayDetails3(rs.getString(121));
        obj.setAmdhistLcDefPayDetails4(rs.getString(122));
        obj.setAmdhistLcDefPayDetails5(rs.getString(123));
        obj.setAmdhistLcPartialShipments(rs.getInt(124));
        obj.setAmdhistLcTranshipment(rs.getInt(125));
        obj.setAmdhistLcConfirmationInst(rs.getInt(126));
        obj.setAmdhistLcReimbReq(stringToChar(rs.getString(127)));
        obj.setAmdhistLcReimbType(stringToChar(rs.getString(128)));
        obj.setAmdhistLcReimbBrnCode(rs.getString(129));
        obj.setAmdhistLcReimbBicCode(rs.getString(130));
        obj.setAmdhistLcReimbRoutid(rs.getString(131));
        obj.setAmdhistLcReimbBnkCode(rs.getString(132));
        obj.setAmdhistLcReimbAddr1(rs.getString(133));
        obj.setAmdhistLcReimbAddr2(rs.getString(134));
        obj.setAmdhistLcReimbAddr3(rs.getString(135));
        obj.setAmdhistLcReimbAddr4(rs.getString(136));
        obj.setAmdhistLcReimbAddr5(rs.getString(137));
        obj.setAmdhistLcInstPaying1(rs.getString(138));
        obj.setAmdhistLcInstPaying2(rs.getString(139));
        obj.setAmdhistLcInstPaying3(rs.getString(140));
        obj.setAmdhistLcInstPaying4(rs.getString(141));
        obj.setAmdhistLcInstPaying5(rs.getString(142));
        obj.setAmdhistLcInstPaying6(rs.getString(143));
        obj.setAmdhistLcInstPaying7(rs.getString(144));
        obj.setAmdhistLcInstPaying8(rs.getString(145));
        obj.setAmdhistLcInstPaying9(rs.getString(146));
        obj.setAmdhistLcInstPaying10(rs.getString(147));
        obj.setAmdhistLcInstPaying11(rs.getString(148));
        obj.setAmdhistLcInstPaying12(rs.getString(149));
        obj.setAmdhistLcSecondAdvReq(stringToChar(rs.getString(150)));
        obj.setAmdhistLcSecondAdvType(stringToChar(rs.getString(151)));
        obj.setAmdhistLcSecondAdvBrnCode(rs.getString(152));
        obj.setAmdhistLcSecondAdvBicCode(rs.getString(153));
        obj.setAmdhistLcSecondAdvRoutid(rs.getString(154));
        obj.setAmdhistLcSecondAdvBnkCode(rs.getString(155));
        obj.setAmdhistLcSecondAdvAddr1(rs.getString(156));
        obj.setAmdhistLcSecondAdvAddr2(rs.getString(157));
        obj.setAmdhistLcSecondAdvAddr3(rs.getString(158));
        obj.setAmdhistLcSecondAdvAddr4(rs.getString(159));
        obj.setAmdhistLcSecondAdvAddr5(rs.getString(160));
        obj.setAmdhistLcSecAdvCntrycode(rs.getString(161));
        obj.setAmendHistLcAvlWithCodetyp(stringToChar(rs.getString(162)));
        obj.setAmendhistLcReimbCntryCode(rs.getString(163));
        obj.setAmendhistLcCnfAdvType(stringToChar(rs.getString(164)));
        obj.setAmendhistLcCnfAdvBrnCode(rs.getString(165));
        obj.setAmendhistLcCnfAdvBicCode(rs.getString(166));
        obj.setAmendhistLcCnfAdvRoutid(rs.getString(167));
        obj.setAmendhistLcCnfAdvBnkCode(rs.getString(168));
        obj.setAmendhistLcCnfAdvAddr1(rs.getString(169));
        obj.setAmendhistLcCnfAdvAddr2(rs.getString(170));
        obj.setAmendhistLcCnfAdvAddr3(rs.getString(171));
        obj.setAmendhistLcCnfAdvAddr4(rs.getString(172));
        obj.setAmendhistLcCnfAdvAddr5(rs.getString(173));
        obj.setAmendhistLcCnfAdvCntrycode(rs.getString(174));
        obj.setIsNew(false);
        obj.resetIsModifiedS2J();

        return obj;
    }

    private AmendDetailsHist decodeRow(ResultSet rs, int[] fieldList) throws SQLException {
        AmendDetailsHist obj = new AmendDetailsHist();
        int pos = 0;
        for(int i = 0; i < fieldList.length; i++) {
            switch(fieldList[i]) {
                case AMENDHIST_LC_BRN_CODE: obj.setAmendhistLcBrnCode(rs.getInt(++pos));
                    break;
                case AMENDHIST_LC_TYPE: obj.setAmendhistLcType(rs.getString(++pos));
                    break;
                case AMENDHIST_LC_YEAR: obj.setAmendhistLcYear(rs.getInt(++pos));
                    break;
                case AMENDHIST_LC_SERIAL: obj.setAmendhistLcSerial(rs.getInt(++pos));
                    break;
                case AMENDHIST_LC_AMD_SL: obj.setAmendhistLcAmdSl(rs.getInt(++pos));
                    break;
                case AMENDHIST_HIST_SL: obj.setAmendhistHistSl(rs.getInt(++pos));
                    break;
                case AMENDHIST_HIST_DATE: obj.setAmendhistHistDate(rs.getDate(++pos));
                    break;
                case AMENDHIST_SNDR_REF: obj.setAmendhistSndrRef(rs.getString(++pos));
                    break;
                case AMENDHIST_RCVR_REF: obj.setAmendhistRcvrRef(rs.getString(++pos));
                    break;
                case AMENDHIST_DOC_CR_NUM: obj.setAmendhistDocCrNum(rs.getString(++pos));
                    break;
                case AMENDHIST_ISSUING_BNK_REQ: obj.setAmendhistIssuingBnkReq(stringToChar(rs.getString(++pos)));
                    break;
                case AMENDHIST_ISSUING_TYPE: obj.setAmendhistIssuingType(stringToChar(rs.getString(++pos)));
                    break;
                case AMENDHIST_ISSUING_BRN_CODE: obj.setAmendhistIssuingBrnCode(rs.getString(++pos));
                    break;
                case AMENDHIST_ISSUING_BIC_CODE: obj.setAmendhistIssuingBicCode(rs.getString(++pos));
                    break;
                case AMENDHIST_ISSUING_ROUTID: obj.setAmendhistIssuingRoutid(rs.getString(++pos));
                    break;
                case AMENDHIST_ISSUING_BNK_CODE: obj.setAmendhistIssuingBnkCode(rs.getString(++pos));
                    break;
                case AMENDHIST_ISSUING_ADDR1: obj.setAmendhistIssuingAddr1(rs.getString(++pos));
                    break;
                case AMENDHIST_ISSUING_ADDR2: obj.setAmendhistIssuingAddr2(rs.getString(++pos));
                    break;
                case AMENDHIST_ISSUING_ADDR3: obj.setAmendhistIssuingAddr3(rs.getString(++pos));
                    break;
                case AMENDHIST_ISSUING_ADDR4: obj.setAmendhistIssuingAddr4(rs.getString(++pos));
                    break;
                case AMENDHIST_ISSUING_ADDR5: obj.setAmendhistIssuingAddr5(rs.getString(++pos));
                    break;
                case AMENDHIST_NON_BNK_ISSUR: obj.setAmendhistNonBnkIssur(rs.getString(++pos));
                    break;
                case AMENDHIST_DATE_OF_ISSUE: obj.setAmendhistDateOfIssue(rs.getDate(++pos));
                    break;
                case AMENDHIST_DATE_OF_AMENDMNT: obj.setAmendhistDateOfAmendmnt(rs.getDate(++pos));
                    break;
                case AMENDHIST_PURPOSE_OF_MSG: obj.setAmendhistPurposeOfMsg(stringToChar(rs.getString(++pos)));
                    break;
                case AMENDHIST_CANCEL_REQUEST: obj.setAmendhistCancelRequest(rs.getString(++pos));
                    break;
                case AMENDHIST_ADVISING_BNK_REQ: obj.setAmendhistAdvisingBnkReq(stringToChar(rs.getString(++pos)));
                    break;
                case AMENDHIST_ADVISING_BNK_TYPE: obj.setAmendhistAdvisingBnkType(stringToChar(rs.getString(++pos)));
                    break;
                case AMENDHIST_ADVISING_BRN_CODE: obj.setAmendhistAdvisingBrnCode(rs.getString(++pos));
                    break;
                case AMENDHIST_ADVISING_BIC_CODE: obj.setAmendhistAdvisingBicCode(rs.getString(++pos));
                    break;
                case AMENDHIST_ADVISING_ROUTID: obj.setAmendhistAdvisingRoutid(rs.getString(++pos));
                    break;
                case AMENDHIST_ADVISING_BNK_CODE: obj.setAmendhistAdvisingBnkCode(rs.getString(++pos));
                    break;
                case AMENDHIST_ADVISING_ADDR1: obj.setAmendhistAdvisingAddr1(rs.getString(++pos));
                    break;
                case AMENDHIST_ADVISING_ADDR2: obj.setAmendhistAdvisingAddr2(rs.getString(++pos));
                    break;
                case AMENDHIST_ADVISING_ADDR3: obj.setAmendhistAdvisingAddr3(rs.getString(++pos));
                    break;
                case AMENDHIST_ADVISING_ADDR4: obj.setAmendhistAdvisingAddr4(rs.getString(++pos));
                    break;
                case AMENDHIST_ADVISING_ADDR5: obj.setAmendhistAdvisingAddr5(rs.getString(++pos));
                    break;
                case AMENDHIST_SECOND_ADV_REQ: obj.setAmendhistSecondAdvReq(stringToChar(rs.getString(++pos)));
                    break;
                case AMENDHIST_SECOND_ADV_TYPE: obj.setAmendhistSecondAdvType(stringToChar(rs.getString(++pos)));
                    break;
                case AMENDHIST_SECOND_ADV_BRN_CODE: obj.setAmendhistSecondAdvBrnCode(rs.getString(++pos));
                    break;
                case AMENDHIST_SECOND_ADV_BIC_CODE: obj.setAmendhistSecondAdvBicCode(rs.getString(++pos));
                    break;
                case AMENDHIST_SECOND_ADV_ROUTID: obj.setAmendhistSecondAdvRoutid(rs.getString(++pos));
                    break;
                case AMENDHIST_SECOND_ADV_BNK_CODE: obj.setAmendhistSecondAdvBnkCode(rs.getString(++pos));
                    break;
                case AMENDHIST_SECOND_ADV_ADDR1: obj.setAmendhistSecondAdvAddr1(rs.getString(++pos));
                    break;
                case AMENDHIST_SECOND_ADV_ADDR2: obj.setAmendhistSecondAdvAddr2(rs.getString(++pos));
                    break;
                case AMENDHIST_SECOND_ADV_ADDR3: obj.setAmendhistSecondAdvAddr3(rs.getString(++pos));
                    break;
                case AMENDHIST_SECOND_ADV_ADDR4: obj.setAmendhistSecondAdvAddr4(rs.getString(++pos));
                    break;
                case AMENDHIST_SECOND_ADV_ADDR5: obj.setAmendhistSecondAdvAddr5(rs.getString(++pos));
                    break;
                case AMENDHIST_NEW_BENEFICIARY: obj.setAmendhistNewBeneficiary(rs.getString(++pos));
                    break;
                case AMENDHIST_NEW_DATE_OF_EXPIRY: obj.setAmendhistNewDateOfExpiry(rs.getDate(++pos));
                    break;
                case AMENDHIST_INCR_DOC_CR_AMT: obj.setAmendhistIncrDocCrAmt(rs.getDouble(++pos));
                    break;
                case AMENDHIST_DECR_DOC_CR_AMT: obj.setAmendhistDecrDocCrAmt(rs.getDouble(++pos));
                    break;
                case AMENDHIST_NEW_ADDNL_AMT: obj.setAmendhistNewAddnlAmt(rs.getDouble(++pos));
                    break;
                case AMENDHIST_PLACE_TAKIN_IN_CHRG: obj.setAmendhistPlaceTakinInChrg(rs.getString(++pos));
                    break;
                case AMENDHIST_PORT_OF_LOADING: obj.setAmendhistPortOfLoading(rs.getString(++pos));
                    break;
                case AMENDHIST_PORT_OF_DISCHARGE: obj.setAmendhistPortOfDischarge(rs.getString(++pos));
                    break;
                case AMENDHIST_PLACE_OF_FINAL_DEST: obj.setAmendhistPlaceOfFinalDest(rs.getString(++pos));
                    break;
                case AMENDHIST_DATE_OF_SHIPMENT: obj.setAmendhistDateOfShipment(rs.getDate(++pos));
                    break;
                case AMENDHIST_DESC_GODD_SER1: obj.setAmendhistDescGoddSer1(rs.getObject(++pos));
                    break;
                case AMENDHIST_DOC_REQ1: obj.setAmendhistDocReq1(rs.getObject(++pos));
                    break;
                case AMENDHIST_ADD_CONDITION1: obj.setAmendhistAddCondition1(rs.getObject(++pos));
                    break;
                case AMENDHIST_CHRG_PAYABLE1: obj.setAmendhistChrgPayable1(rs.getString(++pos));
                    break;
                case AMENDHIST_CHRG_PAYABLE2: obj.setAmendhistChrgPayable2(rs.getString(++pos));
                    break;
                case AMENDHIST_CHRG_PAYABLE3: obj.setAmendhistChrgPayable3(rs.getString(++pos));
                    break;
                case AMENDHIST_CHRG_PAYABLE4: obj.setAmendhistChrgPayable4(rs.getString(++pos));
                    break;
                case AMENDHIST_CHRG_PAYABLE5: obj.setAmendhistChrgPayable5(rs.getString(++pos));
                    break;
                case AMENDHIST_CHRG_PAYABLE6: obj.setAmendhistChrgPayable6(rs.getString(++pos));
                    break;
                case AMENDHIST_SNDR_REC_INFO1: obj.setAmendhistSndrRecInfo1(rs.getString(++pos));
                    break;
                case AMENDHIST_SNDR_REC_INFO2: obj.setAmendhistSndrRecInfo2(rs.getString(++pos));
                    break;
                case AMENDHIST_SNDR_REC_INFO3: obj.setAmendhistSndrRecInfo3(rs.getString(++pos));
                    break;
                case AMENDHIST_SNDR_REC_INFO4: obj.setAmendhistSndrRecInfo4(rs.getString(++pos));
                    break;
                case AMENDHIST_SNDR_REC_INFO5: obj.setAmendhistSndrRecInfo5(rs.getString(++pos));
                    break;
                case AMENDHIST_SNDR_REC_INFO6: obj.setAmendhistSndrRecInfo6(rs.getString(++pos));
                    break;
                case AMENDHIST_CHKBOX: obj.setAmendhistChkbox(rs.getString(++pos));
                    break;
                case AMENDHIST_ISSUING_CNTRY: obj.setAmendhistIssuingCntry(rs.getString(++pos));
                    break;
                case AMENDHIST_ADVISING_CNTRY: obj.setAmendhistAdvisingCntry(rs.getString(++pos));
                    break;
                case AMENDHIST_SECOND_ADV_CNTRY: obj.setAmendhistSecondAdvCntry(rs.getString(++pos));
                    break;
                case AMENDHIST_ISSUE_REF: obj.setAmendhistIssueRef(rs.getString(++pos));
                    break;
                case AMDHIST_FORM_OF_DOC_CREDIT: obj.setAmdhistFormOfDocCredit(rs.getInt(++pos));
                    break;
                case AMDHIST_LC_APPLICABLE_RULES: obj.setAmdhistLcApplicableRules(rs.getInt(++pos));
                    break;
                case AMDHIST_LC_APPL_REQ: obj.setAmdhistLcApplReq(stringToChar(rs.getString(++pos)));
                    break;
                case AMDHIST_LC_APPL_NAME: obj.setAmdhistLcApplName(rs.getString(++pos));
                    break;
                case AMDHIST_LC_APPL_ADDR1: obj.setAmdhistLcApplAddr1(rs.getString(++pos));
                    break;
                case AMDHIST_LC_APPL_ADDR2: obj.setAmdhistLcApplAddr2(rs.getString(++pos));
                    break;
                case AMDHIST_LC_APPL_ADDR3: obj.setAmdhistLcApplAddr3(rs.getString(++pos));
                    break;
                case AMDHIST_LC_APPL_ADDR4: obj.setAmdhistLcApplAddr4(rs.getString(++pos));
                    break;
                case AMDHIST_LC_APPL_ADDR5: obj.setAmdhistLcApplAddr5(rs.getString(++pos));
                    break;
                case AMDHIST_LC_AVL_WITH_TYPE: obj.setAmdhistLcAvlWithType(stringToChar(rs.getString(++pos)));
                    break;
                case AMDHIST_LC_AVL_WITH_BRN_CODE: obj.setAmdhistLcAvlWithBrnCode(rs.getString(++pos));
                    break;
                case AMDHIST_LC_AVL_WITH_BIC_CODE: obj.setAmdhistLcAvlWithBicCode(rs.getString(++pos));
                    break;
                case AMDHIST_LC_LC_AVL_WITH_ROUTID: obj.setAmdhistLcLcAvlWithRoutid(rs.getString(++pos));
                    break;
                case AMDHIST_LC_AVL_WITH_BNK_CODE: obj.setAmdhistLcAvlWithBnkCode(rs.getString(++pos));
                    break;
                case AMDHIST_LC_AVL_WITH_ADDR1: obj.setAmdhistLcAvlWithAddr1(rs.getString(++pos));
                    break;
                case AMDHIST_LC_AVL_WITH_ADDR2: obj.setAmdhistLcAvlWithAddr2(rs.getString(++pos));
                    break;
                case AMDHIST_LC_AVL_WITH_ADDR3: obj.setAmdhistLcAvlWithAddr3(rs.getString(++pos));
                    break;
                case AMDHIST_LC_AVL_WITH_ADDR4: obj.setAmdhistLcAvlWithAddr4(rs.getString(++pos));
                    break;
                case AMDHIST_LC_AVL_WITH_ADDR5: obj.setAmdhistLcAvlWithAddr5(rs.getString(++pos));
                    break;
                case AMDHIST_LC_AVL_WITH_CNTRY: obj.setAmdhistLcAvlWithCntry(rs.getString(++pos));
                    break;
                case AMDHIST_LC_DRAFTS_AT1: obj.setAmdhistLcDraftsAt1(rs.getString(++pos));
                    break;
                case AMDHIST_LC_DRAFTS_AT2: obj.setAmdhistLcDraftsAt2(rs.getString(++pos));
                    break;
                case AMDHIST_LC_DRAFTS_AT3: obj.setAmdhistLcDraftsAt3(rs.getString(++pos));
                    break;
                case AMDHIST_LC_DRAWEE_REQ: obj.setAmdhistLcDraweeReq(stringToChar(rs.getString(++pos)));
                    break;
                case AMDHIST_LC_DRAWEE_TYPE: obj.setAmdhistLcDraweeType(stringToChar(rs.getString(++pos)));
                    break;
                case AMDHIST_LC_DRAWEE_BRN_CODE: obj.setAmdhistLcDraweeBrnCode(rs.getString(++pos));
                    break;
                case AMDHIST_LC_DRAWEE_BIC_CODE: obj.setAmdhistLcDraweeBicCode(rs.getString(++pos));
                    break;
                case AMDHIST_LC_DRAWEE_ROUTID: obj.setAmdhistLcDraweeRoutid(rs.getString(++pos));
                    break;
                case AMDHIST_LC_DRAWEE_BNK_CODE: obj.setAmdhistLcDraweeBnkCode(rs.getString(++pos));
                    break;
                case AMDHIST_LC_DRAWEE_ADDR1: obj.setAmdhistLcDraweeAddr1(rs.getString(++pos));
                    break;
                case AMDHIST_LC_DRAWEE_ADDR2: obj.setAmdhistLcDraweeAddr2(rs.getString(++pos));
                    break;
                case AMDHIST_LC_DRAWEE_ADDR3: obj.setAmdhistLcDraweeAddr3(rs.getString(++pos));
                    break;
                case AMDHIST_LC_DRAWEE_ADDR4: obj.setAmdhistLcDraweeAddr4(rs.getString(++pos));
                    break;
                case AMDHIST_LC_DRAWEE_ADDR5: obj.setAmdhistLcDraweeAddr5(rs.getString(++pos));
                    break;
                case AMDHIST_DRAWEE_CNTRY_CODE: obj.setAmdhistDraweeCntryCode(rs.getString(++pos));
                    break;
                case AMDHIST_LC_MIXED_PAY_DETAILS1: obj.setAmdhistLcMixedPayDetails1(rs.getString(++pos));
                    break;
                case AMDHIST_LC_MIXED_PAY_DETAILS2: obj.setAmdhistLcMixedPayDetails2(rs.getString(++pos));
                    break;
                case AMDHIST_LC_MIXED_PAY_DETAILS3: obj.setAmdhistLcMixedPayDetails3(rs.getString(++pos));
                    break;
                case AMDHIST_LC_MIXED_PAY_DETAILS4: obj.setAmdhistLcMixedPayDetails4(rs.getString(++pos));
                    break;
                case AMDHIST_LC_MIXED_PAY_DETAILS5: obj.setAmdhistLcMixedPayDetails5(rs.getString(++pos));
                    break;
                case AMDHIST_LC_DEF_PAY_DETAILS1: obj.setAmdhistLcDefPayDetails1(rs.getString(++pos));
                    break;
                case AMDHIST_LC_DEF_PAY_DETAILS2: obj.setAmdhistLcDefPayDetails2(rs.getString(++pos));
                    break;
                case AMDHIST_LC_DEF_PAY_DETAILS3: obj.setAmdhistLcDefPayDetails3(rs.getString(++pos));
                    break;
                case AMDHIST_LC_DEF_PAY_DETAILS4: obj.setAmdhistLcDefPayDetails4(rs.getString(++pos));
                    break;
                case AMDHIST_LC_DEF_PAY_DETAILS5: obj.setAmdhistLcDefPayDetails5(rs.getString(++pos));
                    break;
                case AMDHIST_LC_PARTIAL_SHIPMENTS: obj.setAmdhistLcPartialShipments(rs.getInt(++pos));
                    break;
                case AMDHIST_LC_TRANSHIPMENT: obj.setAmdhistLcTranshipment(rs.getInt(++pos));
                    break;
                case AMDHIST_LC_CONFIRMATION_INST: obj.setAmdhistLcConfirmationInst(rs.getInt(++pos));
                    break;
                case AMDHIST_LC_REIMB_REQ: obj.setAmdhistLcReimbReq(stringToChar(rs.getString(++pos)));
                    break;
                case AMDHIST_LC_REIMB_TYPE: obj.setAmdhistLcReimbType(stringToChar(rs.getString(++pos)));
                    break;
                case AMDHIST_LC_REIMB_BRN_CODE: obj.setAmdhistLcReimbBrnCode(rs.getString(++pos));
                    break;
                case AMDHIST_LC_REIMB_BIC_CODE: obj.setAmdhistLcReimbBicCode(rs.getString(++pos));
                    break;
                case AMDHIST_LC_REIMB_ROUTID: obj.setAmdhistLcReimbRoutid(rs.getString(++pos));
                    break;
                case AMDHIST_LC_REIMB_BNK_CODE: obj.setAmdhistLcReimbBnkCode(rs.getString(++pos));
                    break;
                case AMDHIST_LC_REIMB_ADDR1: obj.setAmdhistLcReimbAddr1(rs.getString(++pos));
                    break;
                case AMDHIST_LC_REIMB_ADDR2: obj.setAmdhistLcReimbAddr2(rs.getString(++pos));
                    break;
                case AMDHIST_LC_REIMB_ADDR3: obj.setAmdhistLcReimbAddr3(rs.getString(++pos));
                    break;
                case AMDHIST_LC_REIMB_ADDR4: obj.setAmdhistLcReimbAddr4(rs.getString(++pos));
                    break;
                case AMDHIST_LC_REIMB_ADDR5: obj.setAmdhistLcReimbAddr5(rs.getString(++pos));
                    break;
                case AMDHIST_LC_INST_PAYING1: obj.setAmdhistLcInstPaying1(rs.getString(++pos));
                    break;
                case AMDHIST_LC_INST_PAYING2: obj.setAmdhistLcInstPaying2(rs.getString(++pos));
                    break;
                case AMDHIST_LC_INST_PAYING3: obj.setAmdhistLcInstPaying3(rs.getString(++pos));
                    break;
                case AMDHIST_LC_INST_PAYING4: obj.setAmdhistLcInstPaying4(rs.getString(++pos));
                    break;
                case AMDHIST_LC_INST_PAYING5: obj.setAmdhistLcInstPaying5(rs.getString(++pos));
                    break;
                case AMDHIST_LC_INST_PAYING6: obj.setAmdhistLcInstPaying6(rs.getString(++pos));
                    break;
                case AMDHIST_LC_INST_PAYING7: obj.setAmdhistLcInstPaying7(rs.getString(++pos));
                    break;
                case AMDHIST_LC_INST_PAYING8: obj.setAmdhistLcInstPaying8(rs.getString(++pos));
                    break;
                case AMDHIST_LC_INST_PAYING9: obj.setAmdhistLcInstPaying9(rs.getString(++pos));
                    break;
                case AMDHIST_LC_INST_PAYING10: obj.setAmdhistLcInstPaying10(rs.getString(++pos));
                    break;
                case AMDHIST_LC_INST_PAYING11: obj.setAmdhistLcInstPaying11(rs.getString(++pos));
                    break;
                case AMDHIST_LC_INST_PAYING12: obj.setAmdhistLcInstPaying12(rs.getString(++pos));
                    break;
                case AMDHIST_LC_SECOND_ADV_REQ: obj.setAmdhistLcSecondAdvReq(stringToChar(rs.getString(++pos)));
                    break;
                case AMDHIST_LC_SECOND_ADV_TYPE: obj.setAmdhistLcSecondAdvType(stringToChar(rs.getString(++pos)));
                    break;
                case AMDHIST_LC_SECOND_ADV_BRN_CODE: obj.setAmdhistLcSecondAdvBrnCode(rs.getString(++pos));
                    break;
                case AMDHIST_LC_SECOND_ADV_BIC_CODE: obj.setAmdhistLcSecondAdvBicCode(rs.getString(++pos));
                    break;
                case AMDHIST_LC_SECOND_ADV_ROUTID: obj.setAmdhistLcSecondAdvRoutid(rs.getString(++pos));
                    break;
                case AMDHIST_LC_SECOND_ADV_BNK_CODE: obj.setAmdhistLcSecondAdvBnkCode(rs.getString(++pos));
                    break;
                case AMDHIST_LC_SECOND_ADV_ADDR1: obj.setAmdhistLcSecondAdvAddr1(rs.getString(++pos));
                    break;
                case AMDHIST_LC_SECOND_ADV_ADDR2: obj.setAmdhistLcSecondAdvAddr2(rs.getString(++pos));
                    break;
                case AMDHIST_LC_SECOND_ADV_ADDR3: obj.setAmdhistLcSecondAdvAddr3(rs.getString(++pos));
                    break;
                case AMDHIST_LC_SECOND_ADV_ADDR4: obj.setAmdhistLcSecondAdvAddr4(rs.getString(++pos));
                    break;
                case AMDHIST_LC_SECOND_ADV_ADDR5: obj.setAmdhistLcSecondAdvAddr5(rs.getString(++pos));
                    break;
                case AMDHIST_LC_SEC_ADV_CNTRYCODE: obj.setAmdhistLcSecAdvCntrycode(rs.getString(++pos));
                    break;
                case AMEND_HIST_LC_AVL_WITH_CODETYP: obj.setAmendHistLcAvlWithCodetyp(stringToChar(rs.getString(++pos)));
                    break;
                case AMENDHIST_LC_REIMB_CNTRY_CODE: obj.setAmendhistLcReimbCntryCode(rs.getString(++pos));
                    break;
                case AMENDHIST_LC_CNF_ADV_TYPE: obj.setAmendhistLcCnfAdvType(stringToChar(rs.getString(++pos)));
                    break;
                case AMENDHIST_LC_CNF_ADV_BRN_CODE: obj.setAmendhistLcCnfAdvBrnCode(rs.getString(++pos));
                    break;
                case AMENDHIST_LC_CNF_ADV_BIC_CODE: obj.setAmendhistLcCnfAdvBicCode(rs.getString(++pos));
                    break;
                case AMENDHIST_LC_CNF_ADV_ROUTID: obj.setAmendhistLcCnfAdvRoutid(rs.getString(++pos));
                    break;
                case AMENDHIST_LC_CNF_ADV_BNK_CODE: obj.setAmendhistLcCnfAdvBnkCode(rs.getString(++pos));
                    break;
                case AMENDHIST_LC_CNF_ADV_ADDR1: obj.setAmendhistLcCnfAdvAddr1(rs.getString(++pos));
                    break;
                case AMENDHIST_LC_CNF_ADV_ADDR2: obj.setAmendhistLcCnfAdvAddr2(rs.getString(++pos));
                    break;
                case AMENDHIST_LC_CNF_ADV_ADDR3: obj.setAmendhistLcCnfAdvAddr3(rs.getString(++pos));
                    break;
                case AMENDHIST_LC_CNF_ADV_ADDR4: obj.setAmendhistLcCnfAdvAddr4(rs.getString(++pos));
                    break;
                case AMENDHIST_LC_CNF_ADV_ADDR5: obj.setAmendhistLcCnfAdvAddr5(rs.getString(++pos));
                    break;
                case AMENDHIST_LC_CNF_ADV_CNTRYCODE: obj.setAmendhistLcCnfAdvCntrycode(rs.getString(++pos));
                    break;
            }
        }
        obj.setIsNew(false);
        obj.resetIsModifiedS2J();

        return obj;
    }
    public void save(AmendDetailsHist obj, String tba_main_key, Timestamp tba_entry_date, long tab_dtl_sl ) throws SQLException {
            NewData_Key = "AMEND_DETAILS_HIST" + TableValueSep + NewDataChar + obj.getAmendhistLcBrnCode() + obj.getAmendhistLcType() + obj.getAmendhistLcYear() + obj.getAmendhistLcSerial() + obj.getAmendhistLcAmdSl() + obj.getAmendhistHistSl() + obj.getAmendhistHistDate();
            DataBlock_New = obj.getAmendhistLcBrnCode() + JNDINames.splitchar + obj.getAmendhistLcType() + JNDINames.splitchar + obj.getAmendhistLcYear() + JNDINames.splitchar + obj.getAmendhistLcSerial() + JNDINames.splitchar + obj.getAmendhistLcAmdSl() + JNDINames.splitchar + obj.getAmendhistHistSl() + JNDINames.splitchar + obj.getAmendhistHistDate() + JNDINames.splitchar + obj.getAmendhistSndrRef() + JNDINames.splitchar + obj.getAmendhistRcvrRef() + JNDINames.splitchar + obj.getAmendhistDocCrNum() + JNDINames.splitchar + obj.getAmendhistIssuingBnkReq() + JNDINames.splitchar + obj.getAmendhistIssuingType() + JNDINames.splitchar + obj.getAmendhistIssuingBrnCode() + JNDINames.splitchar + obj.getAmendhistIssuingBicCode() + JNDINames.splitchar + obj.getAmendhistIssuingRoutid() + JNDINames.splitchar + obj.getAmendhistIssuingBnkCode() + JNDINames.splitchar + obj.getAmendhistIssuingAddr1() + JNDINames.splitchar + obj.getAmendhistIssuingAddr2() + JNDINames.splitchar + obj.getAmendhistIssuingAddr3() + JNDINames.splitchar + obj.getAmendhistIssuingAddr4() + JNDINames.splitchar + obj.getAmendhistIssuingAddr5() + JNDINames.splitchar + obj.getAmendhistNonBnkIssur() + JNDINames.splitchar + obj.getAmendhistDateOfIssue() + JNDINames.splitchar + obj.getAmendhistDateOfAmendmnt() + JNDINames.splitchar + obj.getAmendhistPurposeOfMsg() + JNDINames.splitchar + obj.getAmendhistCancelRequest() + JNDINames.splitchar + obj.getAmendhistAdvisingBnkReq() + JNDINames.splitchar + obj.getAmendhistAdvisingBnkType() + JNDINames.splitchar + obj.getAmendhistAdvisingBrnCode() + JNDINames.splitchar + obj.getAmendhistAdvisingBicCode() + JNDINames.splitchar + obj.getAmendhistAdvisingRoutid() + JNDINames.splitchar + obj.getAmendhistAdvisingBnkCode() + JNDINames.splitchar + obj.getAmendhistAdvisingAddr1() + JNDINames.splitchar + obj.getAmendhistAdvisingAddr2() + JNDINames.splitchar + obj.getAmendhistAdvisingAddr3() + JNDINames.splitchar + obj.getAmendhistAdvisingAddr4() + JNDINames.splitchar + obj.getAmendhistAdvisingAddr5() + JNDINames.splitchar + obj.getAmendhistSecondAdvReq() + JNDINames.splitchar + obj.getAmendhistSecondAdvType() + JNDINames.splitchar + obj.getAmendhistSecondAdvBrnCode() + JNDINames.splitchar + obj.getAmendhistSecondAdvBicCode() + JNDINames.splitchar + obj.getAmendhistSecondAdvRoutid() + JNDINames.splitchar + obj.getAmendhistSecondAdvBnkCode() + JNDINames.splitchar + obj.getAmendhistSecondAdvAddr1() + JNDINames.splitchar + obj.getAmendhistSecondAdvAddr2() + JNDINames.splitchar + obj.getAmendhistSecondAdvAddr3() + JNDINames.splitchar + obj.getAmendhistSecondAdvAddr4() + JNDINames.splitchar + obj.getAmendhistSecondAdvAddr5() + JNDINames.splitchar + obj.getAmendhistNewBeneficiary() + JNDINames.splitchar + obj.getAmendhistNewDateOfExpiry() + JNDINames.splitchar + obj.getAmendhistIncrDocCrAmt() + JNDINames.splitchar + obj.getAmendhistDecrDocCrAmt() + JNDINames.splitchar + obj.getAmendhistNewAddnlAmt() + JNDINames.splitchar + obj.getAmendhistPlaceTakinInChrg() + JNDINames.splitchar + obj.getAmendhistPortOfLoading() + JNDINames.splitchar + obj.getAmendhistPortOfDischarge() + JNDINames.splitchar + obj.getAmendhistPlaceOfFinalDest() + JNDINames.splitchar + obj.getAmendhistDateOfShipment() + JNDINames.splitchar + obj.getAmendhistDescGoddSer1() + JNDINames.splitchar + obj.getAmendhistDocReq1() + JNDINames.splitchar + obj.getAmendhistAddCondition1() + JNDINames.splitchar + obj.getAmendhistChrgPayable1() + JNDINames.splitchar + obj.getAmendhistChrgPayable2() + JNDINames.splitchar + obj.getAmendhistChrgPayable3() + JNDINames.splitchar + obj.getAmendhistChrgPayable4() + JNDINames.splitchar + obj.getAmendhistChrgPayable5() + JNDINames.splitchar + obj.getAmendhistChrgPayable6() + JNDINames.splitchar + obj.getAmendhistSndrRecInfo1() + JNDINames.splitchar + obj.getAmendhistSndrRecInfo2() + JNDINames.splitchar + obj.getAmendhistSndrRecInfo3() + JNDINames.splitchar + obj.getAmendhistSndrRecInfo4() + JNDINames.splitchar + obj.getAmendhistSndrRecInfo5() + JNDINames.splitchar + obj.getAmendhistSndrRecInfo6() + JNDINames.splitchar + obj.getAmendhistChkbox() + JNDINames.splitchar + obj.getAmendhistIssuingCntry() + JNDINames.splitchar + obj.getAmendhistAdvisingCntry() + JNDINames.splitchar + obj.getAmendhistSecondAdvCntry() + JNDINames.splitchar + obj.getAmendhistIssueRef() + JNDINames.splitchar + obj.getAmdhistFormOfDocCredit() + JNDINames.splitchar + obj.getAmdhistLcApplicableRules() + JNDINames.splitchar + obj.getAmdhistLcApplReq() + JNDINames.splitchar + obj.getAmdhistLcApplName() + JNDINames.splitchar + obj.getAmdhistLcApplAddr1() + JNDINames.splitchar + obj.getAmdhistLcApplAddr2() + JNDINames.splitchar + obj.getAmdhistLcApplAddr3() + JNDINames.splitchar + obj.getAmdhistLcApplAddr4() + JNDINames.splitchar + obj.getAmdhistLcApplAddr5() + JNDINames.splitchar + obj.getAmdhistLcAvlWithType() + JNDINames.splitchar + obj.getAmdhistLcAvlWithBrnCode() + JNDINames.splitchar + obj.getAmdhistLcAvlWithBicCode() + JNDINames.splitchar + obj.getAmdhistLcLcAvlWithRoutid() + JNDINames.splitchar + obj.getAmdhistLcAvlWithBnkCode() + JNDINames.splitchar + obj.getAmdhistLcAvlWithAddr1() + JNDINames.splitchar + obj.getAmdhistLcAvlWithAddr2() + JNDINames.splitchar + obj.getAmdhistLcAvlWithAddr3() + JNDINames.splitchar + obj.getAmdhistLcAvlWithAddr4() + JNDINames.splitchar + obj.getAmdhistLcAvlWithAddr5() + JNDINames.splitchar + obj.getAmdhistLcAvlWithCntry() + JNDINames.splitchar + obj.getAmdhistLcDraftsAt1() + JNDINames.splitchar + obj.getAmdhistLcDraftsAt2() + JNDINames.splitchar + obj.getAmdhistLcDraftsAt3() + JNDINames.splitchar + obj.getAmdhistLcDraweeReq() + JNDINames.splitchar + obj.getAmdhistLcDraweeType() + JNDINames.splitchar + obj.getAmdhistLcDraweeBrnCode() + JNDINames.splitchar + obj.getAmdhistLcDraweeBicCode() + JNDINames.splitchar + obj.getAmdhistLcDraweeRoutid() + JNDINames.splitchar + obj.getAmdhistLcDraweeBnkCode() + JNDINames.splitchar + obj.getAmdhistLcDraweeAddr1() + JNDINames.splitchar + obj.getAmdhistLcDraweeAddr2() + JNDINames.splitchar + obj.getAmdhistLcDraweeAddr3() + JNDINames.splitchar + obj.getAmdhistLcDraweeAddr4() + JNDINames.splitchar + obj.getAmdhistLcDraweeAddr5() + JNDINames.splitchar + obj.getAmdhistDraweeCntryCode() + JNDINames.splitchar + obj.getAmdhistLcMixedPayDetails1() + JNDINames.splitchar + obj.getAmdhistLcMixedPayDetails2() + JNDINames.splitchar + obj.getAmdhistLcMixedPayDetails3() + JNDINames.splitchar + obj.getAmdhistLcMixedPayDetails4() + JNDINames.splitchar + obj.getAmdhistLcMixedPayDetails5() + JNDINames.splitchar + obj.getAmdhistLcDefPayDetails1() + JNDINames.splitchar + obj.getAmdhistLcDefPayDetails2() + JNDINames.splitchar + obj.getAmdhistLcDefPayDetails3() + JNDINames.splitchar + obj.getAmdhistLcDefPayDetails4() + JNDINames.splitchar + obj.getAmdhistLcDefPayDetails5() + JNDINames.splitchar + obj.getAmdhistLcPartialShipments() + JNDINames.splitchar + obj.getAmdhistLcTranshipment() + JNDINames.splitchar + obj.getAmdhistLcConfirmationInst() + JNDINames.splitchar + obj.getAmdhistLcReimbReq() + JNDINames.splitchar + obj.getAmdhistLcReimbType() + JNDINames.splitchar + obj.getAmdhistLcReimbBrnCode() + JNDINames.splitchar + obj.getAmdhistLcReimbBicCode() + JNDINames.splitchar + obj.getAmdhistLcReimbRoutid() + JNDINames.splitchar + obj.getAmdhistLcReimbBnkCode() + JNDINames.splitchar + obj.getAmdhistLcReimbAddr1() + JNDINames.splitchar + obj.getAmdhistLcReimbAddr2() + JNDINames.splitchar + obj.getAmdhistLcReimbAddr3() + JNDINames.splitchar + obj.getAmdhistLcReimbAddr4() + JNDINames.splitchar + obj.getAmdhistLcReimbAddr5() + JNDINames.splitchar + obj.getAmdhistLcInstPaying1() + JNDINames.splitchar + obj.getAmdhistLcInstPaying2() + JNDINames.splitchar + obj.getAmdhistLcInstPaying3() + JNDINames.splitchar + obj.getAmdhistLcInstPaying4() + JNDINames.splitchar + obj.getAmdhistLcInstPaying5() + JNDINames.splitchar + obj.getAmdhistLcInstPaying6() + JNDINames.splitchar + obj.getAmdhistLcInstPaying7() + JNDINames.splitchar + obj.getAmdhistLcInstPaying8() + JNDINames.splitchar + obj.getAmdhistLcInstPaying9() + JNDINames.splitchar + obj.getAmdhistLcInstPaying10() + JNDINames.splitchar + obj.getAmdhistLcInstPaying11() + JNDINames.splitchar + obj.getAmdhistLcInstPaying12() + JNDINames.splitchar + obj.getAmdhistLcSecondAdvReq() + JNDINames.splitchar + obj.getAmdhistLcSecondAdvType() + JNDINames.splitchar + obj.getAmdhistLcSecondAdvBrnCode() + JNDINames.splitchar + obj.getAmdhistLcSecondAdvBicCode() + JNDINames.splitchar + obj.getAmdhistLcSecondAdvRoutid() + JNDINames.splitchar + obj.getAmdhistLcSecondAdvBnkCode() + JNDINames.splitchar + obj.getAmdhistLcSecondAdvAddr1() + JNDINames.splitchar + obj.getAmdhistLcSecondAdvAddr2() + JNDINames.splitchar + obj.getAmdhistLcSecondAdvAddr3() + JNDINames.splitchar + obj.getAmdhistLcSecondAdvAddr4() + JNDINames.splitchar + obj.getAmdhistLcSecondAdvAddr5() + JNDINames.splitchar + obj.getAmdhistLcSecAdvCntrycode() + JNDINames.splitchar + obj.getAmendHistLcAvlWithCodetyp() + JNDINames.splitchar + obj.getAmendhistLcReimbCntryCode() + JNDINames.splitchar + obj.getAmendhistLcCnfAdvType() + JNDINames.splitchar + obj.getAmendhistLcCnfAdvBrnCode() + JNDINames.splitchar + obj.getAmendhistLcCnfAdvBicCode() + JNDINames.splitchar + obj.getAmendhistLcCnfAdvRoutid() + JNDINames.splitchar + obj.getAmendhistLcCnfAdvBnkCode() + JNDINames.splitchar + obj.getAmendhistLcCnfAdvAddr1() + JNDINames.splitchar + obj.getAmendhistLcCnfAdvAddr2() + JNDINames.splitchar + obj.getAmendhistLcCnfAdvAddr3() + JNDINames.splitchar + obj.getAmendhistLcCnfAdvAddr4() + JNDINames.splitchar + obj.getAmendhistLcCnfAdvAddr5() + JNDINames.splitchar + obj.getAmendhistLcCnfAdvCntrycode();
                if (_Logreq == 1)
                {
                    if (obj.isNew() == false)
                    {
                        if (OldData_Key != null) this._COLLECTIONobj.put(OldData_Key , DataBlock_Old );
                        if (NewData_Key != null) this._COLLECTIONobj.put(NewData_Key , DataBlock_New );
                    }else if ((_Logaddreq == 1) && obj.isNew() == true)
                    {
                        if (NewData_Key != null) this._COLLECTIONobj.put(NewData_Key , DataBlock_New );
                    }
                }
            OldData_Key ="";
            DataBlock_Old = "";
            DataBlock_New = "";
            NewData_Key = "";
        {
    // This is for main table Updation
            save(obj);
        }
    }

	 public long GetMaxSl(java.util.Date _amendhistHistDate, int _amendhistHistSl, int _amendhistLcAmdSl, int _amendhistLcBrnCode, int _amendhistLcSerial, String _amendhistLcType, int _amendhistLcYear) throws SQLException {
        ResultSet rs = null;
        long maxsl = 0;
        Connection _conn = null;
        PreparedStatement _pstmt = null;
            try {
                _conn = openConnection();
                StringBuffer _sql = new StringBuffer("SELECT NVL(MAX(null),0) + 1 AS MAXSL FROM AMEND_DETAILS_HIST WHERE AMEND_DETAILS_HIST.AMENDHIST_HIST_DATE=? and AMEND_DETAILS_HIST.AMENDHIST_HIST_SL=? and AMEND_DETAILS_HIST.AMENDHIST_LC_AMD_SL=? and AMEND_DETAILS_HIST.AMENDHIST_LC_BRN_CODE=? and AMEND_DETAILS_HIST.AMENDHIST_LC_SERIAL=? and AMEND_DETAILS_HIST.AMENDHIST_LC_TYPE=? and AMEND_DETAILS_HIST.AMENDHIST_LC_YEAR=?");
                _pstmt = _conn.prepareStatement(_sql.toString());
            if (_amendhistHistDate == null) {_pstmt.setTimestamp(1, null);} else {_pstmt.setTimestamp(1, new java.sql.Timestamp(_amendhistHistDate.getTime()));}
            _pstmt.setInt(2, _amendhistHistSl);
            _pstmt.setInt(3, _amendhistLcAmdSl);
            _pstmt.setInt(4, _amendhistLcBrnCode);
            _pstmt.setInt(5, _amendhistLcSerial);
            _pstmt.setString(6, _amendhistLcType);
            _pstmt.setInt(7, _amendhistLcYear);
                 rs = _pstmt.executeQuery();
                 if (rs.next())
                {
                maxsl = rs.getLong(1);
                }
                rs.close();
                }
                catch(SQLException e) {
                if(rs!=null) try { rs.close();} catch(Exception e2) {}
                throw e;
            }
            finally
            {
                if(_pstmt!=null) try { _pstmt.close();} catch(Exception e2) {}
                if(_conn!=null) try { closeConnection(_conn);} catch(Exception e2) {}
            }
            return maxsl;
        }


    public int GetMaxSl(java.util.Date _amendhistHistDate, int _amendhistLcAmdSl, int _amendhistLcBrnCode, int _amendhistLcSerial, String _amendhistLcType, int _amendhistLcYear) throws SQLException {
        ResultSet rs = null;
        int maxsl = 0;
        Connection _conn = null;
        PreparedStatement _pstmt = null;
            try {
                _conn = openConnection();
                StringBuffer _sql = new StringBuffer("SELECT NVL(MAX(AMEND_DETAILS_HIST.AMENDHIST_HIST_SL),0) + 1 AS MAXSL FROM AMEND_DETAILS_HIST WHERE AMEND_DETAILS_HIST.AMENDHIST_HIST_DATE=?  and AMEND_DETAILS_HIST.AMENDHIST_LC_AMD_SL=? and AMEND_DETAILS_HIST.AMENDHIST_LC_BRN_CODE=? and AMEND_DETAILS_HIST.AMENDHIST_LC_SERIAL=? and AMEND_DETAILS_HIST.AMENDHIST_LC_TYPE=? and AMEND_DETAILS_HIST.AMENDHIST_LC_YEAR=?");
                _pstmt = _conn.prepareStatement(_sql.toString());
            if (_amendhistHistDate == null) {_pstmt.setTimestamp(1, null);} else {_pstmt.setTimestamp(1, new java.sql.Timestamp(_amendhistHistDate.getTime()));}
           
            _pstmt.setInt(2, _amendhistLcAmdSl);
            _pstmt.setInt(3, _amendhistLcBrnCode);
            _pstmt.setInt(4, _amendhistLcSerial);
            _pstmt.setString(5, _amendhistLcType);
            _pstmt.setInt(6, _amendhistLcYear);
                 rs = _pstmt.executeQuery();
                 if (rs.next())
                {
                maxsl = rs.getInt(1);
                }
                rs.close();
                }
                catch(SQLException e) {
                if(rs!=null) try { rs.close();} catch(Exception e2) {}
                throw e;
            }
            return maxsl;
        }
    
    public AmendDetailsHist loadByKey(java.util.Date _amendhistHistDate, int _amendhistLcAmdSl, int _amendhistLcBrnCode, int _amendhistLcSerial, String _amendhistLcType, int _amendhistLcYear) throws SQLException {
        Connection _conn = null;
        try {
            _conn = openConnection();
            AmendDetailsHist _obj = loadByKey(_amendhistHistDate, _amendhistLcAmdSl, _amendhistLcBrnCode, _amendhistLcSerial, _amendhistLcType, _amendhistLcYear, _conn);
            if ( _obj != null)
            {
            OldData_Key = "AMEND_DETAILS_HIST" + TableValueSep + OldDataChar + _obj.getAmendhistLcBrnCode() + _obj.getAmendhistLcType() + _obj.getAmendhistLcYear() + _obj.getAmendhistLcSerial() + _obj.getAmendhistLcAmdSl() + _obj.getAmendhistHistSl() + _obj.getAmendhistHistDate();
        DataBlock_Old = _obj.getAmendhistLcBrnCode() + JNDINames.splitchar + _obj.getAmendhistLcType() + JNDINames.splitchar + _obj.getAmendhistLcYear() + JNDINames.splitchar + _obj.getAmendhistLcSerial() + JNDINames.splitchar + _obj.getAmendhistLcAmdSl() + JNDINames.splitchar + _obj.getAmendhistHistSl() + JNDINames.splitchar + _obj.getAmendhistHistDate() + JNDINames.splitchar + _obj.getAmendhistSndrRef() + JNDINames.splitchar + _obj.getAmendhistRcvrRef() + JNDINames.splitchar + _obj.getAmendhistDocCrNum() + JNDINames.splitchar + _obj.getAmendhistIssuingBnkReq() + JNDINames.splitchar + _obj.getAmendhistIssuingType() + JNDINames.splitchar + _obj.getAmendhistIssuingBrnCode() + JNDINames.splitchar + _obj.getAmendhistIssuingBicCode() + JNDINames.splitchar + _obj.getAmendhistIssuingRoutid() + JNDINames.splitchar + _obj.getAmendhistIssuingBnkCode() + JNDINames.splitchar + _obj.getAmendhistIssuingAddr1() + JNDINames.splitchar + _obj.getAmendhistIssuingAddr2() + JNDINames.splitchar + _obj.getAmendhistIssuingAddr3() + JNDINames.splitchar + _obj.getAmendhistIssuingAddr4() + JNDINames.splitchar + _obj.getAmendhistIssuingAddr5() + JNDINames.splitchar + _obj.getAmendhistNonBnkIssur() + JNDINames.splitchar + _obj.getAmendhistDateOfIssue() + JNDINames.splitchar + _obj.getAmendhistDateOfAmendmnt() + JNDINames.splitchar + _obj.getAmendhistPurposeOfMsg() + JNDINames.splitchar + _obj.getAmendhistCancelRequest() + JNDINames.splitchar + _obj.getAmendhistAdvisingBnkReq() + JNDINames.splitchar + _obj.getAmendhistAdvisingBnkType() + JNDINames.splitchar + _obj.getAmendhistAdvisingBrnCode() + JNDINames.splitchar + _obj.getAmendhistAdvisingBicCode() + JNDINames.splitchar + _obj.getAmendhistAdvisingRoutid() + JNDINames.splitchar + _obj.getAmendhistAdvisingBnkCode() + JNDINames.splitchar + _obj.getAmendhistAdvisingAddr1() + JNDINames.splitchar + _obj.getAmendhistAdvisingAddr2() + JNDINames.splitchar + _obj.getAmendhistAdvisingAddr3() + JNDINames.splitchar + _obj.getAmendhistAdvisingAddr4() + JNDINames.splitchar + _obj.getAmendhistAdvisingAddr5() + JNDINames.splitchar + _obj.getAmendhistSecondAdvReq() + JNDINames.splitchar + _obj.getAmendhistSecondAdvType() + JNDINames.splitchar + _obj.getAmendhistSecondAdvBrnCode() + JNDINames.splitchar + _obj.getAmendhistSecondAdvBicCode() + JNDINames.splitchar + _obj.getAmendhistSecondAdvRoutid() + JNDINames.splitchar + _obj.getAmendhistSecondAdvBnkCode() + JNDINames.splitchar + _obj.getAmendhistSecondAdvAddr1() + JNDINames.splitchar + _obj.getAmendhistSecondAdvAddr2() + JNDINames.splitchar + _obj.getAmendhistSecondAdvAddr3() + JNDINames.splitchar + _obj.getAmendhistSecondAdvAddr4() + JNDINames.splitchar + _obj.getAmendhistSecondAdvAddr5() + JNDINames.splitchar + _obj.getAmendhistNewBeneficiary() + JNDINames.splitchar + _obj.getAmendhistNewDateOfExpiry() + JNDINames.splitchar + _obj.getAmendhistIncrDocCrAmt() + JNDINames.splitchar + _obj.getAmendhistDecrDocCrAmt() + JNDINames.splitchar + _obj.getAmendhistNewAddnlAmt() + JNDINames.splitchar + _obj.getAmendhistPlaceTakinInChrg() + JNDINames.splitchar + _obj.getAmendhistPortOfLoading() + JNDINames.splitchar + _obj.getAmendhistPortOfDischarge() + JNDINames.splitchar + _obj.getAmendhistPlaceOfFinalDest() + JNDINames.splitchar + _obj.getAmendhistDateOfShipment() + JNDINames.splitchar + _obj.getAmendhistDescGoddSer1() + JNDINames.splitchar + _obj.getAmendhistDocReq1() + JNDINames.splitchar + _obj.getAmendhistAddCondition1() + JNDINames.splitchar + _obj.getAmendhistChrgPayable1() + JNDINames.splitchar + _obj.getAmendhistChrgPayable2() + JNDINames.splitchar + _obj.getAmendhistChrgPayable3() + JNDINames.splitchar + _obj.getAmendhistChrgPayable4() + JNDINames.splitchar + _obj.getAmendhistChrgPayable5() + JNDINames.splitchar + _obj.getAmendhistChrgPayable6() + JNDINames.splitchar + _obj.getAmendhistSndrRecInfo1() + JNDINames.splitchar + _obj.getAmendhistSndrRecInfo2() + JNDINames.splitchar + _obj.getAmendhistSndrRecInfo3() + JNDINames.splitchar + _obj.getAmendhistSndrRecInfo4() + JNDINames.splitchar + _obj.getAmendhistSndrRecInfo5() + JNDINames.splitchar + _obj.getAmendhistSndrRecInfo6() + JNDINames.splitchar  + _obj.getAmendhistChkbox() + JNDINames.splitchar + _obj.getAmendhistIssuingCntry() + JNDINames.splitchar + _obj.getAmendhistAdvisingCntry() + JNDINames.splitchar + _obj.getAmendhistSecondAdvCntry() + JNDINames.splitchar + _obj.getAmendhistIssueRef() + JNDINames.splitchar + _obj.getAmdhistFormOfDocCredit() + JNDINames.splitchar + _obj.getAmdhistLcApplicableRules() + JNDINames.splitchar + _obj.getAmdhistLcApplReq() + JNDINames.splitchar + _obj.getAmdhistLcApplName() + JNDINames.splitchar + _obj.getAmdhistLcApplAddr1() + JNDINames.splitchar + _obj.getAmdhistLcApplAddr2() + JNDINames.splitchar + _obj.getAmdhistLcApplAddr3() + JNDINames.splitchar + _obj.getAmdhistLcApplAddr4() + JNDINames.splitchar + _obj.getAmdhistLcApplAddr5() + JNDINames.splitchar + _obj.getAmdhistLcAvlWithType() + JNDINames.splitchar + _obj.getAmdhistLcAvlWithBrnCode() + JNDINames.splitchar + _obj.getAmdhistLcLcAvlWithRoutid() + JNDINames.splitchar + _obj.getAmdhistLcAvlWithBnkCode() + JNDINames.splitchar + _obj.getAmdhistLcAvlWithAddr1() + JNDINames.splitchar + _obj.getAmdhistLcAvlWithAddr2() + JNDINames.splitchar + _obj.getAmdhistLcAvlWithAddr3() + JNDINames.splitchar + _obj.getAmdhistLcAvlWithAddr4() + JNDINames.splitchar + _obj.getAmdhistLcAvlWithAddr5() + JNDINames.splitchar + _obj.getAmdhistLcAvlWithCntry() + JNDINames.splitchar + _obj.getAmdhistLcDraftsAt1() + JNDINames.splitchar + _obj.getAmdhistLcDraftsAt2() + JNDINames.splitchar + _obj.getAmdhistLcDraftsAt3() + JNDINames.splitchar + _obj.getAmdhistLcDraweeReq() + JNDINames.splitchar + _obj.getAmdhistLcDraweeType() + JNDINames.splitchar + _obj.getAmdhistLcDraweeBrnCode() + JNDINames.splitchar + _obj.getAmdhistLcDraweeBicCode() + JNDINames.splitchar + _obj.getAmdhistLcDraweeRoutid() + JNDINames.splitchar + _obj.getAmdhistLcDraweeBnkCode() + JNDINames.splitchar + _obj.getAmdhistLcDraweeAddr1() + JNDINames.splitchar + _obj.getAmdhistLcDraweeAddr2() + JNDINames.splitchar + _obj.getAmdhistLcDraweeAddr3() + JNDINames.splitchar + _obj.getAmdhistLcDraweeAddr4() + JNDINames.splitchar + _obj.getAmdhistLcDraweeAddr5() + JNDINames.splitchar + _obj.getAmdhistDraweeCntryCode() + JNDINames.splitchar + _obj.getAmdhistLcMixedPayDetails1() + JNDINames.splitchar + _obj.getAmdhistLcMixedPayDetails2() + JNDINames.splitchar + _obj.getAmdhistLcMixedPayDetails3() + JNDINames.splitchar + _obj.getAmdhistLcMixedPayDetails4() + JNDINames.splitchar + _obj.getAmdhistLcMixedPayDetails5() + JNDINames.splitchar + _obj.getAmdhistLcDefPayDetails1() + JNDINames.splitchar + _obj.getAmdhistLcDefPayDetails2() + JNDINames.splitchar + _obj.getAmdhistLcDefPayDetails3() + JNDINames.splitchar + _obj.getAmdhistLcDefPayDetails4() + JNDINames.splitchar + _obj.getAmdhistLcDefPayDetails5() + JNDINames.splitchar + _obj.getAmdhistLcPartialShipments() + JNDINames.splitchar + _obj.getAmdhistLcTranshipment() + JNDINames.splitchar + _obj.getAmdhistLcConfirmationInst() + JNDINames.splitchar +  _obj.getAmdhistLcReimbReq() + JNDINames.splitchar + _obj.getAmdhistLcReimbType() + JNDINames.splitchar + _obj.getAmdhistLcReimbBrnCode() + JNDINames.splitchar + _obj.getAmdhistLcReimbBicCode() + JNDINames.splitchar + _obj.getAmdhistLcReimbRoutid() + JNDINames.splitchar + _obj.getAmdhistLcReimbBnkCode() + JNDINames.splitchar + _obj.getAmdhistLcReimbAddr1() + JNDINames.splitchar + _obj.getAmdhistLcReimbAddr2() + JNDINames.splitchar + _obj.getAmdhistLcReimbAddr3() + JNDINames.splitchar + _obj.getAmdhistLcReimbAddr4() + JNDINames.splitchar + _obj.getAmdhistLcReimbAddr5() + JNDINames.splitchar + _obj.getAmdhistLcInstPaying1() + JNDINames.splitchar + _obj.getAmdhistLcInstPaying2() + JNDINames.splitchar + _obj.getAmdhistLcInstPaying3() + JNDINames.splitchar + _obj.getAmdhistLcInstPaying4() + JNDINames.splitchar + _obj.getAmdhistLcInstPaying5() + JNDINames.splitchar + _obj.getAmdhistLcInstPaying6() + JNDINames.splitchar + _obj.getAmdhistLcInstPaying7() + JNDINames.splitchar + _obj.getAmdhistLcInstPaying8() + JNDINames.splitchar + _obj.getAmdhistLcInstPaying9() + JNDINames.splitchar + _obj.getAmdhistLcInstPaying10() + JNDINames.splitchar + _obj.getAmdhistLcInstPaying11() + JNDINames.splitchar + _obj.getAmdhistLcInstPaying12() + JNDINames.splitchar + _obj.getAmdhistLcSecondAdvReq() + JNDINames.splitchar + _obj.getAmdhistLcSecondAdvType() + JNDINames.splitchar + _obj.getAmdhistLcSecondAdvBrnCode() + JNDINames.splitchar + _obj.getAmdhistLcSecondAdvBicCode() + JNDINames.splitchar + _obj.getAmdhistLcSecondAdvRoutid() + JNDINames.splitchar + _obj.getAmdhistLcSecondAdvBnkCode() + JNDINames.splitchar + _obj.getAmdhistLcSecondAdvAddr1() + JNDINames.splitchar + _obj.getAmdhistLcSecondAdvAddr2() + JNDINames.splitchar + _obj.getAmdhistLcSecondAdvAddr3() + JNDINames.splitchar + _obj.getAmdhistLcSecondAdvAddr4() + JNDINames.splitchar + _obj.getAmdhistLcSecondAdvAddr5() + JNDINames.splitchar + _obj.getAmdhistLcSecAdvCntrycode() + JNDINames.splitchar + _obj.getAmendHistLcAvlWithCodetyp() + JNDINames.splitchar + _obj.getAmendhistLcReimbCntryCode();
        }
            closeConnection(_conn);
            return _obj;
        }
        catch(SQLException e) {
            if(_conn != null)  try { closeConnection(_conn); } catch(SQLException e2) { }
            throw e;
        }
    }

}
