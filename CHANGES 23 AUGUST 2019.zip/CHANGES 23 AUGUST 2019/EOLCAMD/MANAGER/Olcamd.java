package panacea.OLC.Update;


/******************SQL2JAVA_IMPORT_BEGIN******************/

/******************SQL2JAVA_IMPORT_END********************/


public class Olcamd
/******************SQL2JAVA_EXTENDS_BEGIN******************/

/******************SQL2JAVA_EXTENDS_END********************/

{

/******************SQL2JAVA_CLASS_BEGIN******************/

/******************SQL2JAVA_CLASS_END********************/


    private int _olcaBrnCode;
    private boolean __olcaBrnCode_is_modified;
    private String _olcaLcType;
    private boolean __olcaLcType_is_modified;
    private int _olcaLcYear;
    private boolean __olcaLcYear_is_modified;
    private int _olcaLcSl;
    private boolean __olcaLcSl_is_modified;
    private int _olcaAmdSl;
    private boolean __olcaAmdSl_is_modified;
    private java.util.Date _olcaEntryDate;
    private boolean __olcaEntryDate_is_modified;
    private String _olcaCustLetterNum;
    private boolean __olcaCustLetterNum_is_modified;
    private java.util.Date _olcaCustLtrDate;
    private boolean __olcaCustLtrDate_is_modified;
    private char _olcaRsnForAmd;
    private boolean __olcaRsnForAmd_is_modified;
    private char _olcaChangeOfBenef;
    private boolean __olcaChangeOfBenef_is_modified;
    private String _olcaBenefCode;
    private boolean __olcaBenefCode_is_modified;
    private String _olcaBenefName;
    private boolean __olcaBenefName_is_modified;
    private String _olcaBenefAddr1;
    private boolean __olcaBenefAddr1_is_modified;
    private String _olcaBenefAddr2;
    private boolean __olcaBenefAddr2_is_modified;
    private String _olcaBenefAddr3;
    private boolean __olcaBenefAddr3_is_modified;
    private String _olcaBenefAddr4;
    private boolean __olcaBenefAddr4_is_modified;
    private String _olcaBenefAddr5;
    private boolean __olcaBenefAddr5_is_modified;
    private String _olcaBenefCntryCode;
    private boolean __olcaBenefCntryCode_is_modified;
    private char _olcaEnhancemntReducn;
    private boolean __olcaEnhancemntReducn_is_modified;
    private String _olcaLcCurrCode;
    private boolean __olcaLcCurrCode_is_modified;
    private double _olcaAmendedAmt;
    private boolean __olcaAmendedAmt_is_modified;
    private double _olcaPosDevAllwd;
    private boolean __olcaPosDevAllwd_is_modified;
    private double _olcaNegDevAllwd;
    private boolean __olcaNegDevAllwd_is_modified;
    private double _olcaDevAmt;
    private boolean __olcaDevAmt_is_modified;
    private char _olcaAmtQualfr;
    private boolean __olcaAmtQualfr_is_modified;
    private String _olcaPriceTerms;
    private boolean __olcaPriceTerms_is_modified;
    private java.util.Date _olcaLastDateOfNeg;
    private boolean __olcaLastDateOfNeg_is_modified;
    private String _olcaPlaceOfExpiry;
    private boolean __olcaPlaceOfExpiry_is_modified;
    private java.util.Date _olcaLatestDateOfShpmnt;
    private boolean __olcaLatestDateOfShpmnt_is_modified;
    private char _olcaWithinValidateLc;
    private boolean __olcaWithinValidateLc_is_modified;
    private char _olcaLcUiBorneByApplcnt;
    private boolean __olcaLcUiBorneByApplcnt_is_modified;
    private int _olcaNofTenors;
    private boolean __olcaNofTenors_is_modified;
    private double _olcaAddLiabLcCurr;
    private boolean __olcaAddLiabLcCurr_is_modified;
    private double _olcaConvRateBaseCurr;
    private boolean __olcaConvRateBaseCurr_is_modified;
    private double _olcaAddLiabBaseCurr;
    private boolean __olcaAddLiabBaseCurr_is_modified;
    private double _olcaConvRateLimCurr;
    private boolean __olcaConvRateLimCurr_is_modified;
    private double _olcaTotLiabLimCurr;
    private boolean __olcaTotLiabLimCurr_is_modified;
    private double _olcaTotLiabLcCurr;
    private boolean __olcaTotLiabLcCurr_is_modified;
    private double _olcaTotLiabBaseCurr;
    private boolean __olcaTotLiabBaseCurr_is_modified;
    private char _olcaReimbChrgsBy;
    private boolean __olcaReimbChrgsBy_is_modified;
    private double _olcaPercRcPaidByApplcnt;
    private boolean __olcaPercRcPaidByApplcnt_is_modified;
    private String _olcaNostroAlphaCode;
    private boolean __olcaNostroAlphaCode_is_modified;
    private String _olcaAdvThruBk;
    private boolean __olcaAdvThruBk_is_modified;
    private String _olcaAdvThruBrn;
    private boolean __olcaAdvThruBrn_is_modified;
    private char _olcaLcToBeCnfrmd;
    private boolean __olcaLcToBeCnfrmd_is_modified;
    private String _olcaLcToBeCnfrmdByBk;
    private boolean __olcaLcToBeCnfrmdByBk_is_modified;
    private String _olcaLcToBeCnfrmdByBrn;
    private boolean __olcaLcToBeCnfrmdByBrn_is_modified;
    private char _olcaRestricted;
    private boolean __olcaRestricted_is_modified;
    private char _olcaRestrictedToUs;
    private boolean __olcaRestrictedToUs_is_modified;
    private String _olcaRestrictedBkCode;
    private boolean __olcaRestrictedBkCode_is_modified;
    private String _olcaRestrictedBrnCode;
    private boolean __olcaRestrictedBrnCode_is_modified;
    private char _olcaCrAvlblBy;
    private boolean __olcaCrAvlblBy_is_modified;
    private char _olcaIrrevocable;
    private boolean __olcaIrrevocable_is_modified;
    private char _olcaPartShpmnt;
    private boolean __olcaPartShpmnt_is_modified;
    private char _olcaTranShpmnt;
    private boolean __olcaTranShpmnt_is_modified;
    private char _olcaLcTransfrbl;
    private boolean __olcaLcTransfrbl_is_modified;
    private char _olcaDftDtls;
    private boolean __olcaDftDtls_is_modified;
    private double _olcaPercDftValue;
    private boolean __olcaPercDftValue_is_modified;
    private char _olcaDftToBeDrawnOn;
    private boolean __olcaDftToBeDrawnOn_is_modified;
    private String _olcaDftOnBk;
    private boolean __olcaDftOnBk_is_modified;
    private String _olcaDftOnBrn;
    private boolean __olcaDftOnBrn_is_modified;
    private String _olcaSpecText1;
    private boolean __olcaSpecText1_is_modified;
    private String _olcaSpecText2;
    private boolean __olcaSpecText2_is_modified;
    private String _olcaSpecText3;
    private boolean __olcaSpecText3_is_modified;
    private String _olcaSpecText4;
    private boolean __olcaSpecText4_is_modified;
    private char _olcaPrimeRateClauseReq;
    private boolean __olcaPrimeRateClauseReq_is_modified;
    private char _olcaShpmntMode;
    private boolean __olcaShpmntMode_is_modified;
    private char _olcaLloydsClauseReq;
    private boolean __olcaLloydsClauseReq_is_modified;
    private int _olcaMaxShipAge;
    private boolean __olcaMaxShipAge_is_modified;
    private char _olcaShortFormOfBl;
    private boolean __olcaShortFormOfBl_is_modified;
    private char _olcaLashTransDocsAllwd;
    private boolean __olcaLashTransDocsAllwd_is_modified;
    private double _olcaPercOfInsValueCvrd;
    private boolean __olcaPercOfInsValueCvrd_is_modified;
    private String _olcaInsPolicyNum;
    private boolean __olcaInsPolicyNum_is_modified;
    private java.util.Date _olcaInsDate;
    private boolean __olcaInsDate_is_modified;
    private String _olcaInsCurr;
    private boolean __olcaInsCurr_is_modified;
    private double _olcaInsAmt;
    private boolean __olcaInsAmt_is_modified;
    private String _olcaPremiumCurr;
    private boolean __olcaPremiumCurr_is_modified;
    private double _olcaPremiumAmt;
    private boolean __olcaPremiumAmt_is_modified;
    private String _olcaInsCompany;
    private boolean __olcaInsCompany_is_modified;
    private String _olcaInsCompanyName;
    private boolean __olcaInsCompanyName_is_modified;
    private String _olcaCooIssBy;
    private boolean __olcaCooIssBy_is_modified;
    private String _olcaOtherCompAuth;
    private boolean __olcaOtherCompAuth_is_modified;
    private char _olcaIntermediaryTrade;
    private boolean __olcaIntermediaryTrade_is_modified;
    private char _olcaInspTestCertReq;
    private boolean __olcaInspTestCertReq_is_modified;
    private String _olcaCertBy;
    private boolean __olcaCertBy_is_modified;
    private char _olcaImpUnder;
    private boolean __olcaImpUnder_is_modified;
    private String _olcaImpPolicyDet;
    private boolean __olcaImpPolicyDet_is_modified;
    private String _olcaImpRef;
    private boolean __olcaImpRef_is_modified;
    private double _olcaContraAmt;
    private boolean __olcaContraAmt_is_modified;
    private double _olcaUsanceCharges;
    private boolean __olcaUsanceCharges_is_modified;
    private int _olcaUsnChgTakenDays;
    private boolean __olcaUsnChgTakenDays_is_modified;
    private double _olcaCommitmentCharges;
    private boolean __olcaCommitmentCharges_is_modified;
    private int _olcaCommitChgTakenDays;
    private boolean __olcaCommitChgTakenDays_is_modified;
    private long _tranchgsChgsSl;
    private boolean __tranchgsChgsSl_is_modified;
    private long _transtlmntInvNum;
    private boolean __transtlmntInvNum_is_modified;
    private int _postTranBrn;
    private boolean __postTranBrn_is_modified;
    private java.util.Date _postTranDate;
    private boolean __postTranDate_is_modified;
    private int _postTranBatchNum;
    private boolean __postTranBatchNum_is_modified;
    private String _olcaEntdBy;
    private boolean __olcaEntdBy_is_modified;
    private java.util.Date _olcaEntdOn;
    private boolean __olcaEntdOn_is_modified;
    private String _olcaLastmodBy;
    private boolean __olcaLastmodBy_is_modified;
    private java.util.Date _olcaLastmodOn;
    private boolean __olcaLastmodOn_is_modified;
    private String _olcaAuthBy;
    private boolean __olcaAuthBy_is_modified;
    private java.util.Date _olcaAuthOn;
    private boolean __olcaAuthOn_is_modified;
    private String _olcaRejBy;
    private boolean __olcaRejBy_is_modified;
    private java.util.Date _olcaRejOn;
    private boolean __olcaRejOn_is_modified;
    private char _olcaAmdChgPayBy;
    private boolean __olcaAmdChgPayBy_is_modified;
    private String _olcaPerOfPresDays;
    private boolean __olcaPerOfPresDays_is_modified;
    private char _olcaChgInDescGoods;
    private boolean __olcaChgInDescGoods_is_modified;
    private char _olcaChgInDoc;
    private boolean __olcaChgInDoc_is_modified;
    private char _olcaChgInAddlCond;
    private boolean __olcaChgInAddlCond_is_modified;
    private char _olcaReqForCancel;
    private boolean __olcaReqForCancel_is_modified;
    private char _olcaChgOfAppl;
    private boolean __olcaChgOfAppl_is_modified;
    private char _olcaChgInAvlWith;
    private boolean __olcaChgInAvlWith_is_modified;
    private char _olcaChgInDraweePay;
    private boolean __olcaChgInDraweePay_is_modified;
    private char _olcaChgInReimb;
    private boolean __olcaChgInReimb_is_modified;
    private char _olcaChgInAdvBk;
    private boolean __olcaChgInAdvBk_is_modified;
    private char _olcaChgInFormOfDc;
    private boolean __olcaChgInFormOfDc_is_modified;
    private char _olcaChgInApplRules;
    private boolean __olcaChgInApplRules_is_modified;
    private boolean _isNew = true;

    public int getOlcaBrnCode() { return _olcaBrnCode; }
    public void setOlcaBrnCode(int newVal) { this._olcaBrnCode = newVal; __olcaBrnCode_is_modified = true; }
    public boolean olcaBrnCodeIsModifiedS2j() { return __olcaBrnCode_is_modified; }
    public String getOlcaLcType() { return _olcaLcType; }
    public void setOlcaLcType(String newVal) { this._olcaLcType = newVal; __olcaLcType_is_modified = true; }
    public boolean olcaLcTypeIsModifiedS2j() { return __olcaLcType_is_modified; }
    public int getOlcaLcYear() { return _olcaLcYear; }
    public void setOlcaLcYear(int newVal) { this._olcaLcYear = newVal; __olcaLcYear_is_modified = true; }
    public boolean olcaLcYearIsModifiedS2j() { return __olcaLcYear_is_modified; }
    public int getOlcaLcSl() { return _olcaLcSl; }
    public void setOlcaLcSl(int newVal) { this._olcaLcSl = newVal; __olcaLcSl_is_modified = true; }
    public boolean olcaLcSlIsModifiedS2j() { return __olcaLcSl_is_modified; }
    public int getOlcaAmdSl() { return _olcaAmdSl; }
    public void setOlcaAmdSl(int newVal) { this._olcaAmdSl = newVal; __olcaAmdSl_is_modified = true; }
    public boolean olcaAmdSlIsModifiedS2j() { return __olcaAmdSl_is_modified; }
    public java.util.Date getOlcaEntryDate() { return _olcaEntryDate; }
    public void setOlcaEntryDate(java.util.Date newVal) { this._olcaEntryDate = newVal; __olcaEntryDate_is_modified = true; }
    public boolean olcaEntryDateIsModifiedS2j() { return __olcaEntryDate_is_modified; }
    public String getOlcaCustLetterNum() { return _olcaCustLetterNum == null ? "" : _olcaCustLetterNum.trim(); }
    public void setOlcaCustLetterNum(String newVal) { this._olcaCustLetterNum = newVal; __olcaCustLetterNum_is_modified = true; }
    public boolean olcaCustLetterNumIsModifiedS2j() { return __olcaCustLetterNum_is_modified; }
    public java.util.Date getOlcaCustLtrDate() { return _olcaCustLtrDate; }
    public void setOlcaCustLtrDate(java.util.Date newVal) { this._olcaCustLtrDate = newVal; __olcaCustLtrDate_is_modified = true; }
    public boolean olcaCustLtrDateIsModifiedS2j() { return __olcaCustLtrDate_is_modified; }
    public char getOlcaRsnForAmd() { return _olcaRsnForAmd; }
    public void setOlcaRsnForAmd(char newVal) { this._olcaRsnForAmd = newVal; __olcaRsnForAmd_is_modified = true; }
    public boolean olcaRsnForAmdIsModifiedS2j() { return __olcaRsnForAmd_is_modified; }
    public char getOlcaChangeOfBenef() { return _olcaChangeOfBenef; }
    public void setOlcaChangeOfBenef(char newVal) { this._olcaChangeOfBenef = newVal; __olcaChangeOfBenef_is_modified = true; }
    public boolean olcaChangeOfBenefIsModifiedS2j() { return __olcaChangeOfBenef_is_modified; }
    public String getOlcaBenefCode() { return _olcaBenefCode == null ? "" : _olcaBenefCode.trim(); }
    public void setOlcaBenefCode(String newVal) { this._olcaBenefCode = newVal; __olcaBenefCode_is_modified = true; }
    public boolean olcaBenefCodeIsModifiedS2j() { return __olcaBenefCode_is_modified; }
    public String getOlcaBenefName() { return _olcaBenefName == null ? "" : _olcaBenefName.trim(); }
    public void setOlcaBenefName(String newVal) { this._olcaBenefName = newVal; __olcaBenefName_is_modified = true; }
    public boolean olcaBenefNameIsModifiedS2j() { return __olcaBenefName_is_modified; }
    public String getOlcaBenefAddr1() { return _olcaBenefAddr1 == null ? "" : _olcaBenefAddr1.trim(); }
    public void setOlcaBenefAddr1(String newVal) { this._olcaBenefAddr1 = newVal; __olcaBenefAddr1_is_modified = true; }
    public boolean olcaBenefAddr1IsModifiedS2j() { return __olcaBenefAddr1_is_modified; }
    public String getOlcaBenefAddr2() { return _olcaBenefAddr2 == null ? "" : _olcaBenefAddr2.trim(); }
    public void setOlcaBenefAddr2(String newVal) { this._olcaBenefAddr2 = newVal; __olcaBenefAddr2_is_modified = true; }
    public boolean olcaBenefAddr2IsModifiedS2j() { return __olcaBenefAddr2_is_modified; }
    public String getOlcaBenefAddr3() { return _olcaBenefAddr3 == null ? "" : _olcaBenefAddr3.trim(); }
    public void setOlcaBenefAddr3(String newVal) { this._olcaBenefAddr3 = newVal; __olcaBenefAddr3_is_modified = true; }
    public boolean olcaBenefAddr3IsModifiedS2j() { return __olcaBenefAddr3_is_modified; }
    public String getOlcaBenefAddr4() { return _olcaBenefAddr4 == null ? "" : _olcaBenefAddr4.trim(); }
    public void setOlcaBenefAddr4(String newVal) { this._olcaBenefAddr4 = newVal; __olcaBenefAddr4_is_modified = true; }
    public boolean olcaBenefAddr4IsModifiedS2j() { return __olcaBenefAddr4_is_modified; }
    public String getOlcaBenefAddr5() { return _olcaBenefAddr5 == null ? "" : _olcaBenefAddr5.trim(); }
    public void setOlcaBenefAddr5(String newVal) { this._olcaBenefAddr5 = newVal; __olcaBenefAddr5_is_modified = true; }
    public boolean olcaBenefAddr5IsModifiedS2j() { return __olcaBenefAddr5_is_modified; }
    public String getOlcaBenefCntryCode() { return _olcaBenefCntryCode == null ? "" : _olcaBenefCntryCode.trim(); }
    public void setOlcaBenefCntryCode(String newVal) { this._olcaBenefCntryCode = newVal; __olcaBenefCntryCode_is_modified = true; }
    public boolean olcaBenefCntryCodeIsModifiedS2j() { return __olcaBenefCntryCode_is_modified; }
    public char getOlcaEnhancemntReducn() { return _olcaEnhancemntReducn; }
    public void setOlcaEnhancemntReducn(char newVal) { this._olcaEnhancemntReducn = newVal; __olcaEnhancemntReducn_is_modified = true; }
    public boolean olcaEnhancemntReducnIsModifiedS2j() { return __olcaEnhancemntReducn_is_modified; }
    public String getOlcaLcCurrCode() { return _olcaLcCurrCode == null ? "" : _olcaLcCurrCode.trim(); }
    public void setOlcaLcCurrCode(String newVal) { this._olcaLcCurrCode = newVal; __olcaLcCurrCode_is_modified = true; }
    public boolean olcaLcCurrCodeIsModifiedS2j() { return __olcaLcCurrCode_is_modified; }
    public double getOlcaAmendedAmt() { return _olcaAmendedAmt; }
    public void setOlcaAmendedAmt(double newVal) { this._olcaAmendedAmt = newVal; __olcaAmendedAmt_is_modified = true; }
    public boolean olcaAmendedAmtIsModifiedS2j() { return __olcaAmendedAmt_is_modified; }
    public double getOlcaPosDevAllwd() { return _olcaPosDevAllwd; }
    public void setOlcaPosDevAllwd(double newVal) { this._olcaPosDevAllwd = newVal; __olcaPosDevAllwd_is_modified = true; }
    public boolean olcaPosDevAllwdIsModifiedS2j() { return __olcaPosDevAllwd_is_modified; }
    public double getOlcaNegDevAllwd() { return _olcaNegDevAllwd; }
    public void setOlcaNegDevAllwd(double newVal) { this._olcaNegDevAllwd = newVal; __olcaNegDevAllwd_is_modified = true; }
    public boolean olcaNegDevAllwdIsModifiedS2j() { return __olcaNegDevAllwd_is_modified; }
    public double getOlcaDevAmt() { return _olcaDevAmt; }
    public void setOlcaDevAmt(double newVal) { this._olcaDevAmt = newVal; __olcaDevAmt_is_modified = true; }
    public boolean olcaDevAmtIsModifiedS2j() { return __olcaDevAmt_is_modified; }
    public char getOlcaAmtQualfr() { return _olcaAmtQualfr; }
    public void setOlcaAmtQualfr(char newVal) { this._olcaAmtQualfr = newVal; __olcaAmtQualfr_is_modified = true; }
    public boolean olcaAmtQualfrIsModifiedS2j() { return __olcaAmtQualfr_is_modified; }
    public String getOlcaPriceTerms() { return _olcaPriceTerms == null ? "" : _olcaPriceTerms.trim(); }
    public void setOlcaPriceTerms(String newVal) { this._olcaPriceTerms = newVal; __olcaPriceTerms_is_modified = true; }
    public boolean olcaPriceTermsIsModifiedS2j() { return __olcaPriceTerms_is_modified; }
    public java.util.Date getOlcaLastDateOfNeg() { return _olcaLastDateOfNeg; }
    public void setOlcaLastDateOfNeg(java.util.Date newVal) { this._olcaLastDateOfNeg = newVal; __olcaLastDateOfNeg_is_modified = true; }
    public boolean olcaLastDateOfNegIsModifiedS2j() { return __olcaLastDateOfNeg_is_modified; }
    public String getOlcaPlaceOfExpiry() { return _olcaPlaceOfExpiry == null ? "" : _olcaPlaceOfExpiry.trim(); }
    public void setOlcaPlaceOfExpiry(String newVal) { this._olcaPlaceOfExpiry = newVal; __olcaPlaceOfExpiry_is_modified = true; }
    public boolean olcaPlaceOfExpiryIsModifiedS2j() { return __olcaPlaceOfExpiry_is_modified; }
    public java.util.Date getOlcaLatestDateOfShpmnt() { return _olcaLatestDateOfShpmnt; }
    public void setOlcaLatestDateOfShpmnt(java.util.Date newVal) { this._olcaLatestDateOfShpmnt = newVal; __olcaLatestDateOfShpmnt_is_modified = true; }
    public boolean olcaLatestDateOfShpmntIsModifiedS2j() { return __olcaLatestDateOfShpmnt_is_modified; }
    public char getOlcaWithinValidateLc() { return _olcaWithinValidateLc; }
    public void setOlcaWithinValidateLc(char newVal) { this._olcaWithinValidateLc = newVal; __olcaWithinValidateLc_is_modified = true; }
    public boolean olcaWithinValidateLcIsModifiedS2j() { return __olcaWithinValidateLc_is_modified; }
    public char getOlcaLcUiBorneByApplcnt() { return _olcaLcUiBorneByApplcnt; }
    public void setOlcaLcUiBorneByApplcnt(char newVal) { this._olcaLcUiBorneByApplcnt = newVal; __olcaLcUiBorneByApplcnt_is_modified = true; }
    public boolean olcaLcUiBorneByApplcntIsModifiedS2j() { return __olcaLcUiBorneByApplcnt_is_modified; }
    public int getOlcaNofTenors() { return _olcaNofTenors; }
    public void setOlcaNofTenors(int newVal) { this._olcaNofTenors = newVal; __olcaNofTenors_is_modified = true; }
    public boolean olcaNofTenorsIsModifiedS2j() { return __olcaNofTenors_is_modified; }
    public double getOlcaAddLiabLcCurr() { return _olcaAddLiabLcCurr; }
    public void setOlcaAddLiabLcCurr(double newVal) { this._olcaAddLiabLcCurr = newVal; __olcaAddLiabLcCurr_is_modified = true; }
    public boolean olcaAddLiabLcCurrIsModifiedS2j() { return __olcaAddLiabLcCurr_is_modified; }
    public double getOlcaConvRateBaseCurr() { return _olcaConvRateBaseCurr; }
    public void setOlcaConvRateBaseCurr(double newVal) { this._olcaConvRateBaseCurr = newVal; __olcaConvRateBaseCurr_is_modified = true; }
    public boolean olcaConvRateBaseCurrIsModifiedS2j() { return __olcaConvRateBaseCurr_is_modified; }
    public double getOlcaAddLiabBaseCurr() { return _olcaAddLiabBaseCurr; }
    public void setOlcaAddLiabBaseCurr(double newVal) { this._olcaAddLiabBaseCurr = newVal; __olcaAddLiabBaseCurr_is_modified = true; }
    public boolean olcaAddLiabBaseCurrIsModifiedS2j() { return __olcaAddLiabBaseCurr_is_modified; }
    public double getOlcaConvRateLimCurr() { return _olcaConvRateLimCurr; }
    public void setOlcaConvRateLimCurr(double newVal) { this._olcaConvRateLimCurr = newVal; __olcaConvRateLimCurr_is_modified = true; }
    public boolean olcaConvRateLimCurrIsModifiedS2j() { return __olcaConvRateLimCurr_is_modified; }
    public double getOlcaTotLiabLimCurr() { return _olcaTotLiabLimCurr; }
    public void setOlcaTotLiabLimCurr(double newVal) { this._olcaTotLiabLimCurr = newVal; __olcaTotLiabLimCurr_is_modified = true; }
    public boolean olcaTotLiabLimCurrIsModifiedS2j() { return __olcaTotLiabLimCurr_is_modified; }
    public double getOlcaTotLiabLcCurr() { return _olcaTotLiabLcCurr; }
    public void setOlcaTotLiabLcCurr(double newVal) { this._olcaTotLiabLcCurr = newVal; __olcaTotLiabLcCurr_is_modified = true; }
    public boolean olcaTotLiabLcCurrIsModifiedS2j() { return __olcaTotLiabLcCurr_is_modified; }
    public double getOlcaTotLiabBaseCurr() { return _olcaTotLiabBaseCurr; }
    public void setOlcaTotLiabBaseCurr(double newVal) { this._olcaTotLiabBaseCurr = newVal; __olcaTotLiabBaseCurr_is_modified = true; }
    public boolean olcaTotLiabBaseCurrIsModifiedS2j() { return __olcaTotLiabBaseCurr_is_modified; }
    public char getOlcaReimbChrgsBy() { return _olcaReimbChrgsBy; }
    public void setOlcaReimbChrgsBy(char newVal) { this._olcaReimbChrgsBy = newVal; __olcaReimbChrgsBy_is_modified = true; }
    public boolean olcaReimbChrgsByIsModifiedS2j() { return __olcaReimbChrgsBy_is_modified; }
    public double getOlcaPercRcPaidByApplcnt() { return _olcaPercRcPaidByApplcnt; }
    public void setOlcaPercRcPaidByApplcnt(double newVal) { this._olcaPercRcPaidByApplcnt = newVal; __olcaPercRcPaidByApplcnt_is_modified = true; }
    public boolean olcaPercRcPaidByApplcntIsModifiedS2j() { return __olcaPercRcPaidByApplcnt_is_modified; }
    public String getOlcaNostroAlphaCode() { return _olcaNostroAlphaCode == null ? "" : _olcaNostroAlphaCode.trim(); }
    public void setOlcaNostroAlphaCode(String newVal) { this._olcaNostroAlphaCode = newVal; __olcaNostroAlphaCode_is_modified = true; }
    public boolean olcaNostroAlphaCodeIsModifiedS2j() { return __olcaNostroAlphaCode_is_modified; }
    public String getOlcaAdvThruBk() { return _olcaAdvThruBk == null ? "" : _olcaAdvThruBk.trim(); }
    public void setOlcaAdvThruBk(String newVal) { this._olcaAdvThruBk = newVal; __olcaAdvThruBk_is_modified = true; }
    public boolean olcaAdvThruBkIsModifiedS2j() { return __olcaAdvThruBk_is_modified; }
    public String getOlcaAdvThruBrn() { return _olcaAdvThruBrn == null ? "" : _olcaAdvThruBrn.trim(); }
    public void setOlcaAdvThruBrn(String newVal) { this._olcaAdvThruBrn = newVal; __olcaAdvThruBrn_is_modified = true; }
    public boolean olcaAdvThruBrnIsModifiedS2j() { return __olcaAdvThruBrn_is_modified; }
    public char getOlcaLcToBeCnfrmd() { return _olcaLcToBeCnfrmd; }
    public void setOlcaLcToBeCnfrmd(char newVal) { this._olcaLcToBeCnfrmd = newVal; __olcaLcToBeCnfrmd_is_modified = true; }
    public boolean olcaLcToBeCnfrmdIsModifiedS2j() { return __olcaLcToBeCnfrmd_is_modified; }
    public String getOlcaLcToBeCnfrmdByBk() { return _olcaLcToBeCnfrmdByBk == null ? "" : _olcaLcToBeCnfrmdByBk.trim(); }
    public void setOlcaLcToBeCnfrmdByBk(String newVal) { this._olcaLcToBeCnfrmdByBk = newVal; __olcaLcToBeCnfrmdByBk_is_modified = true; }
    public boolean olcaLcToBeCnfrmdByBkIsModifiedS2j() { return __olcaLcToBeCnfrmdByBk_is_modified; }
    public String getOlcaLcToBeCnfrmdByBrn() { return _olcaLcToBeCnfrmdByBrn == null ? "" : _olcaLcToBeCnfrmdByBrn.trim(); }
    public void setOlcaLcToBeCnfrmdByBrn(String newVal) { this._olcaLcToBeCnfrmdByBrn = newVal; __olcaLcToBeCnfrmdByBrn_is_modified = true; }
    public boolean olcaLcToBeCnfrmdByBrnIsModifiedS2j() { return __olcaLcToBeCnfrmdByBrn_is_modified; }
    public char getOlcaRestricted() { return _olcaRestricted; }
    public void setOlcaRestricted(char newVal) { this._olcaRestricted = newVal; __olcaRestricted_is_modified = true; }
    public boolean olcaRestrictedIsModifiedS2j() { return __olcaRestricted_is_modified; }
    public char getOlcaRestrictedToUs() { return _olcaRestrictedToUs; }
    public void setOlcaRestrictedToUs(char newVal) { this._olcaRestrictedToUs = newVal; __olcaRestrictedToUs_is_modified = true; }
    public boolean olcaRestrictedToUsIsModifiedS2j() { return __olcaRestrictedToUs_is_modified; }
    public String getOlcaRestrictedBkCode() { return _olcaRestrictedBkCode == null ? "" : _olcaRestrictedBkCode.trim(); }
    public void setOlcaRestrictedBkCode(String newVal) { this._olcaRestrictedBkCode = newVal; __olcaRestrictedBkCode_is_modified = true; }
    public boolean olcaRestrictedBkCodeIsModifiedS2j() { return __olcaRestrictedBkCode_is_modified; }
    public String getOlcaRestrictedBrnCode() { return _olcaRestrictedBrnCode == null ? "" : _olcaRestrictedBrnCode.trim(); }
    public void setOlcaRestrictedBrnCode(String newVal) { this._olcaRestrictedBrnCode = newVal; __olcaRestrictedBrnCode_is_modified = true; }
    public boolean olcaRestrictedBrnCodeIsModifiedS2j() { return __olcaRestrictedBrnCode_is_modified; }
    public char getOlcaCrAvlblBy() { return _olcaCrAvlblBy; }
    public void setOlcaCrAvlblBy(char newVal) { this._olcaCrAvlblBy = newVal; __olcaCrAvlblBy_is_modified = true; }
    public boolean olcaCrAvlblByIsModifiedS2j() { return __olcaCrAvlblBy_is_modified; }
    public char getOlcaIrrevocable() { return _olcaIrrevocable; }
    public void setOlcaIrrevocable(char newVal) { this._olcaIrrevocable = newVal; __olcaIrrevocable_is_modified = true; }
    public boolean olcaIrrevocableIsModifiedS2j() { return __olcaIrrevocable_is_modified; }
    public char getOlcaPartShpmnt() { return _olcaPartShpmnt; }
    public void setOlcaPartShpmnt(char newVal) { this._olcaPartShpmnt = newVal; __olcaPartShpmnt_is_modified = true; }
    public boolean olcaPartShpmntIsModifiedS2j() { return __olcaPartShpmnt_is_modified; }
    public char getOlcaTranShpmnt() { return _olcaTranShpmnt; }
    public void setOlcaTranShpmnt(char newVal) { this._olcaTranShpmnt = newVal; __olcaTranShpmnt_is_modified = true; }
    public boolean olcaTranShpmntIsModifiedS2j() { return __olcaTranShpmnt_is_modified; }
    public char getOlcaLcTransfrbl() { return _olcaLcTransfrbl; }
    public void setOlcaLcTransfrbl(char newVal) { this._olcaLcTransfrbl = newVal; __olcaLcTransfrbl_is_modified = true; }
    public boolean olcaLcTransfrblIsModifiedS2j() { return __olcaLcTransfrbl_is_modified; }
    public char getOlcaDftDtls() { return _olcaDftDtls; }
    public void setOlcaDftDtls(char newVal) { this._olcaDftDtls = newVal; __olcaDftDtls_is_modified = true; }
    public boolean olcaDftDtlsIsModifiedS2j() { return __olcaDftDtls_is_modified; }
    public double getOlcaPercDftValue() { return _olcaPercDftValue; }
    public void setOlcaPercDftValue(double newVal) { this._olcaPercDftValue = newVal; __olcaPercDftValue_is_modified = true; }
    public boolean olcaPercDftValueIsModifiedS2j() { return __olcaPercDftValue_is_modified; }
    public char getOlcaDftToBeDrawnOn() { return _olcaDftToBeDrawnOn; }
    public void setOlcaDftToBeDrawnOn(char newVal) { this._olcaDftToBeDrawnOn = newVal; __olcaDftToBeDrawnOn_is_modified = true; }
    public boolean olcaDftToBeDrawnOnIsModifiedS2j() { return __olcaDftToBeDrawnOn_is_modified; }
    public String getOlcaDftOnBk() { return _olcaDftOnBk == null ? "" : _olcaDftOnBk.trim(); }
    public void setOlcaDftOnBk(String newVal) { this._olcaDftOnBk = newVal; __olcaDftOnBk_is_modified = true; }
    public boolean olcaDftOnBkIsModifiedS2j() { return __olcaDftOnBk_is_modified; }
    public String getOlcaDftOnBrn() { return _olcaDftOnBrn == null ? "" : _olcaDftOnBrn.trim(); }
    public void setOlcaDftOnBrn(String newVal) { this._olcaDftOnBrn = newVal; __olcaDftOnBrn_is_modified = true; }
    public boolean olcaDftOnBrnIsModifiedS2j() { return __olcaDftOnBrn_is_modified; }
    public String getOlcaSpecText1() { return _olcaSpecText1 == null ? "" : _olcaSpecText1.trim(); }
    public void setOlcaSpecText1(String newVal) { this._olcaSpecText1 = newVal; __olcaSpecText1_is_modified = true; }
    public boolean olcaSpecText1IsModifiedS2j() { return __olcaSpecText1_is_modified; }
    public String getOlcaSpecText2() { return _olcaSpecText2 == null ? "" : _olcaSpecText2.trim(); }
    public void setOlcaSpecText2(String newVal) { this._olcaSpecText2 = newVal; __olcaSpecText2_is_modified = true; }
    public boolean olcaSpecText2IsModifiedS2j() { return __olcaSpecText2_is_modified; }
    public String getOlcaSpecText3() { return _olcaSpecText3 == null ? "" : _olcaSpecText3.trim(); }
    public void setOlcaSpecText3(String newVal) { this._olcaSpecText3 = newVal; __olcaSpecText3_is_modified = true; }
    public boolean olcaSpecText3IsModifiedS2j() { return __olcaSpecText3_is_modified; }
    public String getOlcaSpecText4() { return _olcaSpecText4 == null ? "" : _olcaSpecText4.trim(); }
    public void setOlcaSpecText4(String newVal) { this._olcaSpecText4 = newVal; __olcaSpecText4_is_modified = true; }
    public boolean olcaSpecText4IsModifiedS2j() { return __olcaSpecText4_is_modified; }
    public char getOlcaPrimeRateClauseReq() { return _olcaPrimeRateClauseReq; }
    public void setOlcaPrimeRateClauseReq(char newVal) { this._olcaPrimeRateClauseReq = newVal; __olcaPrimeRateClauseReq_is_modified = true; }
    public boolean olcaPrimeRateClauseReqIsModifiedS2j() { return __olcaPrimeRateClauseReq_is_modified; }
    public char getOlcaShpmntMode() { return _olcaShpmntMode; }
    public void setOlcaShpmntMode(char newVal) { this._olcaShpmntMode = newVal; __olcaShpmntMode_is_modified = true; }
    public boolean olcaShpmntModeIsModifiedS2j() { return __olcaShpmntMode_is_modified; }
    public char getOlcaLloydsClauseReq() { return _olcaLloydsClauseReq; }
    public void setOlcaLloydsClauseReq(char newVal) { this._olcaLloydsClauseReq = newVal; __olcaLloydsClauseReq_is_modified = true; }
    public boolean olcaLloydsClauseReqIsModifiedS2j() { return __olcaLloydsClauseReq_is_modified; }
    public int getOlcaMaxShipAge() { return _olcaMaxShipAge; }
    public void setOlcaMaxShipAge(int newVal) { this._olcaMaxShipAge = newVal; __olcaMaxShipAge_is_modified = true; }
    public boolean olcaMaxShipAgeIsModifiedS2j() { return __olcaMaxShipAge_is_modified; }
    public char getOlcaShortFormOfBl() { return _olcaShortFormOfBl; }
    public void setOlcaShortFormOfBl(char newVal) { this._olcaShortFormOfBl = newVal; __olcaShortFormOfBl_is_modified = true; }
    public boolean olcaShortFormOfBlIsModifiedS2j() { return __olcaShortFormOfBl_is_modified; }
    public char getOlcaLashTransDocsAllwd() { return _olcaLashTransDocsAllwd; }
    public void setOlcaLashTransDocsAllwd(char newVal) { this._olcaLashTransDocsAllwd = newVal; __olcaLashTransDocsAllwd_is_modified = true; }
    public boolean olcaLashTransDocsAllwdIsModifiedS2j() { return __olcaLashTransDocsAllwd_is_modified; }
    public double getOlcaPercOfInsValueCvrd() { return _olcaPercOfInsValueCvrd; }
    public void setOlcaPercOfInsValueCvrd(double newVal) { this._olcaPercOfInsValueCvrd = newVal; __olcaPercOfInsValueCvrd_is_modified = true; }
    public boolean olcaPercOfInsValueCvrdIsModifiedS2j() { return __olcaPercOfInsValueCvrd_is_modified; }
    public String getOlcaInsPolicyNum() { return _olcaInsPolicyNum == null ? "" : _olcaInsPolicyNum.trim(); }
    public void setOlcaInsPolicyNum(String newVal) { this._olcaInsPolicyNum = newVal; __olcaInsPolicyNum_is_modified = true; }
    public boolean olcaInsPolicyNumIsModifiedS2j() { return __olcaInsPolicyNum_is_modified; }
    public java.util.Date getOlcaInsDate() { return _olcaInsDate; }
    public void setOlcaInsDate(java.util.Date newVal) { this._olcaInsDate = newVal; __olcaInsDate_is_modified = true; }
    public boolean olcaInsDateIsModifiedS2j() { return __olcaInsDate_is_modified; }
    public String getOlcaInsCurr() { return _olcaInsCurr == null ? "" : _olcaInsCurr.trim(); }
    public void setOlcaInsCurr(String newVal) { this._olcaInsCurr = newVal; __olcaInsCurr_is_modified = true; }
    public boolean olcaInsCurrIsModifiedS2j() { return __olcaInsCurr_is_modified; }
    public double getOlcaInsAmt() { return _olcaInsAmt; }
    public void setOlcaInsAmt(double newVal) { this._olcaInsAmt = newVal; __olcaInsAmt_is_modified = true; }
    public boolean olcaInsAmtIsModifiedS2j() { return __olcaInsAmt_is_modified; }
    public String getOlcaPremiumCurr() { return _olcaPremiumCurr == null ? "" : _olcaPremiumCurr.trim(); }
    public void setOlcaPremiumCurr(String newVal) { this._olcaPremiumCurr = newVal; __olcaPremiumCurr_is_modified = true; }
    public boolean olcaPremiumCurrIsModifiedS2j() { return __olcaPremiumCurr_is_modified; }
    public double getOlcaPremiumAmt() { return _olcaPremiumAmt; }
    public void setOlcaPremiumAmt(double newVal) { this._olcaPremiumAmt = newVal; __olcaPremiumAmt_is_modified = true; }
    public boolean olcaPremiumAmtIsModifiedS2j() { return __olcaPremiumAmt_is_modified; }
    public String getOlcaInsCompany() { return _olcaInsCompany == null ? "" : _olcaInsCompany.trim(); }
    public void setOlcaInsCompany(String newVal) { this._olcaInsCompany = newVal; __olcaInsCompany_is_modified = true; }
    public boolean olcaInsCompanyIsModifiedS2j() { return __olcaInsCompany_is_modified; }
    public String getOlcaInsCompanyName() { return _olcaInsCompanyName == null ? "" : _olcaInsCompanyName.trim(); }
    public void setOlcaInsCompanyName(String newVal) { this._olcaInsCompanyName = newVal; __olcaInsCompanyName_is_modified = true; }
    public boolean olcaInsCompanyNameIsModifiedS2j() { return __olcaInsCompanyName_is_modified; }
    public String getOlcaCooIssBy() { return _olcaCooIssBy == null ? "" : _olcaCooIssBy.trim(); }
    public void setOlcaCooIssBy(String newVal) { this._olcaCooIssBy = newVal; __olcaCooIssBy_is_modified = true; }
    public boolean olcaCooIssByIsModifiedS2j() { return __olcaCooIssBy_is_modified; }
    public String getOlcaOtherCompAuth() { return _olcaOtherCompAuth == null ? "" : _olcaOtherCompAuth.trim(); }
    public void setOlcaOtherCompAuth(String newVal) { this._olcaOtherCompAuth = newVal; __olcaOtherCompAuth_is_modified = true; }
    public boolean olcaOtherCompAuthIsModifiedS2j() { return __olcaOtherCompAuth_is_modified; }
    public char getOlcaIntermediaryTrade() { return _olcaIntermediaryTrade; }
    public void setOlcaIntermediaryTrade(char newVal) { this._olcaIntermediaryTrade = newVal; __olcaIntermediaryTrade_is_modified = true; }
    public boolean olcaIntermediaryTradeIsModifiedS2j() { return __olcaIntermediaryTrade_is_modified; }
    public char getOlcaInspTestCertReq() { return _olcaInspTestCertReq; }
    public void setOlcaInspTestCertReq(char newVal) { this._olcaInspTestCertReq = newVal; __olcaInspTestCertReq_is_modified = true; }
    public boolean olcaInspTestCertReqIsModifiedS2j() { return __olcaInspTestCertReq_is_modified; }
    public String getOlcaCertBy() { return _olcaCertBy == null ? "" : _olcaCertBy.trim(); }
    public void setOlcaCertBy(String newVal) { this._olcaCertBy = newVal; __olcaCertBy_is_modified = true; }
    public boolean olcaCertByIsModifiedS2j() { return __olcaCertBy_is_modified; }
    public char getOlcaImpUnder() { return _olcaImpUnder; }
    public void setOlcaImpUnder(char newVal) { this._olcaImpUnder = newVal; __olcaImpUnder_is_modified = true; }
    public boolean olcaImpUnderIsModifiedS2j() { return __olcaImpUnder_is_modified; }
    public String getOlcaImpPolicyDet() { return _olcaImpPolicyDet == null ? "" : _olcaImpPolicyDet.trim(); }
    public void setOlcaImpPolicyDet(String newVal) { this._olcaImpPolicyDet = newVal; __olcaImpPolicyDet_is_modified = true; }
    public boolean olcaImpPolicyDetIsModifiedS2j() { return __olcaImpPolicyDet_is_modified; }
    public String getOlcaImpRef() { return _olcaImpRef == null ? "" : _olcaImpRef.trim(); }
    public void setOlcaImpRef(String newVal) { this._olcaImpRef = newVal; __olcaImpRef_is_modified = true; }
    public boolean olcaImpRefIsModifiedS2j() { return __olcaImpRef_is_modified; }
    public double getOlcaContraAmt() { return _olcaContraAmt; }
    public void setOlcaContraAmt(double newVal) { this._olcaContraAmt = newVal; __olcaContraAmt_is_modified = true; }
    public boolean olcaContraAmtIsModifiedS2j() { return __olcaContraAmt_is_modified; }
    public double getOlcaUsanceCharges() { return _olcaUsanceCharges; }
    public void setOlcaUsanceCharges(double newVal) { this._olcaUsanceCharges = newVal; __olcaUsanceCharges_is_modified = true; }
    public boolean olcaUsanceChargesIsModifiedS2j() { return __olcaUsanceCharges_is_modified; }
    public int getOlcaUsnChgTakenDays() { return _olcaUsnChgTakenDays; }
    public void setOlcaUsnChgTakenDays(int newVal) { this._olcaUsnChgTakenDays = newVal; __olcaUsnChgTakenDays_is_modified = true; }
    public boolean olcaUsnChgTakenDaysIsModifiedS2j() { return __olcaUsnChgTakenDays_is_modified; }
    public double getOlcaCommitmentCharges() { return _olcaCommitmentCharges; }
    public void setOlcaCommitmentCharges(double newVal) { this._olcaCommitmentCharges = newVal; __olcaCommitmentCharges_is_modified = true; }
    public boolean olcaCommitmentChargesIsModifiedS2j() { return __olcaCommitmentCharges_is_modified; }
    public int getOlcaCommitChgTakenDays() { return _olcaCommitChgTakenDays; }
    public void setOlcaCommitChgTakenDays(int newVal) { this._olcaCommitChgTakenDays = newVal; __olcaCommitChgTakenDays_is_modified = true; }
    public boolean olcaCommitChgTakenDaysIsModifiedS2j() { return __olcaCommitChgTakenDays_is_modified; }
    public long getTranchgsChgsSl() { return _tranchgsChgsSl; }
    public void setTranchgsChgsSl(long newVal) { this._tranchgsChgsSl = newVal; __tranchgsChgsSl_is_modified = true; }
    public boolean tranchgsChgsSlIsModifiedS2j() { return __tranchgsChgsSl_is_modified; }
    public long getTranstlmntInvNum() { return _transtlmntInvNum; }
    public void setTranstlmntInvNum(long newVal) { this._transtlmntInvNum = newVal; __transtlmntInvNum_is_modified = true; }
    public boolean transtlmntInvNumIsModifiedS2j() { return __transtlmntInvNum_is_modified; }
    public int getPostTranBrn() { return _postTranBrn; }
    public void setPostTranBrn(int newVal) { this._postTranBrn = newVal; __postTranBrn_is_modified = true; }
    public boolean postTranBrnIsModifiedS2j() { return __postTranBrn_is_modified; }
    public java.util.Date getPostTranDate() { return _postTranDate; }
    public void setPostTranDate(java.util.Date newVal) { this._postTranDate = newVal; __postTranDate_is_modified = true; }
    public boolean postTranDateIsModifiedS2j() { return __postTranDate_is_modified; }
    public int getPostTranBatchNum() { return _postTranBatchNum; }
    public void setPostTranBatchNum(int newVal) { this._postTranBatchNum = newVal; __postTranBatchNum_is_modified = true; }
    public boolean postTranBatchNumIsModifiedS2j() { return __postTranBatchNum_is_modified; }
    public String getOlcaEntdBy() { return _olcaEntdBy == null ? "" : _olcaEntdBy.trim(); }
    public void setOlcaEntdBy(String newVal) { this._olcaEntdBy = newVal; __olcaEntdBy_is_modified = true; }
    public boolean olcaEntdByIsModifiedS2j() { return __olcaEntdBy_is_modified; }
    public java.util.Date getOlcaEntdOn() { return _olcaEntdOn; }
    public void setOlcaEntdOn(java.util.Date newVal) { this._olcaEntdOn = newVal; __olcaEntdOn_is_modified = true; }
    public boolean olcaEntdOnIsModifiedS2j() { return __olcaEntdOn_is_modified; }
    public String getOlcaLastmodBy() { return _olcaLastmodBy == null ? "" : _olcaLastmodBy.trim(); }
    public void setOlcaLastmodBy(String newVal) { this._olcaLastmodBy = newVal; __olcaLastmodBy_is_modified = true; }
    public boolean olcaLastmodByIsModifiedS2j() { return __olcaLastmodBy_is_modified; }
    public java.util.Date getOlcaLastmodOn() { return _olcaLastmodOn; }
    public void setOlcaLastmodOn(java.util.Date newVal) { this._olcaLastmodOn = newVal; __olcaLastmodOn_is_modified = true; }
    public boolean olcaLastmodOnIsModifiedS2j() { return __olcaLastmodOn_is_modified; }
    public String getOlcaAuthBy() { return _olcaAuthBy == null ? "" : _olcaAuthBy.trim(); }
    public void setOlcaAuthBy(String newVal) { this._olcaAuthBy = newVal; __olcaAuthBy_is_modified = true; }
    public boolean olcaAuthByIsModifiedS2j() { return __olcaAuthBy_is_modified; }
    public java.util.Date getOlcaAuthOn() { return _olcaAuthOn; }
    public void setOlcaAuthOn(java.util.Date newVal) { this._olcaAuthOn = newVal; __olcaAuthOn_is_modified = true; }
    public boolean olcaAuthOnIsModifiedS2j() { return __olcaAuthOn_is_modified; }
    public String getOlcaRejBy() { return _olcaRejBy == null ? "" : _olcaRejBy.trim(); }
    public void setOlcaRejBy(String newVal) { this._olcaRejBy = newVal; __olcaRejBy_is_modified = true; }
    public boolean olcaRejByIsModifiedS2j() { return __olcaRejBy_is_modified; }
    public java.util.Date getOlcaRejOn() { return _olcaRejOn; }
    public void setOlcaRejOn(java.util.Date newVal) { this._olcaRejOn = newVal; __olcaRejOn_is_modified = true; }
    public boolean olcaRejOnIsModifiedS2j() { return __olcaRejOn_is_modified; }
    public char getOlcaAmdChgPayBy() { return _olcaAmdChgPayBy; }
    public void setOlcaAmdChgPayBy(char newVal) { this._olcaAmdChgPayBy = newVal; __olcaAmdChgPayBy_is_modified = true; }
    public boolean olcaAmdChgPayByIsModifiedS2j() { return __olcaAmdChgPayBy_is_modified; }
    public String getOlcaPerOfPresDays() { return _olcaPerOfPresDays == null ? "" : _olcaPerOfPresDays.trim(); }
    public void setOlcaPerOfPresDays(String newVal) { this._olcaPerOfPresDays = newVal; __olcaPerOfPresDays_is_modified = true; }
    public boolean olcaPerOfPresDaysIsModifiedS2j() { return __olcaPerOfPresDays_is_modified; }
    public char getOlcaChgInDescGoods() { return _olcaChgInDescGoods; }
    public void setOlcaChgInDescGoods(char newVal) { this._olcaChgInDescGoods = newVal; __olcaChgInDescGoods_is_modified = true; }
    public boolean olcaChgInDescGoodsIsModifiedS2j() { return __olcaChgInDescGoods_is_modified; }
    public char getOlcaChgInDoc() { return _olcaChgInDoc; }
    public void setOlcaChgInDoc(char newVal) { this._olcaChgInDoc = newVal; __olcaChgInDoc_is_modified = true; }
    public boolean olcaChgInDocIsModifiedS2j() { return __olcaChgInDoc_is_modified; }
    public char getOlcaChgInAddlCond() { return _olcaChgInAddlCond; }
    public void setOlcaChgInAddlCond(char newVal) { this._olcaChgInAddlCond = newVal; __olcaChgInAddlCond_is_modified = true; }
    public boolean olcaChgInAddlCondIsModifiedS2j() { return __olcaChgInAddlCond_is_modified; }
    public char getOlcaReqForCancel() { return _olcaReqForCancel; }
    public void setOlcaReqForCancel(char newVal) { this._olcaReqForCancel = newVal; __olcaReqForCancel_is_modified = true; }
    public boolean olcaReqForCancelIsModifiedS2j() { return __olcaReqForCancel_is_modified; }
    public char getOlcaChgOfAppl() { return _olcaChgOfAppl; }
    public void setOlcaChgOfAppl(char newVal) { this._olcaChgOfAppl = newVal; __olcaChgOfAppl_is_modified = true; }
    public boolean olcaChgOfApplIsModifiedS2j() { return __olcaChgOfAppl_is_modified; }
    public char getOlcaChgInAvlWith() { return _olcaChgInAvlWith; }
    public void setOlcaChgInAvlWith(char newVal) { this._olcaChgInAvlWith = newVal; __olcaChgInAvlWith_is_modified = true; }
    public boolean olcaChgInAvlWithIsModifiedS2j() { return __olcaChgInAvlWith_is_modified; }
    public char getOlcaChgInDraweePay() { return _olcaChgInDraweePay; }
    public void setOlcaChgInDraweePay(char newVal) { this._olcaChgInDraweePay = newVal; __olcaChgInDraweePay_is_modified = true; }
    public boolean olcaChgInDraweePayIsModifiedS2j() { return __olcaChgInDraweePay_is_modified; }
    public char getOlcaChgInReimb() { return _olcaChgInReimb; }
    public void setOlcaChgInReimb(char newVal) { this._olcaChgInReimb = newVal; __olcaChgInReimb_is_modified = true; }
    public boolean olcaChgInReimbIsModifiedS2j() { return __olcaChgInReimb_is_modified; }
    public char getOlcaChgInAdvBk() { return _olcaChgInAdvBk; }
    public void setOlcaChgInAdvBk(char newVal) { this._olcaChgInAdvBk = newVal; __olcaChgInAdvBk_is_modified = true; }
    public boolean olcaChgInAdvBkIsModifiedS2j() { return __olcaChgInAdvBk_is_modified; }
    public char getOlcaChgInFormOfDc() { return _olcaChgInFormOfDc; }
    public void setOlcaChgInFormOfDc(char newVal) { this._olcaChgInFormOfDc = newVal; __olcaChgInFormOfDc_is_modified = true; }
    public boolean olcaChgInFormOfDcIsModifiedS2j() { return __olcaChgInFormOfDc_is_modified; }
    public char getOlcaChgInApplRules() { return _olcaChgInApplRules; }
    public void setOlcaChgInApplRules(char newVal) { this._olcaChgInApplRules = newVal; __olcaChgInApplRules_is_modified = true; }
    public boolean olcaChgInApplRulesIsModifiedS2j() { return __olcaChgInApplRules_is_modified; }
    public boolean isNew() { return _isNew; }
    public void setIsNew(boolean isNew) { this._isNew = isNew; }

    public boolean isModifiedS2J() {
        return __olcaBrnCode_is_modified || 
        __olcaLcType_is_modified || 
        __olcaLcYear_is_modified || 
        __olcaLcSl_is_modified || 
        __olcaAmdSl_is_modified || 
        __olcaEntryDate_is_modified || 
        __olcaCustLetterNum_is_modified || 
        __olcaCustLtrDate_is_modified || 
        __olcaRsnForAmd_is_modified || 
        __olcaChangeOfBenef_is_modified || 
        __olcaBenefCode_is_modified || 
        __olcaBenefName_is_modified || 
        __olcaBenefAddr1_is_modified || 
        __olcaBenefAddr2_is_modified || 
        __olcaBenefAddr3_is_modified || 
        __olcaBenefAddr4_is_modified || 
        __olcaBenefAddr5_is_modified || 
        __olcaBenefCntryCode_is_modified || 
        __olcaEnhancemntReducn_is_modified || 
        __olcaLcCurrCode_is_modified || 
        __olcaAmendedAmt_is_modified || 
        __olcaPosDevAllwd_is_modified || 
        __olcaNegDevAllwd_is_modified || 
        __olcaDevAmt_is_modified || 
        __olcaAmtQualfr_is_modified || 
        __olcaPriceTerms_is_modified || 
        __olcaLastDateOfNeg_is_modified || 
        __olcaPlaceOfExpiry_is_modified || 
        __olcaLatestDateOfShpmnt_is_modified || 
        __olcaWithinValidateLc_is_modified || 
        __olcaLcUiBorneByApplcnt_is_modified || 
        __olcaNofTenors_is_modified || 
        __olcaAddLiabLcCurr_is_modified || 
        __olcaConvRateBaseCurr_is_modified || 
        __olcaAddLiabBaseCurr_is_modified || 
        __olcaConvRateLimCurr_is_modified || 
        __olcaTotLiabLimCurr_is_modified || 
        __olcaTotLiabLcCurr_is_modified || 
        __olcaTotLiabBaseCurr_is_modified || 
        __olcaReimbChrgsBy_is_modified || 
        __olcaPercRcPaidByApplcnt_is_modified || 
        __olcaNostroAlphaCode_is_modified || 
        __olcaAdvThruBk_is_modified || 
        __olcaAdvThruBrn_is_modified || 
        __olcaLcToBeCnfrmd_is_modified || 
        __olcaLcToBeCnfrmdByBk_is_modified || 
        __olcaLcToBeCnfrmdByBrn_is_modified || 
        __olcaRestricted_is_modified || 
        __olcaRestrictedToUs_is_modified || 
        __olcaRestrictedBkCode_is_modified || 
        __olcaRestrictedBrnCode_is_modified || 
        __olcaCrAvlblBy_is_modified || 
        __olcaIrrevocable_is_modified || 
        __olcaPartShpmnt_is_modified || 
        __olcaTranShpmnt_is_modified || 
        __olcaLcTransfrbl_is_modified || 
        __olcaDftDtls_is_modified || 
        __olcaPercDftValue_is_modified || 
        __olcaDftToBeDrawnOn_is_modified || 
        __olcaDftOnBk_is_modified || 
        __olcaDftOnBrn_is_modified || 
        __olcaSpecText1_is_modified || 
        __olcaSpecText2_is_modified || 
        __olcaSpecText3_is_modified || 
        __olcaSpecText4_is_modified || 
        __olcaPrimeRateClauseReq_is_modified || 
        __olcaShpmntMode_is_modified || 
        __olcaLloydsClauseReq_is_modified || 
        __olcaMaxShipAge_is_modified || 
        __olcaShortFormOfBl_is_modified || 
        __olcaLashTransDocsAllwd_is_modified || 
        __olcaPercOfInsValueCvrd_is_modified || 
        __olcaInsPolicyNum_is_modified || 
        __olcaInsDate_is_modified || 
        __olcaInsCurr_is_modified || 
        __olcaInsAmt_is_modified || 
        __olcaPremiumCurr_is_modified || 
        __olcaPremiumAmt_is_modified || 
        __olcaInsCompany_is_modified || 
        __olcaInsCompanyName_is_modified || 
        __olcaCooIssBy_is_modified || 
        __olcaOtherCompAuth_is_modified || 
        __olcaIntermediaryTrade_is_modified || 
        __olcaInspTestCertReq_is_modified || 
        __olcaCertBy_is_modified || 
        __olcaImpUnder_is_modified || 
        __olcaImpPolicyDet_is_modified || 
        __olcaImpRef_is_modified || 
        __olcaContraAmt_is_modified || 
        __olcaUsanceCharges_is_modified || 
        __olcaUsnChgTakenDays_is_modified || 
        __olcaCommitmentCharges_is_modified || 
        __olcaCommitChgTakenDays_is_modified || 
        __tranchgsChgsSl_is_modified || 
        __transtlmntInvNum_is_modified || 
        __postTranBrn_is_modified || 
        __postTranDate_is_modified || 
        __postTranBatchNum_is_modified || 
        __olcaEntdBy_is_modified || 
        __olcaEntdOn_is_modified || 
        __olcaLastmodBy_is_modified || 
        __olcaLastmodOn_is_modified || 
        __olcaAuthBy_is_modified || 
        __olcaAuthOn_is_modified || 
        __olcaRejBy_is_modified || 
        __olcaRejOn_is_modified || 
        __olcaAmdChgPayBy_is_modified || 
        __olcaPerOfPresDays_is_modified || 
        __olcaChgInDescGoods_is_modified || 
        __olcaChgInDoc_is_modified || 
        __olcaChgInAddlCond_is_modified || 
        __olcaReqForCancel_is_modified || 
        __olcaChgOfAppl_is_modified || 
        __olcaChgInAvlWith_is_modified || 
        __olcaChgInDraweePay_is_modified || 
        __olcaChgInReimb_is_modified || 
        __olcaChgInAdvBk_is_modified || 
        __olcaChgInFormOfDc_is_modified || 
        __olcaChgInApplRules_is_modified;
    }

    public void resetIsModifiedS2J() {
        __olcaBrnCode_is_modified = false;
        __olcaLcType_is_modified = false;
        __olcaLcYear_is_modified = false;
        __olcaLcSl_is_modified = false;
        __olcaAmdSl_is_modified = false;
        __olcaEntryDate_is_modified = false;
        __olcaCustLetterNum_is_modified = false;
        __olcaCustLtrDate_is_modified = false;
        __olcaRsnForAmd_is_modified = false;
        __olcaChangeOfBenef_is_modified = false;
        __olcaBenefCode_is_modified = false;
        __olcaBenefName_is_modified = false;
        __olcaBenefAddr1_is_modified = false;
        __olcaBenefAddr2_is_modified = false;
        __olcaBenefAddr3_is_modified = false;
        __olcaBenefAddr4_is_modified = false;
        __olcaBenefAddr5_is_modified = false;
        __olcaBenefCntryCode_is_modified = false;
        __olcaEnhancemntReducn_is_modified = false;
        __olcaLcCurrCode_is_modified = false;
        __olcaAmendedAmt_is_modified = false;
        __olcaPosDevAllwd_is_modified = false;
        __olcaNegDevAllwd_is_modified = false;
        __olcaDevAmt_is_modified = false;
        __olcaAmtQualfr_is_modified = false;
        __olcaPriceTerms_is_modified = false;
        __olcaLastDateOfNeg_is_modified = false;
        __olcaPlaceOfExpiry_is_modified = false;
        __olcaLatestDateOfShpmnt_is_modified = false;
        __olcaWithinValidateLc_is_modified = false;
        __olcaLcUiBorneByApplcnt_is_modified = false;
        __olcaNofTenors_is_modified = false;
        __olcaAddLiabLcCurr_is_modified = false;
        __olcaConvRateBaseCurr_is_modified = false;
        __olcaAddLiabBaseCurr_is_modified = false;
        __olcaConvRateLimCurr_is_modified = false;
        __olcaTotLiabLimCurr_is_modified = false;
        __olcaTotLiabLcCurr_is_modified = false;
        __olcaTotLiabBaseCurr_is_modified = false;
        __olcaReimbChrgsBy_is_modified = false;
        __olcaPercRcPaidByApplcnt_is_modified = false;
        __olcaNostroAlphaCode_is_modified = false;
        __olcaAdvThruBk_is_modified = false;
        __olcaAdvThruBrn_is_modified = false;
        __olcaLcToBeCnfrmd_is_modified = false;
        __olcaLcToBeCnfrmdByBk_is_modified = false;
        __olcaLcToBeCnfrmdByBrn_is_modified = false;
        __olcaRestricted_is_modified = false;
        __olcaRestrictedToUs_is_modified = false;
        __olcaRestrictedBkCode_is_modified = false;
        __olcaRestrictedBrnCode_is_modified = false;
        __olcaCrAvlblBy_is_modified = false;
        __olcaIrrevocable_is_modified = false;
        __olcaPartShpmnt_is_modified = false;
        __olcaTranShpmnt_is_modified = false;
        __olcaLcTransfrbl_is_modified = false;
        __olcaDftDtls_is_modified = false;
        __olcaPercDftValue_is_modified = false;
        __olcaDftToBeDrawnOn_is_modified = false;
        __olcaDftOnBk_is_modified = false;
        __olcaDftOnBrn_is_modified = false;
        __olcaSpecText1_is_modified = false;
        __olcaSpecText2_is_modified = false;
        __olcaSpecText3_is_modified = false;
        __olcaSpecText4_is_modified = false;
        __olcaPrimeRateClauseReq_is_modified = false;
        __olcaShpmntMode_is_modified = false;
        __olcaLloydsClauseReq_is_modified = false;
        __olcaMaxShipAge_is_modified = false;
        __olcaShortFormOfBl_is_modified = false;
        __olcaLashTransDocsAllwd_is_modified = false;
        __olcaPercOfInsValueCvrd_is_modified = false;
        __olcaInsPolicyNum_is_modified = false;
        __olcaInsDate_is_modified = false;
        __olcaInsCurr_is_modified = false;
        __olcaInsAmt_is_modified = false;
        __olcaPremiumCurr_is_modified = false;
        __olcaPremiumAmt_is_modified = false;
        __olcaInsCompany_is_modified = false;
        __olcaInsCompanyName_is_modified = false;
        __olcaCooIssBy_is_modified = false;
        __olcaOtherCompAuth_is_modified = false;
        __olcaIntermediaryTrade_is_modified = false;
        __olcaInspTestCertReq_is_modified = false;
        __olcaCertBy_is_modified = false;
        __olcaImpUnder_is_modified = false;
        __olcaImpPolicyDet_is_modified = false;
        __olcaImpRef_is_modified = false;
        __olcaContraAmt_is_modified = false;
        __olcaUsanceCharges_is_modified = false;
        __olcaUsnChgTakenDays_is_modified = false;
        __olcaCommitmentCharges_is_modified = false;
        __olcaCommitChgTakenDays_is_modified = false;
        __tranchgsChgsSl_is_modified = false;
        __transtlmntInvNum_is_modified = false;
        __postTranBrn_is_modified = false;
        __postTranDate_is_modified = false;
        __postTranBatchNum_is_modified = false;
        __olcaEntdBy_is_modified = false;
        __olcaEntdOn_is_modified = false;
        __olcaLastmodBy_is_modified = false;
        __olcaLastmodOn_is_modified = false;
        __olcaAuthBy_is_modified = false;
        __olcaAuthOn_is_modified = false;
        __olcaRejBy_is_modified = false;
        __olcaRejOn_is_modified = false;
        __olcaAmdChgPayBy_is_modified = false;
        __olcaPerOfPresDays_is_modified = false;
        __olcaChgInDescGoods_is_modified = false;
        __olcaChgInDoc_is_modified = false;
        __olcaChgInAddlCond_is_modified = false;
        __olcaReqForCancel_is_modified = false;
        __olcaChgOfAppl_is_modified = false;
        __olcaChgInAvlWith_is_modified = false;
        __olcaChgInDraweePay_is_modified = false;
        __olcaChgInReimb_is_modified = false;
        __olcaChgInAdvBk_is_modified = false;
        __olcaChgInFormOfDc_is_modified = false;
        __olcaChgInApplRules_is_modified = false;
    }
    public Olcamd() {
        _initialize();
    }

    public void _initialize() {
        _olcaBrnCode = 0 ;
        _olcaLcType = "" ;
        _olcaLcYear = 0 ;
        _olcaLcSl = 0 ;
        _olcaAmdSl = 0 ;
        _olcaEntryDate = null ;
        _olcaCustLetterNum = "" ;
        _olcaCustLtrDate = null ;
        _olcaRsnForAmd = ' ';
        _olcaChangeOfBenef = ' ';
        _olcaBenefCode = "" ;
        _olcaBenefName = "" ;
        _olcaBenefAddr1 = "" ;
        _olcaBenefAddr2 = "" ;
        _olcaBenefAddr3 = "" ;
        _olcaBenefAddr4 = "" ;
        _olcaBenefAddr5 = "" ;
        _olcaBenefCntryCode = "" ;
        _olcaEnhancemntReducn = ' ';
        _olcaLcCurrCode = "" ;
        _olcaAmendedAmt = 0 ;
        _olcaPosDevAllwd = 0 ;
        _olcaNegDevAllwd = 0 ;
        _olcaDevAmt = 0 ;
        _olcaAmtQualfr = ' ';
        _olcaPriceTerms = "" ;
        _olcaLastDateOfNeg = null ;
        _olcaPlaceOfExpiry = "" ;
        _olcaLatestDateOfShpmnt = null ;
        _olcaWithinValidateLc = ' ';
        _olcaLcUiBorneByApplcnt = ' ';
        _olcaNofTenors = 0 ;
        _olcaAddLiabLcCurr = 0 ;
        _olcaConvRateBaseCurr = 0 ;
        _olcaAddLiabBaseCurr = 0 ;
        _olcaConvRateLimCurr = 0 ;
        _olcaTotLiabLimCurr = 0 ;
        _olcaTotLiabLcCurr = 0 ;
        _olcaTotLiabBaseCurr = 0 ;
        _olcaReimbChrgsBy = ' ';
        _olcaPercRcPaidByApplcnt = 0 ;
        _olcaNostroAlphaCode = "" ;
        _olcaAdvThruBk = "" ;
        _olcaAdvThruBrn = "" ;
        _olcaLcToBeCnfrmd = ' ';
        _olcaLcToBeCnfrmdByBk = "" ;
        _olcaLcToBeCnfrmdByBrn = "" ;
        _olcaRestricted = ' ';
        _olcaRestrictedToUs = ' ';
        _olcaRestrictedBkCode = "" ;
        _olcaRestrictedBrnCode = "" ;
        _olcaCrAvlblBy = ' ';
        _olcaIrrevocable = ' ';
        _olcaPartShpmnt = ' ';
        _olcaTranShpmnt = ' ';
        _olcaLcTransfrbl = ' ';
        _olcaDftDtls = ' ';
        _olcaPercDftValue = 0 ;
        _olcaDftToBeDrawnOn = ' ';
        _olcaDftOnBk = "" ;
        _olcaDftOnBrn = "" ;
        _olcaSpecText1 = "" ;
        _olcaSpecText2 = "" ;
        _olcaSpecText3 = "" ;
        _olcaSpecText4 = "" ;
        _olcaPrimeRateClauseReq = ' ';
        _olcaShpmntMode = ' ';
        _olcaLloydsClauseReq = ' ';
        _olcaMaxShipAge = 0 ;
        _olcaShortFormOfBl = ' ';
        _olcaLashTransDocsAllwd = ' ';
        _olcaPercOfInsValueCvrd = 0 ;
        _olcaInsPolicyNum = "" ;
        _olcaInsDate = null ;
        _olcaInsCurr = "" ;
        _olcaInsAmt = 0 ;
        _olcaPremiumCurr = "" ;
        _olcaPremiumAmt = 0 ;
        _olcaInsCompany = "" ;
        _olcaInsCompanyName = "" ;
        _olcaCooIssBy = "" ;
        _olcaOtherCompAuth = "" ;
        _olcaIntermediaryTrade = ' ';
        _olcaInspTestCertReq = ' ';
        _olcaCertBy = "" ;
        _olcaImpUnder = ' ';
        _olcaImpPolicyDet = "" ;
        _olcaImpRef = "" ;
        _olcaContraAmt = 0 ;
        _olcaUsanceCharges = 0 ;
        _olcaUsnChgTakenDays = 0 ;
        _olcaCommitmentCharges = 0 ;
        _olcaCommitChgTakenDays = 0 ;
        _tranchgsChgsSl = 0 ;
        _transtlmntInvNum = 0 ;
        _postTranBrn = 0 ;
        _postTranDate = null ;
        _postTranBatchNum = 0 ;
        _olcaEntdBy = "" ;
        _olcaEntdOn = null ;
        _olcaLastmodBy = "" ;
        _olcaLastmodOn = null ;
        _olcaAuthBy = "" ;
        _olcaAuthOn = null ;
        _olcaRejBy = "" ;
        _olcaRejOn = null ;
        _olcaAmdChgPayBy = ' ';
        _olcaPerOfPresDays = "" ;
        _olcaChgInDescGoods = ' ';
        _olcaChgInDoc = ' ';
        _olcaChgInAddlCond = ' ';
        _olcaReqForCancel = ' ';
        _olcaChgOfAppl = ' ';
        _olcaChgInAvlWith = ' ';
        _olcaChgInDraweePay = ' ';
        _olcaChgInReimb = ' ';
        _olcaChgInAdvBk = ' ';
        _olcaChgInFormOfDc = ' ';
        _olcaChgInApplRules = ' ';
    }

}
