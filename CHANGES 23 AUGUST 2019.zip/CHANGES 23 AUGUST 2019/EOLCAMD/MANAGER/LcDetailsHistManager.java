package panacea.OLC.Update;

import java.util.Vector;
import java.sql.*;
import panacea.common.JNDINames;
import java.util.LinkedHashMap;
import panacea.Manager.Manager;

/******************SQL2JAVA_IMPORT_BEGIN******************/

/******************SQL2JAVA_IMPORT_END********************/


public class LcDetailsHistManager extends Manager
/******************SQL2JAVA_EXTENDS_BEGIN******************/

/******************SQL2JAVA_EXTENDS_END********************/

{

/******************SQL2JAVA_CLASS_BEGIN******************/

/******************SQL2JAVA_CLASS_END********************/


    public static final int LCHIST_BRN_CODE = 0;
    public static final int LCHIST_LC_TYPE = 1;
    public static final int LCHIST_LC_YEAR = 2;
    public static final int LCHIST_LC_SL = 3;
    public static final int LCHIST_LC_HISTSL = 4;
    public static final int LCHIST_LC_HISTDATE = 5;
    public static final int LCHIST_FORM_OF_DOC_CREDIT = 6;
    public static final int LCHIST_REFERENCE_TO_PREADVICE = 7;
    public static final int LCHIST_APPLICABLE_RULES = 8;
    public static final int LCHIST_APPLICANT_REQ = 9;
    public static final int LCHIST_APPLICANT_TYPE = 10;
    public static final int LCHIST_APPLICANT_BRN_CODE = 11;
    public static final int LCHIST_APPLICANT_BIC_CODE = 12;
    public static final int LCHIST_APPLICANT_ROUTID = 13;
    public static final int LCHIST_APPLICANT_BNK_CODE = 14;
    public static final int LCHIST_APPLICANT_ADDR1 = 15;
    public static final int LCHIST_APPLICANT_ADDR2 = 16;
    public static final int LCHIST_APPLICANT_ADDR3 = 17;
    public static final int LCHIST_APPLICANT_ADDR4 = 18;
    public static final int LCHIST_APPLICANT_ADDR5 = 19;
    public static final int LCHIST_AVAILABLE_WITH_TYPE = 20;
    public static final int LCHIST_AVAILABLE_WITH_BRN_CODE = 21;
    public static final int LCHIST_AVAILABLE_WITH_CODE = 22;
    public static final int LCHIST_AVAILABLE_WITH_ROUTID = 23;
    public static final int LCHIST_AVAILABLE_WITH_BNK_CODE = 24;
    public static final int LCHIST_AVAILABLE_WITH_ADDR1 = 25;
    public static final int LCHIST_AVAILABLE_WITH_ADDR2 = 26;
    public static final int LCHIST_AVAILABLE_WITH_ADDR3 = 27;
    public static final int LCHIST_AVAILABLE_WITH_ADDR4 = 28;
    public static final int LCHIST_AVAILABLE_WITH_ADDR5 = 29;
    public static final int LCHIST_DRAFTS_AT1 = 30;
    public static final int LCHIST_DRAFTS_AT2 = 31;
    public static final int LCHIST_DRAFTS_AT3 = 32;
    public static final int LCHIST_DRAWEE_REQ = 33;
    public static final int LCHIST_DRAWEE_TYPE = 34;
    public static final int LCHIST_DRAWEE_BRN_CODE = 35;
    public static final int LCHIST_DRAWEE_BIC_CODE = 36;
    public static final int LCHIST_DRAWEE_ROUTID = 37;
    public static final int LCHIST_DRAWEE_BNK_CODE = 38;
    public static final int LCHIST_DRAWEE_ADDR1 = 39;
    public static final int LCHIST_DRAWEE_ADDR2 = 40;
    public static final int LCHIST_DRAWEE_ADDR3 = 41;
    public static final int LCHIST_DRAWEE_ADDR4 = 42;
    public static final int LCHIST_DRAWEE_ADDR5 = 43;
    public static final int LCHIST_MIXED_PAY_DETAILS1 = 44;
    public static final int LCHIST_MIXED_PAY_DETAILS2 = 45;
    public static final int LCHIST_MIXED_PAY_DETAILS3 = 46;
    public static final int LCHIST_MIXED_PAY_DETAILS4 = 47;
    public static final int LCHIST_DEFERRED_PAY_DETAILS1 = 48;
    public static final int LCHIST_DEFERRED_PAY_DETAILS2 = 49;
    public static final int LCHIST_DEFERRED_PAY_DETAILS3 = 50;
    public static final int LCHIST_DEFERRED_PAY_DETAILS4 = 51;
    public static final int LCHIST_PARTIAL_SHIPMENTS = 52;
    public static final int LCHIST_TRANSHIPMENT = 53;
    public static final int LCHIST_PLACE_IN_CHARGE = 54;
    public static final int LCHIST_PORT_OF_LOADING = 55;
    public static final int LCHIST_PORT_OF_DISCHARGE = 56;
    public static final int LCHIST_PLACE_OF_FINAL_DEST = 57;
    public static final int LCHIST_DESC_GOODS_SER1 = 58;
    public static final int LCHIST_DESC_GOODS_SER2 = 59;
    public static final int LCHIST_DESC_GOODS_SER3 = 60;
    public static final int LCHIST_DOC_REQ1 = 61;
    public static final int LCHIST_DOC_REQ2 = 62;
    public static final int LCHIST_DOC_REQ3 = 63;
    public static final int LCHIST_ADD_CONDITION1 = 64;
    public static final int LCHIST_ADD_CONDITION2 = 65;
    public static final int LCHIST_ADD_CONDITION3 = 66;
    public static final int LCHIST_CHARGES1 = 67;
    public static final int LCHIST_CHARGES2 = 68;
    public static final int LCHIST_CHARGES3 = 69;
    public static final int LCHIST_CHARGES4 = 70;
    public static final int LCHIST_CHARGES5 = 71;
    public static final int LCHIST_CHARGES6 = 72;
    public static final int LCHIST_PER_PRESENTATION_DAY = 73;
    public static final int LCHIST_CONFIRMATION_INST = 74;
    public static final int LCHIST_REIMB_REQ = 75;
    public static final int LCHIST_REIMB_TYPE = 76;
    public static final int LCHIST_REIMB_BRN_CODE = 77;
    public static final int LCHIST_REIMB_BIC_CODE = 78;
    public static final int LCHIST_REIMB_ROUTID = 79;
    public static final int LCHIST_REIMB_BNK_CODE = 80;
    public static final int LCHIST_REIMB_ADDR1 = 81;
    public static final int LCHIST_REIMB_ADDR2 = 82;
    public static final int LCHIST_REIMB_ADDR3 = 83;
    public static final int LCHIST_REIMB_ADDR4 = 84;
    public static final int LCHIST_REIMB_ADDR5 = 85;
    public static final int LCHIST_INST_PAYING1 = 86;
    public static final int LCHIST_INST_PAYING2 = 87;
    public static final int LCHIST_INST_PAYING3 = 88;
    public static final int LCHIST_INST_PAYING4 = 89;
    public static final int LCHIST_INST_PAYING5 = 90;
    public static final int LCHIST_INST_PAYING6 = 91;
    public static final int LCHIST_INST_PAYING7 = 92;
    public static final int LCHIST_INST_PAYING8 = 93;
    public static final int LCHIST_INST_PAYING9 = 94;
    public static final int LCHIST_INST_PAYING10 = 95;
    public static final int LCHIST_INST_PAYING11 = 96;
    public static final int LCHIST_INST_PAYING12 = 97;
    public static final int LCHIST_SECOND_ADV_REQ = 98;
    public static final int LCHIST_SECOND_ADV_TYPE = 99;
    public static final int LCHIST_SECOND_ADV_BRN_CODE = 100;
    public static final int LCHIST_SECOND_ADV_BIC_CODE = 101;
    public static final int LCHIST_SECOND_ADV_ROUTID = 102;
    public static final int LCHIST_SECOND_ADV_BNK_CODE = 103;
    public static final int LCHIST_SECOND_ADV_ADDR1 = 104;
    public static final int LCHIST_SECOND_ADV_ADDR2 = 105;
    public static final int LCHIST_SECOND_ADV_ADDR3 = 106;
    public static final int LCHIST_SECOND_ADV_ADDR4 = 107;
    public static final int LCHIST_SECOND_ADV_ADDR5 = 108;
    public static final int LCHIST_SNDR_REC_INFO1 = 109;
    public static final int LCHIST_SNDR_REC_INFO2 = 110;
    public static final int LCHIST_SNDR_REC_INFO3 = 111;
    public static final int LCHIST_SNDR_REC_INFO4 = 112;
    public static final int LCHIST_SNDR_REC_INFO5 = 113;
    public static final int LCHIST_SNDR_REC_INFO6 = 114;
    public static final int LCHIST_APPLICANT_CNTRY_CODE = 115;
    public static final int LCHIST_AVAILABLE_WITH_CNTRY = 116;
    public static final int LCHIST_AVAILABLE_WITH_CODETYP = 117;
    public static final int LCHIST_DRAWEE_CNTRY_CODE = 118;
    public static final int LCHIST_CONFIRM_INST_TYPE = 119;
    public static final int LCHIST_REIMB_CNTRY_CODE = 120;
    public static final int LCHIST_SECOND_ADV_CNTRYCODE = 121;
    public static final int LCHIST_SHIPMENT_PERIOD1 = 122;
    public static final int LCHIST_SHIPMENT_PERIOD2 = 123;
    public static final int LCHIST_SHIPMENT_PERIOD3 = 124;
    public static final int LCHIST_SHIPMENT_PERIOD4 = 125;
    public static final int LCHIST_SHIPMENT_PERIOD5 = 126;
    public static final int LCHIST_SHIPMENT_PERIOD6 = 127;
    public static final int LCHIST_PER_PRESNT_REMARKS = 128;
    public static final int LCHIST_REC_BIC_CODE = 129;
    public static final int LCHIST_CFM_REIMB_TYPE = 130;
    public static final int LCHIST_CFM_REIMB_BRN_CODE = 131;
    public static final int LCHIST_CFM_REIMB_BIC_CODE = 132;
    public static final int LCHIST_CFM_REIMB_ROUTID = 133;
    public static final int LCHIST_CFM_REIMB_BNK_CODE = 134;
    public static final int LCHIST_CFM_REIMB_ADDR1 = 135;
    public static final int LCHIST_CFM_REIMB_ADDR2 = 136;
    public static final int LCHIST_CFM_REIMB_ADDR3 = 137;
    public static final int LCHIST_CFM_REIMB_ADDR4 = 138;
    public static final int LCHIST_CFM_REIMB_ADDR5 = 139;
    public static final int LCHIST_CFM_REIMB_CNTRY_CODE = 140;

    private String OldData_Key;
    private String NewData_Key;
    private String DataBlock_Old;
    private String DataBlock_New;
    private LinkedHashMap _COLLECTIONobj;
    private int _Logreq ;
    private int _Logaddreq ;
    public LcDetailsHistManager(LinkedHashMap _COLLECTIONobj, int _Log_Req , int _Log_Add_Req ){
        //_COLLECTIONobjManager = _COLLECTIONobj;
        this._COLLECTIONobj 	= _COLLECTIONobj;
        this._Logreq 			= _Log_Req;
        this._Logaddreq 		= _Log_Add_Req;
        //set_pki_enabled(_COLLECTIONobj);
    }
    private static final String[] S2J_FIELD_NAMES = {
        "LC_DETAILS_HIST.LCHIST_BRN_CODE"
        ,"LC_DETAILS_HIST.LCHIST_LC_TYPE"
        ,"LC_DETAILS_HIST.LCHIST_LC_YEAR"
        ,"LC_DETAILS_HIST.LCHIST_LC_SL"
        ,"LC_DETAILS_HIST.LCHIST_LC_HISTSL"
        ,"LC_DETAILS_HIST.LCHIST_LC_HISTDATE"
        ,"LC_DETAILS_HIST.LCHIST_FORM_OF_DOC_CREDIT"
        ,"LC_DETAILS_HIST.LCHIST_REFERENCE_TO_PREADVICE"
        ,"LC_DETAILS_HIST.LCHIST_APPLICABLE_RULES"
        ,"LC_DETAILS_HIST.LCHIST_APPLICANT_REQ"
        ,"LC_DETAILS_HIST.LCHIST_APPLICANT_TYPE"
        ,"LC_DETAILS_HIST.LCHIST_APPLICANT_BRN_CODE"
        ,"LC_DETAILS_HIST.LCHIST_APPLICANT_BIC_CODE"
        ,"LC_DETAILS_HIST.LCHIST_APPLICANT_ROUTID"
        ,"LC_DETAILS_HIST.LCHIST_APPLICANT_BNK_CODE"
        ,"LC_DETAILS_HIST.LCHIST_APPLICANT_ADDR1"
        ,"LC_DETAILS_HIST.LCHIST_APPLICANT_ADDR2"
        ,"LC_DETAILS_HIST.LCHIST_APPLICANT_ADDR3"
        ,"LC_DETAILS_HIST.LCHIST_APPLICANT_ADDR4"
        ,"LC_DETAILS_HIST.LCHIST_APPLICANT_ADDR5"
        ,"LC_DETAILS_HIST.LCHIST_AVAILABLE_WITH_TYPE"
        ,"LC_DETAILS_HIST.LCHIST_AVAILABLE_WITH_BRN_CODE"
        ,"LC_DETAILS_HIST.LCHIST_AVAILABLE_WITH_CODE"
        ,"LC_DETAILS_HIST.LCHIST_AVAILABLE_WITH_ROUTID"
        ,"LC_DETAILS_HIST.LCHIST_AVAILABLE_WITH_BNK_CODE"
        ,"LC_DETAILS_HIST.LCHIST_AVAILABLE_WITH_ADDR1"
        ,"LC_DETAILS_HIST.LCHIST_AVAILABLE_WITH_ADDR2"
        ,"LC_DETAILS_HIST.LCHIST_AVAILABLE_WITH_ADDR3"
        ,"LC_DETAILS_HIST.LCHIST_AVAILABLE_WITH_ADDR4"
        ,"LC_DETAILS_HIST.LCHIST_AVAILABLE_WITH_ADDR5"
        ,"LC_DETAILS_HIST.LCHIST_DRAFTS_AT1"
        ,"LC_DETAILS_HIST.LCHIST_DRAFTS_AT2"
        ,"LC_DETAILS_HIST.LCHIST_DRAFTS_AT3"
        ,"LC_DETAILS_HIST.LCHIST_DRAWEE_REQ"
        ,"LC_DETAILS_HIST.LCHIST_DRAWEE_TYPE"
        ,"LC_DETAILS_HIST.LCHIST_DRAWEE_BRN_CODE"
        ,"LC_DETAILS_HIST.LCHIST_DRAWEE_BIC_CODE"
        ,"LC_DETAILS_HIST.LCHIST_DRAWEE_ROUTID"
        ,"LC_DETAILS_HIST.LCHIST_DRAWEE_BNK_CODE"
        ,"LC_DETAILS_HIST.LCHIST_DRAWEE_ADDR1"
        ,"LC_DETAILS_HIST.LCHIST_DRAWEE_ADDR2"
        ,"LC_DETAILS_HIST.LCHIST_DRAWEE_ADDR3"
        ,"LC_DETAILS_HIST.LCHIST_DRAWEE_ADDR4"
        ,"LC_DETAILS_HIST.LCHIST_DRAWEE_ADDR5"
        ,"LC_DETAILS_HIST.LCHIST_MIXED_PAY_DETAILS1"
        ,"LC_DETAILS_HIST.LCHIST_MIXED_PAY_DETAILS2"
        ,"LC_DETAILS_HIST.LCHIST_MIXED_PAY_DETAILS3"
        ,"LC_DETAILS_HIST.LCHIST_MIXED_PAY_DETAILS4"
        ,"LC_DETAILS_HIST.LCHIST_DEFERRED_PAY_DETAILS1"
        ,"LC_DETAILS_HIST.LCHIST_DEFERRED_PAY_DETAILS2"
        ,"LC_DETAILS_HIST.LCHIST_DEFERRED_PAY_DETAILS3"
        ,"LC_DETAILS_HIST.LCHIST_DEFERRED_PAY_DETAILS4"
        ,"LC_DETAILS_HIST.LCHIST_PARTIAL_SHIPMENTS"
        ,"LC_DETAILS_HIST.LCHIST_TRANSHIPMENT"
        ,"LC_DETAILS_HIST.LCHIST_PLACE_IN_CHARGE"
        ,"LC_DETAILS_HIST.LCHIST_PORT_OF_LOADING"
        ,"LC_DETAILS_HIST.LCHIST_PORT_OF_DISCHARGE"
        ,"LC_DETAILS_HIST.LCHIST_PLACE_OF_FINAL_DEST"
        ,"LC_DETAILS_HIST.LCHIST_DESC_GOODS_SER1"
        ,"LC_DETAILS_HIST.LCHIST_DESC_GOODS_SER2"
        ,"LC_DETAILS_HIST.LCHIST_DESC_GOODS_SER3"
        ,"LC_DETAILS_HIST.LCHIST_DOC_REQ1"
        ,"LC_DETAILS_HIST.LCHIST_DOC_REQ2"
        ,"LC_DETAILS_HIST.LCHIST_DOC_REQ3"
        ,"LC_DETAILS_HIST.LCHIST_ADD_CONDITION1"
        ,"LC_DETAILS_HIST.LCHIST_ADD_CONDITION2"
        ,"LC_DETAILS_HIST.LCHIST_ADD_CONDITION3"
        ,"LC_DETAILS_HIST.LCHIST_CHARGES1"
        ,"LC_DETAILS_HIST.LCHIST_CHARGES2"
        ,"LC_DETAILS_HIST.LCHIST_CHARGES3"
        ,"LC_DETAILS_HIST.LCHIST_CHARGES4"
        ,"LC_DETAILS_HIST.LCHIST_CHARGES5"
        ,"LC_DETAILS_HIST.LCHIST_CHARGES6"
        ,"LC_DETAILS_HIST.LCHIST_PER_PRESENTATION_DAY"
        ,"LC_DETAILS_HIST.LCHIST_CONFIRMATION_INST"
        ,"LC_DETAILS_HIST.LCHIST_REIMB_REQ"
        ,"LC_DETAILS_HIST.LCHIST_REIMB_TYPE"
        ,"LC_DETAILS_HIST.LCHIST_REIMB_BRN_CODE"
        ,"LC_DETAILS_HIST.LCHIST_REIMB_BIC_CODE"
        ,"LC_DETAILS_HIST.LCHIST_REIMB_ROUTID"
        ,"LC_DETAILS_HIST.LCHIST_REIMB_BNK_CODE"
        ,"LC_DETAILS_HIST.LCHIST_REIMB_ADDR1"
        ,"LC_DETAILS_HIST.LCHIST_REIMB_ADDR2"
        ,"LC_DETAILS_HIST.LCHIST_REIMB_ADDR3"
        ,"LC_DETAILS_HIST.LCHIST_REIMB_ADDR4"
        ,"LC_DETAILS_HIST.LCHIST_REIMB_ADDR5"
        ,"LC_DETAILS_HIST.LCHIST_INST_PAYING1"
        ,"LC_DETAILS_HIST.LCHIST_INST_PAYING2"
        ,"LC_DETAILS_HIST.LCHIST_INST_PAYING3"
        ,"LC_DETAILS_HIST.LCHIST_INST_PAYING4"
        ,"LC_DETAILS_HIST.LCHIST_INST_PAYING5"
        ,"LC_DETAILS_HIST.LCHIST_INST_PAYING6"
        ,"LC_DETAILS_HIST.LCHIST_INST_PAYING7"
        ,"LC_DETAILS_HIST.LCHIST_INST_PAYING8"
        ,"LC_DETAILS_HIST.LCHIST_INST_PAYING9"
        ,"LC_DETAILS_HIST.LCHIST_INST_PAYING10"
        ,"LC_DETAILS_HIST.LCHIST_INST_PAYING11"
        ,"LC_DETAILS_HIST.LCHIST_INST_PAYING12"
        ,"LC_DETAILS_HIST.LCHIST_SECOND_ADV_REQ"
        ,"LC_DETAILS_HIST.LCHIST_SECOND_ADV_TYPE"
        ,"LC_DETAILS_HIST.LCHIST_SECOND_ADV_BRN_CODE"
        ,"LC_DETAILS_HIST.LCHIST_SECOND_ADV_BIC_CODE"
        ,"LC_DETAILS_HIST.LCHIST_SECOND_ADV_ROUTID"
        ,"LC_DETAILS_HIST.LCHIST_SECOND_ADV_BNK_CODE"
        ,"LC_DETAILS_HIST.LCHIST_SECOND_ADV_ADDR1"
        ,"LC_DETAILS_HIST.LCHIST_SECOND_ADV_ADDR2"
        ,"LC_DETAILS_HIST.LCHIST_SECOND_ADV_ADDR3"
        ,"LC_DETAILS_HIST.LCHIST_SECOND_ADV_ADDR4"
        ,"LC_DETAILS_HIST.LCHIST_SECOND_ADV_ADDR5"
        ,"LC_DETAILS_HIST.LCHIST_SNDR_REC_INFO1"
        ,"LC_DETAILS_HIST.LCHIST_SNDR_REC_INFO2"
        ,"LC_DETAILS_HIST.LCHIST_SNDR_REC_INFO3"
        ,"LC_DETAILS_HIST.LCHIST_SNDR_REC_INFO4"
        ,"LC_DETAILS_HIST.LCHIST_SNDR_REC_INFO5"
        ,"LC_DETAILS_HIST.LCHIST_SNDR_REC_INFO6"
        ,"LC_DETAILS_HIST.LCHIST_APPLICANT_CNTRY_CODE"
        ,"LC_DETAILS_HIST.LCHIST_AVAILABLE_WITH_CNTRY"
        ,"LC_DETAILS_HIST.LCHIST_AVAILABLE_WITH_CODETYP"
        ,"LC_DETAILS_HIST.LCHIST_DRAWEE_CNTRY_CODE"
        ,"LC_DETAILS_HIST.LCHIST_CONFIRM_INST_TYPE"
        ,"LC_DETAILS_HIST.LCHIST_REIMB_CNTRY_CODE"
        ,"LC_DETAILS_HIST.LCHIST_SECOND_ADV_CNTRYCODE"
        ,"LC_DETAILS_HIST.LCHIST_SHIPMENT_PERIOD1"
        ,"LC_DETAILS_HIST.LCHIST_SHIPMENT_PERIOD2"
        ,"LC_DETAILS_HIST.LCHIST_SHIPMENT_PERIOD3"
        ,"LC_DETAILS_HIST.LCHIST_SHIPMENT_PERIOD4"
        ,"LC_DETAILS_HIST.LCHIST_SHIPMENT_PERIOD5"
        ,"LC_DETAILS_HIST.LCHIST_SHIPMENT_PERIOD6"
        ,"LC_DETAILS_HIST.LCHIST_PER_PRESNT_REMARKS"
        ,"LC_DETAILS_HIST.LCHIST_REC_BIC_CODE"
        ,"LC_DETAILS_HIST.LCHIST_CFM_REIMB_TYPE"
        ,"LC_DETAILS_HIST.LCHIST_CFM_REIMB_BRN_CODE"
        ,"LC_DETAILS_HIST.LCHIST_CFM_REIMB_BIC_CODE"
        ,"LC_DETAILS_HIST.LCHIST_CFM_REIMB_ROUTID"
        ,"LC_DETAILS_HIST.LCHIST_CFM_REIMB_BNK_CODE"
        ,"LC_DETAILS_HIST.LCHIST_CFM_REIMB_ADDR1"
        ,"LC_DETAILS_HIST.LCHIST_CFM_REIMB_ADDR2"
        ,"LC_DETAILS_HIST.LCHIST_CFM_REIMB_ADDR3"
        ,"LC_DETAILS_HIST.LCHIST_CFM_REIMB_ADDR4"
        ,"LC_DETAILS_HIST.LCHIST_CFM_REIMB_ADDR5"
        ,"LC_DETAILS_HIST.LCHIST_CFM_REIMB_CNTRY_CODE"
    };

    private static final String ALL_FIELDS = "LC_DETAILS_HIST.LCHIST_BRN_CODE"
                            + ",LC_DETAILS_HIST.LCHIST_LC_TYPE"
                            + ",LC_DETAILS_HIST.LCHIST_LC_YEAR"
                            + ",LC_DETAILS_HIST.LCHIST_LC_SL"
                            + ",LC_DETAILS_HIST.LCHIST_LC_HISTSL"
                            + ",LC_DETAILS_HIST.LCHIST_LC_HISTDATE"
                            + ",LC_DETAILS_HIST.LCHIST_FORM_OF_DOC_CREDIT"
                            + ",LC_DETAILS_HIST.LCHIST_REFERENCE_TO_PREADVICE"
                            + ",LC_DETAILS_HIST.LCHIST_APPLICABLE_RULES"
                            + ",LC_DETAILS_HIST.LCHIST_APPLICANT_REQ"
                            + ",LC_DETAILS_HIST.LCHIST_APPLICANT_TYPE"
                            + ",LC_DETAILS_HIST.LCHIST_APPLICANT_BRN_CODE"
                            + ",LC_DETAILS_HIST.LCHIST_APPLICANT_BIC_CODE"
                            + ",LC_DETAILS_HIST.LCHIST_APPLICANT_ROUTID"
                            + ",LC_DETAILS_HIST.LCHIST_APPLICANT_BNK_CODE"
                            + ",LC_DETAILS_HIST.LCHIST_APPLICANT_ADDR1"
                            + ",LC_DETAILS_HIST.LCHIST_APPLICANT_ADDR2"
                            + ",LC_DETAILS_HIST.LCHIST_APPLICANT_ADDR3"
                            + ",LC_DETAILS_HIST.LCHIST_APPLICANT_ADDR4"
                            + ",LC_DETAILS_HIST.LCHIST_APPLICANT_ADDR5"
                            + ",LC_DETAILS_HIST.LCHIST_AVAILABLE_WITH_TYPE"
                            + ",LC_DETAILS_HIST.LCHIST_AVAILABLE_WITH_BRN_CODE"
                            + ",LC_DETAILS_HIST.LCHIST_AVAILABLE_WITH_CODE"
                            + ",LC_DETAILS_HIST.LCHIST_AVAILABLE_WITH_ROUTID"
                            + ",LC_DETAILS_HIST.LCHIST_AVAILABLE_WITH_BNK_CODE"
                            + ",LC_DETAILS_HIST.LCHIST_AVAILABLE_WITH_ADDR1"
                            + ",LC_DETAILS_HIST.LCHIST_AVAILABLE_WITH_ADDR2"
                            + ",LC_DETAILS_HIST.LCHIST_AVAILABLE_WITH_ADDR3"
                            + ",LC_DETAILS_HIST.LCHIST_AVAILABLE_WITH_ADDR4"
                            + ",LC_DETAILS_HIST.LCHIST_AVAILABLE_WITH_ADDR5"
                            + ",LC_DETAILS_HIST.LCHIST_DRAFTS_AT1"
                            + ",LC_DETAILS_HIST.LCHIST_DRAFTS_AT2"
                            + ",LC_DETAILS_HIST.LCHIST_DRAFTS_AT3"
                            + ",LC_DETAILS_HIST.LCHIST_DRAWEE_REQ"
                            + ",LC_DETAILS_HIST.LCHIST_DRAWEE_TYPE"
                            + ",LC_DETAILS_HIST.LCHIST_DRAWEE_BRN_CODE"
                            + ",LC_DETAILS_HIST.LCHIST_DRAWEE_BIC_CODE"
                            + ",LC_DETAILS_HIST.LCHIST_DRAWEE_ROUTID"
                            + ",LC_DETAILS_HIST.LCHIST_DRAWEE_BNK_CODE"
                            + ",LC_DETAILS_HIST.LCHIST_DRAWEE_ADDR1"
                            + ",LC_DETAILS_HIST.LCHIST_DRAWEE_ADDR2"
                            + ",LC_DETAILS_HIST.LCHIST_DRAWEE_ADDR3"
                            + ",LC_DETAILS_HIST.LCHIST_DRAWEE_ADDR4"
                            + ",LC_DETAILS_HIST.LCHIST_DRAWEE_ADDR5"
                            + ",LC_DETAILS_HIST.LCHIST_MIXED_PAY_DETAILS1"
                            + ",LC_DETAILS_HIST.LCHIST_MIXED_PAY_DETAILS2"
                            + ",LC_DETAILS_HIST.LCHIST_MIXED_PAY_DETAILS3"
                            + ",LC_DETAILS_HIST.LCHIST_MIXED_PAY_DETAILS4"
                            + ",LC_DETAILS_HIST.LCHIST_DEFERRED_PAY_DETAILS1"
                            + ",LC_DETAILS_HIST.LCHIST_DEFERRED_PAY_DETAILS2"
                            + ",LC_DETAILS_HIST.LCHIST_DEFERRED_PAY_DETAILS3"
                            + ",LC_DETAILS_HIST.LCHIST_DEFERRED_PAY_DETAILS4"
                            + ",LC_DETAILS_HIST.LCHIST_PARTIAL_SHIPMENTS"
                            + ",LC_DETAILS_HIST.LCHIST_TRANSHIPMENT"
                            + ",LC_DETAILS_HIST.LCHIST_PLACE_IN_CHARGE"
                            + ",LC_DETAILS_HIST.LCHIST_PORT_OF_LOADING"
                            + ",LC_DETAILS_HIST.LCHIST_PORT_OF_DISCHARGE"
                            + ",LC_DETAILS_HIST.LCHIST_PLACE_OF_FINAL_DEST"
                            + ",LC_DETAILS_HIST.LCHIST_DESC_GOODS_SER1"
                            + ",LC_DETAILS_HIST.LCHIST_DESC_GOODS_SER2"
                            + ",LC_DETAILS_HIST.LCHIST_DESC_GOODS_SER3"
                            + ",LC_DETAILS_HIST.LCHIST_DOC_REQ1"
                            + ",LC_DETAILS_HIST.LCHIST_DOC_REQ2"
                            + ",LC_DETAILS_HIST.LCHIST_DOC_REQ3"
                            + ",LC_DETAILS_HIST.LCHIST_ADD_CONDITION1"
                            + ",LC_DETAILS_HIST.LCHIST_ADD_CONDITION2"
                            + ",LC_DETAILS_HIST.LCHIST_ADD_CONDITION3"
                            + ",LC_DETAILS_HIST.LCHIST_CHARGES1"
                            + ",LC_DETAILS_HIST.LCHIST_CHARGES2"
                            + ",LC_DETAILS_HIST.LCHIST_CHARGES3"
                            + ",LC_DETAILS_HIST.LCHIST_CHARGES4"
                            + ",LC_DETAILS_HIST.LCHIST_CHARGES5"
                            + ",LC_DETAILS_HIST.LCHIST_CHARGES6"
                            + ",LC_DETAILS_HIST.LCHIST_PER_PRESENTATION_DAY"
                            + ",LC_DETAILS_HIST.LCHIST_CONFIRMATION_INST"
                            + ",LC_DETAILS_HIST.LCHIST_REIMB_REQ"
                            + ",LC_DETAILS_HIST.LCHIST_REIMB_TYPE"
                            + ",LC_DETAILS_HIST.LCHIST_REIMB_BRN_CODE"
                            + ",LC_DETAILS_HIST.LCHIST_REIMB_BIC_CODE"
                            + ",LC_DETAILS_HIST.LCHIST_REIMB_ROUTID"
                            + ",LC_DETAILS_HIST.LCHIST_REIMB_BNK_CODE"
                            + ",LC_DETAILS_HIST.LCHIST_REIMB_ADDR1"
                            + ",LC_DETAILS_HIST.LCHIST_REIMB_ADDR2"
                            + ",LC_DETAILS_HIST.LCHIST_REIMB_ADDR3"
                            + ",LC_DETAILS_HIST.LCHIST_REIMB_ADDR4"
                            + ",LC_DETAILS_HIST.LCHIST_REIMB_ADDR5"
                            + ",LC_DETAILS_HIST.LCHIST_INST_PAYING1"
                            + ",LC_DETAILS_HIST.LCHIST_INST_PAYING2"
                            + ",LC_DETAILS_HIST.LCHIST_INST_PAYING3"
                            + ",LC_DETAILS_HIST.LCHIST_INST_PAYING4"
                            + ",LC_DETAILS_HIST.LCHIST_INST_PAYING5"
                            + ",LC_DETAILS_HIST.LCHIST_INST_PAYING6"
                            + ",LC_DETAILS_HIST.LCHIST_INST_PAYING7"
                            + ",LC_DETAILS_HIST.LCHIST_INST_PAYING8"
                            + ",LC_DETAILS_HIST.LCHIST_INST_PAYING9"
                            + ",LC_DETAILS_HIST.LCHIST_INST_PAYING10"
                            + ",LC_DETAILS_HIST.LCHIST_INST_PAYING11"
                            + ",LC_DETAILS_HIST.LCHIST_INST_PAYING12"
                            + ",LC_DETAILS_HIST.LCHIST_SECOND_ADV_REQ"
                            + ",LC_DETAILS_HIST.LCHIST_SECOND_ADV_TYPE"
                            + ",LC_DETAILS_HIST.LCHIST_SECOND_ADV_BRN_CODE"
                            + ",LC_DETAILS_HIST.LCHIST_SECOND_ADV_BIC_CODE"
                            + ",LC_DETAILS_HIST.LCHIST_SECOND_ADV_ROUTID"
                            + ",LC_DETAILS_HIST.LCHIST_SECOND_ADV_BNK_CODE"
                            + ",LC_DETAILS_HIST.LCHIST_SECOND_ADV_ADDR1"
                            + ",LC_DETAILS_HIST.LCHIST_SECOND_ADV_ADDR2"
                            + ",LC_DETAILS_HIST.LCHIST_SECOND_ADV_ADDR3"
                            + ",LC_DETAILS_HIST.LCHIST_SECOND_ADV_ADDR4"
                            + ",LC_DETAILS_HIST.LCHIST_SECOND_ADV_ADDR5"
                            + ",LC_DETAILS_HIST.LCHIST_SNDR_REC_INFO1"
                            + ",LC_DETAILS_HIST.LCHIST_SNDR_REC_INFO2"
                            + ",LC_DETAILS_HIST.LCHIST_SNDR_REC_INFO3"
                            + ",LC_DETAILS_HIST.LCHIST_SNDR_REC_INFO4"
                            + ",LC_DETAILS_HIST.LCHIST_SNDR_REC_INFO5"
                            + ",LC_DETAILS_HIST.LCHIST_SNDR_REC_INFO6"
                            + ",LC_DETAILS_HIST.LCHIST_APPLICANT_CNTRY_CODE"
                            + ",LC_DETAILS_HIST.LCHIST_AVAILABLE_WITH_CNTRY"
                            + ",LC_DETAILS_HIST.LCHIST_AVAILABLE_WITH_CODETYP"
                            + ",LC_DETAILS_HIST.LCHIST_DRAWEE_CNTRY_CODE"
                            + ",LC_DETAILS_HIST.LCHIST_CONFIRM_INST_TYPE"
                            + ",LC_DETAILS_HIST.LCHIST_REIMB_CNTRY_CODE"
                            + ",LC_DETAILS_HIST.LCHIST_SECOND_ADV_CNTRYCODE"
                            + ",LC_DETAILS_HIST.LCHIST_SHIPMENT_PERIOD1"
                            + ",LC_DETAILS_HIST.LCHIST_SHIPMENT_PERIOD2"
                            + ",LC_DETAILS_HIST.LCHIST_SHIPMENT_PERIOD3"
                            + ",LC_DETAILS_HIST.LCHIST_SHIPMENT_PERIOD4"
                            + ",LC_DETAILS_HIST.LCHIST_SHIPMENT_PERIOD5"
                            + ",LC_DETAILS_HIST.LCHIST_SHIPMENT_PERIOD6"
                            + ",LC_DETAILS_HIST.LCHIST_PER_PRESNT_REMARKS"
                            + ",LC_DETAILS_HIST.LCHIST_REC_BIC_CODE"
                            + ",LC_DETAILS_HIST.LCHIST_CFM_REIMB_TYPE"
                            + ",LC_DETAILS_HIST.LCHIST_CFM_REIMB_BRN_CODE"
                            + ",LC_DETAILS_HIST.LCHIST_CFM_REIMB_BIC_CODE"
                            + ",LC_DETAILS_HIST.LCHIST_CFM_REIMB_ROUTID"
                            + ",LC_DETAILS_HIST.LCHIST_CFM_REIMB_BNK_CODE"
                            + ",LC_DETAILS_HIST.LCHIST_CFM_REIMB_ADDR1"
                            + ",LC_DETAILS_HIST.LCHIST_CFM_REIMB_ADDR2"
                            + ",LC_DETAILS_HIST.LCHIST_CFM_REIMB_ADDR3"
                            + ",LC_DETAILS_HIST.LCHIST_CFM_REIMB_ADDR4"
                            + ",LC_DETAILS_HIST.LCHIST_CFM_REIMB_ADDR5"
                            + ",LC_DETAILS_HIST.LCHIST_CFM_REIMB_CNTRY_CODE";

    public LcDetailsHist loadByKey(int _lchistBrnCode, java.util.Date _lchistLcHistdate,int _lchistLcSl, String _lchistLcType, int _lchistLcYear) throws SQLException {
        Connection _conn = null;
        try {
            _conn = openConnection();
            LcDetailsHist _obj = loadByKey(_lchistBrnCode, _lchistLcHistdate, _lchistLcSl, _lchistLcType, _lchistLcYear, _conn);
            if ( _obj != null)
            {
            OldData_Key = "LC_DETAILS_HIST" + TableValueSep + OldDataChar + _obj.getLchistBrnCode() + _obj.getLchistLcType() + _obj.getLchistLcYear() + _obj.getLchistLcSl() + _obj.getLchistLcHistsl() + _obj.getLchistLcHistdate();
        DataBlock_Old = _obj.getLchistBrnCode() + JNDINames.splitchar + _obj.getLchistLcType() + JNDINames.splitchar + _obj.getLchistLcYear() + JNDINames.splitchar + _obj.getLchistLcSl() + JNDINames.splitchar + _obj.getLchistLcHistsl() + JNDINames.splitchar + _obj.getLchistLcHistdate() + JNDINames.splitchar + _obj.getLchistFormOfDocCredit() + JNDINames.splitchar + _obj.getLchistReferenceToPreadvice() + JNDINames.splitchar + _obj.getLchistApplicableRules() + JNDINames.splitchar + _obj.getLchistApplicantReq() + JNDINames.splitchar + _obj.getLchistApplicantType() + JNDINames.splitchar + _obj.getLchistApplicantBrnCode() + JNDINames.splitchar + _obj.getLchistApplicantBicCode() + JNDINames.splitchar + _obj.getLchistApplicantRoutid() + JNDINames.splitchar + _obj.getLchistApplicantBnkCode() + JNDINames.splitchar + _obj.getLchistApplicantAddr1() + JNDINames.splitchar + _obj.getLchistApplicantAddr2() + JNDINames.splitchar + _obj.getLchistApplicantAddr3() + JNDINames.splitchar + _obj.getLchistApplicantAddr4() + JNDINames.splitchar + _obj.getLchistApplicantAddr5() + JNDINames.splitchar + _obj.getLchistAvailableWithType() + JNDINames.splitchar + _obj.getLchistAvailableWithBrnCode() + JNDINames.splitchar + _obj.getLchistAvailableWithCode() + JNDINames.splitchar + _obj.getLchistAvailableWithRoutid() + JNDINames.splitchar + _obj.getLchistAvailableWithBnkCode() + JNDINames.splitchar + _obj.getLchistAvailableWithAddr1() + JNDINames.splitchar + _obj.getLchistAvailableWithAddr2() + JNDINames.splitchar + _obj.getLchistAvailableWithAddr3() + JNDINames.splitchar + _obj.getLchistAvailableWithAddr4() + JNDINames.splitchar + _obj.getLchistAvailableWithAddr5() + JNDINames.splitchar + _obj.getLchistDraftsAt1() + JNDINames.splitchar + _obj.getLchistDraftsAt2() + JNDINames.splitchar + _obj.getLchistDraftsAt3() + JNDINames.splitchar + _obj.getLchistDraweeReq() + JNDINames.splitchar + _obj.getLchistDraweeType() + JNDINames.splitchar + _obj.getLchistDraweeBrnCode() + JNDINames.splitchar + _obj.getLchistDraweeBicCode() + JNDINames.splitchar + _obj.getLchistDraweeRoutid() + JNDINames.splitchar + _obj.getLchistDraweeBnkCode() + JNDINames.splitchar + _obj.getLchistDraweeAddr1() + JNDINames.splitchar + _obj.getLchistDraweeAddr2() + JNDINames.splitchar + _obj.getLchistDraweeAddr3() + JNDINames.splitchar + _obj.getLchistDraweeAddr4() + JNDINames.splitchar + _obj.getLchistDraweeAddr5() + JNDINames.splitchar + _obj.getLchistMixedPayDetails1() + JNDINames.splitchar + _obj.getLchistMixedPayDetails2() + JNDINames.splitchar + _obj.getLchistMixedPayDetails3() + JNDINames.splitchar + _obj.getLchistMixedPayDetails4() + JNDINames.splitchar + _obj.getLchistDeferredPayDetails1() + JNDINames.splitchar + _obj.getLchistDeferredPayDetails2() + JNDINames.splitchar + _obj.getLchistDeferredPayDetails3() + JNDINames.splitchar + _obj.getLchistDeferredPayDetails4() + JNDINames.splitchar + _obj.getLchistPartialShipments() + JNDINames.splitchar + _obj.getLchistTranshipment() + JNDINames.splitchar + _obj.getLchistPlaceInCharge() + JNDINames.splitchar + _obj.getLchistPortOfLoading() + JNDINames.splitchar + _obj.getLchistPortOfDischarge() + JNDINames.splitchar + _obj.getLchistPlaceOfFinalDest() + JNDINames.splitchar + _obj.getLchistDescGoodsSer1() + JNDINames.splitchar + _obj.getLchistDescGoodsSer2() + JNDINames.splitchar + _obj.getLchistDescGoodsSer3() + JNDINames.splitchar + _obj.getLchistDocReq1() + JNDINames.splitchar + _obj.getLchistDocReq2() + JNDINames.splitchar + _obj.getLchistDocReq3() + JNDINames.splitchar + _obj.getLchistAddCondition1() + JNDINames.splitchar + _obj.getLchistAddCondition2() + JNDINames.splitchar + _obj.getLchistAddCondition3() + JNDINames.splitchar + _obj.getLchistCharges1() + JNDINames.splitchar + _obj.getLchistCharges2() + JNDINames.splitchar + _obj.getLchistCharges3() + JNDINames.splitchar + _obj.getLchistCharges4() + JNDINames.splitchar + _obj.getLchistCharges5() + JNDINames.splitchar + _obj.getLchistCharges6() + JNDINames.splitchar + _obj.getLchistPerPresentationDay() + JNDINames.splitchar + _obj.getLchistConfirmationInst() + JNDINames.splitchar + _obj.getLchistReimbReq() + JNDINames.splitchar + _obj.getLchistReimbType() + JNDINames.splitchar + _obj.getLchistReimbBrnCode() + JNDINames.splitchar + _obj.getLchistReimbBicCode() + JNDINames.splitchar + _obj.getLchistReimbRoutid() + JNDINames.splitchar + _obj.getLchistReimbBnkCode() + JNDINames.splitchar + _obj.getLchistReimbAddr1() + JNDINames.splitchar + _obj.getLchistReimbAddr2() + JNDINames.splitchar + _obj.getLchistReimbAddr3() + JNDINames.splitchar + _obj.getLchistReimbAddr4() + JNDINames.splitchar + _obj.getLchistReimbAddr5() + JNDINames.splitchar + _obj.getLchistInstPaying1() + JNDINames.splitchar + _obj.getLchistInstPaying2() + JNDINames.splitchar + _obj.getLchistInstPaying3() + JNDINames.splitchar + _obj.getLchistInstPaying4() + JNDINames.splitchar + _obj.getLchistInstPaying5() + JNDINames.splitchar + _obj.getLchistInstPaying6() + JNDINames.splitchar + _obj.getLchistInstPaying7() + JNDINames.splitchar + _obj.getLchistInstPaying8() + JNDINames.splitchar + _obj.getLchistInstPaying9() + JNDINames.splitchar + _obj.getLchistInstPaying10() + JNDINames.splitchar + _obj.getLchistInstPaying11() + JNDINames.splitchar + _obj.getLchistInstPaying12() + JNDINames.splitchar + _obj.getLchistSecondAdvReq() + JNDINames.splitchar + _obj.getLchistSecondAdvType() + JNDINames.splitchar + _obj.getLchistSecondAdvBrnCode() + JNDINames.splitchar + _obj.getLchistSecondAdvBicCode() + JNDINames.splitchar + _obj.getLchistSecondAdvRoutid() + JNDINames.splitchar + _obj.getLchistSecondAdvBnkCode() + JNDINames.splitchar + _obj.getLchistSecondAdvAddr1() + JNDINames.splitchar + _obj.getLchistSecondAdvAddr2() + JNDINames.splitchar + _obj.getLchistSecondAdvAddr3() + JNDINames.splitchar + _obj.getLchistSecondAdvAddr4() + JNDINames.splitchar + _obj.getLchistSecondAdvAddr5() + JNDINames.splitchar + _obj.getLchistSndrRecInfo1() + JNDINames.splitchar + _obj.getLchistSndrRecInfo2() + JNDINames.splitchar + _obj.getLchistSndrRecInfo3() + JNDINames.splitchar + _obj.getLchistSndrRecInfo4() + JNDINames.splitchar + _obj.getLchistSndrRecInfo5() + JNDINames.splitchar + _obj.getLchistSndrRecInfo6() + JNDINames.splitchar + _obj.getLchistApplicantCntryCode() + JNDINames.splitchar + _obj.getLchistAvailableWithCntry() + JNDINames.splitchar + _obj.getLchistAvailableWithCodetyp() + JNDINames.splitchar + _obj.getLchistDraweeCntryCode() + JNDINames.splitchar + _obj.getLchistConfirmInstType() + JNDINames.splitchar + _obj.getLchistReimbCntryCode() + JNDINames.splitchar + _obj.getLchistSecondAdvCntrycode() + JNDINames.splitchar + _obj.getLchistShipmentPeriod1() + JNDINames.splitchar + _obj.getLchistShipmentPeriod2() + JNDINames.splitchar + _obj.getLchistShipmentPeriod3() + JNDINames.splitchar + _obj.getLchistShipmentPeriod4() + JNDINames.splitchar + _obj.getLchistShipmentPeriod5() + JNDINames.splitchar + _obj.getLchistShipmentPeriod6() + JNDINames.splitchar + _obj.getLchistPerPresntRemarks() + JNDINames.splitchar + _obj.getLchistRecBicCode() + JNDINames.splitchar + _obj.getLchistCfmReimbType() + JNDINames.splitchar + _obj.getLchistCfmReimbBrnCode() + JNDINames.splitchar + _obj.getLchistCfmReimbBicCode() + JNDINames.splitchar + _obj.getLchistCfmReimbRoutid() + JNDINames.splitchar + _obj.getLchistCfmReimbBnkCode() + JNDINames.splitchar + _obj.getLchistCfmReimbAddr1() + JNDINames.splitchar + _obj.getLchistCfmReimbAddr2() + JNDINames.splitchar + _obj.getLchistCfmReimbAddr3() + JNDINames.splitchar + _obj.getLchistCfmReimbAddr4() + JNDINames.splitchar + _obj.getLchistCfmReimbAddr5() + JNDINames.splitchar + _obj.getLchistCfmReimbCntryCode();
        }
            closeConnection(_conn);
            return _obj;
        }
        catch(SQLException e) {
            if(_conn != null)  try { closeConnection(_conn); } catch(SQLException e2) { }
            throw e;
        }
    }

    public LcDetailsHist loadByKey(int _lchistBrnCode, java.util.Date _lchistLcHistdate, int _lchistLcSl, String _lchistLcType, int _lchistLcYear, Connection _conn) throws SQLException {
        PreparedStatement _pstmt = null;
        try {
            _pstmt = _conn.prepareStatement("SELECT " + ALL_FIELDS + " FROM LC_DETAILS_HIST WHERE LC_DETAILS_HIST.LCHIST_BRN_CODE=? and LC_DETAILS_HIST.LCHIST_LC_HISTDATE=? and LC_DETAILS_HIST.LCHIST_LC_SL=? and LC_DETAILS_HIST.LCHIST_LC_TYPE=? and LC_DETAILS_HIST.LCHIST_LC_YEAR=?");
            _pstmt.setInt(1, _lchistBrnCode);
            if (_lchistLcHistdate == null) {_pstmt.setTimestamp(2, null);} else {_pstmt.setTimestamp(2, new java.sql.Timestamp(_lchistLcHistdate.getTime()));}
            _pstmt.setInt(3, _lchistLcSl);
            _pstmt.setString(4, _lchistLcType);
            _pstmt.setInt(5, _lchistLcYear);
            LcDetailsHist _list[] = loadByPreparedStatement(_pstmt);
            _pstmt.close();
            if(_list.length < 1) return null;
            else                 return _list[0];
        }
        catch(SQLException e) {
            if(_pstmt != null) try { _pstmt.close(); } catch(SQLException e2) { }
            throw e;
        }
    }

    public LcDetailsHist[] loadAll() throws SQLException {
        Connection _conn = null;
        try {
            _conn = openConnection();
            LcDetailsHist _list[] = loadAll(_conn);
            closeConnection(_conn);
            return _list;
        }
        catch(SQLException e) {
            if(_conn != null)  try { closeConnection(_conn); } catch(SQLException e2) { }
            throw e;
        }
    }

    public LcDetailsHist[] loadAll(Connection _conn) throws SQLException {
        PreparedStatement _pstmt = null;
        try {
            _pstmt = _conn.prepareStatement("SELECT " + ALL_FIELDS + " FROM LC_DETAILS_HIST");
            LcDetailsHist _list[] = loadByPreparedStatement(_pstmt);
            _pstmt.close();
            return _list;
        }
        catch(SQLException e) {
            if(_pstmt != null) try { _pstmt.close(); } catch(SQLException e2) { }
            throw e;
        }
    }

    public LcDetailsHist[] loadByPreparedStatement(PreparedStatement pstmt) throws SQLException {
        return loadByPreparedStatement(pstmt, null, 0);
    }

    public LcDetailsHist[] loadByPreparedStatement(PreparedStatement pstmt, int maxRows) throws SQLException {
        return loadByPreparedStatement(pstmt, null, maxRows);
    }

    public LcDetailsHist[] loadByPreparedStatement(PreparedStatement pstmt, int[] fieldList) throws SQLException {
        return loadByPreparedStatement(pstmt, fieldList, 0);
    }

    public LcDetailsHist[] loadByPreparedStatement(PreparedStatement pstmt, int[] fieldList, int maxRows) throws SQLException {
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            java.util.Vector v = new java.util.Vector();
            while(rs.next() && (maxRows == 0 || v.size() < maxRows)) {
                if(fieldList == null) v.addElement(decodeRow(rs));
                else v.addElement(decodeRow(rs, fieldList));
            }
            rs.close();
            LcDetailsHist list[] = new LcDetailsHist[v.size()];
            v.copyInto(list);
            return list;
        }
        catch(SQLException e) {
            if(rs!=null) try { rs.close();} catch(Exception e2) {}
            throw e;
        }
    }

    public LcDetailsHist[] loadByWhere(String where) throws SQLException {
        return loadByWhere(where, (int[])null, 0);
    }
    public LcDetailsHist[] loadByWhere(String where, int maxRows) throws SQLException {
        return loadByWhere(where, (int[])null, maxRows);
    }
    public LcDetailsHist[] loadByWhere(String where, int[] fieldList) throws SQLException {
        return loadByWhere(where, fieldList, 0);
    }
    public LcDetailsHist[] loadByWhere(String where, int[] fieldList, int maxRows) throws SQLException {
        Connection conn = null;
        try {
            conn = openConnection();
            LcDetailsHist _list[] = loadByWhere(where, conn, fieldList, maxRows);
            closeConnection(conn);
            return _list;
        }
        catch(SQLException e) {
            if(conn!=null) try { closeConnection(conn);} catch(Exception e2) {}
            throw e;
        }
    }

    public LcDetailsHist[] loadByWhere(String where, Connection conn) throws SQLException {
        return loadByWhere(where, conn, null, 0);
    }

    public LcDetailsHist[] loadByWhere(String where, Connection conn, int[] fieldList) throws SQLException {
        return loadByWhere(where, conn, fieldList, 0);
    }

    public LcDetailsHist[] loadByWhere(String where, Connection conn, int[] fieldList, int maxRows) throws SQLException {
        String sql = null;
        if(fieldList == null) sql = "select " + ALL_FIELDS + " from LC_DETAILS_HIST " + where;
        else {
            StringBuffer buff = new StringBuffer(128);
            buff.append("select ");
            for(int i = 0; i < fieldList.length; i++) {
                if(i != 0) buff.append(",");
                buff.append(S2J_FIELD_NAMES[fieldList[i]]);
            }
            buff.append(" from LC_DETAILS_HIST ");
            buff.append(where);
            sql = buff.toString();
        }
        Statement stmt = null;
        ResultSet rs = null;
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            java.util.Vector v = new java.util.Vector();
            while(rs.next() && (maxRows == 0 || v.size() < maxRows)) {
                if(fieldList == null) v.addElement(decodeRow(rs));
                else v.addElement(decodeRow(rs, fieldList));
            }
            rs.close();
            stmt.close();

            LcDetailsHist _list[] = new LcDetailsHist[v.size()];
            v.copyInto(_list);
            return _list;
        }
        catch(SQLException e) {
            if(rs!=null) try { rs.close();} catch(Exception e2) {}
            if(stmt!=null) try { stmt.close();} catch(Exception e2) {}
            throw e;
        }
    }

	public long GetMaxSl(int _lchistBrnCode, java.util.Date _lchistLcHistdate, int _lchistLcSl, String _lchistLcType, int _lchistLcYear) throws SQLException {
        ResultSet rs = null;
        long maxsl = 0;
        Connection _conn = null;
        PreparedStatement _pstmt = null;
            try {
                _conn = openConnection();
                StringBuffer _sql = new StringBuffer("SELECT NVL(MAX(LCHIST_LC_HISTSL),0) + 1 AS MAXSL FROM LC_DETAILS_HIST WHERE LC_DETAILS_HIST.LCHIST_BRN_CODE=? and LC_DETAILS_HIST.LCHIST_LC_HISTDATE=? and LC_DETAILS_HIST.LCHIST_LC_SL=? and LC_DETAILS_HIST.LCHIST_LC_TYPE=? and LC_DETAILS_HIST.LCHIST_LC_YEAR=?");
                _pstmt = _conn.prepareStatement(_sql.toString());
            _pstmt.setInt(1, _lchistBrnCode);
            if (_lchistLcHistdate == null) {_pstmt.setTimestamp(2, null);} else {_pstmt.setTimestamp(2, new java.sql.Timestamp(_lchistLcHistdate.getTime()));}
            _pstmt.setInt(3, _lchistLcSl);
            _pstmt.setString(4, _lchistLcType);
            _pstmt.setInt(5, _lchistLcYear);
                 rs = _pstmt.executeQuery();
                 if (rs.next())
                {
                maxsl = rs.getLong(1);
                }
                rs.close();
                }
                catch(SQLException e) {
                if(rs!=null) try { rs.close();} catch(Exception e2) {}
                throw e;
            }
            return maxsl;
        }

    public int UpdateByQuery(String w_sql) throws SQLException {
        Connection _conn = null;
        PreparedStatement _pstmt = null;
            try {
                _conn = openConnection();
                _pstmt = _conn.prepareStatement(w_sql);
                int _rows = _pstmt.executeUpdate();
                closeConnection(_conn);
                return 1;
            }
            catch(SQLException e) {
                if(_pstmt!=null) try { _pstmt.close();} catch(Exception e2) {}
                if(_conn!=null) try { closeConnection(_conn);} catch(Exception e2) {}
                throw e;
            }
    }
    public int deleteByKey(int _lchistBrnCode, java.util.Date _lchistLcHistdate, long _lchistLcHistsl, int _lchistLcSl, String _lchistLcType, int _lchistLcYear) throws SQLException {
        Connection _conn = null;
        try {
            _conn = openConnection();
            int _rows = deleteByKey(_lchistBrnCode, _lchistLcHistdate, _lchistLcHistsl, _lchistLcSl, _lchistLcType, _lchistLcYear, _conn);
            closeConnection(_conn);
            return _rows;
        }
        catch(SQLException e) {
            if(_conn!=null) try { closeConnection(_conn);} catch(Exception e2) {}
            throw e;
        }
    }

    public int deleteByKey(int _lchistBrnCode, java.util.Date _lchistLcHistdate, long _lchistLcHistsl, int _lchistLcSl, String _lchistLcType, int _lchistLcYear, Connection _conn) throws SQLException {
        PreparedStatement _pstmt = null;
        try {
        LcDetailsHist _obj  = loadByKey(_lchistBrnCode, _lchistLcHistdate,_lchistLcSl, _lchistLcType, _lchistLcYear);
        _obj  = null;
            _pstmt = _conn.prepareStatement("DELETE from LC_DETAILS_HIST WHERE LC_DETAILS_HIST.LCHIST_BRN_CODE=? and LC_DETAILS_HIST.LCHIST_LC_HISTDATE=? and LC_DETAILS_HIST.LCHIST_LC_SL=? and LC_DETAILS_HIST.LCHIST_LC_TYPE=? and LC_DETAILS_HIST.LCHIST_LC_YEAR=?");
            _pstmt.setInt(1, _lchistBrnCode);
            if (_lchistLcHistdate == null) {_pstmt.setTimestamp(2, null);} else {_pstmt.setTimestamp(2, new java.sql.Timestamp(_lchistLcHistdate.getTime()));}
             _pstmt.setInt(3, _lchistLcSl);
            _pstmt.setString(4, _lchistLcType);
            _pstmt.setInt(5, _lchistLcYear);
            int _rows = _pstmt.executeUpdate();
            _pstmt.close();
            return _rows;
        }
        catch(SQLException e) {
            if(_pstmt!=null) try { _pstmt.close();} catch(Exception e2) {}
            throw e;
        }
    }

    public void save(LcDetailsHist obj) throws SQLException {
//        _srcTablePKI = "LCDETAILSHIST";
//        _srcKeyPKI = obj.getLchistBrnCode() + JNDINames.splitchar + obj.getLchistLcType() + JNDINames.splitchar + obj.getLchistLcYear() + JNDINames.splitchar + obj.getLchistLcSl() + JNDINames.splitchar + obj.getLchistLcHistsl() + JNDINames.splitchar + obj.getLchistLcHistdate();
//        set_pki_values(this._COLLECTIONobj);
        if(!obj.isModifiedS2J()) return;
        Connection _conn = null;
        try {
            _conn = openConnection();
            save(obj, _conn);
            closeConnection(_conn);
        }
        catch(SQLException e) {
            if(_conn!=null) try { closeConnection(_conn);} catch(Exception e2) {}
            throw e;
        }
    }

    public void save(LcDetailsHist obj, Connection _conn) throws SQLException {
        PreparedStatement _pstmt = null;
        try {
            if(obj.isNew()) {
                int _dirtyCount = 0;
                StringBuffer _sql = new StringBuffer("INSERT into LC_DETAILS_HIST (");
                if(obj.lchistBrnCodeIsModifiedS2j()) {  _sql.append("LCHIST_BRN_CODE").append(","); _dirtyCount++; }
                if(obj.lchistLcTypeIsModifiedS2j()) {  _sql.append("LCHIST_LC_TYPE").append(","); _dirtyCount++; }
                if(obj.lchistLcYearIsModifiedS2j()) {  _sql.append("LCHIST_LC_YEAR").append(","); _dirtyCount++; }
                if(obj.lchistLcSlIsModifiedS2j()) {  _sql.append("LCHIST_LC_SL").append(","); _dirtyCount++; }
                if(obj.lchistLcHistslIsModifiedS2j()) {  _sql.append("LCHIST_LC_HISTSL").append(","); _dirtyCount++; }
                if(obj.lchistLcHistdateIsModifiedS2j()) {  _sql.append("LCHIST_LC_HISTDATE").append(","); _dirtyCount++; }
                if(obj.lchistFormOfDocCreditIsModifiedS2j()) {  _sql.append("LCHIST_FORM_OF_DOC_CREDIT").append(","); _dirtyCount++; }
                if(obj.lchistReferenceToPreadviceIsModifiedS2j()) {  _sql.append("LCHIST_REFERENCE_TO_PREADVICE").append(","); _dirtyCount++; }
                if(obj.lchistApplicableRulesIsModifiedS2j()) {  _sql.append("LCHIST_APPLICABLE_RULES").append(","); _dirtyCount++; }
                if(obj.lchistApplicantReqIsModifiedS2j()) {  _sql.append("LCHIST_APPLICANT_REQ").append(","); _dirtyCount++; }
                if(obj.lchistApplicantTypeIsModifiedS2j()) {  _sql.append("LCHIST_APPLICANT_TYPE").append(","); _dirtyCount++; }
                if(obj.lchistApplicantBrnCodeIsModifiedS2j()) {  _sql.append("LCHIST_APPLICANT_BRN_CODE").append(","); _dirtyCount++; }
                if(obj.lchistApplicantBicCodeIsModifiedS2j()) {  _sql.append("LCHIST_APPLICANT_BIC_CODE").append(","); _dirtyCount++; }
                if(obj.lchistApplicantRoutidIsModifiedS2j()) {  _sql.append("LCHIST_APPLICANT_ROUTID").append(","); _dirtyCount++; }
                if(obj.lchistApplicantBnkCodeIsModifiedS2j()) {  _sql.append("LCHIST_APPLICANT_BNK_CODE").append(","); _dirtyCount++; }
                if(obj.lchistApplicantAddr1IsModifiedS2j()) {  _sql.append("LCHIST_APPLICANT_ADDR1").append(","); _dirtyCount++; }
                if(obj.lchistApplicantAddr2IsModifiedS2j()) {  _sql.append("LCHIST_APPLICANT_ADDR2").append(","); _dirtyCount++; }
                if(obj.lchistApplicantAddr3IsModifiedS2j()) {  _sql.append("LCHIST_APPLICANT_ADDR3").append(","); _dirtyCount++; }
                if(obj.lchistApplicantAddr4IsModifiedS2j()) {  _sql.append("LCHIST_APPLICANT_ADDR4").append(","); _dirtyCount++; }
                if(obj.lchistApplicantAddr5IsModifiedS2j()) {  _sql.append("LCHIST_APPLICANT_ADDR5").append(","); _dirtyCount++; }
                if(obj.lchistAvailableWithTypeIsModifiedS2j()) {  _sql.append("LCHIST_AVAILABLE_WITH_TYPE").append(","); _dirtyCount++; }
                if(obj.lchistAvailableWithBrnCodeIsModifiedS2j()) {  _sql.append("LCHIST_AVAILABLE_WITH_BRN_CODE").append(","); _dirtyCount++; }
                if(obj.lchistAvailableWithCodeIsModifiedS2j()) {  _sql.append("LCHIST_AVAILABLE_WITH_CODE").append(","); _dirtyCount++; }
                if(obj.lchistAvailableWithRoutidIsModifiedS2j()) {  _sql.append("LCHIST_AVAILABLE_WITH_ROUTID").append(","); _dirtyCount++; }
                if(obj.lchistAvailableWithBnkCodeIsModifiedS2j()) {  _sql.append("LCHIST_AVAILABLE_WITH_BNK_CODE").append(","); _dirtyCount++; }
                if(obj.lchistAvailableWithAddr1IsModifiedS2j()) {  _sql.append("LCHIST_AVAILABLE_WITH_ADDR1").append(","); _dirtyCount++; }
                if(obj.lchistAvailableWithAddr2IsModifiedS2j()) {  _sql.append("LCHIST_AVAILABLE_WITH_ADDR2").append(","); _dirtyCount++; }
                if(obj.lchistAvailableWithAddr3IsModifiedS2j()) {  _sql.append("LCHIST_AVAILABLE_WITH_ADDR3").append(","); _dirtyCount++; }
                if(obj.lchistAvailableWithAddr4IsModifiedS2j()) {  _sql.append("LCHIST_AVAILABLE_WITH_ADDR4").append(","); _dirtyCount++; }
                if(obj.lchistAvailableWithAddr5IsModifiedS2j()) {  _sql.append("LCHIST_AVAILABLE_WITH_ADDR5").append(","); _dirtyCount++; }
                if(obj.lchistDraftsAt1IsModifiedS2j()) {  _sql.append("LCHIST_DRAFTS_AT1").append(","); _dirtyCount++; }
                if(obj.lchistDraftsAt2IsModifiedS2j()) {  _sql.append("LCHIST_DRAFTS_AT2").append(","); _dirtyCount++; }
                if(obj.lchistDraftsAt3IsModifiedS2j()) {  _sql.append("LCHIST_DRAFTS_AT3").append(","); _dirtyCount++; }
                if(obj.lchistDraweeReqIsModifiedS2j()) {  _sql.append("LCHIST_DRAWEE_REQ").append(","); _dirtyCount++; }
                if(obj.lchistDraweeTypeIsModifiedS2j()) {  _sql.append("LCHIST_DRAWEE_TYPE").append(","); _dirtyCount++; }
                if(obj.lchistDraweeBrnCodeIsModifiedS2j()) {  _sql.append("LCHIST_DRAWEE_BRN_CODE").append(","); _dirtyCount++; }
                if(obj.lchistDraweeBicCodeIsModifiedS2j()) {  _sql.append("LCHIST_DRAWEE_BIC_CODE").append(","); _dirtyCount++; }
                if(obj.lchistDraweeRoutidIsModifiedS2j()) {  _sql.append("LCHIST_DRAWEE_ROUTID").append(","); _dirtyCount++; }
                if(obj.lchistDraweeBnkCodeIsModifiedS2j()) {  _sql.append("LCHIST_DRAWEE_BNK_CODE").append(","); _dirtyCount++; }
                if(obj.lchistDraweeAddr1IsModifiedS2j()) {  _sql.append("LCHIST_DRAWEE_ADDR1").append(","); _dirtyCount++; }
                if(obj.lchistDraweeAddr2IsModifiedS2j()) {  _sql.append("LCHIST_DRAWEE_ADDR2").append(","); _dirtyCount++; }
                if(obj.lchistDraweeAddr3IsModifiedS2j()) {  _sql.append("LCHIST_DRAWEE_ADDR3").append(","); _dirtyCount++; }
                if(obj.lchistDraweeAddr4IsModifiedS2j()) {  _sql.append("LCHIST_DRAWEE_ADDR4").append(","); _dirtyCount++; }
                if(obj.lchistDraweeAddr5IsModifiedS2j()) {  _sql.append("LCHIST_DRAWEE_ADDR5").append(","); _dirtyCount++; }
                if(obj.lchistMixedPayDetails1IsModifiedS2j()) {  _sql.append("LCHIST_MIXED_PAY_DETAILS1").append(","); _dirtyCount++; }
                if(obj.lchistMixedPayDetails2IsModifiedS2j()) {  _sql.append("LCHIST_MIXED_PAY_DETAILS2").append(","); _dirtyCount++; }
                if(obj.lchistMixedPayDetails3IsModifiedS2j()) {  _sql.append("LCHIST_MIXED_PAY_DETAILS3").append(","); _dirtyCount++; }
                if(obj.lchistMixedPayDetails4IsModifiedS2j()) {  _sql.append("LCHIST_MIXED_PAY_DETAILS4").append(","); _dirtyCount++; }
                if(obj.lchistDeferredPayDetails1IsModifiedS2j()) {  _sql.append("LCHIST_DEFERRED_PAY_DETAILS1").append(","); _dirtyCount++; }
                if(obj.lchistDeferredPayDetails2IsModifiedS2j()) {  _sql.append("LCHIST_DEFERRED_PAY_DETAILS2").append(","); _dirtyCount++; }
                if(obj.lchistDeferredPayDetails3IsModifiedS2j()) {  _sql.append("LCHIST_DEFERRED_PAY_DETAILS3").append(","); _dirtyCount++; }
                if(obj.lchistDeferredPayDetails4IsModifiedS2j()) {  _sql.append("LCHIST_DEFERRED_PAY_DETAILS4").append(","); _dirtyCount++; }
                if(obj.lchistPartialShipmentsIsModifiedS2j()) {  _sql.append("LCHIST_PARTIAL_SHIPMENTS").append(","); _dirtyCount++; }
                if(obj.lchistTranshipmentIsModifiedS2j()) {  _sql.append("LCHIST_TRANSHIPMENT").append(","); _dirtyCount++; }
                if(obj.lchistPlaceInChargeIsModifiedS2j()) {  _sql.append("LCHIST_PLACE_IN_CHARGE").append(","); _dirtyCount++; }
                if(obj.lchistPortOfLoadingIsModifiedS2j()) {  _sql.append("LCHIST_PORT_OF_LOADING").append(","); _dirtyCount++; }
                if(obj.lchistPortOfDischargeIsModifiedS2j()) {  _sql.append("LCHIST_PORT_OF_DISCHARGE").append(","); _dirtyCount++; }
                if(obj.lchistPlaceOfFinalDestIsModifiedS2j()) {  _sql.append("LCHIST_PLACE_OF_FINAL_DEST").append(","); _dirtyCount++; }
                if(obj.lchistDescGoodsSer1IsModifiedS2j()) {  _sql.append("LCHIST_DESC_GOODS_SER1").append(","); _dirtyCount++; }
                if(obj.lchistDescGoodsSer2IsModifiedS2j()) {  _sql.append("LCHIST_DESC_GOODS_SER2").append(","); _dirtyCount++; }
                if(obj.lchistDescGoodsSer3IsModifiedS2j()) {  _sql.append("LCHIST_DESC_GOODS_SER3").append(","); _dirtyCount++; }
                if(obj.lchistDocReq1IsModifiedS2j()) {  _sql.append("LCHIST_DOC_REQ1").append(","); _dirtyCount++; }
                if(obj.lchistDocReq2IsModifiedS2j()) {  _sql.append("LCHIST_DOC_REQ2").append(","); _dirtyCount++; }
                if(obj.lchistDocReq3IsModifiedS2j()) {  _sql.append("LCHIST_DOC_REQ3").append(","); _dirtyCount++; }
                if(obj.lchistAddCondition1IsModifiedS2j()) {  _sql.append("LCHIST_ADD_CONDITION1").append(","); _dirtyCount++; }
                if(obj.lchistAddCondition2IsModifiedS2j()) {  _sql.append("LCHIST_ADD_CONDITION2").append(","); _dirtyCount++; }
                if(obj.lchistAddCondition3IsModifiedS2j()) {  _sql.append("LCHIST_ADD_CONDITION3").append(","); _dirtyCount++; }
                if(obj.lchistCharges1IsModifiedS2j()) {  _sql.append("LCHIST_CHARGES1").append(","); _dirtyCount++; }
                if(obj.lchistCharges2IsModifiedS2j()) {  _sql.append("LCHIST_CHARGES2").append(","); _dirtyCount++; }
                if(obj.lchistCharges3IsModifiedS2j()) {  _sql.append("LCHIST_CHARGES3").append(","); _dirtyCount++; }
                if(obj.lchistCharges4IsModifiedS2j()) {  _sql.append("LCHIST_CHARGES4").append(","); _dirtyCount++; }
                if(obj.lchistCharges5IsModifiedS2j()) {  _sql.append("LCHIST_CHARGES5").append(","); _dirtyCount++; }
                if(obj.lchistCharges6IsModifiedS2j()) {  _sql.append("LCHIST_CHARGES6").append(","); _dirtyCount++; }
                if(obj.lchistPerPresentationDayIsModifiedS2j()) {  _sql.append("LCHIST_PER_PRESENTATION_DAY").append(","); _dirtyCount++; }
                if(obj.lchistConfirmationInstIsModifiedS2j()) {  _sql.append("LCHIST_CONFIRMATION_INST").append(","); _dirtyCount++; }
                if(obj.lchistReimbReqIsModifiedS2j()) {  _sql.append("LCHIST_REIMB_REQ").append(","); _dirtyCount++; }
                if(obj.lchistReimbTypeIsModifiedS2j()) {  _sql.append("LCHIST_REIMB_TYPE").append(","); _dirtyCount++; }
                if(obj.lchistReimbBrnCodeIsModifiedS2j()) {  _sql.append("LCHIST_REIMB_BRN_CODE").append(","); _dirtyCount++; }
                if(obj.lchistReimbBicCodeIsModifiedS2j()) {  _sql.append("LCHIST_REIMB_BIC_CODE").append(","); _dirtyCount++; }
                if(obj.lchistReimbRoutidIsModifiedS2j()) {  _sql.append("LCHIST_REIMB_ROUTID").append(","); _dirtyCount++; }
                if(obj.lchistReimbBnkCodeIsModifiedS2j()) {  _sql.append("LCHIST_REIMB_BNK_CODE").append(","); _dirtyCount++; }
                if(obj.lchistReimbAddr1IsModifiedS2j()) {  _sql.append("LCHIST_REIMB_ADDR1").append(","); _dirtyCount++; }
                if(obj.lchistReimbAddr2IsModifiedS2j()) {  _sql.append("LCHIST_REIMB_ADDR2").append(","); _dirtyCount++; }
                if(obj.lchistReimbAddr3IsModifiedS2j()) {  _sql.append("LCHIST_REIMB_ADDR3").append(","); _dirtyCount++; }
                if(obj.lchistReimbAddr4IsModifiedS2j()) {  _sql.append("LCHIST_REIMB_ADDR4").append(","); _dirtyCount++; }
                if(obj.lchistReimbAddr5IsModifiedS2j()) {  _sql.append("LCHIST_REIMB_ADDR5").append(","); _dirtyCount++; }
                if(obj.lchistInstPaying1IsModifiedS2j()) {  _sql.append("LCHIST_INST_PAYING1").append(","); _dirtyCount++; }
                if(obj.lchistInstPaying2IsModifiedS2j()) {  _sql.append("LCHIST_INST_PAYING2").append(","); _dirtyCount++; }
                if(obj.lchistInstPaying3IsModifiedS2j()) {  _sql.append("LCHIST_INST_PAYING3").append(","); _dirtyCount++; }
                if(obj.lchistInstPaying4IsModifiedS2j()) {  _sql.append("LCHIST_INST_PAYING4").append(","); _dirtyCount++; }
                if(obj.lchistInstPaying5IsModifiedS2j()) {  _sql.append("LCHIST_INST_PAYING5").append(","); _dirtyCount++; }
                if(obj.lchistInstPaying6IsModifiedS2j()) {  _sql.append("LCHIST_INST_PAYING6").append(","); _dirtyCount++; }
                if(obj.lchistInstPaying7IsModifiedS2j()) {  _sql.append("LCHIST_INST_PAYING7").append(","); _dirtyCount++; }
                if(obj.lchistInstPaying8IsModifiedS2j()) {  _sql.append("LCHIST_INST_PAYING8").append(","); _dirtyCount++; }
                if(obj.lchistInstPaying9IsModifiedS2j()) {  _sql.append("LCHIST_INST_PAYING9").append(","); _dirtyCount++; }
                if(obj.lchistInstPaying10IsModifiedS2j()) {  _sql.append("LCHIST_INST_PAYING10").append(","); _dirtyCount++; }
                if(obj.lchistInstPaying11IsModifiedS2j()) {  _sql.append("LCHIST_INST_PAYING11").append(","); _dirtyCount++; }
                if(obj.lchistInstPaying12IsModifiedS2j()) {  _sql.append("LCHIST_INST_PAYING12").append(","); _dirtyCount++; }
                if(obj.lchistSecondAdvReqIsModifiedS2j()) {  _sql.append("LCHIST_SECOND_ADV_REQ").append(","); _dirtyCount++; }
                if(obj.lchistSecondAdvTypeIsModifiedS2j()) {  _sql.append("LCHIST_SECOND_ADV_TYPE").append(","); _dirtyCount++; }
                if(obj.lchistSecondAdvBrnCodeIsModifiedS2j()) {  _sql.append("LCHIST_SECOND_ADV_BRN_CODE").append(","); _dirtyCount++; }
                if(obj.lchistSecondAdvBicCodeIsModifiedS2j()) {  _sql.append("LCHIST_SECOND_ADV_BIC_CODE").append(","); _dirtyCount++; }
                if(obj.lchistSecondAdvRoutidIsModifiedS2j()) {  _sql.append("LCHIST_SECOND_ADV_ROUTID").append(","); _dirtyCount++; }
                if(obj.lchistSecondAdvBnkCodeIsModifiedS2j()) {  _sql.append("LCHIST_SECOND_ADV_BNK_CODE").append(","); _dirtyCount++; }
                if(obj.lchistSecondAdvAddr1IsModifiedS2j()) {  _sql.append("LCHIST_SECOND_ADV_ADDR1").append(","); _dirtyCount++; }
                if(obj.lchistSecondAdvAddr2IsModifiedS2j()) {  _sql.append("LCHIST_SECOND_ADV_ADDR2").append(","); _dirtyCount++; }
                if(obj.lchistSecondAdvAddr3IsModifiedS2j()) {  _sql.append("LCHIST_SECOND_ADV_ADDR3").append(","); _dirtyCount++; }
                if(obj.lchistSecondAdvAddr4IsModifiedS2j()) {  _sql.append("LCHIST_SECOND_ADV_ADDR4").append(","); _dirtyCount++; }
                if(obj.lchistSecondAdvAddr5IsModifiedS2j()) {  _sql.append("LCHIST_SECOND_ADV_ADDR5").append(","); _dirtyCount++; }
                if(obj.lchistSndrRecInfo1IsModifiedS2j()) {  _sql.append("LCHIST_SNDR_REC_INFO1").append(","); _dirtyCount++; }
                if(obj.lchistSndrRecInfo2IsModifiedS2j()) {  _sql.append("LCHIST_SNDR_REC_INFO2").append(","); _dirtyCount++; }
                if(obj.lchistSndrRecInfo3IsModifiedS2j()) {  _sql.append("LCHIST_SNDR_REC_INFO3").append(","); _dirtyCount++; }
                if(obj.lchistSndrRecInfo4IsModifiedS2j()) {  _sql.append("LCHIST_SNDR_REC_INFO4").append(","); _dirtyCount++; }
                if(obj.lchistSndrRecInfo5IsModifiedS2j()) {  _sql.append("LCHIST_SNDR_REC_INFO5").append(","); _dirtyCount++; }
                if(obj.lchistSndrRecInfo6IsModifiedS2j()) {  _sql.append("LCHIST_SNDR_REC_INFO6").append(","); _dirtyCount++; }
                if(obj.lchistApplicantCntryCodeIsModifiedS2j()) {  _sql.append("LCHIST_APPLICANT_CNTRY_CODE").append(","); _dirtyCount++; }
                if(obj.lchistAvailableWithCntryIsModifiedS2j()) {  _sql.append("LCHIST_AVAILABLE_WITH_CNTRY").append(","); _dirtyCount++; }
                if(obj.lchistAvailableWithCodetypIsModifiedS2j()) {  _sql.append("LCHIST_AVAILABLE_WITH_CODETYP").append(","); _dirtyCount++; }
                if(obj.lchistDraweeCntryCodeIsModifiedS2j()) {  _sql.append("LCHIST_DRAWEE_CNTRY_CODE").append(","); _dirtyCount++; }
                if(obj.lchistConfirmInstTypeIsModifiedS2j()) {  _sql.append("LCHIST_CONFIRM_INST_TYPE").append(","); _dirtyCount++; }
                if(obj.lchistReimbCntryCodeIsModifiedS2j()) {  _sql.append("LCHIST_REIMB_CNTRY_CODE").append(","); _dirtyCount++; }
                if(obj.lchistSecondAdvCntrycodeIsModifiedS2j()) {  _sql.append("LCHIST_SECOND_ADV_CNTRYCODE").append(","); _dirtyCount++; }
                if(obj.lchistShipmentPeriod1IsModifiedS2j()) {  _sql.append("LCHIST_SHIPMENT_PERIOD1").append(","); _dirtyCount++; }
                if(obj.lchistShipmentPeriod2IsModifiedS2j()) {  _sql.append("LCHIST_SHIPMENT_PERIOD2").append(","); _dirtyCount++; }
                if(obj.lchistShipmentPeriod3IsModifiedS2j()) {  _sql.append("LCHIST_SHIPMENT_PERIOD3").append(","); _dirtyCount++; }
                if(obj.lchistShipmentPeriod4IsModifiedS2j()) {  _sql.append("LCHIST_SHIPMENT_PERIOD4").append(","); _dirtyCount++; }
                if(obj.lchistShipmentPeriod5IsModifiedS2j()) {  _sql.append("LCHIST_SHIPMENT_PERIOD5").append(","); _dirtyCount++; }
                if(obj.lchistShipmentPeriod6IsModifiedS2j()) {  _sql.append("LCHIST_SHIPMENT_PERIOD6").append(","); _dirtyCount++; }
                if(obj.lchistPerPresntRemarksIsModifiedS2j()) {  _sql.append("LCHIST_PER_PRESNT_REMARKS").append(","); _dirtyCount++; }
                if(obj.lchistRecBicCodeIsModifiedS2j()) {  _sql.append("LCHIST_REC_BIC_CODE").append(","); _dirtyCount++; }
                if(obj.lchistCfmReimbTypeIsModifiedS2j()) {  _sql.append("LCHIST_CFM_REIMB_TYPE").append(","); _dirtyCount++; }
                if(obj.lchistCfmReimbBrnCodeIsModifiedS2j()) {  _sql.append("LCHIST_CFM_REIMB_BRN_CODE").append(","); _dirtyCount++; }
                if(obj.lchistCfmReimbBicCodeIsModifiedS2j()) {  _sql.append("LCHIST_CFM_REIMB_BIC_CODE").append(","); _dirtyCount++; }
                if(obj.lchistCfmReimbRoutidIsModifiedS2j()) {  _sql.append("LCHIST_CFM_REIMB_ROUTID").append(","); _dirtyCount++; }
                if(obj.lchistCfmReimbBnkCodeIsModifiedS2j()) {  _sql.append("LCHIST_CFM_REIMB_BNK_CODE").append(","); _dirtyCount++; }
                if(obj.lchistCfmReimbAddr1IsModifiedS2j()) {  _sql.append("LCHIST_CFM_REIMB_ADDR1").append(","); _dirtyCount++; }
                if(obj.lchistCfmReimbAddr2IsModifiedS2j()) {  _sql.append("LCHIST_CFM_REIMB_ADDR2").append(","); _dirtyCount++; }
                if(obj.lchistCfmReimbAddr3IsModifiedS2j()) {  _sql.append("LCHIST_CFM_REIMB_ADDR3").append(","); _dirtyCount++; }
                if(obj.lchistCfmReimbAddr4IsModifiedS2j()) {  _sql.append("LCHIST_CFM_REIMB_ADDR4").append(","); _dirtyCount++; }
                if(obj.lchistCfmReimbAddr5IsModifiedS2j()) {  _sql.append("LCHIST_CFM_REIMB_ADDR5").append(","); _dirtyCount++; }
                if(obj.lchistCfmReimbCntryCodeIsModifiedS2j()) {  _sql.append("LCHIST_CFM_REIMB_CNTRY_CODE").append(","); _dirtyCount++; }
                _sql.setLength(_sql.length() - 1);
                _sql.append(") values (" );
                for(int i = 0; i < _dirtyCount; i++) _sql.append("?,");
                _sql.setLength(_sql.length() - 1);
                _sql.append(")");

                _pstmt = _conn.prepareStatement(_sql.toString());
                _dirtyCount = 0;
                if(obj.lchistBrnCodeIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLchistBrnCode()); } 
                if(obj.lchistLcTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistLcType()); } 
                if(obj.lchistLcYearIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLchistLcYear()); } 
                if(obj.lchistLcSlIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLchistLcSl()); } 
                if(obj.lchistLcHistslIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLchistLcHistsl()); } 
                if(obj.lchistLcHistdateIsModifiedS2j()) { if (obj.getLchistLcHistdate() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getLchistLcHistdate().getTime()));} } 
                if(obj.lchistFormOfDocCreditIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLchistFormOfDocCredit()); } 
                if(obj.lchistReferenceToPreadviceIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistReferenceToPreadvice()); } 
                if(obj.lchistApplicableRulesIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLchistApplicableRules()); } 
                if(obj.lchistApplicantReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLchistApplicantReq())); } 
                if(obj.lchistApplicantTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLchistApplicantType())); } 
                if(obj.lchistApplicantBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistApplicantBrnCode()); } 
                if(obj.lchistApplicantBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistApplicantBicCode()); } 
                if(obj.lchistApplicantRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistApplicantRoutid()); } 
                if(obj.lchistApplicantBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistApplicantBnkCode()); } 
                if(obj.lchistApplicantAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistApplicantAddr1()); } 
                if(obj.lchistApplicantAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistApplicantAddr2()); } 
                if(obj.lchistApplicantAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistApplicantAddr3()); } 
                if(obj.lchistApplicantAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistApplicantAddr4()); } 
                if(obj.lchistApplicantAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistApplicantAddr5()); } 
                if(obj.lchistAvailableWithTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLchistAvailableWithType())); } 
                if(obj.lchistAvailableWithBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistAvailableWithBrnCode()); } 
                if(obj.lchistAvailableWithCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistAvailableWithCode()); } 
                if(obj.lchistAvailableWithRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistAvailableWithRoutid()); } 
                if(obj.lchistAvailableWithBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistAvailableWithBnkCode()); } 
                if(obj.lchistAvailableWithAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistAvailableWithAddr1()); } 
                if(obj.lchistAvailableWithAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistAvailableWithAddr2()); } 
                if(obj.lchistAvailableWithAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistAvailableWithAddr3()); } 
                if(obj.lchistAvailableWithAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistAvailableWithAddr4()); } 
                if(obj.lchistAvailableWithAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistAvailableWithAddr5()); } 
                if(obj.lchistDraftsAt1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistDraftsAt1()); } 
                if(obj.lchistDraftsAt2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistDraftsAt2()); } 
                if(obj.lchistDraftsAt3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistDraftsAt3()); } 
                if(obj.lchistDraweeReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLchistDraweeReq())); } 
                if(obj.lchistDraweeTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLchistDraweeType())); } 
                if(obj.lchistDraweeBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistDraweeBrnCode()); } 
                if(obj.lchistDraweeBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistDraweeBicCode()); } 
                if(obj.lchistDraweeRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistDraweeRoutid()); } 
                if(obj.lchistDraweeBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistDraweeBnkCode()); } 
                if(obj.lchistDraweeAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistDraweeAddr1()); } 
                if(obj.lchistDraweeAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistDraweeAddr2()); } 
                if(obj.lchistDraweeAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistDraweeAddr3()); } 
                if(obj.lchistDraweeAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistDraweeAddr4()); } 
                if(obj.lchistDraweeAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistDraweeAddr5()); } 
                if(obj.lchistMixedPayDetails1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistMixedPayDetails1()); } 
                if(obj.lchistMixedPayDetails2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistMixedPayDetails2()); } 
                if(obj.lchistMixedPayDetails3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistMixedPayDetails3()); } 
                if(obj.lchistMixedPayDetails4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistMixedPayDetails4()); } 
                if(obj.lchistDeferredPayDetails1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistDeferredPayDetails1()); } 
                if(obj.lchistDeferredPayDetails2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistDeferredPayDetails2()); } 
                if(obj.lchistDeferredPayDetails3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistDeferredPayDetails3()); } 
                if(obj.lchistDeferredPayDetails4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistDeferredPayDetails4()); } 
                if(obj.lchistPartialShipmentsIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLchistPartialShipments()); } 
                if(obj.lchistTranshipmentIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLchistTranshipment()); } 
                if(obj.lchistPlaceInChargeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistPlaceInCharge()); } 
                if(obj.lchistPortOfLoadingIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistPortOfLoading()); } 
                if(obj.lchistPortOfDischargeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistPortOfDischarge()); } 
                if(obj.lchistPlaceOfFinalDestIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistPlaceOfFinalDest()); } 
                if(obj.lchistDescGoodsSer1IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getLchistDescGoodsSer1()); } 
                if(obj.lchistDescGoodsSer2IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getLchistDescGoodsSer2()); } 
                if(obj.lchistDescGoodsSer3IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getLchistDescGoodsSer3()); } 
                if(obj.lchistDocReq1IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getLchistDocReq1()); } 
                if(obj.lchistDocReq2IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getLchistDocReq2()); } 
                if(obj.lchistDocReq3IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getLchistDocReq3()); } 
                if(obj.lchistAddCondition1IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getLchistAddCondition1()); } 
                if(obj.lchistAddCondition2IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getLchistAddCondition2()); } 
                if(obj.lchistAddCondition3IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getLchistAddCondition3()); } 
                if(obj.lchistCharges1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistCharges1()); } 
                if(obj.lchistCharges2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistCharges2()); } 
                if(obj.lchistCharges3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistCharges3()); } 
                if(obj.lchistCharges4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistCharges4()); } 
                if(obj.lchistCharges5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistCharges5()); } 
                if(obj.lchistCharges6IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistCharges6()); } 
                if(obj.lchistPerPresentationDayIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLchistPerPresentationDay()); } 
                if(obj.lchistConfirmationInstIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLchistConfirmationInst()); } 
                if(obj.lchistReimbReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLchistReimbReq())); } 
                if(obj.lchistReimbTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLchistReimbType())); } 
                if(obj.lchistReimbBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistReimbBrnCode()); } 
                if(obj.lchistReimbBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistReimbBicCode()); } 
                if(obj.lchistReimbRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistReimbRoutid()); } 
                if(obj.lchistReimbBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistReimbBnkCode()); } 
                if(obj.lchistReimbAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistReimbAddr1()); } 
                if(obj.lchistReimbAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistReimbAddr2()); } 
                if(obj.lchistReimbAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistReimbAddr3()); } 
                if(obj.lchistReimbAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistReimbAddr4()); } 
                if(obj.lchistReimbAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistReimbAddr5()); } 
                if(obj.lchistInstPaying1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistInstPaying1()); } 
                if(obj.lchistInstPaying2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistInstPaying2()); } 
                if(obj.lchistInstPaying3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistInstPaying3()); } 
                if(obj.lchistInstPaying4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistInstPaying4()); } 
                if(obj.lchistInstPaying5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistInstPaying5()); } 
                if(obj.lchistInstPaying6IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistInstPaying6()); } 
                if(obj.lchistInstPaying7IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistInstPaying7()); } 
                if(obj.lchistInstPaying8IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistInstPaying8()); } 
                if(obj.lchistInstPaying9IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistInstPaying9()); } 
                if(obj.lchistInstPaying10IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistInstPaying10()); } 
                if(obj.lchistInstPaying11IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistInstPaying11()); } 
                if(obj.lchistInstPaying12IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistInstPaying12()); } 
                if(obj.lchistSecondAdvReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLchistSecondAdvReq())); } 
                if(obj.lchistSecondAdvTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLchistSecondAdvType())); } 
                if(obj.lchistSecondAdvBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistSecondAdvBrnCode()); } 
                if(obj.lchistSecondAdvBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistSecondAdvBicCode()); } 
                if(obj.lchistSecondAdvRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistSecondAdvRoutid()); } 
                if(obj.lchistSecondAdvBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistSecondAdvBnkCode()); } 
                if(obj.lchistSecondAdvAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistSecondAdvAddr1()); } 
                if(obj.lchistSecondAdvAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistSecondAdvAddr2()); } 
                if(obj.lchistSecondAdvAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistSecondAdvAddr3()); } 
                if(obj.lchistSecondAdvAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistSecondAdvAddr4()); } 
                if(obj.lchistSecondAdvAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistSecondAdvAddr5()); } 
                if(obj.lchistSndrRecInfo1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistSndrRecInfo1()); } 
                if(obj.lchistSndrRecInfo2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistSndrRecInfo2()); } 
                if(obj.lchistSndrRecInfo3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistSndrRecInfo3()); } 
                if(obj.lchistSndrRecInfo4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistSndrRecInfo4()); } 
                if(obj.lchistSndrRecInfo5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistSndrRecInfo5()); } 
                if(obj.lchistSndrRecInfo6IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistSndrRecInfo6()); } 
                if(obj.lchistApplicantCntryCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistApplicantCntryCode()); } 
                if(obj.lchistAvailableWithCntryIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistAvailableWithCntry()); } 
                if(obj.lchistAvailableWithCodetypIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLchistAvailableWithCodetyp()); } 
                if(obj.lchistDraweeCntryCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistDraweeCntryCode()); } 
                if(obj.lchistConfirmInstTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLchistConfirmInstType())); } 
                if(obj.lchistReimbCntryCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistReimbCntryCode()); } 
                if(obj.lchistSecondAdvCntrycodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistSecondAdvCntrycode()); } 
                if(obj.lchistShipmentPeriod1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistShipmentPeriod1()); } 
                if(obj.lchistShipmentPeriod2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistShipmentPeriod2()); } 
                if(obj.lchistShipmentPeriod3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistShipmentPeriod3()); } 
                if(obj.lchistShipmentPeriod4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistShipmentPeriod4()); } 
                if(obj.lchistShipmentPeriod5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistShipmentPeriod5()); } 
                if(obj.lchistShipmentPeriod6IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistShipmentPeriod6()); } 
                if(obj.lchistPerPresntRemarksIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistPerPresntRemarks()); } 
                if(obj.lchistRecBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistRecBicCode()); } 
                if(obj.lchistCfmReimbTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLchistCfmReimbType())); } 
                if(obj.lchistCfmReimbBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistCfmReimbBrnCode()); } 
                if(obj.lchistCfmReimbBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistCfmReimbBicCode()); } 
                if(obj.lchistCfmReimbRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistCfmReimbRoutid()); } 
                if(obj.lchistCfmReimbBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistCfmReimbBnkCode()); } 
                if(obj.lchistCfmReimbAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistCfmReimbAddr1()); } 
                if(obj.lchistCfmReimbAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistCfmReimbAddr2()); } 
                if(obj.lchistCfmReimbAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistCfmReimbAddr3()); } 
                if(obj.lchistCfmReimbAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistCfmReimbAddr4()); } 
                if(obj.lchistCfmReimbAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistCfmReimbAddr5()); } 
                if(obj.lchistCfmReimbCntryCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistCfmReimbCntryCode()); } 
                _pstmt.executeUpdate();
                obj.setIsNew(false);
                obj.resetIsModifiedS2J();
            }
            else {
                StringBuffer _sql = new StringBuffer("UPDATE LC_DETAILS_HIST SET ");
                if(obj.lchistBrnCodeIsModifiedS2j()) {  _sql.append("LCHIST_BRN_CODE").append("=?,"); }
                if(obj.lchistLcTypeIsModifiedS2j()) {  _sql.append("LCHIST_LC_TYPE").append("=?,"); }
                if(obj.lchistLcYearIsModifiedS2j()) {  _sql.append("LCHIST_LC_YEAR").append("=?,"); }
                if(obj.lchistLcSlIsModifiedS2j()) {  _sql.append("LCHIST_LC_SL").append("=?,"); }
                if(obj.lchistLcHistslIsModifiedS2j()) {  _sql.append("LCHIST_LC_HISTSL").append("=?,"); }
                if(obj.lchistLcHistdateIsModifiedS2j()) {  _sql.append("LCHIST_LC_HISTDATE").append("=?,"); }
                if(obj.lchistFormOfDocCreditIsModifiedS2j()) {  _sql.append("LCHIST_FORM_OF_DOC_CREDIT").append("=?,"); }
                if(obj.lchistReferenceToPreadviceIsModifiedS2j()) {  _sql.append("LCHIST_REFERENCE_TO_PREADVICE").append("=?,"); }
                if(obj.lchistApplicableRulesIsModifiedS2j()) {  _sql.append("LCHIST_APPLICABLE_RULES").append("=?,"); }
                if(obj.lchistApplicantReqIsModifiedS2j()) {  _sql.append("LCHIST_APPLICANT_REQ").append("=?,"); }
                if(obj.lchistApplicantTypeIsModifiedS2j()) {  _sql.append("LCHIST_APPLICANT_TYPE").append("=?,"); }
                if(obj.lchistApplicantBrnCodeIsModifiedS2j()) {  _sql.append("LCHIST_APPLICANT_BRN_CODE").append("=?,"); }
                if(obj.lchistApplicantBicCodeIsModifiedS2j()) {  _sql.append("LCHIST_APPLICANT_BIC_CODE").append("=?,"); }
                if(obj.lchistApplicantRoutidIsModifiedS2j()) {  _sql.append("LCHIST_APPLICANT_ROUTID").append("=?,"); }
                if(obj.lchistApplicantBnkCodeIsModifiedS2j()) {  _sql.append("LCHIST_APPLICANT_BNK_CODE").append("=?,"); }
                if(obj.lchistApplicantAddr1IsModifiedS2j()) {  _sql.append("LCHIST_APPLICANT_ADDR1").append("=?,"); }
                if(obj.lchistApplicantAddr2IsModifiedS2j()) {  _sql.append("LCHIST_APPLICANT_ADDR2").append("=?,"); }
                if(obj.lchistApplicantAddr3IsModifiedS2j()) {  _sql.append("LCHIST_APPLICANT_ADDR3").append("=?,"); }
                if(obj.lchistApplicantAddr4IsModifiedS2j()) {  _sql.append("LCHIST_APPLICANT_ADDR4").append("=?,"); }
                if(obj.lchistApplicantAddr5IsModifiedS2j()) {  _sql.append("LCHIST_APPLICANT_ADDR5").append("=?,"); }
                if(obj.lchistAvailableWithTypeIsModifiedS2j()) {  _sql.append("LCHIST_AVAILABLE_WITH_TYPE").append("=?,"); }
                if(obj.lchistAvailableWithBrnCodeIsModifiedS2j()) {  _sql.append("LCHIST_AVAILABLE_WITH_BRN_CODE").append("=?,"); }
                if(obj.lchistAvailableWithCodeIsModifiedS2j()) {  _sql.append("LCHIST_AVAILABLE_WITH_CODE").append("=?,"); }
                if(obj.lchistAvailableWithRoutidIsModifiedS2j()) {  _sql.append("LCHIST_AVAILABLE_WITH_ROUTID").append("=?,"); }
                if(obj.lchistAvailableWithBnkCodeIsModifiedS2j()) {  _sql.append("LCHIST_AVAILABLE_WITH_BNK_CODE").append("=?,"); }
                if(obj.lchistAvailableWithAddr1IsModifiedS2j()) {  _sql.append("LCHIST_AVAILABLE_WITH_ADDR1").append("=?,"); }
                if(obj.lchistAvailableWithAddr2IsModifiedS2j()) {  _sql.append("LCHIST_AVAILABLE_WITH_ADDR2").append("=?,"); }
                if(obj.lchistAvailableWithAddr3IsModifiedS2j()) {  _sql.append("LCHIST_AVAILABLE_WITH_ADDR3").append("=?,"); }
                if(obj.lchistAvailableWithAddr4IsModifiedS2j()) {  _sql.append("LCHIST_AVAILABLE_WITH_ADDR4").append("=?,"); }
                if(obj.lchistAvailableWithAddr5IsModifiedS2j()) {  _sql.append("LCHIST_AVAILABLE_WITH_ADDR5").append("=?,"); }
                if(obj.lchistDraftsAt1IsModifiedS2j()) {  _sql.append("LCHIST_DRAFTS_AT1").append("=?,"); }
                if(obj.lchistDraftsAt2IsModifiedS2j()) {  _sql.append("LCHIST_DRAFTS_AT2").append("=?,"); }
                if(obj.lchistDraftsAt3IsModifiedS2j()) {  _sql.append("LCHIST_DRAFTS_AT3").append("=?,"); }
                if(obj.lchistDraweeReqIsModifiedS2j()) {  _sql.append("LCHIST_DRAWEE_REQ").append("=?,"); }
                if(obj.lchistDraweeTypeIsModifiedS2j()) {  _sql.append("LCHIST_DRAWEE_TYPE").append("=?,"); }
                if(obj.lchistDraweeBrnCodeIsModifiedS2j()) {  _sql.append("LCHIST_DRAWEE_BRN_CODE").append("=?,"); }
                if(obj.lchistDraweeBicCodeIsModifiedS2j()) {  _sql.append("LCHIST_DRAWEE_BIC_CODE").append("=?,"); }
                if(obj.lchistDraweeRoutidIsModifiedS2j()) {  _sql.append("LCHIST_DRAWEE_ROUTID").append("=?,"); }
                if(obj.lchistDraweeBnkCodeIsModifiedS2j()) {  _sql.append("LCHIST_DRAWEE_BNK_CODE").append("=?,"); }
                if(obj.lchistDraweeAddr1IsModifiedS2j()) {  _sql.append("LCHIST_DRAWEE_ADDR1").append("=?,"); }
                if(obj.lchistDraweeAddr2IsModifiedS2j()) {  _sql.append("LCHIST_DRAWEE_ADDR2").append("=?,"); }
                if(obj.lchistDraweeAddr3IsModifiedS2j()) {  _sql.append("LCHIST_DRAWEE_ADDR3").append("=?,"); }
                if(obj.lchistDraweeAddr4IsModifiedS2j()) {  _sql.append("LCHIST_DRAWEE_ADDR4").append("=?,"); }
                if(obj.lchistDraweeAddr5IsModifiedS2j()) {  _sql.append("LCHIST_DRAWEE_ADDR5").append("=?,"); }
                if(obj.lchistMixedPayDetails1IsModifiedS2j()) {  _sql.append("LCHIST_MIXED_PAY_DETAILS1").append("=?,"); }
                if(obj.lchistMixedPayDetails2IsModifiedS2j()) {  _sql.append("LCHIST_MIXED_PAY_DETAILS2").append("=?,"); }
                if(obj.lchistMixedPayDetails3IsModifiedS2j()) {  _sql.append("LCHIST_MIXED_PAY_DETAILS3").append("=?,"); }
                if(obj.lchistMixedPayDetails4IsModifiedS2j()) {  _sql.append("LCHIST_MIXED_PAY_DETAILS4").append("=?,"); }
                if(obj.lchistDeferredPayDetails1IsModifiedS2j()) {  _sql.append("LCHIST_DEFERRED_PAY_DETAILS1").append("=?,"); }
                if(obj.lchistDeferredPayDetails2IsModifiedS2j()) {  _sql.append("LCHIST_DEFERRED_PAY_DETAILS2").append("=?,"); }
                if(obj.lchistDeferredPayDetails3IsModifiedS2j()) {  _sql.append("LCHIST_DEFERRED_PAY_DETAILS3").append("=?,"); }
                if(obj.lchistDeferredPayDetails4IsModifiedS2j()) {  _sql.append("LCHIST_DEFERRED_PAY_DETAILS4").append("=?,"); }
                if(obj.lchistPartialShipmentsIsModifiedS2j()) {  _sql.append("LCHIST_PARTIAL_SHIPMENTS").append("=?,"); }
                if(obj.lchistTranshipmentIsModifiedS2j()) {  _sql.append("LCHIST_TRANSHIPMENT").append("=?,"); }
                if(obj.lchistPlaceInChargeIsModifiedS2j()) {  _sql.append("LCHIST_PLACE_IN_CHARGE").append("=?,"); }
                if(obj.lchistPortOfLoadingIsModifiedS2j()) {  _sql.append("LCHIST_PORT_OF_LOADING").append("=?,"); }
                if(obj.lchistPortOfDischargeIsModifiedS2j()) {  _sql.append("LCHIST_PORT_OF_DISCHARGE").append("=?,"); }
                if(obj.lchistPlaceOfFinalDestIsModifiedS2j()) {  _sql.append("LCHIST_PLACE_OF_FINAL_DEST").append("=?,"); }
                if(obj.lchistDescGoodsSer1IsModifiedS2j()) {  _sql.append("LCHIST_DESC_GOODS_SER1").append("=?,"); }
                if(obj.lchistDescGoodsSer2IsModifiedS2j()) {  _sql.append("LCHIST_DESC_GOODS_SER2").append("=?,"); }
                if(obj.lchistDescGoodsSer3IsModifiedS2j()) {  _sql.append("LCHIST_DESC_GOODS_SER3").append("=?,"); }
                if(obj.lchistDocReq1IsModifiedS2j()) {  _sql.append("LCHIST_DOC_REQ1").append("=?,"); }
                if(obj.lchistDocReq2IsModifiedS2j()) {  _sql.append("LCHIST_DOC_REQ2").append("=?,"); }
                if(obj.lchistDocReq3IsModifiedS2j()) {  _sql.append("LCHIST_DOC_REQ3").append("=?,"); }
                if(obj.lchistAddCondition1IsModifiedS2j()) {  _sql.append("LCHIST_ADD_CONDITION1").append("=?,"); }
                if(obj.lchistAddCondition2IsModifiedS2j()) {  _sql.append("LCHIST_ADD_CONDITION2").append("=?,"); }
                if(obj.lchistAddCondition3IsModifiedS2j()) {  _sql.append("LCHIST_ADD_CONDITION3").append("=?,"); }
                if(obj.lchistCharges1IsModifiedS2j()) {  _sql.append("LCHIST_CHARGES1").append("=?,"); }
                if(obj.lchistCharges2IsModifiedS2j()) {  _sql.append("LCHIST_CHARGES2").append("=?,"); }
                if(obj.lchistCharges3IsModifiedS2j()) {  _sql.append("LCHIST_CHARGES3").append("=?,"); }
                if(obj.lchistCharges4IsModifiedS2j()) {  _sql.append("LCHIST_CHARGES4").append("=?,"); }
                if(obj.lchistCharges5IsModifiedS2j()) {  _sql.append("LCHIST_CHARGES5").append("=?,"); }
                if(obj.lchistCharges6IsModifiedS2j()) {  _sql.append("LCHIST_CHARGES6").append("=?,"); }
                if(obj.lchistPerPresentationDayIsModifiedS2j()) {  _sql.append("LCHIST_PER_PRESENTATION_DAY").append("=?,"); }
                if(obj.lchistConfirmationInstIsModifiedS2j()) {  _sql.append("LCHIST_CONFIRMATION_INST").append("=?,"); }
                if(obj.lchistReimbReqIsModifiedS2j()) {  _sql.append("LCHIST_REIMB_REQ").append("=?,"); }
                if(obj.lchistReimbTypeIsModifiedS2j()) {  _sql.append("LCHIST_REIMB_TYPE").append("=?,"); }
                if(obj.lchistReimbBrnCodeIsModifiedS2j()) {  _sql.append("LCHIST_REIMB_BRN_CODE").append("=?,"); }
                if(obj.lchistReimbBicCodeIsModifiedS2j()) {  _sql.append("LCHIST_REIMB_BIC_CODE").append("=?,"); }
                if(obj.lchistReimbRoutidIsModifiedS2j()) {  _sql.append("LCHIST_REIMB_ROUTID").append("=?,"); }
                if(obj.lchistReimbBnkCodeIsModifiedS2j()) {  _sql.append("LCHIST_REIMB_BNK_CODE").append("=?,"); }
                if(obj.lchistReimbAddr1IsModifiedS2j()) {  _sql.append("LCHIST_REIMB_ADDR1").append("=?,"); }
                if(obj.lchistReimbAddr2IsModifiedS2j()) {  _sql.append("LCHIST_REIMB_ADDR2").append("=?,"); }
                if(obj.lchistReimbAddr3IsModifiedS2j()) {  _sql.append("LCHIST_REIMB_ADDR3").append("=?,"); }
                if(obj.lchistReimbAddr4IsModifiedS2j()) {  _sql.append("LCHIST_REIMB_ADDR4").append("=?,"); }
                if(obj.lchistReimbAddr5IsModifiedS2j()) {  _sql.append("LCHIST_REIMB_ADDR5").append("=?,"); }
                if(obj.lchistInstPaying1IsModifiedS2j()) {  _sql.append("LCHIST_INST_PAYING1").append("=?,"); }
                if(obj.lchistInstPaying2IsModifiedS2j()) {  _sql.append("LCHIST_INST_PAYING2").append("=?,"); }
                if(obj.lchistInstPaying3IsModifiedS2j()) {  _sql.append("LCHIST_INST_PAYING3").append("=?,"); }
                if(obj.lchistInstPaying4IsModifiedS2j()) {  _sql.append("LCHIST_INST_PAYING4").append("=?,"); }
                if(obj.lchistInstPaying5IsModifiedS2j()) {  _sql.append("LCHIST_INST_PAYING5").append("=?,"); }
                if(obj.lchistInstPaying6IsModifiedS2j()) {  _sql.append("LCHIST_INST_PAYING6").append("=?,"); }
                if(obj.lchistInstPaying7IsModifiedS2j()) {  _sql.append("LCHIST_INST_PAYING7").append("=?,"); }
                if(obj.lchistInstPaying8IsModifiedS2j()) {  _sql.append("LCHIST_INST_PAYING8").append("=?,"); }
                if(obj.lchistInstPaying9IsModifiedS2j()) {  _sql.append("LCHIST_INST_PAYING9").append("=?,"); }
                if(obj.lchistInstPaying10IsModifiedS2j()) {  _sql.append("LCHIST_INST_PAYING10").append("=?,"); }
                if(obj.lchistInstPaying11IsModifiedS2j()) {  _sql.append("LCHIST_INST_PAYING11").append("=?,"); }
                if(obj.lchistInstPaying12IsModifiedS2j()) {  _sql.append("LCHIST_INST_PAYING12").append("=?,"); }
                if(obj.lchistSecondAdvReqIsModifiedS2j()) {  _sql.append("LCHIST_SECOND_ADV_REQ").append("=?,"); }
                if(obj.lchistSecondAdvTypeIsModifiedS2j()) {  _sql.append("LCHIST_SECOND_ADV_TYPE").append("=?,"); }
                if(obj.lchistSecondAdvBrnCodeIsModifiedS2j()) {  _sql.append("LCHIST_SECOND_ADV_BRN_CODE").append("=?,"); }
                if(obj.lchistSecondAdvBicCodeIsModifiedS2j()) {  _sql.append("LCHIST_SECOND_ADV_BIC_CODE").append("=?,"); }
                if(obj.lchistSecondAdvRoutidIsModifiedS2j()) {  _sql.append("LCHIST_SECOND_ADV_ROUTID").append("=?,"); }
                if(obj.lchistSecondAdvBnkCodeIsModifiedS2j()) {  _sql.append("LCHIST_SECOND_ADV_BNK_CODE").append("=?,"); }
                if(obj.lchistSecondAdvAddr1IsModifiedS2j()) {  _sql.append("LCHIST_SECOND_ADV_ADDR1").append("=?,"); }
                if(obj.lchistSecondAdvAddr2IsModifiedS2j()) {  _sql.append("LCHIST_SECOND_ADV_ADDR2").append("=?,"); }
                if(obj.lchistSecondAdvAddr3IsModifiedS2j()) {  _sql.append("LCHIST_SECOND_ADV_ADDR3").append("=?,"); }
                if(obj.lchistSecondAdvAddr4IsModifiedS2j()) {  _sql.append("LCHIST_SECOND_ADV_ADDR4").append("=?,"); }
                if(obj.lchistSecondAdvAddr5IsModifiedS2j()) {  _sql.append("LCHIST_SECOND_ADV_ADDR5").append("=?,"); }
                if(obj.lchistSndrRecInfo1IsModifiedS2j()) {  _sql.append("LCHIST_SNDR_REC_INFO1").append("=?,"); }
                if(obj.lchistSndrRecInfo2IsModifiedS2j()) {  _sql.append("LCHIST_SNDR_REC_INFO2").append("=?,"); }
                if(obj.lchistSndrRecInfo3IsModifiedS2j()) {  _sql.append("LCHIST_SNDR_REC_INFO3").append("=?,"); }
                if(obj.lchistSndrRecInfo4IsModifiedS2j()) {  _sql.append("LCHIST_SNDR_REC_INFO4").append("=?,"); }
                if(obj.lchistSndrRecInfo5IsModifiedS2j()) {  _sql.append("LCHIST_SNDR_REC_INFO5").append("=?,"); }
                if(obj.lchistSndrRecInfo6IsModifiedS2j()) {  _sql.append("LCHIST_SNDR_REC_INFO6").append("=?,"); }
                if(obj.lchistApplicantCntryCodeIsModifiedS2j()) {  _sql.append("LCHIST_APPLICANT_CNTRY_CODE").append("=?,"); }
                if(obj.lchistAvailableWithCntryIsModifiedS2j()) {  _sql.append("LCHIST_AVAILABLE_WITH_CNTRY").append("=?,"); }
                if(obj.lchistAvailableWithCodetypIsModifiedS2j()) {  _sql.append("LCHIST_AVAILABLE_WITH_CODETYP").append("=?,"); }
                if(obj.lchistDraweeCntryCodeIsModifiedS2j()) {  _sql.append("LCHIST_DRAWEE_CNTRY_CODE").append("=?,"); }
                if(obj.lchistConfirmInstTypeIsModifiedS2j()) {  _sql.append("LCHIST_CONFIRM_INST_TYPE").append("=?,"); }
                if(obj.lchistReimbCntryCodeIsModifiedS2j()) {  _sql.append("LCHIST_REIMB_CNTRY_CODE").append("=?,"); }
                if(obj.lchistSecondAdvCntrycodeIsModifiedS2j()) {  _sql.append("LCHIST_SECOND_ADV_CNTRYCODE").append("=?,"); }
                if(obj.lchistShipmentPeriod1IsModifiedS2j()) {  _sql.append("LCHIST_SHIPMENT_PERIOD1").append("=?,"); }
                if(obj.lchistShipmentPeriod2IsModifiedS2j()) {  _sql.append("LCHIST_SHIPMENT_PERIOD2").append("=?,"); }
                if(obj.lchistShipmentPeriod3IsModifiedS2j()) {  _sql.append("LCHIST_SHIPMENT_PERIOD3").append("=?,"); }
                if(obj.lchistShipmentPeriod4IsModifiedS2j()) {  _sql.append("LCHIST_SHIPMENT_PERIOD4").append("=?,"); }
                if(obj.lchistShipmentPeriod5IsModifiedS2j()) {  _sql.append("LCHIST_SHIPMENT_PERIOD5").append("=?,"); }
                if(obj.lchistShipmentPeriod6IsModifiedS2j()) {  _sql.append("LCHIST_SHIPMENT_PERIOD6").append("=?,"); }
                if(obj.lchistPerPresntRemarksIsModifiedS2j()) {  _sql.append("LCHIST_PER_PRESNT_REMARKS").append("=?,"); }
                if(obj.lchistRecBicCodeIsModifiedS2j()) {  _sql.append("LCHIST_REC_BIC_CODE").append("=?,"); }
                if(obj.lchistCfmReimbTypeIsModifiedS2j()) {  _sql.append("LCHIST_CFM_REIMB_TYPE").append("=?,"); }
                if(obj.lchistCfmReimbBrnCodeIsModifiedS2j()) {  _sql.append("LCHIST_CFM_REIMB_BRN_CODE").append("=?,"); }
                if(obj.lchistCfmReimbBicCodeIsModifiedS2j()) {  _sql.append("LCHIST_CFM_REIMB_BIC_CODE").append("=?,"); }
                if(obj.lchistCfmReimbRoutidIsModifiedS2j()) {  _sql.append("LCHIST_CFM_REIMB_ROUTID").append("=?,"); }
                if(obj.lchistCfmReimbBnkCodeIsModifiedS2j()) {  _sql.append("LCHIST_CFM_REIMB_BNK_CODE").append("=?,"); }
                if(obj.lchistCfmReimbAddr1IsModifiedS2j()) {  _sql.append("LCHIST_CFM_REIMB_ADDR1").append("=?,"); }
                if(obj.lchistCfmReimbAddr2IsModifiedS2j()) {  _sql.append("LCHIST_CFM_REIMB_ADDR2").append("=?,"); }
                if(obj.lchistCfmReimbAddr3IsModifiedS2j()) {  _sql.append("LCHIST_CFM_REIMB_ADDR3").append("=?,"); }
                if(obj.lchistCfmReimbAddr4IsModifiedS2j()) {  _sql.append("LCHIST_CFM_REIMB_ADDR4").append("=?,"); }
                if(obj.lchistCfmReimbAddr5IsModifiedS2j()) {  _sql.append("LCHIST_CFM_REIMB_ADDR5").append("=?,"); }
                if(obj.lchistCfmReimbCntryCodeIsModifiedS2j()) {  _sql.append("LCHIST_CFM_REIMB_CNTRY_CODE").append("=?,"); }
                _sql.setLength(_sql.length() - 1);
                _sql.append(" WHERE ");
                _sql.append("LC_DETAILS_HIST.LCHIST_BRN_CODE=? and LC_DETAILS_HIST.LCHIST_LC_HISTDATE=? and LC_DETAILS_HIST.LCHIST_LC_HISTSL=? and LC_DETAILS_HIST.LCHIST_LC_SL=? and LC_DETAILS_HIST.LCHIST_LC_TYPE=? and LC_DETAILS_HIST.LCHIST_LC_YEAR=?");
                _pstmt = _conn.prepareStatement(_sql.toString());
                int _dirtyCount = 0;
                if(obj.lchistBrnCodeIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLchistBrnCode()); } 
                if(obj.lchistLcTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistLcType()); } 
                if(obj.lchistLcYearIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLchistLcYear()); } 
                if(obj.lchistLcSlIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLchistLcSl()); } 
                if(obj.lchistLcHistslIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLchistLcHistsl()); } 
                if(obj.lchistLcHistdateIsModifiedS2j()) { if (obj.getLchistLcHistdate() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getLchistLcHistdate().getTime()));} } 
                if(obj.lchistFormOfDocCreditIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLchistFormOfDocCredit()); } 
                if(obj.lchistReferenceToPreadviceIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistReferenceToPreadvice()); } 
                if(obj.lchistApplicableRulesIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLchistApplicableRules()); } 
                if(obj.lchistApplicantReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLchistApplicantReq())); } 
                if(obj.lchistApplicantTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLchistApplicantType())); } 
                if(obj.lchistApplicantBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistApplicantBrnCode()); } 
                if(obj.lchistApplicantBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistApplicantBicCode()); } 
                if(obj.lchistApplicantRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistApplicantRoutid()); } 
                if(obj.lchistApplicantBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistApplicantBnkCode()); } 
                if(obj.lchistApplicantAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistApplicantAddr1()); } 
                if(obj.lchistApplicantAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistApplicantAddr2()); } 
                if(obj.lchistApplicantAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistApplicantAddr3()); } 
                if(obj.lchistApplicantAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistApplicantAddr4()); } 
                if(obj.lchistApplicantAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistApplicantAddr5()); } 
                if(obj.lchistAvailableWithTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLchistAvailableWithType())); } 
                if(obj.lchistAvailableWithBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistAvailableWithBrnCode()); } 
                if(obj.lchistAvailableWithCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistAvailableWithCode()); } 
                if(obj.lchistAvailableWithRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistAvailableWithRoutid()); } 
                if(obj.lchistAvailableWithBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistAvailableWithBnkCode()); } 
                if(obj.lchistAvailableWithAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistAvailableWithAddr1()); } 
                if(obj.lchistAvailableWithAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistAvailableWithAddr2()); } 
                if(obj.lchistAvailableWithAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistAvailableWithAddr3()); } 
                if(obj.lchistAvailableWithAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistAvailableWithAddr4()); } 
                if(obj.lchistAvailableWithAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistAvailableWithAddr5()); } 
                if(obj.lchistDraftsAt1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistDraftsAt1()); } 
                if(obj.lchistDraftsAt2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistDraftsAt2()); } 
                if(obj.lchistDraftsAt3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistDraftsAt3()); } 
                if(obj.lchistDraweeReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLchistDraweeReq())); } 
                if(obj.lchistDraweeTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLchistDraweeType())); } 
                if(obj.lchistDraweeBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistDraweeBrnCode()); } 
                if(obj.lchistDraweeBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistDraweeBicCode()); } 
                if(obj.lchistDraweeRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistDraweeRoutid()); } 
                if(obj.lchistDraweeBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistDraweeBnkCode()); } 
                if(obj.lchistDraweeAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistDraweeAddr1()); } 
                if(obj.lchistDraweeAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistDraweeAddr2()); } 
                if(obj.lchistDraweeAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistDraweeAddr3()); } 
                if(obj.lchistDraweeAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistDraweeAddr4()); } 
                if(obj.lchistDraweeAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistDraweeAddr5()); } 
                if(obj.lchistMixedPayDetails1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistMixedPayDetails1()); } 
                if(obj.lchistMixedPayDetails2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistMixedPayDetails2()); } 
                if(obj.lchistMixedPayDetails3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistMixedPayDetails3()); } 
                if(obj.lchistMixedPayDetails4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistMixedPayDetails4()); } 
                if(obj.lchistDeferredPayDetails1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistDeferredPayDetails1()); } 
                if(obj.lchistDeferredPayDetails2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistDeferredPayDetails2()); } 
                if(obj.lchistDeferredPayDetails3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistDeferredPayDetails3()); } 
                if(obj.lchistDeferredPayDetails4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistDeferredPayDetails4()); } 
                if(obj.lchistPartialShipmentsIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLchistPartialShipments()); } 
                if(obj.lchistTranshipmentIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLchistTranshipment()); } 
                if(obj.lchistPlaceInChargeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistPlaceInCharge()); } 
                if(obj.lchistPortOfLoadingIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistPortOfLoading()); } 
                if(obj.lchistPortOfDischargeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistPortOfDischarge()); } 
                if(obj.lchistPlaceOfFinalDestIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistPlaceOfFinalDest()); } 
                if(obj.lchistDescGoodsSer1IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getLchistDescGoodsSer1()); } 
                if(obj.lchistDescGoodsSer2IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getLchistDescGoodsSer2()); } 
                if(obj.lchistDescGoodsSer3IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getLchistDescGoodsSer3()); } 
                if(obj.lchistDocReq1IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getLchistDocReq1()); } 
                if(obj.lchistDocReq2IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getLchistDocReq2()); } 
                if(obj.lchistDocReq3IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getLchistDocReq3()); } 
                if(obj.lchistAddCondition1IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getLchistAddCondition1()); } 
                if(obj.lchistAddCondition2IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getLchistAddCondition2()); } 
                if(obj.lchistAddCondition3IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getLchistAddCondition3()); } 
                if(obj.lchistCharges1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistCharges1()); } 
                if(obj.lchistCharges2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistCharges2()); } 
                if(obj.lchistCharges3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistCharges3()); } 
                if(obj.lchistCharges4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistCharges4()); } 
                if(obj.lchistCharges5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistCharges5()); } 
                if(obj.lchistCharges6IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistCharges6()); } 
                if(obj.lchistPerPresentationDayIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLchistPerPresentationDay()); } 
                if(obj.lchistConfirmationInstIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLchistConfirmationInst()); } 
                if(obj.lchistReimbReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLchistReimbReq())); } 
                if(obj.lchistReimbTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLchistReimbType())); } 
                if(obj.lchistReimbBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistReimbBrnCode()); } 
                if(obj.lchistReimbBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistReimbBicCode()); } 
                if(obj.lchistReimbRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistReimbRoutid()); } 
                if(obj.lchistReimbBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistReimbBnkCode()); } 
                if(obj.lchistReimbAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistReimbAddr1()); } 
                if(obj.lchistReimbAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistReimbAddr2()); } 
                if(obj.lchistReimbAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistReimbAddr3()); } 
                if(obj.lchistReimbAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistReimbAddr4()); } 
                if(obj.lchistReimbAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistReimbAddr5()); } 
                if(obj.lchistInstPaying1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistInstPaying1()); } 
                if(obj.lchistInstPaying2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistInstPaying2()); } 
                if(obj.lchistInstPaying3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistInstPaying3()); } 
                if(obj.lchistInstPaying4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistInstPaying4()); } 
                if(obj.lchistInstPaying5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistInstPaying5()); } 
                if(obj.lchistInstPaying6IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistInstPaying6()); } 
                if(obj.lchistInstPaying7IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistInstPaying7()); } 
                if(obj.lchistInstPaying8IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistInstPaying8()); } 
                if(obj.lchistInstPaying9IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistInstPaying9()); } 
                if(obj.lchistInstPaying10IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistInstPaying10()); } 
                if(obj.lchistInstPaying11IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistInstPaying11()); } 
                if(obj.lchistInstPaying12IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistInstPaying12()); } 
                if(obj.lchistSecondAdvReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLchistSecondAdvReq())); } 
                if(obj.lchistSecondAdvTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLchistSecondAdvType())); } 
                if(obj.lchistSecondAdvBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistSecondAdvBrnCode()); } 
                if(obj.lchistSecondAdvBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistSecondAdvBicCode()); } 
                if(obj.lchistSecondAdvRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistSecondAdvRoutid()); } 
                if(obj.lchistSecondAdvBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistSecondAdvBnkCode()); } 
                if(obj.lchistSecondAdvAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistSecondAdvAddr1()); } 
                if(obj.lchistSecondAdvAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistSecondAdvAddr2()); } 
                if(obj.lchistSecondAdvAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistSecondAdvAddr3()); } 
                if(obj.lchistSecondAdvAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistSecondAdvAddr4()); } 
                if(obj.lchistSecondAdvAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistSecondAdvAddr5()); } 
                if(obj.lchistSndrRecInfo1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistSndrRecInfo1()); } 
                if(obj.lchistSndrRecInfo2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistSndrRecInfo2()); } 
                if(obj.lchistSndrRecInfo3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistSndrRecInfo3()); } 
                if(obj.lchistSndrRecInfo4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistSndrRecInfo4()); } 
                if(obj.lchistSndrRecInfo5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistSndrRecInfo5()); } 
                if(obj.lchistSndrRecInfo6IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistSndrRecInfo6()); } 
                if(obj.lchistApplicantCntryCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistApplicantCntryCode()); } 
                if(obj.lchistAvailableWithCntryIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistAvailableWithCntry()); } 
                if(obj.lchistAvailableWithCodetypIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLchistAvailableWithCodetyp()); } 
                if(obj.lchistDraweeCntryCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistDraweeCntryCode()); } 
                if(obj.lchistConfirmInstTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLchistConfirmInstType())); } 
                if(obj.lchistReimbCntryCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistReimbCntryCode()); } 
                if(obj.lchistSecondAdvCntrycodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistSecondAdvCntrycode()); } 
                if(obj.lchistShipmentPeriod1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistShipmentPeriod1()); } 
                if(obj.lchistShipmentPeriod2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistShipmentPeriod2()); } 
                if(obj.lchistShipmentPeriod3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistShipmentPeriod3()); } 
                if(obj.lchistShipmentPeriod4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistShipmentPeriod4()); } 
                if(obj.lchistShipmentPeriod5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistShipmentPeriod5()); } 
                if(obj.lchistShipmentPeriod6IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistShipmentPeriod6()); } 
                if(obj.lchistPerPresntRemarksIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistPerPresntRemarks()); } 
                if(obj.lchistRecBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistRecBicCode()); } 
                if(obj.lchistCfmReimbTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLchistCfmReimbType())); } 
                if(obj.lchistCfmReimbBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistCfmReimbBrnCode()); } 
                if(obj.lchistCfmReimbBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistCfmReimbBicCode()); } 
                if(obj.lchistCfmReimbRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistCfmReimbRoutid()); } 
                if(obj.lchistCfmReimbBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistCfmReimbBnkCode()); } 
                if(obj.lchistCfmReimbAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistCfmReimbAddr1()); } 
                if(obj.lchistCfmReimbAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistCfmReimbAddr2()); } 
                if(obj.lchistCfmReimbAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistCfmReimbAddr3()); } 
                if(obj.lchistCfmReimbAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistCfmReimbAddr4()); } 
                if(obj.lchistCfmReimbAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistCfmReimbAddr5()); } 
                if(obj.lchistCfmReimbCntryCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLchistCfmReimbCntryCode()); } 
                _pstmt.setDouble(++_dirtyCount, obj.getLchistBrnCode());
                if (obj.getLchistLcHistdate() == null) {_pstmt.setTimestamp(++_dirtyCount, null);} else {_pstmt.setTimestamp(++_dirtyCount, new java.sql.Timestamp(obj.getLchistLcHistdate().getTime()));}
                _pstmt.setDouble(++_dirtyCount, obj.getLchistLcHistsl());
                _pstmt.setDouble(++_dirtyCount, obj.getLchistLcSl());
                _pstmt.setString(++_dirtyCount, obj.getLchistLcType());
                _pstmt.setDouble(++_dirtyCount, obj.getLchistLcYear());
                _pstmt.executeUpdate();
                obj.resetIsModifiedS2J();
            }
            _pstmt.close();
        }
        catch(SQLException e) {
            if(_pstmt!=null) try { _pstmt.close();} catch(Exception e2) {}
            throw e;
        }
    }

    private LcDetailsHist decodeRow(ResultSet rs) throws SQLException {
        LcDetailsHist obj = new LcDetailsHist();
        obj.setLchistBrnCode(rs.getInt(1));
        obj.setLchistLcType(rs.getString(2));
        obj.setLchistLcYear(rs.getInt(3));
        obj.setLchistLcSl(rs.getInt(4));
        obj.setLchistLcHistsl(rs.getLong(5));
        obj.setLchistLcHistdate(rs.getDate(6));
        obj.setLchistFormOfDocCredit(rs.getInt(7));
        obj.setLchistReferenceToPreadvice(rs.getString(8));
        obj.setLchistApplicableRules(rs.getInt(9));
        obj.setLchistApplicantReq(stringToChar(rs.getString(10)));
        obj.setLchistApplicantType(stringToChar(rs.getString(11)));
        obj.setLchistApplicantBrnCode(rs.getString(12));
        obj.setLchistApplicantBicCode(rs.getString(13));
        obj.setLchistApplicantRoutid(rs.getString(14));
        obj.setLchistApplicantBnkCode(rs.getString(15));
        obj.setLchistApplicantAddr1(rs.getString(16));
        obj.setLchistApplicantAddr2(rs.getString(17));
        obj.setLchistApplicantAddr3(rs.getString(18));
        obj.setLchistApplicantAddr4(rs.getString(19));
        obj.setLchistApplicantAddr5(rs.getString(20));
        obj.setLchistAvailableWithType(stringToChar(rs.getString(21)));
        obj.setLchistAvailableWithBrnCode(rs.getString(22));
        obj.setLchistAvailableWithCode(rs.getString(23));
        obj.setLchistAvailableWithRoutid(rs.getString(24));
        obj.setLchistAvailableWithBnkCode(rs.getString(25));
        obj.setLchistAvailableWithAddr1(rs.getString(26));
        obj.setLchistAvailableWithAddr2(rs.getString(27));
        obj.setLchistAvailableWithAddr3(rs.getString(28));
        obj.setLchistAvailableWithAddr4(rs.getString(29));
        obj.setLchistAvailableWithAddr5(rs.getString(30));
        obj.setLchistDraftsAt1(rs.getString(31));
        obj.setLchistDraftsAt2(rs.getString(32));
        obj.setLchistDraftsAt3(rs.getString(33));
        obj.setLchistDraweeReq(stringToChar(rs.getString(34)));
        obj.setLchistDraweeType(stringToChar(rs.getString(35)));
        obj.setLchistDraweeBrnCode(rs.getString(36));
        obj.setLchistDraweeBicCode(rs.getString(37));
        obj.setLchistDraweeRoutid(rs.getString(38));
        obj.setLchistDraweeBnkCode(rs.getString(39));
        obj.setLchistDraweeAddr1(rs.getString(40));
        obj.setLchistDraweeAddr2(rs.getString(41));
        obj.setLchistDraweeAddr3(rs.getString(42));
        obj.setLchistDraweeAddr4(rs.getString(43));
        obj.setLchistDraweeAddr5(rs.getString(44));
        obj.setLchistMixedPayDetails1(rs.getString(45));
        obj.setLchistMixedPayDetails2(rs.getString(46));
        obj.setLchistMixedPayDetails3(rs.getString(47));
        obj.setLchistMixedPayDetails4(rs.getString(48));
        obj.setLchistDeferredPayDetails1(rs.getString(49));
        obj.setLchistDeferredPayDetails2(rs.getString(50));
        obj.setLchistDeferredPayDetails3(rs.getString(51));
        obj.setLchistDeferredPayDetails4(rs.getString(52));
        obj.setLchistPartialShipments(rs.getInt(53));
        obj.setLchistTranshipment(rs.getInt(54));
        obj.setLchistPlaceInCharge(rs.getString(55));
        obj.setLchistPortOfLoading(rs.getString(56));
        obj.setLchistPortOfDischarge(rs.getString(57));
        obj.setLchistPlaceOfFinalDest(rs.getString(58));
        obj.setLchistDescGoodsSer1(rs.getObject(59));
        obj.setLchistDescGoodsSer2(rs.getObject(60));
        obj.setLchistDescGoodsSer3(rs.getObject(61));
        obj.setLchistDocReq1(rs.getObject(62));
        obj.setLchistDocReq2(rs.getObject(63));
        obj.setLchistDocReq3(rs.getObject(64));
        obj.setLchistAddCondition1(rs.getObject(65));
        obj.setLchistAddCondition2(rs.getObject(66));
        obj.setLchistAddCondition3(rs.getObject(67));
        obj.setLchistCharges1(rs.getString(68));
        obj.setLchistCharges2(rs.getString(69));
        obj.setLchistCharges3(rs.getString(70));
        obj.setLchistCharges4(rs.getString(71));
        obj.setLchistCharges5(rs.getString(72));
        obj.setLchistCharges6(rs.getString(73));
        obj.setLchistPerPresentationDay(rs.getInt(74));
        obj.setLchistConfirmationInst(rs.getInt(75));
        obj.setLchistReimbReq(stringToChar(rs.getString(76)));
        obj.setLchistReimbType(stringToChar(rs.getString(77)));
        obj.setLchistReimbBrnCode(rs.getString(78));
        obj.setLchistReimbBicCode(rs.getString(79));
        obj.setLchistReimbRoutid(rs.getString(80));
        obj.setLchistReimbBnkCode(rs.getString(81));
        obj.setLchistReimbAddr1(rs.getString(82));
        obj.setLchistReimbAddr2(rs.getString(83));
        obj.setLchistReimbAddr3(rs.getString(84));
        obj.setLchistReimbAddr4(rs.getString(85));
        obj.setLchistReimbAddr5(rs.getString(86));
        obj.setLchistInstPaying1(rs.getString(87));
        obj.setLchistInstPaying2(rs.getString(88));
        obj.setLchistInstPaying3(rs.getString(89));
        obj.setLchistInstPaying4(rs.getString(90));
        obj.setLchistInstPaying5(rs.getString(91));
        obj.setLchistInstPaying6(rs.getString(92));
        obj.setLchistInstPaying7(rs.getString(93));
        obj.setLchistInstPaying8(rs.getString(94));
        obj.setLchistInstPaying9(rs.getString(95));
        obj.setLchistInstPaying10(rs.getString(96));
        obj.setLchistInstPaying11(rs.getString(97));
        obj.setLchistInstPaying12(rs.getString(98));
        obj.setLchistSecondAdvReq(stringToChar(rs.getString(99)));
        obj.setLchistSecondAdvType(stringToChar(rs.getString(100)));
        obj.setLchistSecondAdvBrnCode(rs.getString(101));
        obj.setLchistSecondAdvBicCode(rs.getString(102));
        obj.setLchistSecondAdvRoutid(rs.getString(103));
        obj.setLchistSecondAdvBnkCode(rs.getString(104));
        obj.setLchistSecondAdvAddr1(rs.getString(105));
        obj.setLchistSecondAdvAddr2(rs.getString(106));
        obj.setLchistSecondAdvAddr3(rs.getString(107));
        obj.setLchistSecondAdvAddr4(rs.getString(108));
        obj.setLchistSecondAdvAddr5(rs.getString(109));
        obj.setLchistSndrRecInfo1(rs.getString(110));
        obj.setLchistSndrRecInfo2(rs.getString(111));
        obj.setLchistSndrRecInfo3(rs.getString(112));
        obj.setLchistSndrRecInfo4(rs.getString(113));
        obj.setLchistSndrRecInfo5(rs.getString(114));
        obj.setLchistSndrRecInfo6(rs.getString(115));
        obj.setLchistApplicantCntryCode(rs.getString(116));
        obj.setLchistAvailableWithCntry(rs.getString(117));
        obj.setLchistAvailableWithCodetyp(rs.getInt(118));
        obj.setLchistDraweeCntryCode(rs.getString(119));
        obj.setLchistConfirmInstType(stringToChar(rs.getString(120)));
        obj.setLchistReimbCntryCode(rs.getString(121));
        obj.setLchistSecondAdvCntrycode(rs.getString(122));
        obj.setLchistShipmentPeriod1(rs.getString(123));
        obj.setLchistShipmentPeriod2(rs.getString(124));
        obj.setLchistShipmentPeriod3(rs.getString(125));
        obj.setLchistShipmentPeriod4(rs.getString(126));
        obj.setLchistShipmentPeriod5(rs.getString(127));
        obj.setLchistShipmentPeriod6(rs.getString(128));
        obj.setLchistPerPresntRemarks(rs.getString(129));
        obj.setLchistRecBicCode(rs.getString(130));
        obj.setLchistCfmReimbType(stringToChar(rs.getString(131)));
        obj.setLchistCfmReimbBrnCode(rs.getString(132));
        obj.setLchistCfmReimbBicCode(rs.getString(133));
        obj.setLchistCfmReimbRoutid(rs.getString(134));
        obj.setLchistCfmReimbBnkCode(rs.getString(135));
        obj.setLchistCfmReimbAddr1(rs.getString(136));
        obj.setLchistCfmReimbAddr2(rs.getString(137));
        obj.setLchistCfmReimbAddr3(rs.getString(138));
        obj.setLchistCfmReimbAddr4(rs.getString(139));
        obj.setLchistCfmReimbAddr5(rs.getString(140));
        obj.setLchistCfmReimbCntryCode(rs.getString(141));
        obj.setIsNew(false);
        obj.resetIsModifiedS2J();

        return obj;
    }

    private LcDetailsHist decodeRow(ResultSet rs, int[] fieldList) throws SQLException {
        LcDetailsHist obj = new LcDetailsHist();
        int pos = 0;
        for(int i = 0; i < fieldList.length; i++) {
            switch(fieldList[i]) {
                case LCHIST_BRN_CODE: obj.setLchistBrnCode(rs.getInt(++pos));
                    break;
                case LCHIST_LC_TYPE: obj.setLchistLcType(rs.getString(++pos));
                    break;
                case LCHIST_LC_YEAR: obj.setLchistLcYear(rs.getInt(++pos));
                    break;
                case LCHIST_LC_SL: obj.setLchistLcSl(rs.getInt(++pos));
                    break;
                case LCHIST_LC_HISTSL: obj.setLchistLcHistsl(rs.getLong(++pos));
                    break;
                case LCHIST_LC_HISTDATE: obj.setLchistLcHistdate(rs.getDate(++pos));
                    break;
                case LCHIST_FORM_OF_DOC_CREDIT: obj.setLchistFormOfDocCredit(rs.getInt(++pos));
                    break;
                case LCHIST_REFERENCE_TO_PREADVICE: obj.setLchistReferenceToPreadvice(rs.getString(++pos));
                    break;
                case LCHIST_APPLICABLE_RULES: obj.setLchistApplicableRules(rs.getInt(++pos));
                    break;
                case LCHIST_APPLICANT_REQ: obj.setLchistApplicantReq(stringToChar(rs.getString(++pos)));
                    break;
                case LCHIST_APPLICANT_TYPE: obj.setLchistApplicantType(stringToChar(rs.getString(++pos)));
                    break;
                case LCHIST_APPLICANT_BRN_CODE: obj.setLchistApplicantBrnCode(rs.getString(++pos));
                    break;
                case LCHIST_APPLICANT_BIC_CODE: obj.setLchistApplicantBicCode(rs.getString(++pos));
                    break;
                case LCHIST_APPLICANT_ROUTID: obj.setLchistApplicantRoutid(rs.getString(++pos));
                    break;
                case LCHIST_APPLICANT_BNK_CODE: obj.setLchistApplicantBnkCode(rs.getString(++pos));
                    break;
                case LCHIST_APPLICANT_ADDR1: obj.setLchistApplicantAddr1(rs.getString(++pos));
                    break;
                case LCHIST_APPLICANT_ADDR2: obj.setLchistApplicantAddr2(rs.getString(++pos));
                    break;
                case LCHIST_APPLICANT_ADDR3: obj.setLchistApplicantAddr3(rs.getString(++pos));
                    break;
                case LCHIST_APPLICANT_ADDR4: obj.setLchistApplicantAddr4(rs.getString(++pos));
                    break;
                case LCHIST_APPLICANT_ADDR5: obj.setLchistApplicantAddr5(rs.getString(++pos));
                    break;
                case LCHIST_AVAILABLE_WITH_TYPE: obj.setLchistAvailableWithType(stringToChar(rs.getString(++pos)));
                    break;
                case LCHIST_AVAILABLE_WITH_BRN_CODE: obj.setLchistAvailableWithBrnCode(rs.getString(++pos));
                    break;
                case LCHIST_AVAILABLE_WITH_CODE: obj.setLchistAvailableWithCode(rs.getString(++pos));
                    break;
                case LCHIST_AVAILABLE_WITH_ROUTID: obj.setLchistAvailableWithRoutid(rs.getString(++pos));
                    break;
                case LCHIST_AVAILABLE_WITH_BNK_CODE: obj.setLchistAvailableWithBnkCode(rs.getString(++pos));
                    break;
                case LCHIST_AVAILABLE_WITH_ADDR1: obj.setLchistAvailableWithAddr1(rs.getString(++pos));
                    break;
                case LCHIST_AVAILABLE_WITH_ADDR2: obj.setLchistAvailableWithAddr2(rs.getString(++pos));
                    break;
                case LCHIST_AVAILABLE_WITH_ADDR3: obj.setLchistAvailableWithAddr3(rs.getString(++pos));
                    break;
                case LCHIST_AVAILABLE_WITH_ADDR4: obj.setLchistAvailableWithAddr4(rs.getString(++pos));
                    break;
                case LCHIST_AVAILABLE_WITH_ADDR5: obj.setLchistAvailableWithAddr5(rs.getString(++pos));
                    break;
                case LCHIST_DRAFTS_AT1: obj.setLchistDraftsAt1(rs.getString(++pos));
                    break;
                case LCHIST_DRAFTS_AT2: obj.setLchistDraftsAt2(rs.getString(++pos));
                    break;
                case LCHIST_DRAFTS_AT3: obj.setLchistDraftsAt3(rs.getString(++pos));
                    break;
                case LCHIST_DRAWEE_REQ: obj.setLchistDraweeReq(stringToChar(rs.getString(++pos)));
                    break;
                case LCHIST_DRAWEE_TYPE: obj.setLchistDraweeType(stringToChar(rs.getString(++pos)));
                    break;
                case LCHIST_DRAWEE_BRN_CODE: obj.setLchistDraweeBrnCode(rs.getString(++pos));
                    break;
                case LCHIST_DRAWEE_BIC_CODE: obj.setLchistDraweeBicCode(rs.getString(++pos));
                    break;
                case LCHIST_DRAWEE_ROUTID: obj.setLchistDraweeRoutid(rs.getString(++pos));
                    break;
                case LCHIST_DRAWEE_BNK_CODE: obj.setLchistDraweeBnkCode(rs.getString(++pos));
                    break;
                case LCHIST_DRAWEE_ADDR1: obj.setLchistDraweeAddr1(rs.getString(++pos));
                    break;
                case LCHIST_DRAWEE_ADDR2: obj.setLchistDraweeAddr2(rs.getString(++pos));
                    break;
                case LCHIST_DRAWEE_ADDR3: obj.setLchistDraweeAddr3(rs.getString(++pos));
                    break;
                case LCHIST_DRAWEE_ADDR4: obj.setLchistDraweeAddr4(rs.getString(++pos));
                    break;
                case LCHIST_DRAWEE_ADDR5: obj.setLchistDraweeAddr5(rs.getString(++pos));
                    break;
                case LCHIST_MIXED_PAY_DETAILS1: obj.setLchistMixedPayDetails1(rs.getString(++pos));
                    break;
                case LCHIST_MIXED_PAY_DETAILS2: obj.setLchistMixedPayDetails2(rs.getString(++pos));
                    break;
                case LCHIST_MIXED_PAY_DETAILS3: obj.setLchistMixedPayDetails3(rs.getString(++pos));
                    break;
                case LCHIST_MIXED_PAY_DETAILS4: obj.setLchistMixedPayDetails4(rs.getString(++pos));
                    break;
                case LCHIST_DEFERRED_PAY_DETAILS1: obj.setLchistDeferredPayDetails1(rs.getString(++pos));
                    break;
                case LCHIST_DEFERRED_PAY_DETAILS2: obj.setLchistDeferredPayDetails2(rs.getString(++pos));
                    break;
                case LCHIST_DEFERRED_PAY_DETAILS3: obj.setLchistDeferredPayDetails3(rs.getString(++pos));
                    break;
                case LCHIST_DEFERRED_PAY_DETAILS4: obj.setLchistDeferredPayDetails4(rs.getString(++pos));
                    break;
                case LCHIST_PARTIAL_SHIPMENTS: obj.setLchistPartialShipments(rs.getInt(++pos));
                    break;
                case LCHIST_TRANSHIPMENT: obj.setLchistTranshipment(rs.getInt(++pos));
                    break;
                case LCHIST_PLACE_IN_CHARGE: obj.setLchistPlaceInCharge(rs.getString(++pos));
                    break;
                case LCHIST_PORT_OF_LOADING: obj.setLchistPortOfLoading(rs.getString(++pos));
                    break;
                case LCHIST_PORT_OF_DISCHARGE: obj.setLchistPortOfDischarge(rs.getString(++pos));
                    break;
                case LCHIST_PLACE_OF_FINAL_DEST: obj.setLchistPlaceOfFinalDest(rs.getString(++pos));
                    break;
                case LCHIST_DESC_GOODS_SER1: obj.setLchistDescGoodsSer1(rs.getObject(++pos));
                    break;
                case LCHIST_DESC_GOODS_SER2: obj.setLchistDescGoodsSer2(rs.getObject(++pos));
                    break;
                case LCHIST_DESC_GOODS_SER3: obj.setLchistDescGoodsSer3(rs.getObject(++pos));
                    break;
                case LCHIST_DOC_REQ1: obj.setLchistDocReq1(rs.getObject(++pos));
                    break;
                case LCHIST_DOC_REQ2: obj.setLchistDocReq2(rs.getObject(++pos));
                    break;
                case LCHIST_DOC_REQ3: obj.setLchistDocReq3(rs.getObject(++pos));
                    break;
                case LCHIST_ADD_CONDITION1: obj.setLchistAddCondition1(rs.getObject(++pos));
                    break;
                case LCHIST_ADD_CONDITION2: obj.setLchistAddCondition2(rs.getObject(++pos));
                    break;
                case LCHIST_ADD_CONDITION3: obj.setLchistAddCondition3(rs.getObject(++pos));
                    break;
                case LCHIST_CHARGES1: obj.setLchistCharges1(rs.getString(++pos));
                    break;
                case LCHIST_CHARGES2: obj.setLchistCharges2(rs.getString(++pos));
                    break;
                case LCHIST_CHARGES3: obj.setLchistCharges3(rs.getString(++pos));
                    break;
                case LCHIST_CHARGES4: obj.setLchistCharges4(rs.getString(++pos));
                    break;
                case LCHIST_CHARGES5: obj.setLchistCharges5(rs.getString(++pos));
                    break;
                case LCHIST_CHARGES6: obj.setLchistCharges6(rs.getString(++pos));
                    break;
                case LCHIST_PER_PRESENTATION_DAY: obj.setLchistPerPresentationDay(rs.getInt(++pos));
                    break;
                case LCHIST_CONFIRMATION_INST: obj.setLchistConfirmationInst(rs.getInt(++pos));
                    break;
                case LCHIST_REIMB_REQ: obj.setLchistReimbReq(stringToChar(rs.getString(++pos)));
                    break;
                case LCHIST_REIMB_TYPE: obj.setLchistReimbType(stringToChar(rs.getString(++pos)));
                    break;
                case LCHIST_REIMB_BRN_CODE: obj.setLchistReimbBrnCode(rs.getString(++pos));
                    break;
                case LCHIST_REIMB_BIC_CODE: obj.setLchistReimbBicCode(rs.getString(++pos));
                    break;
                case LCHIST_REIMB_ROUTID: obj.setLchistReimbRoutid(rs.getString(++pos));
                    break;
                case LCHIST_REIMB_BNK_CODE: obj.setLchistReimbBnkCode(rs.getString(++pos));
                    break;
                case LCHIST_REIMB_ADDR1: obj.setLchistReimbAddr1(rs.getString(++pos));
                    break;
                case LCHIST_REIMB_ADDR2: obj.setLchistReimbAddr2(rs.getString(++pos));
                    break;
                case LCHIST_REIMB_ADDR3: obj.setLchistReimbAddr3(rs.getString(++pos));
                    break;
                case LCHIST_REIMB_ADDR4: obj.setLchistReimbAddr4(rs.getString(++pos));
                    break;
                case LCHIST_REIMB_ADDR5: obj.setLchistReimbAddr5(rs.getString(++pos));
                    break;
                case LCHIST_INST_PAYING1: obj.setLchistInstPaying1(rs.getString(++pos));
                    break;
                case LCHIST_INST_PAYING2: obj.setLchistInstPaying2(rs.getString(++pos));
                    break;
                case LCHIST_INST_PAYING3: obj.setLchistInstPaying3(rs.getString(++pos));
                    break;
                case LCHIST_INST_PAYING4: obj.setLchistInstPaying4(rs.getString(++pos));
                    break;
                case LCHIST_INST_PAYING5: obj.setLchistInstPaying5(rs.getString(++pos));
                    break;
                case LCHIST_INST_PAYING6: obj.setLchistInstPaying6(rs.getString(++pos));
                    break;
                case LCHIST_INST_PAYING7: obj.setLchistInstPaying7(rs.getString(++pos));
                    break;
                case LCHIST_INST_PAYING8: obj.setLchistInstPaying8(rs.getString(++pos));
                    break;
                case LCHIST_INST_PAYING9: obj.setLchistInstPaying9(rs.getString(++pos));
                    break;
                case LCHIST_INST_PAYING10: obj.setLchistInstPaying10(rs.getString(++pos));
                    break;
                case LCHIST_INST_PAYING11: obj.setLchistInstPaying11(rs.getString(++pos));
                    break;
                case LCHIST_INST_PAYING12: obj.setLchistInstPaying12(rs.getString(++pos));
                    break;
                case LCHIST_SECOND_ADV_REQ: obj.setLchistSecondAdvReq(stringToChar(rs.getString(++pos)));
                    break;
                case LCHIST_SECOND_ADV_TYPE: obj.setLchistSecondAdvType(stringToChar(rs.getString(++pos)));
                    break;
                case LCHIST_SECOND_ADV_BRN_CODE: obj.setLchistSecondAdvBrnCode(rs.getString(++pos));
                    break;
                case LCHIST_SECOND_ADV_BIC_CODE: obj.setLchistSecondAdvBicCode(rs.getString(++pos));
                    break;
                case LCHIST_SECOND_ADV_ROUTID: obj.setLchistSecondAdvRoutid(rs.getString(++pos));
                    break;
                case LCHIST_SECOND_ADV_BNK_CODE: obj.setLchistSecondAdvBnkCode(rs.getString(++pos));
                    break;
                case LCHIST_SECOND_ADV_ADDR1: obj.setLchistSecondAdvAddr1(rs.getString(++pos));
                    break;
                case LCHIST_SECOND_ADV_ADDR2: obj.setLchistSecondAdvAddr2(rs.getString(++pos));
                    break;
                case LCHIST_SECOND_ADV_ADDR3: obj.setLchistSecondAdvAddr3(rs.getString(++pos));
                    break;
                case LCHIST_SECOND_ADV_ADDR4: obj.setLchistSecondAdvAddr4(rs.getString(++pos));
                    break;
                case LCHIST_SECOND_ADV_ADDR5: obj.setLchistSecondAdvAddr5(rs.getString(++pos));
                    break;
                case LCHIST_SNDR_REC_INFO1: obj.setLchistSndrRecInfo1(rs.getString(++pos));
                    break;
                case LCHIST_SNDR_REC_INFO2: obj.setLchistSndrRecInfo2(rs.getString(++pos));
                    break;
                case LCHIST_SNDR_REC_INFO3: obj.setLchistSndrRecInfo3(rs.getString(++pos));
                    break;
                case LCHIST_SNDR_REC_INFO4: obj.setLchistSndrRecInfo4(rs.getString(++pos));
                    break;
                case LCHIST_SNDR_REC_INFO5: obj.setLchistSndrRecInfo5(rs.getString(++pos));
                    break;
                case LCHIST_SNDR_REC_INFO6: obj.setLchistSndrRecInfo6(rs.getString(++pos));
                    break;
                case LCHIST_APPLICANT_CNTRY_CODE: obj.setLchistApplicantCntryCode(rs.getString(++pos));
                    break;
                case LCHIST_AVAILABLE_WITH_CNTRY: obj.setLchistAvailableWithCntry(rs.getString(++pos));
                    break;
                case LCHIST_AVAILABLE_WITH_CODETYP: obj.setLchistAvailableWithCodetyp(rs.getInt(++pos));
                    break;
                case LCHIST_DRAWEE_CNTRY_CODE: obj.setLchistDraweeCntryCode(rs.getString(++pos));
                    break;
                case LCHIST_CONFIRM_INST_TYPE: obj.setLchistConfirmInstType(stringToChar(rs.getString(++pos)));
                    break;
                case LCHIST_REIMB_CNTRY_CODE: obj.setLchistReimbCntryCode(rs.getString(++pos));
                    break;
                case LCHIST_SECOND_ADV_CNTRYCODE: obj.setLchistSecondAdvCntrycode(rs.getString(++pos));
                    break;
                case LCHIST_SHIPMENT_PERIOD1: obj.setLchistShipmentPeriod1(rs.getString(++pos));
                    break;
                case LCHIST_SHIPMENT_PERIOD2: obj.setLchistShipmentPeriod2(rs.getString(++pos));
                    break;
                case LCHIST_SHIPMENT_PERIOD3: obj.setLchistShipmentPeriod3(rs.getString(++pos));
                    break;
                case LCHIST_SHIPMENT_PERIOD4: obj.setLchistShipmentPeriod4(rs.getString(++pos));
                    break;
                case LCHIST_SHIPMENT_PERIOD5: obj.setLchistShipmentPeriod5(rs.getString(++pos));
                    break;
                case LCHIST_SHIPMENT_PERIOD6: obj.setLchistShipmentPeriod6(rs.getString(++pos));
                    break;
                case LCHIST_PER_PRESNT_REMARKS: obj.setLchistPerPresntRemarks(rs.getString(++pos));
                    break;
                case LCHIST_REC_BIC_CODE: obj.setLchistRecBicCode(rs.getString(++pos));
                    break;
                case LCHIST_CFM_REIMB_TYPE: obj.setLchistCfmReimbType(stringToChar(rs.getString(++pos)));
                    break;
                case LCHIST_CFM_REIMB_BRN_CODE: obj.setLchistCfmReimbBrnCode(rs.getString(++pos));
                    break;
                case LCHIST_CFM_REIMB_BIC_CODE: obj.setLchistCfmReimbBicCode(rs.getString(++pos));
                    break;
                case LCHIST_CFM_REIMB_ROUTID: obj.setLchistCfmReimbRoutid(rs.getString(++pos));
                    break;
                case LCHIST_CFM_REIMB_BNK_CODE: obj.setLchistCfmReimbBnkCode(rs.getString(++pos));
                    break;
                case LCHIST_CFM_REIMB_ADDR1: obj.setLchistCfmReimbAddr1(rs.getString(++pos));
                    break;
                case LCHIST_CFM_REIMB_ADDR2: obj.setLchistCfmReimbAddr2(rs.getString(++pos));
                    break;
                case LCHIST_CFM_REIMB_ADDR3: obj.setLchistCfmReimbAddr3(rs.getString(++pos));
                    break;
                case LCHIST_CFM_REIMB_ADDR4: obj.setLchistCfmReimbAddr4(rs.getString(++pos));
                    break;
                case LCHIST_CFM_REIMB_ADDR5: obj.setLchistCfmReimbAddr5(rs.getString(++pos));
                    break;
                case LCHIST_CFM_REIMB_CNTRY_CODE: obj.setLchistCfmReimbCntryCode(rs.getString(++pos));
                    break;
            }
        }
        obj.setIsNew(false);
        obj.resetIsModifiedS2J();

        return obj;
    }
    public void save(LcDetailsHist obj, String tba_main_key, Timestamp tba_entry_date, long tab_dtl_sl ) throws SQLException {
            NewData_Key = "LC_DETAILS_HIST" + TableValueSep + NewDataChar + obj.getLchistBrnCode() + obj.getLchistLcType() + obj.getLchistLcYear() + obj.getLchistLcSl() + obj.getLchistLcHistsl() + obj.getLchistLcHistdate();
            DataBlock_New = obj.getLchistBrnCode() + JNDINames.splitchar + obj.getLchistLcType() + JNDINames.splitchar + obj.getLchistLcYear() + JNDINames.splitchar + obj.getLchistLcSl() + JNDINames.splitchar + obj.getLchistLcHistsl() + JNDINames.splitchar + obj.getLchistLcHistdate() + JNDINames.splitchar + obj.getLchistFormOfDocCredit() + JNDINames.splitchar + obj.getLchistReferenceToPreadvice() + JNDINames.splitchar + obj.getLchistApplicableRules() + JNDINames.splitchar + obj.getLchistApplicantReq() + JNDINames.splitchar + obj.getLchistApplicantType() + JNDINames.splitchar + obj.getLchistApplicantBrnCode() + JNDINames.splitchar + obj.getLchistApplicantBicCode() + JNDINames.splitchar + obj.getLchistApplicantRoutid() + JNDINames.splitchar + obj.getLchistApplicantBnkCode() + JNDINames.splitchar + obj.getLchistApplicantAddr1() + JNDINames.splitchar + obj.getLchistApplicantAddr2() + JNDINames.splitchar + obj.getLchistApplicantAddr3() + JNDINames.splitchar + obj.getLchistApplicantAddr4() + JNDINames.splitchar + obj.getLchistApplicantAddr5() + JNDINames.splitchar + obj.getLchistAvailableWithType() + JNDINames.splitchar + obj.getLchistAvailableWithBrnCode() + JNDINames.splitchar + obj.getLchistAvailableWithCode() + JNDINames.splitchar + obj.getLchistAvailableWithRoutid() + JNDINames.splitchar + obj.getLchistAvailableWithBnkCode() + JNDINames.splitchar + obj.getLchistAvailableWithAddr1() + JNDINames.splitchar + obj.getLchistAvailableWithAddr2() + JNDINames.splitchar + obj.getLchistAvailableWithAddr3() + JNDINames.splitchar + obj.getLchistAvailableWithAddr4() + JNDINames.splitchar + obj.getLchistAvailableWithAddr5() + JNDINames.splitchar + obj.getLchistDraftsAt1() + JNDINames.splitchar + obj.getLchistDraftsAt2() + JNDINames.splitchar + obj.getLchistDraftsAt3() + JNDINames.splitchar + obj.getLchistDraweeReq() + JNDINames.splitchar + obj.getLchistDraweeType() + JNDINames.splitchar + obj.getLchistDraweeBrnCode() + JNDINames.splitchar + obj.getLchistDraweeBicCode() + JNDINames.splitchar + obj.getLchistDraweeRoutid() + JNDINames.splitchar + obj.getLchistDraweeBnkCode() + JNDINames.splitchar + obj.getLchistDraweeAddr1() + JNDINames.splitchar + obj.getLchistDraweeAddr2() + JNDINames.splitchar + obj.getLchistDraweeAddr3() + JNDINames.splitchar + obj.getLchistDraweeAddr4() + JNDINames.splitchar + obj.getLchistDraweeAddr5() + JNDINames.splitchar + obj.getLchistMixedPayDetails1() + JNDINames.splitchar + obj.getLchistMixedPayDetails2() + JNDINames.splitchar + obj.getLchistMixedPayDetails3() + JNDINames.splitchar + obj.getLchistMixedPayDetails4() + JNDINames.splitchar + obj.getLchistDeferredPayDetails1() + JNDINames.splitchar + obj.getLchistDeferredPayDetails2() + JNDINames.splitchar + obj.getLchistDeferredPayDetails3() + JNDINames.splitchar + obj.getLchistDeferredPayDetails4() + JNDINames.splitchar + obj.getLchistPartialShipments() + JNDINames.splitchar + obj.getLchistTranshipment() + JNDINames.splitchar + obj.getLchistPlaceInCharge() + JNDINames.splitchar + obj.getLchistPortOfLoading() + JNDINames.splitchar + obj.getLchistPortOfDischarge() + JNDINames.splitchar + obj.getLchistPlaceOfFinalDest() + JNDINames.splitchar + obj.getLchistDescGoodsSer1() + JNDINames.splitchar + obj.getLchistDescGoodsSer2() + JNDINames.splitchar + obj.getLchistDescGoodsSer3() + JNDINames.splitchar + obj.getLchistDocReq1() + JNDINames.splitchar + obj.getLchistDocReq2() + JNDINames.splitchar + obj.getLchistDocReq3() + JNDINames.splitchar + obj.getLchistAddCondition1() + JNDINames.splitchar + obj.getLchistAddCondition2() + JNDINames.splitchar + obj.getLchistAddCondition3() + JNDINames.splitchar + obj.getLchistCharges1() + JNDINames.splitchar + obj.getLchistCharges2() + JNDINames.splitchar + obj.getLchistCharges3() + JNDINames.splitchar + obj.getLchistCharges4() + JNDINames.splitchar + obj.getLchistCharges5() + JNDINames.splitchar + obj.getLchistCharges6() + JNDINames.splitchar + obj.getLchistPerPresentationDay() + JNDINames.splitchar + obj.getLchistConfirmationInst() + JNDINames.splitchar + obj.getLchistReimbReq() + JNDINames.splitchar + obj.getLchistReimbType() + JNDINames.splitchar + obj.getLchistReimbBrnCode() + JNDINames.splitchar + obj.getLchistReimbBicCode() + JNDINames.splitchar + obj.getLchistReimbRoutid() + JNDINames.splitchar + obj.getLchistReimbBnkCode() + JNDINames.splitchar + obj.getLchistReimbAddr1() + JNDINames.splitchar + obj.getLchistReimbAddr2() + JNDINames.splitchar + obj.getLchistReimbAddr3() + JNDINames.splitchar + obj.getLchistReimbAddr4() + JNDINames.splitchar + obj.getLchistReimbAddr5() + JNDINames.splitchar + obj.getLchistInstPaying1() + JNDINames.splitchar + obj.getLchistInstPaying2() + JNDINames.splitchar + obj.getLchistInstPaying3() + JNDINames.splitchar + obj.getLchistInstPaying4() + JNDINames.splitchar + obj.getLchistInstPaying5() + JNDINames.splitchar + obj.getLchistInstPaying6() + JNDINames.splitchar + obj.getLchistInstPaying7() + JNDINames.splitchar + obj.getLchistInstPaying8() + JNDINames.splitchar + obj.getLchistInstPaying9() + JNDINames.splitchar + obj.getLchistInstPaying10() + JNDINames.splitchar + obj.getLchistInstPaying11() + JNDINames.splitchar + obj.getLchistInstPaying12() + JNDINames.splitchar + obj.getLchistSecondAdvReq() + JNDINames.splitchar + obj.getLchistSecondAdvType() + JNDINames.splitchar + obj.getLchistSecondAdvBrnCode() + JNDINames.splitchar + obj.getLchistSecondAdvBicCode() + JNDINames.splitchar + obj.getLchistSecondAdvRoutid() + JNDINames.splitchar + obj.getLchistSecondAdvBnkCode() + JNDINames.splitchar + obj.getLchistSecondAdvAddr1() + JNDINames.splitchar + obj.getLchistSecondAdvAddr2() + JNDINames.splitchar + obj.getLchistSecondAdvAddr3() + JNDINames.splitchar + obj.getLchistSecondAdvAddr4() + JNDINames.splitchar + obj.getLchistSecondAdvAddr5() + JNDINames.splitchar + obj.getLchistSndrRecInfo1() + JNDINames.splitchar + obj.getLchistSndrRecInfo2() + JNDINames.splitchar + obj.getLchistSndrRecInfo3() + JNDINames.splitchar + obj.getLchistSndrRecInfo4() + JNDINames.splitchar + obj.getLchistSndrRecInfo5() + JNDINames.splitchar + obj.getLchistSndrRecInfo6() + JNDINames.splitchar + obj.getLchistApplicantCntryCode() + JNDINames.splitchar + obj.getLchistAvailableWithCntry() + JNDINames.splitchar + obj.getLchistAvailableWithCodetyp() + JNDINames.splitchar + obj.getLchistDraweeCntryCode() + JNDINames.splitchar + obj.getLchistConfirmInstType() + JNDINames.splitchar + obj.getLchistReimbCntryCode() + JNDINames.splitchar + obj.getLchistSecondAdvCntrycode() + JNDINames.splitchar + obj.getLchistShipmentPeriod1() + JNDINames.splitchar + obj.getLchistShipmentPeriod2() + JNDINames.splitchar + obj.getLchistShipmentPeriod3() + JNDINames.splitchar + obj.getLchistShipmentPeriod4() + JNDINames.splitchar + obj.getLchistShipmentPeriod5() + JNDINames.splitchar + obj.getLchistShipmentPeriod6() + JNDINames.splitchar + obj.getLchistPerPresntRemarks() + JNDINames.splitchar + obj.getLchistRecBicCode() + JNDINames.splitchar + obj.getLchistCfmReimbType() + JNDINames.splitchar + obj.getLchistCfmReimbBrnCode() + JNDINames.splitchar + obj.getLchistCfmReimbBicCode() + JNDINames.splitchar + obj.getLchistCfmReimbRoutid() + JNDINames.splitchar + obj.getLchistCfmReimbBnkCode() + JNDINames.splitchar + obj.getLchistCfmReimbAddr1() + JNDINames.splitchar + obj.getLchistCfmReimbAddr2() + JNDINames.splitchar + obj.getLchistCfmReimbAddr3() + JNDINames.splitchar + obj.getLchistCfmReimbAddr4() + JNDINames.splitchar + obj.getLchistCfmReimbAddr5() + JNDINames.splitchar + obj.getLchistCfmReimbCntryCode();
                if (_Logreq == 1)
                {
                    if (obj.isNew() == false)
                    {
                        if (OldData_Key != null) this._COLLECTIONobj.put(OldData_Key , DataBlock_Old );
                        if (NewData_Key != null) this._COLLECTIONobj.put(NewData_Key , DataBlock_New );
                    }else if ((_Logaddreq == 1) && obj.isNew() == true)
                    {
                        if (NewData_Key != null) this._COLLECTIONobj.put(NewData_Key , DataBlock_New );
                    }
                }
            OldData_Key ="";
            DataBlock_Old = "";
            DataBlock_New = "";
            NewData_Key = "";
        {
    // This is for main table Updation
            save(obj);
        }
    }

}