package panacea.OLC.Update;


/******************SQL2JAVA_IMPORT_BEGIN******************/

/******************SQL2JAVA_IMPORT_END********************/


public class AmendDetails
/******************SQL2JAVA_EXTENDS_BEGIN******************/

/******************SQL2JAVA_EXTENDS_END********************/

{

/******************SQL2JAVA_CLASS_BEGIN******************/

/******************SQL2JAVA_CLASS_END********************/


    private int _amendLcBrnCode;
    private boolean __amendLcBrnCode_is_modified;
    private String _amendLcType;
    private boolean __amendLcType_is_modified;
    private int _amendLcYear;
    private boolean __amendLcYear_is_modified;
    private int _amendLcSerial;
    private boolean __amendLcSerial_is_modified;
    private int _amendLcAmdSl;
    private boolean __amendLcAmdSl_is_modified;
    private String _amendSndrRef;
    private boolean __amendSndrRef_is_modified;
    private String _amendRcvrRef;
    private boolean __amendRcvrRef_is_modified;
    private String _amendDocCrNum;
    private boolean __amendDocCrNum_is_modified;
    private char _amendIssuingBnkReq;
    private boolean __amendIssuingBnkReq_is_modified;
    private char _amendIssuingType;
    private boolean __amendIssuingType_is_modified;
    private String _amendIssuingBrnCode;
    private boolean __amendIssuingBrnCode_is_modified;
    private String _amendIssuingBicCode;
    private boolean __amendIssuingBicCode_is_modified;
    private String _amendIssuingRoutid;
    private boolean __amendIssuingRoutid_is_modified;
    private String _amendIssuingBnkCode;
    private boolean __amendIssuingBnkCode_is_modified;
    private String _amendIssuingAddr1;
    private boolean __amendIssuingAddr1_is_modified;
    private String _amendIssuingAddr2;
    private boolean __amendIssuingAddr2_is_modified;
    private String _amendIssuingAddr3;
    private boolean __amendIssuingAddr3_is_modified;
    private String _amendIssuingAddr4;
    private boolean __amendIssuingAddr4_is_modified;
    private String _amendIssuingAddr5;
    private boolean __amendIssuingAddr5_is_modified;
    private String _amendNonBnkIssur;
    private boolean __amendNonBnkIssur_is_modified;
    private java.util.Date _amendDateOfIssue;
    private boolean __amendDateOfIssue_is_modified;
    private java.util.Date _amendDateOfAmendment;
    private boolean __amendDateOfAmendment_is_modified;
    private char _amendPurposeOfMsg;
    private boolean __amendPurposeOfMsg_is_modified;
    private String _amendCancelRequest;
    private boolean __amendCancelRequest_is_modified;
    private char _amendAdvisingBnkReq;
    private boolean __amendAdvisingBnkReq_is_modified;
    private char _amendAdvisingBnkType;
    private boolean __amendAdvisingBnkType_is_modified;
    private String _amendAdvisingBrnCode;
    private boolean __amendAdvisingBrnCode_is_modified;
    private String _amendAdvisingBicCode;
    private boolean __amendAdvisingBicCode_is_modified;
    private String _amendAdvisingRoutid;
    private boolean __amendAdvisingRoutid_is_modified;
    private String _amendAdvisingBnkCode;
    private boolean __amendAdvisingBnkCode_is_modified;
    private String _amendAdvisingAddr1;
    private boolean __amendAdvisingAddr1_is_modified;
    private String _amendAdvisingAddr2;
    private boolean __amendAdvisingAddr2_is_modified;
    private String _amendAdvisingAddr3;
    private boolean __amendAdvisingAddr3_is_modified;
    private String _amendAdvisingAddr4;
    private boolean __amendAdvisingAddr4_is_modified;
    private String _amendAdvisingAddr5;
    private boolean __amendAdvisingAddr5_is_modified;
    private char _amendSecondAdvReq;
    private boolean __amendSecondAdvReq_is_modified;
    private char _amendSecondAdvType;
    private boolean __amendSecondAdvType_is_modified;
    private String _amendSecondAdvBrnCode;
    private boolean __amendSecondAdvBrnCode_is_modified;
    private String _amendSecondAdvBicCode;
    private boolean __amendSecondAdvBicCode_is_modified;
    private String _amendSecondAdvRoutid;
    private boolean __amendSecondAdvRoutid_is_modified;
    private String _amendSecondAdvBnkCode;
    private boolean __amendSecondAdvBnkCode_is_modified;
    private String _amendSecondAdvAddr1;
    private boolean __amendSecondAdvAddr1_is_modified;
    private String _amendSecondAdvAddr2;
    private boolean __amendSecondAdvAddr2_is_modified;
    private String _amendSecondAdvAddr3;
    private boolean __amendSecondAdvAddr3_is_modified;
    private String _amendSecondAdvAddr4;
    private boolean __amendSecondAdvAddr4_is_modified;
    private String _amendSecondAdvAddr5;
    private boolean __amendSecondAdvAddr5_is_modified;
    private String _amendNewBeneficiary;
    private boolean __amendNewBeneficiary_is_modified;
    private java.util.Date _amendNewDateOfExpiry;
    private boolean __amendNewDateOfExpiry_is_modified;
    private double _amendIncrDocCrAmt;
    private boolean __amendIncrDocCrAmt_is_modified;
    private double _amendDecrDocCrAmt;
    private boolean __amendDecrDocCrAmt_is_modified;
    private double _amendNewAddnlAmt;
    private boolean __amendNewAddnlAmt_is_modified;
    private String _amendPlaceTakinInChrg;
    private boolean __amendPlaceTakinInChrg_is_modified;
    private String _amendPortOfLoading;
    private boolean __amendPortOfLoading_is_modified;
    private String _amendPortOfDischarge;
    private boolean __amendPortOfDischarge_is_modified;
    private String _amendPlaceOfFinalDest;
    private boolean __amendPlaceOfFinalDest_is_modified;
    private java.util.Date _amendDateOfShipment;
    private boolean __amendDateOfShipment_is_modified;
    private Object _amendDescGoddSer1;
    private boolean __amendDescGoddSer1_is_modified;
    private Object _amendDocReq1;
    private boolean __amendDocReq1_is_modified;
    private Object _amendAddCondition1;
    private boolean __amendAddCondition1_is_modified;
    private String _amendChrgPayable1;
    private boolean __amendChrgPayable1_is_modified;
    private String _amendChrgPayable2;
    private boolean __amendChrgPayable2_is_modified;
    private String _amendChrgPayable3;
    private boolean __amendChrgPayable3_is_modified;
    private String _amendChrgPayable4;
    private boolean __amendChrgPayable4_is_modified;
    private String _amendChrgPayable5;
    private boolean __amendChrgPayable5_is_modified;
    private String _amendChrgPayable6;
    private boolean __amendChrgPayable6_is_modified;
    private String _amendSndrRecInfo1;
    private boolean __amendSndrRecInfo1_is_modified;
    private String _amendSndrRecInfo2;
    private boolean __amendSndrRecInfo2_is_modified;
    private String _amendSndrRecInfo3;
    private boolean __amendSndrRecInfo3_is_modified;
    private String _amendSndrRecInfo4;
    private boolean __amendSndrRecInfo4_is_modified;
    private String _amendSndrRecInfo5;
    private boolean __amendSndrRecInfo5_is_modified;
    private String _amendSndrRecInfo6;
    private boolean __amendSndrRecInfo6_is_modified;
    private String _amendChkbox;
    private boolean __amendChkbox_is_modified;
    private String _amendIssuingCntry;
    private boolean __amendIssuingCntry_is_modified;
    private String _amendAdvisingCntry;
    private boolean __amendAdvisingCntry_is_modified;
    private String _amendSecondAdvCntry;
    private boolean __amendSecondAdvCntry_is_modified;
    private String _amendIssueRef;
    private boolean __amendIssueRef_is_modified;
    private int _amendFormOfDocCredit;
    private boolean __amendFormOfDocCredit_is_modified;
    private int _amendLcApplicableRules;
    private boolean __amendLcApplicableRules_is_modified;
    private char _amendLcApplicantReq;
    private boolean __amendLcApplicantReq_is_modified;
    private String _amendLcApplicantName;
    private boolean __amendLcApplicantName_is_modified;
    private String _amendLcApplicantAddr1;
    private boolean __amendLcApplicantAddr1_is_modified;
    private String _amendLcApplicantAddr2;
    private boolean __amendLcApplicantAddr2_is_modified;
    private String _amendLcApplicantAddr3;
    private boolean __amendLcApplicantAddr3_is_modified;
    private String _amendLcApplicantAddr4;
    private boolean __amendLcApplicantAddr4_is_modified;
    private String _amendLcApplicantAddr5;
    private boolean __amendLcApplicantAddr5_is_modified;
    private char _amendLcAvlWithType;
    private boolean __amendLcAvlWithType_is_modified;
    private String _amendLcAvlWithBrnCode;
    private boolean __amendLcAvlWithBrnCode_is_modified;
    private String _amendLcAvlWithBicCode;
    private boolean __amendLcAvlWithBicCode_is_modified;
    private String _amendLcLcAvlWithRoutid;
    private boolean __amendLcLcAvlWithRoutid_is_modified;
    private String _amendLcAvlWithBnkCode;
    private boolean __amendLcAvlWithBnkCode_is_modified;
    private String _amendLcAvlWithAddr1;
    private boolean __amendLcAvlWithAddr1_is_modified;
    private String _amendLcAvlWithAddr2;
    private boolean __amendLcAvlWithAddr2_is_modified;
    private String _amendLcAvlWithAddr3;
    private boolean __amendLcAvlWithAddr3_is_modified;
    private String _amendLcAvlWithAddr4;
    private boolean __amendLcAvlWithAddr4_is_modified;
    private String _amendLcAvlWithAddr5;
    private boolean __amendLcAvlWithAddr5_is_modified;
    private String _amendLcAvlWithCntry;
    private boolean __amendLcAvlWithCntry_is_modified;
    private String _amendLcDraftsAt1;
    private boolean __amendLcDraftsAt1_is_modified;
    private String _amendLcDraftsAt2;
    private boolean __amendLcDraftsAt2_is_modified;
    private String _amendLcDraftsAt3;
    private boolean __amendLcDraftsAt3_is_modified;
    private char _amendLcDraweeReq;
    private boolean __amendLcDraweeReq_is_modified;
    private char _amendLcDraweeType;
    private boolean __amendLcDraweeType_is_modified;
    private String _amendLcDraweeBrnCode;
    private boolean __amendLcDraweeBrnCode_is_modified;
    private String _amendLcDraweeBicCode;
    private boolean __amendLcDraweeBicCode_is_modified;
    private String _amendLcDraweeRoutid;
    private boolean __amendLcDraweeRoutid_is_modified;
    private String _amendLcDraweeBnkCode;
    private boolean __amendLcDraweeBnkCode_is_modified;
    private String _amendLcDraweeAddr1;
    private boolean __amendLcDraweeAddr1_is_modified;
    private String _amendLcDraweeAddr2;
    private boolean __amendLcDraweeAddr2_is_modified;
    private String _amendLcDraweeAddr3;
    private boolean __amendLcDraweeAddr3_is_modified;
    private String _amendLcDraweeAddr4;
    private boolean __amendLcDraweeAddr4_is_modified;
    private String _amendLcDraweeAddr5;
    private boolean __amendLcDraweeAddr5_is_modified;
    private String _amendDraweeCntryCode;
    private boolean __amendDraweeCntryCode_is_modified;
    private String _amendLcMixedPayDetails1;
    private boolean __amendLcMixedPayDetails1_is_modified;
    private String _amendLcMixedPayDetails2;
    private boolean __amendLcMixedPayDetails2_is_modified;
    private String _amendLcMixedPayDetails3;
    private boolean __amendLcMixedPayDetails3_is_modified;
    private String _amendLcMixedPayDetails4;
    private boolean __amendLcMixedPayDetails4_is_modified;
    private String _amendLcMixedPayDetails5;
    private boolean __amendLcMixedPayDetails5_is_modified;
    private String _amendLcDeferredPayDetails1;
    private boolean __amendLcDeferredPayDetails1_is_modified;
    private String _amendLcDeferredPayDetails2;
    private boolean __amendLcDeferredPayDetails2_is_modified;
    private String _amendLcDeferredPayDetails3;
    private boolean __amendLcDeferredPayDetails3_is_modified;
    private String _amendLcDeferredPayDetails4;
    private boolean __amendLcDeferredPayDetails4_is_modified;
    private String _amendLcDeferredPayDetails5;
    private boolean __amendLcDeferredPayDetails5_is_modified;
    private int _amendLcPartialShipments;
    private boolean __amendLcPartialShipments_is_modified;
    private int _amendLcTranshipment;
    private boolean __amendLcTranshipment_is_modified;
    private int _amendLcConfirmationInst;
    private boolean __amendLcConfirmationInst_is_modified;
    private char _amendLcReimbReq;
    private boolean __amendLcReimbReq_is_modified;
    private char _amendLcReimbType;
    private boolean __amendLcReimbType_is_modified;
    private String _amendLcReimbBrnCode;
    private boolean __amendLcReimbBrnCode_is_modified;
    private String _amendLcReimbBicCode;
    private boolean __amendLcReimbBicCode_is_modified;
    private String _amendLcReimbRoutid;
    private boolean __amendLcReimbRoutid_is_modified;
    private String _amendLcReimbBnkCode;
    private boolean __amendLcReimbBnkCode_is_modified;
    private String _amendLcReimbAddr1;
    private boolean __amendLcReimbAddr1_is_modified;
    private String _amendLcReimbAddr2;
    private boolean __amendLcReimbAddr2_is_modified;
    private String _amendLcReimbAddr3;
    private boolean __amendLcReimbAddr3_is_modified;
    private String _amendLcReimbAddr4;
    private boolean __amendLcReimbAddr4_is_modified;
    private String _amendLcReimbAddr5;
    private boolean __amendLcReimbAddr5_is_modified;
    private String _amendLcInstPaying1;
    private boolean __amendLcInstPaying1_is_modified;
    private String _amendLcInstPaying2;
    private boolean __amendLcInstPaying2_is_modified;
    private String _amendLcInstPaying3;
    private boolean __amendLcInstPaying3_is_modified;
    private String _amendLcInstPaying4;
    private boolean __amendLcInstPaying4_is_modified;
    private String _amendLcInstPaying5;
    private boolean __amendLcInstPaying5_is_modified;
    private String _amendLcInstPaying6;
    private boolean __amendLcInstPaying6_is_modified;
    private String _amendLcInstPaying7;
    private boolean __amendLcInstPaying7_is_modified;
    private String _amendLcInstPaying8;
    private boolean __amendLcInstPaying8_is_modified;
    private String _amendLcInstPaying9;
    private boolean __amendLcInstPaying9_is_modified;
    private String _amendLcInstPaying10;
    private boolean __amendLcInstPaying10_is_modified;
    private String _amendLcInstPaying11;
    private boolean __amendLcInstPaying11_is_modified;
    private String _amendLcInstPaying12;
    private boolean __amendLcInstPaying12_is_modified;
    private char _amendLcSecondAdvReq;
    private boolean __amendLcSecondAdvReq_is_modified;
    private char _amendLcSecondAdvType;
    private boolean __amendLcSecondAdvType_is_modified;
    private String _amendLcSecondAdvBrnCode;
    private boolean __amendLcSecondAdvBrnCode_is_modified;
    private String _amendLcSecondAdvBicCode;
    private boolean __amendLcSecondAdvBicCode_is_modified;
    private String _amendLcSecondAdvRoutid;
    private boolean __amendLcSecondAdvRoutid_is_modified;
    private String _amendLcSecondAdvBnkCode;
    private boolean __amendLcSecondAdvBnkCode_is_modified;
    private String _amendLcSecondAdvAddr1;
    private boolean __amendLcSecondAdvAddr1_is_modified;
    private String _amendLcSecondAdvAddr2;
    private boolean __amendLcSecondAdvAddr2_is_modified;
    private String _amendLcSecondAdvAddr3;
    private boolean __amendLcSecondAdvAddr3_is_modified;
    private String _amendLcSecondAdvAddr4;
    private boolean __amendLcSecondAdvAddr4_is_modified;
    private String _amendLcSecondAdvAddr5;
    private boolean __amendLcSecondAdvAddr5_is_modified;
    private String _amendLcSecondAdvCntrycode;
    private boolean __amendLcSecondAdvCntrycode_is_modified;
    private char _amendLcAvlWithCodetyp;
    private boolean __amendLcAvlWithCodetyp_is_modified;
    private String _amendLcReimbCntryCode;
    private boolean __amendLcReimbCntryCode_is_modified;
    private char _amendLcCnfAdvType;
    private boolean __amendLcCnfAdvType_is_modified;
    private String _amendLcCnfAdvBrnCode;
    private boolean __amendLcCnfAdvBrnCode_is_modified;
    private String _amendLcCnfAdvBicCode;
    private boolean __amendLcCnfAdvBicCode_is_modified;
    private String _amendLcCnfAdvRoutid;
    private boolean __amendLcCnfAdvRoutid_is_modified;
    private String _amendLcCnfAdvBnkCode;
    private boolean __amendLcCnfAdvBnkCode_is_modified;
    private String _amendLcCnfAdvAddr1;
    private boolean __amendLcCnfAdvAddr1_is_modified;
    private String _amendLcCnfAdvAddr2;
    private boolean __amendLcCnfAdvAddr2_is_modified;
    private String _amendLcCnfAdvAddr3;
    private boolean __amendLcCnfAdvAddr3_is_modified;
    private String _amendLcCnfAdvAddr4;
    private boolean __amendLcCnfAdvAddr4_is_modified;
    private String _amendLcCnfAdvAddr5;
    private boolean __amendLcCnfAdvAddr5_is_modified;
    private String _amendLcCnfAdvCntrycode;
    private boolean __amendLcCnfAdvCntrycode_is_modified;
    private boolean _isNew = true;

    public int getAmendLcBrnCode() { return _amendLcBrnCode; }
    public void setAmendLcBrnCode(int newVal) { this._amendLcBrnCode = newVal; __amendLcBrnCode_is_modified = true; }
    public boolean amendLcBrnCodeIsModifiedS2j() { return __amendLcBrnCode_is_modified; }
    public String getAmendLcType() { return _amendLcType; }
    public void setAmendLcType(String newVal) { this._amendLcType = newVal; __amendLcType_is_modified = true; }
    public boolean amendLcTypeIsModifiedS2j() { return __amendLcType_is_modified; }
    public int getAmendLcYear() { return _amendLcYear; }
    public void setAmendLcYear(int newVal) { this._amendLcYear = newVal; __amendLcYear_is_modified = true; }
    public boolean amendLcYearIsModifiedS2j() { return __amendLcYear_is_modified; }
    public int getAmendLcSerial() { return _amendLcSerial; }
    public void setAmendLcSerial(int newVal) { this._amendLcSerial = newVal; __amendLcSerial_is_modified = true; }
    public boolean amendLcSerialIsModifiedS2j() { return __amendLcSerial_is_modified; }
    public int getAmendLcAmdSl() { return _amendLcAmdSl; }
    public void setAmendLcAmdSl(int newVal) { this._amendLcAmdSl = newVal; __amendLcAmdSl_is_modified = true; }
    public boolean amendLcAmdSlIsModifiedS2j() { return __amendLcAmdSl_is_modified; }
    public String getAmendSndrRef() { return _amendSndrRef == null ? "" : _amendSndrRef.trim(); }
    public void setAmendSndrRef(String newVal) { this._amendSndrRef = newVal; __amendSndrRef_is_modified = true; }
    public boolean amendSndrRefIsModifiedS2j() { return __amendSndrRef_is_modified; }
    public String getAmendRcvrRef() { return _amendRcvrRef == null ? "" : _amendRcvrRef.trim(); }
    public void setAmendRcvrRef(String newVal) { this._amendRcvrRef = newVal; __amendRcvrRef_is_modified = true; }
    public boolean amendRcvrRefIsModifiedS2j() { return __amendRcvrRef_is_modified; }
    public String getAmendDocCrNum() { return _amendDocCrNum == null ? "" : _amendDocCrNum.trim(); }
    public void setAmendDocCrNum(String newVal) { this._amendDocCrNum = newVal; __amendDocCrNum_is_modified = true; }
    public boolean amendDocCrNumIsModifiedS2j() { return __amendDocCrNum_is_modified; }
    public char getAmendIssuingBnkReq() { return _amendIssuingBnkReq; }
    public void setAmendIssuingBnkReq(char newVal) { this._amendIssuingBnkReq = newVal; __amendIssuingBnkReq_is_modified = true; }
    public boolean amendIssuingBnkReqIsModifiedS2j() { return __amendIssuingBnkReq_is_modified; }
    public char getAmendIssuingType() { return _amendIssuingType; }
    public void setAmendIssuingType(char newVal) { this._amendIssuingType = newVal; __amendIssuingType_is_modified = true; }
    public boolean amendIssuingTypeIsModifiedS2j() { return __amendIssuingType_is_modified; }
    public String getAmendIssuingBrnCode() { return _amendIssuingBrnCode == null ? "" : _amendIssuingBrnCode.trim(); }
    public void setAmendIssuingBrnCode(String newVal) { this._amendIssuingBrnCode = newVal; __amendIssuingBrnCode_is_modified = true; }
    public boolean amendIssuingBrnCodeIsModifiedS2j() { return __amendIssuingBrnCode_is_modified; }
    public String getAmendIssuingBicCode() { return _amendIssuingBicCode == null ? "" : _amendIssuingBicCode.trim(); }
    public void setAmendIssuingBicCode(String newVal) { this._amendIssuingBicCode = newVal; __amendIssuingBicCode_is_modified = true; }
    public boolean amendIssuingBicCodeIsModifiedS2j() { return __amendIssuingBicCode_is_modified; }
    public String getAmendIssuingRoutid() { return _amendIssuingRoutid == null ? "" : _amendIssuingRoutid.trim(); }
    public void setAmendIssuingRoutid(String newVal) { this._amendIssuingRoutid = newVal; __amendIssuingRoutid_is_modified = true; }
    public boolean amendIssuingRoutidIsModifiedS2j() { return __amendIssuingRoutid_is_modified; }
    public String getAmendIssuingBnkCode() { return _amendIssuingBnkCode == null ? "" : _amendIssuingBnkCode.trim(); }
    public void setAmendIssuingBnkCode(String newVal) { this._amendIssuingBnkCode = newVal; __amendIssuingBnkCode_is_modified = true; }
    public boolean amendIssuingBnkCodeIsModifiedS2j() { return __amendIssuingBnkCode_is_modified; }
    public String getAmendIssuingAddr1() { return _amendIssuingAddr1 == null ? "" : _amendIssuingAddr1.trim(); }
    public void setAmendIssuingAddr1(String newVal) { this._amendIssuingAddr1 = newVal; __amendIssuingAddr1_is_modified = true; }
    public boolean amendIssuingAddr1IsModifiedS2j() { return __amendIssuingAddr1_is_modified; }
    public String getAmendIssuingAddr2() { return _amendIssuingAddr2 == null ? "" : _amendIssuingAddr2.trim(); }
    public void setAmendIssuingAddr2(String newVal) { this._amendIssuingAddr2 = newVal; __amendIssuingAddr2_is_modified = true; }
    public boolean amendIssuingAddr2IsModifiedS2j() { return __amendIssuingAddr2_is_modified; }
    public String getAmendIssuingAddr3() { return _amendIssuingAddr3 == null ? "" : _amendIssuingAddr3.trim(); }
    public void setAmendIssuingAddr3(String newVal) { this._amendIssuingAddr3 = newVal; __amendIssuingAddr3_is_modified = true; }
    public boolean amendIssuingAddr3IsModifiedS2j() { return __amendIssuingAddr3_is_modified; }
    public String getAmendIssuingAddr4() { return _amendIssuingAddr4 == null ? "" : _amendIssuingAddr4.trim(); }
    public void setAmendIssuingAddr4(String newVal) { this._amendIssuingAddr4 = newVal; __amendIssuingAddr4_is_modified = true; }
    public boolean amendIssuingAddr4IsModifiedS2j() { return __amendIssuingAddr4_is_modified; }
    public String getAmendIssuingAddr5() { return _amendIssuingAddr5 == null ? "" : _amendIssuingAddr5.trim(); }
    public void setAmendIssuingAddr5(String newVal) { this._amendIssuingAddr5 = newVal; __amendIssuingAddr5_is_modified = true; }
    public boolean amendIssuingAddr5IsModifiedS2j() { return __amendIssuingAddr5_is_modified; }
    public String getAmendNonBnkIssur() { return _amendNonBnkIssur == null ? "" : _amendNonBnkIssur.trim(); }
    public void setAmendNonBnkIssur(String newVal) { this._amendNonBnkIssur = newVal; __amendNonBnkIssur_is_modified = true; }
    public boolean amendNonBnkIssurIsModifiedS2j() { return __amendNonBnkIssur_is_modified; }
    public java.util.Date getAmendDateOfIssue() { return _amendDateOfIssue; }
    public void setAmendDateOfIssue(java.util.Date newVal) { this._amendDateOfIssue = newVal; __amendDateOfIssue_is_modified = true; }
    public boolean amendDateOfIssueIsModifiedS2j() { return __amendDateOfIssue_is_modified; }
    public java.util.Date getAmendDateOfAmendment() { return _amendDateOfAmendment; }
    public void setAmendDateOfAmendment(java.util.Date newVal) { this._amendDateOfAmendment = newVal; __amendDateOfAmendment_is_modified = true; }
    public boolean amendDateOfAmendmentIsModifiedS2j() { return __amendDateOfAmendment_is_modified; }
    public char getAmendPurposeOfMsg() { return _amendPurposeOfMsg; }
    public void setAmendPurposeOfMsg(char newVal) { this._amendPurposeOfMsg = newVal; __amendPurposeOfMsg_is_modified = true; }
    public boolean amendPurposeOfMsgIsModifiedS2j() { return __amendPurposeOfMsg_is_modified; }
    public String getAmendCancelRequest() { return _amendCancelRequest == null ? "" : _amendCancelRequest.trim(); }
    public void setAmendCancelRequest(String newVal) { this._amendCancelRequest = newVal; __amendCancelRequest_is_modified = true; }
    public boolean amendCancelRequestIsModifiedS2j() { return __amendCancelRequest_is_modified; }
    public char getAmendAdvisingBnkReq() { return _amendAdvisingBnkReq; }
    public void setAmendAdvisingBnkReq(char newVal) { this._amendAdvisingBnkReq = newVal; __amendAdvisingBnkReq_is_modified = true; }
    public boolean amendAdvisingBnkReqIsModifiedS2j() { return __amendAdvisingBnkReq_is_modified; }
    public char getAmendAdvisingBnkType() { return _amendAdvisingBnkType; }
    public void setAmendAdvisingBnkType(char newVal) { this._amendAdvisingBnkType = newVal; __amendAdvisingBnkType_is_modified = true; }
    public boolean amendAdvisingBnkTypeIsModifiedS2j() { return __amendAdvisingBnkType_is_modified; }
    public String getAmendAdvisingBrnCode() { return _amendAdvisingBrnCode == null ? "" : _amendAdvisingBrnCode.trim(); }
    public void setAmendAdvisingBrnCode(String newVal) { this._amendAdvisingBrnCode = newVal; __amendAdvisingBrnCode_is_modified = true; }
    public boolean amendAdvisingBrnCodeIsModifiedS2j() { return __amendAdvisingBrnCode_is_modified; }
    public String getAmendAdvisingBicCode() { return _amendAdvisingBicCode == null ? "" : _amendAdvisingBicCode.trim(); }
    public void setAmendAdvisingBicCode(String newVal) { this._amendAdvisingBicCode = newVal; __amendAdvisingBicCode_is_modified = true; }
    public boolean amendAdvisingBicCodeIsModifiedS2j() { return __amendAdvisingBicCode_is_modified; }
    public String getAmendAdvisingRoutid() { return _amendAdvisingRoutid == null ? "" : _amendAdvisingRoutid.trim(); }
    public void setAmendAdvisingRoutid(String newVal) { this._amendAdvisingRoutid = newVal; __amendAdvisingRoutid_is_modified = true; }
    public boolean amendAdvisingRoutidIsModifiedS2j() { return __amendAdvisingRoutid_is_modified; }
    public String getAmendAdvisingBnkCode() { return _amendAdvisingBnkCode == null ? "" : _amendAdvisingBnkCode.trim(); }
    public void setAmendAdvisingBnkCode(String newVal) { this._amendAdvisingBnkCode = newVal; __amendAdvisingBnkCode_is_modified = true; }
    public boolean amendAdvisingBnkCodeIsModifiedS2j() { return __amendAdvisingBnkCode_is_modified; }
    public String getAmendAdvisingAddr1() { return _amendAdvisingAddr1 == null ? "" : _amendAdvisingAddr1.trim(); }
    public void setAmendAdvisingAddr1(String newVal) { this._amendAdvisingAddr1 = newVal; __amendAdvisingAddr1_is_modified = true; }
    public boolean amendAdvisingAddr1IsModifiedS2j() { return __amendAdvisingAddr1_is_modified; }
    public String getAmendAdvisingAddr2() { return _amendAdvisingAddr2 == null ? "" : _amendAdvisingAddr2.trim(); }
    public void setAmendAdvisingAddr2(String newVal) { this._amendAdvisingAddr2 = newVal; __amendAdvisingAddr2_is_modified = true; }
    public boolean amendAdvisingAddr2IsModifiedS2j() { return __amendAdvisingAddr2_is_modified; }
    public String getAmendAdvisingAddr3() { return _amendAdvisingAddr3 == null ? "" : _amendAdvisingAddr3.trim(); }
    public void setAmendAdvisingAddr3(String newVal) { this._amendAdvisingAddr3 = newVal; __amendAdvisingAddr3_is_modified = true; }
    public boolean amendAdvisingAddr3IsModifiedS2j() { return __amendAdvisingAddr3_is_modified; }
    public String getAmendAdvisingAddr4() { return _amendAdvisingAddr4 == null ? "" : _amendAdvisingAddr4.trim(); }
    public void setAmendAdvisingAddr4(String newVal) { this._amendAdvisingAddr4 = newVal; __amendAdvisingAddr4_is_modified = true; }
    public boolean amendAdvisingAddr4IsModifiedS2j() { return __amendAdvisingAddr4_is_modified; }
    public String getAmendAdvisingAddr5() { return _amendAdvisingAddr5 == null ? "" : _amendAdvisingAddr5.trim(); }
    public void setAmendAdvisingAddr5(String newVal) { this._amendAdvisingAddr5 = newVal; __amendAdvisingAddr5_is_modified = true; }
    public boolean amendAdvisingAddr5IsModifiedS2j() { return __amendAdvisingAddr5_is_modified; }
    public char getAmendSecondAdvReq() { return _amendSecondAdvReq; }
    public void setAmendSecondAdvReq(char newVal) { this._amendSecondAdvReq = newVal; __amendSecondAdvReq_is_modified = true; }
    public boolean amendSecondAdvReqIsModifiedS2j() { return __amendSecondAdvReq_is_modified; }
    public char getAmendSecondAdvType() { return _amendSecondAdvType; }
    public void setAmendSecondAdvType(char newVal) { this._amendSecondAdvType = newVal; __amendSecondAdvType_is_modified = true; }
    public boolean amendSecondAdvTypeIsModifiedS2j() { return __amendSecondAdvType_is_modified; }
    public String getAmendSecondAdvBrnCode() { return _amendSecondAdvBrnCode == null ? "" : _amendSecondAdvBrnCode.trim(); }
    public void setAmendSecondAdvBrnCode(String newVal) { this._amendSecondAdvBrnCode = newVal; __amendSecondAdvBrnCode_is_modified = true; }
    public boolean amendSecondAdvBrnCodeIsModifiedS2j() { return __amendSecondAdvBrnCode_is_modified; }
    public String getAmendSecondAdvBicCode() { return _amendSecondAdvBicCode == null ? "" : _amendSecondAdvBicCode.trim(); }
    public void setAmendSecondAdvBicCode(String newVal) { this._amendSecondAdvBicCode = newVal; __amendSecondAdvBicCode_is_modified = true; }
    public boolean amendSecondAdvBicCodeIsModifiedS2j() { return __amendSecondAdvBicCode_is_modified; }
    public String getAmendSecondAdvRoutid() { return _amendSecondAdvRoutid == null ? "" : _amendSecondAdvRoutid.trim(); }
    public void setAmendSecondAdvRoutid(String newVal) { this._amendSecondAdvRoutid = newVal; __amendSecondAdvRoutid_is_modified = true; }
    public boolean amendSecondAdvRoutidIsModifiedS2j() { return __amendSecondAdvRoutid_is_modified; }
    public String getAmendSecondAdvBnkCode() { return _amendSecondAdvBnkCode == null ? "" : _amendSecondAdvBnkCode.trim(); }
    public void setAmendSecondAdvBnkCode(String newVal) { this._amendSecondAdvBnkCode = newVal; __amendSecondAdvBnkCode_is_modified = true; }
    public boolean amendSecondAdvBnkCodeIsModifiedS2j() { return __amendSecondAdvBnkCode_is_modified; }
    public String getAmendSecondAdvAddr1() { return _amendSecondAdvAddr1 == null ? "" : _amendSecondAdvAddr1.trim(); }
    public void setAmendSecondAdvAddr1(String newVal) { this._amendSecondAdvAddr1 = newVal; __amendSecondAdvAddr1_is_modified = true; }
    public boolean amendSecondAdvAddr1IsModifiedS2j() { return __amendSecondAdvAddr1_is_modified; }
    public String getAmendSecondAdvAddr2() { return _amendSecondAdvAddr2 == null ? "" : _amendSecondAdvAddr2.trim(); }
    public void setAmendSecondAdvAddr2(String newVal) { this._amendSecondAdvAddr2 = newVal; __amendSecondAdvAddr2_is_modified = true; }
    public boolean amendSecondAdvAddr2IsModifiedS2j() { return __amendSecondAdvAddr2_is_modified; }
    public String getAmendSecondAdvAddr3() { return _amendSecondAdvAddr3 == null ? "" : _amendSecondAdvAddr3.trim(); }
    public void setAmendSecondAdvAddr3(String newVal) { this._amendSecondAdvAddr3 = newVal; __amendSecondAdvAddr3_is_modified = true; }
    public boolean amendSecondAdvAddr3IsModifiedS2j() { return __amendSecondAdvAddr3_is_modified; }
    public String getAmendSecondAdvAddr4() { return _amendSecondAdvAddr4 == null ? "" : _amendSecondAdvAddr4.trim(); }
    public void setAmendSecondAdvAddr4(String newVal) { this._amendSecondAdvAddr4 = newVal; __amendSecondAdvAddr4_is_modified = true; }
    public boolean amendSecondAdvAddr4IsModifiedS2j() { return __amendSecondAdvAddr4_is_modified; }
    public String getAmendSecondAdvAddr5() { return _amendSecondAdvAddr5 == null ? "" : _amendSecondAdvAddr5.trim(); }
    public void setAmendSecondAdvAddr5(String newVal) { this._amendSecondAdvAddr5 = newVal; __amendSecondAdvAddr5_is_modified = true; }
    public boolean amendSecondAdvAddr5IsModifiedS2j() { return __amendSecondAdvAddr5_is_modified; }
    public String getAmendNewBeneficiary() { return _amendNewBeneficiary == null ? "" : _amendNewBeneficiary.trim(); }
    public void setAmendNewBeneficiary(String newVal) { this._amendNewBeneficiary = newVal; __amendNewBeneficiary_is_modified = true; }
    public boolean amendNewBeneficiaryIsModifiedS2j() { return __amendNewBeneficiary_is_modified; }
    public java.util.Date getAmendNewDateOfExpiry() { return _amendNewDateOfExpiry; }
    public void setAmendNewDateOfExpiry(java.util.Date newVal) { this._amendNewDateOfExpiry = newVal; __amendNewDateOfExpiry_is_modified = true; }
    public boolean amendNewDateOfExpiryIsModifiedS2j() { return __amendNewDateOfExpiry_is_modified; }
    public double getAmendIncrDocCrAmt() { return _amendIncrDocCrAmt; }
    public void setAmendIncrDocCrAmt(double newVal) { this._amendIncrDocCrAmt = newVal; __amendIncrDocCrAmt_is_modified = true; }
    public boolean amendIncrDocCrAmtIsModifiedS2j() { return __amendIncrDocCrAmt_is_modified; }
    public double getAmendDecrDocCrAmt() { return _amendDecrDocCrAmt; }
    public void setAmendDecrDocCrAmt(double newVal) { this._amendDecrDocCrAmt = newVal; __amendDecrDocCrAmt_is_modified = true; }
    public boolean amendDecrDocCrAmtIsModifiedS2j() { return __amendDecrDocCrAmt_is_modified; }
    public double getAmendNewAddnlAmt() { return _amendNewAddnlAmt; }
    public void setAmendNewAddnlAmt(double newVal) { this._amendNewAddnlAmt = newVal; __amendNewAddnlAmt_is_modified = true; }
    public boolean amendNewAddnlAmtIsModifiedS2j() { return __amendNewAddnlAmt_is_modified; }
    public String getAmendPlaceTakinInChrg() { return _amendPlaceTakinInChrg == null ? "" : _amendPlaceTakinInChrg.trim(); }
    public void setAmendPlaceTakinInChrg(String newVal) { this._amendPlaceTakinInChrg = newVal; __amendPlaceTakinInChrg_is_modified = true; }
    public boolean amendPlaceTakinInChrgIsModifiedS2j() { return __amendPlaceTakinInChrg_is_modified; }
    public String getAmendPortOfLoading() { return _amendPortOfLoading == null ? "" : _amendPortOfLoading.trim(); }
    public void setAmendPortOfLoading(String newVal) { this._amendPortOfLoading = newVal; __amendPortOfLoading_is_modified = true; }
    public boolean amendPortOfLoadingIsModifiedS2j() { return __amendPortOfLoading_is_modified; }
    public String getAmendPortOfDischarge() { return _amendPortOfDischarge == null ? "" : _amendPortOfDischarge.trim(); }
    public void setAmendPortOfDischarge(String newVal) { this._amendPortOfDischarge = newVal; __amendPortOfDischarge_is_modified = true; }
    public boolean amendPortOfDischargeIsModifiedS2j() { return __amendPortOfDischarge_is_modified; }
    public String getAmendPlaceOfFinalDest() { return _amendPlaceOfFinalDest == null ? "" : _amendPlaceOfFinalDest.trim(); }
    public void setAmendPlaceOfFinalDest(String newVal) { this._amendPlaceOfFinalDest = newVal; __amendPlaceOfFinalDest_is_modified = true; }
    public boolean amendPlaceOfFinalDestIsModifiedS2j() { return __amendPlaceOfFinalDest_is_modified; }
    public java.util.Date getAmendDateOfShipment() { return _amendDateOfShipment; }
    public void setAmendDateOfShipment(java.util.Date newVal) { this._amendDateOfShipment = newVal; __amendDateOfShipment_is_modified = true; }
    public boolean amendDateOfShipmentIsModifiedS2j() { return __amendDateOfShipment_is_modified; }
    public Object getAmendDescGoddSer1() { return _amendDescGoddSer1; }
    public void setAmendDescGoddSer1(Object newVal) { this._amendDescGoddSer1 = newVal; __amendDescGoddSer1_is_modified = true; }
    public boolean amendDescGoddSer1IsModifiedS2j() { return __amendDescGoddSer1_is_modified; }
    public Object getAmendDocReq1() { return _amendDocReq1; }
    public void setAmendDocReq1(Object newVal) { this._amendDocReq1 = newVal; __amendDocReq1_is_modified = true; }
    public boolean amendDocReq1IsModifiedS2j() { return __amendDocReq1_is_modified; }
    public Object getAmendAddCondition1() { return _amendAddCondition1; }
    public void setAmendAddCondition1(Object newVal) { this._amendAddCondition1 = newVal; __amendAddCondition1_is_modified = true; }
    public boolean amendAddCondition1IsModifiedS2j() { return __amendAddCondition1_is_modified; }
    public String getAmendChrgPayable1() { return _amendChrgPayable1 == null ? "" : _amendChrgPayable1.trim(); }
    public void setAmendChrgPayable1(String newVal) { this._amendChrgPayable1 = newVal; __amendChrgPayable1_is_modified = true; }
    public boolean amendChrgPayable1IsModifiedS2j() { return __amendChrgPayable1_is_modified; }
    public String getAmendChrgPayable2() { return _amendChrgPayable2 == null ? "" : _amendChrgPayable2.trim(); }
    public void setAmendChrgPayable2(String newVal) { this._amendChrgPayable2 = newVal; __amendChrgPayable2_is_modified = true; }
    public boolean amendChrgPayable2IsModifiedS2j() { return __amendChrgPayable2_is_modified; }
    public String getAmendChrgPayable3() { return _amendChrgPayable3 == null ? "" : _amendChrgPayable3.trim(); }
    public void setAmendChrgPayable3(String newVal) { this._amendChrgPayable3 = newVal; __amendChrgPayable3_is_modified = true; }
    public boolean amendChrgPayable3IsModifiedS2j() { return __amendChrgPayable3_is_modified; }
    public String getAmendChrgPayable4() { return _amendChrgPayable4 == null ? "" : _amendChrgPayable4.trim(); }
    public void setAmendChrgPayable4(String newVal) { this._amendChrgPayable4 = newVal; __amendChrgPayable4_is_modified = true; }
    public boolean amendChrgPayable4IsModifiedS2j() { return __amendChrgPayable4_is_modified; }
    public String getAmendChrgPayable5() { return _amendChrgPayable5 == null ? "" : _amendChrgPayable5.trim(); }
    public void setAmendChrgPayable5(String newVal) { this._amendChrgPayable5 = newVal; __amendChrgPayable5_is_modified = true; }
    public boolean amendChrgPayable5IsModifiedS2j() { return __amendChrgPayable5_is_modified; }
    public String getAmendChrgPayable6() { return _amendChrgPayable6 == null ? "" : _amendChrgPayable6.trim(); }
    public void setAmendChrgPayable6(String newVal) { this._amendChrgPayable6 = newVal; __amendChrgPayable6_is_modified = true; }
    public boolean amendChrgPayable6IsModifiedS2j() { return __amendChrgPayable6_is_modified; }
    public String getAmendSndrRecInfo1() { return _amendSndrRecInfo1 == null ? "" : _amendSndrRecInfo1.trim(); }
    public void setAmendSndrRecInfo1(String newVal) { this._amendSndrRecInfo1 = newVal; __amendSndrRecInfo1_is_modified = true; }
    public boolean amendSndrRecInfo1IsModifiedS2j() { return __amendSndrRecInfo1_is_modified; }
    public String getAmendSndrRecInfo2() { return _amendSndrRecInfo2 == null ? "" : _amendSndrRecInfo2.trim(); }
    public void setAmendSndrRecInfo2(String newVal) { this._amendSndrRecInfo2 = newVal; __amendSndrRecInfo2_is_modified = true; }
    public boolean amendSndrRecInfo2IsModifiedS2j() { return __amendSndrRecInfo2_is_modified; }
    public String getAmendSndrRecInfo3() { return _amendSndrRecInfo3 == null ? "" : _amendSndrRecInfo3.trim(); }
    public void setAmendSndrRecInfo3(String newVal) { this._amendSndrRecInfo3 = newVal; __amendSndrRecInfo3_is_modified = true; }
    public boolean amendSndrRecInfo3IsModifiedS2j() { return __amendSndrRecInfo3_is_modified; }
    public String getAmendSndrRecInfo4() { return _amendSndrRecInfo4 == null ? "" : _amendSndrRecInfo4.trim(); }
    public void setAmendSndrRecInfo4(String newVal) { this._amendSndrRecInfo4 = newVal; __amendSndrRecInfo4_is_modified = true; }
    public boolean amendSndrRecInfo4IsModifiedS2j() { return __amendSndrRecInfo4_is_modified; }
    public String getAmendSndrRecInfo5() { return _amendSndrRecInfo5 == null ? "" : _amendSndrRecInfo5.trim(); }
    public void setAmendSndrRecInfo5(String newVal) { this._amendSndrRecInfo5 = newVal; __amendSndrRecInfo5_is_modified = true; }
    public boolean amendSndrRecInfo5IsModifiedS2j() { return __amendSndrRecInfo5_is_modified; }
    public String getAmendSndrRecInfo6() { return _amendSndrRecInfo6 == null ? "" : _amendSndrRecInfo6.trim(); }
    public void setAmendSndrRecInfo6(String newVal) { this._amendSndrRecInfo6 = newVal; __amendSndrRecInfo6_is_modified = true; }
    public boolean amendSndrRecInfo6IsModifiedS2j() { return __amendSndrRecInfo6_is_modified; }
    public String getAmendChkbox() { return _amendChkbox == null ? "" : _amendChkbox.trim(); }
    public void setAmendChkbox(String newVal) { this._amendChkbox = newVal; __amendChkbox_is_modified = true; }
    public boolean amendChkboxIsModifiedS2j() { return __amendChkbox_is_modified; }
    public String getAmendIssuingCntry() { return _amendIssuingCntry == null ? "" : _amendIssuingCntry.trim(); }
    public void setAmendIssuingCntry(String newVal) { this._amendIssuingCntry = newVal; __amendIssuingCntry_is_modified = true; }
    public boolean amendIssuingCntryIsModifiedS2j() { return __amendIssuingCntry_is_modified; }
    public String getAmendAdvisingCntry() { return _amendAdvisingCntry == null ? "" : _amendAdvisingCntry.trim(); }
    public void setAmendAdvisingCntry(String newVal) { this._amendAdvisingCntry = newVal; __amendAdvisingCntry_is_modified = true; }
    public boolean amendAdvisingCntryIsModifiedS2j() { return __amendAdvisingCntry_is_modified; }
    public String getAmendSecondAdvCntry() { return _amendSecondAdvCntry == null ? "" : _amendSecondAdvCntry.trim(); }
    public void setAmendSecondAdvCntry(String newVal) { this._amendSecondAdvCntry = newVal; __amendSecondAdvCntry_is_modified = true; }
    public boolean amendSecondAdvCntryIsModifiedS2j() { return __amendSecondAdvCntry_is_modified; }
    public String getAmendIssueRef() { return _amendIssueRef == null ? "" : _amendIssueRef.trim(); }
    public void setAmendIssueRef(String newVal) { this._amendIssueRef = newVal; __amendIssueRef_is_modified = true; }
    public boolean amendIssueRefIsModifiedS2j() { return __amendIssueRef_is_modified; }
    public int getAmendFormOfDocCredit() { return _amendFormOfDocCredit; }
    public void setAmendFormOfDocCredit(int newVal) { this._amendFormOfDocCredit = newVal; __amendFormOfDocCredit_is_modified = true; }
    public boolean amendFormOfDocCreditIsModifiedS2j() { return __amendFormOfDocCredit_is_modified; }
    public int getAmendLcApplicableRules() { return _amendLcApplicableRules; }
    public void setAmendLcApplicableRules(int newVal) { this._amendLcApplicableRules = newVal; __amendLcApplicableRules_is_modified = true; }
    public boolean amendLcApplicableRulesIsModifiedS2j() { return __amendLcApplicableRules_is_modified; }
    public char getAmendLcApplicantReq() { return _amendLcApplicantReq; }
    public void setAmendLcApplicantReq(char newVal) { this._amendLcApplicantReq = newVal; __amendLcApplicantReq_is_modified = true; }
    public boolean amendLcApplicantReqIsModifiedS2j() { return __amendLcApplicantReq_is_modified; }
    public String getAmendLcApplicantName() { return _amendLcApplicantName == null ? "" : _amendLcApplicantName.trim(); }
    public void setAmendLcApplicantName(String newVal) { this._amendLcApplicantName = newVal; __amendLcApplicantName_is_modified = true; }
    public boolean amendLcApplicantNameIsModifiedS2j() { return __amendLcApplicantName_is_modified; }
    public String getAmendLcApplicantAddr1() { return _amendLcApplicantAddr1 == null ? "" : _amendLcApplicantAddr1.trim(); }
    public void setAmendLcApplicantAddr1(String newVal) { this._amendLcApplicantAddr1 = newVal; __amendLcApplicantAddr1_is_modified = true; }
    public boolean amendLcApplicantAddr1IsModifiedS2j() { return __amendLcApplicantAddr1_is_modified; }
    public String getAmendLcApplicantAddr2() { return _amendLcApplicantAddr2 == null ? "" : _amendLcApplicantAddr2.trim(); }
    public void setAmendLcApplicantAddr2(String newVal) { this._amendLcApplicantAddr2 = newVal; __amendLcApplicantAddr2_is_modified = true; }
    public boolean amendLcApplicantAddr2IsModifiedS2j() { return __amendLcApplicantAddr2_is_modified; }
    public String getAmendLcApplicantAddr3() { return _amendLcApplicantAddr3 == null ? "" : _amendLcApplicantAddr3.trim(); }
    public void setAmendLcApplicantAddr3(String newVal) { this._amendLcApplicantAddr3 = newVal; __amendLcApplicantAddr3_is_modified = true; }
    public boolean amendLcApplicantAddr3IsModifiedS2j() { return __amendLcApplicantAddr3_is_modified; }
    public String getAmendLcApplicantAddr4() { return _amendLcApplicantAddr4 == null ? "" : _amendLcApplicantAddr4.trim(); }
    public void setAmendLcApplicantAddr4(String newVal) { this._amendLcApplicantAddr4 = newVal; __amendLcApplicantAddr4_is_modified = true; }
    public boolean amendLcApplicantAddr4IsModifiedS2j() { return __amendLcApplicantAddr4_is_modified; }
    public String getAmendLcApplicantAddr5() { return _amendLcApplicantAddr5 == null ? "" : _amendLcApplicantAddr5.trim(); }
    public void setAmendLcApplicantAddr5(String newVal) { this._amendLcApplicantAddr5 = newVal; __amendLcApplicantAddr5_is_modified = true; }
    public boolean amendLcApplicantAddr5IsModifiedS2j() { return __amendLcApplicantAddr5_is_modified; }
    public char getAmendLcAvlWithType() { return _amendLcAvlWithType; }
    public void setAmendLcAvlWithType(char newVal) { this._amendLcAvlWithType = newVal; __amendLcAvlWithType_is_modified = true; }
    public boolean amendLcAvlWithTypeIsModifiedS2j() { return __amendLcAvlWithType_is_modified; }
    public String getAmendLcAvlWithBrnCode() { return _amendLcAvlWithBrnCode == null ? "" : _amendLcAvlWithBrnCode.trim(); }
    public void setAmendLcAvlWithBrnCode(String newVal) { this._amendLcAvlWithBrnCode = newVal; __amendLcAvlWithBrnCode_is_modified = true; }
    public boolean amendLcAvlWithBrnCodeIsModifiedS2j() { return __amendLcAvlWithBrnCode_is_modified; }
    public String getAmendLcAvlWithBicCode() { return _amendLcAvlWithBicCode == null ? "" : _amendLcAvlWithBicCode.trim(); }
    public void setAmendLcAvlWithBicCode(String newVal) { this._amendLcAvlWithBicCode = newVal; __amendLcAvlWithBicCode_is_modified = true; }
    public boolean amendLcAvlWithBicCodeIsModifiedS2j() { return __amendLcAvlWithBicCode_is_modified; }
    public String getAmendLcLcAvlWithRoutid() { return _amendLcLcAvlWithRoutid == null ? "" : _amendLcLcAvlWithRoutid.trim(); }
    public void setAmendLcLcAvlWithRoutid(String newVal) { this._amendLcLcAvlWithRoutid = newVal; __amendLcLcAvlWithRoutid_is_modified = true; }
    public boolean amendLcLcAvlWithRoutidIsModifiedS2j() { return __amendLcLcAvlWithRoutid_is_modified; }
    public String getAmendLcAvlWithBnkCode() { return _amendLcAvlWithBnkCode == null ? "" : _amendLcAvlWithBnkCode.trim(); }
    public void setAmendLcAvlWithBnkCode(String newVal) { this._amendLcAvlWithBnkCode = newVal; __amendLcAvlWithBnkCode_is_modified = true; }
    public boolean amendLcAvlWithBnkCodeIsModifiedS2j() { return __amendLcAvlWithBnkCode_is_modified; }
    public String getAmendLcAvlWithAddr1() { return _amendLcAvlWithAddr1 == null ? "" : _amendLcAvlWithAddr1.trim(); }
    public void setAmendLcAvlWithAddr1(String newVal) { this._amendLcAvlWithAddr1 = newVal; __amendLcAvlWithAddr1_is_modified = true; }
    public boolean amendLcAvlWithAddr1IsModifiedS2j() { return __amendLcAvlWithAddr1_is_modified; }
    public String getAmendLcAvlWithAddr2() { return _amendLcAvlWithAddr2 == null ? "" : _amendLcAvlWithAddr2.trim(); }
    public void setAmendLcAvlWithAddr2(String newVal) { this._amendLcAvlWithAddr2 = newVal; __amendLcAvlWithAddr2_is_modified = true; }
    public boolean amendLcAvlWithAddr2IsModifiedS2j() { return __amendLcAvlWithAddr2_is_modified; }
    public String getAmendLcAvlWithAddr3() { return _amendLcAvlWithAddr3 == null ? "" : _amendLcAvlWithAddr3.trim(); }
    public void setAmendLcAvlWithAddr3(String newVal) { this._amendLcAvlWithAddr3 = newVal; __amendLcAvlWithAddr3_is_modified = true; }
    public boolean amendLcAvlWithAddr3IsModifiedS2j() { return __amendLcAvlWithAddr3_is_modified; }
    public String getAmendLcAvlWithAddr4() { return _amendLcAvlWithAddr4 == null ? "" : _amendLcAvlWithAddr4.trim(); }
    public void setAmendLcAvlWithAddr4(String newVal) { this._amendLcAvlWithAddr4 = newVal; __amendLcAvlWithAddr4_is_modified = true; }
    public boolean amendLcAvlWithAddr4IsModifiedS2j() { return __amendLcAvlWithAddr4_is_modified; }
    public String getAmendLcAvlWithAddr5() { return _amendLcAvlWithAddr5 == null ? "" : _amendLcAvlWithAddr5.trim(); }
    public void setAmendLcAvlWithAddr5(String newVal) { this._amendLcAvlWithAddr5 = newVal; __amendLcAvlWithAddr5_is_modified = true; }
    public boolean amendLcAvlWithAddr5IsModifiedS2j() { return __amendLcAvlWithAddr5_is_modified; }
    public String getAmendLcAvlWithCntry() { return _amendLcAvlWithCntry == null ? "" : _amendLcAvlWithCntry.trim(); }
    public void setAmendLcAvlWithCntry(String newVal) { this._amendLcAvlWithCntry = newVal; __amendLcAvlWithCntry_is_modified = true; }
    public boolean amendLcAvlWithCntryIsModifiedS2j() { return __amendLcAvlWithCntry_is_modified; }
    public String getAmendLcDraftsAt1() { return _amendLcDraftsAt1 == null ? "" : _amendLcDraftsAt1.trim(); }
    public void setAmendLcDraftsAt1(String newVal) { this._amendLcDraftsAt1 = newVal; __amendLcDraftsAt1_is_modified = true; }
    public boolean amendLcDraftsAt1IsModifiedS2j() { return __amendLcDraftsAt1_is_modified; }
    public String getAmendLcDraftsAt2() { return _amendLcDraftsAt2 == null ? "" : _amendLcDraftsAt2.trim(); }
    public void setAmendLcDraftsAt2(String newVal) { this._amendLcDraftsAt2 = newVal; __amendLcDraftsAt2_is_modified = true; }
    public boolean amendLcDraftsAt2IsModifiedS2j() { return __amendLcDraftsAt2_is_modified; }
    public String getAmendLcDraftsAt3() { return _amendLcDraftsAt3 == null ? "" : _amendLcDraftsAt3.trim(); }
    public void setAmendLcDraftsAt3(String newVal) { this._amendLcDraftsAt3 = newVal; __amendLcDraftsAt3_is_modified = true; }
    public boolean amendLcDraftsAt3IsModifiedS2j() { return __amendLcDraftsAt3_is_modified; }
    public char getAmendLcDraweeReq() { return _amendLcDraweeReq; }
    public void setAmendLcDraweeReq(char newVal) { this._amendLcDraweeReq = newVal; __amendLcDraweeReq_is_modified = true; }
    public boolean amendLcDraweeReqIsModifiedS2j() { return __amendLcDraweeReq_is_modified; }
    public char getAmendLcDraweeType() { return _amendLcDraweeType; }
    public void setAmendLcDraweeType(char newVal) { this._amendLcDraweeType = newVal; __amendLcDraweeType_is_modified = true; }
    public boolean amendLcDraweeTypeIsModifiedS2j() { return __amendLcDraweeType_is_modified; }
    public String getAmendLcDraweeBrnCode() { return _amendLcDraweeBrnCode == null ? "" : _amendLcDraweeBrnCode.trim(); }
    public void setAmendLcDraweeBrnCode(String newVal) { this._amendLcDraweeBrnCode = newVal; __amendLcDraweeBrnCode_is_modified = true; }
    public boolean amendLcDraweeBrnCodeIsModifiedS2j() { return __amendLcDraweeBrnCode_is_modified; }
    public String getAmendLcDraweeBicCode() { return _amendLcDraweeBicCode == null ? "" : _amendLcDraweeBicCode.trim(); }
    public void setAmendLcDraweeBicCode(String newVal) { this._amendLcDraweeBicCode = newVal; __amendLcDraweeBicCode_is_modified = true; }
    public boolean amendLcDraweeBicCodeIsModifiedS2j() { return __amendLcDraweeBicCode_is_modified; }
    public String getAmendLcDraweeRoutid() { return _amendLcDraweeRoutid == null ? "" : _amendLcDraweeRoutid.trim(); }
    public void setAmendLcDraweeRoutid(String newVal) { this._amendLcDraweeRoutid = newVal; __amendLcDraweeRoutid_is_modified = true; }
    public boolean amendLcDraweeRoutidIsModifiedS2j() { return __amendLcDraweeRoutid_is_modified; }
    public String getAmendLcDraweeBnkCode() { return _amendLcDraweeBnkCode == null ? "" : _amendLcDraweeBnkCode.trim(); }
    public void setAmendLcDraweeBnkCode(String newVal) { this._amendLcDraweeBnkCode = newVal; __amendLcDraweeBnkCode_is_modified = true; }
    public boolean amendLcDraweeBnkCodeIsModifiedS2j() { return __amendLcDraweeBnkCode_is_modified; }
    public String getAmendLcDraweeAddr1() { return _amendLcDraweeAddr1 == null ? "" : _amendLcDraweeAddr1.trim(); }
    public void setAmendLcDraweeAddr1(String newVal) { this._amendLcDraweeAddr1 = newVal; __amendLcDraweeAddr1_is_modified = true; }
    public boolean amendLcDraweeAddr1IsModifiedS2j() { return __amendLcDraweeAddr1_is_modified; }
    public String getAmendLcDraweeAddr2() { return _amendLcDraweeAddr2 == null ? "" : _amendLcDraweeAddr2.trim(); }
    public void setAmendLcDraweeAddr2(String newVal) { this._amendLcDraweeAddr2 = newVal; __amendLcDraweeAddr2_is_modified = true; }
    public boolean amendLcDraweeAddr2IsModifiedS2j() { return __amendLcDraweeAddr2_is_modified; }
    public String getAmendLcDraweeAddr3() { return _amendLcDraweeAddr3 == null ? "" : _amendLcDraweeAddr3.trim(); }
    public void setAmendLcDraweeAddr3(String newVal) { this._amendLcDraweeAddr3 = newVal; __amendLcDraweeAddr3_is_modified = true; }
    public boolean amendLcDraweeAddr3IsModifiedS2j() { return __amendLcDraweeAddr3_is_modified; }
    public String getAmendLcDraweeAddr4() { return _amendLcDraweeAddr4 == null ? "" : _amendLcDraweeAddr4.trim(); }
    public void setAmendLcDraweeAddr4(String newVal) { this._amendLcDraweeAddr4 = newVal; __amendLcDraweeAddr4_is_modified = true; }
    public boolean amendLcDraweeAddr4IsModifiedS2j() { return __amendLcDraweeAddr4_is_modified; }
    public String getAmendLcDraweeAddr5() { return _amendLcDraweeAddr5 == null ? "" : _amendLcDraweeAddr5.trim(); }
    public void setAmendLcDraweeAddr5(String newVal) { this._amendLcDraweeAddr5 = newVal; __amendLcDraweeAddr5_is_modified = true; }
    public boolean amendLcDraweeAddr5IsModifiedS2j() { return __amendLcDraweeAddr5_is_modified; }
    public String getAmendDraweeCntryCode() { return _amendDraweeCntryCode == null ? "" : _amendDraweeCntryCode.trim(); }
    public void setAmendDraweeCntryCode(String newVal) { this._amendDraweeCntryCode = newVal; __amendDraweeCntryCode_is_modified = true; }
    public boolean amendDraweeCntryCodeIsModifiedS2j() { return __amendDraweeCntryCode_is_modified; }
    public String getAmendLcMixedPayDetails1() { return _amendLcMixedPayDetails1 == null ? "" : _amendLcMixedPayDetails1.trim(); }
    public void setAmendLcMixedPayDetails1(String newVal) { this._amendLcMixedPayDetails1 = newVal; __amendLcMixedPayDetails1_is_modified = true; }
    public boolean amendLcMixedPayDetails1IsModifiedS2j() { return __amendLcMixedPayDetails1_is_modified; }
    public String getAmendLcMixedPayDetails2() { return _amendLcMixedPayDetails2 == null ? "" : _amendLcMixedPayDetails2.trim(); }
    public void setAmendLcMixedPayDetails2(String newVal) { this._amendLcMixedPayDetails2 = newVal; __amendLcMixedPayDetails2_is_modified = true; }
    public boolean amendLcMixedPayDetails2IsModifiedS2j() { return __amendLcMixedPayDetails2_is_modified; }
    public String getAmendLcMixedPayDetails3() { return _amendLcMixedPayDetails3 == null ? "" : _amendLcMixedPayDetails3.trim(); }
    public void setAmendLcMixedPayDetails3(String newVal) { this._amendLcMixedPayDetails3 = newVal; __amendLcMixedPayDetails3_is_modified = true; }
    public boolean amendLcMixedPayDetails3IsModifiedS2j() { return __amendLcMixedPayDetails3_is_modified; }
    public String getAmendLcMixedPayDetails4() { return _amendLcMixedPayDetails4 == null ? "" : _amendLcMixedPayDetails4.trim(); }
    public void setAmendLcMixedPayDetails4(String newVal) { this._amendLcMixedPayDetails4 = newVal; __amendLcMixedPayDetails4_is_modified = true; }
    public boolean amendLcMixedPayDetails4IsModifiedS2j() { return __amendLcMixedPayDetails4_is_modified; }
    public String getAmendLcMixedPayDetails5() { return _amendLcMixedPayDetails5 == null ? "" : _amendLcMixedPayDetails5.trim(); }
    public void setAmendLcMixedPayDetails5(String newVal) { this._amendLcMixedPayDetails5 = newVal; __amendLcMixedPayDetails5_is_modified = true; }
    public boolean amendLcMixedPayDetails5IsModifiedS2j() { return __amendLcMixedPayDetails5_is_modified; }
    public String getAmendLcDeferredPayDetails1() { return _amendLcDeferredPayDetails1 == null ? "" : _amendLcDeferredPayDetails1.trim(); }
    public void setAmendLcDeferredPayDetails1(String newVal) { this._amendLcDeferredPayDetails1 = newVal; __amendLcDeferredPayDetails1_is_modified = true; }
    public boolean amendLcDeferredPayDetails1IsModifiedS2j() { return __amendLcDeferredPayDetails1_is_modified; }
    public String getAmendLcDeferredPayDetails2() { return _amendLcDeferredPayDetails2 == null ? "" : _amendLcDeferredPayDetails2.trim(); }
    public void setAmendLcDeferredPayDetails2(String newVal) { this._amendLcDeferredPayDetails2 = newVal; __amendLcDeferredPayDetails2_is_modified = true; }
    public boolean amendLcDeferredPayDetails2IsModifiedS2j() { return __amendLcDeferredPayDetails2_is_modified; }
    public String getAmendLcDeferredPayDetails3() { return _amendLcDeferredPayDetails3 == null ? "" : _amendLcDeferredPayDetails3.trim(); }
    public void setAmendLcDeferredPayDetails3(String newVal) { this._amendLcDeferredPayDetails3 = newVal; __amendLcDeferredPayDetails3_is_modified = true; }
    public boolean amendLcDeferredPayDetails3IsModifiedS2j() { return __amendLcDeferredPayDetails3_is_modified; }
    public String getAmendLcDeferredPayDetails4() { return _amendLcDeferredPayDetails4 == null ? "" : _amendLcDeferredPayDetails4.trim(); }
    public void setAmendLcDeferredPayDetails4(String newVal) { this._amendLcDeferredPayDetails4 = newVal; __amendLcDeferredPayDetails4_is_modified = true; }
    public boolean amendLcDeferredPayDetails4IsModifiedS2j() { return __amendLcDeferredPayDetails4_is_modified; }
    public String getAmendLcDeferredPayDetails5() { return _amendLcDeferredPayDetails5 == null ? "" : _amendLcDeferredPayDetails5.trim(); }
    public void setAmendLcDeferredPayDetails5(String newVal) { this._amendLcDeferredPayDetails5 = newVal; __amendLcDeferredPayDetails5_is_modified = true; }
    public boolean amendLcDeferredPayDetails5IsModifiedS2j() { return __amendLcDeferredPayDetails5_is_modified; }
    public int getAmendLcPartialShipments() { return _amendLcPartialShipments; }
    public void setAmendLcPartialShipments(int newVal) { this._amendLcPartialShipments = newVal; __amendLcPartialShipments_is_modified = true; }
    public boolean amendLcPartialShipmentsIsModifiedS2j() { return __amendLcPartialShipments_is_modified; }
    public int getAmendLcTranshipment() { return _amendLcTranshipment; }
    public void setAmendLcTranshipment(int newVal) { this._amendLcTranshipment = newVal; __amendLcTranshipment_is_modified = true; }
    public boolean amendLcTranshipmentIsModifiedS2j() { return __amendLcTranshipment_is_modified; }
    public int getAmendLcConfirmationInst() { return _amendLcConfirmationInst; }
    public void setAmendLcConfirmationInst(int newVal) { this._amendLcConfirmationInst = newVal; __amendLcConfirmationInst_is_modified = true; }
    public boolean amendLcConfirmationInstIsModifiedS2j() { return __amendLcConfirmationInst_is_modified; }
    public char getAmendLcReimbReq() { return _amendLcReimbReq; }
    public void setAmendLcReimbReq(char newVal) { this._amendLcReimbReq = newVal; __amendLcReimbReq_is_modified = true; }
    public boolean amendLcReimbReqIsModifiedS2j() { return __amendLcReimbReq_is_modified; }
    public char getAmendLcReimbType() { return _amendLcReimbType; }
    public void setAmendLcReimbType(char newVal) { this._amendLcReimbType = newVal; __amendLcReimbType_is_modified = true; }
    public boolean amendLcReimbTypeIsModifiedS2j() { return __amendLcReimbType_is_modified; }
    public String getAmendLcReimbBrnCode() { return _amendLcReimbBrnCode == null ? "" : _amendLcReimbBrnCode.trim(); }
    public void setAmendLcReimbBrnCode(String newVal) { this._amendLcReimbBrnCode = newVal; __amendLcReimbBrnCode_is_modified = true; }
    public boolean amendLcReimbBrnCodeIsModifiedS2j() { return __amendLcReimbBrnCode_is_modified; }
    public String getAmendLcReimbBicCode() { return _amendLcReimbBicCode == null ? "" : _amendLcReimbBicCode.trim(); }
    public void setAmendLcReimbBicCode(String newVal) { this._amendLcReimbBicCode = newVal; __amendLcReimbBicCode_is_modified = true; }
    public boolean amendLcReimbBicCodeIsModifiedS2j() { return __amendLcReimbBicCode_is_modified; }
    public String getAmendLcReimbRoutid() { return _amendLcReimbRoutid == null ? "" : _amendLcReimbRoutid.trim(); }
    public void setAmendLcReimbRoutid(String newVal) { this._amendLcReimbRoutid = newVal; __amendLcReimbRoutid_is_modified = true; }
    public boolean amendLcReimbRoutidIsModifiedS2j() { return __amendLcReimbRoutid_is_modified; }
    public String getAmendLcReimbBnkCode() { return _amendLcReimbBnkCode == null ? "" : _amendLcReimbBnkCode.trim(); }
    public void setAmendLcReimbBnkCode(String newVal) { this._amendLcReimbBnkCode = newVal; __amendLcReimbBnkCode_is_modified = true; }
    public boolean amendLcReimbBnkCodeIsModifiedS2j() { return __amendLcReimbBnkCode_is_modified; }
    public String getAmendLcReimbAddr1() { return _amendLcReimbAddr1 == null ? "" : _amendLcReimbAddr1.trim(); }
    public void setAmendLcReimbAddr1(String newVal) { this._amendLcReimbAddr1 = newVal; __amendLcReimbAddr1_is_modified = true; }
    public boolean amendLcReimbAddr1IsModifiedS2j() { return __amendLcReimbAddr1_is_modified; }
    public String getAmendLcReimbAddr2() { return _amendLcReimbAddr2 == null ? "" : _amendLcReimbAddr2.trim(); }
    public void setAmendLcReimbAddr2(String newVal) { this._amendLcReimbAddr2 = newVal; __amendLcReimbAddr2_is_modified = true; }
    public boolean amendLcReimbAddr2IsModifiedS2j() { return __amendLcReimbAddr2_is_modified; }
    public String getAmendLcReimbAddr3() { return _amendLcReimbAddr3 == null ? "" : _amendLcReimbAddr3.trim(); }
    public void setAmendLcReimbAddr3(String newVal) { this._amendLcReimbAddr3 = newVal; __amendLcReimbAddr3_is_modified = true; }
    public boolean amendLcReimbAddr3IsModifiedS2j() { return __amendLcReimbAddr3_is_modified; }
    public String getAmendLcReimbAddr4() { return _amendLcReimbAddr4 == null ? "" : _amendLcReimbAddr4.trim(); }
    public void setAmendLcReimbAddr4(String newVal) { this._amendLcReimbAddr4 = newVal; __amendLcReimbAddr4_is_modified = true; }
    public boolean amendLcReimbAddr4IsModifiedS2j() { return __amendLcReimbAddr4_is_modified; }
    public String getAmendLcReimbAddr5() { return _amendLcReimbAddr5 == null ? "" : _amendLcReimbAddr5.trim(); }
    public void setAmendLcReimbAddr5(String newVal) { this._amendLcReimbAddr5 = newVal; __amendLcReimbAddr5_is_modified = true; }
    public boolean amendLcReimbAddr5IsModifiedS2j() { return __amendLcReimbAddr5_is_modified; }
    public String getAmendLcInstPaying1() { return _amendLcInstPaying1 == null ? "" : _amendLcInstPaying1.trim(); }
    public void setAmendLcInstPaying1(String newVal) { this._amendLcInstPaying1 = newVal; __amendLcInstPaying1_is_modified = true; }
    public boolean amendLcInstPaying1IsModifiedS2j() { return __amendLcInstPaying1_is_modified; }
    public String getAmendLcInstPaying2() { return _amendLcInstPaying2 == null ? "" : _amendLcInstPaying2.trim(); }
    public void setAmendLcInstPaying2(String newVal) { this._amendLcInstPaying2 = newVal; __amendLcInstPaying2_is_modified = true; }
    public boolean amendLcInstPaying2IsModifiedS2j() { return __amendLcInstPaying2_is_modified; }
    public String getAmendLcInstPaying3() { return _amendLcInstPaying3 == null ? "" : _amendLcInstPaying3.trim(); }
    public void setAmendLcInstPaying3(String newVal) { this._amendLcInstPaying3 = newVal; __amendLcInstPaying3_is_modified = true; }
    public boolean amendLcInstPaying3IsModifiedS2j() { return __amendLcInstPaying3_is_modified; }
    public String getAmendLcInstPaying4() { return _amendLcInstPaying4 == null ? "" : _amendLcInstPaying4.trim(); }
    public void setAmendLcInstPaying4(String newVal) { this._amendLcInstPaying4 = newVal; __amendLcInstPaying4_is_modified = true; }
    public boolean amendLcInstPaying4IsModifiedS2j() { return __amendLcInstPaying4_is_modified; }
    public String getAmendLcInstPaying5() { return _amendLcInstPaying5 == null ? "" : _amendLcInstPaying5.trim(); }
    public void setAmendLcInstPaying5(String newVal) { this._amendLcInstPaying5 = newVal; __amendLcInstPaying5_is_modified = true; }
    public boolean amendLcInstPaying5IsModifiedS2j() { return __amendLcInstPaying5_is_modified; }
    public String getAmendLcInstPaying6() { return _amendLcInstPaying6 == null ? "" : _amendLcInstPaying6.trim(); }
    public void setAmendLcInstPaying6(String newVal) { this._amendLcInstPaying6 = newVal; __amendLcInstPaying6_is_modified = true; }
    public boolean amendLcInstPaying6IsModifiedS2j() { return __amendLcInstPaying6_is_modified; }
    public String getAmendLcInstPaying7() { return _amendLcInstPaying7 == null ? "" : _amendLcInstPaying7.trim(); }
    public void setAmendLcInstPaying7(String newVal) { this._amendLcInstPaying7 = newVal; __amendLcInstPaying7_is_modified = true; }
    public boolean amendLcInstPaying7IsModifiedS2j() { return __amendLcInstPaying7_is_modified; }
    public String getAmendLcInstPaying8() { return _amendLcInstPaying8 == null ? "" : _amendLcInstPaying8.trim(); }
    public void setAmendLcInstPaying8(String newVal) { this._amendLcInstPaying8 = newVal; __amendLcInstPaying8_is_modified = true; }
    public boolean amendLcInstPaying8IsModifiedS2j() { return __amendLcInstPaying8_is_modified; }
    public String getAmendLcInstPaying9() { return _amendLcInstPaying9 == null ? "" : _amendLcInstPaying9.trim(); }
    public void setAmendLcInstPaying9(String newVal) { this._amendLcInstPaying9 = newVal; __amendLcInstPaying9_is_modified = true; }
    public boolean amendLcInstPaying9IsModifiedS2j() { return __amendLcInstPaying9_is_modified; }
    public String getAmendLcInstPaying10() { return _amendLcInstPaying10 == null ? "" : _amendLcInstPaying10.trim(); }
    public void setAmendLcInstPaying10(String newVal) { this._amendLcInstPaying10 = newVal; __amendLcInstPaying10_is_modified = true; }
    public boolean amendLcInstPaying10IsModifiedS2j() { return __amendLcInstPaying10_is_modified; }
    public String getAmendLcInstPaying11() { return _amendLcInstPaying11 == null ? "" : _amendLcInstPaying11.trim(); }
    public void setAmendLcInstPaying11(String newVal) { this._amendLcInstPaying11 = newVal; __amendLcInstPaying11_is_modified = true; }
    public boolean amendLcInstPaying11IsModifiedS2j() { return __amendLcInstPaying11_is_modified; }
    public String getAmendLcInstPaying12() { return _amendLcInstPaying12 == null ? "" : _amendLcInstPaying12.trim(); }
    public void setAmendLcInstPaying12(String newVal) { this._amendLcInstPaying12 = newVal; __amendLcInstPaying12_is_modified = true; }
    public boolean amendLcInstPaying12IsModifiedS2j() { return __amendLcInstPaying12_is_modified; }
    public char getAmendLcSecondAdvReq() { return _amendLcSecondAdvReq; }
    public void setAmendLcSecondAdvReq(char newVal) { this._amendLcSecondAdvReq = newVal; __amendLcSecondAdvReq_is_modified = true; }
    public boolean amendLcSecondAdvReqIsModifiedS2j() { return __amendLcSecondAdvReq_is_modified; }
    public char getAmendLcSecondAdvType() { return _amendLcSecondAdvType; }
    public void setAmendLcSecondAdvType(char newVal) { this._amendLcSecondAdvType = newVal; __amendLcSecondAdvType_is_modified = true; }
    public boolean amendLcSecondAdvTypeIsModifiedS2j() { return __amendLcSecondAdvType_is_modified; }
    public String getAmendLcSecondAdvBrnCode() { return _amendLcSecondAdvBrnCode == null ? "" : _amendLcSecondAdvBrnCode.trim(); }
    public void setAmendLcSecondAdvBrnCode(String newVal) { this._amendLcSecondAdvBrnCode = newVal; __amendLcSecondAdvBrnCode_is_modified = true; }
    public boolean amendLcSecondAdvBrnCodeIsModifiedS2j() { return __amendLcSecondAdvBrnCode_is_modified; }
    public String getAmendLcSecondAdvBicCode() { return _amendLcSecondAdvBicCode == null ? "" : _amendLcSecondAdvBicCode.trim(); }
    public void setAmendLcSecondAdvBicCode(String newVal) { this._amendLcSecondAdvBicCode = newVal; __amendLcSecondAdvBicCode_is_modified = true; }
    public boolean amendLcSecondAdvBicCodeIsModifiedS2j() { return __amendLcSecondAdvBicCode_is_modified; }
    public String getAmendLcSecondAdvRoutid() { return _amendLcSecondAdvRoutid == null ? "" : _amendLcSecondAdvRoutid.trim(); }
    public void setAmendLcSecondAdvRoutid(String newVal) { this._amendLcSecondAdvRoutid = newVal; __amendLcSecondAdvRoutid_is_modified = true; }
    public boolean amendLcSecondAdvRoutidIsModifiedS2j() { return __amendLcSecondAdvRoutid_is_modified; }
    public String getAmendLcSecondAdvBnkCode() { return _amendLcSecondAdvBnkCode == null ? "" : _amendLcSecondAdvBnkCode.trim(); }
    public void setAmendLcSecondAdvBnkCode(String newVal) { this._amendLcSecondAdvBnkCode = newVal; __amendLcSecondAdvBnkCode_is_modified = true; }
    public boolean amendLcSecondAdvBnkCodeIsModifiedS2j() { return __amendLcSecondAdvBnkCode_is_modified; }
    public String getAmendLcSecondAdvAddr1() { return _amendLcSecondAdvAddr1 == null ? "" : _amendLcSecondAdvAddr1.trim(); }
    public void setAmendLcSecondAdvAddr1(String newVal) { this._amendLcSecondAdvAddr1 = newVal; __amendLcSecondAdvAddr1_is_modified = true; }
    public boolean amendLcSecondAdvAddr1IsModifiedS2j() { return __amendLcSecondAdvAddr1_is_modified; }
    public String getAmendLcSecondAdvAddr2() { return _amendLcSecondAdvAddr2 == null ? "" : _amendLcSecondAdvAddr2.trim(); }
    public void setAmendLcSecondAdvAddr2(String newVal) { this._amendLcSecondAdvAddr2 = newVal; __amendLcSecondAdvAddr2_is_modified = true; }
    public boolean amendLcSecondAdvAddr2IsModifiedS2j() { return __amendLcSecondAdvAddr2_is_modified; }
    public String getAmendLcSecondAdvAddr3() { return _amendLcSecondAdvAddr3 == null ? "" : _amendLcSecondAdvAddr3.trim(); }
    public void setAmendLcSecondAdvAddr3(String newVal) { this._amendLcSecondAdvAddr3 = newVal; __amendLcSecondAdvAddr3_is_modified = true; }
    public boolean amendLcSecondAdvAddr3IsModifiedS2j() { return __amendLcSecondAdvAddr3_is_modified; }
    public String getAmendLcSecondAdvAddr4() { return _amendLcSecondAdvAddr4 == null ? "" : _amendLcSecondAdvAddr4.trim(); }
    public void setAmendLcSecondAdvAddr4(String newVal) { this._amendLcSecondAdvAddr4 = newVal; __amendLcSecondAdvAddr4_is_modified = true; }
    public boolean amendLcSecondAdvAddr4IsModifiedS2j() { return __amendLcSecondAdvAddr4_is_modified; }
    public String getAmendLcSecondAdvAddr5() { return _amendLcSecondAdvAddr5 == null ? "" : _amendLcSecondAdvAddr5.trim(); }
    public void setAmendLcSecondAdvAddr5(String newVal) { this._amendLcSecondAdvAddr5 = newVal; __amendLcSecondAdvAddr5_is_modified = true; }
    public boolean amendLcSecondAdvAddr5IsModifiedS2j() { return __amendLcSecondAdvAddr5_is_modified; }
    public String getAmendLcSecondAdvCntrycode() { return _amendLcSecondAdvCntrycode == null ? "" : _amendLcSecondAdvCntrycode.trim(); }
    public void setAmendLcSecondAdvCntrycode(String newVal) { this._amendLcSecondAdvCntrycode = newVal; __amendLcSecondAdvCntrycode_is_modified = true; }
    public boolean amendLcSecondAdvCntrycodeIsModifiedS2j() { return __amendLcSecondAdvCntrycode_is_modified; }
    public char getAmendLcAvlWithCodetyp() { return _amendLcAvlWithCodetyp; }
    public void setAmendLcAvlWithCodetyp(char newVal) { this._amendLcAvlWithCodetyp = newVal; __amendLcAvlWithCodetyp_is_modified = true; }
    public boolean amendLcAvlWithCodetypIsModifiedS2j() { return __amendLcAvlWithCodetyp_is_modified; }
    public String getAmendLcReimbCntryCode() { return _amendLcReimbCntryCode == null ? "" : _amendLcReimbCntryCode.trim(); }
    public void setAmendLcReimbCntryCode(String newVal) { this._amendLcReimbCntryCode = newVal; __amendLcReimbCntryCode_is_modified = true; }
    public boolean amendLcReimbCntryCodeIsModifiedS2j() { return __amendLcReimbCntryCode_is_modified; }
    public char getAmendLcCnfAdvType() { return _amendLcCnfAdvType; }
    public void setAmendLcCnfAdvType(char newVal) { this._amendLcCnfAdvType = newVal; __amendLcCnfAdvType_is_modified = true; }
    public boolean amendLcCnfAdvTypeIsModifiedS2j() { return __amendLcCnfAdvType_is_modified; }
    public String getAmendLcCnfAdvBrnCode() { return _amendLcCnfAdvBrnCode == null ? "" : _amendLcCnfAdvBrnCode.trim(); }
    public void setAmendLcCnfAdvBrnCode(String newVal) { this._amendLcCnfAdvBrnCode = newVal; __amendLcCnfAdvBrnCode_is_modified = true; }
    public boolean amendLcCnfAdvBrnCodeIsModifiedS2j() { return __amendLcCnfAdvBrnCode_is_modified; }
    public String getAmendLcCnfAdvBicCode() { return _amendLcCnfAdvBicCode == null ? "" : _amendLcCnfAdvBicCode.trim(); }
    public void setAmendLcCnfAdvBicCode(String newVal) { this._amendLcCnfAdvBicCode = newVal; __amendLcCnfAdvBicCode_is_modified = true; }
    public boolean amendLcCnfAdvBicCodeIsModifiedS2j() { return __amendLcCnfAdvBicCode_is_modified; }
    public String getAmendLcCnfAdvRoutid() { return _amendLcCnfAdvRoutid == null ? "" : _amendLcCnfAdvRoutid.trim(); }
    public void setAmendLcCnfAdvRoutid(String newVal) { this._amendLcCnfAdvRoutid = newVal; __amendLcCnfAdvRoutid_is_modified = true; }
    public boolean amendLcCnfAdvRoutidIsModifiedS2j() { return __amendLcCnfAdvRoutid_is_modified; }
    public String getAmendLcCnfAdvBnkCode() { return _amendLcCnfAdvBnkCode == null ? "" : _amendLcCnfAdvBnkCode.trim(); }
    public void setAmendLcCnfAdvBnkCode(String newVal) { this._amendLcCnfAdvBnkCode = newVal; __amendLcCnfAdvBnkCode_is_modified = true; }
    public boolean amendLcCnfAdvBnkCodeIsModifiedS2j() { return __amendLcCnfAdvBnkCode_is_modified; }
    public String getAmendLcCnfAdvAddr1() { return _amendLcCnfAdvAddr1 == null ? "" : _amendLcCnfAdvAddr1.trim(); }
    public void setAmendLcCnfAdvAddr1(String newVal) { this._amendLcCnfAdvAddr1 = newVal; __amendLcCnfAdvAddr1_is_modified = true; }
    public boolean amendLcCnfAdvAddr1IsModifiedS2j() { return __amendLcCnfAdvAddr1_is_modified; }
    public String getAmendLcCnfAdvAddr2() { return _amendLcCnfAdvAddr2 == null ? "" : _amendLcCnfAdvAddr2.trim(); }
    public void setAmendLcCnfAdvAddr2(String newVal) { this._amendLcCnfAdvAddr2 = newVal; __amendLcCnfAdvAddr2_is_modified = true; }
    public boolean amendLcCnfAdvAddr2IsModifiedS2j() { return __amendLcCnfAdvAddr2_is_modified; }
    public String getAmendLcCnfAdvAddr3() { return _amendLcCnfAdvAddr3 == null ? "" : _amendLcCnfAdvAddr3.trim(); }
    public void setAmendLcCnfAdvAddr3(String newVal) { this._amendLcCnfAdvAddr3 = newVal; __amendLcCnfAdvAddr3_is_modified = true; }
    public boolean amendLcCnfAdvAddr3IsModifiedS2j() { return __amendLcCnfAdvAddr3_is_modified; }
    public String getAmendLcCnfAdvAddr4() { return _amendLcCnfAdvAddr4 == null ? "" : _amendLcCnfAdvAddr4.trim(); }
    public void setAmendLcCnfAdvAddr4(String newVal) { this._amendLcCnfAdvAddr4 = newVal; __amendLcCnfAdvAddr4_is_modified = true; }
    public boolean amendLcCnfAdvAddr4IsModifiedS2j() { return __amendLcCnfAdvAddr4_is_modified; }
    public String getAmendLcCnfAdvAddr5() { return _amendLcCnfAdvAddr5 == null ? "" : _amendLcCnfAdvAddr5.trim(); }
    public void setAmendLcCnfAdvAddr5(String newVal) { this._amendLcCnfAdvAddr5 = newVal; __amendLcCnfAdvAddr5_is_modified = true; }
    public boolean amendLcCnfAdvAddr5IsModifiedS2j() { return __amendLcCnfAdvAddr5_is_modified; }
    public String getAmendLcCnfAdvCntrycode() { return _amendLcCnfAdvCntrycode == null ? "" : _amendLcCnfAdvCntrycode.trim(); }
    public void setAmendLcCnfAdvCntrycode(String newVal) { this._amendLcCnfAdvCntrycode = newVal; __amendLcCnfAdvCntrycode_is_modified = true; }
    public boolean amendLcCnfAdvCntrycodeIsModifiedS2j() { return __amendLcCnfAdvCntrycode_is_modified; }
    public boolean isNew() { return _isNew; }
    public void setIsNew(boolean isNew) { this._isNew = isNew; }

    public boolean isModifiedS2J() {
        return __amendLcBrnCode_is_modified || 
        __amendLcType_is_modified || 
        __amendLcYear_is_modified || 
        __amendLcSerial_is_modified || 
        __amendLcAmdSl_is_modified || 
        __amendSndrRef_is_modified || 
        __amendRcvrRef_is_modified || 
        __amendDocCrNum_is_modified || 
        __amendIssuingBnkReq_is_modified || 
        __amendIssuingType_is_modified || 
        __amendIssuingBrnCode_is_modified || 
        __amendIssuingBicCode_is_modified || 
        __amendIssuingRoutid_is_modified || 
        __amendIssuingBnkCode_is_modified || 
        __amendIssuingAddr1_is_modified || 
        __amendIssuingAddr2_is_modified || 
        __amendIssuingAddr3_is_modified || 
        __amendIssuingAddr4_is_modified || 
        __amendIssuingAddr5_is_modified || 
        __amendNonBnkIssur_is_modified || 
        __amendDateOfIssue_is_modified || 
        __amendDateOfAmendment_is_modified || 
        __amendPurposeOfMsg_is_modified || 
        __amendCancelRequest_is_modified || 
        __amendAdvisingBnkReq_is_modified || 
        __amendAdvisingBnkType_is_modified || 
        __amendAdvisingBrnCode_is_modified || 
        __amendAdvisingBicCode_is_modified || 
        __amendAdvisingRoutid_is_modified || 
        __amendAdvisingBnkCode_is_modified || 
        __amendAdvisingAddr1_is_modified || 
        __amendAdvisingAddr2_is_modified || 
        __amendAdvisingAddr3_is_modified || 
        __amendAdvisingAddr4_is_modified || 
        __amendAdvisingAddr5_is_modified || 
        __amendSecondAdvReq_is_modified || 
        __amendSecondAdvType_is_modified || 
        __amendSecondAdvBrnCode_is_modified || 
        __amendSecondAdvBicCode_is_modified || 
        __amendSecondAdvRoutid_is_modified || 
        __amendSecondAdvBnkCode_is_modified || 
        __amendSecondAdvAddr1_is_modified || 
        __amendSecondAdvAddr2_is_modified || 
        __amendSecondAdvAddr3_is_modified || 
        __amendSecondAdvAddr4_is_modified || 
        __amendSecondAdvAddr5_is_modified || 
        __amendNewBeneficiary_is_modified || 
        __amendNewDateOfExpiry_is_modified || 
        __amendIncrDocCrAmt_is_modified || 
        __amendDecrDocCrAmt_is_modified || 
        __amendNewAddnlAmt_is_modified || 
        __amendPlaceTakinInChrg_is_modified || 
        __amendPortOfLoading_is_modified || 
        __amendPortOfDischarge_is_modified || 
        __amendPlaceOfFinalDest_is_modified || 
        __amendDateOfShipment_is_modified || 
        __amendDescGoddSer1_is_modified || 
        __amendDocReq1_is_modified || 
        __amendAddCondition1_is_modified || 
        __amendChrgPayable1_is_modified || 
        __amendChrgPayable2_is_modified || 
        __amendChrgPayable3_is_modified || 
        __amendChrgPayable4_is_modified || 
        __amendChrgPayable5_is_modified || 
        __amendChrgPayable6_is_modified || 
        __amendSndrRecInfo1_is_modified || 
        __amendSndrRecInfo2_is_modified || 
        __amendSndrRecInfo3_is_modified || 
        __amendSndrRecInfo4_is_modified || 
        __amendSndrRecInfo5_is_modified || 
        __amendSndrRecInfo6_is_modified || 
        __amendChkbox_is_modified || 
        __amendIssuingCntry_is_modified || 
        __amendAdvisingCntry_is_modified || 
        __amendSecondAdvCntry_is_modified || 
        __amendIssueRef_is_modified || 
        __amendFormOfDocCredit_is_modified || 
        __amendLcApplicableRules_is_modified || 
        __amendLcApplicantReq_is_modified || 
        __amendLcApplicantName_is_modified || 
        __amendLcApplicantAddr1_is_modified || 
        __amendLcApplicantAddr2_is_modified || 
        __amendLcApplicantAddr3_is_modified || 
        __amendLcApplicantAddr4_is_modified || 
        __amendLcApplicantAddr5_is_modified || 
        __amendLcAvlWithType_is_modified || 
        __amendLcAvlWithBrnCode_is_modified || 
        __amendLcAvlWithBicCode_is_modified || 
        __amendLcLcAvlWithRoutid_is_modified || 
        __amendLcAvlWithBnkCode_is_modified || 
        __amendLcAvlWithAddr1_is_modified || 
        __amendLcAvlWithAddr2_is_modified || 
        __amendLcAvlWithAddr3_is_modified || 
        __amendLcAvlWithAddr4_is_modified || 
        __amendLcAvlWithAddr5_is_modified || 
        __amendLcAvlWithCntry_is_modified || 
        __amendLcDraftsAt1_is_modified || 
        __amendLcDraftsAt2_is_modified || 
        __amendLcDraftsAt3_is_modified || 
        __amendLcDraweeReq_is_modified || 
        __amendLcDraweeType_is_modified || 
        __amendLcDraweeBrnCode_is_modified || 
        __amendLcDraweeBicCode_is_modified || 
        __amendLcDraweeRoutid_is_modified || 
        __amendLcDraweeBnkCode_is_modified || 
        __amendLcDraweeAddr1_is_modified || 
        __amendLcDraweeAddr2_is_modified || 
        __amendLcDraweeAddr3_is_modified || 
        __amendLcDraweeAddr4_is_modified || 
        __amendLcDraweeAddr5_is_modified || 
        __amendDraweeCntryCode_is_modified || 
        __amendLcMixedPayDetails1_is_modified || 
        __amendLcMixedPayDetails2_is_modified || 
        __amendLcMixedPayDetails3_is_modified || 
        __amendLcMixedPayDetails4_is_modified || 
        __amendLcMixedPayDetails5_is_modified || 
        __amendLcDeferredPayDetails1_is_modified || 
        __amendLcDeferredPayDetails2_is_modified || 
        __amendLcDeferredPayDetails3_is_modified || 
        __amendLcDeferredPayDetails4_is_modified || 
        __amendLcDeferredPayDetails5_is_modified || 
        __amendLcPartialShipments_is_modified || 
        __amendLcTranshipment_is_modified || 
        __amendLcConfirmationInst_is_modified || 
        __amendLcReimbReq_is_modified || 
        __amendLcReimbType_is_modified || 
        __amendLcReimbBrnCode_is_modified || 
        __amendLcReimbBicCode_is_modified || 
        __amendLcReimbRoutid_is_modified || 
        __amendLcReimbBnkCode_is_modified || 
        __amendLcReimbAddr1_is_modified || 
        __amendLcReimbAddr2_is_modified || 
        __amendLcReimbAddr3_is_modified || 
        __amendLcReimbAddr4_is_modified || 
        __amendLcReimbAddr5_is_modified || 
        __amendLcInstPaying1_is_modified || 
        __amendLcInstPaying2_is_modified || 
        __amendLcInstPaying3_is_modified || 
        __amendLcInstPaying4_is_modified || 
        __amendLcInstPaying5_is_modified || 
        __amendLcInstPaying6_is_modified || 
        __amendLcInstPaying7_is_modified || 
        __amendLcInstPaying8_is_modified || 
        __amendLcInstPaying9_is_modified || 
        __amendLcInstPaying10_is_modified || 
        __amendLcInstPaying11_is_modified || 
        __amendLcInstPaying12_is_modified || 
        __amendLcSecondAdvReq_is_modified || 
        __amendLcSecondAdvType_is_modified || 
        __amendLcSecondAdvBrnCode_is_modified || 
        __amendLcSecondAdvBicCode_is_modified || 
        __amendLcSecondAdvRoutid_is_modified || 
        __amendLcSecondAdvBnkCode_is_modified || 
        __amendLcSecondAdvAddr1_is_modified || 
        __amendLcSecondAdvAddr2_is_modified || 
        __amendLcSecondAdvAddr3_is_modified || 
        __amendLcSecondAdvAddr4_is_modified || 
        __amendLcSecondAdvAddr5_is_modified || 
        __amendLcSecondAdvCntrycode_is_modified || 
        __amendLcAvlWithCodetyp_is_modified || 
        __amendLcReimbCntryCode_is_modified || 
        __amendLcCnfAdvType_is_modified || 
        __amendLcCnfAdvBrnCode_is_modified || 
        __amendLcCnfAdvBicCode_is_modified || 
        __amendLcCnfAdvRoutid_is_modified || 
        __amendLcCnfAdvBnkCode_is_modified || 
        __amendLcCnfAdvAddr1_is_modified || 
        __amendLcCnfAdvAddr2_is_modified || 
        __amendLcCnfAdvAddr3_is_modified || 
        __amendLcCnfAdvAddr4_is_modified || 
        __amendLcCnfAdvAddr5_is_modified || 
        __amendLcCnfAdvCntrycode_is_modified;
    }

    public void resetIsModifiedS2J() {
        __amendLcBrnCode_is_modified = false;
        __amendLcType_is_modified = false;
        __amendLcYear_is_modified = false;
        __amendLcSerial_is_modified = false;
        __amendLcAmdSl_is_modified = false;
        __amendSndrRef_is_modified = false;
        __amendRcvrRef_is_modified = false;
        __amendDocCrNum_is_modified = false;
        __amendIssuingBnkReq_is_modified = false;
        __amendIssuingType_is_modified = false;
        __amendIssuingBrnCode_is_modified = false;
        __amendIssuingBicCode_is_modified = false;
        __amendIssuingRoutid_is_modified = false;
        __amendIssuingBnkCode_is_modified = false;
        __amendIssuingAddr1_is_modified = false;
        __amendIssuingAddr2_is_modified = false;
        __amendIssuingAddr3_is_modified = false;
        __amendIssuingAddr4_is_modified = false;
        __amendIssuingAddr5_is_modified = false;
        __amendNonBnkIssur_is_modified = false;
        __amendDateOfIssue_is_modified = false;
        __amendDateOfAmendment_is_modified = false;
        __amendPurposeOfMsg_is_modified = false;
        __amendCancelRequest_is_modified = false;
        __amendAdvisingBnkReq_is_modified = false;
        __amendAdvisingBnkType_is_modified = false;
        __amendAdvisingBrnCode_is_modified = false;
        __amendAdvisingBicCode_is_modified = false;
        __amendAdvisingRoutid_is_modified = false;
        __amendAdvisingBnkCode_is_modified = false;
        __amendAdvisingAddr1_is_modified = false;
        __amendAdvisingAddr2_is_modified = false;
        __amendAdvisingAddr3_is_modified = false;
        __amendAdvisingAddr4_is_modified = false;
        __amendAdvisingAddr5_is_modified = false;
        __amendSecondAdvReq_is_modified = false;
        __amendSecondAdvType_is_modified = false;
        __amendSecondAdvBrnCode_is_modified = false;
        __amendSecondAdvBicCode_is_modified = false;
        __amendSecondAdvRoutid_is_modified = false;
        __amendSecondAdvBnkCode_is_modified = false;
        __amendSecondAdvAddr1_is_modified = false;
        __amendSecondAdvAddr2_is_modified = false;
        __amendSecondAdvAddr3_is_modified = false;
        __amendSecondAdvAddr4_is_modified = false;
        __amendSecondAdvAddr5_is_modified = false;
        __amendNewBeneficiary_is_modified = false;
        __amendNewDateOfExpiry_is_modified = false;
        __amendIncrDocCrAmt_is_modified = false;
        __amendDecrDocCrAmt_is_modified = false;
        __amendNewAddnlAmt_is_modified = false;
        __amendPlaceTakinInChrg_is_modified = false;
        __amendPortOfLoading_is_modified = false;
        __amendPortOfDischarge_is_modified = false;
        __amendPlaceOfFinalDest_is_modified = false;
        __amendDateOfShipment_is_modified = false;
        __amendDescGoddSer1_is_modified = false;
        __amendDocReq1_is_modified = false;
        __amendAddCondition1_is_modified = false;
        __amendChrgPayable1_is_modified = false;
        __amendChrgPayable2_is_modified = false;
        __amendChrgPayable3_is_modified = false;
        __amendChrgPayable4_is_modified = false;
        __amendChrgPayable5_is_modified = false;
        __amendChrgPayable6_is_modified = false;
        __amendSndrRecInfo1_is_modified = false;
        __amendSndrRecInfo2_is_modified = false;
        __amendSndrRecInfo3_is_modified = false;
        __amendSndrRecInfo4_is_modified = false;
        __amendSndrRecInfo5_is_modified = false;
        __amendSndrRecInfo6_is_modified = false;
        __amendChkbox_is_modified = false;
        __amendIssuingCntry_is_modified = false;
        __amendAdvisingCntry_is_modified = false;
        __amendSecondAdvCntry_is_modified = false;
        __amendIssueRef_is_modified = false;
        __amendFormOfDocCredit_is_modified = false;
        __amendLcApplicableRules_is_modified = false;
        __amendLcApplicantReq_is_modified = false;
        __amendLcApplicantName_is_modified = false;
        __amendLcApplicantAddr1_is_modified = false;
        __amendLcApplicantAddr2_is_modified = false;
        __amendLcApplicantAddr3_is_modified = false;
        __amendLcApplicantAddr4_is_modified = false;
        __amendLcApplicantAddr5_is_modified = false;
        __amendLcAvlWithType_is_modified = false;
        __amendLcAvlWithBrnCode_is_modified = false;
        __amendLcAvlWithBicCode_is_modified = false;
        __amendLcLcAvlWithRoutid_is_modified = false;
        __amendLcAvlWithBnkCode_is_modified = false;
        __amendLcAvlWithAddr1_is_modified = false;
        __amendLcAvlWithAddr2_is_modified = false;
        __amendLcAvlWithAddr3_is_modified = false;
        __amendLcAvlWithAddr4_is_modified = false;
        __amendLcAvlWithAddr5_is_modified = false;
        __amendLcAvlWithCntry_is_modified = false;
        __amendLcDraftsAt1_is_modified = false;
        __amendLcDraftsAt2_is_modified = false;
        __amendLcDraftsAt3_is_modified = false;
        __amendLcDraweeReq_is_modified = false;
        __amendLcDraweeType_is_modified = false;
        __amendLcDraweeBrnCode_is_modified = false;
        __amendLcDraweeBicCode_is_modified = false;
        __amendLcDraweeRoutid_is_modified = false;
        __amendLcDraweeBnkCode_is_modified = false;
        __amendLcDraweeAddr1_is_modified = false;
        __amendLcDraweeAddr2_is_modified = false;
        __amendLcDraweeAddr3_is_modified = false;
        __amendLcDraweeAddr4_is_modified = false;
        __amendLcDraweeAddr5_is_modified = false;
        __amendDraweeCntryCode_is_modified = false;
        __amendLcMixedPayDetails1_is_modified = false;
        __amendLcMixedPayDetails2_is_modified = false;
        __amendLcMixedPayDetails3_is_modified = false;
        __amendLcMixedPayDetails4_is_modified = false;
        __amendLcMixedPayDetails5_is_modified = false;
        __amendLcDeferredPayDetails1_is_modified = false;
        __amendLcDeferredPayDetails2_is_modified = false;
        __amendLcDeferredPayDetails3_is_modified = false;
        __amendLcDeferredPayDetails4_is_modified = false;
        __amendLcDeferredPayDetails5_is_modified = false;
        __amendLcPartialShipments_is_modified = false;
        __amendLcTranshipment_is_modified = false;
        __amendLcConfirmationInst_is_modified = false;
        __amendLcReimbReq_is_modified = false;
        __amendLcReimbType_is_modified = false;
        __amendLcReimbBrnCode_is_modified = false;
        __amendLcReimbBicCode_is_modified = false;
        __amendLcReimbRoutid_is_modified = false;
        __amendLcReimbBnkCode_is_modified = false;
        __amendLcReimbAddr1_is_modified = false;
        __amendLcReimbAddr2_is_modified = false;
        __amendLcReimbAddr3_is_modified = false;
        __amendLcReimbAddr4_is_modified = false;
        __amendLcReimbAddr5_is_modified = false;
        __amendLcInstPaying1_is_modified = false;
        __amendLcInstPaying2_is_modified = false;
        __amendLcInstPaying3_is_modified = false;
        __amendLcInstPaying4_is_modified = false;
        __amendLcInstPaying5_is_modified = false;
        __amendLcInstPaying6_is_modified = false;
        __amendLcInstPaying7_is_modified = false;
        __amendLcInstPaying8_is_modified = false;
        __amendLcInstPaying9_is_modified = false;
        __amendLcInstPaying10_is_modified = false;
        __amendLcInstPaying11_is_modified = false;
        __amendLcInstPaying12_is_modified = false;
        __amendLcSecondAdvReq_is_modified = false;
        __amendLcSecondAdvType_is_modified = false;
        __amendLcSecondAdvBrnCode_is_modified = false;
        __amendLcSecondAdvBicCode_is_modified = false;
        __amendLcSecondAdvRoutid_is_modified = false;
        __amendLcSecondAdvBnkCode_is_modified = false;
        __amendLcSecondAdvAddr1_is_modified = false;
        __amendLcSecondAdvAddr2_is_modified = false;
        __amendLcSecondAdvAddr3_is_modified = false;
        __amendLcSecondAdvAddr4_is_modified = false;
        __amendLcSecondAdvAddr5_is_modified = false;
        __amendLcSecondAdvCntrycode_is_modified = false;
        __amendLcAvlWithCodetyp_is_modified = false;
        __amendLcReimbCntryCode_is_modified = false;
        __amendLcCnfAdvType_is_modified = false;
        __amendLcCnfAdvBrnCode_is_modified = false;
        __amendLcCnfAdvBicCode_is_modified = false;
        __amendLcCnfAdvRoutid_is_modified = false;
        __amendLcCnfAdvBnkCode_is_modified = false;
        __amendLcCnfAdvAddr1_is_modified = false;
        __amendLcCnfAdvAddr2_is_modified = false;
        __amendLcCnfAdvAddr3_is_modified = false;
        __amendLcCnfAdvAddr4_is_modified = false;
        __amendLcCnfAdvAddr5_is_modified = false;
        __amendLcCnfAdvCntrycode_is_modified = false;
    }
    public AmendDetails() {
        _initialize();
    }

    public void _initialize() {
        _amendLcBrnCode = 0 ;
        _amendLcType = "" ;
        _amendLcYear = 0 ;
        _amendLcSerial = 0 ;
        _amendLcAmdSl = 0 ;
        _amendSndrRef = "" ;
        _amendRcvrRef = "" ;
        _amendDocCrNum = "" ;
        _amendIssuingBnkReq = ' ';
        _amendIssuingType = ' ';
        _amendIssuingBrnCode = "" ;
        _amendIssuingBicCode = "" ;
        _amendIssuingRoutid = "" ;
        _amendIssuingBnkCode = "" ;
        _amendIssuingAddr1 = "" ;
        _amendIssuingAddr2 = "" ;
        _amendIssuingAddr3 = "" ;
        _amendIssuingAddr4 = "" ;
        _amendIssuingAddr5 = "" ;
        _amendNonBnkIssur = "" ;
        _amendDateOfIssue = null ;
        _amendDateOfAmendment = null ;
        _amendPurposeOfMsg = ' ';
        _amendCancelRequest = "" ;
        _amendAdvisingBnkReq = ' ';
        _amendAdvisingBnkType = ' ';
        _amendAdvisingBrnCode = "" ;
        _amendAdvisingBicCode = "" ;
        _amendAdvisingRoutid = "" ;
        _amendAdvisingBnkCode = "" ;
        _amendAdvisingAddr1 = "" ;
        _amendAdvisingAddr2 = "" ;
        _amendAdvisingAddr3 = "" ;
        _amendAdvisingAddr4 = "" ;
        _amendAdvisingAddr5 = "" ;
        _amendSecondAdvReq = ' ';
        _amendSecondAdvType = ' ';
        _amendSecondAdvBrnCode = "" ;
        _amendSecondAdvBicCode = "" ;
        _amendSecondAdvRoutid = "" ;
        _amendSecondAdvBnkCode = "" ;
        _amendSecondAdvAddr1 = "" ;
        _amendSecondAdvAddr2 = "" ;
        _amendSecondAdvAddr3 = "" ;
        _amendSecondAdvAddr4 = "" ;
        _amendSecondAdvAddr5 = "" ;
        _amendNewBeneficiary = "" ;
        _amendNewDateOfExpiry = null ;
        _amendIncrDocCrAmt = 0 ;
        _amendDecrDocCrAmt = 0 ;
        _amendNewAddnlAmt = 0 ;
        _amendPlaceTakinInChrg = "" ;
        _amendPortOfLoading = "" ;
        _amendPortOfDischarge = "" ;
        _amendPlaceOfFinalDest = "" ;
        _amendDateOfShipment = null ;
        _amendDescGoddSer1 = "" ;
        _amendDocReq1 = "" ;
        _amendAddCondition1 = "" ;
        _amendChrgPayable1 = "" ;
        _amendChrgPayable2 = "" ;
        _amendChrgPayable3 = "" ;
        _amendChrgPayable4 = "" ;
        _amendChrgPayable5 = "" ;
        _amendChrgPayable6 = "" ;
        _amendSndrRecInfo1 = "" ;
        _amendSndrRecInfo2 = "" ;
        _amendSndrRecInfo3 = "" ;
        _amendSndrRecInfo4 = "" ;
        _amendSndrRecInfo5 = "" ;
        _amendSndrRecInfo6 = "" ;
        _amendChkbox = "" ;
        _amendIssuingCntry = "" ;
        _amendAdvisingCntry = "" ;
        _amendSecondAdvCntry = "" ;
        _amendIssueRef = "" ;
        _amendFormOfDocCredit = 0 ;
        _amendLcApplicableRules = 0 ;
        _amendLcApplicantReq = ' ';
        _amendLcApplicantName = "" ;
        _amendLcApplicantAddr1 = "" ;
        _amendLcApplicantAddr2 = "" ;
        _amendLcApplicantAddr3 = "" ;
        _amendLcApplicantAddr4 = "" ;
        _amendLcApplicantAddr5 = "" ;
        _amendLcAvlWithType = ' ';
        _amendLcAvlWithBrnCode = "" ;
        _amendLcAvlWithBicCode = "" ;
        _amendLcLcAvlWithRoutid = "" ;
        _amendLcAvlWithBnkCode = "" ;
        _amendLcAvlWithAddr1 = "" ;
        _amendLcAvlWithAddr2 = "" ;
        _amendLcAvlWithAddr3 = "" ;
        _amendLcAvlWithAddr4 = "" ;
        _amendLcAvlWithAddr5 = "" ;
        _amendLcAvlWithCntry = "" ;
        _amendLcDraftsAt1 = "" ;
        _amendLcDraftsAt2 = "" ;
        _amendLcDraftsAt3 = "" ;
        _amendLcDraweeReq = ' ';
        _amendLcDraweeType = ' ';
        _amendLcDraweeBrnCode = "" ;
        _amendLcDraweeBicCode = "" ;
        _amendLcDraweeRoutid = "" ;
        _amendLcDraweeBnkCode = "" ;
        _amendLcDraweeAddr1 = "" ;
        _amendLcDraweeAddr2 = "" ;
        _amendLcDraweeAddr3 = "" ;
        _amendLcDraweeAddr4 = "" ;
        _amendLcDraweeAddr5 = "" ;
        _amendDraweeCntryCode = "" ;
        _amendLcMixedPayDetails1 = "" ;
        _amendLcMixedPayDetails2 = "" ;
        _amendLcMixedPayDetails3 = "" ;
        _amendLcMixedPayDetails4 = "" ;
        _amendLcMixedPayDetails5 = "" ;
        _amendLcDeferredPayDetails1 = "" ;
        _amendLcDeferredPayDetails2 = "" ;
        _amendLcDeferredPayDetails3 = "" ;
        _amendLcDeferredPayDetails4 = "" ;
        _amendLcDeferredPayDetails5 = "" ;
        _amendLcPartialShipments = 0 ;
        _amendLcTranshipment = 0 ;
        _amendLcConfirmationInst = 0 ;
        _amendLcReimbReq = ' ';
        _amendLcReimbType = ' ';
        _amendLcReimbBrnCode = "" ;
        _amendLcReimbBicCode = "" ;
        _amendLcReimbRoutid = "" ;
        _amendLcReimbBnkCode = "" ;
        _amendLcReimbAddr1 = "" ;
        _amendLcReimbAddr2 = "" ;
        _amendLcReimbAddr3 = "" ;
        _amendLcReimbAddr4 = "" ;
        _amendLcReimbAddr5 = "" ;
        _amendLcInstPaying1 = "" ;
        _amendLcInstPaying2 = "" ;
        _amendLcInstPaying3 = "" ;
        _amendLcInstPaying4 = "" ;
        _amendLcInstPaying5 = "" ;
        _amendLcInstPaying6 = "" ;
        _amendLcInstPaying7 = "" ;
        _amendLcInstPaying8 = "" ;
        _amendLcInstPaying9 = "" ;
        _amendLcInstPaying10 = "" ;
        _amendLcInstPaying11 = "" ;
        _amendLcInstPaying12 = "" ;
        _amendLcSecondAdvReq = ' ';
        _amendLcSecondAdvType = ' ';
        _amendLcSecondAdvBrnCode = "" ;
        _amendLcSecondAdvBicCode = "" ;
        _amendLcSecondAdvRoutid = "" ;
        _amendLcSecondAdvBnkCode = "" ;
        _amendLcSecondAdvAddr1 = "" ;
        _amendLcSecondAdvAddr2 = "" ;
        _amendLcSecondAdvAddr3 = "" ;
        _amendLcSecondAdvAddr4 = "" ;
        _amendLcSecondAdvAddr5 = "" ;
        _amendLcSecondAdvCntrycode = "" ;
        _amendLcAvlWithCodetyp = ' ';
        _amendLcReimbCntryCode = "" ;
        _amendLcCnfAdvType = ' ';
        _amendLcCnfAdvBrnCode = "" ;
        _amendLcCnfAdvBicCode = "" ;
        _amendLcCnfAdvRoutid = "" ;
        _amendLcCnfAdvBnkCode = "" ;
        _amendLcCnfAdvAddr1 = "" ;
        _amendLcCnfAdvAddr2 = "" ;
        _amendLcCnfAdvAddr3 = "" ;
        _amendLcCnfAdvAddr4 = "" ;
        _amendLcCnfAdvAddr5 = "" ;
        _amendLcCnfAdvCntrycode = "" ;
    }

}
