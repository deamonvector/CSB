package panacea.OLC.Update;

import java.util.Vector;
import java.sql.*;
import panacea.common.JNDINames;
import java.util.LinkedHashMap;
import panacea.Manager.Manager;

/******************SQL2JAVA_IMPORT_BEGIN******************/

/******************SQL2JAVA_IMPORT_END********************/


public class LcDetailsManager extends Manager
/******************SQL2JAVA_EXTENDS_BEGIN******************/

/******************SQL2JAVA_EXTENDS_END********************/

{

/******************SQL2JAVA_CLASS_BEGIN******************/

/******************SQL2JAVA_CLASS_END********************/


    public static final int LC_BRN_CODE = 0;
    public static final int LC_LC_TYPE = 1;
    public static final int LC_LC_YEAR = 2;
    public static final int LC_LC_SL = 3;
    public static final int LC_FORM_OF_DOC_CREDIT = 4;
    public static final int LC_REFERENCE_TO_PREADVICE = 5;
    public static final int LC_APPLICABLE_RULES = 6;
    public static final int LC_APPLICANT_REQ = 7;
    public static final int LC_APPLICANT_TYPE = 8;
    public static final int LC_APPLICANT_BRN_CODE = 9;
    public static final int LC_APPLICANT_BIC_CODE = 10;
    public static final int LC_APPLICANT_ROUTID = 11;
    public static final int LC_APPLICANT_BNK_CODE = 12;
    public static final int LC_APPLICANT_ADDR1 = 13;
    public static final int LC_APPLICANT_ADDR2 = 14;
    public static final int LC_APPLICANT_ADDR3 = 15;
    public static final int LC_APPLICANT_ADDR4 = 16;
    public static final int LC_APPLICANT_ADDR5 = 17;
    public static final int LC_AVAILABLE_WITH_TYPE = 18;
    public static final int LC_AVAILABLE_WITH_BRN_CODE = 19;
    public static final int LC_AVAILABLE_WITH_CODE = 20;
    public static final int LC_AVAILABLE_WITH_ROUTID = 21;
    public static final int LC_AVAILABLE_WITH_BNK_CODE = 22;
    public static final int LC_AVAILABLE_WITH_ADDR1 = 23;
    public static final int LC_AVAILABLE_WITH_ADDR2 = 24;
    public static final int LC_AVAILABLE_WITH_ADDR3 = 25;
    public static final int LC_AVAILABLE_WITH_ADDR4 = 26;
    public static final int LC_AVAILABLE_WITH_ADDR5 = 27;
    public static final int LC_DRAFTS_AT1 = 28;
    public static final int LC_DRAFTS_AT2 = 29;
    public static final int LC_DRAFTS_AT3 = 30;
    public static final int LC_DRAWEE_REQ = 31;
    public static final int LC_DRAWEE_TYPE = 32;
    public static final int LC_DRAWEE_BRN_CODE = 33;
    public static final int LC_DRAWEE_BIC_CODE = 34;
    public static final int LC_DRAWEE_ROUTID = 35;
    public static final int LC_DRAWEE_BNK_CODE = 36;
    public static final int LC_DRAWEE_ADDR1 = 37;
    public static final int LC_DRAWEE_ADDR2 = 38;
    public static final int LC_DRAWEE_ADDR3 = 39;
    public static final int LC_DRAWEE_ADDR4 = 40;
    public static final int LC_DRAWEE_ADDR5 = 41;
    public static final int LC_MIXED_PAY_DETAILS1 = 42;
    public static final int LC_MIXED_PAY_DETAILS2 = 43;
    public static final int LC_MIXED_PAY_DETAILS3 = 44;
    public static final int LC_MIXED_PAY_DETAILS4 = 45;
    public static final int LC_DEFERRED_PAY_DETAILS1 = 46;
    public static final int LC_DEFERRED_PAY_DETAILS2 = 47;
    public static final int LC_DEFERRED_PAY_DETAILS3 = 48;
    public static final int LC_DEFERRED_PAY_DETAILS4 = 49;
    public static final int LC_PARTIAL_SHIPMENTS = 50;
    public static final int LC_TRANSHIPMENT = 51;
    public static final int LC_PLACE_OF_TAKING_IN_CHARGE = 52;
    public static final int LC_PORT_OF_LOADING = 53;
    public static final int LC_PORT_OF_DISCHARGE = 54;
    public static final int LC_PLACE_OF_FINAL_DEST = 55;
    public static final int LC_DESC_GOODS_SER1 = 56;
    public static final int LC_DESC_GOODS_SER2 = 57;
    public static final int LC_DESC_GOODS_SER3 = 58;
    public static final int LC_DOC_REQ1 = 59;
    public static final int LC_DOC_REQ2 = 60;
    public static final int LC_DOC_REQ3 = 61;
    public static final int LC_ADD_CONDITION1 = 62;
    public static final int LC_ADD_CONDITION2 = 63;
    public static final int LC_ADD_CONDITION3 = 64;
    public static final int LC_CHARGES1 = 65;
    public static final int LC_CHARGES2 = 66;
    public static final int LC_CHARGES3 = 67;
    public static final int LC_CHARGES4 = 68;
    public static final int LC_CHARGES5 = 69;
    public static final int LC_CHARGES6 = 70;
    public static final int LC_PER_PRESENTATION_DAY = 71;
    public static final int LC_CONFIRMATION_INST = 72;
    public static final int LC_REIMB_REQ = 73;
    public static final int LC_REIMB_TYPE = 74;
    public static final int LC_REIMB_BRN_CODE = 75;
    public static final int LC_REIMB_BIC_CODE = 76;
    public static final int LC_REIMB_ROUTID = 77;
    public static final int LC_REIMB_BNK_CODE = 78;
    public static final int LC_REIMB_ADDR1 = 79;
    public static final int LC_REIMB_ADDR2 = 80;
    public static final int LC_REIMB_ADDR3 = 81;
    public static final int LC_REIMB_ADDR4 = 82;
    public static final int LC_REIMB_ADDR5 = 83;
    public static final int LC_INST_PAYING1 = 84;
    public static final int LC_INST_PAYING2 = 85;
    public static final int LC_INST_PAYING3 = 86;
    public static final int LC_INST_PAYING4 = 87;
    public static final int LC_INST_PAYING5 = 88;
    public static final int LC_INST_PAYING6 = 89;
    public static final int LC_INST_PAYING7 = 90;
    public static final int LC_INST_PAYING8 = 91;
    public static final int LC_INST_PAYING9 = 92;
    public static final int LC_INST_PAYING10 = 93;
    public static final int LC_INST_PAYING11 = 94;
    public static final int LC_INST_PAYING12 = 95;
    public static final int LC_SECOND_ADV_REQ = 96;
    public static final int LC_SECOND_ADV_TYPE = 97;
    public static final int LC_SECOND_ADV_BRN_CODE = 98;
    public static final int LC_SECOND_ADV_BIC_CODE = 99;
    public static final int LC_SECOND_ADV_ROUTID = 100;
    public static final int LC_SECOND_ADV_BNK_CODE = 101;
    public static final int LC_SECOND_ADV_ADDR1 = 102;
    public static final int LC_SECOND_ADV_ADDR2 = 103;
    public static final int LC_SECOND_ADV_ADDR3 = 104;
    public static final int LC_SECOND_ADV_ADDR4 = 105;
    public static final int LC_SECOND_ADV_ADDR5 = 106;
    public static final int LC_SNDR_REC_INFO1 = 107;
    public static final int LC_SNDR_REC_INFO2 = 108;
    public static final int LC_SNDR_REC_INFO3 = 109;
    public static final int LC_SNDR_REC_INFO4 = 110;
    public static final int LC_SNDR_REC_INFO5 = 111;
    public static final int LC_SNDR_REC_INFO6 = 112;
    public static final int LC_APPLICANT_CNTRY_CODE = 113;
    public static final int LC_AVAILABLE_WITH_CNTRY = 114;
    public static final int LC_AVAILABLE_WITH_CODETYP = 115;
    public static final int LC_DRAWEE_CNTRY_CODE = 116;
    public static final int LC_CONFIRM_INST_TYPE = 117;
    public static final int LC_REIMB_CNTRY_CODE = 118;
    public static final int LC_SECOND_ADV_CNTRYCODE = 119;
    public static final int LC_SHIPMENT_PERIOD1 = 120;
    public static final int LC_SHIPMENT_PERIOD2 = 121;
    public static final int LC_SHIPMENT_PERIOD3 = 122;
    public static final int LC_SHIPMENT_PERIOD4 = 123;
    public static final int LC_SHIPMENT_PERIOD5 = 124;
    public static final int LC_SHIPMENT_PERIOD6 = 125;
    public static final int LC_PER_PRESENTATION_REMARKS = 126;
    public static final int LC_REC_BIC_CODE = 127;
    public static final int LC_CFM_REIMB_TYPE = 128;
    public static final int LC_CFM_REIMB_BRN_CODE = 129;
    public static final int LC_CFM_REIMB_BIC_CODE = 130;
    public static final int LC_CFM_REIMB_ROUTID = 131;
    public static final int LC_CFM_REIMB_BNK_CODE = 132;
    public static final int LC_CFM_REIMB_ADDR1 = 133;
    public static final int LC_CFM_REIMB_ADDR2 = 134;
    public static final int LC_CFM_REIMB_ADDR3 = 135;
    public static final int LC_CFM_REIMB_ADDR4 = 136;
    public static final int LC_CFM_REIMB_ADDR5 = 137;
    public static final int LC_CFM_REIMB_CNTRY_CODE = 138;

    private String OldData_Key;
    private String NewData_Key;
    private String DataBlock_Old;
    private String DataBlock_New;
    private LinkedHashMap _COLLECTIONobj;
    private int _Logreq ;
    private int _Logaddreq ;
    public LcDetailsManager(LinkedHashMap _COLLECTIONobj, int _Log_Req , int _Log_Add_Req ){
        //_COLLECTIONobjManager = _COLLECTIONobj;
        this._COLLECTIONobj 	= _COLLECTIONobj;
        this._Logreq 			= _Log_Req;
        this._Logaddreq 		= _Log_Add_Req;
        //set_pki_enabled(_COLLECTIONobj);
    }
    private static final String[] S2J_FIELD_NAMES = {
        "LC_DETAILS.LC_BRN_CODE"
        ,"LC_DETAILS.LC_LC_TYPE"
        ,"LC_DETAILS.LC_LC_YEAR"
        ,"LC_DETAILS.LC_LC_SL"
        ,"LC_DETAILS.LC_FORM_OF_DOC_CREDIT"
        ,"LC_DETAILS.LC_REFERENCE_TO_PREADVICE"
        ,"LC_DETAILS.LC_APPLICABLE_RULES"
        ,"LC_DETAILS.LC_APPLICANT_REQ"
        ,"LC_DETAILS.LC_APPLICANT_TYPE"
        ,"LC_DETAILS.LC_APPLICANT_BRN_CODE"
        ,"LC_DETAILS.LC_APPLICANT_BIC_CODE"
        ,"LC_DETAILS.LC_APPLICANT_ROUTID"
        ,"LC_DETAILS.LC_APPLICANT_BNK_CODE"
        ,"LC_DETAILS.LC_APPLICANT_ADDR1"
        ,"LC_DETAILS.LC_APPLICANT_ADDR2"
        ,"LC_DETAILS.LC_APPLICANT_ADDR3"
        ,"LC_DETAILS.LC_APPLICANT_ADDR4"
        ,"LC_DETAILS.LC_APPLICANT_ADDR5"
        ,"LC_DETAILS.LC_AVAILABLE_WITH_TYPE"
        ,"LC_DETAILS.LC_AVAILABLE_WITH_BRN_CODE"
        ,"LC_DETAILS.LC_AVAILABLE_WITH_CODE"
        ,"LC_DETAILS.LC_AVAILABLE_WITH_ROUTID"
        ,"LC_DETAILS.LC_AVAILABLE_WITH_BNK_CODE"
        ,"LC_DETAILS.LC_AVAILABLE_WITH_ADDR1"
        ,"LC_DETAILS.LC_AVAILABLE_WITH_ADDR2"
        ,"LC_DETAILS.LC_AVAILABLE_WITH_ADDR3"
        ,"LC_DETAILS.LC_AVAILABLE_WITH_ADDR4"
        ,"LC_DETAILS.LC_AVAILABLE_WITH_ADDR5"
        ,"LC_DETAILS.LC_DRAFTS_AT1"
        ,"LC_DETAILS.LC_DRAFTS_AT2"
        ,"LC_DETAILS.LC_DRAFTS_AT3"
        ,"LC_DETAILS.LC_DRAWEE_REQ"
        ,"LC_DETAILS.LC_DRAWEE_TYPE"
        ,"LC_DETAILS.LC_DRAWEE_BRN_CODE"
        ,"LC_DETAILS.LC_DRAWEE_BIC_CODE"
        ,"LC_DETAILS.LC_DRAWEE_ROUTID"
        ,"LC_DETAILS.LC_DRAWEE_BNK_CODE"
        ,"LC_DETAILS.LC_DRAWEE_ADDR1"
        ,"LC_DETAILS.LC_DRAWEE_ADDR2"
        ,"LC_DETAILS.LC_DRAWEE_ADDR3"
        ,"LC_DETAILS.LC_DRAWEE_ADDR4"
        ,"LC_DETAILS.LC_DRAWEE_ADDR5"
        ,"LC_DETAILS.LC_MIXED_PAY_DETAILS1"
        ,"LC_DETAILS.LC_MIXED_PAY_DETAILS2"
        ,"LC_DETAILS.LC_MIXED_PAY_DETAILS3"
        ,"LC_DETAILS.LC_MIXED_PAY_DETAILS4"
        ,"LC_DETAILS.LC_DEFERRED_PAY_DETAILS1"
        ,"LC_DETAILS.LC_DEFERRED_PAY_DETAILS2"
        ,"LC_DETAILS.LC_DEFERRED_PAY_DETAILS3"
        ,"LC_DETAILS.LC_DEFERRED_PAY_DETAILS4"
        ,"LC_DETAILS.LC_PARTIAL_SHIPMENTS"
        ,"LC_DETAILS.LC_TRANSHIPMENT"
        ,"LC_DETAILS.LC_PLACE_OF_TAKING_IN_CHARGE"
        ,"LC_DETAILS.LC_PORT_OF_LOADING"
        ,"LC_DETAILS.LC_PORT_OF_DISCHARGE"
        ,"LC_DETAILS.LC_PLACE_OF_FINAL_DEST"
        ,"LC_DETAILS.LC_DESC_GOODS_SER1"
        ,"LC_DETAILS.LC_DESC_GOODS_SER2"
        ,"LC_DETAILS.LC_DESC_GOODS_SER3"
        ,"LC_DETAILS.LC_DOC_REQ1"
        ,"LC_DETAILS.LC_DOC_REQ2"
        ,"LC_DETAILS.LC_DOC_REQ3"
        ,"LC_DETAILS.LC_ADD_CONDITION1"
        ,"LC_DETAILS.LC_ADD_CONDITION2"
        ,"LC_DETAILS.LC_ADD_CONDITION3"
        ,"LC_DETAILS.LC_CHARGES1"
        ,"LC_DETAILS.LC_CHARGES2"
        ,"LC_DETAILS.LC_CHARGES3"
        ,"LC_DETAILS.LC_CHARGES4"
        ,"LC_DETAILS.LC_CHARGES5"
        ,"LC_DETAILS.LC_CHARGES6"
        ,"LC_DETAILS.LC_PER_PRESENTATION_DAY"
        ,"LC_DETAILS.LC_CONFIRMATION_INST"
        ,"LC_DETAILS.LC_REIMB_REQ"
        ,"LC_DETAILS.LC_REIMB_TYPE"
        ,"LC_DETAILS.LC_REIMB_BRN_CODE"
        ,"LC_DETAILS.LC_REIMB_BIC_CODE"
        ,"LC_DETAILS.LC_REIMB_ROUTID"
        ,"LC_DETAILS.LC_REIMB_BNK_CODE"
        ,"LC_DETAILS.LC_REIMB_ADDR1"
        ,"LC_DETAILS.LC_REIMB_ADDR2"
        ,"LC_DETAILS.LC_REIMB_ADDR3"
        ,"LC_DETAILS.LC_REIMB_ADDR4"
        ,"LC_DETAILS.LC_REIMB_ADDR5"
        ,"LC_DETAILS.LC_INST_PAYING1"
        ,"LC_DETAILS.LC_INST_PAYING2"
        ,"LC_DETAILS.LC_INST_PAYING3"
        ,"LC_DETAILS.LC_INST_PAYING4"
        ,"LC_DETAILS.LC_INST_PAYING5"
        ,"LC_DETAILS.LC_INST_PAYING6"
        ,"LC_DETAILS.LC_INST_PAYING7"
        ,"LC_DETAILS.LC_INST_PAYING8"
        ,"LC_DETAILS.LC_INST_PAYING9"
        ,"LC_DETAILS.LC_INST_PAYING10"
        ,"LC_DETAILS.LC_INST_PAYING11"
        ,"LC_DETAILS.LC_INST_PAYING12"
        ,"LC_DETAILS.LC_SECOND_ADV_REQ"
        ,"LC_DETAILS.LC_SECOND_ADV_TYPE"
        ,"LC_DETAILS.LC_SECOND_ADV_BRN_CODE"
        ,"LC_DETAILS.LC_SECOND_ADV_BIC_CODE"
        ,"LC_DETAILS.LC_SECOND_ADV_ROUTID"
        ,"LC_DETAILS.LC_SECOND_ADV_BNK_CODE"
        ,"LC_DETAILS.LC_SECOND_ADV_ADDR1"
        ,"LC_DETAILS.LC_SECOND_ADV_ADDR2"
        ,"LC_DETAILS.LC_SECOND_ADV_ADDR3"
        ,"LC_DETAILS.LC_SECOND_ADV_ADDR4"
        ,"LC_DETAILS.LC_SECOND_ADV_ADDR5"
        ,"LC_DETAILS.LC_SNDR_REC_INFO1"
        ,"LC_DETAILS.LC_SNDR_REC_INFO2"
        ,"LC_DETAILS.LC_SNDR_REC_INFO3"
        ,"LC_DETAILS.LC_SNDR_REC_INFO4"
        ,"LC_DETAILS.LC_SNDR_REC_INFO5"
        ,"LC_DETAILS.LC_SNDR_REC_INFO6"
        ,"LC_DETAILS.LC_APPLICANT_CNTRY_CODE"
        ,"LC_DETAILS.LC_AVAILABLE_WITH_CNTRY"
        ,"LC_DETAILS.LC_AVAILABLE_WITH_CODETYP"
        ,"LC_DETAILS.LC_DRAWEE_CNTRY_CODE"
        ,"LC_DETAILS.LC_CONFIRM_INST_TYPE"
        ,"LC_DETAILS.LC_REIMB_CNTRY_CODE"
        ,"LC_DETAILS.LC_SECOND_ADV_CNTRYCODE"
        ,"LC_DETAILS.LC_SHIPMENT_PERIOD1"
        ,"LC_DETAILS.LC_SHIPMENT_PERIOD2"
        ,"LC_DETAILS.LC_SHIPMENT_PERIOD3"
        ,"LC_DETAILS.LC_SHIPMENT_PERIOD4"
        ,"LC_DETAILS.LC_SHIPMENT_PERIOD5"
        ,"LC_DETAILS.LC_SHIPMENT_PERIOD6"
        ,"LC_DETAILS.LC_PER_PRESENTATION_REMARKS"
        ,"LC_DETAILS.LC_REC_BIC_CODE"
        ,"LC_DETAILS.LC_CFM_REIMB_TYPE"
        ,"LC_DETAILS.LC_CFM_REIMB_BRN_CODE"
        ,"LC_DETAILS.LC_CFM_REIMB_BIC_CODE"
        ,"LC_DETAILS.LC_CFM_REIMB_ROUTID"
        ,"LC_DETAILS.LC_CFM_REIMB_BNK_CODE"
        ,"LC_DETAILS.LC_CFM_REIMB_ADDR1"
        ,"LC_DETAILS.LC_CFM_REIMB_ADDR2"
        ,"LC_DETAILS.LC_CFM_REIMB_ADDR3"
        ,"LC_DETAILS.LC_CFM_REIMB_ADDR4"
        ,"LC_DETAILS.LC_CFM_REIMB_ADDR5"
        ,"LC_DETAILS.LC_CFM_REIMB_CNTRY_CODE"
    };

    private static final String ALL_FIELDS = "LC_DETAILS.LC_BRN_CODE"
                            + ",LC_DETAILS.LC_LC_TYPE"
                            + ",LC_DETAILS.LC_LC_YEAR"
                            + ",LC_DETAILS.LC_LC_SL"
                            + ",LC_DETAILS.LC_FORM_OF_DOC_CREDIT"
                            + ",LC_DETAILS.LC_REFERENCE_TO_PREADVICE"
                            + ",LC_DETAILS.LC_APPLICABLE_RULES"
                            + ",LC_DETAILS.LC_APPLICANT_REQ"
                            + ",LC_DETAILS.LC_APPLICANT_TYPE"
                            + ",LC_DETAILS.LC_APPLICANT_BRN_CODE"
                            + ",LC_DETAILS.LC_APPLICANT_BIC_CODE"
                            + ",LC_DETAILS.LC_APPLICANT_ROUTID"
                            + ",LC_DETAILS.LC_APPLICANT_BNK_CODE"
                            + ",LC_DETAILS.LC_APPLICANT_ADDR1"
                            + ",LC_DETAILS.LC_APPLICANT_ADDR2"
                            + ",LC_DETAILS.LC_APPLICANT_ADDR3"
                            + ",LC_DETAILS.LC_APPLICANT_ADDR4"
                            + ",LC_DETAILS.LC_APPLICANT_ADDR5"
                            + ",LC_DETAILS.LC_AVAILABLE_WITH_TYPE"
                            + ",LC_DETAILS.LC_AVAILABLE_WITH_BRN_CODE"
                            + ",LC_DETAILS.LC_AVAILABLE_WITH_CODE"
                            + ",LC_DETAILS.LC_AVAILABLE_WITH_ROUTID"
                            + ",LC_DETAILS.LC_AVAILABLE_WITH_BNK_CODE"
                            + ",LC_DETAILS.LC_AVAILABLE_WITH_ADDR1"
                            + ",LC_DETAILS.LC_AVAILABLE_WITH_ADDR2"
                            + ",LC_DETAILS.LC_AVAILABLE_WITH_ADDR3"
                            + ",LC_DETAILS.LC_AVAILABLE_WITH_ADDR4"
                            + ",LC_DETAILS.LC_AVAILABLE_WITH_ADDR5"
                            + ",LC_DETAILS.LC_DRAFTS_AT1"
                            + ",LC_DETAILS.LC_DRAFTS_AT2"
                            + ",LC_DETAILS.LC_DRAFTS_AT3"
                            + ",LC_DETAILS.LC_DRAWEE_REQ"
                            + ",LC_DETAILS.LC_DRAWEE_TYPE"
                            + ",LC_DETAILS.LC_DRAWEE_BRN_CODE"
                            + ",LC_DETAILS.LC_DRAWEE_BIC_CODE"
                            + ",LC_DETAILS.LC_DRAWEE_ROUTID"
                            + ",LC_DETAILS.LC_DRAWEE_BNK_CODE"
                            + ",LC_DETAILS.LC_DRAWEE_ADDR1"
                            + ",LC_DETAILS.LC_DRAWEE_ADDR2"
                            + ",LC_DETAILS.LC_DRAWEE_ADDR3"
                            + ",LC_DETAILS.LC_DRAWEE_ADDR4"
                            + ",LC_DETAILS.LC_DRAWEE_ADDR5"
                            + ",LC_DETAILS.LC_MIXED_PAY_DETAILS1"
                            + ",LC_DETAILS.LC_MIXED_PAY_DETAILS2"
                            + ",LC_DETAILS.LC_MIXED_PAY_DETAILS3"
                            + ",LC_DETAILS.LC_MIXED_PAY_DETAILS4"
                            + ",LC_DETAILS.LC_DEFERRED_PAY_DETAILS1"
                            + ",LC_DETAILS.LC_DEFERRED_PAY_DETAILS2"
                            + ",LC_DETAILS.LC_DEFERRED_PAY_DETAILS3"
                            + ",LC_DETAILS.LC_DEFERRED_PAY_DETAILS4"
                            + ",LC_DETAILS.LC_PARTIAL_SHIPMENTS"
                            + ",LC_DETAILS.LC_TRANSHIPMENT"
                            + ",LC_DETAILS.LC_PLACE_OF_TAKING_IN_CHARGE"
                            + ",LC_DETAILS.LC_PORT_OF_LOADING"
                            + ",LC_DETAILS.LC_PORT_OF_DISCHARGE"
                            + ",LC_DETAILS.LC_PLACE_OF_FINAL_DEST"
                            + ",LC_DETAILS.LC_DESC_GOODS_SER1"
                            + ",LC_DETAILS.LC_DESC_GOODS_SER2"
                            + ",LC_DETAILS.LC_DESC_GOODS_SER3"
                            + ",LC_DETAILS.LC_DOC_REQ1"
                            + ",LC_DETAILS.LC_DOC_REQ2"
                            + ",LC_DETAILS.LC_DOC_REQ3"
                            + ",LC_DETAILS.LC_ADD_CONDITION1"
                            + ",LC_DETAILS.LC_ADD_CONDITION2"
                            + ",LC_DETAILS.LC_ADD_CONDITION3"
                            + ",LC_DETAILS.LC_CHARGES1"
                            + ",LC_DETAILS.LC_CHARGES2"
                            + ",LC_DETAILS.LC_CHARGES3"
                            + ",LC_DETAILS.LC_CHARGES4"
                            + ",LC_DETAILS.LC_CHARGES5"
                            + ",LC_DETAILS.LC_CHARGES6"
                            + ",LC_DETAILS.LC_PER_PRESENTATION_DAY"
                            + ",LC_DETAILS.LC_CONFIRMATION_INST"
                            + ",LC_DETAILS.LC_REIMB_REQ"
                            + ",LC_DETAILS.LC_REIMB_TYPE"
                            + ",LC_DETAILS.LC_REIMB_BRN_CODE"
                            + ",LC_DETAILS.LC_REIMB_BIC_CODE"
                            + ",LC_DETAILS.LC_REIMB_ROUTID"
                            + ",LC_DETAILS.LC_REIMB_BNK_CODE"
                            + ",LC_DETAILS.LC_REIMB_ADDR1"
                            + ",LC_DETAILS.LC_REIMB_ADDR2"
                            + ",LC_DETAILS.LC_REIMB_ADDR3"
                            + ",LC_DETAILS.LC_REIMB_ADDR4"
                            + ",LC_DETAILS.LC_REIMB_ADDR5"
                            + ",LC_DETAILS.LC_INST_PAYING1"
                            + ",LC_DETAILS.LC_INST_PAYING2"
                            + ",LC_DETAILS.LC_INST_PAYING3"
                            + ",LC_DETAILS.LC_INST_PAYING4"
                            + ",LC_DETAILS.LC_INST_PAYING5"
                            + ",LC_DETAILS.LC_INST_PAYING6"
                            + ",LC_DETAILS.LC_INST_PAYING7"
                            + ",LC_DETAILS.LC_INST_PAYING8"
                            + ",LC_DETAILS.LC_INST_PAYING9"
                            + ",LC_DETAILS.LC_INST_PAYING10"
                            + ",LC_DETAILS.LC_INST_PAYING11"
                            + ",LC_DETAILS.LC_INST_PAYING12"
                            + ",LC_DETAILS.LC_SECOND_ADV_REQ"
                            + ",LC_DETAILS.LC_SECOND_ADV_TYPE"
                            + ",LC_DETAILS.LC_SECOND_ADV_BRN_CODE"
                            + ",LC_DETAILS.LC_SECOND_ADV_BIC_CODE"
                            + ",LC_DETAILS.LC_SECOND_ADV_ROUTID"
                            + ",LC_DETAILS.LC_SECOND_ADV_BNK_CODE"
                            + ",LC_DETAILS.LC_SECOND_ADV_ADDR1"
                            + ",LC_DETAILS.LC_SECOND_ADV_ADDR2"
                            + ",LC_DETAILS.LC_SECOND_ADV_ADDR3"
                            + ",LC_DETAILS.LC_SECOND_ADV_ADDR4"
                            + ",LC_DETAILS.LC_SECOND_ADV_ADDR5"
                            + ",LC_DETAILS.LC_SNDR_REC_INFO1"
                            + ",LC_DETAILS.LC_SNDR_REC_INFO2"
                            + ",LC_DETAILS.LC_SNDR_REC_INFO3"
                            + ",LC_DETAILS.LC_SNDR_REC_INFO4"
                            + ",LC_DETAILS.LC_SNDR_REC_INFO5"
                            + ",LC_DETAILS.LC_SNDR_REC_INFO6"
                            + ",LC_DETAILS.LC_APPLICANT_CNTRY_CODE"
                            + ",LC_DETAILS.LC_AVAILABLE_WITH_CNTRY"
                            + ",LC_DETAILS.LC_AVAILABLE_WITH_CODETYP"
                            + ",LC_DETAILS.LC_DRAWEE_CNTRY_CODE"
                            + ",LC_DETAILS.LC_CONFIRM_INST_TYPE"
                            + ",LC_DETAILS.LC_REIMB_CNTRY_CODE"
                            + ",LC_DETAILS.LC_SECOND_ADV_CNTRYCODE"
                            + ",LC_DETAILS.LC_SHIPMENT_PERIOD1"
                            + ",LC_DETAILS.LC_SHIPMENT_PERIOD2"
                            + ",LC_DETAILS.LC_SHIPMENT_PERIOD3"
                            + ",LC_DETAILS.LC_SHIPMENT_PERIOD4"
                            + ",LC_DETAILS.LC_SHIPMENT_PERIOD5"
                            + ",LC_DETAILS.LC_SHIPMENT_PERIOD6"
                            + ",LC_DETAILS.LC_PER_PRESENTATION_REMARKS"
                            + ",LC_DETAILS.LC_REC_BIC_CODE"
                            + ",LC_DETAILS.LC_CFM_REIMB_TYPE"
                            + ",LC_DETAILS.LC_CFM_REIMB_BRN_CODE"
                            + ",LC_DETAILS.LC_CFM_REIMB_BIC_CODE"
                            + ",LC_DETAILS.LC_CFM_REIMB_ROUTID"
                            + ",LC_DETAILS.LC_CFM_REIMB_BNK_CODE"
                            + ",LC_DETAILS.LC_CFM_REIMB_ADDR1"
                            + ",LC_DETAILS.LC_CFM_REIMB_ADDR2"
                            + ",LC_DETAILS.LC_CFM_REIMB_ADDR3"
                            + ",LC_DETAILS.LC_CFM_REIMB_ADDR4"
                            + ",LC_DETAILS.LC_CFM_REIMB_ADDR5"
                            + ",LC_DETAILS.LC_CFM_REIMB_CNTRY_CODE";

    public LcDetails loadByKey(int _lcBrnCode, int _lcLcSl, String _lcLcType, int _lcLcYear) throws SQLException {
        Connection _conn = null;
        try {
            _conn = openConnection();
            LcDetails _obj = loadByKey(_lcBrnCode, _lcLcSl, _lcLcType, _lcLcYear, _conn);
            if ( _obj != null)
            {
            OldData_Key = "LC_DETAILS" + TableValueSep + OldDataChar + _obj.getLcBrnCode() + _obj.getLcLcType() + _obj.getLcLcYear() + _obj.getLcLcSl();
        DataBlock_Old = _obj.getLcBrnCode() + JNDINames.splitchar + _obj.getLcLcType() + JNDINames.splitchar + _obj.getLcLcYear() + JNDINames.splitchar + _obj.getLcLcSl() + JNDINames.splitchar + _obj.getLcFormOfDocCredit() + JNDINames.splitchar + _obj.getLcReferenceToPreadvice() + JNDINames.splitchar + _obj.getLcApplicableRules() + JNDINames.splitchar + _obj.getLcApplicantReq() + JNDINames.splitchar + _obj.getLcApplicantType() + JNDINames.splitchar + _obj.getLcApplicantBrnCode() + JNDINames.splitchar + _obj.getLcApplicantBicCode() + JNDINames.splitchar + _obj.getLcApplicantRoutid() + JNDINames.splitchar + _obj.getLcApplicantBnkCode() + JNDINames.splitchar + _obj.getLcApplicantAddr1() + JNDINames.splitchar + _obj.getLcApplicantAddr2() + JNDINames.splitchar + _obj.getLcApplicantAddr3() + JNDINames.splitchar + _obj.getLcApplicantAddr4() + JNDINames.splitchar + _obj.getLcApplicantAddr5() + JNDINames.splitchar + _obj.getLcAvailableWithType() + JNDINames.splitchar + _obj.getLcAvailableWithBrnCode() + JNDINames.splitchar + _obj.getLcAvailableWithCode() + JNDINames.splitchar + _obj.getLcAvailableWithRoutid() + JNDINames.splitchar + _obj.getLcAvailableWithBnkCode() + JNDINames.splitchar + _obj.getLcAvailableWithAddr1() + JNDINames.splitchar + _obj.getLcAvailableWithAddr2() + JNDINames.splitchar + _obj.getLcAvailableWithAddr3() + JNDINames.splitchar + _obj.getLcAvailableWithAddr4() + JNDINames.splitchar + _obj.getLcAvailableWithAddr5() + JNDINames.splitchar + _obj.getLcDraftsAt1() + JNDINames.splitchar + _obj.getLcDraftsAt2() + JNDINames.splitchar + _obj.getLcDraftsAt3() + JNDINames.splitchar + _obj.getLcDraweeReq() + JNDINames.splitchar + _obj.getLcDraweeType() + JNDINames.splitchar + _obj.getLcDraweeBrnCode() + JNDINames.splitchar + _obj.getLcDraweeBicCode() + JNDINames.splitchar + _obj.getLcDraweeRoutid() + JNDINames.splitchar + _obj.getLcDraweeBnkCode() + JNDINames.splitchar + _obj.getLcDraweeAddr1() + JNDINames.splitchar + _obj.getLcDraweeAddr2() + JNDINames.splitchar + _obj.getLcDraweeAddr3() + JNDINames.splitchar + _obj.getLcDraweeAddr4() + JNDINames.splitchar + _obj.getLcDraweeAddr5() + JNDINames.splitchar + _obj.getLcMixedPayDetails1() + JNDINames.splitchar + _obj.getLcMixedPayDetails2() + JNDINames.splitchar + _obj.getLcMixedPayDetails3() + JNDINames.splitchar + _obj.getLcMixedPayDetails4() + JNDINames.splitchar + _obj.getLcDeferredPayDetails1() + JNDINames.splitchar + _obj.getLcDeferredPayDetails2() + JNDINames.splitchar + _obj.getLcDeferredPayDetails3() + JNDINames.splitchar + _obj.getLcDeferredPayDetails4() + JNDINames.splitchar + _obj.getLcPartialShipments() + JNDINames.splitchar + _obj.getLcTranshipment() + JNDINames.splitchar + _obj.getLcPlaceOfTakingInCharge() + JNDINames.splitchar + _obj.getLcPortOfLoading() + JNDINames.splitchar + _obj.getLcPortOfDischarge() + JNDINames.splitchar + _obj.getLcPlaceOfFinalDest() + JNDINames.splitchar + _obj.getLcDescGoodsSer1() + JNDINames.splitchar + _obj.getLcDescGoodsSer2() + JNDINames.splitchar + _obj.getLcDescGoodsSer3() + JNDINames.splitchar + _obj.getLcDocReq1() + JNDINames.splitchar + _obj.getLcDocReq2() + JNDINames.splitchar + _obj.getLcDocReq3() + JNDINames.splitchar + _obj.getLcAddCondition1() + JNDINames.splitchar + _obj.getLcAddCondition2() + JNDINames.splitchar + _obj.getLcAddCondition3() + JNDINames.splitchar + _obj.getLcCharges1() + JNDINames.splitchar + _obj.getLcCharges2() + JNDINames.splitchar + _obj.getLcCharges3() + JNDINames.splitchar + _obj.getLcCharges4() + JNDINames.splitchar + _obj.getLcCharges5() + JNDINames.splitchar + _obj.getLcCharges6() + JNDINames.splitchar + _obj.getLcPerPresentationDay() + JNDINames.splitchar + _obj.getLcConfirmationInst() + JNDINames.splitchar + _obj.getLcReimbReq() + JNDINames.splitchar + _obj.getLcReimbType() + JNDINames.splitchar + _obj.getLcReimbBrnCode() + JNDINames.splitchar + _obj.getLcReimbBicCode() + JNDINames.splitchar + _obj.getLcReimbRoutid() + JNDINames.splitchar + _obj.getLcReimbBnkCode() + JNDINames.splitchar + _obj.getLcReimbAddr1() + JNDINames.splitchar + _obj.getLcReimbAddr2() + JNDINames.splitchar + _obj.getLcReimbAddr3() + JNDINames.splitchar + _obj.getLcReimbAddr4() + JNDINames.splitchar + _obj.getLcReimbAddr5() + JNDINames.splitchar + _obj.getLcInstPaying1() + JNDINames.splitchar + _obj.getLcInstPaying2() + JNDINames.splitchar + _obj.getLcInstPaying3() + JNDINames.splitchar + _obj.getLcInstPaying4() + JNDINames.splitchar + _obj.getLcInstPaying5() + JNDINames.splitchar + _obj.getLcInstPaying6() + JNDINames.splitchar + _obj.getLcInstPaying7() + JNDINames.splitchar + _obj.getLcInstPaying8() + JNDINames.splitchar + _obj.getLcInstPaying9() + JNDINames.splitchar + _obj.getLcInstPaying10() + JNDINames.splitchar + _obj.getLcInstPaying11() + JNDINames.splitchar + _obj.getLcInstPaying12() + JNDINames.splitchar + _obj.getLcSecondAdvReq() + JNDINames.splitchar + _obj.getLcSecondAdvType() + JNDINames.splitchar + _obj.getLcSecondAdvBrnCode() + JNDINames.splitchar + _obj.getLcSecondAdvBicCode() + JNDINames.splitchar + _obj.getLcSecondAdvRoutid() + JNDINames.splitchar + _obj.getLcSecondAdvBnkCode() + JNDINames.splitchar + _obj.getLcSecondAdvAddr1() + JNDINames.splitchar + _obj.getLcSecondAdvAddr2() + JNDINames.splitchar + _obj.getLcSecondAdvAddr3() + JNDINames.splitchar + _obj.getLcSecondAdvAddr4() + JNDINames.splitchar + _obj.getLcSecondAdvAddr5() + JNDINames.splitchar + _obj.getLcSndrRecInfo1() + JNDINames.splitchar + _obj.getLcSndrRecInfo2() + JNDINames.splitchar + _obj.getLcSndrRecInfo3() + JNDINames.splitchar + _obj.getLcSndrRecInfo4() + JNDINames.splitchar + _obj.getLcSndrRecInfo5() + JNDINames.splitchar + _obj.getLcSndrRecInfo6() + JNDINames.splitchar + _obj.getLcApplicantCntryCode() + JNDINames.splitchar + _obj.getLcAvailableWithCntry() + JNDINames.splitchar + _obj.getLcAvailableWithCodetyp() + JNDINames.splitchar + _obj.getLcDraweeCntryCode() + JNDINames.splitchar + _obj.getLcConfirmInstType() + JNDINames.splitchar + _obj.getLcReimbCntryCode() + JNDINames.splitchar + _obj.getLcSecondAdvCntrycode() + JNDINames.splitchar + _obj.getLcShipmentPeriod1() + JNDINames.splitchar + _obj.getLcShipmentPeriod2() + JNDINames.splitchar + _obj.getLcShipmentPeriod3() + JNDINames.splitchar + _obj.getLcShipmentPeriod4() + JNDINames.splitchar + _obj.getLcShipmentPeriod5() + JNDINames.splitchar + _obj.getLcShipmentPeriod6() + JNDINames.splitchar + _obj.getLcPerPresentationRemarks() + JNDINames.splitchar + _obj.getLcRecBicCode() + JNDINames.splitchar + _obj.getLcCfmReimbType() + JNDINames.splitchar + _obj.getLcCfmReimbBrnCode() + JNDINames.splitchar + _obj.getLcCfmReimbBicCode() + JNDINames.splitchar + _obj.getLcCfmReimbRoutid() + JNDINames.splitchar + _obj.getLcCfmReimbBnkCode() + JNDINames.splitchar + _obj.getLcCfmReimbAddr1() + JNDINames.splitchar + _obj.getLcCfmReimbAddr2() + JNDINames.splitchar + _obj.getLcCfmReimbAddr3() + JNDINames.splitchar + _obj.getLcCfmReimbAddr4() + JNDINames.splitchar + _obj.getLcCfmReimbAddr5() + JNDINames.splitchar + _obj.getLcCfmReimbCntryCode();
        }
            closeConnection(_conn);
            return _obj;
        }
        catch(SQLException e) {
            if(_conn != null)  try { closeConnection(_conn); } catch(SQLException e2) { }
            throw e;
        }
    }

    public LcDetails loadByKey(int _lcBrnCode, int _lcLcSl, String _lcLcType, int _lcLcYear, Connection _conn) throws SQLException {
        PreparedStatement _pstmt = null;
        try {
            _pstmt = _conn.prepareStatement("SELECT " + ALL_FIELDS + " FROM LC_DETAILS WHERE LC_DETAILS.LC_BRN_CODE=? and LC_DETAILS.LC_LC_SL=? and LC_DETAILS.LC_LC_TYPE=? and LC_DETAILS.LC_LC_YEAR=?");
            _pstmt.setInt(1, _lcBrnCode);
            _pstmt.setInt(2, _lcLcSl);
            _pstmt.setString(3, _lcLcType);
            _pstmt.setInt(4, _lcLcYear);
            LcDetails _list[] = loadByPreparedStatement(_pstmt);
            _pstmt.close();
            if(_list.length < 1) return null;
            else                 return _list[0];
        }
        catch(SQLException e) {
            if(_pstmt != null) try { _pstmt.close(); } catch(SQLException e2) { }
            throw e;
        }
    }

    public LcDetails[] loadAll() throws SQLException {
        Connection _conn = null;
        try {
            _conn = openConnection();
            LcDetails _list[] = loadAll(_conn);
            closeConnection(_conn);
            return _list;
        }
        catch(SQLException e) {
            if(_conn != null)  try { closeConnection(_conn); } catch(SQLException e2) { }
            throw e;
        }
    }

    public LcDetails[] loadAll(Connection _conn) throws SQLException {
        PreparedStatement _pstmt = null;
        try {
            _pstmt = _conn.prepareStatement("SELECT " + ALL_FIELDS + " FROM LC_DETAILS");
            LcDetails _list[] = loadByPreparedStatement(_pstmt);
            _pstmt.close();
            return _list;
        }
        catch(SQLException e) {
            if(_pstmt != null) try { _pstmt.close(); } catch(SQLException e2) { }
            throw e;
        }
    }

    public LcDetails[] loadByPreparedStatement(PreparedStatement pstmt) throws SQLException {
        return loadByPreparedStatement(pstmt, null, 0);
    }

    public LcDetails[] loadByPreparedStatement(PreparedStatement pstmt, int maxRows) throws SQLException {
        return loadByPreparedStatement(pstmt, null, maxRows);
    }

    public LcDetails[] loadByPreparedStatement(PreparedStatement pstmt, int[] fieldList) throws SQLException {
        return loadByPreparedStatement(pstmt, fieldList, 0);
    }

    public LcDetails[] loadByPreparedStatement(PreparedStatement pstmt, int[] fieldList, int maxRows) throws SQLException {
        ResultSet rs = null;
        try {
            rs = pstmt.executeQuery();
            java.util.Vector v = new java.util.Vector();
            while(rs.next() && (maxRows == 0 || v.size() < maxRows)) {
                if(fieldList == null) v.addElement(decodeRow(rs));
                else v.addElement(decodeRow(rs, fieldList));
            }
            rs.close();
            LcDetails list[] = new LcDetails[v.size()];
            v.copyInto(list);
            return list;
        }
        catch(SQLException e) {
            if(rs!=null) try { rs.close();} catch(Exception e2) {}
            throw e;
        }
    }

    public LcDetails[] loadByWhere(String where) throws SQLException {
        return loadByWhere(where, (int[])null, 0);
    }
    public LcDetails[] loadByWhere(String where, int maxRows) throws SQLException {
        return loadByWhere(where, (int[])null, maxRows);
    }
    public LcDetails[] loadByWhere(String where, int[] fieldList) throws SQLException {
        return loadByWhere(where, fieldList, 0);
    }
    public LcDetails[] loadByWhere(String where, int[] fieldList, int maxRows) throws SQLException {
        Connection conn = null;
        try {
            conn = openConnection();
            LcDetails _list[] = loadByWhere(where, conn, fieldList, maxRows);
            closeConnection(conn);
            return _list;
        }
        catch(SQLException e) {
            if(conn!=null) try { closeConnection(conn);} catch(Exception e2) {}
            throw e;
        }
    }

    public LcDetails[] loadByWhere(String where, Connection conn) throws SQLException {
        return loadByWhere(where, conn, null, 0);
    }

    public LcDetails[] loadByWhere(String where, Connection conn, int[] fieldList) throws SQLException {
        return loadByWhere(where, conn, fieldList, 0);
    }

    public LcDetails[] loadByWhere(String where, Connection conn, int[] fieldList, int maxRows) throws SQLException {
        String sql = null;
        if(fieldList == null) sql = "select " + ALL_FIELDS + " from LC_DETAILS " + where;
        else {
            StringBuffer buff = new StringBuffer(128);
            buff.append("select ");
            for(int i = 0; i < fieldList.length; i++) {
                if(i != 0) buff.append(",");
                buff.append(S2J_FIELD_NAMES[fieldList[i]]);
            }
            buff.append(" from LC_DETAILS ");
            buff.append(where);
            sql = buff.toString();
        }
        Statement stmt = null;
        ResultSet rs = null;
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            java.util.Vector v = new java.util.Vector();
            while(rs.next() && (maxRows == 0 || v.size() < maxRows)) {
                if(fieldList == null) v.addElement(decodeRow(rs));
                else v.addElement(decodeRow(rs, fieldList));
            }
            rs.close();
            stmt.close();

            LcDetails _list[] = new LcDetails[v.size()];
            v.copyInto(_list);
            return _list;
        }
        catch(SQLException e) {
            if(rs!=null) try { rs.close();} catch(Exception e2) {}
            if(stmt!=null) try { stmt.close();} catch(Exception e2) {}
            throw e;
        }
    }

    public int UpdateByQuery(String w_sql) throws SQLException {
        Connection _conn = null;
        PreparedStatement _pstmt = null;
            try {
                _conn = openConnection();
                _pstmt = _conn.prepareStatement(w_sql);
                int _rows = _pstmt.executeUpdate();
                closeConnection(_conn);
                return 1;
            }
            catch(SQLException e) {
                if(_pstmt!=null) try { _pstmt.close();} catch(Exception e2) {}
                if(_conn!=null) try { closeConnection(_conn);} catch(Exception e2) {}
                throw e;
            }
    }
    public int deleteByKey(int _lcBrnCode, int _lcLcSl, String _lcLcType, int _lcLcYear) throws SQLException {
        Connection _conn = null;
        try {
            _conn = openConnection();
            int _rows = deleteByKey(_lcBrnCode, _lcLcSl, _lcLcType, _lcLcYear, _conn);
            closeConnection(_conn);
            return _rows;
        }
        catch(SQLException e) {
            if(_conn!=null) try { closeConnection(_conn);} catch(Exception e2) {}
            throw e;
        }
    }

    public int deleteByKey(int _lcBrnCode, int _lcLcSl, String _lcLcType, int _lcLcYear, Connection _conn) throws SQLException {
        PreparedStatement _pstmt = null;
        try {
        LcDetails _obj  = loadByKey(_lcBrnCode, _lcLcSl, _lcLcType, _lcLcYear);
        _obj  = null;
            _pstmt = _conn.prepareStatement("DELETE FROM LC_DETAILS WHERE LC_DETAILS.LC_BRN_CODE=? and LC_DETAILS.LC_LC_SL=? and LC_DETAILS.LC_LC_TYPE=? and LC_DETAILS.LC_LC_YEAR=?");
            _pstmt.setInt(1, _lcBrnCode);
            _pstmt.setInt(2, _lcLcSl);
            _pstmt.setString(3, _lcLcType);
            _pstmt.setInt(4, _lcLcYear);
            int _rows = _pstmt.executeUpdate();
            _pstmt.close();
            return _rows;
        }
        catch(SQLException e) {
            if(_pstmt!=null) try { _pstmt.close();} catch(Exception e2) {}
            throw e;
        }
    }

    public void save(LcDetails obj) throws SQLException {
//        _srcTablePKI = "LCDETAILS";
//        _srcKeyPKI = obj.getLcBrnCode() + JNDINames.splitchar + obj.getLcLcType() + JNDINames.splitchar + obj.getLcLcYear() + JNDINames.splitchar + obj.getLcLcSl();
//        set_pki_values(this._COLLECTIONobj);
        if(!obj.isModifiedS2J()) return;
        Connection _conn = null;
        try {
            _conn = openConnection();
            save(obj, _conn);
            closeConnection(_conn);
        }
        catch(SQLException e) {
            if(_conn!=null) try { closeConnection(_conn);} catch(Exception e2) {}
            throw e;
        }
    }

    public void save(LcDetails obj, Connection _conn) throws SQLException {
        PreparedStatement _pstmt = null;
        try {
            if(obj.isNew()) {
                int _dirtyCount = 0;
                StringBuffer _sql = new StringBuffer("INSERT into LC_DETAILS (");
                if(obj.lcBrnCodeIsModifiedS2j()) {  _sql.append("LC_BRN_CODE").append(","); _dirtyCount++; }
                if(obj.lcLcTypeIsModifiedS2j()) {  _sql.append("LC_LC_TYPE").append(","); _dirtyCount++; }
                if(obj.lcLcYearIsModifiedS2j()) {  _sql.append("LC_LC_YEAR").append(","); _dirtyCount++; }
                if(obj.lcLcSlIsModifiedS2j()) {  _sql.append("LC_LC_SL").append(","); _dirtyCount++; }
                if(obj.lcFormOfDocCreditIsModifiedS2j()) {  _sql.append("LC_FORM_OF_DOC_CREDIT").append(","); _dirtyCount++; }
                if(obj.lcReferenceToPreadviceIsModifiedS2j()) {  _sql.append("LC_REFERENCE_TO_PREADVICE").append(","); _dirtyCount++; }
                if(obj.lcApplicableRulesIsModifiedS2j()) {  _sql.append("LC_APPLICABLE_RULES").append(","); _dirtyCount++; }
                if(obj.lcApplicantReqIsModifiedS2j()) {  _sql.append("LC_APPLICANT_REQ").append(","); _dirtyCount++; }
                if(obj.lcApplicantTypeIsModifiedS2j()) {  _sql.append("LC_APPLICANT_TYPE").append(","); _dirtyCount++; }
                if(obj.lcApplicantBrnCodeIsModifiedS2j()) {  _sql.append("LC_APPLICANT_BRN_CODE").append(","); _dirtyCount++; }
                if(obj.lcApplicantBicCodeIsModifiedS2j()) {  _sql.append("LC_APPLICANT_BIC_CODE").append(","); _dirtyCount++; }
                if(obj.lcApplicantRoutidIsModifiedS2j()) {  _sql.append("LC_APPLICANT_ROUTID").append(","); _dirtyCount++; }
                if(obj.lcApplicantBnkCodeIsModifiedS2j()) {  _sql.append("LC_APPLICANT_BNK_CODE").append(","); _dirtyCount++; }
                if(obj.lcApplicantAddr1IsModifiedS2j()) {  _sql.append("LC_APPLICANT_ADDR1").append(","); _dirtyCount++; }
                if(obj.lcApplicantAddr2IsModifiedS2j()) {  _sql.append("LC_APPLICANT_ADDR2").append(","); _dirtyCount++; }
                if(obj.lcApplicantAddr3IsModifiedS2j()) {  _sql.append("LC_APPLICANT_ADDR3").append(","); _dirtyCount++; }
                if(obj.lcApplicantAddr4IsModifiedS2j()) {  _sql.append("LC_APPLICANT_ADDR4").append(","); _dirtyCount++; }
                if(obj.lcApplicantAddr5IsModifiedS2j()) {  _sql.append("LC_APPLICANT_ADDR5").append(","); _dirtyCount++; }
                if(obj.lcAvailableWithTypeIsModifiedS2j()) {  _sql.append("LC_AVAILABLE_WITH_TYPE").append(","); _dirtyCount++; }
                if(obj.lcAvailableWithBrnCodeIsModifiedS2j()) {  _sql.append("LC_AVAILABLE_WITH_BRN_CODE").append(","); _dirtyCount++; }
                if(obj.lcAvailableWithCodeIsModifiedS2j()) {  _sql.append("LC_AVAILABLE_WITH_CODE").append(","); _dirtyCount++; }
                if(obj.lcAvailableWithRoutidIsModifiedS2j()) {  _sql.append("LC_AVAILABLE_WITH_ROUTID").append(","); _dirtyCount++; }
                if(obj.lcAvailableWithBnkCodeIsModifiedS2j()) {  _sql.append("LC_AVAILABLE_WITH_BNK_CODE").append(","); _dirtyCount++; }
                if(obj.lcAvailableWithAddr1IsModifiedS2j()) {  _sql.append("LC_AVAILABLE_WITH_ADDR1").append(","); _dirtyCount++; }
                if(obj.lcAvailableWithAddr2IsModifiedS2j()) {  _sql.append("LC_AVAILABLE_WITH_ADDR2").append(","); _dirtyCount++; }
                if(obj.lcAvailableWithAddr3IsModifiedS2j()) {  _sql.append("LC_AVAILABLE_WITH_ADDR3").append(","); _dirtyCount++; }
                if(obj.lcAvailableWithAddr4IsModifiedS2j()) {  _sql.append("LC_AVAILABLE_WITH_ADDR4").append(","); _dirtyCount++; }
                if(obj.lcAvailableWithAddr5IsModifiedS2j()) {  _sql.append("LC_AVAILABLE_WITH_ADDR5").append(","); _dirtyCount++; }
                if(obj.lcDraftsAt1IsModifiedS2j()) {  _sql.append("LC_DRAFTS_AT1").append(","); _dirtyCount++; }
                if(obj.lcDraftsAt2IsModifiedS2j()) {  _sql.append("LC_DRAFTS_AT2").append(","); _dirtyCount++; }
                if(obj.lcDraftsAt3IsModifiedS2j()) {  _sql.append("LC_DRAFTS_AT3").append(","); _dirtyCount++; }
                if(obj.lcDraweeReqIsModifiedS2j()) {  _sql.append("LC_DRAWEE_REQ").append(","); _dirtyCount++; }
                if(obj.lcDraweeTypeIsModifiedS2j()) {  _sql.append("LC_DRAWEE_TYPE").append(","); _dirtyCount++; }
                if(obj.lcDraweeBrnCodeIsModifiedS2j()) {  _sql.append("LC_DRAWEE_BRN_CODE").append(","); _dirtyCount++; }
                if(obj.lcDraweeBicCodeIsModifiedS2j()) {  _sql.append("LC_DRAWEE_BIC_CODE").append(","); _dirtyCount++; }
                if(obj.lcDraweeRoutidIsModifiedS2j()) {  _sql.append("LC_DRAWEE_ROUTID").append(","); _dirtyCount++; }
                if(obj.lcDraweeBnkCodeIsModifiedS2j()) {  _sql.append("LC_DRAWEE_BNK_CODE").append(","); _dirtyCount++; }
                if(obj.lcDraweeAddr1IsModifiedS2j()) {  _sql.append("LC_DRAWEE_ADDR1").append(","); _dirtyCount++; }
                if(obj.lcDraweeAddr2IsModifiedS2j()) {  _sql.append("LC_DRAWEE_ADDR2").append(","); _dirtyCount++; }
                if(obj.lcDraweeAddr3IsModifiedS2j()) {  _sql.append("LC_DRAWEE_ADDR3").append(","); _dirtyCount++; }
                if(obj.lcDraweeAddr4IsModifiedS2j()) {  _sql.append("LC_DRAWEE_ADDR4").append(","); _dirtyCount++; }
                if(obj.lcDraweeAddr5IsModifiedS2j()) {  _sql.append("LC_DRAWEE_ADDR5").append(","); _dirtyCount++; }
                if(obj.lcMixedPayDetails1IsModifiedS2j()) {  _sql.append("LC_MIXED_PAY_DETAILS1").append(","); _dirtyCount++; }
                if(obj.lcMixedPayDetails2IsModifiedS2j()) {  _sql.append("LC_MIXED_PAY_DETAILS2").append(","); _dirtyCount++; }
                if(obj.lcMixedPayDetails3IsModifiedS2j()) {  _sql.append("LC_MIXED_PAY_DETAILS3").append(","); _dirtyCount++; }
                if(obj.lcMixedPayDetails4IsModifiedS2j()) {  _sql.append("LC_MIXED_PAY_DETAILS4").append(","); _dirtyCount++; }
                if(obj.lcDeferredPayDetails1IsModifiedS2j()) {  _sql.append("LC_DEFERRED_PAY_DETAILS1").append(","); _dirtyCount++; }
                if(obj.lcDeferredPayDetails2IsModifiedS2j()) {  _sql.append("LC_DEFERRED_PAY_DETAILS2").append(","); _dirtyCount++; }
                if(obj.lcDeferredPayDetails3IsModifiedS2j()) {  _sql.append("LC_DEFERRED_PAY_DETAILS3").append(","); _dirtyCount++; }
                if(obj.lcDeferredPayDetails4IsModifiedS2j()) {  _sql.append("LC_DEFERRED_PAY_DETAILS4").append(","); _dirtyCount++; }
                if(obj.lcPartialShipmentsIsModifiedS2j()) {  _sql.append("LC_PARTIAL_SHIPMENTS").append(","); _dirtyCount++; }
                if(obj.lcTranshipmentIsModifiedS2j()) {  _sql.append("LC_TRANSHIPMENT").append(","); _dirtyCount++; }
                if(obj.lcPlaceOfTakingInChargeIsModifiedS2j()) {  _sql.append("LC_PLACE_OF_TAKING_IN_CHARGE").append(","); _dirtyCount++; }
                if(obj.lcPortOfLoadingIsModifiedS2j()) {  _sql.append("LC_PORT_OF_LOADING").append(","); _dirtyCount++; }
                if(obj.lcPortOfDischargeIsModifiedS2j()) {  _sql.append("LC_PORT_OF_DISCHARGE").append(","); _dirtyCount++; }
                if(obj.lcPlaceOfFinalDestIsModifiedS2j()) {  _sql.append("LC_PLACE_OF_FINAL_DEST").append(","); _dirtyCount++; }
                if(obj.lcDescGoodsSer1IsModifiedS2j()) {  _sql.append("LC_DESC_GOODS_SER1").append(","); _dirtyCount++; }
                if(obj.lcDescGoodsSer2IsModifiedS2j()) {  _sql.append("LC_DESC_GOODS_SER2").append(","); _dirtyCount++; }
                if(obj.lcDescGoodsSer3IsModifiedS2j()) {  _sql.append("LC_DESC_GOODS_SER3").append(","); _dirtyCount++; }
                if(obj.lcDocReq1IsModifiedS2j()) {  _sql.append("LC_DOC_REQ1").append(","); _dirtyCount++; }
                if(obj.lcDocReq2IsModifiedS2j()) {  _sql.append("LC_DOC_REQ2").append(","); _dirtyCount++; }
                if(obj.lcDocReq3IsModifiedS2j()) {  _sql.append("LC_DOC_REQ3").append(","); _dirtyCount++; }
                if(obj.lcAddCondition1IsModifiedS2j()) {  _sql.append("LC_ADD_CONDITION1").append(","); _dirtyCount++; }
                if(obj.lcAddCondition2IsModifiedS2j()) {  _sql.append("LC_ADD_CONDITION2").append(","); _dirtyCount++; }
                if(obj.lcAddCondition3IsModifiedS2j()) {  _sql.append("LC_ADD_CONDITION3").append(","); _dirtyCount++; }
                if(obj.lcCharges1IsModifiedS2j()) {  _sql.append("LC_CHARGES1").append(","); _dirtyCount++; }
                if(obj.lcCharges2IsModifiedS2j()) {  _sql.append("LC_CHARGES2").append(","); _dirtyCount++; }
                if(obj.lcCharges3IsModifiedS2j()) {  _sql.append("LC_CHARGES3").append(","); _dirtyCount++; }
                if(obj.lcCharges4IsModifiedS2j()) {  _sql.append("LC_CHARGES4").append(","); _dirtyCount++; }
                if(obj.lcCharges5IsModifiedS2j()) {  _sql.append("LC_CHARGES5").append(","); _dirtyCount++; }
                if(obj.lcCharges6IsModifiedS2j()) {  _sql.append("LC_CHARGES6").append(","); _dirtyCount++; }
                if(obj.lcPerPresentationDayIsModifiedS2j()) {  _sql.append("LC_PER_PRESENTATION_DAY").append(","); _dirtyCount++; }
                if(obj.lcConfirmationInstIsModifiedS2j()) {  _sql.append("LC_CONFIRMATION_INST").append(","); _dirtyCount++; }
                if(obj.lcReimbReqIsModifiedS2j()) {  _sql.append("LC_REIMB_REQ").append(","); _dirtyCount++; }
                if(obj.lcReimbTypeIsModifiedS2j()) {  _sql.append("LC_REIMB_TYPE").append(","); _dirtyCount++; }
                if(obj.lcReimbBrnCodeIsModifiedS2j()) {  _sql.append("LC_REIMB_BRN_CODE").append(","); _dirtyCount++; }
                if(obj.lcReimbBicCodeIsModifiedS2j()) {  _sql.append("LC_REIMB_BIC_CODE").append(","); _dirtyCount++; }
                if(obj.lcReimbRoutidIsModifiedS2j()) {  _sql.append("LC_REIMB_ROUTID").append(","); _dirtyCount++; }
                if(obj.lcReimbBnkCodeIsModifiedS2j()) {  _sql.append("LC_REIMB_BNK_CODE").append(","); _dirtyCount++; }
                if(obj.lcReimbAddr1IsModifiedS2j()) {  _sql.append("LC_REIMB_ADDR1").append(","); _dirtyCount++; }
                if(obj.lcReimbAddr2IsModifiedS2j()) {  _sql.append("LC_REIMB_ADDR2").append(","); _dirtyCount++; }
                if(obj.lcReimbAddr3IsModifiedS2j()) {  _sql.append("LC_REIMB_ADDR3").append(","); _dirtyCount++; }
                if(obj.lcReimbAddr4IsModifiedS2j()) {  _sql.append("LC_REIMB_ADDR4").append(","); _dirtyCount++; }
                if(obj.lcReimbAddr5IsModifiedS2j()) {  _sql.append("LC_REIMB_ADDR5").append(","); _dirtyCount++; }
                if(obj.lcInstPaying1IsModifiedS2j()) {  _sql.append("LC_INST_PAYING1").append(","); _dirtyCount++; }
                if(obj.lcInstPaying2IsModifiedS2j()) {  _sql.append("LC_INST_PAYING2").append(","); _dirtyCount++; }
                if(obj.lcInstPaying3IsModifiedS2j()) {  _sql.append("LC_INST_PAYING3").append(","); _dirtyCount++; }
                if(obj.lcInstPaying4IsModifiedS2j()) {  _sql.append("LC_INST_PAYING4").append(","); _dirtyCount++; }
                if(obj.lcInstPaying5IsModifiedS2j()) {  _sql.append("LC_INST_PAYING5").append(","); _dirtyCount++; }
                if(obj.lcInstPaying6IsModifiedS2j()) {  _sql.append("LC_INST_PAYING6").append(","); _dirtyCount++; }
                if(obj.lcInstPaying7IsModifiedS2j()) {  _sql.append("LC_INST_PAYING7").append(","); _dirtyCount++; }
                if(obj.lcInstPaying8IsModifiedS2j()) {  _sql.append("LC_INST_PAYING8").append(","); _dirtyCount++; }
                if(obj.lcInstPaying9IsModifiedS2j()) {  _sql.append("LC_INST_PAYING9").append(","); _dirtyCount++; }
                if(obj.lcInstPaying10IsModifiedS2j()) {  _sql.append("LC_INST_PAYING10").append(","); _dirtyCount++; }
                if(obj.lcInstPaying11IsModifiedS2j()) {  _sql.append("LC_INST_PAYING11").append(","); _dirtyCount++; }
                if(obj.lcInstPaying12IsModifiedS2j()) {  _sql.append("LC_INST_PAYING12").append(","); _dirtyCount++; }
                if(obj.lcSecondAdvReqIsModifiedS2j()) {  _sql.append("LC_SECOND_ADV_REQ").append(","); _dirtyCount++; }
                if(obj.lcSecondAdvTypeIsModifiedS2j()) {  _sql.append("LC_SECOND_ADV_TYPE").append(","); _dirtyCount++; }
                if(obj.lcSecondAdvBrnCodeIsModifiedS2j()) {  _sql.append("LC_SECOND_ADV_BRN_CODE").append(","); _dirtyCount++; }
                if(obj.lcSecondAdvBicCodeIsModifiedS2j()) {  _sql.append("LC_SECOND_ADV_BIC_CODE").append(","); _dirtyCount++; }
                if(obj.lcSecondAdvRoutidIsModifiedS2j()) {  _sql.append("LC_SECOND_ADV_ROUTID").append(","); _dirtyCount++; }
                if(obj.lcSecondAdvBnkCodeIsModifiedS2j()) {  _sql.append("LC_SECOND_ADV_BNK_CODE").append(","); _dirtyCount++; }
                if(obj.lcSecondAdvAddr1IsModifiedS2j()) {  _sql.append("LC_SECOND_ADV_ADDR1").append(","); _dirtyCount++; }
                if(obj.lcSecondAdvAddr2IsModifiedS2j()) {  _sql.append("LC_SECOND_ADV_ADDR2").append(","); _dirtyCount++; }
                if(obj.lcSecondAdvAddr3IsModifiedS2j()) {  _sql.append("LC_SECOND_ADV_ADDR3").append(","); _dirtyCount++; }
                if(obj.lcSecondAdvAddr4IsModifiedS2j()) {  _sql.append("LC_SECOND_ADV_ADDR4").append(","); _dirtyCount++; }
                if(obj.lcSecondAdvAddr5IsModifiedS2j()) {  _sql.append("LC_SECOND_ADV_ADDR5").append(","); _dirtyCount++; }
                if(obj.lcSndrRecInfo1IsModifiedS2j()) {  _sql.append("LC_SNDR_REC_INFO1").append(","); _dirtyCount++; }
                if(obj.lcSndrRecInfo2IsModifiedS2j()) {  _sql.append("LC_SNDR_REC_INFO2").append(","); _dirtyCount++; }
                if(obj.lcSndrRecInfo3IsModifiedS2j()) {  _sql.append("LC_SNDR_REC_INFO3").append(","); _dirtyCount++; }
                if(obj.lcSndrRecInfo4IsModifiedS2j()) {  _sql.append("LC_SNDR_REC_INFO4").append(","); _dirtyCount++; }
                if(obj.lcSndrRecInfo5IsModifiedS2j()) {  _sql.append("LC_SNDR_REC_INFO5").append(","); _dirtyCount++; }
                if(obj.lcSndrRecInfo6IsModifiedS2j()) {  _sql.append("LC_SNDR_REC_INFO6").append(","); _dirtyCount++; }
                if(obj.lcApplicantCntryCodeIsModifiedS2j()) {  _sql.append("LC_APPLICANT_CNTRY_CODE").append(","); _dirtyCount++; }
                if(obj.lcAvailableWithCntryIsModifiedS2j()) {  _sql.append("LC_AVAILABLE_WITH_CNTRY").append(","); _dirtyCount++; }
                if(obj.lcAvailableWithCodetypIsModifiedS2j()) {  _sql.append("LC_AVAILABLE_WITH_CODETYP").append(","); _dirtyCount++; }
                if(obj.lcDraweeCntryCodeIsModifiedS2j()) {  _sql.append("LC_DRAWEE_CNTRY_CODE").append(","); _dirtyCount++; }
                if(obj.lcConfirmInstTypeIsModifiedS2j()) {  _sql.append("LC_CONFIRM_INST_TYPE").append(","); _dirtyCount++; }
                if(obj.lcReimbCntryCodeIsModifiedS2j()) {  _sql.append("LC_REIMB_CNTRY_CODE").append(","); _dirtyCount++; }
                if(obj.lcSecondAdvCntrycodeIsModifiedS2j()) {  _sql.append("LC_SECOND_ADV_CNTRYCODE").append(","); _dirtyCount++; }
                if(obj.lcShipmentPeriod1IsModifiedS2j()) {  _sql.append("LC_SHIPMENT_PERIOD1").append(","); _dirtyCount++; }
                if(obj.lcShipmentPeriod2IsModifiedS2j()) {  _sql.append("LC_SHIPMENT_PERIOD2").append(","); _dirtyCount++; }
                if(obj.lcShipmentPeriod3IsModifiedS2j()) {  _sql.append("LC_SHIPMENT_PERIOD3").append(","); _dirtyCount++; }
                if(obj.lcShipmentPeriod4IsModifiedS2j()) {  _sql.append("LC_SHIPMENT_PERIOD4").append(","); _dirtyCount++; }
                if(obj.lcShipmentPeriod5IsModifiedS2j()) {  _sql.append("LC_SHIPMENT_PERIOD5").append(","); _dirtyCount++; }
                if(obj.lcShipmentPeriod6IsModifiedS2j()) {  _sql.append("LC_SHIPMENT_PERIOD6").append(","); _dirtyCount++; }
                if(obj.lcPerPresentationRemarksIsModifiedS2j()) {  _sql.append("LC_PER_PRESENTATION_REMARKS").append(","); _dirtyCount++; }
                if(obj.lcRecBicCodeIsModifiedS2j()) {  _sql.append("LC_REC_BIC_CODE").append(","); _dirtyCount++; }
                if(obj.lcCfmReimbTypeIsModifiedS2j()) {  _sql.append("LC_CFM_REIMB_TYPE").append(","); _dirtyCount++; }
                if(obj.lcCfmReimbBrnCodeIsModifiedS2j()) {  _sql.append("LC_CFM_REIMB_BRN_CODE").append(","); _dirtyCount++; }
                if(obj.lcCfmReimbBicCodeIsModifiedS2j()) {  _sql.append("LC_CFM_REIMB_BIC_CODE").append(","); _dirtyCount++; }
                if(obj.lcCfmReimbRoutidIsModifiedS2j()) {  _sql.append("LC_CFM_REIMB_ROUTID").append(","); _dirtyCount++; }
                if(obj.lcCfmReimbBnkCodeIsModifiedS2j()) {  _sql.append("LC_CFM_REIMB_BNK_CODE").append(","); _dirtyCount++; }
                if(obj.lcCfmReimbAddr1IsModifiedS2j()) {  _sql.append("LC_CFM_REIMB_ADDR1").append(","); _dirtyCount++; }
                if(obj.lcCfmReimbAddr2IsModifiedS2j()) {  _sql.append("LC_CFM_REIMB_ADDR2").append(","); _dirtyCount++; }
                if(obj.lcCfmReimbAddr3IsModifiedS2j()) {  _sql.append("LC_CFM_REIMB_ADDR3").append(","); _dirtyCount++; }
                if(obj.lcCfmReimbAddr4IsModifiedS2j()) {  _sql.append("LC_CFM_REIMB_ADDR4").append(","); _dirtyCount++; }
                if(obj.lcCfmReimbAddr5IsModifiedS2j()) {  _sql.append("LC_CFM_REIMB_ADDR5").append(","); _dirtyCount++; }
                if(obj.lcCfmReimbCntryCodeIsModifiedS2j()) {  _sql.append("LC_CFM_REIMB_CNTRY_CODE").append(","); _dirtyCount++; }
                _sql.setLength(_sql.length() - 1);
                _sql.append(") values (" );
                for(int i = 0; i < _dirtyCount; i++) _sql.append("?,");
                _sql.setLength(_sql.length() - 1);
                _sql.append(")");

                _pstmt = _conn.prepareStatement(_sql.toString());
                _dirtyCount = 0;
                if(obj.lcBrnCodeIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLcBrnCode()); } 
                if(obj.lcLcTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcLcType()); } 
                if(obj.lcLcYearIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLcLcYear()); } 
                if(obj.lcLcSlIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLcLcSl()); } 
                if(obj.lcFormOfDocCreditIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLcFormOfDocCredit()); } 
                if(obj.lcReferenceToPreadviceIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcReferenceToPreadvice()); } 
                if(obj.lcApplicableRulesIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLcApplicableRules()); } 
                if(obj.lcApplicantReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLcApplicantReq())); } 
                if(obj.lcApplicantTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLcApplicantType())); } 
                if(obj.lcApplicantBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcApplicantBrnCode()); } 
                if(obj.lcApplicantBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcApplicantBicCode()); } 
                if(obj.lcApplicantRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcApplicantRoutid()); } 
                if(obj.lcApplicantBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcApplicantBnkCode()); } 
                if(obj.lcApplicantAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcApplicantAddr1()); } 
                if(obj.lcApplicantAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcApplicantAddr2()); } 
                if(obj.lcApplicantAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcApplicantAddr3()); } 
                if(obj.lcApplicantAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcApplicantAddr4()); } 
                if(obj.lcApplicantAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcApplicantAddr5()); } 
                if(obj.lcAvailableWithTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLcAvailableWithType())); } 
                if(obj.lcAvailableWithBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcAvailableWithBrnCode()); } 
                if(obj.lcAvailableWithCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcAvailableWithCode()); } 
                if(obj.lcAvailableWithRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcAvailableWithRoutid()); } 
                if(obj.lcAvailableWithBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcAvailableWithBnkCode()); } 
                if(obj.lcAvailableWithAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcAvailableWithAddr1()); } 
                if(obj.lcAvailableWithAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcAvailableWithAddr2()); } 
                if(obj.lcAvailableWithAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcAvailableWithAddr3()); } 
                if(obj.lcAvailableWithAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcAvailableWithAddr4()); } 
                if(obj.lcAvailableWithAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcAvailableWithAddr5()); } 
                if(obj.lcDraftsAt1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcDraftsAt1()); } 
                if(obj.lcDraftsAt2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcDraftsAt2()); } 
                if(obj.lcDraftsAt3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcDraftsAt3()); } 
                if(obj.lcDraweeReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLcDraweeReq())); } 
                if(obj.lcDraweeTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLcDraweeType())); } 
                if(obj.lcDraweeBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcDraweeBrnCode()); } 
                if(obj.lcDraweeBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcDraweeBicCode()); } 
                if(obj.lcDraweeRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcDraweeRoutid()); } 
                if(obj.lcDraweeBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcDraweeBnkCode()); } 
                if(obj.lcDraweeAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcDraweeAddr1()); } 
                if(obj.lcDraweeAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcDraweeAddr2()); } 
                if(obj.lcDraweeAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcDraweeAddr3()); } 
                if(obj.lcDraweeAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcDraweeAddr4()); } 
                if(obj.lcDraweeAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcDraweeAddr5()); } 
                if(obj.lcMixedPayDetails1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcMixedPayDetails1()); } 
                if(obj.lcMixedPayDetails2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcMixedPayDetails2()); } 
                if(obj.lcMixedPayDetails3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcMixedPayDetails3()); } 
                if(obj.lcMixedPayDetails4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcMixedPayDetails4()); } 
                if(obj.lcDeferredPayDetails1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcDeferredPayDetails1()); } 
                if(obj.lcDeferredPayDetails2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcDeferredPayDetails2()); } 
                if(obj.lcDeferredPayDetails3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcDeferredPayDetails3()); } 
                if(obj.lcDeferredPayDetails4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcDeferredPayDetails4()); } 
                if(obj.lcPartialShipmentsIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLcPartialShipments()); } 
                if(obj.lcTranshipmentIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLcTranshipment()); } 
                if(obj.lcPlaceOfTakingInChargeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcPlaceOfTakingInCharge()); } 
                if(obj.lcPortOfLoadingIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcPortOfLoading()); } 
                if(obj.lcPortOfDischargeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcPortOfDischarge()); } 
                if(obj.lcPlaceOfFinalDestIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcPlaceOfFinalDest()); } 
                if(obj.lcDescGoodsSer1IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getLcDescGoodsSer1()); } 
                if(obj.lcDescGoodsSer2IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getLcDescGoodsSer2()); } 
                if(obj.lcDescGoodsSer3IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getLcDescGoodsSer3()); } 
                if(obj.lcDocReq1IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getLcDocReq1()); } 
                if(obj.lcDocReq2IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getLcDocReq2()); } 
                if(obj.lcDocReq3IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getLcDocReq3()); } 
                if(obj.lcAddCondition1IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getLcAddCondition1()); } 
                if(obj.lcAddCondition2IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getLcAddCondition2()); } 
                if(obj.lcAddCondition3IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getLcAddCondition3()); } 
                if(obj.lcCharges1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcCharges1()); } 
                if(obj.lcCharges2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcCharges2()); } 
                if(obj.lcCharges3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcCharges3()); } 
                if(obj.lcCharges4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcCharges4()); } 
                if(obj.lcCharges5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcCharges5()); } 
                if(obj.lcCharges6IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcCharges6()); } 
                if(obj.lcPerPresentationDayIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLcPerPresentationDay()); } 
                if(obj.lcConfirmationInstIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLcConfirmationInst()); } 
                if(obj.lcReimbReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLcReimbReq())); } 
                if(obj.lcReimbTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLcReimbType())); } 
                if(obj.lcReimbBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcReimbBrnCode()); } 
                if(obj.lcReimbBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcReimbBicCode()); } 
                if(obj.lcReimbRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcReimbRoutid()); } 
                if(obj.lcReimbBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcReimbBnkCode()); } 
                if(obj.lcReimbAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcReimbAddr1()); } 
                if(obj.lcReimbAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcReimbAddr2()); } 
                if(obj.lcReimbAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcReimbAddr3()); } 
                if(obj.lcReimbAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcReimbAddr4()); } 
                if(obj.lcReimbAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcReimbAddr5()); } 
                if(obj.lcInstPaying1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcInstPaying1()); } 
                if(obj.lcInstPaying2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcInstPaying2()); } 
                if(obj.lcInstPaying3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcInstPaying3()); } 
                if(obj.lcInstPaying4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcInstPaying4()); } 
                if(obj.lcInstPaying5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcInstPaying5()); } 
                if(obj.lcInstPaying6IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcInstPaying6()); } 
                if(obj.lcInstPaying7IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcInstPaying7()); } 
                if(obj.lcInstPaying8IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcInstPaying8()); } 
                if(obj.lcInstPaying9IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcInstPaying9()); } 
                if(obj.lcInstPaying10IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcInstPaying10()); } 
                if(obj.lcInstPaying11IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcInstPaying11()); } 
                if(obj.lcInstPaying12IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcInstPaying12()); } 
                if(obj.lcSecondAdvReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLcSecondAdvReq())); } 
                if(obj.lcSecondAdvTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLcSecondAdvType())); } 
                if(obj.lcSecondAdvBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcSecondAdvBrnCode()); } 
                if(obj.lcSecondAdvBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcSecondAdvBicCode()); } 
                if(obj.lcSecondAdvRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcSecondAdvRoutid()); } 
                if(obj.lcSecondAdvBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcSecondAdvBnkCode()); } 
                if(obj.lcSecondAdvAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcSecondAdvAddr1()); } 
                if(obj.lcSecondAdvAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcSecondAdvAddr2()); } 
                if(obj.lcSecondAdvAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcSecondAdvAddr3()); } 
                if(obj.lcSecondAdvAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcSecondAdvAddr4()); } 
                if(obj.lcSecondAdvAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcSecondAdvAddr5()); } 
                if(obj.lcSndrRecInfo1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcSndrRecInfo1()); } 
                if(obj.lcSndrRecInfo2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcSndrRecInfo2()); } 
                if(obj.lcSndrRecInfo3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcSndrRecInfo3()); } 
                if(obj.lcSndrRecInfo4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcSndrRecInfo4()); } 
                if(obj.lcSndrRecInfo5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcSndrRecInfo5()); } 
                if(obj.lcSndrRecInfo6IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcSndrRecInfo6()); } 
                if(obj.lcApplicantCntryCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcApplicantCntryCode()); } 
                if(obj.lcAvailableWithCntryIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcAvailableWithCntry()); } 
                if(obj.lcAvailableWithCodetypIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLcAvailableWithCodetyp()); } 
                if(obj.lcDraweeCntryCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcDraweeCntryCode()); } 
                if(obj.lcConfirmInstTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLcConfirmInstType())); } 
                if(obj.lcReimbCntryCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcReimbCntryCode()); } 
                if(obj.lcSecondAdvCntrycodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcSecondAdvCntrycode()); } 
                if(obj.lcShipmentPeriod1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcShipmentPeriod1()); } 
                if(obj.lcShipmentPeriod2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcShipmentPeriod2()); } 
                if(obj.lcShipmentPeriod3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcShipmentPeriod3()); } 
                if(obj.lcShipmentPeriod4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcShipmentPeriod4()); } 
                if(obj.lcShipmentPeriod5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcShipmentPeriod5()); } 
                if(obj.lcShipmentPeriod6IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcShipmentPeriod6()); } 
                if(obj.lcPerPresentationRemarksIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcPerPresentationRemarks()); } 
                if(obj.lcRecBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcRecBicCode()); } 
                if(obj.lcCfmReimbTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLcCfmReimbType())); } 
                if(obj.lcCfmReimbBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcCfmReimbBrnCode()); } 
                if(obj.lcCfmReimbBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcCfmReimbBicCode()); } 
                if(obj.lcCfmReimbRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcCfmReimbRoutid()); } 
                if(obj.lcCfmReimbBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcCfmReimbBnkCode()); } 
                if(obj.lcCfmReimbAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcCfmReimbAddr1()); } 
                if(obj.lcCfmReimbAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcCfmReimbAddr2()); } 
                if(obj.lcCfmReimbAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcCfmReimbAddr3()); } 
                if(obj.lcCfmReimbAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcCfmReimbAddr4()); } 
                if(obj.lcCfmReimbAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcCfmReimbAddr5()); } 
                if(obj.lcCfmReimbCntryCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcCfmReimbCntryCode()); } 
                _pstmt.executeUpdate();
                obj.setIsNew(false);
                obj.resetIsModifiedS2J();
            }
            else {
                StringBuffer _sql = new StringBuffer("UPDATE LC_DETAILS SET ");
                if(obj.lcBrnCodeIsModifiedS2j()) {  _sql.append("LC_BRN_CODE").append("=?,"); }
                if(obj.lcLcTypeIsModifiedS2j()) {  _sql.append("LC_LC_TYPE").append("=?,"); }
                if(obj.lcLcYearIsModifiedS2j()) {  _sql.append("LC_LC_YEAR").append("=?,"); }
                if(obj.lcLcSlIsModifiedS2j()) {  _sql.append("LC_LC_SL").append("=?,"); }
                if(obj.lcFormOfDocCreditIsModifiedS2j()) {  _sql.append("LC_FORM_OF_DOC_CREDIT").append("=?,"); }
                if(obj.lcReferenceToPreadviceIsModifiedS2j()) {  _sql.append("LC_REFERENCE_TO_PREADVICE").append("=?,"); }
                if(obj.lcApplicableRulesIsModifiedS2j()) {  _sql.append("LC_APPLICABLE_RULES").append("=?,"); }
                if(obj.lcApplicantReqIsModifiedS2j()) {  _sql.append("LC_APPLICANT_REQ").append("=?,"); }
                if(obj.lcApplicantTypeIsModifiedS2j()) {  _sql.append("LC_APPLICANT_TYPE").append("=?,"); }
                if(obj.lcApplicantBrnCodeIsModifiedS2j()) {  _sql.append("LC_APPLICANT_BRN_CODE").append("=?,"); }
                if(obj.lcApplicantBicCodeIsModifiedS2j()) {  _sql.append("LC_APPLICANT_BIC_CODE").append("=?,"); }
                if(obj.lcApplicantRoutidIsModifiedS2j()) {  _sql.append("LC_APPLICANT_ROUTID").append("=?,"); }
                if(obj.lcApplicantBnkCodeIsModifiedS2j()) {  _sql.append("LC_APPLICANT_BNK_CODE").append("=?,"); }
                if(obj.lcApplicantAddr1IsModifiedS2j()) {  _sql.append("LC_APPLICANT_ADDR1").append("=?,"); }
                if(obj.lcApplicantAddr2IsModifiedS2j()) {  _sql.append("LC_APPLICANT_ADDR2").append("=?,"); }
                if(obj.lcApplicantAddr3IsModifiedS2j()) {  _sql.append("LC_APPLICANT_ADDR3").append("=?,"); }
                if(obj.lcApplicantAddr4IsModifiedS2j()) {  _sql.append("LC_APPLICANT_ADDR4").append("=?,"); }
                if(obj.lcApplicantAddr5IsModifiedS2j()) {  _sql.append("LC_APPLICANT_ADDR5").append("=?,"); }
                if(obj.lcAvailableWithTypeIsModifiedS2j()) {  _sql.append("LC_AVAILABLE_WITH_TYPE").append("=?,"); }
                if(obj.lcAvailableWithBrnCodeIsModifiedS2j()) {  _sql.append("LC_AVAILABLE_WITH_BRN_CODE").append("=?,"); }
                if(obj.lcAvailableWithCodeIsModifiedS2j()) {  _sql.append("LC_AVAILABLE_WITH_CODE").append("=?,"); }
                if(obj.lcAvailableWithRoutidIsModifiedS2j()) {  _sql.append("LC_AVAILABLE_WITH_ROUTID").append("=?,"); }
                if(obj.lcAvailableWithBnkCodeIsModifiedS2j()) {  _sql.append("LC_AVAILABLE_WITH_BNK_CODE").append("=?,"); }
                if(obj.lcAvailableWithAddr1IsModifiedS2j()) {  _sql.append("LC_AVAILABLE_WITH_ADDR1").append("=?,"); }
                if(obj.lcAvailableWithAddr2IsModifiedS2j()) {  _sql.append("LC_AVAILABLE_WITH_ADDR2").append("=?,"); }
                if(obj.lcAvailableWithAddr3IsModifiedS2j()) {  _sql.append("LC_AVAILABLE_WITH_ADDR3").append("=?,"); }
                if(obj.lcAvailableWithAddr4IsModifiedS2j()) {  _sql.append("LC_AVAILABLE_WITH_ADDR4").append("=?,"); }
                if(obj.lcAvailableWithAddr5IsModifiedS2j()) {  _sql.append("LC_AVAILABLE_WITH_ADDR5").append("=?,"); }
                if(obj.lcDraftsAt1IsModifiedS2j()) {  _sql.append("LC_DRAFTS_AT1").append("=?,"); }
                if(obj.lcDraftsAt2IsModifiedS2j()) {  _sql.append("LC_DRAFTS_AT2").append("=?,"); }
                if(obj.lcDraftsAt3IsModifiedS2j()) {  _sql.append("LC_DRAFTS_AT3").append("=?,"); }
                if(obj.lcDraweeReqIsModifiedS2j()) {  _sql.append("LC_DRAWEE_REQ").append("=?,"); }
                if(obj.lcDraweeTypeIsModifiedS2j()) {  _sql.append("LC_DRAWEE_TYPE").append("=?,"); }
                if(obj.lcDraweeBrnCodeIsModifiedS2j()) {  _sql.append("LC_DRAWEE_BRN_CODE").append("=?,"); }
                if(obj.lcDraweeBicCodeIsModifiedS2j()) {  _sql.append("LC_DRAWEE_BIC_CODE").append("=?,"); }
                if(obj.lcDraweeRoutidIsModifiedS2j()) {  _sql.append("LC_DRAWEE_ROUTID").append("=?,"); }
                if(obj.lcDraweeBnkCodeIsModifiedS2j()) {  _sql.append("LC_DRAWEE_BNK_CODE").append("=?,"); }
                if(obj.lcDraweeAddr1IsModifiedS2j()) {  _sql.append("LC_DRAWEE_ADDR1").append("=?,"); }
                if(obj.lcDraweeAddr2IsModifiedS2j()) {  _sql.append("LC_DRAWEE_ADDR2").append("=?,"); }
                if(obj.lcDraweeAddr3IsModifiedS2j()) {  _sql.append("LC_DRAWEE_ADDR3").append("=?,"); }
                if(obj.lcDraweeAddr4IsModifiedS2j()) {  _sql.append("LC_DRAWEE_ADDR4").append("=?,"); }
                if(obj.lcDraweeAddr5IsModifiedS2j()) {  _sql.append("LC_DRAWEE_ADDR5").append("=?,"); }
                if(obj.lcMixedPayDetails1IsModifiedS2j()) {  _sql.append("LC_MIXED_PAY_DETAILS1").append("=?,"); }
                if(obj.lcMixedPayDetails2IsModifiedS2j()) {  _sql.append("LC_MIXED_PAY_DETAILS2").append("=?,"); }
                if(obj.lcMixedPayDetails3IsModifiedS2j()) {  _sql.append("LC_MIXED_PAY_DETAILS3").append("=?,"); }
                if(obj.lcMixedPayDetails4IsModifiedS2j()) {  _sql.append("LC_MIXED_PAY_DETAILS4").append("=?,"); }
                if(obj.lcDeferredPayDetails1IsModifiedS2j()) {  _sql.append("LC_DEFERRED_PAY_DETAILS1").append("=?,"); }
                if(obj.lcDeferredPayDetails2IsModifiedS2j()) {  _sql.append("LC_DEFERRED_PAY_DETAILS2").append("=?,"); }
                if(obj.lcDeferredPayDetails3IsModifiedS2j()) {  _sql.append("LC_DEFERRED_PAY_DETAILS3").append("=?,"); }
                if(obj.lcDeferredPayDetails4IsModifiedS2j()) {  _sql.append("LC_DEFERRED_PAY_DETAILS4").append("=?,"); }
                if(obj.lcPartialShipmentsIsModifiedS2j()) {  _sql.append("LC_PARTIAL_SHIPMENTS").append("=?,"); }
                if(obj.lcTranshipmentIsModifiedS2j()) {  _sql.append("LC_TRANSHIPMENT").append("=?,"); }
                if(obj.lcPlaceOfTakingInChargeIsModifiedS2j()) {  _sql.append("LC_PLACE_OF_TAKING_IN_CHARGE").append("=?,"); }
                if(obj.lcPortOfLoadingIsModifiedS2j()) {  _sql.append("LC_PORT_OF_LOADING").append("=?,"); }
                if(obj.lcPortOfDischargeIsModifiedS2j()) {  _sql.append("LC_PORT_OF_DISCHARGE").append("=?,"); }
                if(obj.lcPlaceOfFinalDestIsModifiedS2j()) {  _sql.append("LC_PLACE_OF_FINAL_DEST").append("=?,"); }
                if(obj.lcDescGoodsSer1IsModifiedS2j()) {  _sql.append("LC_DESC_GOODS_SER1").append("=?,"); }
                if(obj.lcDescGoodsSer2IsModifiedS2j()) {  _sql.append("LC_DESC_GOODS_SER2").append("=?,"); }
                if(obj.lcDescGoodsSer3IsModifiedS2j()) {  _sql.append("LC_DESC_GOODS_SER3").append("=?,"); }
                if(obj.lcDocReq1IsModifiedS2j()) {  _sql.append("LC_DOC_REQ1").append("=?,"); }
                if(obj.lcDocReq2IsModifiedS2j()) {  _sql.append("LC_DOC_REQ2").append("=?,"); }
                if(obj.lcDocReq3IsModifiedS2j()) {  _sql.append("LC_DOC_REQ3").append("=?,"); }
                if(obj.lcAddCondition1IsModifiedS2j()) {  _sql.append("LC_ADD_CONDITION1").append("=?,"); }
                if(obj.lcAddCondition2IsModifiedS2j()) {  _sql.append("LC_ADD_CONDITION2").append("=?,"); }
                if(obj.lcAddCondition3IsModifiedS2j()) {  _sql.append("LC_ADD_CONDITION3").append("=?,"); }
                if(obj.lcCharges1IsModifiedS2j()) {  _sql.append("LC_CHARGES1").append("=?,"); }
                if(obj.lcCharges2IsModifiedS2j()) {  _sql.append("LC_CHARGES2").append("=?,"); }
                if(obj.lcCharges3IsModifiedS2j()) {  _sql.append("LC_CHARGES3").append("=?,"); }
                if(obj.lcCharges4IsModifiedS2j()) {  _sql.append("LC_CHARGES4").append("=?,"); }
                if(obj.lcCharges5IsModifiedS2j()) {  _sql.append("LC_CHARGES5").append("=?,"); }
                if(obj.lcCharges6IsModifiedS2j()) {  _sql.append("LC_CHARGES6").append("=?,"); }
                if(obj.lcPerPresentationDayIsModifiedS2j()) {  _sql.append("LC_PER_PRESENTATION_DAY").append("=?,"); }
                if(obj.lcConfirmationInstIsModifiedS2j()) {  _sql.append("LC_CONFIRMATION_INST").append("=?,"); }
                if(obj.lcReimbReqIsModifiedS2j()) {  _sql.append("LC_REIMB_REQ").append("=?,"); }
                if(obj.lcReimbTypeIsModifiedS2j()) {  _sql.append("LC_REIMB_TYPE").append("=?,"); }
                if(obj.lcReimbBrnCodeIsModifiedS2j()) {  _sql.append("LC_REIMB_BRN_CODE").append("=?,"); }
                if(obj.lcReimbBicCodeIsModifiedS2j()) {  _sql.append("LC_REIMB_BIC_CODE").append("=?,"); }
                if(obj.lcReimbRoutidIsModifiedS2j()) {  _sql.append("LC_REIMB_ROUTID").append("=?,"); }
                if(obj.lcReimbBnkCodeIsModifiedS2j()) {  _sql.append("LC_REIMB_BNK_CODE").append("=?,"); }
                if(obj.lcReimbAddr1IsModifiedS2j()) {  _sql.append("LC_REIMB_ADDR1").append("=?,"); }
                if(obj.lcReimbAddr2IsModifiedS2j()) {  _sql.append("LC_REIMB_ADDR2").append("=?,"); }
                if(obj.lcReimbAddr3IsModifiedS2j()) {  _sql.append("LC_REIMB_ADDR3").append("=?,"); }
                if(obj.lcReimbAddr4IsModifiedS2j()) {  _sql.append("LC_REIMB_ADDR4").append("=?,"); }
                if(obj.lcReimbAddr5IsModifiedS2j()) {  _sql.append("LC_REIMB_ADDR5").append("=?,"); }
                if(obj.lcInstPaying1IsModifiedS2j()) {  _sql.append("LC_INST_PAYING1").append("=?,"); }
                if(obj.lcInstPaying2IsModifiedS2j()) {  _sql.append("LC_INST_PAYING2").append("=?,"); }
                if(obj.lcInstPaying3IsModifiedS2j()) {  _sql.append("LC_INST_PAYING3").append("=?,"); }
                if(obj.lcInstPaying4IsModifiedS2j()) {  _sql.append("LC_INST_PAYING4").append("=?,"); }
                if(obj.lcInstPaying5IsModifiedS2j()) {  _sql.append("LC_INST_PAYING5").append("=?,"); }
                if(obj.lcInstPaying6IsModifiedS2j()) {  _sql.append("LC_INST_PAYING6").append("=?,"); }
                if(obj.lcInstPaying7IsModifiedS2j()) {  _sql.append("LC_INST_PAYING7").append("=?,"); }
                if(obj.lcInstPaying8IsModifiedS2j()) {  _sql.append("LC_INST_PAYING8").append("=?,"); }
                if(obj.lcInstPaying9IsModifiedS2j()) {  _sql.append("LC_INST_PAYING9").append("=?,"); }
                if(obj.lcInstPaying10IsModifiedS2j()) {  _sql.append("LC_INST_PAYING10").append("=?,"); }
                if(obj.lcInstPaying11IsModifiedS2j()) {  _sql.append("LC_INST_PAYING11").append("=?,"); }
                if(obj.lcInstPaying12IsModifiedS2j()) {  _sql.append("LC_INST_PAYING12").append("=?,"); }
                if(obj.lcSecondAdvReqIsModifiedS2j()) {  _sql.append("LC_SECOND_ADV_REQ").append("=?,"); }
                if(obj.lcSecondAdvTypeIsModifiedS2j()) {  _sql.append("LC_SECOND_ADV_TYPE").append("=?,"); }
                if(obj.lcSecondAdvBrnCodeIsModifiedS2j()) {  _sql.append("LC_SECOND_ADV_BRN_CODE").append("=?,"); }
                if(obj.lcSecondAdvBicCodeIsModifiedS2j()) {  _sql.append("LC_SECOND_ADV_BIC_CODE").append("=?,"); }
                if(obj.lcSecondAdvRoutidIsModifiedS2j()) {  _sql.append("LC_SECOND_ADV_ROUTID").append("=?,"); }
                if(obj.lcSecondAdvBnkCodeIsModifiedS2j()) {  _sql.append("LC_SECOND_ADV_BNK_CODE").append("=?,"); }
                if(obj.lcSecondAdvAddr1IsModifiedS2j()) {  _sql.append("LC_SECOND_ADV_ADDR1").append("=?,"); }
                if(obj.lcSecondAdvAddr2IsModifiedS2j()) {  _sql.append("LC_SECOND_ADV_ADDR2").append("=?,"); }
                if(obj.lcSecondAdvAddr3IsModifiedS2j()) {  _sql.append("LC_SECOND_ADV_ADDR3").append("=?,"); }
                if(obj.lcSecondAdvAddr4IsModifiedS2j()) {  _sql.append("LC_SECOND_ADV_ADDR4").append("=?,"); }
                if(obj.lcSecondAdvAddr5IsModifiedS2j()) {  _sql.append("LC_SECOND_ADV_ADDR5").append("=?,"); }
                if(obj.lcSndrRecInfo1IsModifiedS2j()) {  _sql.append("LC_SNDR_REC_INFO1").append("=?,"); }
                if(obj.lcSndrRecInfo2IsModifiedS2j()) {  _sql.append("LC_SNDR_REC_INFO2").append("=?,"); }
                if(obj.lcSndrRecInfo3IsModifiedS2j()) {  _sql.append("LC_SNDR_REC_INFO3").append("=?,"); }
                if(obj.lcSndrRecInfo4IsModifiedS2j()) {  _sql.append("LC_SNDR_REC_INFO4").append("=?,"); }
                if(obj.lcSndrRecInfo5IsModifiedS2j()) {  _sql.append("LC_SNDR_REC_INFO5").append("=?,"); }
                if(obj.lcSndrRecInfo6IsModifiedS2j()) {  _sql.append("LC_SNDR_REC_INFO6").append("=?,"); }
                if(obj.lcApplicantCntryCodeIsModifiedS2j()) {  _sql.append("LC_APPLICANT_CNTRY_CODE").append("=?,"); }
                if(obj.lcAvailableWithCntryIsModifiedS2j()) {  _sql.append("LC_AVAILABLE_WITH_CNTRY").append("=?,"); }
                if(obj.lcAvailableWithCodetypIsModifiedS2j()) {  _sql.append("LC_AVAILABLE_WITH_CODETYP").append("=?,"); }
                if(obj.lcDraweeCntryCodeIsModifiedS2j()) {  _sql.append("LC_DRAWEE_CNTRY_CODE").append("=?,"); }
                if(obj.lcConfirmInstTypeIsModifiedS2j()) {  _sql.append("LC_CONFIRM_INST_TYPE").append("=?,"); }
                if(obj.lcReimbCntryCodeIsModifiedS2j()) {  _sql.append("LC_REIMB_CNTRY_CODE").append("=?,"); }
                if(obj.lcSecondAdvCntrycodeIsModifiedS2j()) {  _sql.append("LC_SECOND_ADV_CNTRYCODE").append("=?,"); }
                if(obj.lcShipmentPeriod1IsModifiedS2j()) {  _sql.append("LC_SHIPMENT_PERIOD1").append("=?,"); }
                if(obj.lcShipmentPeriod2IsModifiedS2j()) {  _sql.append("LC_SHIPMENT_PERIOD2").append("=?,"); }
                if(obj.lcShipmentPeriod3IsModifiedS2j()) {  _sql.append("LC_SHIPMENT_PERIOD3").append("=?,"); }
                if(obj.lcShipmentPeriod4IsModifiedS2j()) {  _sql.append("LC_SHIPMENT_PERIOD4").append("=?,"); }
                if(obj.lcShipmentPeriod5IsModifiedS2j()) {  _sql.append("LC_SHIPMENT_PERIOD5").append("=?,"); }
                if(obj.lcShipmentPeriod6IsModifiedS2j()) {  _sql.append("LC_SHIPMENT_PERIOD6").append("=?,"); }
                if(obj.lcPerPresentationRemarksIsModifiedS2j()) {  _sql.append("LC_PER_PRESENTATION_REMARKS").append("=?,"); }
                if(obj.lcRecBicCodeIsModifiedS2j()) {  _sql.append("LC_REC_BIC_CODE").append("=?,"); }
                if(obj.lcCfmReimbTypeIsModifiedS2j()) {  _sql.append("LC_CFM_REIMB_TYPE").append("=?,"); }
                if(obj.lcCfmReimbBrnCodeIsModifiedS2j()) {  _sql.append("LC_CFM_REIMB_BRN_CODE").append("=?,"); }
                if(obj.lcCfmReimbBicCodeIsModifiedS2j()) {  _sql.append("LC_CFM_REIMB_BIC_CODE").append("=?,"); }
                if(obj.lcCfmReimbRoutidIsModifiedS2j()) {  _sql.append("LC_CFM_REIMB_ROUTID").append("=?,"); }
                if(obj.lcCfmReimbBnkCodeIsModifiedS2j()) {  _sql.append("LC_CFM_REIMB_BNK_CODE").append("=?,"); }
                if(obj.lcCfmReimbAddr1IsModifiedS2j()) {  _sql.append("LC_CFM_REIMB_ADDR1").append("=?,"); }
                if(obj.lcCfmReimbAddr2IsModifiedS2j()) {  _sql.append("LC_CFM_REIMB_ADDR2").append("=?,"); }
                if(obj.lcCfmReimbAddr3IsModifiedS2j()) {  _sql.append("LC_CFM_REIMB_ADDR3").append("=?,"); }
                if(obj.lcCfmReimbAddr4IsModifiedS2j()) {  _sql.append("LC_CFM_REIMB_ADDR4").append("=?,"); }
                if(obj.lcCfmReimbAddr5IsModifiedS2j()) {  _sql.append("LC_CFM_REIMB_ADDR5").append("=?,"); }
                if(obj.lcCfmReimbCntryCodeIsModifiedS2j()) {  _sql.append("LC_CFM_REIMB_CNTRY_CODE").append("=?,"); }
                _sql.setLength(_sql.length() - 1);
                _sql.append(" WHERE ");
                _sql.append("LC_DETAILS.LC_BRN_CODE=? and LC_DETAILS.LC_LC_SL=? and LC_DETAILS.LC_LC_TYPE=? and LC_DETAILS.LC_LC_YEAR=?");
                _pstmt = _conn.prepareStatement(_sql.toString());
                int _dirtyCount = 0;
                if(obj.lcBrnCodeIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLcBrnCode()); } 
                if(obj.lcLcTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcLcType()); } 
                if(obj.lcLcYearIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLcLcYear()); } 
                if(obj.lcLcSlIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLcLcSl()); } 
                if(obj.lcFormOfDocCreditIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLcFormOfDocCredit()); } 
                if(obj.lcReferenceToPreadviceIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcReferenceToPreadvice()); } 
                if(obj.lcApplicableRulesIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLcApplicableRules()); } 
                if(obj.lcApplicantReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLcApplicantReq())); } 
                if(obj.lcApplicantTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLcApplicantType())); } 
                if(obj.lcApplicantBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcApplicantBrnCode()); } 
                if(obj.lcApplicantBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcApplicantBicCode()); } 
                if(obj.lcApplicantRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcApplicantRoutid()); } 
                if(obj.lcApplicantBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcApplicantBnkCode()); } 
                if(obj.lcApplicantAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcApplicantAddr1()); } 
                if(obj.lcApplicantAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcApplicantAddr2()); } 
                if(obj.lcApplicantAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcApplicantAddr3()); } 
                if(obj.lcApplicantAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcApplicantAddr4()); } 
                if(obj.lcApplicantAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcApplicantAddr5()); } 
                if(obj.lcAvailableWithTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLcAvailableWithType())); } 
                if(obj.lcAvailableWithBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcAvailableWithBrnCode()); } 
                if(obj.lcAvailableWithCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcAvailableWithCode()); } 
                if(obj.lcAvailableWithRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcAvailableWithRoutid()); } 
                if(obj.lcAvailableWithBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcAvailableWithBnkCode()); } 
                if(obj.lcAvailableWithAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcAvailableWithAddr1()); } 
                if(obj.lcAvailableWithAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcAvailableWithAddr2()); } 
                if(obj.lcAvailableWithAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcAvailableWithAddr3()); } 
                if(obj.lcAvailableWithAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcAvailableWithAddr4()); } 
                if(obj.lcAvailableWithAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcAvailableWithAddr5()); } 
                if(obj.lcDraftsAt1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcDraftsAt1()); } 
                if(obj.lcDraftsAt2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcDraftsAt2()); } 
                if(obj.lcDraftsAt3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcDraftsAt3()); } 
                if(obj.lcDraweeReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLcDraweeReq())); } 
                if(obj.lcDraweeTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLcDraweeType())); } 
                if(obj.lcDraweeBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcDraweeBrnCode()); } 
                if(obj.lcDraweeBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcDraweeBicCode()); } 
                if(obj.lcDraweeRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcDraweeRoutid()); } 
                if(obj.lcDraweeBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcDraweeBnkCode()); } 
                if(obj.lcDraweeAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcDraweeAddr1()); } 
                if(obj.lcDraweeAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcDraweeAddr2()); } 
                if(obj.lcDraweeAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcDraweeAddr3()); } 
                if(obj.lcDraweeAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcDraweeAddr4()); } 
                if(obj.lcDraweeAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcDraweeAddr5()); } 
                if(obj.lcMixedPayDetails1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcMixedPayDetails1()); } 
                if(obj.lcMixedPayDetails2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcMixedPayDetails2()); } 
                if(obj.lcMixedPayDetails3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcMixedPayDetails3()); } 
                if(obj.lcMixedPayDetails4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcMixedPayDetails4()); } 
                if(obj.lcDeferredPayDetails1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcDeferredPayDetails1()); } 
                if(obj.lcDeferredPayDetails2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcDeferredPayDetails2()); } 
                if(obj.lcDeferredPayDetails3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcDeferredPayDetails3()); } 
                if(obj.lcDeferredPayDetails4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcDeferredPayDetails4()); } 
                if(obj.lcPartialShipmentsIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLcPartialShipments()); } 
                if(obj.lcTranshipmentIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLcTranshipment()); } 
                if(obj.lcPlaceOfTakingInChargeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcPlaceOfTakingInCharge()); } 
                if(obj.lcPortOfLoadingIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcPortOfLoading()); } 
                if(obj.lcPortOfDischargeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcPortOfDischarge()); } 
                if(obj.lcPlaceOfFinalDestIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcPlaceOfFinalDest()); } 
                if(obj.lcDescGoodsSer1IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getLcDescGoodsSer1()); } 
                if(obj.lcDescGoodsSer2IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getLcDescGoodsSer2()); } 
                if(obj.lcDescGoodsSer3IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getLcDescGoodsSer3()); } 
                if(obj.lcDocReq1IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getLcDocReq1()); } 
                if(obj.lcDocReq2IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getLcDocReq2()); } 
                if(obj.lcDocReq3IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getLcDocReq3()); } 
                if(obj.lcAddCondition1IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getLcAddCondition1()); } 
                if(obj.lcAddCondition2IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getLcAddCondition2()); } 
                if(obj.lcAddCondition3IsModifiedS2j()) { _pstmt.setObject(++_dirtyCount, obj.getLcAddCondition3()); } 
                if(obj.lcCharges1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcCharges1()); } 
                if(obj.lcCharges2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcCharges2()); } 
                if(obj.lcCharges3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcCharges3()); } 
                if(obj.lcCharges4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcCharges4()); } 
                if(obj.lcCharges5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcCharges5()); } 
                if(obj.lcCharges6IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcCharges6()); } 
                if(obj.lcPerPresentationDayIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLcPerPresentationDay()); } 
                if(obj.lcConfirmationInstIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLcConfirmationInst()); } 
                if(obj.lcReimbReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLcReimbReq())); } 
                if(obj.lcReimbTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLcReimbType())); } 
                if(obj.lcReimbBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcReimbBrnCode()); } 
                if(obj.lcReimbBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcReimbBicCode()); } 
                if(obj.lcReimbRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcReimbRoutid()); } 
                if(obj.lcReimbBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcReimbBnkCode()); } 
                if(obj.lcReimbAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcReimbAddr1()); } 
                if(obj.lcReimbAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcReimbAddr2()); } 
                if(obj.lcReimbAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcReimbAddr3()); } 
                if(obj.lcReimbAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcReimbAddr4()); } 
                if(obj.lcReimbAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcReimbAddr5()); } 
                if(obj.lcInstPaying1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcInstPaying1()); } 
                if(obj.lcInstPaying2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcInstPaying2()); } 
                if(obj.lcInstPaying3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcInstPaying3()); } 
                if(obj.lcInstPaying4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcInstPaying4()); } 
                if(obj.lcInstPaying5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcInstPaying5()); } 
                if(obj.lcInstPaying6IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcInstPaying6()); } 
                if(obj.lcInstPaying7IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcInstPaying7()); } 
                if(obj.lcInstPaying8IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcInstPaying8()); } 
                if(obj.lcInstPaying9IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcInstPaying9()); } 
                if(obj.lcInstPaying10IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcInstPaying10()); } 
                if(obj.lcInstPaying11IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcInstPaying11()); } 
                if(obj.lcInstPaying12IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcInstPaying12()); } 
                if(obj.lcSecondAdvReqIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLcSecondAdvReq())); } 
                if(obj.lcSecondAdvTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLcSecondAdvType())); } 
                if(obj.lcSecondAdvBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcSecondAdvBrnCode()); } 
                if(obj.lcSecondAdvBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcSecondAdvBicCode()); } 
                if(obj.lcSecondAdvRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcSecondAdvRoutid()); } 
                if(obj.lcSecondAdvBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcSecondAdvBnkCode()); } 
                if(obj.lcSecondAdvAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcSecondAdvAddr1()); } 
                if(obj.lcSecondAdvAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcSecondAdvAddr2()); } 
                if(obj.lcSecondAdvAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcSecondAdvAddr3()); } 
                if(obj.lcSecondAdvAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcSecondAdvAddr4()); } 
                if(obj.lcSecondAdvAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcSecondAdvAddr5()); } 
                if(obj.lcSndrRecInfo1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcSndrRecInfo1()); } 
                if(obj.lcSndrRecInfo2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcSndrRecInfo2()); } 
                if(obj.lcSndrRecInfo3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcSndrRecInfo3()); } 
                if(obj.lcSndrRecInfo4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcSndrRecInfo4()); } 
                if(obj.lcSndrRecInfo5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcSndrRecInfo5()); } 
                if(obj.lcSndrRecInfo6IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcSndrRecInfo6()); } 
                if(obj.lcApplicantCntryCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcApplicantCntryCode()); } 
                if(obj.lcAvailableWithCntryIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcAvailableWithCntry()); } 
                if(obj.lcAvailableWithCodetypIsModifiedS2j()) { _pstmt.setDouble(++_dirtyCount, obj.getLcAvailableWithCodetyp()); } 
                if(obj.lcDraweeCntryCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcDraweeCntryCode()); } 
                if(obj.lcConfirmInstTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLcConfirmInstType())); } 
                if(obj.lcReimbCntryCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcReimbCntryCode()); } 
                if(obj.lcSecondAdvCntrycodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcSecondAdvCntrycode()); } 
                if(obj.lcShipmentPeriod1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcShipmentPeriod1()); } 
                if(obj.lcShipmentPeriod2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcShipmentPeriod2()); } 
                if(obj.lcShipmentPeriod3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcShipmentPeriod3()); } 
                if(obj.lcShipmentPeriod4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcShipmentPeriod4()); } 
                if(obj.lcShipmentPeriod5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcShipmentPeriod5()); } 
                if(obj.lcShipmentPeriod6IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcShipmentPeriod6()); } 
                if(obj.lcPerPresentationRemarksIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcPerPresentationRemarks()); } 
                if(obj.lcRecBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcRecBicCode()); } 
                if(obj.lcCfmReimbTypeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, charToString(obj.getLcCfmReimbType())); } 
                if(obj.lcCfmReimbBrnCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcCfmReimbBrnCode()); } 
                if(obj.lcCfmReimbBicCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcCfmReimbBicCode()); } 
                if(obj.lcCfmReimbRoutidIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcCfmReimbRoutid()); } 
                if(obj.lcCfmReimbBnkCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcCfmReimbBnkCode()); } 
                if(obj.lcCfmReimbAddr1IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcCfmReimbAddr1()); } 
                if(obj.lcCfmReimbAddr2IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcCfmReimbAddr2()); } 
                if(obj.lcCfmReimbAddr3IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcCfmReimbAddr3()); } 
                if(obj.lcCfmReimbAddr4IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcCfmReimbAddr4()); } 
                if(obj.lcCfmReimbAddr5IsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcCfmReimbAddr5()); } 
                if(obj.lcCfmReimbCntryCodeIsModifiedS2j()) { _pstmt.setString(++_dirtyCount, obj.getLcCfmReimbCntryCode()); } 
                _pstmt.setDouble(++_dirtyCount, obj.getLcBrnCode());
                _pstmt.setDouble(++_dirtyCount, obj.getLcLcSl());
                _pstmt.setString(++_dirtyCount, obj.getLcLcType());
                _pstmt.setDouble(++_dirtyCount, obj.getLcLcYear());
                _pstmt.executeUpdate();
                obj.resetIsModifiedS2J();
            }
            _pstmt.close();
        }
        catch(SQLException e) {
            if(_pstmt!=null) try { _pstmt.close();} catch(Exception e2) {}
            throw e;
        }
    }

    private LcDetails decodeRow(ResultSet rs) throws SQLException {
        LcDetails obj = new LcDetails();
        obj.setLcBrnCode(rs.getInt(1));
        obj.setLcLcType(rs.getString(2));
        obj.setLcLcYear(rs.getInt(3));
        obj.setLcLcSl(rs.getInt(4));
        obj.setLcFormOfDocCredit(rs.getInt(5));
        obj.setLcReferenceToPreadvice(rs.getString(6));
        obj.setLcApplicableRules(rs.getInt(7));
        obj.setLcApplicantReq(stringToChar(rs.getString(8)));
        obj.setLcApplicantType(stringToChar(rs.getString(9)));
        obj.setLcApplicantBrnCode(rs.getString(10));
        obj.setLcApplicantBicCode(rs.getString(11));
        obj.setLcApplicantRoutid(rs.getString(12));
        obj.setLcApplicantBnkCode(rs.getString(13));
        obj.setLcApplicantAddr1(rs.getString(14));
        obj.setLcApplicantAddr2(rs.getString(15));
        obj.setLcApplicantAddr3(rs.getString(16));
        obj.setLcApplicantAddr4(rs.getString(17));
        obj.setLcApplicantAddr5(rs.getString(18));
        obj.setLcAvailableWithType(stringToChar(rs.getString(19)));
        obj.setLcAvailableWithBrnCode(rs.getString(20));
        obj.setLcAvailableWithCode(rs.getString(21));
        obj.setLcAvailableWithRoutid(rs.getString(22));
        obj.setLcAvailableWithBnkCode(rs.getString(23));
        obj.setLcAvailableWithAddr1(rs.getString(24));
        obj.setLcAvailableWithAddr2(rs.getString(25));
        obj.setLcAvailableWithAddr3(rs.getString(26));
        obj.setLcAvailableWithAddr4(rs.getString(27));
        obj.setLcAvailableWithAddr5(rs.getString(28));
        obj.setLcDraftsAt1(rs.getString(29));
        obj.setLcDraftsAt2(rs.getString(30));
        obj.setLcDraftsAt3(rs.getString(31));
        obj.setLcDraweeReq(stringToChar(rs.getString(32)));
        obj.setLcDraweeType(stringToChar(rs.getString(33)));
        obj.setLcDraweeBrnCode(rs.getString(34));
        obj.setLcDraweeBicCode(rs.getString(35));
        obj.setLcDraweeRoutid(rs.getString(36));
        obj.setLcDraweeBnkCode(rs.getString(37));
        obj.setLcDraweeAddr1(rs.getString(38));
        obj.setLcDraweeAddr2(rs.getString(39));
        obj.setLcDraweeAddr3(rs.getString(40));
        obj.setLcDraweeAddr4(rs.getString(41));
        obj.setLcDraweeAddr5(rs.getString(42));
        obj.setLcMixedPayDetails1(rs.getString(43));
        obj.setLcMixedPayDetails2(rs.getString(44));
        obj.setLcMixedPayDetails3(rs.getString(45));
        obj.setLcMixedPayDetails4(rs.getString(46));
        obj.setLcDeferredPayDetails1(rs.getString(47));
        obj.setLcDeferredPayDetails2(rs.getString(48));
        obj.setLcDeferredPayDetails3(rs.getString(49));
        obj.setLcDeferredPayDetails4(rs.getString(50));
        obj.setLcPartialShipments(rs.getInt(51));
        obj.setLcTranshipment(rs.getInt(52));
        obj.setLcPlaceOfTakingInCharge(rs.getString(53));
        obj.setLcPortOfLoading(rs.getString(54));
        obj.setLcPortOfDischarge(rs.getString(55));
        obj.setLcPlaceOfFinalDest(rs.getString(56));
        obj.setLcDescGoodsSer1(rs.getObject(57));
        obj.setLcDescGoodsSer2(rs.getObject(58));
        obj.setLcDescGoodsSer3(rs.getObject(59));
        obj.setLcDocReq1(rs.getObject(60));
        obj.setLcDocReq2(rs.getObject(61));
        obj.setLcDocReq3(rs.getObject(62));
        obj.setLcAddCondition1(rs.getObject(63));
        obj.setLcAddCondition2(rs.getObject(64));
        obj.setLcAddCondition3(rs.getObject(65));
        obj.setLcCharges1(rs.getString(66));
        obj.setLcCharges2(rs.getString(67));
        obj.setLcCharges3(rs.getString(68));
        obj.setLcCharges4(rs.getString(69));
        obj.setLcCharges5(rs.getString(70));
        obj.setLcCharges6(rs.getString(71));
        obj.setLcPerPresentationDay(rs.getInt(72));
        obj.setLcConfirmationInst(rs.getInt(73));
        obj.setLcReimbReq(stringToChar(rs.getString(74)));
        obj.setLcReimbType(stringToChar(rs.getString(75)));
        obj.setLcReimbBrnCode(rs.getString(76));
        obj.setLcReimbBicCode(rs.getString(77));
        obj.setLcReimbRoutid(rs.getString(78));
        obj.setLcReimbBnkCode(rs.getString(79));
        obj.setLcReimbAddr1(rs.getString(80));
        obj.setLcReimbAddr2(rs.getString(81));
        obj.setLcReimbAddr3(rs.getString(82));
        obj.setLcReimbAddr4(rs.getString(83));
        obj.setLcReimbAddr5(rs.getString(84));
        obj.setLcInstPaying1(rs.getString(85));
        obj.setLcInstPaying2(rs.getString(86));
        obj.setLcInstPaying3(rs.getString(87));
        obj.setLcInstPaying4(rs.getString(88));
        obj.setLcInstPaying5(rs.getString(89));
        obj.setLcInstPaying6(rs.getString(90));
        obj.setLcInstPaying7(rs.getString(91));
        obj.setLcInstPaying8(rs.getString(92));
        obj.setLcInstPaying9(rs.getString(93));
        obj.setLcInstPaying10(rs.getString(94));
        obj.setLcInstPaying11(rs.getString(95));
        obj.setLcInstPaying12(rs.getString(96));
        obj.setLcSecondAdvReq(stringToChar(rs.getString(97)));
        obj.setLcSecondAdvType(stringToChar(rs.getString(98)));
        obj.setLcSecondAdvBrnCode(rs.getString(99));
        obj.setLcSecondAdvBicCode(rs.getString(100));
        obj.setLcSecondAdvRoutid(rs.getString(101));
        obj.setLcSecondAdvBnkCode(rs.getString(102));
        obj.setLcSecondAdvAddr1(rs.getString(103));
        obj.setLcSecondAdvAddr2(rs.getString(104));
        obj.setLcSecondAdvAddr3(rs.getString(105));
        obj.setLcSecondAdvAddr4(rs.getString(106));
        obj.setLcSecondAdvAddr5(rs.getString(107));
        obj.setLcSndrRecInfo1(rs.getString(108));
        obj.setLcSndrRecInfo2(rs.getString(109));
        obj.setLcSndrRecInfo3(rs.getString(110));
        obj.setLcSndrRecInfo4(rs.getString(111));
        obj.setLcSndrRecInfo5(rs.getString(112));
        obj.setLcSndrRecInfo6(rs.getString(113));
        obj.setLcApplicantCntryCode(rs.getString(114));
        obj.setLcAvailableWithCntry(rs.getString(115));
        obj.setLcAvailableWithCodetyp(rs.getInt(116));
        obj.setLcDraweeCntryCode(rs.getString(117));
        obj.setLcConfirmInstType(stringToChar(rs.getString(118)));
        obj.setLcReimbCntryCode(rs.getString(119));
        obj.setLcSecondAdvCntrycode(rs.getString(120));
        obj.setLcShipmentPeriod1(rs.getString(121));
        obj.setLcShipmentPeriod2(rs.getString(122));
        obj.setLcShipmentPeriod3(rs.getString(123));
        obj.setLcShipmentPeriod4(rs.getString(124));
        obj.setLcShipmentPeriod5(rs.getString(125));
        obj.setLcShipmentPeriod6(rs.getString(126));
        obj.setLcPerPresentationRemarks(rs.getString(127));
        obj.setLcRecBicCode(rs.getString(128));
        obj.setLcCfmReimbType(stringToChar(rs.getString(129)));
        obj.setLcCfmReimbBrnCode(rs.getString(130));
        obj.setLcCfmReimbBicCode(rs.getString(131));
        obj.setLcCfmReimbRoutid(rs.getString(132));
        obj.setLcCfmReimbBnkCode(rs.getString(133));
        obj.setLcCfmReimbAddr1(rs.getString(134));
        obj.setLcCfmReimbAddr2(rs.getString(135));
        obj.setLcCfmReimbAddr3(rs.getString(136));
        obj.setLcCfmReimbAddr4(rs.getString(137));
        obj.setLcCfmReimbAddr5(rs.getString(138));
        obj.setLcCfmReimbCntryCode(rs.getString(139));
        obj.setIsNew(false);
        obj.resetIsModifiedS2J();

        return obj;
    }

    private LcDetails decodeRow(ResultSet rs, int[] fieldList) throws SQLException {
        LcDetails obj = new LcDetails();
        int pos = 0;
        for(int i = 0; i < fieldList.length; i++) {
            switch(fieldList[i]) {
                case LC_BRN_CODE: obj.setLcBrnCode(rs.getInt(++pos));
                    break;
                case LC_LC_TYPE: obj.setLcLcType(rs.getString(++pos));
                    break;
                case LC_LC_YEAR: obj.setLcLcYear(rs.getInt(++pos));
                    break;
                case LC_LC_SL: obj.setLcLcSl(rs.getInt(++pos));
                    break;
                case LC_FORM_OF_DOC_CREDIT: obj.setLcFormOfDocCredit(rs.getInt(++pos));
                    break;
                case LC_REFERENCE_TO_PREADVICE: obj.setLcReferenceToPreadvice(rs.getString(++pos));
                    break;
                case LC_APPLICABLE_RULES: obj.setLcApplicableRules(rs.getInt(++pos));
                    break;
                case LC_APPLICANT_REQ: obj.setLcApplicantReq(stringToChar(rs.getString(++pos)));
                    break;
                case LC_APPLICANT_TYPE: obj.setLcApplicantType(stringToChar(rs.getString(++pos)));
                    break;
                case LC_APPLICANT_BRN_CODE: obj.setLcApplicantBrnCode(rs.getString(++pos));
                    break;
                case LC_APPLICANT_BIC_CODE: obj.setLcApplicantBicCode(rs.getString(++pos));
                    break;
                case LC_APPLICANT_ROUTID: obj.setLcApplicantRoutid(rs.getString(++pos));
                    break;
                case LC_APPLICANT_BNK_CODE: obj.setLcApplicantBnkCode(rs.getString(++pos));
                    break;
                case LC_APPLICANT_ADDR1: obj.setLcApplicantAddr1(rs.getString(++pos));
                    break;
                case LC_APPLICANT_ADDR2: obj.setLcApplicantAddr2(rs.getString(++pos));
                    break;
                case LC_APPLICANT_ADDR3: obj.setLcApplicantAddr3(rs.getString(++pos));
                    break;
                case LC_APPLICANT_ADDR4: obj.setLcApplicantAddr4(rs.getString(++pos));
                    break;
                case LC_APPLICANT_ADDR5: obj.setLcApplicantAddr5(rs.getString(++pos));
                    break;
                case LC_AVAILABLE_WITH_TYPE: obj.setLcAvailableWithType(stringToChar(rs.getString(++pos)));
                    break;
                case LC_AVAILABLE_WITH_BRN_CODE: obj.setLcAvailableWithBrnCode(rs.getString(++pos));
                    break;
                case LC_AVAILABLE_WITH_CODE: obj.setLcAvailableWithCode(rs.getString(++pos));
                    break;
                case LC_AVAILABLE_WITH_ROUTID: obj.setLcAvailableWithRoutid(rs.getString(++pos));
                    break;
                case LC_AVAILABLE_WITH_BNK_CODE: obj.setLcAvailableWithBnkCode(rs.getString(++pos));
                    break;
                case LC_AVAILABLE_WITH_ADDR1: obj.setLcAvailableWithAddr1(rs.getString(++pos));
                    break;
                case LC_AVAILABLE_WITH_ADDR2: obj.setLcAvailableWithAddr2(rs.getString(++pos));
                    break;
                case LC_AVAILABLE_WITH_ADDR3: obj.setLcAvailableWithAddr3(rs.getString(++pos));
                    break;
                case LC_AVAILABLE_WITH_ADDR4: obj.setLcAvailableWithAddr4(rs.getString(++pos));
                    break;
                case LC_AVAILABLE_WITH_ADDR5: obj.setLcAvailableWithAddr5(rs.getString(++pos));
                    break;
                case LC_DRAFTS_AT1: obj.setLcDraftsAt1(rs.getString(++pos));
                    break;
                case LC_DRAFTS_AT2: obj.setLcDraftsAt2(rs.getString(++pos));
                    break;
                case LC_DRAFTS_AT3: obj.setLcDraftsAt3(rs.getString(++pos));
                    break;
                case LC_DRAWEE_REQ: obj.setLcDraweeReq(stringToChar(rs.getString(++pos)));
                    break;
                case LC_DRAWEE_TYPE: obj.setLcDraweeType(stringToChar(rs.getString(++pos)));
                    break;
                case LC_DRAWEE_BRN_CODE: obj.setLcDraweeBrnCode(rs.getString(++pos));
                    break;
                case LC_DRAWEE_BIC_CODE: obj.setLcDraweeBicCode(rs.getString(++pos));
                    break;
                case LC_DRAWEE_ROUTID: obj.setLcDraweeRoutid(rs.getString(++pos));
                    break;
                case LC_DRAWEE_BNK_CODE: obj.setLcDraweeBnkCode(rs.getString(++pos));
                    break;
                case LC_DRAWEE_ADDR1: obj.setLcDraweeAddr1(rs.getString(++pos));
                    break;
                case LC_DRAWEE_ADDR2: obj.setLcDraweeAddr2(rs.getString(++pos));
                    break;
                case LC_DRAWEE_ADDR3: obj.setLcDraweeAddr3(rs.getString(++pos));
                    break;
                case LC_DRAWEE_ADDR4: obj.setLcDraweeAddr4(rs.getString(++pos));
                    break;
                case LC_DRAWEE_ADDR5: obj.setLcDraweeAddr5(rs.getString(++pos));
                    break;
                case LC_MIXED_PAY_DETAILS1: obj.setLcMixedPayDetails1(rs.getString(++pos));
                    break;
                case LC_MIXED_PAY_DETAILS2: obj.setLcMixedPayDetails2(rs.getString(++pos));
                    break;
                case LC_MIXED_PAY_DETAILS3: obj.setLcMixedPayDetails3(rs.getString(++pos));
                    break;
                case LC_MIXED_PAY_DETAILS4: obj.setLcMixedPayDetails4(rs.getString(++pos));
                    break;
                case LC_DEFERRED_PAY_DETAILS1: obj.setLcDeferredPayDetails1(rs.getString(++pos));
                    break;
                case LC_DEFERRED_PAY_DETAILS2: obj.setLcDeferredPayDetails2(rs.getString(++pos));
                    break;
                case LC_DEFERRED_PAY_DETAILS3: obj.setLcDeferredPayDetails3(rs.getString(++pos));
                    break;
                case LC_DEFERRED_PAY_DETAILS4: obj.setLcDeferredPayDetails4(rs.getString(++pos));
                    break;
                case LC_PARTIAL_SHIPMENTS: obj.setLcPartialShipments(rs.getInt(++pos));
                    break;
                case LC_TRANSHIPMENT: obj.setLcTranshipment(rs.getInt(++pos));
                    break;
                case LC_PLACE_OF_TAKING_IN_CHARGE: obj.setLcPlaceOfTakingInCharge(rs.getString(++pos));
                    break;
                case LC_PORT_OF_LOADING: obj.setLcPortOfLoading(rs.getString(++pos));
                    break;
                case LC_PORT_OF_DISCHARGE: obj.setLcPortOfDischarge(rs.getString(++pos));
                    break;
                case LC_PLACE_OF_FINAL_DEST: obj.setLcPlaceOfFinalDest(rs.getString(++pos));
                    break;
                case LC_DESC_GOODS_SER1: obj.setLcDescGoodsSer1(rs.getObject(++pos));
                    break;
                case LC_DESC_GOODS_SER2: obj.setLcDescGoodsSer2(rs.getObject(++pos));
                    break;
                case LC_DESC_GOODS_SER3: obj.setLcDescGoodsSer3(rs.getObject(++pos));
                    break;
                case LC_DOC_REQ1: obj.setLcDocReq1(rs.getObject(++pos));
                    break;
                case LC_DOC_REQ2: obj.setLcDocReq2(rs.getObject(++pos));
                    break;
                case LC_DOC_REQ3: obj.setLcDocReq3(rs.getObject(++pos));
                    break;
                case LC_ADD_CONDITION1: obj.setLcAddCondition1(rs.getObject(++pos));
                    break;
                case LC_ADD_CONDITION2: obj.setLcAddCondition2(rs.getObject(++pos));
                    break;
                case LC_ADD_CONDITION3: obj.setLcAddCondition3(rs.getObject(++pos));
                    break;
                case LC_CHARGES1: obj.setLcCharges1(rs.getString(++pos));
                    break;
                case LC_CHARGES2: obj.setLcCharges2(rs.getString(++pos));
                    break;
                case LC_CHARGES3: obj.setLcCharges3(rs.getString(++pos));
                    break;
                case LC_CHARGES4: obj.setLcCharges4(rs.getString(++pos));
                    break;
                case LC_CHARGES5: obj.setLcCharges5(rs.getString(++pos));
                    break;
                case LC_CHARGES6: obj.setLcCharges6(rs.getString(++pos));
                    break;
                case LC_PER_PRESENTATION_DAY: obj.setLcPerPresentationDay(rs.getInt(++pos));
                    break;
                case LC_CONFIRMATION_INST: obj.setLcConfirmationInst(rs.getInt(++pos));
                    break;
                case LC_REIMB_REQ: obj.setLcReimbReq(stringToChar(rs.getString(++pos)));
                    break;
                case LC_REIMB_TYPE: obj.setLcReimbType(stringToChar(rs.getString(++pos)));
                    break;
                case LC_REIMB_BRN_CODE: obj.setLcReimbBrnCode(rs.getString(++pos));
                    break;
                case LC_REIMB_BIC_CODE: obj.setLcReimbBicCode(rs.getString(++pos));
                    break;
                case LC_REIMB_ROUTID: obj.setLcReimbRoutid(rs.getString(++pos));
                    break;
                case LC_REIMB_BNK_CODE: obj.setLcReimbBnkCode(rs.getString(++pos));
                    break;
                case LC_REIMB_ADDR1: obj.setLcReimbAddr1(rs.getString(++pos));
                    break;
                case LC_REIMB_ADDR2: obj.setLcReimbAddr2(rs.getString(++pos));
                    break;
                case LC_REIMB_ADDR3: obj.setLcReimbAddr3(rs.getString(++pos));
                    break;
                case LC_REIMB_ADDR4: obj.setLcReimbAddr4(rs.getString(++pos));
                    break;
                case LC_REIMB_ADDR5: obj.setLcReimbAddr5(rs.getString(++pos));
                    break;
                case LC_INST_PAYING1: obj.setLcInstPaying1(rs.getString(++pos));
                    break;
                case LC_INST_PAYING2: obj.setLcInstPaying2(rs.getString(++pos));
                    break;
                case LC_INST_PAYING3: obj.setLcInstPaying3(rs.getString(++pos));
                    break;
                case LC_INST_PAYING4: obj.setLcInstPaying4(rs.getString(++pos));
                    break;
                case LC_INST_PAYING5: obj.setLcInstPaying5(rs.getString(++pos));
                    break;
                case LC_INST_PAYING6: obj.setLcInstPaying6(rs.getString(++pos));
                    break;
                case LC_INST_PAYING7: obj.setLcInstPaying7(rs.getString(++pos));
                    break;
                case LC_INST_PAYING8: obj.setLcInstPaying8(rs.getString(++pos));
                    break;
                case LC_INST_PAYING9: obj.setLcInstPaying9(rs.getString(++pos));
                    break;
                case LC_INST_PAYING10: obj.setLcInstPaying10(rs.getString(++pos));
                    break;
                case LC_INST_PAYING11: obj.setLcInstPaying11(rs.getString(++pos));
                    break;
                case LC_INST_PAYING12: obj.setLcInstPaying12(rs.getString(++pos));
                    break;
                case LC_SECOND_ADV_REQ: obj.setLcSecondAdvReq(stringToChar(rs.getString(++pos)));
                    break;
                case LC_SECOND_ADV_TYPE: obj.setLcSecondAdvType(stringToChar(rs.getString(++pos)));
                    break;
                case LC_SECOND_ADV_BRN_CODE: obj.setLcSecondAdvBrnCode(rs.getString(++pos));
                    break;
                case LC_SECOND_ADV_BIC_CODE: obj.setLcSecondAdvBicCode(rs.getString(++pos));
                    break;
                case LC_SECOND_ADV_ROUTID: obj.setLcSecondAdvRoutid(rs.getString(++pos));
                    break;
                case LC_SECOND_ADV_BNK_CODE: obj.setLcSecondAdvBnkCode(rs.getString(++pos));
                    break;
                case LC_SECOND_ADV_ADDR1: obj.setLcSecondAdvAddr1(rs.getString(++pos));
                    break;
                case LC_SECOND_ADV_ADDR2: obj.setLcSecondAdvAddr2(rs.getString(++pos));
                    break;
                case LC_SECOND_ADV_ADDR3: obj.setLcSecondAdvAddr3(rs.getString(++pos));
                    break;
                case LC_SECOND_ADV_ADDR4: obj.setLcSecondAdvAddr4(rs.getString(++pos));
                    break;
                case LC_SECOND_ADV_ADDR5: obj.setLcSecondAdvAddr5(rs.getString(++pos));
                    break;
                case LC_SNDR_REC_INFO1: obj.setLcSndrRecInfo1(rs.getString(++pos));
                    break;
                case LC_SNDR_REC_INFO2: obj.setLcSndrRecInfo2(rs.getString(++pos));
                    break;
                case LC_SNDR_REC_INFO3: obj.setLcSndrRecInfo3(rs.getString(++pos));
                    break;
                case LC_SNDR_REC_INFO4: obj.setLcSndrRecInfo4(rs.getString(++pos));
                    break;
                case LC_SNDR_REC_INFO5: obj.setLcSndrRecInfo5(rs.getString(++pos));
                    break;
                case LC_SNDR_REC_INFO6: obj.setLcSndrRecInfo6(rs.getString(++pos));
                    break;
                case LC_APPLICANT_CNTRY_CODE: obj.setLcApplicantCntryCode(rs.getString(++pos));
                    break;
                case LC_AVAILABLE_WITH_CNTRY: obj.setLcAvailableWithCntry(rs.getString(++pos));
                    break;
                case LC_AVAILABLE_WITH_CODETYP: obj.setLcAvailableWithCodetyp(rs.getInt(++pos));
                    break;
                case LC_DRAWEE_CNTRY_CODE: obj.setLcDraweeCntryCode(rs.getString(++pos));
                    break;
                case LC_CONFIRM_INST_TYPE: obj.setLcConfirmInstType(stringToChar(rs.getString(++pos)));
                    break;
                case LC_REIMB_CNTRY_CODE: obj.setLcReimbCntryCode(rs.getString(++pos));
                    break;
                case LC_SECOND_ADV_CNTRYCODE: obj.setLcSecondAdvCntrycode(rs.getString(++pos));
                    break;
                case LC_SHIPMENT_PERIOD1: obj.setLcShipmentPeriod1(rs.getString(++pos));
                    break;
                case LC_SHIPMENT_PERIOD2: obj.setLcShipmentPeriod2(rs.getString(++pos));
                    break;
                case LC_SHIPMENT_PERIOD3: obj.setLcShipmentPeriod3(rs.getString(++pos));
                    break;
                case LC_SHIPMENT_PERIOD4: obj.setLcShipmentPeriod4(rs.getString(++pos));
                    break;
                case LC_SHIPMENT_PERIOD5: obj.setLcShipmentPeriod5(rs.getString(++pos));
                    break;
                case LC_SHIPMENT_PERIOD6: obj.setLcShipmentPeriod6(rs.getString(++pos));
                    break;
                case LC_PER_PRESENTATION_REMARKS: obj.setLcPerPresentationRemarks(rs.getString(++pos));
                    break;
                case LC_REC_BIC_CODE: obj.setLcRecBicCode(rs.getString(++pos));
                    break;
                case LC_CFM_REIMB_TYPE: obj.setLcCfmReimbType(stringToChar(rs.getString(++pos)));
                    break;
                case LC_CFM_REIMB_BRN_CODE: obj.setLcCfmReimbBrnCode(rs.getString(++pos));
                    break;
                case LC_CFM_REIMB_BIC_CODE: obj.setLcCfmReimbBicCode(rs.getString(++pos));
                    break;
                case LC_CFM_REIMB_ROUTID: obj.setLcCfmReimbRoutid(rs.getString(++pos));
                    break;
                case LC_CFM_REIMB_BNK_CODE: obj.setLcCfmReimbBnkCode(rs.getString(++pos));
                    break;
                case LC_CFM_REIMB_ADDR1: obj.setLcCfmReimbAddr1(rs.getString(++pos));
                    break;
                case LC_CFM_REIMB_ADDR2: obj.setLcCfmReimbAddr2(rs.getString(++pos));
                    break;
                case LC_CFM_REIMB_ADDR3: obj.setLcCfmReimbAddr3(rs.getString(++pos));
                    break;
                case LC_CFM_REIMB_ADDR4: obj.setLcCfmReimbAddr4(rs.getString(++pos));
                    break;
                case LC_CFM_REIMB_ADDR5: obj.setLcCfmReimbAddr5(rs.getString(++pos));
                    break;
                case LC_CFM_REIMB_CNTRY_CODE: obj.setLcCfmReimbCntryCode(rs.getString(++pos));
                    break;
            }
        }
        obj.setIsNew(false);
        obj.resetIsModifiedS2J();

        return obj;
    }
    public void save(LcDetails obj, String tba_main_key, Timestamp tba_entry_date, long tab_dtl_sl ) throws SQLException {
            NewData_Key = "LC_DETAILS" + TableValueSep + NewDataChar + obj.getLcBrnCode() + obj.getLcLcType() + obj.getLcLcYear() + obj.getLcLcSl();
            DataBlock_New = obj.getLcBrnCode() + JNDINames.splitchar + obj.getLcLcType() + JNDINames.splitchar + obj.getLcLcYear() + JNDINames.splitchar + obj.getLcLcSl() + JNDINames.splitchar + obj.getLcFormOfDocCredit() + JNDINames.splitchar + obj.getLcReferenceToPreadvice() + JNDINames.splitchar + obj.getLcApplicableRules() + JNDINames.splitchar + obj.getLcApplicantReq() + JNDINames.splitchar + obj.getLcApplicantType() + JNDINames.splitchar + obj.getLcApplicantBrnCode() + JNDINames.splitchar + obj.getLcApplicantBicCode() + JNDINames.splitchar + obj.getLcApplicantRoutid() + JNDINames.splitchar + obj.getLcApplicantBnkCode() + JNDINames.splitchar + obj.getLcApplicantAddr1() + JNDINames.splitchar + obj.getLcApplicantAddr2() + JNDINames.splitchar + obj.getLcApplicantAddr3() + JNDINames.splitchar + obj.getLcApplicantAddr4() + JNDINames.splitchar + obj.getLcApplicantAddr5() + JNDINames.splitchar + obj.getLcAvailableWithType() + JNDINames.splitchar + obj.getLcAvailableWithBrnCode() + JNDINames.splitchar + obj.getLcAvailableWithCode() + JNDINames.splitchar + obj.getLcAvailableWithRoutid() + JNDINames.splitchar + obj.getLcAvailableWithBnkCode() + JNDINames.splitchar + obj.getLcAvailableWithAddr1() + JNDINames.splitchar + obj.getLcAvailableWithAddr2() + JNDINames.splitchar + obj.getLcAvailableWithAddr3() + JNDINames.splitchar + obj.getLcAvailableWithAddr4() + JNDINames.splitchar + obj.getLcAvailableWithAddr5() + JNDINames.splitchar + obj.getLcDraftsAt1() + JNDINames.splitchar + obj.getLcDraftsAt2() + JNDINames.splitchar + obj.getLcDraftsAt3() + JNDINames.splitchar + obj.getLcDraweeReq() + JNDINames.splitchar + obj.getLcDraweeType() + JNDINames.splitchar + obj.getLcDraweeBrnCode() + JNDINames.splitchar + obj.getLcDraweeBicCode() + JNDINames.splitchar + obj.getLcDraweeRoutid() + JNDINames.splitchar + obj.getLcDraweeBnkCode() + JNDINames.splitchar + obj.getLcDraweeAddr1() + JNDINames.splitchar + obj.getLcDraweeAddr2() + JNDINames.splitchar + obj.getLcDraweeAddr3() + JNDINames.splitchar + obj.getLcDraweeAddr4() + JNDINames.splitchar + obj.getLcDraweeAddr5() + JNDINames.splitchar + obj.getLcMixedPayDetails1() + JNDINames.splitchar + obj.getLcMixedPayDetails2() + JNDINames.splitchar + obj.getLcMixedPayDetails3() + JNDINames.splitchar + obj.getLcMixedPayDetails4() + JNDINames.splitchar + obj.getLcDeferredPayDetails1() + JNDINames.splitchar + obj.getLcDeferredPayDetails2() + JNDINames.splitchar + obj.getLcDeferredPayDetails3() + JNDINames.splitchar + obj.getLcDeferredPayDetails4() + JNDINames.splitchar + obj.getLcPartialShipments() + JNDINames.splitchar + obj.getLcTranshipment() + JNDINames.splitchar + obj.getLcPlaceOfTakingInCharge() + JNDINames.splitchar + obj.getLcPortOfLoading() + JNDINames.splitchar + obj.getLcPortOfDischarge() + JNDINames.splitchar + obj.getLcPlaceOfFinalDest() + JNDINames.splitchar + obj.getLcDescGoodsSer1() + JNDINames.splitchar + obj.getLcDescGoodsSer2() + JNDINames.splitchar + obj.getLcDescGoodsSer3() + JNDINames.splitchar + obj.getLcDocReq1() + JNDINames.splitchar + obj.getLcDocReq2() + JNDINames.splitchar + obj.getLcDocReq3() + JNDINames.splitchar + obj.getLcAddCondition1() + JNDINames.splitchar + obj.getLcAddCondition2() + JNDINames.splitchar + obj.getLcAddCondition3() + JNDINames.splitchar + obj.getLcCharges1() + JNDINames.splitchar + obj.getLcCharges2() + JNDINames.splitchar + obj.getLcCharges3() + JNDINames.splitchar + obj.getLcCharges4() + JNDINames.splitchar + obj.getLcCharges5() + JNDINames.splitchar + obj.getLcCharges6() + JNDINames.splitchar + obj.getLcPerPresentationDay() + JNDINames.splitchar + obj.getLcConfirmationInst() + JNDINames.splitchar + obj.getLcReimbReq() + JNDINames.splitchar + obj.getLcReimbType() + JNDINames.splitchar + obj.getLcReimbBrnCode() + JNDINames.splitchar + obj.getLcReimbBicCode() + JNDINames.splitchar + obj.getLcReimbRoutid() + JNDINames.splitchar + obj.getLcReimbBnkCode() + JNDINames.splitchar + obj.getLcReimbAddr1() + JNDINames.splitchar + obj.getLcReimbAddr2() + JNDINames.splitchar + obj.getLcReimbAddr3() + JNDINames.splitchar + obj.getLcReimbAddr4() + JNDINames.splitchar + obj.getLcReimbAddr5() + JNDINames.splitchar + obj.getLcInstPaying1() + JNDINames.splitchar + obj.getLcInstPaying2() + JNDINames.splitchar + obj.getLcInstPaying3() + JNDINames.splitchar + obj.getLcInstPaying4() + JNDINames.splitchar + obj.getLcInstPaying5() + JNDINames.splitchar + obj.getLcInstPaying6() + JNDINames.splitchar + obj.getLcInstPaying7() + JNDINames.splitchar + obj.getLcInstPaying8() + JNDINames.splitchar + obj.getLcInstPaying9() + JNDINames.splitchar + obj.getLcInstPaying10() + JNDINames.splitchar + obj.getLcInstPaying11() + JNDINames.splitchar + obj.getLcInstPaying12() + JNDINames.splitchar + obj.getLcSecondAdvReq() + JNDINames.splitchar + obj.getLcSecondAdvType() + JNDINames.splitchar + obj.getLcSecondAdvBrnCode() + JNDINames.splitchar + obj.getLcSecondAdvBicCode() + JNDINames.splitchar + obj.getLcSecondAdvRoutid() + JNDINames.splitchar + obj.getLcSecondAdvBnkCode() + JNDINames.splitchar + obj.getLcSecondAdvAddr1() + JNDINames.splitchar + obj.getLcSecondAdvAddr2() + JNDINames.splitchar + obj.getLcSecondAdvAddr3() + JNDINames.splitchar + obj.getLcSecondAdvAddr4() + JNDINames.splitchar + obj.getLcSecondAdvAddr5() + JNDINames.splitchar + obj.getLcSndrRecInfo1() + JNDINames.splitchar + obj.getLcSndrRecInfo2() + JNDINames.splitchar + obj.getLcSndrRecInfo3() + JNDINames.splitchar + obj.getLcSndrRecInfo4() + JNDINames.splitchar + obj.getLcSndrRecInfo5() + JNDINames.splitchar + obj.getLcSndrRecInfo6() + JNDINames.splitchar + obj.getLcApplicantCntryCode() + JNDINames.splitchar + obj.getLcAvailableWithCntry() + JNDINames.splitchar + obj.getLcAvailableWithCodetyp() + JNDINames.splitchar + obj.getLcDraweeCntryCode() + JNDINames.splitchar + obj.getLcConfirmInstType() + JNDINames.splitchar + obj.getLcReimbCntryCode() + JNDINames.splitchar + obj.getLcSecondAdvCntrycode() + JNDINames.splitchar + obj.getLcShipmentPeriod1() + JNDINames.splitchar + obj.getLcShipmentPeriod2() + JNDINames.splitchar + obj.getLcShipmentPeriod3() + JNDINames.splitchar + obj.getLcShipmentPeriod4() + JNDINames.splitchar + obj.getLcShipmentPeriod5() + JNDINames.splitchar + obj.getLcShipmentPeriod6() + JNDINames.splitchar + obj.getLcPerPresentationRemarks() + JNDINames.splitchar + obj.getLcRecBicCode() + JNDINames.splitchar + obj.getLcCfmReimbType() + JNDINames.splitchar + obj.getLcCfmReimbBrnCode() + JNDINames.splitchar + obj.getLcCfmReimbBicCode() + JNDINames.splitchar + obj.getLcCfmReimbRoutid() + JNDINames.splitchar + obj.getLcCfmReimbBnkCode() + JNDINames.splitchar + obj.getLcCfmReimbAddr1() + JNDINames.splitchar + obj.getLcCfmReimbAddr2() + JNDINames.splitchar + obj.getLcCfmReimbAddr3() + JNDINames.splitchar + obj.getLcCfmReimbAddr4() + JNDINames.splitchar + obj.getLcCfmReimbAddr5() + JNDINames.splitchar + obj.getLcCfmReimbCntryCode();
                if (_Logreq == 1)
                {
                    if (obj.isNew() == false)
                    {
                        if (OldData_Key != null) this._COLLECTIONobj.put(OldData_Key , DataBlock_Old );
                        if (NewData_Key != null) this._COLLECTIONobj.put(NewData_Key , DataBlock_New );
                    }else if ((_Logaddreq == 1) && obj.isNew() == true)
                    {
                        if (NewData_Key != null) this._COLLECTIONobj.put(NewData_Key , DataBlock_New );
                    }
                }
            OldData_Key ="";
            DataBlock_Old = "";
            DataBlock_New = "";
            NewData_Key = "";
        {
    // This is for main table Updation
            save(obj);
        }
    }

}
