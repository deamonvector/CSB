package panacea.OLC.Update;


/******************SQL2JAVA_IMPORT_BEGIN******************/

/******************SQL2JAVA_IMPORT_END********************/


public class LcDetails
/******************SQL2JAVA_EXTENDS_BEGIN******************/

/******************SQL2JAVA_EXTENDS_END********************/

{

/******************SQL2JAVA_CLASS_BEGIN******************/

/******************SQL2JAVA_CLASS_END********************/


    private int _lcBrnCode;
    private boolean __lcBrnCode_is_modified;
    private String _lcLcType;
    private boolean __lcLcType_is_modified;
    private int _lcLcYear;
    private boolean __lcLcYear_is_modified;
    private int _lcLcSl;
    private boolean __lcLcSl_is_modified;
    private int _lcFormOfDocCredit;
    private boolean __lcFormOfDocCredit_is_modified;
    private String _lcReferenceToPreadvice;
    private boolean __lcReferenceToPreadvice_is_modified;
    private int _lcApplicableRules;
    private boolean __lcApplicableRules_is_modified;
    private char _lcApplicantReq;
    private boolean __lcApplicantReq_is_modified;
    private char _lcApplicantType;
    private boolean __lcApplicantType_is_modified;
    private String _lcApplicantBrnCode;
    private boolean __lcApplicantBrnCode_is_modified;
    private String _lcApplicantBicCode;
    private boolean __lcApplicantBicCode_is_modified;
    private String _lcApplicantRoutid;
    private boolean __lcApplicantRoutid_is_modified;
    private String _lcApplicantBnkCode;
    private boolean __lcApplicantBnkCode_is_modified;
    private String _lcApplicantAddr1;
    private boolean __lcApplicantAddr1_is_modified;
    private String _lcApplicantAddr2;
    private boolean __lcApplicantAddr2_is_modified;
    private String _lcApplicantAddr3;
    private boolean __lcApplicantAddr3_is_modified;
    private String _lcApplicantAddr4;
    private boolean __lcApplicantAddr4_is_modified;
    private String _lcApplicantAddr5;
    private boolean __lcApplicantAddr5_is_modified;
    private char _lcAvailableWithType;
    private boolean __lcAvailableWithType_is_modified;
    private String _lcAvailableWithBrnCode;
    private boolean __lcAvailableWithBrnCode_is_modified;
    private String _lcAvailableWithCode;
    private boolean __lcAvailableWithCode_is_modified;
    private String _lcAvailableWithRoutid;
    private boolean __lcAvailableWithRoutid_is_modified;
    private String _lcAvailableWithBnkCode;
    private boolean __lcAvailableWithBnkCode_is_modified;
    private String _lcAvailableWithAddr1;
    private boolean __lcAvailableWithAddr1_is_modified;
    private String _lcAvailableWithAddr2;
    private boolean __lcAvailableWithAddr2_is_modified;
    private String _lcAvailableWithAddr3;
    private boolean __lcAvailableWithAddr3_is_modified;
    private String _lcAvailableWithAddr4;
    private boolean __lcAvailableWithAddr4_is_modified;
    private String _lcAvailableWithAddr5;
    private boolean __lcAvailableWithAddr5_is_modified;
    private String _lcDraftsAt1;
    private boolean __lcDraftsAt1_is_modified;
    private String _lcDraftsAt2;
    private boolean __lcDraftsAt2_is_modified;
    private String _lcDraftsAt3;
    private boolean __lcDraftsAt3_is_modified;
    private char _lcDraweeReq;
    private boolean __lcDraweeReq_is_modified;
    private char _lcDraweeType;
    private boolean __lcDraweeType_is_modified;
    private String _lcDraweeBrnCode;
    private boolean __lcDraweeBrnCode_is_modified;
    private String _lcDraweeBicCode;
    private boolean __lcDraweeBicCode_is_modified;
    private String _lcDraweeRoutid;
    private boolean __lcDraweeRoutid_is_modified;
    private String _lcDraweeBnkCode;
    private boolean __lcDraweeBnkCode_is_modified;
    private String _lcDraweeAddr1;
    private boolean __lcDraweeAddr1_is_modified;
    private String _lcDraweeAddr2;
    private boolean __lcDraweeAddr2_is_modified;
    private String _lcDraweeAddr3;
    private boolean __lcDraweeAddr3_is_modified;
    private String _lcDraweeAddr4;
    private boolean __lcDraweeAddr4_is_modified;
    private String _lcDraweeAddr5;
    private boolean __lcDraweeAddr5_is_modified;
    private String _lcMixedPayDetails1;
    private boolean __lcMixedPayDetails1_is_modified;
    private String _lcMixedPayDetails2;
    private boolean __lcMixedPayDetails2_is_modified;
    private String _lcMixedPayDetails3;
    private boolean __lcMixedPayDetails3_is_modified;
    private String _lcMixedPayDetails4;
    private boolean __lcMixedPayDetails4_is_modified;
    private String _lcDeferredPayDetails1;
    private boolean __lcDeferredPayDetails1_is_modified;
    private String _lcDeferredPayDetails2;
    private boolean __lcDeferredPayDetails2_is_modified;
    private String _lcDeferredPayDetails3;
    private boolean __lcDeferredPayDetails3_is_modified;
    private String _lcDeferredPayDetails4;
    private boolean __lcDeferredPayDetails4_is_modified;
    private int _lcPartialShipments;
    private boolean __lcPartialShipments_is_modified;
    private int _lcTranshipment;
    private boolean __lcTranshipment_is_modified;
    private String _lcPlaceOfTakingInCharge;
    private boolean __lcPlaceOfTakingInCharge_is_modified;
    private String _lcPortOfLoading;
    private boolean __lcPortOfLoading_is_modified;
    private String _lcPortOfDischarge;
    private boolean __lcPortOfDischarge_is_modified;
    private String _lcPlaceOfFinalDest;
    private boolean __lcPlaceOfFinalDest_is_modified;
    private Object _lcDescGoodsSer1;
    private boolean __lcDescGoodsSer1_is_modified;
    private Object _lcDescGoodsSer2;
    private boolean __lcDescGoodsSer2_is_modified;
    private Object _lcDescGoodsSer3;
    private boolean __lcDescGoodsSer3_is_modified;
    private Object _lcDocReq1;
    private boolean __lcDocReq1_is_modified;
    private Object _lcDocReq2;
    private boolean __lcDocReq2_is_modified;
    private Object _lcDocReq3;
    private boolean __lcDocReq3_is_modified;
    private Object _lcAddCondition1;
    private boolean __lcAddCondition1_is_modified;
    private Object _lcAddCondition2;
    private boolean __lcAddCondition2_is_modified;
    private Object _lcAddCondition3;
    private boolean __lcAddCondition3_is_modified;
    private String _lcCharges1;
    private boolean __lcCharges1_is_modified;
    private String _lcCharges2;
    private boolean __lcCharges2_is_modified;
    private String _lcCharges3;
    private boolean __lcCharges3_is_modified;
    private String _lcCharges4;
    private boolean __lcCharges4_is_modified;
    private String _lcCharges5;
    private boolean __lcCharges5_is_modified;
    private String _lcCharges6;
    private boolean __lcCharges6_is_modified;
    private int _lcPerPresentationDay;
    private boolean __lcPerPresentationDay_is_modified;
    private int _lcConfirmationInst;
    private boolean __lcConfirmationInst_is_modified;
    private char _lcReimbReq;
    private boolean __lcReimbReq_is_modified;
    private char _lcReimbType;
    private boolean __lcReimbType_is_modified;
    private String _lcReimbBrnCode;
    private boolean __lcReimbBrnCode_is_modified;
    private String _lcReimbBicCode;
    private boolean __lcReimbBicCode_is_modified;
    private String _lcReimbRoutid;
    private boolean __lcReimbRoutid_is_modified;
    private String _lcReimbBnkCode;
    private boolean __lcReimbBnkCode_is_modified;
    private String _lcReimbAddr1;
    private boolean __lcReimbAddr1_is_modified;
    private String _lcReimbAddr2;
    private boolean __lcReimbAddr2_is_modified;
    private String _lcReimbAddr3;
    private boolean __lcReimbAddr3_is_modified;
    private String _lcReimbAddr4;
    private boolean __lcReimbAddr4_is_modified;
    private String _lcReimbAddr5;
    private boolean __lcReimbAddr5_is_modified;
    private String _lcInstPaying1;
    private boolean __lcInstPaying1_is_modified;
    private String _lcInstPaying2;
    private boolean __lcInstPaying2_is_modified;
    private String _lcInstPaying3;
    private boolean __lcInstPaying3_is_modified;
    private String _lcInstPaying4;
    private boolean __lcInstPaying4_is_modified;
    private String _lcInstPaying5;
    private boolean __lcInstPaying5_is_modified;
    private String _lcInstPaying6;
    private boolean __lcInstPaying6_is_modified;
    private String _lcInstPaying7;
    private boolean __lcInstPaying7_is_modified;
    private String _lcInstPaying8;
    private boolean __lcInstPaying8_is_modified;
    private String _lcInstPaying9;
    private boolean __lcInstPaying9_is_modified;
    private String _lcInstPaying10;
    private boolean __lcInstPaying10_is_modified;
    private String _lcInstPaying11;
    private boolean __lcInstPaying11_is_modified;
    private String _lcInstPaying12;
    private boolean __lcInstPaying12_is_modified;
    private char _lcSecondAdvReq;
    private boolean __lcSecondAdvReq_is_modified;
    private char _lcSecondAdvType;
    private boolean __lcSecondAdvType_is_modified;
    private String _lcSecondAdvBrnCode;
    private boolean __lcSecondAdvBrnCode_is_modified;
    private String _lcSecondAdvBicCode;
    private boolean __lcSecondAdvBicCode_is_modified;
    private String _lcSecondAdvRoutid;
    private boolean __lcSecondAdvRoutid_is_modified;
    private String _lcSecondAdvBnkCode;
    private boolean __lcSecondAdvBnkCode_is_modified;
    private String _lcSecondAdvAddr1;
    private boolean __lcSecondAdvAddr1_is_modified;
    private String _lcSecondAdvAddr2;
    private boolean __lcSecondAdvAddr2_is_modified;
    private String _lcSecondAdvAddr3;
    private boolean __lcSecondAdvAddr3_is_modified;
    private String _lcSecondAdvAddr4;
    private boolean __lcSecondAdvAddr4_is_modified;
    private String _lcSecondAdvAddr5;
    private boolean __lcSecondAdvAddr5_is_modified;
    private String _lcSndrRecInfo1;
    private boolean __lcSndrRecInfo1_is_modified;
    private String _lcSndrRecInfo2;
    private boolean __lcSndrRecInfo2_is_modified;
    private String _lcSndrRecInfo3;
    private boolean __lcSndrRecInfo3_is_modified;
    private String _lcSndrRecInfo4;
    private boolean __lcSndrRecInfo4_is_modified;
    private String _lcSndrRecInfo5;
    private boolean __lcSndrRecInfo5_is_modified;
    private String _lcSndrRecInfo6;
    private boolean __lcSndrRecInfo6_is_modified;
    private String _lcApplicantCntryCode;
    private boolean __lcApplicantCntryCode_is_modified;
    private String _lcAvailableWithCntry;
    private boolean __lcAvailableWithCntry_is_modified;
    private int _lcAvailableWithCodetyp;
    private boolean __lcAvailableWithCodetyp_is_modified;
    private String _lcDraweeCntryCode;
    private boolean __lcDraweeCntryCode_is_modified;
    private char _lcConfirmInstType;
    private boolean __lcConfirmInstType_is_modified;
    private String _lcReimbCntryCode;
    private boolean __lcReimbCntryCode_is_modified;
    private String _lcSecondAdvCntrycode;
    private boolean __lcSecondAdvCntrycode_is_modified;
    private String _lcShipmentPeriod1;
    private boolean __lcShipmentPeriod1_is_modified;
    private String _lcShipmentPeriod2;
    private boolean __lcShipmentPeriod2_is_modified;
    private String _lcShipmentPeriod3;
    private boolean __lcShipmentPeriod3_is_modified;
    private String _lcShipmentPeriod4;
    private boolean __lcShipmentPeriod4_is_modified;
    private String _lcShipmentPeriod5;
    private boolean __lcShipmentPeriod5_is_modified;
    private String _lcShipmentPeriod6;
    private boolean __lcShipmentPeriod6_is_modified;
    private String _lcPerPresentationRemarks;
    private boolean __lcPerPresentationRemarks_is_modified;
    private String _lcRecBicCode;
    private boolean __lcRecBicCode_is_modified;
    private char _lcCfmReimbType;
    private boolean __lcCfmReimbType_is_modified;
    private String _lcCfmReimbBrnCode;
    private boolean __lcCfmReimbBrnCode_is_modified;
    private String _lcCfmReimbBicCode;
    private boolean __lcCfmReimbBicCode_is_modified;
    private String _lcCfmReimbRoutid;
    private boolean __lcCfmReimbRoutid_is_modified;
    private String _lcCfmReimbBnkCode;
    private boolean __lcCfmReimbBnkCode_is_modified;
    private String _lcCfmReimbAddr1;
    private boolean __lcCfmReimbAddr1_is_modified;
    private String _lcCfmReimbAddr2;
    private boolean __lcCfmReimbAddr2_is_modified;
    private String _lcCfmReimbAddr3;
    private boolean __lcCfmReimbAddr3_is_modified;
    private String _lcCfmReimbAddr4;
    private boolean __lcCfmReimbAddr4_is_modified;
    private String _lcCfmReimbAddr5;
    private boolean __lcCfmReimbAddr5_is_modified;
    private String _lcCfmReimbCntryCode;
    private boolean __lcCfmReimbCntryCode_is_modified;
    private boolean _isNew = true;

    public int getLcBrnCode() { return _lcBrnCode; }
    public void setLcBrnCode(int newVal) { this._lcBrnCode = newVal; __lcBrnCode_is_modified = true; }
    public boolean lcBrnCodeIsModifiedS2j() { return __lcBrnCode_is_modified; }
    public String getLcLcType() { return _lcLcType; }
    public void setLcLcType(String newVal) { this._lcLcType = newVal; __lcLcType_is_modified = true; }
    public boolean lcLcTypeIsModifiedS2j() { return __lcLcType_is_modified; }
    public int getLcLcYear() { return _lcLcYear; }
    public void setLcLcYear(int newVal) { this._lcLcYear = newVal; __lcLcYear_is_modified = true; }
    public boolean lcLcYearIsModifiedS2j() { return __lcLcYear_is_modified; }
    public int getLcLcSl() { return _lcLcSl; }
    public void setLcLcSl(int newVal) { this._lcLcSl = newVal; __lcLcSl_is_modified = true; }
    public boolean lcLcSlIsModifiedS2j() { return __lcLcSl_is_modified; }
    public int getLcFormOfDocCredit() { return _lcFormOfDocCredit; }
    public void setLcFormOfDocCredit(int newVal) { this._lcFormOfDocCredit = newVal; __lcFormOfDocCredit_is_modified = true; }
    public boolean lcFormOfDocCreditIsModifiedS2j() { return __lcFormOfDocCredit_is_modified; }
    public String getLcReferenceToPreadvice() { return _lcReferenceToPreadvice == null ? "" : _lcReferenceToPreadvice.trim(); }
    public void setLcReferenceToPreadvice(String newVal) { this._lcReferenceToPreadvice = newVal; __lcReferenceToPreadvice_is_modified = true; }
    public boolean lcReferenceToPreadviceIsModifiedS2j() { return __lcReferenceToPreadvice_is_modified; }
    public int getLcApplicableRules() { return _lcApplicableRules; }
    public void setLcApplicableRules(int newVal) { this._lcApplicableRules = newVal; __lcApplicableRules_is_modified = true; }
    public boolean lcApplicableRulesIsModifiedS2j() { return __lcApplicableRules_is_modified; }
    public char getLcApplicantReq() { return _lcApplicantReq; }
    public void setLcApplicantReq(char newVal) { this._lcApplicantReq = newVal; __lcApplicantReq_is_modified = true; }
    public boolean lcApplicantReqIsModifiedS2j() { return __lcApplicantReq_is_modified; }
    public char getLcApplicantType() { return _lcApplicantType; }
    public void setLcApplicantType(char newVal) { this._lcApplicantType = newVal; __lcApplicantType_is_modified = true; }
    public boolean lcApplicantTypeIsModifiedS2j() { return __lcApplicantType_is_modified; }
    public String getLcApplicantBrnCode() { return _lcApplicantBrnCode == null ? "" : _lcApplicantBrnCode.trim(); }
    public void setLcApplicantBrnCode(String newVal) { this._lcApplicantBrnCode = newVal; __lcApplicantBrnCode_is_modified = true; }
    public boolean lcApplicantBrnCodeIsModifiedS2j() { return __lcApplicantBrnCode_is_modified; }
    public String getLcApplicantBicCode() { return _lcApplicantBicCode == null ? "" : _lcApplicantBicCode.trim(); }
    public void setLcApplicantBicCode(String newVal) { this._lcApplicantBicCode = newVal; __lcApplicantBicCode_is_modified = true; }
    public boolean lcApplicantBicCodeIsModifiedS2j() { return __lcApplicantBicCode_is_modified; }
    public String getLcApplicantRoutid() { return _lcApplicantRoutid == null ? "" : _lcApplicantRoutid.trim(); }
    public void setLcApplicantRoutid(String newVal) { this._lcApplicantRoutid = newVal; __lcApplicantRoutid_is_modified = true; }
    public boolean lcApplicantRoutidIsModifiedS2j() { return __lcApplicantRoutid_is_modified; }
    public String getLcApplicantBnkCode() { return _lcApplicantBnkCode == null ? "" : _lcApplicantBnkCode.trim(); }
    public void setLcApplicantBnkCode(String newVal) { this._lcApplicantBnkCode = newVal; __lcApplicantBnkCode_is_modified = true; }
    public boolean lcApplicantBnkCodeIsModifiedS2j() { return __lcApplicantBnkCode_is_modified; }
    public String getLcApplicantAddr1() { return _lcApplicantAddr1 == null ? "" : _lcApplicantAddr1.trim(); }
    public void setLcApplicantAddr1(String newVal) { this._lcApplicantAddr1 = newVal; __lcApplicantAddr1_is_modified = true; }
    public boolean lcApplicantAddr1IsModifiedS2j() { return __lcApplicantAddr1_is_modified; }
    public String getLcApplicantAddr2() { return _lcApplicantAddr2 == null ? "" : _lcApplicantAddr2.trim(); }
    public void setLcApplicantAddr2(String newVal) { this._lcApplicantAddr2 = newVal; __lcApplicantAddr2_is_modified = true; }
    public boolean lcApplicantAddr2IsModifiedS2j() { return __lcApplicantAddr2_is_modified; }
    public String getLcApplicantAddr3() { return _lcApplicantAddr3 == null ? "" : _lcApplicantAddr3.trim(); }
    public void setLcApplicantAddr3(String newVal) { this._lcApplicantAddr3 = newVal; __lcApplicantAddr3_is_modified = true; }
    public boolean lcApplicantAddr3IsModifiedS2j() { return __lcApplicantAddr3_is_modified; }
    public String getLcApplicantAddr4() { return _lcApplicantAddr4 == null ? "" : _lcApplicantAddr4.trim(); }
    public void setLcApplicantAddr4(String newVal) { this._lcApplicantAddr4 = newVal; __lcApplicantAddr4_is_modified = true; }
    public boolean lcApplicantAddr4IsModifiedS2j() { return __lcApplicantAddr4_is_modified; }
    public String getLcApplicantAddr5() { return _lcApplicantAddr5 == null ? "" : _lcApplicantAddr5.trim(); }
    public void setLcApplicantAddr5(String newVal) { this._lcApplicantAddr5 = newVal; __lcApplicantAddr5_is_modified = true; }
    public boolean lcApplicantAddr5IsModifiedS2j() { return __lcApplicantAddr5_is_modified; }
    public char getLcAvailableWithType() { return _lcAvailableWithType; }
    public void setLcAvailableWithType(char newVal) { this._lcAvailableWithType = newVal; __lcAvailableWithType_is_modified = true; }
    public boolean lcAvailableWithTypeIsModifiedS2j() { return __lcAvailableWithType_is_modified; }
    public String getLcAvailableWithBrnCode() { return _lcAvailableWithBrnCode == null ? "" : _lcAvailableWithBrnCode.trim(); }
    public void setLcAvailableWithBrnCode(String newVal) { this._lcAvailableWithBrnCode = newVal; __lcAvailableWithBrnCode_is_modified = true; }
    public boolean lcAvailableWithBrnCodeIsModifiedS2j() { return __lcAvailableWithBrnCode_is_modified; }
    public String getLcAvailableWithCode() { return _lcAvailableWithCode == null ? "" : _lcAvailableWithCode.trim(); }
    public void setLcAvailableWithCode(String newVal) { this._lcAvailableWithCode = newVal; __lcAvailableWithCode_is_modified = true; }
    public boolean lcAvailableWithCodeIsModifiedS2j() { return __lcAvailableWithCode_is_modified; }
    public String getLcAvailableWithRoutid() { return _lcAvailableWithRoutid == null ? "" : _lcAvailableWithRoutid.trim(); }
    public void setLcAvailableWithRoutid(String newVal) { this._lcAvailableWithRoutid = newVal; __lcAvailableWithRoutid_is_modified = true; }
    public boolean lcAvailableWithRoutidIsModifiedS2j() { return __lcAvailableWithRoutid_is_modified; }
    public String getLcAvailableWithBnkCode() { return _lcAvailableWithBnkCode == null ? "" : _lcAvailableWithBnkCode.trim(); }
    public void setLcAvailableWithBnkCode(String newVal) { this._lcAvailableWithBnkCode = newVal; __lcAvailableWithBnkCode_is_modified = true; }
    public boolean lcAvailableWithBnkCodeIsModifiedS2j() { return __lcAvailableWithBnkCode_is_modified; }
    public String getLcAvailableWithAddr1() { return _lcAvailableWithAddr1 == null ? "" : _lcAvailableWithAddr1.trim(); }
    public void setLcAvailableWithAddr1(String newVal) { this._lcAvailableWithAddr1 = newVal; __lcAvailableWithAddr1_is_modified = true; }
    public boolean lcAvailableWithAddr1IsModifiedS2j() { return __lcAvailableWithAddr1_is_modified; }
    public String getLcAvailableWithAddr2() { return _lcAvailableWithAddr2 == null ? "" : _lcAvailableWithAddr2.trim(); }
    public void setLcAvailableWithAddr2(String newVal) { this._lcAvailableWithAddr2 = newVal; __lcAvailableWithAddr2_is_modified = true; }
    public boolean lcAvailableWithAddr2IsModifiedS2j() { return __lcAvailableWithAddr2_is_modified; }
    public String getLcAvailableWithAddr3() { return _lcAvailableWithAddr3 == null ? "" : _lcAvailableWithAddr3.trim(); }
    public void setLcAvailableWithAddr3(String newVal) { this._lcAvailableWithAddr3 = newVal; __lcAvailableWithAddr3_is_modified = true; }
    public boolean lcAvailableWithAddr3IsModifiedS2j() { return __lcAvailableWithAddr3_is_modified; }
    public String getLcAvailableWithAddr4() { return _lcAvailableWithAddr4 == null ? "" : _lcAvailableWithAddr4.trim(); }
    public void setLcAvailableWithAddr4(String newVal) { this._lcAvailableWithAddr4 = newVal; __lcAvailableWithAddr4_is_modified = true; }
    public boolean lcAvailableWithAddr4IsModifiedS2j() { return __lcAvailableWithAddr4_is_modified; }
    public String getLcAvailableWithAddr5() { return _lcAvailableWithAddr5 == null ? "" : _lcAvailableWithAddr5.trim(); }
    public void setLcAvailableWithAddr5(String newVal) { this._lcAvailableWithAddr5 = newVal; __lcAvailableWithAddr5_is_modified = true; }
    public boolean lcAvailableWithAddr5IsModifiedS2j() { return __lcAvailableWithAddr5_is_modified; }
    public String getLcDraftsAt1() { return _lcDraftsAt1 == null ? "" : _lcDraftsAt1.trim(); }
    public void setLcDraftsAt1(String newVal) { this._lcDraftsAt1 = newVal; __lcDraftsAt1_is_modified = true; }
    public boolean lcDraftsAt1IsModifiedS2j() { return __lcDraftsAt1_is_modified; }
    public String getLcDraftsAt2() { return _lcDraftsAt2 == null ? "" : _lcDraftsAt2.trim(); }
    public void setLcDraftsAt2(String newVal) { this._lcDraftsAt2 = newVal; __lcDraftsAt2_is_modified = true; }
    public boolean lcDraftsAt2IsModifiedS2j() { return __lcDraftsAt2_is_modified; }
    public String getLcDraftsAt3() { return _lcDraftsAt3 == null ? "" : _lcDraftsAt3.trim(); }
    public void setLcDraftsAt3(String newVal) { this._lcDraftsAt3 = newVal; __lcDraftsAt3_is_modified = true; }
    public boolean lcDraftsAt3IsModifiedS2j() { return __lcDraftsAt3_is_modified; }
    public char getLcDraweeReq() { return _lcDraweeReq; }
    public void setLcDraweeReq(char newVal) { this._lcDraweeReq = newVal; __lcDraweeReq_is_modified = true; }
    public boolean lcDraweeReqIsModifiedS2j() { return __lcDraweeReq_is_modified; }
    public char getLcDraweeType() { return _lcDraweeType; }
    public void setLcDraweeType(char newVal) { this._lcDraweeType = newVal; __lcDraweeType_is_modified = true; }
    public boolean lcDraweeTypeIsModifiedS2j() { return __lcDraweeType_is_modified; }
    public String getLcDraweeBrnCode() { return _lcDraweeBrnCode == null ? "" : _lcDraweeBrnCode.trim(); }
    public void setLcDraweeBrnCode(String newVal) { this._lcDraweeBrnCode = newVal; __lcDraweeBrnCode_is_modified = true; }
    public boolean lcDraweeBrnCodeIsModifiedS2j() { return __lcDraweeBrnCode_is_modified; }
    public String getLcDraweeBicCode() { return _lcDraweeBicCode == null ? "" : _lcDraweeBicCode.trim(); }
    public void setLcDraweeBicCode(String newVal) { this._lcDraweeBicCode = newVal; __lcDraweeBicCode_is_modified = true; }
    public boolean lcDraweeBicCodeIsModifiedS2j() { return __lcDraweeBicCode_is_modified; }
    public String getLcDraweeRoutid() { return _lcDraweeRoutid == null ? "" : _lcDraweeRoutid.trim(); }
    public void setLcDraweeRoutid(String newVal) { this._lcDraweeRoutid = newVal; __lcDraweeRoutid_is_modified = true; }
    public boolean lcDraweeRoutidIsModifiedS2j() { return __lcDraweeRoutid_is_modified; }
    public String getLcDraweeBnkCode() { return _lcDraweeBnkCode == null ? "" : _lcDraweeBnkCode.trim(); }
    public void setLcDraweeBnkCode(String newVal) { this._lcDraweeBnkCode = newVal; __lcDraweeBnkCode_is_modified = true; }
    public boolean lcDraweeBnkCodeIsModifiedS2j() { return __lcDraweeBnkCode_is_modified; }
    public String getLcDraweeAddr1() { return _lcDraweeAddr1 == null ? "" : _lcDraweeAddr1.trim(); }
    public void setLcDraweeAddr1(String newVal) { this._lcDraweeAddr1 = newVal; __lcDraweeAddr1_is_modified = true; }
    public boolean lcDraweeAddr1IsModifiedS2j() { return __lcDraweeAddr1_is_modified; }
    public String getLcDraweeAddr2() { return _lcDraweeAddr2 == null ? "" : _lcDraweeAddr2.trim(); }
    public void setLcDraweeAddr2(String newVal) { this._lcDraweeAddr2 = newVal; __lcDraweeAddr2_is_modified = true; }
    public boolean lcDraweeAddr2IsModifiedS2j() { return __lcDraweeAddr2_is_modified; }
    public String getLcDraweeAddr3() { return _lcDraweeAddr3 == null ? "" : _lcDraweeAddr3.trim(); }
    public void setLcDraweeAddr3(String newVal) { this._lcDraweeAddr3 = newVal; __lcDraweeAddr3_is_modified = true; }
    public boolean lcDraweeAddr3IsModifiedS2j() { return __lcDraweeAddr3_is_modified; }
    public String getLcDraweeAddr4() { return _lcDraweeAddr4 == null ? "" : _lcDraweeAddr4.trim(); }
    public void setLcDraweeAddr4(String newVal) { this._lcDraweeAddr4 = newVal; __lcDraweeAddr4_is_modified = true; }
    public boolean lcDraweeAddr4IsModifiedS2j() { return __lcDraweeAddr4_is_modified; }
    public String getLcDraweeAddr5() { return _lcDraweeAddr5 == null ? "" : _lcDraweeAddr5.trim(); }
    public void setLcDraweeAddr5(String newVal) { this._lcDraweeAddr5 = newVal; __lcDraweeAddr5_is_modified = true; }
    public boolean lcDraweeAddr5IsModifiedS2j() { return __lcDraweeAddr5_is_modified; }
    public String getLcMixedPayDetails1() { return _lcMixedPayDetails1 == null ? "" : _lcMixedPayDetails1.trim(); }
    public void setLcMixedPayDetails1(String newVal) { this._lcMixedPayDetails1 = newVal; __lcMixedPayDetails1_is_modified = true; }
    public boolean lcMixedPayDetails1IsModifiedS2j() { return __lcMixedPayDetails1_is_modified; }
    public String getLcMixedPayDetails2() { return _lcMixedPayDetails2 == null ? "" : _lcMixedPayDetails2.trim(); }
    public void setLcMixedPayDetails2(String newVal) { this._lcMixedPayDetails2 = newVal; __lcMixedPayDetails2_is_modified = true; }
    public boolean lcMixedPayDetails2IsModifiedS2j() { return __lcMixedPayDetails2_is_modified; }
    public String getLcMixedPayDetails3() { return _lcMixedPayDetails3 == null ? "" : _lcMixedPayDetails3.trim(); }
    public void setLcMixedPayDetails3(String newVal) { this._lcMixedPayDetails3 = newVal; __lcMixedPayDetails3_is_modified = true; }
    public boolean lcMixedPayDetails3IsModifiedS2j() { return __lcMixedPayDetails3_is_modified; }
    public String getLcMixedPayDetails4() { return _lcMixedPayDetails4 == null ? "" : _lcMixedPayDetails4.trim(); }
    public void setLcMixedPayDetails4(String newVal) { this._lcMixedPayDetails4 = newVal; __lcMixedPayDetails4_is_modified = true; }
    public boolean lcMixedPayDetails4IsModifiedS2j() { return __lcMixedPayDetails4_is_modified; }
    public String getLcDeferredPayDetails1() { return _lcDeferredPayDetails1 == null ? "" : _lcDeferredPayDetails1.trim(); }
    public void setLcDeferredPayDetails1(String newVal) { this._lcDeferredPayDetails1 = newVal; __lcDeferredPayDetails1_is_modified = true; }
    public boolean lcDeferredPayDetails1IsModifiedS2j() { return __lcDeferredPayDetails1_is_modified; }
    public String getLcDeferredPayDetails2() { return _lcDeferredPayDetails2 == null ? "" : _lcDeferredPayDetails2.trim(); }
    public void setLcDeferredPayDetails2(String newVal) { this._lcDeferredPayDetails2 = newVal; __lcDeferredPayDetails2_is_modified = true; }
    public boolean lcDeferredPayDetails2IsModifiedS2j() { return __lcDeferredPayDetails2_is_modified; }
    public String getLcDeferredPayDetails3() { return _lcDeferredPayDetails3 == null ? "" : _lcDeferredPayDetails3.trim(); }
    public void setLcDeferredPayDetails3(String newVal) { this._lcDeferredPayDetails3 = newVal; __lcDeferredPayDetails3_is_modified = true; }
    public boolean lcDeferredPayDetails3IsModifiedS2j() { return __lcDeferredPayDetails3_is_modified; }
    public String getLcDeferredPayDetails4() { return _lcDeferredPayDetails4 == null ? "" : _lcDeferredPayDetails4.trim(); }
    public void setLcDeferredPayDetails4(String newVal) { this._lcDeferredPayDetails4 = newVal; __lcDeferredPayDetails4_is_modified = true; }
    public boolean lcDeferredPayDetails4IsModifiedS2j() { return __lcDeferredPayDetails4_is_modified; }
    public int getLcPartialShipments() { return _lcPartialShipments; }
    public void setLcPartialShipments(int newVal) { this._lcPartialShipments = newVal; __lcPartialShipments_is_modified = true; }
    public boolean lcPartialShipmentsIsModifiedS2j() { return __lcPartialShipments_is_modified; }
    public int getLcTranshipment() { return _lcTranshipment; }
    public void setLcTranshipment(int newVal) { this._lcTranshipment = newVal; __lcTranshipment_is_modified = true; }
    public boolean lcTranshipmentIsModifiedS2j() { return __lcTranshipment_is_modified; }
    public String getLcPlaceOfTakingInCharge() { return _lcPlaceOfTakingInCharge == null ? "" : _lcPlaceOfTakingInCharge.trim(); }
    public void setLcPlaceOfTakingInCharge(String newVal) { this._lcPlaceOfTakingInCharge = newVal; __lcPlaceOfTakingInCharge_is_modified = true; }
    public boolean lcPlaceOfTakingInChargeIsModifiedS2j() { return __lcPlaceOfTakingInCharge_is_modified; }
    public String getLcPortOfLoading() { return _lcPortOfLoading == null ? "" : _lcPortOfLoading.trim(); }
    public void setLcPortOfLoading(String newVal) { this._lcPortOfLoading = newVal; __lcPortOfLoading_is_modified = true; }
    public boolean lcPortOfLoadingIsModifiedS2j() { return __lcPortOfLoading_is_modified; }
    public String getLcPortOfDischarge() { return _lcPortOfDischarge == null ? "" : _lcPortOfDischarge.trim(); }
    public void setLcPortOfDischarge(String newVal) { this._lcPortOfDischarge = newVal; __lcPortOfDischarge_is_modified = true; }
    public boolean lcPortOfDischargeIsModifiedS2j() { return __lcPortOfDischarge_is_modified; }
    public String getLcPlaceOfFinalDest() { return _lcPlaceOfFinalDest == null ? "" : _lcPlaceOfFinalDest.trim(); }
    public void setLcPlaceOfFinalDest(String newVal) { this._lcPlaceOfFinalDest = newVal; __lcPlaceOfFinalDest_is_modified = true; }
    public boolean lcPlaceOfFinalDestIsModifiedS2j() { return __lcPlaceOfFinalDest_is_modified; }
    public Object getLcDescGoodsSer1() { return _lcDescGoodsSer1; }
    public void setLcDescGoodsSer1(Object newVal) { this._lcDescGoodsSer1 = newVal; __lcDescGoodsSer1_is_modified = true; }
    public boolean lcDescGoodsSer1IsModifiedS2j() { return __lcDescGoodsSer1_is_modified; }
    public Object getLcDescGoodsSer2() { return _lcDescGoodsSer2; }
    public void setLcDescGoodsSer2(Object newVal) { this._lcDescGoodsSer2 = newVal; __lcDescGoodsSer2_is_modified = true; }
    public boolean lcDescGoodsSer2IsModifiedS2j() { return __lcDescGoodsSer2_is_modified; }
    public Object getLcDescGoodsSer3() { return _lcDescGoodsSer3; }
    public void setLcDescGoodsSer3(Object newVal) { this._lcDescGoodsSer3 = newVal; __lcDescGoodsSer3_is_modified = true; }
    public boolean lcDescGoodsSer3IsModifiedS2j() { return __lcDescGoodsSer3_is_modified; }
    public Object getLcDocReq1() { return _lcDocReq1; }
    public void setLcDocReq1(Object newVal) { this._lcDocReq1 = newVal; __lcDocReq1_is_modified = true; }
    public boolean lcDocReq1IsModifiedS2j() { return __lcDocReq1_is_modified; }
    public Object getLcDocReq2() { return _lcDocReq2; }
    public void setLcDocReq2(Object newVal) { this._lcDocReq2 = newVal; __lcDocReq2_is_modified = true; }
    public boolean lcDocReq2IsModifiedS2j() { return __lcDocReq2_is_modified; }
    public Object getLcDocReq3() { return _lcDocReq3; }
    public void setLcDocReq3(Object newVal) { this._lcDocReq3 = newVal; __lcDocReq3_is_modified = true; }
    public boolean lcDocReq3IsModifiedS2j() { return __lcDocReq3_is_modified; }
    public Object getLcAddCondition1() { return _lcAddCondition1; }
    public void setLcAddCondition1(Object newVal) { this._lcAddCondition1 = newVal; __lcAddCondition1_is_modified = true; }
    public boolean lcAddCondition1IsModifiedS2j() { return __lcAddCondition1_is_modified; }
    public Object getLcAddCondition2() { return _lcAddCondition2; }
    public void setLcAddCondition2(Object newVal) { this._lcAddCondition2 = newVal; __lcAddCondition2_is_modified = true; }
    public boolean lcAddCondition2IsModifiedS2j() { return __lcAddCondition2_is_modified; }
    public Object getLcAddCondition3() { return _lcAddCondition3; }
    public void setLcAddCondition3(Object newVal) { this._lcAddCondition3 = newVal; __lcAddCondition3_is_modified = true; }
    public boolean lcAddCondition3IsModifiedS2j() { return __lcAddCondition3_is_modified; }
    public String getLcCharges1() { return _lcCharges1 == null ? "" : _lcCharges1.trim(); }
    public void setLcCharges1(String newVal) { this._lcCharges1 = newVal; __lcCharges1_is_modified = true; }
    public boolean lcCharges1IsModifiedS2j() { return __lcCharges1_is_modified; }
    public String getLcCharges2() { return _lcCharges2 == null ? "" : _lcCharges2.trim(); }
    public void setLcCharges2(String newVal) { this._lcCharges2 = newVal; __lcCharges2_is_modified = true; }
    public boolean lcCharges2IsModifiedS2j() { return __lcCharges2_is_modified; }
    public String getLcCharges3() { return _lcCharges3 == null ? "" : _lcCharges3.trim(); }
    public void setLcCharges3(String newVal) { this._lcCharges3 = newVal; __lcCharges3_is_modified = true; }
    public boolean lcCharges3IsModifiedS2j() { return __lcCharges3_is_modified; }
    public String getLcCharges4() { return _lcCharges4 == null ? "" : _lcCharges4.trim(); }
    public void setLcCharges4(String newVal) { this._lcCharges4 = newVal; __lcCharges4_is_modified = true; }
    public boolean lcCharges4IsModifiedS2j() { return __lcCharges4_is_modified; }
    public String getLcCharges5() { return _lcCharges5 == null ? "" : _lcCharges5.trim(); }
    public void setLcCharges5(String newVal) { this._lcCharges5 = newVal; __lcCharges5_is_modified = true; }
    public boolean lcCharges5IsModifiedS2j() { return __lcCharges5_is_modified; }
    public String getLcCharges6() { return _lcCharges6 == null ? "" : _lcCharges6.trim(); }
    public void setLcCharges6(String newVal) { this._lcCharges6 = newVal; __lcCharges6_is_modified = true; }
    public boolean lcCharges6IsModifiedS2j() { return __lcCharges6_is_modified; }
    public int getLcPerPresentationDay() { return _lcPerPresentationDay; }
    public void setLcPerPresentationDay(int newVal) { this._lcPerPresentationDay = newVal; __lcPerPresentationDay_is_modified = true; }
    public boolean lcPerPresentationDayIsModifiedS2j() { return __lcPerPresentationDay_is_modified; }
    public int getLcConfirmationInst() { return _lcConfirmationInst; }
    public void setLcConfirmationInst(int newVal) { this._lcConfirmationInst = newVal; __lcConfirmationInst_is_modified = true; }
    public boolean lcConfirmationInstIsModifiedS2j() { return __lcConfirmationInst_is_modified; }
    public char getLcReimbReq() { return _lcReimbReq; }
    public void setLcReimbReq(char newVal) { this._lcReimbReq = newVal; __lcReimbReq_is_modified = true; }
    public boolean lcReimbReqIsModifiedS2j() { return __lcReimbReq_is_modified; }
    public char getLcReimbType() { return _lcReimbType; }
    public void setLcReimbType(char newVal) { this._lcReimbType = newVal; __lcReimbType_is_modified = true; }
    public boolean lcReimbTypeIsModifiedS2j() { return __lcReimbType_is_modified; }
    public String getLcReimbBrnCode() { return _lcReimbBrnCode == null ? "" : _lcReimbBrnCode.trim(); }
    public void setLcReimbBrnCode(String newVal) { this._lcReimbBrnCode = newVal; __lcReimbBrnCode_is_modified = true; }
    public boolean lcReimbBrnCodeIsModifiedS2j() { return __lcReimbBrnCode_is_modified; }
    public String getLcReimbBicCode() { return _lcReimbBicCode == null ? "" : _lcReimbBicCode.trim(); }
    public void setLcReimbBicCode(String newVal) { this._lcReimbBicCode = newVal; __lcReimbBicCode_is_modified = true; }
    public boolean lcReimbBicCodeIsModifiedS2j() { return __lcReimbBicCode_is_modified; }
    public String getLcReimbRoutid() { return _lcReimbRoutid == null ? "" : _lcReimbRoutid.trim(); }
    public void setLcReimbRoutid(String newVal) { this._lcReimbRoutid = newVal; __lcReimbRoutid_is_modified = true; }
    public boolean lcReimbRoutidIsModifiedS2j() { return __lcReimbRoutid_is_modified; }
    public String getLcReimbBnkCode() { return _lcReimbBnkCode == null ? "" : _lcReimbBnkCode.trim(); }
    public void setLcReimbBnkCode(String newVal) { this._lcReimbBnkCode = newVal; __lcReimbBnkCode_is_modified = true; }
    public boolean lcReimbBnkCodeIsModifiedS2j() { return __lcReimbBnkCode_is_modified; }
    public String getLcReimbAddr1() { return _lcReimbAddr1 == null ? "" : _lcReimbAddr1.trim(); }
    public void setLcReimbAddr1(String newVal) { this._lcReimbAddr1 = newVal; __lcReimbAddr1_is_modified = true; }
    public boolean lcReimbAddr1IsModifiedS2j() { return __lcReimbAddr1_is_modified; }
    public String getLcReimbAddr2() { return _lcReimbAddr2 == null ? "" : _lcReimbAddr2.trim(); }
    public void setLcReimbAddr2(String newVal) { this._lcReimbAddr2 = newVal; __lcReimbAddr2_is_modified = true; }
    public boolean lcReimbAddr2IsModifiedS2j() { return __lcReimbAddr2_is_modified; }
    public String getLcReimbAddr3() { return _lcReimbAddr3 == null ? "" : _lcReimbAddr3.trim(); }
    public void setLcReimbAddr3(String newVal) { this._lcReimbAddr3 = newVal; __lcReimbAddr3_is_modified = true; }
    public boolean lcReimbAddr3IsModifiedS2j() { return __lcReimbAddr3_is_modified; }
    public String getLcReimbAddr4() { return _lcReimbAddr4 == null ? "" : _lcReimbAddr4.trim(); }
    public void setLcReimbAddr4(String newVal) { this._lcReimbAddr4 = newVal; __lcReimbAddr4_is_modified = true; }
    public boolean lcReimbAddr4IsModifiedS2j() { return __lcReimbAddr4_is_modified; }
    public String getLcReimbAddr5() { return _lcReimbAddr5 == null ? "" : _lcReimbAddr5.trim(); }
    public void setLcReimbAddr5(String newVal) { this._lcReimbAddr5 = newVal; __lcReimbAddr5_is_modified = true; }
    public boolean lcReimbAddr5IsModifiedS2j() { return __lcReimbAddr5_is_modified; }
    public String getLcInstPaying1() { return _lcInstPaying1 == null ? "" : _lcInstPaying1.trim(); }
    public void setLcInstPaying1(String newVal) { this._lcInstPaying1 = newVal; __lcInstPaying1_is_modified = true; }
    public boolean lcInstPaying1IsModifiedS2j() { return __lcInstPaying1_is_modified; }
    public String getLcInstPaying2() { return _lcInstPaying2 == null ? "" : _lcInstPaying2.trim(); }
    public void setLcInstPaying2(String newVal) { this._lcInstPaying2 = newVal; __lcInstPaying2_is_modified = true; }
    public boolean lcInstPaying2IsModifiedS2j() { return __lcInstPaying2_is_modified; }
    public String getLcInstPaying3() { return _lcInstPaying3 == null ? "" : _lcInstPaying3.trim(); }
    public void setLcInstPaying3(String newVal) { this._lcInstPaying3 = newVal; __lcInstPaying3_is_modified = true; }
    public boolean lcInstPaying3IsModifiedS2j() { return __lcInstPaying3_is_modified; }
    public String getLcInstPaying4() { return _lcInstPaying4 == null ? "" : _lcInstPaying4.trim(); }
    public void setLcInstPaying4(String newVal) { this._lcInstPaying4 = newVal; __lcInstPaying4_is_modified = true; }
    public boolean lcInstPaying4IsModifiedS2j() { return __lcInstPaying4_is_modified; }
    public String getLcInstPaying5() { return _lcInstPaying5 == null ? "" : _lcInstPaying5.trim(); }
    public void setLcInstPaying5(String newVal) { this._lcInstPaying5 = newVal; __lcInstPaying5_is_modified = true; }
    public boolean lcInstPaying5IsModifiedS2j() { return __lcInstPaying5_is_modified; }
    public String getLcInstPaying6() { return _lcInstPaying6 == null ? "" : _lcInstPaying6.trim(); }
    public void setLcInstPaying6(String newVal) { this._lcInstPaying6 = newVal; __lcInstPaying6_is_modified = true; }
    public boolean lcInstPaying6IsModifiedS2j() { return __lcInstPaying6_is_modified; }
    public String getLcInstPaying7() { return _lcInstPaying7 == null ? "" : _lcInstPaying7.trim(); }
    public void setLcInstPaying7(String newVal) { this._lcInstPaying7 = newVal; __lcInstPaying7_is_modified = true; }
    public boolean lcInstPaying7IsModifiedS2j() { return __lcInstPaying7_is_modified; }
    public String getLcInstPaying8() { return _lcInstPaying8 == null ? "" : _lcInstPaying8.trim(); }
    public void setLcInstPaying8(String newVal) { this._lcInstPaying8 = newVal; __lcInstPaying8_is_modified = true; }
    public boolean lcInstPaying8IsModifiedS2j() { return __lcInstPaying8_is_modified; }
    public String getLcInstPaying9() { return _lcInstPaying9 == null ? "" : _lcInstPaying9.trim(); }
    public void setLcInstPaying9(String newVal) { this._lcInstPaying9 = newVal; __lcInstPaying9_is_modified = true; }
    public boolean lcInstPaying9IsModifiedS2j() { return __lcInstPaying9_is_modified; }
    public String getLcInstPaying10() { return _lcInstPaying10 == null ? "" : _lcInstPaying10.trim(); }
    public void setLcInstPaying10(String newVal) { this._lcInstPaying10 = newVal; __lcInstPaying10_is_modified = true; }
    public boolean lcInstPaying10IsModifiedS2j() { return __lcInstPaying10_is_modified; }
    public String getLcInstPaying11() { return _lcInstPaying11 == null ? "" : _lcInstPaying11.trim(); }
    public void setLcInstPaying11(String newVal) { this._lcInstPaying11 = newVal; __lcInstPaying11_is_modified = true; }
    public boolean lcInstPaying11IsModifiedS2j() { return __lcInstPaying11_is_modified; }
    public String getLcInstPaying12() { return _lcInstPaying12 == null ? "" : _lcInstPaying12.trim(); }
    public void setLcInstPaying12(String newVal) { this._lcInstPaying12 = newVal; __lcInstPaying12_is_modified = true; }
    public boolean lcInstPaying12IsModifiedS2j() { return __lcInstPaying12_is_modified; }
    public char getLcSecondAdvReq() { return _lcSecondAdvReq; }
    public void setLcSecondAdvReq(char newVal) { this._lcSecondAdvReq = newVal; __lcSecondAdvReq_is_modified = true; }
    public boolean lcSecondAdvReqIsModifiedS2j() { return __lcSecondAdvReq_is_modified; }
    public char getLcSecondAdvType() { return _lcSecondAdvType; }
    public void setLcSecondAdvType(char newVal) { this._lcSecondAdvType = newVal; __lcSecondAdvType_is_modified = true; }
    public boolean lcSecondAdvTypeIsModifiedS2j() { return __lcSecondAdvType_is_modified; }
    public String getLcSecondAdvBrnCode() { return _lcSecondAdvBrnCode == null ? "" : _lcSecondAdvBrnCode.trim(); }
    public void setLcSecondAdvBrnCode(String newVal) { this._lcSecondAdvBrnCode = newVal; __lcSecondAdvBrnCode_is_modified = true; }
    public boolean lcSecondAdvBrnCodeIsModifiedS2j() { return __lcSecondAdvBrnCode_is_modified; }
    public String getLcSecondAdvBicCode() { return _lcSecondAdvBicCode == null ? "" : _lcSecondAdvBicCode.trim(); }
    public void setLcSecondAdvBicCode(String newVal) { this._lcSecondAdvBicCode = newVal; __lcSecondAdvBicCode_is_modified = true; }
    public boolean lcSecondAdvBicCodeIsModifiedS2j() { return __lcSecondAdvBicCode_is_modified; }
    public String getLcSecondAdvRoutid() { return _lcSecondAdvRoutid == null ? "" : _lcSecondAdvRoutid.trim(); }
    public void setLcSecondAdvRoutid(String newVal) { this._lcSecondAdvRoutid = newVal; __lcSecondAdvRoutid_is_modified = true; }
    public boolean lcSecondAdvRoutidIsModifiedS2j() { return __lcSecondAdvRoutid_is_modified; }
    public String getLcSecondAdvBnkCode() { return _lcSecondAdvBnkCode == null ? "" : _lcSecondAdvBnkCode.trim(); }
    public void setLcSecondAdvBnkCode(String newVal) { this._lcSecondAdvBnkCode = newVal; __lcSecondAdvBnkCode_is_modified = true; }
    public boolean lcSecondAdvBnkCodeIsModifiedS2j() { return __lcSecondAdvBnkCode_is_modified; }
    public String getLcSecondAdvAddr1() { return _lcSecondAdvAddr1 == null ? "" : _lcSecondAdvAddr1.trim(); }
    public void setLcSecondAdvAddr1(String newVal) { this._lcSecondAdvAddr1 = newVal; __lcSecondAdvAddr1_is_modified = true; }
    public boolean lcSecondAdvAddr1IsModifiedS2j() { return __lcSecondAdvAddr1_is_modified; }
    public String getLcSecondAdvAddr2() { return _lcSecondAdvAddr2 == null ? "" : _lcSecondAdvAddr2.trim(); }
    public void setLcSecondAdvAddr2(String newVal) { this._lcSecondAdvAddr2 = newVal; __lcSecondAdvAddr2_is_modified = true; }
    public boolean lcSecondAdvAddr2IsModifiedS2j() { return __lcSecondAdvAddr2_is_modified; }
    public String getLcSecondAdvAddr3() { return _lcSecondAdvAddr3 == null ? "" : _lcSecondAdvAddr3.trim(); }
    public void setLcSecondAdvAddr3(String newVal) { this._lcSecondAdvAddr3 = newVal; __lcSecondAdvAddr3_is_modified = true; }
    public boolean lcSecondAdvAddr3IsModifiedS2j() { return __lcSecondAdvAddr3_is_modified; }
    public String getLcSecondAdvAddr4() { return _lcSecondAdvAddr4 == null ? "" : _lcSecondAdvAddr4.trim(); }
    public void setLcSecondAdvAddr4(String newVal) { this._lcSecondAdvAddr4 = newVal; __lcSecondAdvAddr4_is_modified = true; }
    public boolean lcSecondAdvAddr4IsModifiedS2j() { return __lcSecondAdvAddr4_is_modified; }
    public String getLcSecondAdvAddr5() { return _lcSecondAdvAddr5 == null ? "" : _lcSecondAdvAddr5.trim(); }
    public void setLcSecondAdvAddr5(String newVal) { this._lcSecondAdvAddr5 = newVal; __lcSecondAdvAddr5_is_modified = true; }
    public boolean lcSecondAdvAddr5IsModifiedS2j() { return __lcSecondAdvAddr5_is_modified; }
    public String getLcSndrRecInfo1() { return _lcSndrRecInfo1 == null ? "" : _lcSndrRecInfo1.trim(); }
    public void setLcSndrRecInfo1(String newVal) { this._lcSndrRecInfo1 = newVal; __lcSndrRecInfo1_is_modified = true; }
    public boolean lcSndrRecInfo1IsModifiedS2j() { return __lcSndrRecInfo1_is_modified; }
    public String getLcSndrRecInfo2() { return _lcSndrRecInfo2 == null ? "" : _lcSndrRecInfo2.trim(); }
    public void setLcSndrRecInfo2(String newVal) { this._lcSndrRecInfo2 = newVal; __lcSndrRecInfo2_is_modified = true; }
    public boolean lcSndrRecInfo2IsModifiedS2j() { return __lcSndrRecInfo2_is_modified; }
    public String getLcSndrRecInfo3() { return _lcSndrRecInfo3 == null ? "" : _lcSndrRecInfo3.trim(); }
    public void setLcSndrRecInfo3(String newVal) { this._lcSndrRecInfo3 = newVal; __lcSndrRecInfo3_is_modified = true; }
    public boolean lcSndrRecInfo3IsModifiedS2j() { return __lcSndrRecInfo3_is_modified; }
    public String getLcSndrRecInfo4() { return _lcSndrRecInfo4 == null ? "" : _lcSndrRecInfo4.trim(); }
    public void setLcSndrRecInfo4(String newVal) { this._lcSndrRecInfo4 = newVal; __lcSndrRecInfo4_is_modified = true; }
    public boolean lcSndrRecInfo4IsModifiedS2j() { return __lcSndrRecInfo4_is_modified; }
    public String getLcSndrRecInfo5() { return _lcSndrRecInfo5 == null ? "" : _lcSndrRecInfo5.trim(); }
    public void setLcSndrRecInfo5(String newVal) { this._lcSndrRecInfo5 = newVal; __lcSndrRecInfo5_is_modified = true; }
    public boolean lcSndrRecInfo5IsModifiedS2j() { return __lcSndrRecInfo5_is_modified; }
    public String getLcSndrRecInfo6() { return _lcSndrRecInfo6 == null ? "" : _lcSndrRecInfo6.trim(); }
    public void setLcSndrRecInfo6(String newVal) { this._lcSndrRecInfo6 = newVal; __lcSndrRecInfo6_is_modified = true; }
    public boolean lcSndrRecInfo6IsModifiedS2j() { return __lcSndrRecInfo6_is_modified; }
    public String getLcApplicantCntryCode() { return _lcApplicantCntryCode == null ? "" : _lcApplicantCntryCode.trim(); }
    public void setLcApplicantCntryCode(String newVal) { this._lcApplicantCntryCode = newVal; __lcApplicantCntryCode_is_modified = true; }
    public boolean lcApplicantCntryCodeIsModifiedS2j() { return __lcApplicantCntryCode_is_modified; }
    public String getLcAvailableWithCntry() { return _lcAvailableWithCntry == null ? "" : _lcAvailableWithCntry.trim(); }
    public void setLcAvailableWithCntry(String newVal) { this._lcAvailableWithCntry = newVal; __lcAvailableWithCntry_is_modified = true; }
    public boolean lcAvailableWithCntryIsModifiedS2j() { return __lcAvailableWithCntry_is_modified; }
    public int getLcAvailableWithCodetyp() { return _lcAvailableWithCodetyp; }
    public void setLcAvailableWithCodetyp(int newVal) { this._lcAvailableWithCodetyp = newVal; __lcAvailableWithCodetyp_is_modified = true; }
    public boolean lcAvailableWithCodetypIsModifiedS2j() { return __lcAvailableWithCodetyp_is_modified; }
    public String getLcDraweeCntryCode() { return _lcDraweeCntryCode == null ? "" : _lcDraweeCntryCode.trim(); }
    public void setLcDraweeCntryCode(String newVal) { this._lcDraweeCntryCode = newVal; __lcDraweeCntryCode_is_modified = true; }
    public boolean lcDraweeCntryCodeIsModifiedS2j() { return __lcDraweeCntryCode_is_modified; }
    public char getLcConfirmInstType() { return _lcConfirmInstType; }
    public void setLcConfirmInstType(char newVal) { this._lcConfirmInstType = newVal; __lcConfirmInstType_is_modified = true; }
    public boolean lcConfirmInstTypeIsModifiedS2j() { return __lcConfirmInstType_is_modified; }
    public String getLcReimbCntryCode() { return _lcReimbCntryCode == null ? "" : _lcReimbCntryCode.trim(); }
    public void setLcReimbCntryCode(String newVal) { this._lcReimbCntryCode = newVal; __lcReimbCntryCode_is_modified = true; }
    public boolean lcReimbCntryCodeIsModifiedS2j() { return __lcReimbCntryCode_is_modified; }
    public String getLcSecondAdvCntrycode() { return _lcSecondAdvCntrycode == null ? "" : _lcSecondAdvCntrycode.trim(); }
    public void setLcSecondAdvCntrycode(String newVal) { this._lcSecondAdvCntrycode = newVal; __lcSecondAdvCntrycode_is_modified = true; }
    public boolean lcSecondAdvCntrycodeIsModifiedS2j() { return __lcSecondAdvCntrycode_is_modified; }
    public String getLcShipmentPeriod1() { return _lcShipmentPeriod1 == null ? "" : _lcShipmentPeriod1.trim(); }
    public void setLcShipmentPeriod1(String newVal) { this._lcShipmentPeriod1 = newVal; __lcShipmentPeriod1_is_modified = true; }
    public boolean lcShipmentPeriod1IsModifiedS2j() { return __lcShipmentPeriod1_is_modified; }
    public String getLcShipmentPeriod2() { return _lcShipmentPeriod2 == null ? "" : _lcShipmentPeriod2.trim(); }
    public void setLcShipmentPeriod2(String newVal) { this._lcShipmentPeriod2 = newVal; __lcShipmentPeriod2_is_modified = true; }
    public boolean lcShipmentPeriod2IsModifiedS2j() { return __lcShipmentPeriod2_is_modified; }
    public String getLcShipmentPeriod3() { return _lcShipmentPeriod3 == null ? "" : _lcShipmentPeriod3.trim(); }
    public void setLcShipmentPeriod3(String newVal) { this._lcShipmentPeriod3 = newVal; __lcShipmentPeriod3_is_modified = true; }
    public boolean lcShipmentPeriod3IsModifiedS2j() { return __lcShipmentPeriod3_is_modified; }
    public String getLcShipmentPeriod4() { return _lcShipmentPeriod4 == null ? "" : _lcShipmentPeriod4.trim(); }
    public void setLcShipmentPeriod4(String newVal) { this._lcShipmentPeriod4 = newVal; __lcShipmentPeriod4_is_modified = true; }
    public boolean lcShipmentPeriod4IsModifiedS2j() { return __lcShipmentPeriod4_is_modified; }
    public String getLcShipmentPeriod5() { return _lcShipmentPeriod5 == null ? "" : _lcShipmentPeriod5.trim(); }
    public void setLcShipmentPeriod5(String newVal) { this._lcShipmentPeriod5 = newVal; __lcShipmentPeriod5_is_modified = true; }
    public boolean lcShipmentPeriod5IsModifiedS2j() { return __lcShipmentPeriod5_is_modified; }
    public String getLcShipmentPeriod6() { return _lcShipmentPeriod6 == null ? "" : _lcShipmentPeriod6.trim(); }
    public void setLcShipmentPeriod6(String newVal) { this._lcShipmentPeriod6 = newVal; __lcShipmentPeriod6_is_modified = true; }
    public boolean lcShipmentPeriod6IsModifiedS2j() { return __lcShipmentPeriod6_is_modified; }
    public String getLcPerPresentationRemarks() { return _lcPerPresentationRemarks == null ? "" : _lcPerPresentationRemarks.trim(); }
    public void setLcPerPresentationRemarks(String newVal) { this._lcPerPresentationRemarks = newVal; __lcPerPresentationRemarks_is_modified = true; }
    public boolean lcPerPresentationRemarksIsModifiedS2j() { return __lcPerPresentationRemarks_is_modified; }
    public String getLcRecBicCode() { return _lcRecBicCode == null ? "" : _lcRecBicCode.trim(); }
    public void setLcRecBicCode(String newVal) { this._lcRecBicCode = newVal; __lcRecBicCode_is_modified = true; }
    public boolean lcRecBicCodeIsModifiedS2j() { return __lcRecBicCode_is_modified; }
    public char getLcCfmReimbType() { return _lcCfmReimbType; }
    public void setLcCfmReimbType(char newVal) { this._lcCfmReimbType = newVal; __lcCfmReimbType_is_modified = true; }
    public boolean lcCfmReimbTypeIsModifiedS2j() { return __lcCfmReimbType_is_modified; }
    public String getLcCfmReimbBrnCode() { return _lcCfmReimbBrnCode == null ? "" : _lcCfmReimbBrnCode.trim(); }
    public void setLcCfmReimbBrnCode(String newVal) { this._lcCfmReimbBrnCode = newVal; __lcCfmReimbBrnCode_is_modified = true; }
    public boolean lcCfmReimbBrnCodeIsModifiedS2j() { return __lcCfmReimbBrnCode_is_modified; }
    public String getLcCfmReimbBicCode() { return _lcCfmReimbBicCode == null ? "" : _lcCfmReimbBicCode.trim(); }
    public void setLcCfmReimbBicCode(String newVal) { this._lcCfmReimbBicCode = newVal; __lcCfmReimbBicCode_is_modified = true; }
    public boolean lcCfmReimbBicCodeIsModifiedS2j() { return __lcCfmReimbBicCode_is_modified; }
    public String getLcCfmReimbRoutid() { return _lcCfmReimbRoutid == null ? "" : _lcCfmReimbRoutid.trim(); }
    public void setLcCfmReimbRoutid(String newVal) { this._lcCfmReimbRoutid = newVal; __lcCfmReimbRoutid_is_modified = true; }
    public boolean lcCfmReimbRoutidIsModifiedS2j() { return __lcCfmReimbRoutid_is_modified; }
    public String getLcCfmReimbBnkCode() { return _lcCfmReimbBnkCode == null ? "" : _lcCfmReimbBnkCode.trim(); }
    public void setLcCfmReimbBnkCode(String newVal) { this._lcCfmReimbBnkCode = newVal; __lcCfmReimbBnkCode_is_modified = true; }
    public boolean lcCfmReimbBnkCodeIsModifiedS2j() { return __lcCfmReimbBnkCode_is_modified; }
    public String getLcCfmReimbAddr1() { return _lcCfmReimbAddr1 == null ? "" : _lcCfmReimbAddr1.trim(); }
    public void setLcCfmReimbAddr1(String newVal) { this._lcCfmReimbAddr1 = newVal; __lcCfmReimbAddr1_is_modified = true; }
    public boolean lcCfmReimbAddr1IsModifiedS2j() { return __lcCfmReimbAddr1_is_modified; }
    public String getLcCfmReimbAddr2() { return _lcCfmReimbAddr2 == null ? "" : _lcCfmReimbAddr2.trim(); }
    public void setLcCfmReimbAddr2(String newVal) { this._lcCfmReimbAddr2 = newVal; __lcCfmReimbAddr2_is_modified = true; }
    public boolean lcCfmReimbAddr2IsModifiedS2j() { return __lcCfmReimbAddr2_is_modified; }
    public String getLcCfmReimbAddr3() { return _lcCfmReimbAddr3 == null ? "" : _lcCfmReimbAddr3.trim(); }
    public void setLcCfmReimbAddr3(String newVal) { this._lcCfmReimbAddr3 = newVal; __lcCfmReimbAddr3_is_modified = true; }
    public boolean lcCfmReimbAddr3IsModifiedS2j() { return __lcCfmReimbAddr3_is_modified; }
    public String getLcCfmReimbAddr4() { return _lcCfmReimbAddr4 == null ? "" : _lcCfmReimbAddr4.trim(); }
    public void setLcCfmReimbAddr4(String newVal) { this._lcCfmReimbAddr4 = newVal; __lcCfmReimbAddr4_is_modified = true; }
    public boolean lcCfmReimbAddr4IsModifiedS2j() { return __lcCfmReimbAddr4_is_modified; }
    public String getLcCfmReimbAddr5() { return _lcCfmReimbAddr5 == null ? "" : _lcCfmReimbAddr5.trim(); }
    public void setLcCfmReimbAddr5(String newVal) { this._lcCfmReimbAddr5 = newVal; __lcCfmReimbAddr5_is_modified = true; }
    public boolean lcCfmReimbAddr5IsModifiedS2j() { return __lcCfmReimbAddr5_is_modified; }
    public String getLcCfmReimbCntryCode() { return _lcCfmReimbCntryCode == null ? "" : _lcCfmReimbCntryCode.trim(); }
    public void setLcCfmReimbCntryCode(String newVal) { this._lcCfmReimbCntryCode = newVal; __lcCfmReimbCntryCode_is_modified = true; }
    public boolean lcCfmReimbCntryCodeIsModifiedS2j() { return __lcCfmReimbCntryCode_is_modified; }
    public boolean isNew() { return _isNew; }
    public void setIsNew(boolean isNew) { this._isNew = isNew; }

    public boolean isModifiedS2J() {
        return __lcBrnCode_is_modified || 
        __lcLcType_is_modified || 
        __lcLcYear_is_modified || 
        __lcLcSl_is_modified || 
        __lcFormOfDocCredit_is_modified || 
        __lcReferenceToPreadvice_is_modified || 
        __lcApplicableRules_is_modified || 
        __lcApplicantReq_is_modified || 
        __lcApplicantType_is_modified || 
        __lcApplicantBrnCode_is_modified || 
        __lcApplicantBicCode_is_modified || 
        __lcApplicantRoutid_is_modified || 
        __lcApplicantBnkCode_is_modified || 
        __lcApplicantAddr1_is_modified || 
        __lcApplicantAddr2_is_modified || 
        __lcApplicantAddr3_is_modified || 
        __lcApplicantAddr4_is_modified || 
        __lcApplicantAddr5_is_modified || 
        __lcAvailableWithType_is_modified || 
        __lcAvailableWithBrnCode_is_modified || 
        __lcAvailableWithCode_is_modified || 
        __lcAvailableWithRoutid_is_modified || 
        __lcAvailableWithBnkCode_is_modified || 
        __lcAvailableWithAddr1_is_modified || 
        __lcAvailableWithAddr2_is_modified || 
        __lcAvailableWithAddr3_is_modified || 
        __lcAvailableWithAddr4_is_modified || 
        __lcAvailableWithAddr5_is_modified || 
        __lcDraftsAt1_is_modified || 
        __lcDraftsAt2_is_modified || 
        __lcDraftsAt3_is_modified || 
        __lcDraweeReq_is_modified || 
        __lcDraweeType_is_modified || 
        __lcDraweeBrnCode_is_modified || 
        __lcDraweeBicCode_is_modified || 
        __lcDraweeRoutid_is_modified || 
        __lcDraweeBnkCode_is_modified || 
        __lcDraweeAddr1_is_modified || 
        __lcDraweeAddr2_is_modified || 
        __lcDraweeAddr3_is_modified || 
        __lcDraweeAddr4_is_modified || 
        __lcDraweeAddr5_is_modified || 
        __lcMixedPayDetails1_is_modified || 
        __lcMixedPayDetails2_is_modified || 
        __lcMixedPayDetails3_is_modified || 
        __lcMixedPayDetails4_is_modified || 
        __lcDeferredPayDetails1_is_modified || 
        __lcDeferredPayDetails2_is_modified || 
        __lcDeferredPayDetails3_is_modified || 
        __lcDeferredPayDetails4_is_modified || 
        __lcPartialShipments_is_modified || 
        __lcTranshipment_is_modified || 
        __lcPlaceOfTakingInCharge_is_modified || 
        __lcPortOfLoading_is_modified || 
        __lcPortOfDischarge_is_modified || 
        __lcPlaceOfFinalDest_is_modified || 
        __lcDescGoodsSer1_is_modified || 
        __lcDescGoodsSer2_is_modified || 
        __lcDescGoodsSer3_is_modified || 
        __lcDocReq1_is_modified || 
        __lcDocReq2_is_modified || 
        __lcDocReq3_is_modified || 
        __lcAddCondition1_is_modified || 
        __lcAddCondition2_is_modified || 
        __lcAddCondition3_is_modified || 
        __lcCharges1_is_modified || 
        __lcCharges2_is_modified || 
        __lcCharges3_is_modified || 
        __lcCharges4_is_modified || 
        __lcCharges5_is_modified || 
        __lcCharges6_is_modified || 
        __lcPerPresentationDay_is_modified || 
        __lcConfirmationInst_is_modified || 
        __lcReimbReq_is_modified || 
        __lcReimbType_is_modified || 
        __lcReimbBrnCode_is_modified || 
        __lcReimbBicCode_is_modified || 
        __lcReimbRoutid_is_modified || 
        __lcReimbBnkCode_is_modified || 
        __lcReimbAddr1_is_modified || 
        __lcReimbAddr2_is_modified || 
        __lcReimbAddr3_is_modified || 
        __lcReimbAddr4_is_modified || 
        __lcReimbAddr5_is_modified || 
        __lcInstPaying1_is_modified || 
        __lcInstPaying2_is_modified || 
        __lcInstPaying3_is_modified || 
        __lcInstPaying4_is_modified || 
        __lcInstPaying5_is_modified || 
        __lcInstPaying6_is_modified || 
        __lcInstPaying7_is_modified || 
        __lcInstPaying8_is_modified || 
        __lcInstPaying9_is_modified || 
        __lcInstPaying10_is_modified || 
        __lcInstPaying11_is_modified || 
        __lcInstPaying12_is_modified || 
        __lcSecondAdvReq_is_modified || 
        __lcSecondAdvType_is_modified || 
        __lcSecondAdvBrnCode_is_modified || 
        __lcSecondAdvBicCode_is_modified || 
        __lcSecondAdvRoutid_is_modified || 
        __lcSecondAdvBnkCode_is_modified || 
        __lcSecondAdvAddr1_is_modified || 
        __lcSecondAdvAddr2_is_modified || 
        __lcSecondAdvAddr3_is_modified || 
        __lcSecondAdvAddr4_is_modified || 
        __lcSecondAdvAddr5_is_modified || 
        __lcSndrRecInfo1_is_modified || 
        __lcSndrRecInfo2_is_modified || 
        __lcSndrRecInfo3_is_modified || 
        __lcSndrRecInfo4_is_modified || 
        __lcSndrRecInfo5_is_modified || 
        __lcSndrRecInfo6_is_modified || 
        __lcApplicantCntryCode_is_modified || 
        __lcAvailableWithCntry_is_modified || 
        __lcAvailableWithCodetyp_is_modified || 
        __lcDraweeCntryCode_is_modified || 
        __lcConfirmInstType_is_modified || 
        __lcReimbCntryCode_is_modified || 
        __lcSecondAdvCntrycode_is_modified || 
        __lcShipmentPeriod1_is_modified || 
        __lcShipmentPeriod2_is_modified || 
        __lcShipmentPeriod3_is_modified || 
        __lcShipmentPeriod4_is_modified || 
        __lcShipmentPeriod5_is_modified || 
        __lcShipmentPeriod6_is_modified || 
        __lcPerPresentationRemarks_is_modified || 
        __lcRecBicCode_is_modified || 
        __lcCfmReimbType_is_modified || 
        __lcCfmReimbBrnCode_is_modified || 
        __lcCfmReimbBicCode_is_modified || 
        __lcCfmReimbRoutid_is_modified || 
        __lcCfmReimbBnkCode_is_modified || 
        __lcCfmReimbAddr1_is_modified || 
        __lcCfmReimbAddr2_is_modified || 
        __lcCfmReimbAddr3_is_modified || 
        __lcCfmReimbAddr4_is_modified || 
        __lcCfmReimbAddr5_is_modified || 
        __lcCfmReimbCntryCode_is_modified;
    }

    public void resetIsModifiedS2J() {
        __lcBrnCode_is_modified = false;
        __lcLcType_is_modified = false;
        __lcLcYear_is_modified = false;
        __lcLcSl_is_modified = false;
        __lcFormOfDocCredit_is_modified = false;
        __lcReferenceToPreadvice_is_modified = false;
        __lcApplicableRules_is_modified = false;
        __lcApplicantReq_is_modified = false;
        __lcApplicantType_is_modified = false;
        __lcApplicantBrnCode_is_modified = false;
        __lcApplicantBicCode_is_modified = false;
        __lcApplicantRoutid_is_modified = false;
        __lcApplicantBnkCode_is_modified = false;
        __lcApplicantAddr1_is_modified = false;
        __lcApplicantAddr2_is_modified = false;
        __lcApplicantAddr3_is_modified = false;
        __lcApplicantAddr4_is_modified = false;
        __lcApplicantAddr5_is_modified = false;
        __lcAvailableWithType_is_modified = false;
        __lcAvailableWithBrnCode_is_modified = false;
        __lcAvailableWithCode_is_modified = false;
        __lcAvailableWithRoutid_is_modified = false;
        __lcAvailableWithBnkCode_is_modified = false;
        __lcAvailableWithAddr1_is_modified = false;
        __lcAvailableWithAddr2_is_modified = false;
        __lcAvailableWithAddr3_is_modified = false;
        __lcAvailableWithAddr4_is_modified = false;
        __lcAvailableWithAddr5_is_modified = false;
        __lcDraftsAt1_is_modified = false;
        __lcDraftsAt2_is_modified = false;
        __lcDraftsAt3_is_modified = false;
        __lcDraweeReq_is_modified = false;
        __lcDraweeType_is_modified = false;
        __lcDraweeBrnCode_is_modified = false;
        __lcDraweeBicCode_is_modified = false;
        __lcDraweeRoutid_is_modified = false;
        __lcDraweeBnkCode_is_modified = false;
        __lcDraweeAddr1_is_modified = false;
        __lcDraweeAddr2_is_modified = false;
        __lcDraweeAddr3_is_modified = false;
        __lcDraweeAddr4_is_modified = false;
        __lcDraweeAddr5_is_modified = false;
        __lcMixedPayDetails1_is_modified = false;
        __lcMixedPayDetails2_is_modified = false;
        __lcMixedPayDetails3_is_modified = false;
        __lcMixedPayDetails4_is_modified = false;
        __lcDeferredPayDetails1_is_modified = false;
        __lcDeferredPayDetails2_is_modified = false;
        __lcDeferredPayDetails3_is_modified = false;
        __lcDeferredPayDetails4_is_modified = false;
        __lcPartialShipments_is_modified = false;
        __lcTranshipment_is_modified = false;
        __lcPlaceOfTakingInCharge_is_modified = false;
        __lcPortOfLoading_is_modified = false;
        __lcPortOfDischarge_is_modified = false;
        __lcPlaceOfFinalDest_is_modified = false;
        __lcDescGoodsSer1_is_modified = false;
        __lcDescGoodsSer2_is_modified = false;
        __lcDescGoodsSer3_is_modified = false;
        __lcDocReq1_is_modified = false;
        __lcDocReq2_is_modified = false;
        __lcDocReq3_is_modified = false;
        __lcAddCondition1_is_modified = false;
        __lcAddCondition2_is_modified = false;
        __lcAddCondition3_is_modified = false;
        __lcCharges1_is_modified = false;
        __lcCharges2_is_modified = false;
        __lcCharges3_is_modified = false;
        __lcCharges4_is_modified = false;
        __lcCharges5_is_modified = false;
        __lcCharges6_is_modified = false;
        __lcPerPresentationDay_is_modified = false;
        __lcConfirmationInst_is_modified = false;
        __lcReimbReq_is_modified = false;
        __lcReimbType_is_modified = false;
        __lcReimbBrnCode_is_modified = false;
        __lcReimbBicCode_is_modified = false;
        __lcReimbRoutid_is_modified = false;
        __lcReimbBnkCode_is_modified = false;
        __lcReimbAddr1_is_modified = false;
        __lcReimbAddr2_is_modified = false;
        __lcReimbAddr3_is_modified = false;
        __lcReimbAddr4_is_modified = false;
        __lcReimbAddr5_is_modified = false;
        __lcInstPaying1_is_modified = false;
        __lcInstPaying2_is_modified = false;
        __lcInstPaying3_is_modified = false;
        __lcInstPaying4_is_modified = false;
        __lcInstPaying5_is_modified = false;
        __lcInstPaying6_is_modified = false;
        __lcInstPaying7_is_modified = false;
        __lcInstPaying8_is_modified = false;
        __lcInstPaying9_is_modified = false;
        __lcInstPaying10_is_modified = false;
        __lcInstPaying11_is_modified = false;
        __lcInstPaying12_is_modified = false;
        __lcSecondAdvReq_is_modified = false;
        __lcSecondAdvType_is_modified = false;
        __lcSecondAdvBrnCode_is_modified = false;
        __lcSecondAdvBicCode_is_modified = false;
        __lcSecondAdvRoutid_is_modified = false;
        __lcSecondAdvBnkCode_is_modified = false;
        __lcSecondAdvAddr1_is_modified = false;
        __lcSecondAdvAddr2_is_modified = false;
        __lcSecondAdvAddr3_is_modified = false;
        __lcSecondAdvAddr4_is_modified = false;
        __lcSecondAdvAddr5_is_modified = false;
        __lcSndrRecInfo1_is_modified = false;
        __lcSndrRecInfo2_is_modified = false;
        __lcSndrRecInfo3_is_modified = false;
        __lcSndrRecInfo4_is_modified = false;
        __lcSndrRecInfo5_is_modified = false;
        __lcSndrRecInfo6_is_modified = false;
        __lcApplicantCntryCode_is_modified = false;
        __lcAvailableWithCntry_is_modified = false;
        __lcAvailableWithCodetyp_is_modified = false;
        __lcDraweeCntryCode_is_modified = false;
        __lcConfirmInstType_is_modified = false;
        __lcReimbCntryCode_is_modified = false;
        __lcSecondAdvCntrycode_is_modified = false;
        __lcShipmentPeriod1_is_modified = false;
        __lcShipmentPeriod2_is_modified = false;
        __lcShipmentPeriod3_is_modified = false;
        __lcShipmentPeriod4_is_modified = false;
        __lcShipmentPeriod5_is_modified = false;
        __lcShipmentPeriod6_is_modified = false;
        __lcPerPresentationRemarks_is_modified = false;
        __lcRecBicCode_is_modified = false;
        __lcCfmReimbType_is_modified = false;
        __lcCfmReimbBrnCode_is_modified = false;
        __lcCfmReimbBicCode_is_modified = false;
        __lcCfmReimbRoutid_is_modified = false;
        __lcCfmReimbBnkCode_is_modified = false;
        __lcCfmReimbAddr1_is_modified = false;
        __lcCfmReimbAddr2_is_modified = false;
        __lcCfmReimbAddr3_is_modified = false;
        __lcCfmReimbAddr4_is_modified = false;
        __lcCfmReimbAddr5_is_modified = false;
        __lcCfmReimbCntryCode_is_modified = false;
    }
    public LcDetails() {
        _initialize();
    }

    public void _initialize() {
        _lcBrnCode = 0 ;
        _lcLcType = "" ;
        _lcLcYear = 0 ;
        _lcLcSl = 0 ;
        _lcFormOfDocCredit = 0 ;
        _lcReferenceToPreadvice = "" ;
        _lcApplicableRules = 0 ;
        _lcApplicantReq = ' ';
        _lcApplicantType = ' ';
        _lcApplicantBrnCode = "" ;
        _lcApplicantBicCode = "" ;
        _lcApplicantRoutid = "" ;
        _lcApplicantBnkCode = "" ;
        _lcApplicantAddr1 = "" ;
        _lcApplicantAddr2 = "" ;
        _lcApplicantAddr3 = "" ;
        _lcApplicantAddr4 = "" ;
        _lcApplicantAddr5 = "" ;
        _lcAvailableWithType = ' ';
        _lcAvailableWithBrnCode = "" ;
        _lcAvailableWithCode = "" ;
        _lcAvailableWithRoutid = "" ;
        _lcAvailableWithBnkCode = "" ;
        _lcAvailableWithAddr1 = "" ;
        _lcAvailableWithAddr2 = "" ;
        _lcAvailableWithAddr3 = "" ;
        _lcAvailableWithAddr4 = "" ;
        _lcAvailableWithAddr5 = "" ;
        _lcDraftsAt1 = "" ;
        _lcDraftsAt2 = "" ;
        _lcDraftsAt3 = "" ;
        _lcDraweeReq = ' ';
        _lcDraweeType = ' ';
        _lcDraweeBrnCode = "" ;
        _lcDraweeBicCode = "" ;
        _lcDraweeRoutid = "" ;
        _lcDraweeBnkCode = "" ;
        _lcDraweeAddr1 = "" ;
        _lcDraweeAddr2 = "" ;
        _lcDraweeAddr3 = "" ;
        _lcDraweeAddr4 = "" ;
        _lcDraweeAddr5 = "" ;
        _lcMixedPayDetails1 = "" ;
        _lcMixedPayDetails2 = "" ;
        _lcMixedPayDetails3 = "" ;
        _lcMixedPayDetails4 = "" ;
        _lcDeferredPayDetails1 = "" ;
        _lcDeferredPayDetails2 = "" ;
        _lcDeferredPayDetails3 = "" ;
        _lcDeferredPayDetails4 = "" ;
        _lcPartialShipments = 0 ;
        _lcTranshipment = 0 ;
        _lcPlaceOfTakingInCharge = "" ;
        _lcPortOfLoading = "" ;
        _lcPortOfDischarge = "" ;
        _lcPlaceOfFinalDest = "" ;
        _lcDescGoodsSer1 = "" ;
        _lcDescGoodsSer2 = "" ;
        _lcDescGoodsSer3 = "" ;
        _lcDocReq1 = "" ;
        _lcDocReq2 = "" ;
        _lcDocReq3 = "" ;
        _lcAddCondition1 = "" ;
        _lcAddCondition2 = "" ;
        _lcAddCondition3 = "" ;
        _lcCharges1 = "" ;
        _lcCharges2 = "" ;
        _lcCharges3 = "" ;
        _lcCharges4 = "" ;
        _lcCharges5 = "" ;
        _lcCharges6 = "" ;
        _lcPerPresentationDay = 0 ;
        _lcConfirmationInst = 0 ;
        _lcReimbReq = ' ';
        _lcReimbType = ' ';
        _lcReimbBrnCode = "" ;
        _lcReimbBicCode = "" ;
        _lcReimbRoutid = "" ;
        _lcReimbBnkCode = "" ;
        _lcReimbAddr1 = "" ;
        _lcReimbAddr2 = "" ;
        _lcReimbAddr3 = "" ;
        _lcReimbAddr4 = "" ;
        _lcReimbAddr5 = "" ;
        _lcInstPaying1 = "" ;
        _lcInstPaying2 = "" ;
        _lcInstPaying3 = "" ;
        _lcInstPaying4 = "" ;
        _lcInstPaying5 = "" ;
        _lcInstPaying6 = "" ;
        _lcInstPaying7 = "" ;
        _lcInstPaying8 = "" ;
        _lcInstPaying9 = "" ;
        _lcInstPaying10 = "" ;
        _lcInstPaying11 = "" ;
        _lcInstPaying12 = "" ;
        _lcSecondAdvReq = ' ';
        _lcSecondAdvType = ' ';
        _lcSecondAdvBrnCode = "" ;
        _lcSecondAdvBicCode = "" ;
        _lcSecondAdvRoutid = "" ;
        _lcSecondAdvBnkCode = "" ;
        _lcSecondAdvAddr1 = "" ;
        _lcSecondAdvAddr2 = "" ;
        _lcSecondAdvAddr3 = "" ;
        _lcSecondAdvAddr4 = "" ;
        _lcSecondAdvAddr5 = "" ;
        _lcSndrRecInfo1 = "" ;
        _lcSndrRecInfo2 = "" ;
        _lcSndrRecInfo3 = "" ;
        _lcSndrRecInfo4 = "" ;
        _lcSndrRecInfo5 = "" ;
        _lcSndrRecInfo6 = "" ;
        _lcApplicantCntryCode = "" ;
        _lcAvailableWithCntry = "" ;
        _lcAvailableWithCodetyp = 0 ;
        _lcDraweeCntryCode = "" ;
        _lcConfirmInstType = ' ';
        _lcReimbCntryCode = "" ;
        _lcSecondAdvCntrycode = "" ;
        _lcShipmentPeriod1 = "" ;
        _lcShipmentPeriod2 = "" ;
        _lcShipmentPeriod3 = "" ;
        _lcShipmentPeriod4 = "" ;
        _lcShipmentPeriod5 = "" ;
        _lcShipmentPeriod6 = "" ;
        _lcPerPresentationRemarks = "" ;
        _lcRecBicCode = "" ;
        _lcCfmReimbType = ' ';
        _lcCfmReimbBrnCode = "" ;
        _lcCfmReimbBicCode = "" ;
        _lcCfmReimbRoutid = "" ;
        _lcCfmReimbBnkCode = "" ;
        _lcCfmReimbAddr1 = "" ;
        _lcCfmReimbAddr2 = "" ;
        _lcCfmReimbAddr3 = "" ;
        _lcCfmReimbAddr4 = "" ;
        _lcCfmReimbAddr5 = "" ;
        _lcCfmReimbCntryCode = "" ;
    }

}
