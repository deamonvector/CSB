package panacea.OLC.ejb;

import java.rmi.RemoteException;
import java.sql.SQLException;
import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import panacea.common.DTObject;
import panacea.common.PanErrorMsg;
import panacea.common.PanaceaException;
import panacea.common.FormatUtils;
import panacea.TranControl.TransControl;
import panacea.IRS.Update.Inremdisp;
import panacea.IRS.Update.InremdispManager;
import panacea.OLC.Update.LcDetailsHist;
import panacea.OLC.Update.LcDetailsHistManager;
import panacea.OLC.Update.LcDetailsManager;
import panacea.OLC.Update.Olcamd;
import panacea.OLC.Update.OlcamdManager;
import panacea.OLC.Update.Olcamdchoice;
import panacea.OLC.Update.OlcamdchoiceManager;
import panacea.OLC.Update.Olcamdtext;
import panacea.OLC.Update.OlcamdtextManager;
import panacea.OLC.Update.Olcamdtextlog;
import panacea.OLC.Update.OlcamdtextlogManager;
import panacea.OLC.Update.Olcled;
import panacea.OLC.Update.OlcledManager;
import panacea.OLC.Update.Olcmar;
import panacea.OLC.Update.OlcmarManager;
import panacea.OLC.Update.Olcotext;
import panacea.OLC.Update.OlcotextManager;
import panacea.OLC.Update.Olcshiptext;
import panacea.OLC.Update.OlcshiptextManager;
import panacea.OLC.Update.Olctenorsamd;
import panacea.OLC.Update.OlctenorsamdManager;
import panacea.AML.Update.blacklistVerificationQueueUpdate;
import panacea.COMP.Update.TranstlmntBO;
import panacea.autopost.comp.*; //Changes P.Subramani-Chn25/08/2008 Beg
import panacea.OLC.Update.Olctenors;
import panacea.OLC.Update.OlctenorsManager;
import panacea.OLC.Update.Olc;
import panacea.OLC.Update.OlcManager; //changes P.Subramani-Chn25/08/2008 End

//Changes in EOLCAMD on 16-Oct-2018 start
import panacea.OLC.Update.AmendDetails;
import panacea.OLC.Update.AmendDetailsManager;
import panacea.OLC.Update.AmendDetailsHist;
import panacea.OLC.Update.AmendDetailsHistManager; //Changes in EOLCAMD on 16-Oct-2018 end

import java.sql.Types;
import java.rmi.RemoteException;
import java.sql.CallableStatement;
import java.sql.Connection;

import panacea.COMP.Update.ctranchgsBO;
import panacea.autopost.comp.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * XDoclet-based session bean. The class must be declared public according to
 * the EJB specification.
 * 
 * To generate the EJB related files to this EJB: - Add Standard EJB module to
 * XDoclet project properties - Customize XDoclet configuration for your
 * appserver - Run XDoclet
 * 
 * @ejb.bean name= "eolcamdBO" display-name="Name for Bean Information"
 *           description="Description" jndi-name="ejb/eolcamdBO"
 *           type="Stateless" view-type="both" transaction-type = "Bean"
 * @ejb.interface remote-class ="panacea.OLC.interfaces.eolcamd" local-class
 *                ="panacea.OLC.interfaces.eolcamdLocal"
 * @ejb.home remote-class ="panacea.OLC.interfaces.eolcamdHome" local-class
 *           ="panacea.OLC.interfaces.eolcamdLocalHome"
 * 
 */
public class eolcamdBO extends postingComponent implements SessionBean {

	private static final Olctenors OlctenorsInstance = null;
	private String Option;
	private String _olcShipment1;
	private String _olcShipment2;
	private String _olca_entry_date;// get this from SQL token
	private String _olc_entry_date;
	private ctranchgsBO ctranchgsInstance;
	private String _sourceKey;
	private String _branchCode;
	private String _lcType;
	private String _lcYear;
	private String _lcSl;
	private String _redFlag;
	private String _redAmt;
	private String _prevRedFlag;
	private String _prevRedAmt;
	private int _noOfDrawDowns;
	private int _Wi;
	private String _prevTenorAmt;
	private String _currTenorAmt;
	private String _prevUsanceIntAmt;
	private String _currUsanceIntAmt;
	String[] PrevTenorAmt = null;
	String[] TotalLiabAmt = null;
	String[] BalTenor = null;
	String[] BalUsanceAmt = null;
	private String _totalLiabAmt;
	private String _amdSerial;

	private double CurrentDeviation;
	private String _olcBal;
	private String _olcAMT;
	private double _currTotalAmt;
	private String _olcBalUsaInt;
	private String _olcBalTenAmt;
	private String _CBD;
	private String postBrn;
	private String postDate;
	private String postBatchNum;
	private String corrRefNum;
	private String contra_Glacc_Code;
	private String baseCurr;
	private String contactAmt;
	private String internalAccNum;
	private String totalAmt;
	private String redlcliabbaseamt;
	private String zeroval = "0";

	// Changes P.Subramani-23-06-2008 Beg
	private String contraGL1;
	private String contraGL2;
	private String usancechgcode;
	private String commchgcode;
	private double usancechgs;
	private double commchgs;
	// Changes P.Subramani 23-06-2008 End

	// Changes P.Subramani-Chn-22/08/2008 Beg
	private double _EnhancedAmt;
	private double _Prev_EnhancedAmt;
	private double _ReductionAmt;
	private double _Prev_ReductionAmt;
	private double _PrevCommAmt;
	// Changes P.Subramani-Chn-22/08/2008 End
	private double _olc_devbal;
	private double Resdevbal;

	// Changes P.Subramani-Chn22/10/2008 B
	private String olcotexttype = "A";
	private String maxSl = "";
	private String TxnSl = "";
	private String userBrnCode = "";
	private String _brnAuth = "";
	private String _brnAuthLCType = "";

	// Chnages in EOLCAMD on 16-Oct-2018 start
	private int max_sl = 0;
	// Changes in EOLCAMD on 16-Oct-2018 end

	private SessionContext context;

	public eolcamdBO() {
		super();

	}

	/**
	 * Set the associated session context. The container calls this method after
	 * the instance creation.
	 * 
	 * The enterprise bean instance should store the reference to the context
	 * object in an instance variable.
	 * 
	 * This method is called with no transaction context.
	 * 
	 * @throws EJBException
	 *             Thrown if method fails due to system-level error.
	 */
	public void setSessionContext(SessionContext newContext) throws EJBException {
		context = newContext;
	}

	public void ejbRemove() throws EJBException, RemoteException {
		// TODO Auto-generated method stub

	}

	public void ejbActivate() throws EJBException, RemoteException {
		// TODO Auto-generated method stub

	}

	public void ejbPassivate() throws EJBException, RemoteException {
		// TODO Auto-generated method stub

	}

	/**
	 * An ejbCreate method as required by the EJB specification.
	 * 
	 * The container calls the instance?s <code>ejbCreate</code> method whose
	 * signature matches the signature of the <code>create</code> method
	 * invoked by the client. The input parameters sent from the client are
	 * passed to the <code>ejbCreate</code> method. Each session bean class
	 * must have at least one <code>ejbCreate</code> method. The number and
	 * signatures of a session bean?s <code>create</code> methods are specific
	 * to each session bean class.
	 * 
	 * @throws CreateException
	 *             Thrown if method fails due to system-level error.
	 * 
	 * 
	 * @ejb.create-method
	 * 
	 */
	public void ejbCreate() throws CreateException {
		// TODO Add ejbCreate method implementation

	}

	private void Init_Para() throws PanaceaException {
		Tba_key_In_Main_Table = "";
		Programid = "eolcamd";
		TBAAUTH_MAIN_TABLE_NAME = "OLCAMD";
		TBAAUTH_MAIN_PK = dtoobj.getValue("OLCA_AMD_SL") + "|" + dtoobj.getValue("OLCA_BRN_CODE") + "|" + dtoobj.getValue("OLCA_LC_SL") + "|" + dtoobj.getValue("OLCA_LC_TYPE") + "|" + dtoobj.getValue("OLCA_LC_YEAR");
		TBAAUTH_ENTRY_DATE = null;
		TBAAUTH_DTL_SL = 0;
		TBA_DISPLAY_DTLS = "";
		Option = dtoobj.getValue("UserOption");
		TBAAUTH_OPERN_FLG = Option;
		User_Id = dtoobj.getValue("USERID");
		ReturnResult = new DTObject();
		ReturnResult.clearMap();
		tba_auth_queue_req = false;
		Table_Class_Name = "OLCAMD";
		ctranchgsInstance = new ctranchgsBO();

	}

	/**
	 * @ejb.interface-method view-type = "both"
	 */
	public DTObject updateValues(DTObject InputmapObj) throws EJBException, RemoteException {
		dtoobj = InputmapObj;
		DTObject tranchgsDTO = new DTObject();
		_olc_entry_date = dtoobj.getValue("OLCA_ENTRY_DATE");
		// Settlement Comp Local Variable Starts
		_sourceKey = dtoobj.getValue("OLCA_BRN_CODE") + "|" + dtoobj.getValue("OLCA_LC_TYPE") + "|" + dtoobj.getValue("OLCA_LC_YEAR") + "|" + dtoobj.getValue("OLCA_LC_SL") + "|" + dtoobj.getValue("OLCA_AMD_SL");
		// Settlement Comp Ends

		// Procedures Local Variables Starts
		_branchCode = dtoobj.getValue("OLCA_BRN_CODE");
		_lcType = dtoobj.getValue("OLCA_LC_TYPE");
		_lcYear = dtoobj.getValue("OLCA_LC_YEAR");
		_lcSl = dtoobj.getValue("OLCA_LC_SL");
		_redFlag = dtoobj.getValue("OLCA_ENHANCEMNT_REDUCN");
		_redAmt = dtoobj.getValue("OLCLD_TXN_AMT");
		_prevRedFlag = dtoobj.getValue("PREV_RED_FLAG");
		_prevRedAmt = dtoobj.getValue("PREV_RED_AMT");
		_noOfDrawDowns = Integer.parseInt(dtoobj.getValue("OLCA_NOF_TENORS"));
		_prevTenorAmt = dtoobj.getValue("PREV_GRID_TENOR_AMT");
		_totalLiabAmt = dtoobj.getValue("PREV_GRID_LIAB_AMT");
		_olcBal = dtoobj.getValue("OLC_DEV_BAL");// OLC.OLC_DEV_BAL
		_olcAMT = dtoobj.getValue("OLC_LC_AMOUNT");// OLC.OLC_LC_AMOUNT
		_olcBalTenAmt = dtoobj.getValue("OLCT_BAL_TENOR_AMT");// OLCT_BAL_TENOR_AMT
		_olcBalUsaInt = dtoobj.getValue("OLCT_BAL_USANCE_INT_AMT");// OLCT_BAL_TENOR_AMT
		_amdSerial = dtoobj.getValue("OLCA_AMD_SL");
		_CBD = dtoobj.getValue("CBD");
		postBrn = dtoobj.getValue("POST_TRAN_BRN");
		postDate = dtoobj.getValue("POST_TRAN_DATE");
		postBatchNum = dtoobj.getValue("POST_TRAN_BATCH_NUM");
		corrRefNum = dtoobj.getValue("CORR_REF_NUM");
		baseCurr = dtoobj.getValue("BASE_CURR");
		contactAmt = dtoobj.getValue("OLCA_ADD_LIAB_BASE_CURR");
		redlcliabbaseamt = dtoobj.getValue("RED_LCLIAB_BASE_AMT");
		internalAccNum = dtoobj.getValue("INTERNAL_ACC_NUM");
		totalAmt = dtoobj.getValue("TOTAL_CHARGE_AMT");

		// Changes P.Subramani-Chn-23-06-2008 Beg
		usancechgcode = InputmapObj.getValue("TRCHG_USANCE_CHGCD");
		commchgcode = InputmapObj.getValue("TRCHG_COMMITMNT_CHGCD");
		usancechgs = Double.parseDouble(InputmapObj.getValue("USANCE_CHARGES"));
		commchgs = Double.parseDouble(InputmapObj.getValue("COMMITMENT_CHARGES"));
		// Changes P.Subramani-Chn-23-06-2008 End
		// CHANGED ADDED ON 25/07/2018 START
		userBrnCode = dtoobj.getValue("USRBRNCODE");
		_brnAuth = dtoobj.getValue("USER_BRNAUTH");
		_brnAuthLCType = dtoobj.getValue("BRN_AUTH_LCTYPE");
		// CHANGED ADDED ON 25/07/2018 END

		try {
			Init_Para();
			BeginTransaction(context);
			check_for_tba_updation();

			ctranchgsInstance.set_COLLECTIONObj(_COLLECTIONObj);
			ctranchgsInstance.setV_ADD_LOG_REQ(V_ADD_LOG_REQ);
			ctranchgsInstance.setV_LOG_REQ(V_LOG_REQ);
			tranchgsDTO = ctranchgsInstance.updateValues(InputmapObj);
			InputmapObj.setValue("TRANCHGS_RET_SL", tranchgsDTO.getValue("TRANCHGS_SL"));

			if (Option.equalsIgnoreCase("A")) {
				addRecord(InputmapObj);
				addOLCLED(InputmapObj);
				if (Integer.parseInt(_amdSerial) == 1) {
					addOLCSHIPTEXT1(InputmapObj);
					addOLCSHIPTEXT2(InputmapObj);
				} else {
					modOLCSHIPTEXT1(InputmapObj);
					modOLCSHIPTEXT2(InputmapObj);
				}

				addOLCOTEXT(InputmapObj);
				addOLCTENORSAMD(InputmapObj);
				// Changes P.Subramani-Chn-22/10/2008 Beg
				AddOlcMar(InputmapObj);
				// Changes P.Subramani-Chn-22/10/2008 End
				// Changes in EOLCAMD on 16-Oct-2018 start
				// if(_lcType.trim().toString().equalsIgnoreCase("OLC"))
				AddSwiftAmendLcDetails(InputmapObj);
				// Changes in EOLCAMD on 16-Oct-2018 end
			} else {

				_olca_entry_date = dtoobj.getValue("OLCA_ENTRY_DATE_SQL");
				modRecord(InputmapObj);
				if (!_olc_entry_date.equalsIgnoreCase(_olca_entry_date)) {
					modOLCLED(InputmapObj);
				}

				modOLCSHIPTEXT1(InputmapObj);
				modOLCSHIPTEXT2(InputmapObj);

				modOLCOTEXT(InputmapObj);
				modOLCTENORSAMD(InputmapObj);
				// Changes P.Subramani-Chn-22/10/2008 Beg
				ModOlcMar(InputmapObj);
				// Changes P.Subramani-Chn-22/10/2008 End
				// Changes in EOLCAMD on 16-Oct-2018 start
				// if(_lcType.trim().toString().equalsIgnoreCase("OLC"))
				ModifySwiftamendDetails(InputmapObj);
				// Changes in EOLCAMD on 16-Oct-2018 end
			}
			// Changes in EOLCAMD on 16-Oct-2018 start
			if (_lcType.trim().toString().equalsIgnoreCase("OLC")) {
				setSerialNumber(InputmapObj);
				AddSwiftAmendDetailsHist(InputmapObj);
			}

			// Changes in EOLCAMD on 16-Oct-2018 start

			Set_Tran_Settlement_values();
			// Changes P.Subramani-Chn-25/08/2008 Beg
			addOLCTENORS(InputmapObj);
			UpdateOLCDevBal(InputmapObj);
			// Changes P.Subramani-Chn-25/08/2008 End
			// Changes P.Subramani-Chn-21/10/2008 Beg
			UpdateOLCMarginBal(InputmapObj);
			// Changes P.Subramani-Chn-21/10/2008 End
			// Procedure-Starts
			UpdateProcedure(InputmapObj);
			// Procedure-Ends

			// ADDED BY PRASHANTH FOR BLACKLIST VERIRFICATION ON 08 FEB 2019
		 	setBlackListVerification(InputmapObj);
			// ADDED BY PRASHANTH FOR BLACKLIST VERIRFICATION ON 08 FEB 2019

			
			
			// added by prashanth on 22 feb 2019
			
			DeleteRecordAmdChoice(InputmapObj);
			DeleteaddRecordOlcTxtLogInstance(InputmapObj);
			DeleteaddRecordOlcAmdtext(InputmapObj);
			
			
			addRecordAmdChoice(InputmapObj);
			addRecordOlcTxtLogInstance(InputmapObj);
			addRecordOlcAmdtext(InputmapObj);
			// added by prashanth on 22 feb 2019
			posting_Transaction(InputmapObj);
			CommitTran();
		} catch (PanaceaException Excep) {
			RollBackTran(Excep.getLocalizedMessage());
		}
		return ReturnResult;
	}

	// ADDED BY PRASHANTH FOR BLACKLIST VERIRFICATION ON 08 FEB 2019
	private void setBlackListVerification(DTObject InputmapObj) throws PanaceaException {
		blacklistVerificationQueueUpdate blkUpdate = new blacklistVerificationQueueUpdate();
		InputmapObj.setValue("PROGRAM_ID", "EOLCAMD");
		InputmapObj.setValue("MODULE_CODE", "OLC");
		InputmapObj.setValue("SRC_TABLE", "OLCAMD");
		InputmapObj.setValue("BRANCH_CODE", _branchCode);
		InputmapObj.setValue("BLKLSTVQ_DATE", _CBD);
		InputmapObj.setValue("CUST_CODE", InputmapObj.getValue("CUST_CODE"));
		InputmapObj.setValue("CPARTY_CODE", InputmapObj.getValue("OLCA_BENEF_CODE"));
		InputmapObj.setValue("SOURCE_KEY", _sourceKey);
		blkUpdate.deleteBlacklistQueue(InputmapObj);// DELETE THE QUEUE
		blkUpdate.updateBlackValue(InputmapObj);
	}

	// ADDED BY PRASHANTH FOR BLACKLIST VERIRFICATION ON 08 FEB 2019

	private void Set_Entd_Dtls(Olcamd inputObj) throws PanaceaException {
		if (Option.equalsIgnoreCase("A")) {
			inputObj.setOlcaEntdBy(User_Id);
			inputObj.setOlcaEntdOn(Get_System_Time());
		} else {
			inputObj.setOlcaAuthBy("");
			inputObj.setOlcaAuthOn(null);
		}
		inputObj.setOlcaAuthBy("");
		inputObj.setOlcaAuthOn(null);
	}

	private void addRecord(DTObject dtoobject) throws PanaceaException {
		try {
			Olcamd OlcamdInstance = new Olcamd();
			OlcamdManager OlcamdManagerInstance = new OlcamdManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);
			OlcamdInstance.setOlcaBrnCode(Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")));
			OlcamdInstance.setOlcaLcType(dtoobject.getValue("OLCA_LC_TYPE"));
			OlcamdInstance.setOlcaLcYear(Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")));
			OlcamdInstance.setOlcaLcSl(Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")));
			OlcamdInstance.setOlcaAmdSl(Integer.parseInt(dtoobject.getValue("OLCA_AMD_SL")));
			OlcamdInstance.setOlcaEntryDate(DateToYYYYMMDD(dtoobject.getValue("OLCA_ENTRY_DATE")));
			OlcamdInstance.setOlcaCustLetterNum(dtoobject.getValue("OLCA_CUST_LETTER_NUM"));
			OlcamdInstance.setOlcaCustLtrDate(DateToYYYYMMDD(dtoobject.getValue("OLCA_CUST_LTR_DATE")));
			OlcamdInstance.setOlcaRsnForAmd(stringToChar(dtoobject.getValue("OLCA_RSN_FOR_AMD")));
			OlcamdInstance.setOlcaChangeOfBenef(stringToChar(dtoobject.getValue("OLCA_CHANGE_OF_BENEF")));
			OlcamdInstance.setOlcaBenefCode(dtoobject.getValue("OLCA_BENEF_CODE"));
			OlcamdInstance.setOlcaBenefName(dtoobject.getValue("OLCA_BENEF_NAME"));
			OlcamdInstance.setOlcaBenefAddr1(dtoobject.getValue("OLCA_BENEF_ADDR1"));
			OlcamdInstance.setOlcaBenefAddr2(dtoobject.getValue("OLCA_BENEF_ADDR2"));
			OlcamdInstance.setOlcaBenefAddr3(dtoobject.getValue("OLCA_BENEF_ADDR3"));
			OlcamdInstance.setOlcaBenefAddr4(dtoobject.getValue("OLCA_BENEF_ADDR4"));
			OlcamdInstance.setOlcaBenefAddr5(dtoobject.getValue("OLCA_BENEF_ADDR5"));
			OlcamdInstance.setOlcaBenefCntryCode(dtoobject.getValue("OLCA_BENEF_CNTRY_CODE"));
			OlcamdInstance.setOlcaEnhancemntReducn(stringToChar(dtoobject.getValue("OLCA_ENHANCEMNT_REDUCN")));
			OlcamdInstance.setOlcaLcCurrCode(dtoobject.getValue("OLCA_LC_CURR_CODE"));
			OlcamdInstance.setOlcaAmendedAmt(Double.parseDouble(dtoobject.getValue("OLCA_AMENDED_AMT")));
			OlcamdInstance.setOlcaPosDevAllwd(Double.parseDouble(dtoobject.getValue("OLCA_POS_DEV_ALLWD")));
			OlcamdInstance.setOlcaNegDevAllwd(Double.parseDouble(dtoobject.getValue("OLCA_NEG_DEV_ALLWD")));
			OlcamdInstance.setOlcaDevAmt(Double.parseDouble(dtoobject.getValue("OLCA_DEV_AMT")));
			OlcamdInstance.setOlcaAmtQualfr(stringToChar(dtoobject.getValue("OLCA_AMT_QUALFR")));
			OlcamdInstance.setOlcaPriceTerms(dtoobject.getValue("OLCA_PRICE_TERMS"));
			if (!dtoobj.getValue("OLCA_LAST_DATE_OF_NEG").trim().equals("") || !dtoobj.getValue("OLCA_LAST_DATE_OF_NEG").trim().equals(""))
				OlcamdInstance.setOlcaLastDateOfNeg(DateToYYYYMMDD(dtoobj.getValue("OLCA_LAST_DATE_OF_NEG")));
			else
				OlcamdInstance.setOlcaLastDateOfNeg(null);
			// OlcamdInstance.setOlcaLastDateOfNeg(DateToYYYYMMDD(dtoobject.getValue("OLCA_LAST_DATE_OF_NEG")));
			OlcamdInstance.setOlcaPlaceOfExpiry(dtoobject.getValue("OLCA_PLACE_OF_EXPIRY"));
			// OlcamdInstance.setOlcaLatestDateOfShpmnt(DateToYYYYMMDD(dtoobject.getValue("OLCA_LATEST_DATE_OF_SHPMNT")));
			if (dtoobj.getValue("OLCA_LATEST_DATE_OF_SHPMNT") != null)
				OlcamdInstance.setOlcaLatestDateOfShpmnt(DateToYYYYMMDD(dtoobj.getValue("OLCA_LATEST_DATE_OF_SHPMNT")));
			else
				OlcamdInstance.setOlcaLatestDateOfShpmnt(null);
			OlcamdInstance.setOlcaWithinValidateLc(stringToChar(dtoobject.getValue("OLCA_WITHIN_VALIDATE_LC")));
			OlcamdInstance.setOlcaLcUiBorneByApplcnt(stringToChar(dtoobject.getValue("OLCA_LC_UI_BORNE_BY_APPLCNT")));
			OlcamdInstance.setOlcaNofTenors(Integer.parseInt(dtoobject.getValue("OLCA_NOF_TENORS")));
			OlcamdInstance.setOlcaAddLiabLcCurr(Double.parseDouble(dtoobject.getValue("OLCA_ADD_LIAB_LC_CURR")));
			OlcamdInstance.setOlcaConvRateBaseCurr(Double.parseDouble(dtoobject.getValue("OLCA_CONV_RATE_BASE_CURR")));
			OlcamdInstance.setOlcaAddLiabBaseCurr(Double.parseDouble(dtoobject.getValue("OLCA_ADD_LIAB_BASE_CURR")));
			OlcamdInstance.setOlcaConvRateLimCurr(Double.parseDouble(dtoobject.getValue("OLCA_CONV_RATE_LIM_CURR")));
			OlcamdInstance.setOlcaTotLiabLimCurr(Double.parseDouble(dtoobject.getValue("OLCA_TOT_LIAB_LIM_CURR")));
			OlcamdInstance.setOlcaContraAmt(Double.parseDouble(dtoobject.getValue("OLCA_ADD_LIAB_BASE_CURR")));
			// Changes P.Subramani-Chn-12/04/2008 Beg
			OlcamdInstance.setOlcaUsanceCharges(Double.parseDouble(dtoobject.getValue("USANCE_CHARGES")));
			OlcamdInstance.setOlcaUsnChgTakenDays(Integer.parseInt(dtoobject.getValue("OLCA_USN_CHG_TAKEN_DAYS")));
			OlcamdInstance.setOlcaCommitmentCharges(Double.parseDouble(dtoobject.getValue("COMMITMENT_CHARGES")));
			OlcamdInstance.setOlcaCommitChgTakenDays(Integer.parseInt(dtoobject.getValue("OLCA_COMMIT_CHG_TAKEN_DAYS")));
			// Changes P.Subramani-Chn-12/04/2008 End

			// Changes P.Subramani-Chn-19/08/2008 Beg
			OlcamdInstance.setOlcaTotLiabLcCurr(Double.parseDouble(dtoobject.getValue("OLCA_TOT_LIAB_LC_CURR")));
			OlcamdInstance.setOlcaTotLiabBaseCurr(Double.parseDouble(dtoobject.getValue("OLCA_TOT_LIAB_BASE_CURR")));
			// Changes P.Subramani-Chn-19/08/2008 End

			OlcamdInstance.setTranchgsChgsSl(Long.parseLong(dtoobject.getValue("TRANCHGS_RET_SL")));
			OlcamdInstance.setTranstlmntInvNum(Long.parseLong(dtoobject.getValue("TRANSTLMNT_INV_NUM")));
			OlcamdInstance.setOlcaLastmodBy(dtoobject.getValue("OLCA_LASTMOD_BY"));
			OlcamdInstance.setOlcaLastmodOn(DateToYYYYMMDD(dtoobject.getValue("OLCA_LASTMOD_ON")));
			OlcamdInstance.setOlcaRejBy(dtoobject.getValue("OLCA_REJ_BY"));
			OlcamdInstance.setOlcaRejOn(DateToYYYYMMDD(dtoobject.getValue("OLCA_REJ_ON")));
			// NEW FIELDS ADDED BY PRASHANTH ON 08 FEB 2019
			OlcamdInstance.setOlcaChgInDescGoods(stringToChar(dtoobject.getValue("OLCA_CHG_IN_DESC_GOODS")));
			OlcamdInstance.setOlcaChgInDoc(stringToChar(dtoobject.getValue("OLCA_CHG_IN_DOC")));
			OlcamdInstance.setOlcaChgInAddlCond(stringToChar(dtoobject.getValue("OLCA_CHG_IN_ADDL_COND")));
			// NEW FIELDS ADDED BY PRASHANTH ON 08 FEB 2019

			// NEW FIELDS ADDED BY PRASHANTH ON 21 FEB 2019
			OlcamdInstance.setOlcaReqForCancel(stringToChar(dtoobject.getValue("OLCA_REQ_FOR_CANCEL")));
			OlcamdInstance.setOlcaChgOfAppl(stringToChar(dtoobject.getValue("OLCA_CHG_OF_APPL")));
			OlcamdInstance.setOlcaChgInAvlWith(stringToChar(dtoobject.getValue("OLCA_CHG_IN_AVL_WITH")));
			OlcamdInstance.setOlcaChgInDraweePay(stringToChar(dtoobject.getValue("OLCA_CHG_IN_DRAWEE_PAY")));
			//Changes Sanjay 02-07-2019 Begin
			OlcamdInstance.setOlcaAmdChgPayBy(stringToChar(dtoobject.getValue("OLCA_AMD_CHG_PAY_BY")));
			OlcamdInstance.setOlcaPerOfPresDays((dtoobject.getValue("OLCA_PER_OF_PRES_DAYS")));
			//Changes Sanjay 02-07-2019 end
			OlcamdInstance.setOlcaChgInReimb(stringToChar(dtoobject.getValue("OLCA_CHG_IN_REIMB")));
			OlcamdInstance.setOlcaChgInAdvBk(stringToChar(dtoobject.getValue("OLCA_CHG_IN_ADV_BK")));

			OlcamdInstance.setOlcaChgInFormOfDc(stringToChar(dtoobject.getValue("OLCA_CHG_IN_FORM_OF_DC")));
			OlcamdInstance.setOlcaChgInApplRules(stringToChar(dtoobject.getValue("OLCA_CHG_IN_APPL_RULES")));
			// NEW FIELDS ADDED BY PRASHANTH ON 21 FEB 2019

			Set_Entd_Dtls(OlcamdInstance);
			OlcamdInstance.setIsNew(true);
			OlcamdManagerInstance.save(OlcamdInstance, TBAAUTH_MAIN_PK, TBAAUTH_ENTRY_DATE, TBAAUTH_DTL_SL);
		} catch (Exception e) {
			throw new PanaceaException(e.getLocalizedMessage());
		}
	}

	private void modRecord(DTObject dtoobject) throws PanaceaException {
		try {
			Olcamd OlcamdInstance = new Olcamd();
			OlcamdManager OlcamdManagerInstance = new OlcamdManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);
			OlcamdInstance = OlcamdManagerInstance.loadByKey(Integer.parseInt(dtoobj.getValue("OLCA_AMD_SL")), Integer.parseInt(dtoobj.getValue("OLCA_BRN_CODE")), Integer.parseInt(dtoobj.getValue("OLCA_LC_SL")), dtoobj.getValue("OLCA_LC_TYPE"), Integer.parseInt(dtoobj.getValue("OLCA_LC_YEAR")));
			if (OlcamdInstance != null) {
				OlcamdInstance.setOlcaBrnCode(Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")));
				OlcamdInstance.setOlcaLcType(dtoobject.getValue("OLCA_LC_TYPE"));
				OlcamdInstance.setOlcaLcYear(Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")));
				OlcamdInstance.setOlcaLcSl(Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")));
				OlcamdInstance.setOlcaAmdSl(Integer.parseInt(dtoobject.getValue("OLCA_AMD_SL")));
				OlcamdInstance.setOlcaEntryDate(DateToYYYYMMDD(dtoobject.getValue("OLCA_ENTRY_DATE")));
				OlcamdInstance.setOlcaCustLetterNum(dtoobject.getValue("OLCA_CUST_LETTER_NUM"));
				OlcamdInstance.setOlcaCustLtrDate(DateToYYYYMMDD(dtoobject.getValue("OLCA_CUST_LTR_DATE")));
				OlcamdInstance.setOlcaRsnForAmd(stringToChar(dtoobject.getValue("OLCA_RSN_FOR_AMD")));
				OlcamdInstance.setOlcaChangeOfBenef(stringToChar(dtoobject.getValue("OLCA_CHANGE_OF_BENEF")));
				OlcamdInstance.setOlcaBenefCode(dtoobject.getValue("OLCA_BENEF_CODE"));
				OlcamdInstance.setOlcaBenefName(dtoobject.getValue("OLCA_BENEF_NAME"));
				OlcamdInstance.setOlcaBenefAddr1(dtoobject.getValue("OLCA_BENEF_ADDR1"));
				OlcamdInstance.setOlcaBenefAddr2(dtoobject.getValue("OLCA_BENEF_ADDR2"));
				OlcamdInstance.setOlcaBenefAddr3(dtoobject.getValue("OLCA_BENEF_ADDR3"));
				OlcamdInstance.setOlcaBenefAddr4(dtoobject.getValue("OLCA_BENEF_ADDR4"));
				OlcamdInstance.setOlcaBenefAddr5(dtoobject.getValue("OLCA_BENEF_ADDR5"));
				OlcamdInstance.setOlcaBenefCntryCode(dtoobject.getValue("OLCA_BENEF_CNTRY_CODE"));
				OlcamdInstance.setOlcaEnhancemntReducn(stringToChar(dtoobject.getValue("OLCA_ENHANCEMNT_REDUCN")));
				OlcamdInstance.setOlcaLcCurrCode(dtoobject.getValue("OLCA_LC_CURR_CODE"));
				OlcamdInstance.setOlcaAmendedAmt(Double.parseDouble(dtoobject.getValue("OLCA_AMENDED_AMT")));
				OlcamdInstance.setOlcaPosDevAllwd(Double.parseDouble(dtoobject.getValue("OLCA_POS_DEV_ALLWD")));
				OlcamdInstance.setOlcaNegDevAllwd(Double.parseDouble(dtoobject.getValue("OLCA_NEG_DEV_ALLWD")));
				OlcamdInstance.setOlcaDevAmt(Double.parseDouble(dtoobject.getValue("OLCA_DEV_AMT")));
				OlcamdInstance.setOlcaAmtQualfr(stringToChar(dtoobject.getValue("OLCA_AMT_QUALFR")));
				OlcamdInstance.setOlcaPriceTerms(dtoobject.getValue("OLCA_PRICE_TERMS"));
				// OlcamdInstance.setOlcaLastDateOfNeg(DateToYYYYMMDD(dtoobject.getValue("OLCA_LAST_DATE_OF_NEG")));
				if (!dtoobj.getValue("OLCA_LAST_DATE_OF_NEG").trim().equals("") || !dtoobj.getValue("OLCA_LAST_DATE_OF_NEG").trim().equals(""))
					OlcamdInstance.setOlcaLastDateOfNeg(DateToYYYYMMDD(dtoobj.getValue("OLCA_LAST_DATE_OF_NEG")));
				else
					OlcamdInstance.setOlcaLastDateOfNeg(null);
				OlcamdInstance.setOlcaPlaceOfExpiry(dtoobject.getValue("OLCA_PLACE_OF_EXPIRY"));
				if (dtoobj.getValue("OLCA_LATEST_DATE_OF_SHPMNT") != null)
					OlcamdInstance.setOlcaLatestDateOfShpmnt(DateToYYYYMMDD(dtoobj.getValue("OLCA_LATEST_DATE_OF_SHPMNT")));
				else
					OlcamdInstance.setOlcaLatestDateOfShpmnt(null);
				// OlcamdInstance.setOlcaLatestDateOfShpmnt(DateToYYYYMMDD(dtoobject.getValue("OLCA_LATEST_DATE_OF_SHPMNT")));
				OlcamdInstance.setOlcaWithinValidateLc(stringToChar(dtoobject.getValue("OLCA_WITHIN_VALIDATE_LC")));
				OlcamdInstance.setOlcaLcUiBorneByApplcnt(stringToChar(dtoobject.getValue("OLCA_LC_UI_BORNE_BY_APPLCNT")));
				OlcamdInstance.setOlcaNofTenors(Integer.parseInt(dtoobject.getValue("OLCA_NOF_TENORS")));
				OlcamdInstance.setOlcaAddLiabLcCurr(Double.parseDouble(dtoobject.getValue("OLCA_ADD_LIAB_LC_CURR")));
				OlcamdInstance.setOlcaConvRateBaseCurr(Double.parseDouble(dtoobject.getValue("OLCA_CONV_RATE_BASE_CURR")));
				OlcamdInstance.setOlcaAddLiabBaseCurr(Double.parseDouble(dtoobject.getValue("OLCA_ADD_LIAB_BASE_CURR")));
				OlcamdInstance.setOlcaConvRateLimCurr(Double.parseDouble(dtoobject.getValue("OLCA_CONV_RATE_LIM_CURR")));
				OlcamdInstance.setOlcaTotLiabLimCurr(Double.parseDouble(dtoobject.getValue("OLCA_TOT_LIAB_LIM_CURR")));
				OlcamdInstance.setOlcaContraAmt(Double.parseDouble(dtoobject.getValue("OLCA_ADD_LIAB_BASE_CURR")));
				// Changes P.Subramani-Chn-12/04/2008 Beg
				OlcamdInstance.setOlcaUsanceCharges(Double.parseDouble(dtoobject.getValue("USANCE_CHARGES")));
				OlcamdInstance.setOlcaUsnChgTakenDays(Integer.parseInt(dtoobject.getValue("OLCA_USN_CHG_TAKEN_DAYS")));
				OlcamdInstance.setOlcaCommitmentCharges(Double.parseDouble(dtoobject.getValue("COMMITMENT_CHARGES")));
				OlcamdInstance.setOlcaCommitChgTakenDays(Integer.parseInt(dtoobject.getValue("OLCA_COMMIT_CHG_TAKEN_DAYS")));
				// Changes P.Subramani-Chn-12/04/2008 End

				// Changes P.Subramani-Chn-19/08/2008 Beg
				OlcamdInstance.setOlcaTotLiabLcCurr(Double.parseDouble(dtoobject.getValue("OLCA_TOT_LIAB_LC_CURR")));
				OlcamdInstance.setOlcaTotLiabBaseCurr(Double.parseDouble(dtoobject.getValue("OLCA_TOT_LIAB_BASE_CURR")));
				// Changes P.Subramani-Chn-19/08/2008 End

				OlcamdInstance.setTranchgsChgsSl(Long.parseLong(dtoobject.getValue("TRANCHGS_CHGS_SL")));
				OlcamdInstance.setTranstlmntInvNum(Long.parseLong(dtoobject.getValue("TRANSTLMNT_INV_NUM")));
				OlcamdInstance.setPostTranBrn(Integer.parseInt(dtoobject.getValue("POST_TRAN_BRN")));
				OlcamdInstance.setPostTranDate(DateToYYYYMMDD(dtoobject.getValue("POST_TRAN_DATE")));
				OlcamdInstance.setPostTranBatchNum(Integer.parseInt(dtoobject.getValue("POST_TRAN_BATCH_NUM")));
				OlcamdInstance.setOlcaLastmodBy(dtoobject.getValue("OLCA_LASTMOD_BY"));
				OlcamdInstance.setOlcaLastmodOn(DateToYYYYMMDD(dtoobject.getValue("OLCA_LASTMOD_ON")));
				OlcamdInstance.setOlcaRejBy(dtoobject.getValue("OLCA_REJ_BY"));
				OlcamdInstance.setOlcaRejOn(DateToYYYYMMDD(dtoobject.getValue("OLCA_REJ_ON")));
				// NEW FIELDS ADDED BY PRASHANTH ON 08 FEB 2019
				OlcamdInstance.setOlcaChgInDescGoods(stringToChar(dtoobject.getValue("OLCA_CHG_IN_DESC_GOODS")));
				OlcamdInstance.setOlcaChgInDoc(stringToChar(dtoobject.getValue("OLCA_CHG_IN_DOC")));
				OlcamdInstance.setOlcaChgInAddlCond(stringToChar(dtoobject.getValue("OLCA_CHG_IN_ADDL_COND")));
				// NEW FIELDS ADDED BY PRASHANTH ON 08 FEB 2019

				// NEW FIELDS ADDED BY PRASHANTH ON 21 FEB 2019
				OlcamdInstance.setOlcaReqForCancel(stringToChar(dtoobject.getValue("OLCA_REQ_FOR_CANCEL")));
				OlcamdInstance.setOlcaChgOfAppl(stringToChar(dtoobject.getValue("OLCA_CHG_OF_APPL")));
				OlcamdInstance.setOlcaChgInAvlWith(stringToChar(dtoobject.getValue("OLCA_CHG_IN_AVL_WITH")));
				OlcamdInstance.setOlcaChgInDraweePay(stringToChar(dtoobject.getValue("OLCA_CHG_IN_DRAWEE_PAY")));
				//Changes Sanjay 02-07-2019 Begin
				OlcamdInstance.setOlcaAmdChgPayBy(stringToChar(dtoobject.getValue("OLCA_AMD_CHG_PAY_BY")));
				OlcamdInstance.setOlcaPerOfPresDays((dtoobject.getValue("OLCA_PER_OF_PRES_DAYS")));
				//Changes Sanjay 02-07-2019 End
				OlcamdInstance.setOlcaChgInReimb(stringToChar(dtoobject.getValue("OLCA_CHG_IN_REIMB")));
				OlcamdInstance.setOlcaChgInAdvBk(stringToChar(dtoobject.getValue("OLCA_CHG_IN_ADV_BK")));

				OlcamdInstance.setOlcaChgInFormOfDc(stringToChar(dtoobject.getValue("OLCA_CHG_IN_FORM_OF_DC")));
				OlcamdInstance.setOlcaChgInApplRules(stringToChar(dtoobject.getValue("OLCA_CHG_IN_APPL_RULES")));
				// NEW FIELDS ADDED BY PRASHANTH ON 21 FEB 2019

				Set_Entd_Dtls(OlcamdInstance);
				OlcamdInstance.setIsNew(false);
				OlcamdManagerInstance.save(OlcamdInstance, TBAAUTH_MAIN_PK, TBAAUTH_ENTRY_DATE, TBAAUTH_DTL_SL);
			}
		} catch (Exception e) {
			throw new PanaceaException(e.getLocalizedMessage());
		}
	}

	// OLCLED Updation

	private void addOLCLED(DTObject dtoobject) throws PanaceaException {
		try {
			Olcled OlcledInstance = new Olcled();
			OlcledManager OlcledManagerInstance = new OlcledManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);
			OlcledInstance.setOlcldBrnCode(Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")));
			OlcledInstance.setOlcldLcType(dtoobject.getValue("OLCA_LC_TYPE"));
			OlcledInstance.setOlcldLcYear(Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")));
			OlcledInstance.setOlcldLcSl(Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")));
			OlcledInstance.setOlcldTxnDate(DateToYYYYMMDD(dtoobject.getValue("OLCLD_TXN_DATE")));
			OlcledInstance.setOlcldTxnType(stringToChar("A"));
			OlcledInstance.setOlcldTxnSl(Integer.parseInt(dtoobject.getValue("OLCA_AMD_SL")));
			OlcledInstance.setOlcldRedEnh(stringToChar(dtoobject.getValue("OLCLD_RED_ENH")));
			OlcledInstance.setOlcldTxnAmt(Double.parseDouble(dtoobject.getValue("OLCLD_TXN_AMT")));
			OlcledInstance.setOlcldSourceKey("");
			OlcledInstance.setIsNew(true);
			OlcledManagerInstance.save(OlcledInstance, TBAAUTH_MAIN_PK, TBAAUTH_ENTRY_DATE, TBAAUTH_DTL_SL);
		}

		catch (Exception e) {
			throw new PanaceaException(e.getLocalizedMessage());
		}
	}

	private void modOLCLED(DTObject dtoobject) throws PanaceaException {
		try {
			Olcled OlcledInstance;
			OlcledManager OlcledManagerInstance = new OlcledManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);
			OlcledInstance = OlcledManagerInstance.loadByKey(Integer.parseInt(dtoobj.getValue("OLCA_BRN_CODE")), Integer.parseInt(dtoobj.getValue("OLCA_LC_SL")), dtoobj.getValue("OLCA_LC_TYPE"), Integer.parseInt(dtoobj.getValue("OLCA_LC_YEAR")), DateToYYYYMMDD(dtoobj.getValue("OLCLD_TXN_DATE")), Integer.parseInt(dtoobj.getValue("OLCST_TXN_SL")), stringToChar(dtoobj.getValue("OLCST_TEXT_TYPE")));

			if (OlcledInstance != null) {
				OlcledInstance.setOlcldBrnCode(Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")));
				OlcledInstance.setOlcldLcType(dtoobject.getValue("OLCA_LC_TYPE"));
				OlcledInstance.setOlcldLcYear(Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")));
				OlcledInstance.setOlcldLcSl(Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")));
				OlcledInstance.setOlcldTxnDate(DateToYYYYMMDD(dtoobject.getValue("OLCLD_TXN_DATE")));
				OlcledInstance.setOlcldTxnType(stringToChar("A"));
				OlcledInstance.setOlcldTxnSl(Integer.parseInt(dtoobject.getValue("OLCA_AMD_SL")));
				OlcledInstance.setOlcldRedEnh(stringToChar(dtoobject.getValue("OLCLD_RED_ENH")));
				OlcledInstance.setOlcldTxnAmt(Double.parseDouble(dtoobject.getValue("OLCLD_TXN_AMT")));
				OlcledInstance.setOlcldSourceKey("");
				OlcledInstance.setIsNew(false);
				OlcledManagerInstance.save(OlcledInstance, TBAAUTH_MAIN_PK, TBAAUTH_ENTRY_DATE, TBAAUTH_DTL_SL);
			}
		} catch (Exception e) {
			throw new PanaceaException(e.getLocalizedMessage());
		}
	}

	// OLCLED Ends

	// OLCSHIPTEXT Updation Begins

	private void addOLCSHIPTEXT1(DTObject dtoobject) throws PanaceaException {
		try {
			Olcshiptext OlcshiptextInstance = new Olcshiptext();
			OlcshiptextManager OlcshiptextManagerInstance = new OlcshiptextManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);
			OlcshiptextInstance.setOlcstBrnCode(Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")));
			OlcshiptextInstance.setOlcstLcType(dtoobject.getValue("OLCA_LC_TYPE"));
			OlcshiptextInstance.setOlcstLcYear(Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")));
			OlcshiptextInstance.setOlcstLcSl(Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")));
			OlcshiptextInstance.setOlcstTxnType(stringToChar("A"));
			OlcshiptextInstance.setOlcstTxnSl(1);
			OlcshiptextInstance.setOlcstTextType("SH");
			OlcshiptextInstance.setOlcstText1(dtoobject.getValue("OLCST_TEXT11"));
			OlcshiptextInstance.setOlcstText2(dtoobject.getValue("OLCST_TEXT21"));
			OlcshiptextInstance.setOlcstText3(dtoobject.getValue("OLCST_TEXT31"));
			OlcshiptextInstance.setOlcstText4(dtoobject.getValue("OLCST_TEXT41"));
			OlcshiptextInstance.setIsNew(true);
			OlcshiptextManagerInstance.save(OlcshiptextInstance, TBAAUTH_MAIN_PK, TBAAUTH_ENTRY_DATE, TBAAUTH_DTL_SL);

		}

		catch (Exception e) {
			throw new PanaceaException(e.getLocalizedMessage());
		}
	}

	private void addOLCSHIPTEXT2(DTObject dtoobject) throws PanaceaException {
		try {
			Olcshiptext OlcshiptextInstance = new Olcshiptext();
			OlcshiptextManager OlcshiptextManagerInstance = new OlcshiptextManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);
			OlcshiptextInstance.setOlcstBrnCode(Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")));
			OlcshiptextInstance.setOlcstLcType(dtoobject.getValue("OLCA_LC_TYPE"));
			OlcshiptextInstance.setOlcstLcYear(Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")));
			OlcshiptextInstance.setOlcstLcSl(Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")));
			OlcshiptextInstance.setOlcstTxnType(stringToChar("A"));
			OlcshiptextInstance.setOlcstTxnSl(1);
			OlcshiptextInstance.setOlcstTextType("PD");
			OlcshiptextInstance.setOlcstText1(dtoobject.getValue("OLCST_TEXT12"));
			OlcshiptextInstance.setOlcstText2(dtoobject.getValue("OLCST_TEXT22"));
			OlcshiptextInstance.setOlcstText3(dtoobject.getValue("OLCST_TEXT32"));
			OlcshiptextInstance.setOlcstText4(dtoobject.getValue("OLCST_TEXT42"));
			OlcshiptextInstance.setIsNew(true);
			OlcshiptextManagerInstance.save(OlcshiptextInstance, TBAAUTH_MAIN_PK, TBAAUTH_ENTRY_DATE, TBAAUTH_DTL_SL);

		}

		catch (Exception e) {
			throw new PanaceaException(e.getLocalizedMessage());
		}
	}

	private void modOLCSHIPTEXT1(DTObject dtoobject) throws PanaceaException {
		try {
			Olcshiptext OlcshiptextInstance;
			OlcshiptextManager OlcshiptextManagerInstance = new OlcshiptextManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);
			OlcshiptextInstance = OlcshiptextManagerInstance.loadByKey(Integer.parseInt(dtoobj.getValue("OLCA_BRN_CODE")), Integer.parseInt(dtoobj.getValue("OLCA_LC_SL")), dtoobj.getValue("OLCA_LC_TYPE"), Integer.parseInt(dtoobj.getValue("OLCA_LC_YEAR")), "SH", 1, stringToChar("A"));
			if (OlcshiptextInstance != null) {
				OlcshiptextInstance.setOlcstBrnCode(Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")));
				OlcshiptextInstance.setOlcstLcType(dtoobject.getValue("OLCA_LC_TYPE"));
				OlcshiptextInstance.setOlcstLcYear(Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")));
				OlcshiptextInstance.setOlcstLcSl(Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")));
				OlcshiptextInstance.setOlcstTxnType(stringToChar("A"));
				OlcshiptextInstance.setOlcstTxnSl(1);
				OlcshiptextInstance.setOlcstTextType("SH");
				OlcshiptextInstance.setOlcstText1(dtoobject.getValue("OLCST_TEXT11"));
				OlcshiptextInstance.setOlcstText2(dtoobject.getValue("OLCST_TEXT21"));
				OlcshiptextInstance.setOlcstText3(dtoobject.getValue("OLCST_TEXT31"));
				OlcshiptextInstance.setOlcstText4(dtoobject.getValue("OLCST_TEXT41"));
				OlcshiptextInstance.setIsNew(false);
				OlcshiptextManagerInstance.save(OlcshiptextInstance, TBAAUTH_MAIN_PK, TBAAUTH_ENTRY_DATE, TBAAUTH_DTL_SL);
			}
		} catch (Exception e) {
			throw new PanaceaException(e.getLocalizedMessage());
		}
	}

	private void modOLCSHIPTEXT2(DTObject dtoobject) throws PanaceaException {
		try {
			Olcshiptext OlcshiptextInstance;
			OlcshiptextManager OlcshiptextManagerInstance = new OlcshiptextManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);
			OlcshiptextInstance = OlcshiptextManagerInstance.loadByKey(Integer.parseInt(dtoobj.getValue("OLCA_BRN_CODE")), Integer.parseInt(dtoobj.getValue("OLCA_LC_SL")), dtoobj.getValue("OLCA_LC_TYPE"), Integer.parseInt(dtoobj.getValue("OLCA_LC_YEAR")), "PD", 1, stringToChar("A"));
			if (OlcshiptextInstance != null) {
				OlcshiptextInstance.setOlcstBrnCode(Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")));
				OlcshiptextInstance.setOlcstLcType(dtoobject.getValue("OLCA_LC_TYPE"));
				OlcshiptextInstance.setOlcstLcYear(Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")));
				OlcshiptextInstance.setOlcstLcSl(Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")));
				OlcshiptextInstance.setOlcstTxnType(stringToChar("A"));
				OlcshiptextInstance.setOlcstTxnSl(1);
				OlcshiptextInstance.setOlcstTextType("PD");
				OlcshiptextInstance.setOlcstText1(dtoobject.getValue("OLCST_TEXT12"));
				OlcshiptextInstance.setOlcstText2(dtoobject.getValue("OLCST_TEXT22"));
				OlcshiptextInstance.setOlcstText3(dtoobject.getValue("OLCST_TEXT32"));
				OlcshiptextInstance.setOlcstText4(dtoobject.getValue("OLCST_TEXT42"));
				OlcshiptextInstance.setIsNew(false);
				OlcshiptextManagerInstance.save(OlcshiptextInstance, TBAAUTH_MAIN_PK, TBAAUTH_ENTRY_DATE, TBAAUTH_DTL_SL);
			}
		} catch (Exception e) {
			throw new PanaceaException(e.getLocalizedMessage());
		}
	}

	// OLCSHIPTEXT Updation Ends

	// OLCOTEXT Updation Begins

	private void addOLCOTEXT(DTObject dtoobject) throws PanaceaException {
		try {
			Olcotext OlcotextInstance = new Olcotext();
			OlcotextManager OlcotextManagerInstance = new OlcotextManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);
			OlcotextInstance.setOlcotxBrnCode(Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")));
			OlcotextInstance.setOlcotxLcType(dtoobject.getValue("OLCA_LC_TYPE"));
			OlcotextInstance.setOlcotxLcYear(Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")));
			OlcotextInstance.setOlcotxLcSl(Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")));
			OlcotextInstance.setOlcotxTxnType(stringToChar(dtoobject.getValue("OLCOTX_TXN_TYPE")));
			OlcotextInstance.setOlcotxTxnSl(Integer.parseInt(dtoobject.getValue("OLCOTX_TXN_SL")));
			OlcotextInstance.setOlcotxAddtnlAmtCvrd1(dtoobject.getValue("OLCOTX_ADDTNL_AMT_CVRD1"));
			OlcotextInstance.setOlcotxAddtnlAmtCvrd2(dtoobject.getValue("OLCOTX_ADDTNL_AMT_CVRD2"));
			OlcotextInstance.setOlcotxAddtnlAmtCvrd3(dtoobject.getValue("OLCOTX_ADDTNL_AMT_CVRD3"));
			OlcotextInstance.setOlcotxAddtnlAmtCvrd4(dtoobject.getValue("OLCOTX_ADDTNL_AMT_CVRD4"));
			OlcotextInstance.setIsNew(true);
			OlcotextManagerInstance.save(OlcotextInstance, TBAAUTH_MAIN_PK, TBAAUTH_ENTRY_DATE, TBAAUTH_DTL_SL);

		}

		catch (Exception e) {
			throw new PanaceaException(e.getLocalizedMessage());
		}
	}

	private void modOLCOTEXT(DTObject dtoobject) throws PanaceaException {
		try {
			Olcotext OlcotextInstance;
			OlcotextManager OlcotextManagerInstance = new OlcotextManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);
			OlcotextInstance = OlcotextManagerInstance.loadByKey(Integer.parseInt(dtoobj.getValue("OLCA_BRN_CODE")), Integer.parseInt(dtoobj.getValue("OLCA_LC_SL")), dtoobj.getValue("OLCA_LC_TYPE"), Integer.parseInt(dtoobj.getValue("OLCA_LC_YEAR")), Integer.parseInt(dtoobj.getValue("OLCOTX_TXN_SL")), stringToChar(dtoobj.getValue("OLCOTX_TXN_TYPE")));
			if (OlcotextInstance != null) {
				OlcotextInstance.setOlcotxBrnCode(Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")));
				OlcotextInstance.setOlcotxLcType(dtoobject.getValue("OLCA_LC_TYPE"));
				OlcotextInstance.setOlcotxLcYear(Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")));
				OlcotextInstance.setOlcotxLcSl(Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")));
				OlcotextInstance.setOlcotxTxnType(stringToChar(dtoobject.getValue("OLCOTX_TXN_TYPE")));
				OlcotextInstance.setOlcotxTxnSl(Integer.parseInt(dtoobject.getValue("OLCOTX_TXN_SL")));
				OlcotextInstance.setOlcotxAddtnlAmtCvrd1(dtoobject.getValue("OLCOTX_ADDTNL_AMT_CVRD1"));
				OlcotextInstance.setOlcotxAddtnlAmtCvrd2(dtoobject.getValue("OLCOTX_ADDTNL_AMT_CVRD2"));
				OlcotextInstance.setOlcotxAddtnlAmtCvrd3(dtoobject.getValue("OLCOTX_ADDTNL_AMT_CVRD3"));
				OlcotextInstance.setOlcotxAddtnlAmtCvrd4(dtoobject.getValue("OLCOTX_ADDTNL_AMT_CVRD4"));
				OlcotextInstance.setIsNew(false);
				OlcotextManagerInstance.save(OlcotextInstance, TBAAUTH_MAIN_PK, TBAAUTH_ENTRY_DATE, TBAAUTH_DTL_SL);
			}
		} catch (Exception e) {
			throw new PanaceaException(e.getLocalizedMessage());
		}
	}

	// OLCTENORSAMD Updation Starts
	private void addOLCTENORSAMD(DTObject dtoobject) throws PanaceaException {
		try {

			Olctenorsamd OlctenorsamdInstance = new Olctenorsamd();
			OlctenorsamdManager OlctenorsamdManagerInstance = new OlctenorsamdManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);
			Integer xmltempRowCount = new Integer(dtoobject.getDTDObject("valeolcamdOLCTENORS").getRowCount());
			/*
			 * if(tba_auth_queue_req == false) { deleteolctenor(dtoobject); }
			 */
			for (int i = 0; i < xmltempRowCount.intValue(); i++) {
				String space = " ";
				OlctenorsamdInstance.setOlctaBrnCode(Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")));
				OlctenorsamdInstance.setOlctaLcType(dtoobject.getValue("OLCA_LC_TYPE"));
				OlctenorsamdInstance.setOlctaLcYear(Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")));
				OlctenorsamdInstance.setOlctaLcSl(Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")));
				OlctenorsamdInstance.setOlctaAmdSl(Integer.parseInt(dtoobject.getValue("OLCA_AMD_SL")));
				OlctenorsamdInstance.setOlctaTenorSl(i + 1);

				if (dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 0).equalsIgnoreCase("")) {
					OlctenorsamdInstance.setOlctaTenorType(stringToChar(space));
				} else {
					OlctenorsamdInstance.setOlctaTenorType(stringToChar(dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 0)));
				}
				// Changes P.Subramani-Chn-22/08/2008 Beg
				if (dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 1).equalsIgnoreCase("")) {
					OlctenorsamdInstance.setOlctaPrevTenorAmt(0);
				} else {
					OlctenorsamdInstance.setOlctaPrevTenorAmt(Double.parseDouble(dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 1)));
				}
				// Changes P.Subramani-Chn-22/08/2008 End
				if (dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 2).equalsIgnoreCase("")) {
					OlctenorsamdInstance.setOlctaTenorAmt(0);
				} else {
					OlctenorsamdInstance.setOlctaTenorAmt(Double.parseDouble(dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 2)));
				}
				if (dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 3).equalsIgnoreCase("")) {
					OlctenorsamdInstance.setOlctaUsancePerd(0);
				} else {
					OlctenorsamdInstance.setOlctaUsancePerd(Integer.parseInt(dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 3)));
				}
				if (dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 4).equalsIgnoreCase("")) {
					OlctenorsamdInstance.setOlctaUsanceFrom(stringToChar(space));
				} else {
					OlctenorsamdInstance.setOlctaUsanceFrom(stringToChar(dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 4)));
				}
				if (dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 5).equalsIgnoreCase("")) {
					OlctenorsamdInstance.setOlctaOtherDateDesc(space);
				} else {
					OlctenorsamdInstance.setOlctaOtherDateDesc(dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 5));
				}
				if (dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 6).equalsIgnoreCase("")) {
					OlctenorsamdInstance.setOlctaOtherDateStartFrom(null);
				} else {
					OlctenorsamdInstance.setOlctaOtherDateStartFrom(DateToYYYYMMDD(dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 6)));
				}
				OlctenorsamdInstance.setOlctaUsanceIntRate(Double.parseDouble(dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 7)));

				// Changes P.Subramani-Chn-22/08/2008 Beg
				OlctenorsamdInstance.setOlctaPrevUsanceInt(Double.parseDouble(dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 8)));
				// Changes P.Subramani-Chn-22/08/2008 End
				OlctenorsamdInstance.setOlctaUsanceIntAmt(Double.parseDouble(dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 9)));
				OlctenorsamdInstance.setOlctaDocDelivery(stringToChar(dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 10)));
				// Changes P.Subramani-Chn-25/08/2008 BEg
				if (dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 12).equalsIgnoreCase("")) {
					OlctenorsamdInstance.setOlctaUsnChrgTakenDays(0);
				} else {
					OlctenorsamdInstance.setOlctaUsnChrgTakenDays(Integer.parseInt(dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 12)));
				}

				if (Option.equalsIgnoreCase("A")) {// latest tot_tenor_liab
					// present in olctenors for
					// the serial,tenorserial
					// wise.
					String qstr = "SELECT OLCT_TOT_TENOR_LIAB  FROM OLCTENORS WHERE OLCT_BRN_CODE=? AND OLCT_LC_TYPE=? AND OLCT_LC_YEAR=? AND OLCT_LC_SL=? AND OLCT_TENOR_SL=? ";
					try {
						Connection _conn = null;
						_conn = openConnection();
						PreparedStatement _pstmt = _conn.prepareStatement(qstr);
						_pstmt.setInt(1, Integer.parseInt(_branchCode));
						_pstmt.setString(2, _lcType);
						_pstmt.setInt(3, Integer.parseInt(_lcYear));
						_pstmt.setInt(4, Integer.parseInt(_lcSl));
						_pstmt.setInt(5, i + 1);
						ResultSet rs = _pstmt.executeQuery();
						if (rs.next()) {
							_PrevCommAmt = rs.getDouble("OLCT_TOT_TENOR_LIAB");
							System.out.println(_PrevCommAmt);
						}
					} catch (Exception e) {
						throw new PanaceaException(e.getLocalizedMessage());
					}

					OlctenorsamdInstance.setOlctaPrevAmtForComm(_PrevCommAmt);
				}

				// Changes P.Subramani-Chn-25/08/2008 End
				OlctenorsamdInstance.setIsNew(true);
				OlctenorsamdManagerInstance.save(OlctenorsamdInstance, TBAAUTH_MAIN_PK, TBAAUTH_ENTRY_DATE, TBAAUTH_DTL_SL);
			}
		} catch (Exception e) {
			throw new PanaceaException(e.getLocalizedMessage());
		}
	}

	private void modOLCTENORSAMD(DTObject dtoobject) throws PanaceaException {
		try {
			String space = " ";
			Olctenorsamd OlctenorsamdInstance;
			OlctenorsamdManager OlctenorsamdManagerInstance = new OlctenorsamdManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);
			Integer xmltempRowCount = new Integer(dtoobject.getDTDObject("valeolcamdOLCTENORS").getRowCount());
			for (int i = 0; i < xmltempRowCount.intValue(); i++) {
				OlctenorsamdInstance = OlctenorsamdManagerInstance.loadByKey(Integer.parseInt(_amdSerial), Integer.parseInt(_branchCode), Integer.parseInt(_lcSl), _lcType, Integer.parseInt(_lcYear), i + 1);
				if (OlctenorsamdInstance != null) {
					if (dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 0).equalsIgnoreCase("")) {
						OlctenorsamdInstance.setOlctaTenorType(stringToChar(space));
					} else {
						OlctenorsamdInstance.setOlctaTenorType(stringToChar(dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 0)));
					}
					// Changes P.Subramani-Chn-22/08/2008 Beg
					if (dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 1).equalsIgnoreCase("")) {
						OlctenorsamdInstance.setOlctaPrevTenorAmt(0);
					} else {
						OlctenorsamdInstance.setOlctaPrevTenorAmt(Double.parseDouble(dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 1)));
					}
					// Changes P.Subramani-Chn-22/08/2008 End
					if (dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 2).equalsIgnoreCase("")) {
						OlctenorsamdInstance.setOlctaTenorAmt(0);
					} else {
						OlctenorsamdInstance.setOlctaTenorAmt(Double.parseDouble(dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 2)));
					}
					if (dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 3).equalsIgnoreCase("")) {
						OlctenorsamdInstance.setOlctaUsancePerd(0);
					} else {
						OlctenorsamdInstance.setOlctaUsancePerd(Integer.parseInt(dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 3)));
					}
					if (dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 4).equalsIgnoreCase("")) {
						OlctenorsamdInstance.setOlctaUsanceFrom(stringToChar(space));
					} else {
						OlctenorsamdInstance.setOlctaUsanceFrom(stringToChar(dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 4)));
					}
					if (dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 5).equalsIgnoreCase("")) {
						OlctenorsamdInstance.setOlctaOtherDateDesc(space);
					} else {
						OlctenorsamdInstance.setOlctaOtherDateDesc(dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 5));
					}
					if (dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 6).equalsIgnoreCase("")) {
						OlctenorsamdInstance.setOlctaOtherDateStartFrom(null);
					} else {
						OlctenorsamdInstance.setOlctaOtherDateStartFrom(DateToYYYYMMDD(dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 6)));
					}
					OlctenorsamdInstance.setOlctaUsanceIntRate(Double.parseDouble(dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 7)));

					// Changes P.Subramani-Chn-22/08/2008 Beg
					OlctenorsamdInstance.setOlctaPrevUsanceInt(Double.parseDouble(dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 8)));
					// Changes P.Subramani-Chn-22/08/2008 End
					OlctenorsamdInstance.setOlctaUsanceIntAmt(Double.parseDouble(dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 9)));
					OlctenorsamdInstance.setOlctaDocDelivery(stringToChar(dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 10)));
					// Changes P.Subramani-Chn-25/08/2008 BEg
					if (dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 12).equalsIgnoreCase("")) {
						OlctenorsamdInstance.setOlctaUsnChrgTakenDays(0);
					} else {
						OlctenorsamdInstance.setOlctaUsnChrgTakenDays(Integer.parseInt(dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 12)));
					}

					// Changes P.Subramani-Chn-25/08/2008 End
					OlctenorsamdInstance.setIsNew(false);
					OlctenorsamdManagerInstance.save(OlctenorsamdInstance, TBAAUTH_MAIN_PK, TBAAUTH_ENTRY_DATE, TBAAUTH_DTL_SL);
				}
			}
		} catch (Exception e) {
			throw new PanaceaException(e.getLocalizedMessage());
		}
	}

	/*
	 * private void deleteolctenor(DTObject dtoobject) throws PanaceaException {
	 * try{ String w_Sql; OlctenorsamdManager OlctenorsManagerInstance = new
	 * OlctenorsamdManager(_COLLECTIONObj,V_LOG_REQ,V_ADD_LOG_REQ); w_Sql =
	 * "DELETE FROM OLCTENORSAMD WHERE OLCTA_BRN_CODE='" +
	 * Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE"))+"' AND
	 * OLCTA_LC_TYPE ='" +dtoobject.getValue("OLCA_LC_TYPE")+"' AND
	 * OLCTA_LC_YEAR='" +
	 * Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR"))+"' AND
	 * OLCTA_LC_SL='" + Integer.parseInt(dtoobject.getValue("OLCA_LC_SL"))+"'
	 * AND OLCTA_AMD_SL='" +
	 * Integer.parseInt(dtoobject.getValue("OLCA_AMD_SL"))+"'";
	 * OlctenorsManagerInstance.deleteByQuery(w_Sql); } catch(Exception e) {
	 * throw new PanaceaException(e.getLocalizedMessage()); } }
	 */

	// OLCTENORSAMD Updation Ends
	// Changes P.Subramani-Chn-25/08/2008 Beg
	// OLCTENORS Updation Starts
	// Latest TotLiab for tenorwise is in OLCTENORS
	private void addOLCTENORS(DTObject dtoobject) throws PanaceaException {
		try {
			Olctenors OlctenorsInstance = new Olctenors();
			OlctenorsManager OlctenorsManagerInstance = new OlctenorsManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);
			Integer xmltempRowCount = new Integer(dtoobject.getDTDObject("valeolcamdOLCTENORS").getRowCount());
			for (int i = 0; i < xmltempRowCount.intValue(); i++) {
				String space = " ";
				OlctenorsInstance.setOlctBrnCode(Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")));
				OlctenorsInstance.setOlctLcType(dtoobject.getValue("OLCA_LC_TYPE"));
				OlctenorsInstance.setOlctLcYear(Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")));
				OlctenorsInstance.setOlctLcSl(Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")));
				OlctenorsInstance.setOlctTenorSl(i + 1);

				double tamt = Double.parseDouble(dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 2));
				double intamt = Double.parseDouble(dtoobject.getDTDObject("valeolcamdOLCTENORS", i, 9));
				double lcamt = Double.parseDouble(dtoobject.getValue("OLCA_AMENDED_AMT"));
				double devamt = Double.parseDouble(dtoobject.getValue("OLCA_DEV_AMT"));
				double res = tamt + ((devamt / lcamt) * tamt) + intamt;

				OlctenorsInstance.setOlctTotTenorLiab(res);
				OlctenorsInstance.setIsNew(false);
				OlctenorsManagerInstance.save(OlctenorsInstance, TBAAUTH_MAIN_PK, TBAAUTH_ENTRY_DATE, TBAAUTH_DTL_SL);
			}
		} catch (Exception e) {
			throw new PanaceaException(e.getLocalizedMessage());
		}
	}

	// Changes P.Subramani-Chn-25/08/2008 End

	// Settlement Components Starts
	public void Set_Tran_Settlement_values() throws PanaceaException {
		try {
			TranstlmntBO Transtlmntobj = new TranstlmntBO();
			Transtlmntobj.setSourceTable(dtoobj.getValue("TranStl_SOURCE_TABLE"));
			Transtlmntobj.setSourceKey(_sourceKey);
			Transtlmntobj.setSourceTable("OLCAMD");
			Transtlmntobj.setTba_main_key(TBAAUTH_MAIN_PK);
			Transtlmntobj.setTba_entry_date(TBAAUTH_ENTRY_DATE);
			Transtlmntobj.setTab_dtl_sl(TBAAUTH_DTL_SL);
			dtoobj.setValue("TranStl_SOURCE_KEY", _sourceKey);
			Transtlmntobj.updateValues(dtoobj);
			// Move_Transtlmnt_Values(Transtlmntobj.getTransactionRecords(),Transtlmntobj.getTransactionBatchRecord());
			if (dtoobj.getValue("UserOption").equalsIgnoreCase("A")) {
				String update_q = "UPDATE OLCAMD SET TRANSTLMNT_INV_NUM=" + Transtlmntobj.getInventoryNumber() + " WHERE  OLCA_BRN_CODE='" + Integer.parseInt(dtoobj.getValue("OLCA_BRN_CODE")) + "' AND  OLCA_LC_TYPE='" + dtoobj.getValue("OLCA_LC_TYPE") + "' AND OLCA_LC_YEAR='" + Integer.parseInt(dtoobj.getValue("OLCA_LC_YEAR")) + "' AND OLCA_LC_SL ='" + Integer.parseInt(dtoobj.getValue("OLCA_LC_SL")) + "' AND OLCA_AMD_SL ='" + Integer.parseInt(dtoobj.getValue("OLCA_AMD_SL")) + "'";
				new OlcamdManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ).UpdateByQuery(update_q);
			}
		} catch (Exception e) {
			throw new PanaceaException(e.getLocalizedMessage());
		}
	}

	// Settlement Components Ends

	// Updation of Procedure Starts
	private void UpdateProcedure(DTObject dtoobj) throws PanaceaException {
		try {
			if (Option.equalsIgnoreCase("A")) {
				if (!_redFlag.equalsIgnoreCase("")) {
					UpdateProcedureOLCBALANCEADD();
				}
			} else {
				if ((!_redFlag.equalsIgnoreCase("")) && (!_prevRedFlag.equalsIgnoreCase(""))) {
					UpdateProcedureOLCBALANCEMOD();
				}
			}
			PrevTenorAmt = _prevTenorAmt.split("&");
			TotalLiabAmt = _totalLiabAmt.split("&");
			BalTenor = _olcBalTenAmt.split("&");
			BalUsanceAmt = _olcBalUsaInt.split("&");
			// Changes P.Subramani-Chn22/08/2008 Beg
			for (_Wi = 0; _Wi < _noOfDrawDowns; _Wi++) {
				if (Double.parseDouble(dtoobj.getDTDObject("valeolcamdOLCTENORS", _Wi, 2)) > Double.parseDouble(dtoobj.getDTDObject("valeolcamdOLCTENORS", _Wi, 1))) {
					_EnhancedAmt = Double.parseDouble(dtoobj.getDTDObject("valeolcamdOLCTENORS", _Wi, 2)) - Double.parseDouble(dtoobj.getDTDObject("valeolcamdOLCTENORS", _Wi, 1));
					_ReductionAmt = 0;
				} else {
					_EnhancedAmt = 0;
					_ReductionAmt = Double.parseDouble(dtoobj.getDTDObject("valeolcamdOLCTENORS", _Wi, 1)) - Double.parseDouble(dtoobj.getDTDObject("valeolcamdOLCTENORS", _Wi, 2));
				}
				// SUGANYA BEGIN 23-09-2016
				if (!dtoobj.getDTDObject("valeolcamdOLCTENORS", _Wi, 11).equalsIgnoreCase("")) {
					// SUGANYA END 23-09-2016
					if (Double.parseDouble(dtoobj.getDTDObject("valeolcamdOLCTENORS", _Wi, 11)) > 0) {
						_Prev_EnhancedAmt = Double.parseDouble(dtoobj.getDTDObject("valeolcamdOLCTENORS", _Wi, 11));
						_Prev_ReductionAmt = 0;
					} else if (Double.parseDouble(dtoobj.getDTDObject("valeolcamdOLCTENORS", _Wi, 11)) < 0) {
						_Prev_EnhancedAmt = 0;
						_Prev_ReductionAmt = Math.abs(Double.parseDouble(dtoobj.getDTDObject("valeolcamdOLCTENORS", _Wi, 11)));
					}
				}// SUGANYA ON 23-09-2016
				UpdateOLCTenorBalance();
			}
			// Changes P.Subramani-Chn22/08/2008 End

			for (_Wi = 0; _Wi < _noOfDrawDowns; _Wi++) {
				UpdateOLCUSANCEBalance();
				// Removed P.Subramani-Chn-27/08/2008
				// UpdateOLCTenorLiab();
			}
		} catch (Exception e) {
			throw new PanaceaException(e.getLocalizedMessage());
		}
	}

	public void UpdateProcedureOLCBALANCEADD() throws PanaceaException {
		try {

			Connection _conn = null;
			CallableStatement _cstmt = null;
			_conn = openConnection();
			_cstmt = _conn.prepareCall("CALL SP_UPDATEOLCBAL(?,?,?,?,?,?,?,?,?)");
			_cstmt.setInt(1, Integer.parseInt(_branchCode));
			_cstmt.setString(2, _lcType);
			_cstmt.setInt(3, Integer.parseInt(_lcYear));
			_cstmt.setInt(4, Integer.parseInt(_lcSl));
			_cstmt.setString(5, _redFlag);
			_cstmt.setDouble(6, Double.parseDouble(_redAmt));
			_cstmt.setInt(7, 0);
			_cstmt.setInt(8, 0);
			_cstmt.registerOutParameter(9, Types.VARCHAR);
			_cstmt.execute();

			String error_msg = _cstmt.getString(9);

		} catch (Exception e) {
			throw new PanaceaException(e.getLocalizedMessage());
		}

	}

	public void UpdateProcedureOLCBALANCEMOD() throws PanaceaException {
		try {

			Connection _conn = null;
			CallableStatement _cstmt = null;
			_conn = openConnection();
			_cstmt = _conn.prepareCall("CALL SP_UPDATEOLCBAL(?,?,?,?,?,?,?,?,?)");
			_cstmt.setInt(1, Integer.parseInt(_branchCode));
			_cstmt.setString(2, _lcType);
			_cstmt.setInt(3, Integer.parseInt(_lcYear));
			_cstmt.setInt(4, Integer.parseInt(_lcSl));
			_cstmt.setString(5, _redFlag);
			_cstmt.setDouble(6, Double.parseDouble(_redAmt));
			_cstmt.setString(7, _prevRedFlag);
			_cstmt.setDouble(8, Double.parseDouble(_prevRedAmt));
			_cstmt.registerOutParameter(9, Types.VARCHAR);
			_cstmt.execute();

			String error_msg = _cstmt.getString(9);

		} catch (Exception e) {
			throw new PanaceaException(e.getLocalizedMessage());
		}

	}

	public void UpdateOLCTenorBalance() throws PanaceaException {
		try {
			Connection _conn = null;
			CallableStatement _cstmt = null;
			_conn = openConnection();
			_cstmt = _conn.prepareCall("CALL SP_UPDATEOLCTENORBAL(?,?,?,?,?,?,?,?,?,?)");
			_cstmt.setInt(1, Integer.parseInt(_branchCode));
			_cstmt.setString(2, _lcType);
			_cstmt.setInt(3, Integer.parseInt(_lcYear));
			_cstmt.setInt(4, Integer.parseInt(_lcSl));
			_cstmt.setInt(5, (_Wi + 1));
			// Changes P.Subramani-Chn-22/08/2008 Beg
			_cstmt.setDouble(6, _EnhancedAmt);
			_cstmt.setDouble(7, _Prev_EnhancedAmt);
			_cstmt.setDouble(8, _ReductionAmt);
			_cstmt.setDouble(9, _Prev_ReductionAmt);
			// Changes P.Subramani-Chn-22/08/2008 End
			_cstmt.registerOutParameter(10, Types.VARCHAR);
			_cstmt.execute();

			String error_msg = _cstmt.getString(10);
		}

		catch (Exception e) {
			throw new PanaceaException(e.getLocalizedMessage());
		}

	}

	public void UpdateOLCUSANCEBalance() throws PanaceaException {
		try {
			Connection _conn = null;
			CallableStatement _cstmt = null;
			_conn = openConnection();
			_cstmt = _conn.prepareCall("CALL SP_UPDATEOLCUSANCEBAL(?,?,?,?,?,?,?,?)");
			_cstmt.setInt(1, Integer.parseInt(_branchCode));
			_cstmt.setString(2, _lcType);
			_cstmt.setInt(3, Integer.parseInt(_lcYear));
			_cstmt.setInt(4, Integer.parseInt(_lcSl));
			_cstmt.setInt(5, (_Wi + 1));
			_cstmt.setDouble(6, Double.parseDouble(dtoobj.getDTDObject("valeolcamdOLCTENORS", _Wi, 8)));// previous
			// usance
			// intamt
			_cstmt.setDouble(7, Double.parseDouble(dtoobj.getDTDObject("valeolcamdOLCTENORS", _Wi, 9)));// usance
			// intamt
			_cstmt.registerOutParameter(8, Types.VARCHAR);
			_cstmt.execute();

			String error_msg = _cstmt.getString(8);
		}

		catch (Exception e) {
			throw new PanaceaException(e.getLocalizedMessage());
		}
	}

	public void UpdateOLCTenorLiab() throws PanaceaException {
		// Calculation of Current Tenor Total

		CurrentDeviation = (Double.parseDouble(_olcBal) * Double.parseDouble(dtoobj.getDTDObject("valeolcamdOLCTENORS", _Wi, 8))) / Double.parseDouble(_olcAMT);
		_currTotalAmt = Double.parseDouble(BalTenor[_Wi].trim()) + Double.parseDouble(BalUsanceAmt[_Wi].trim()) + CurrentDeviation;

		try {
			Connection _conn = null;
			CallableStatement _cstmt = null;
			_conn = openConnection();
			_cstmt = _conn.prepareCall("CALL SP_UPDATEOLCTENORLIAB(?,?,?,?,?,?,?,?,?)");
			_cstmt.setInt(1, Integer.parseInt(_branchCode));
			_cstmt.setString(2, _lcType);
			_cstmt.setInt(3, Integer.parseInt(_lcYear));
			_cstmt.setInt(4, Integer.parseInt(_lcSl));
			_cstmt.setInt(5, (_Wi + 1));
			_cstmt.setString(6, "E");
			_cstmt.setString(7, TotalLiabAmt[_Wi].trim());
			_cstmt.setDouble(8, _currTotalAmt);
			_cstmt.registerOutParameter(9, Types.VARCHAR);
			_cstmt.execute();

			String error_msg = _cstmt.getString(9);
		}

		catch (Exception e) {
			throw new PanaceaException(e.getLocalizedMessage());
		}
	}

	// Changes P.Subramani-Chn26/08/2008 Beg
	private void UpdateOLCDevBal(DTObject dtoobject) throws PanaceaException {
		try {
			Olc OlcInstance = new Olc();
			OlcManager OlcManagerInstance = new OlcManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);
			OlcInstance.setOlcBrnCode(Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")));
			OlcInstance.setOlcLcType(dtoobject.getValue("OLCA_LC_TYPE"));
			OlcInstance.setOlcLcYear(Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")));
			OlcInstance.setOlcLcSl(Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")));

			String qstr = "SELECT OLC_DEV_BAL FROM OLC WHERE OLC_BRN_CODE=? AND OLC_LC_TYPE=? AND OLC_LC_YEAR=? AND OLC_LC_SL=?  ";
			try {
				Connection _conn = null;
				_conn = openConnection();
				PreparedStatement _pstmt = _conn.prepareStatement(qstr);
				_pstmt.setInt(1, Integer.parseInt(_branchCode));
				_pstmt.setString(2, _lcType);
				_pstmt.setInt(3, Integer.parseInt(_lcYear));
				_pstmt.setInt(4, Integer.parseInt(_lcSl));
				ResultSet rs = _pstmt.executeQuery();
				if (rs.next()) {
					_olc_devbal = rs.getDouble("OLC_DEV_BAL");
				}
			} catch (Exception e) {
				throw new PanaceaException(e.getLocalizedMessage());
			}

			Resdevbal = (_olc_devbal) + (Double.parseDouble(dtoobject.getValue("OLCA_DEV_AMT"))) - (Double.parseDouble(dtoobject.getValue("PREV_DEV_AMT")));
			OlcInstance.setOlcDevBal(Resdevbal);

			OlcInstance.setIsNew(false);
			OlcManagerInstance.save(OlcInstance, TBAAUTH_MAIN_PK, TBAAUTH_ENTRY_DATE, TBAAUTH_DTL_SL);
		} catch (Exception e) {
			throw new PanaceaException(e.getLocalizedMessage());
		}
	}

	// Changes P.Subramani-Chn26/08/2008 End

	// Changes P.Subramani-Chn-21/10/2008 Beg
	private void UpdateOLCMarginBal(DTObject dtoobject) throws PanaceaException {
		try {
			Olc OlcInstance = new Olc();
			OlcManager OlcManagerInstance = new OlcManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);
			OlcInstance.setOlcBrnCode(Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")));
			OlcInstance.setOlcLcType(dtoobject.getValue("OLCA_LC_TYPE"));
			OlcInstance.setOlcLcYear(Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")));
			OlcInstance.setOlcLcSl(Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")));

			OlcInstance.setOlcMarginAmt(Double.parseDouble(dtoobject.getValue("OLC_MARGIN_AMT")));
			OlcInstance.setOlcMarginBal(Double.parseDouble(dtoobject.getValue("OLC_MARGIN_BAL")));
			OlcInstance.setOlcCashMarAmt(Double.parseDouble(dtoobject.getValue("OLC_CASH_MAR_AMT")));
			OlcInstance.setOlcCashMarBal(Double.parseDouble(dtoobject.getValue("OLC_CASH_MAR_BAL")));

			OlcInstance.setIsNew(false);
			OlcManagerInstance.save(OlcInstance, TBAAUTH_MAIN_PK, TBAAUTH_ENTRY_DATE, TBAAUTH_DTL_SL);
		} catch (Exception e) {
			throw new PanaceaException(e.getLocalizedMessage());
		}
	}

	// Changes P.Subramani-Chn-21/10/2008 End

	// Updation of Procedure Ends

	private void posting_Transaction(DTObject InputmapObj) throws PanaceaException {
		System.out.println(" Posting Started...");
		Begin_Posting();
		Set_Tran_Key_Values(InputmapObj);
		Set_Tranbat_Values();
		Set_Tran_Values();
		// Changes P.Subramani-Chn-23-06-2008 Beg
		Set_Tran_Values1();
		Set_Tran_Values2();
		if (usancechgs > 0.0) {
			set_CREDIT_CONTRA_VOUCHER_USANCE();
		}
		if (commchgs > 0.0) {
			set_CREDIT_CONTRA_VOUCHER_COMMITMENT();
		}
		// Changes P.Subramani-Chn-23-06-2008 End
		// M.Murali - Changes - 18-05-2012 - Beg
		// if(Double.parseDouble(totalAmt)>0)
		if (Double.parseDouble(totalAmt) > 0 || (usancechgs) > 0 || (commchgs) > 0)
		// M.Murali - Changes - 18-05-2012 - End
		{
			DEBIT_VOUCHER(InputmapObj);
			chargeStax(InputmapObj);
		}
		Post_Transaction();
		System.out.println(" SuccessFully Completed Posting ");
	}

	public void Set_Tran_Key_Values(DTObject InputmapObj) {
		System.out.println(" I am in Posting Component");
		if (Option.equalsIgnoreCase("A")) {

			// CHANGED ADDED ON 25/07/2018 START
			if (Integer.parseInt(_brnAuth) > 0 && Integer.parseInt(_brnAuthLCType) > 0) {
				trankey.set_TRAN_BRN_CODE(Integer.parseInt(userBrnCode));
			} else {
				trankey.set_TRAN_BRN_CODE(Integer.parseInt(_branchCode));
			}
			// CHANGED ADDED ON 25/07/2018 END

			trankey.set_TRAN_DATE_OF_TRAN(_CBD);
			trankey.set_TRAN_BATCH_NUMBER(0);
			trankey.set_TRAN_BATCH_SL_NUM(0);
			trankey.set_User_Option("A");
			System.out.println("SuccessFully: Set_Tran_Key_Values for Add Mode");
		}

		else {
			// CHANGED ADDED ON 25/07/2018 START
			if (Integer.parseInt(_brnAuth) > 0 && Integer.parseInt(_brnAuthLCType) > 0) {
				trankey.set_TRAN_BRN_CODE(Integer.parseInt(userBrnCode));
			} else {
				trankey.set_TRAN_BRN_CODE(Integer.parseInt(postBrn));
			}
			// CHANGED ADDED ON 25/07/2018 END

			trankey.set_TRAN_DATE_OF_TRAN(postDate);
			trankey.set_TRAN_BATCH_NUMBER(Integer.parseInt(postBatchNum));
			trankey.set_TRAN_BATCH_SL_NUM(0);
			trankey.set_User_Option("M");
			System.out.println("SuccessFully: Set_Tran_Key_Values for Modify Mode");
		}
	}

	public void Set_Tranbat_Values() {
		tranbatrec.setTranbatSourceTable("OLCAMD");
		tranbatrec.setTranbatSourceKey(_sourceKey);
		tranbatrec.setTranbatNarrDtl1("Import LC Amendment Issue");
		tranbatrec.setTranbatNarrDtl2(corrRefNum);
		tranbatrec.set_auto_authorise(false);
	}

	public void Set_Tran_Values() throws PanaceaException {
		String qstr = "SELECT TRAC_COLL_CONTRA_GLACC_CODE FROM TRACPARAM WHERE TRAC_NOMEN_CODE=?";
		try {
			Connection _conn = null;
			_conn = openConnection();
			PreparedStatement _pstmt = _conn.prepareStatement(qstr);
			_pstmt.setString(1, _lcType);
			ResultSet rs = _pstmt.executeQuery();
			if (rs.next()) {
				contra_Glacc_Code = rs.getString("TRAC_COLL_CONTRA_GLACC_CODE");
			}

			// Changes P.Subramani-Chn-02/04/2008 Beg
			if (Double.parseDouble(contactAmt) > 0) {
				set_DEBIT_CONTRA_VOUCHER();
				set_CREDIT_CONTRA_VOUCHER();
			} else if (Double.parseDouble(redlcliabbaseamt) > 0) {
				set_DEBIT_CONTRA_VOUCHER_1();
				set_CREDIT_CONTRA_VOUCHER_1();
			}
			// Changes P.Subramani-Chn-02/04/2008 End
		} catch (Exception e) {
			throw new PanaceaException(e.getLocalizedMessage());
		}
	}

	// Changes P.Subramani-Chn-23-06-2008 Beg
	public void Set_Tran_Values1() throws PanaceaException {
		Connection _conn = null;
		ResultSet rs = null;
		ResultSet rs1 = null;
		String qstr = "select CHGCD_CR_INCOME_HEAD from chgcd where CHGCD_CHARGE_CODE=?";
		try {

			_conn = openConnection();
			PreparedStatement _pstmt = _conn.prepareStatement(qstr);
			_pstmt.setString(1, usancechgcode);
			rs = _pstmt.executeQuery();

			if (rs.next()) {
				contraGL1 = rs.getString(1);

			}

		} catch (Exception e) {
			throw new PanaceaException(e.getLocalizedMessage());
		} finally {

			try {
				_conn.close();
			} catch (Exception e) {
				throw new PanaceaException(e.getLocalizedMessage());
			}
		}
	}

	public void Set_Tran_Values2() throws PanaceaException {
		Connection _conn = null;
		ResultSet rs = null;
		ResultSet rs1 = null;
		String qstr = "select CHGCD_CR_INCOME_HEAD from chgcd where CHGCD_CHARGE_CODE=?";
		try {

			_conn = openConnection();
			PreparedStatement _pstmt = _conn.prepareStatement(qstr);
			_pstmt.setString(1, commchgcode);
			rs = _pstmt.executeQuery();

			if (rs.next()) {
				contraGL2 = rs.getString(1);

			}

		} catch (Exception e) {
			throw new PanaceaException(e.getLocalizedMessage());
		} finally {

			try {
				_conn.close();
			} catch (Exception e) {
				throw new PanaceaException(e.getLocalizedMessage());
			}
		}
	}

	// Changes P.Subramani-Chn-23-06-2008 End

	public void set_DEBIT_CONTRA_VOUCHER() throws PanaceaException {
		tranRec.setTranAcingBrnCode(Integer.parseInt(_branchCode));
		tranRec.setTranInternalAcnum(Long.parseLong(internalAccNum));
		tranRec.setTranContractNum(0);
		tranRec.setTranDbCrFlg("D");
		tranRec.setTranNarrDtl1("Import LC Amendment Issue");
		tranRec.setTranNarrDtl2(corrRefNum);
		tranRec.setTranAmount(Double.parseDouble(contactAmt));
		tranRec.setTranBaseCurrEqAmt(Double.parseDouble(contactAmt));
		Move_Tran_Values(tranRec);

	}

	public void set_CREDIT_CONTRA_VOUCHER() throws PanaceaException {
		tranRec.setTranAcingBrnCode(Integer.parseInt(_branchCode));
		tranRec.setTranInternalAcnum(0);
		tranRec.setTranContractNum(0);
		tranRec.setTranGlaccCode(contra_Glacc_Code);
		tranRec.setTranCurrCode(baseCurr);
		tranRec.setTranDbCrFlg("C");
		tranRec.setTranNarrDtl1("Import LC Amendment Issue");
		tranRec.setTranNarrDtl2(corrRefNum);
		tranRec.setTranAmount(Double.parseDouble(contactAmt));
		tranRec.setTranBaseCurrEqAmt(Double.parseDouble(contactAmt));
		Move_Tran_Values(tranRec);
	}

	// Changes P.Subramani-Chn-02/04/2008 Beg
	public void set_DEBIT_CONTRA_VOUCHER_1() throws PanaceaException {
		tranRec.setTranAcingBrnCode(Integer.parseInt(_branchCode));
		tranRec.setTranInternalAcnum(Long.parseLong(internalAccNum));
		tranRec.setTranContractNum(0);
		tranRec.setTranDbCrFlg("C");
		tranRec.setTranNarrDtl1("Import LC Amendment Issue");
		tranRec.setTranNarrDtl2(corrRefNum);
		tranRec.setTranAmount(Double.parseDouble(redlcliabbaseamt));
		tranRec.setTranBaseCurrEqAmt(Double.parseDouble(redlcliabbaseamt));
		Move_Tran_Values(tranRec);

	}

	public void set_CREDIT_CONTRA_VOUCHER_1() throws PanaceaException {
		tranRec.setTranAcingBrnCode(Integer.parseInt(_branchCode));
		tranRec.setTranInternalAcnum(0);
		tranRec.setTranContractNum(0);
		tranRec.setTranGlaccCode(contra_Glacc_Code);
		tranRec.setTranCurrCode(baseCurr);
		tranRec.setTranDbCrFlg("D");
		tranRec.setTranNarrDtl1("Import LC Amendment Issue");
		tranRec.setTranNarrDtl2(corrRefNum);
		tranRec.setTranAmount(Double.parseDouble(redlcliabbaseamt));
		tranRec.setTranBaseCurrEqAmt(Double.parseDouble(redlcliabbaseamt));
		Move_Tran_Values(tranRec);
	}

	// Changes P.Subramani-Chn-02/04/2008 End

	// Changes P.Subramani-23-06-2008 Beg
	public void set_CREDIT_CONTRA_VOUCHER_USANCE() throws PanaceaException {
		tranRec.setTranAcingBrnCode(Integer.parseInt(_branchCode));
		tranRec.setTranInternalAcnum(0);
		tranRec.setTranContractNum(0);
		tranRec.setTranGlaccCode(contraGL1);
		tranRec.setTranCurrCode(baseCurr);
		tranRec.setTranDbCrFlg("C");
		tranRec.setTranNarrDtl1("Import LC Amendment Issue");
		tranRec.setTranNarrDtl2(corrRefNum);
		tranRec.setTranAmount(usancechgs);
		tranRec.setTranBaseCurrEqAmt(usancechgs);
		Move_Tran_Values(tranRec);
	}

	public void set_CREDIT_CONTRA_VOUCHER_COMMITMENT() throws PanaceaException {
		tranRec.setTranAcingBrnCode(Integer.parseInt(_branchCode));
		tranRec.setTranInternalAcnum(0);
		tranRec.setTranContractNum(0);
		tranRec.setTranGlaccCode(contraGL2);
		tranRec.setTranCurrCode(baseCurr);
		tranRec.setTranDbCrFlg("C");
		tranRec.setTranNarrDtl1("Import LC Amendment Issue");
		tranRec.setTranNarrDtl2(corrRefNum);
		tranRec.setTranAmount(commchgs);
		tranRec.setTranBaseCurrEqAmt(commchgs);
		Move_Tran_Values(tranRec);
	}

	// Changes P.Subramani-Chn-23-06-2008 End

	public void DEBIT_VOUCHER(DTObject InputmapObj) throws PanaceaException {
		TranstlmntBO Transtlmntobj = new TranstlmntBO();
		Transtlmntobj.setSourceTable(dtoobj.getValue("TranStl_SOURCE_TABLE"));
		Transtlmntobj.setSourceKey(_sourceKey);
		Transtlmntobj.setTba_main_key(TBAAUTH_MAIN_PK);
		Transtlmntobj.setTba_entry_date(TBAAUTH_ENTRY_DATE);
		Transtlmntobj.setTab_dtl_sl(TBAAUTH_DTL_SL);
		dtoobj.setValue("TranStl_SOURCE_KEY", _sourceKey);
		Transtlmntobj.updateValues(dtoobj);
		Move_Transtlmnt_Values(Transtlmntobj.getTransactionRecords(), Transtlmntobj.getTransactionBatchRecord());
		updateInvNum(Transtlmntobj.getInventoryNumber());
	}

	public void chargeStax(DTObject InputmapObj) throws PanaceaException {
		chargeStax chargestax = new chargeStax();
		for (int i = 0; i < InputmapObj.getDTDObject("TRANCHGS").getRowCount(); i++) {
			// Vinoth.S Changes on 28-Jan-2011 Beg
			// if((Double.parseDouble(InputmapObj.getDTDObject("TRANCHGS",i,"TRANCHGS_ACT_CHGS"))
			// > 0)||Removed
			if ((Double.parseDouble(InputmapObj.getDTDObject("TRANCHGS", i, "TRANCHGS_CHGAMT_REC_CURR")) > 0) ||
			// Vinoth.S Changes on 28-Jan-2011 End
					(Double.parseDouble(InputmapObj.getDTDObject("TRANCHGS", i, "TRANCHGS_STAX_REC_CURR"))) > 0) {
				chargestax.set_chargeStaxBrnCode(Integer.parseInt(_branchCode));
				chargestax.set_chargeStaxChrgCode(InputmapObj.getDTDObject("TRANCHGS", i, "TRANCHGS_CHG_CODE"));
				chargestax.set_chargeStaxChrgCurr(InputmapObj.getDTDObject("TRANCHGS", i, "TRANCHGS_CHG_CURR"));
				// Vinoth.S Changes on 28-Jan-2011 for Round Off Changes Beg
				// chargestax.set_chargeStaxTotChrgAmt(Double.parseDouble(InputmapObj.getDTDObject("TRANCHGS",i,"TRANCHGS_ACT_CHGS")));
				chargestax.set_chargeStaxTotChrgAmt(Double.parseDouble(InputmapObj.getDTDObject("TRANCHGS", i, "TRANCHGS_CHGAMT_REC_CURR")));
				// Vinoth.S Changes on 28-Jan-2011 End
				chargestax.set_chargeStaxTotSvrChrgAmt(Double.parseDouble(InputmapObj.getDTDObject("TRANCHGS", i, "TRANCHGS_STAX_REC_CURR")));
				Move_Charge_Values(chargestax.post_CmnChrg_SrvChrg());
			}
		}
	}

	private void updateInvNum(long _invNum) throws PanaceaException {
		try {
			String update_q = "UPDATE OLCAMD SET TRANSTLMNT_INV_NUM=" + _invNum + " WHERE  OLCA_BRN_CODE='" + Integer.parseInt(dtoobj.getValue("OLCA_BRN_CODE")) + "' AND  OLCA_LC_TYPE='" + dtoobj.getValue("OLCA_LC_TYPE") + "' AND OLCA_LC_YEAR='" + Integer.parseInt(dtoobj.getValue("OLCA_LC_YEAR")) + "' AND OLCA_LC_SL ='" + Integer.parseInt(dtoobj.getValue("OLCA_LC_SL")) + "' AND OLCA_AMD_SL ='" + Integer.parseInt(dtoobj.getValue("OLCA_AMD_SL")) + "'";
			new OlcamdManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ).UpdateByQuery(update_q);
		} catch (Exception e) {
			throw new PanaceaException(e.getLocalizedMessage());
		}
	}

	private void AddOlcMar(DTObject dtoobject) throws PanaceaException {
		try {
			Olcmar OlcmarInstance = new Olcmar();
			OlcmarManager OlcmarManagerInstance = new OlcmarManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);
			maxSl = String.valueOf(OlcmarManagerInstance.GetMaxSl(Integer.parseInt(dtoobj.getValue("OLCA_BRN_CODE")), Integer.parseInt(dtoobj.getValue("OLCA_LC_SL")), dtoobj.getValue("OLCA_LC_TYPE"), Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")), stringToChar(olcotexttype)));
			OlcmarInstance.setOlcmBrnCode(Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")));
			OlcmarInstance.setOlcmLcType(dtoobject.getValue("OLCA_LC_TYPE"));
			OlcmarInstance.setOlcmLcYear(Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")));
			OlcmarInstance.setOlcmLcSl(Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")));
			OlcmarInstance.setOlcmTxnType(stringToChar(olcotexttype));
			OlcmarInstance.setOlcmTxnSl(Integer.parseInt(maxSl));
			OlcmarInstance.setOlcmMarginCurr(dtoobject.getValue("MARGIN_CURR"));
			OlcmarInstance.setOlcmMarginPerc(Double.parseDouble(dtoobject.getValue("MARGIN_PER")));
			OlcmarInstance.setOlcmExOverLimitMarginPerc(Double.parseDouble(dtoobject.getValue("EOL_MARGIN_PER")));
			OlcmarInstance.setOlcmMarginAmt(Double.parseDouble(dtoobject.getValue("MARGIN_AMT")));
			OlcmarInstance.setOlcmExOverLimitMarginAmt(Double.parseDouble(dtoobject.getValue("EOL_MARGIN_AMT")));
			OlcmarInstance.setOlcmCashMarginAmt(Double.parseDouble(dtoobject.getValue("CASH_MARGIN")));
			OlcmarInstance.setOlcmEolCashMarginAmt(Double.parseDouble(dtoobject.getValue("EOL_CASH_MARGIN")));
			OlcmarInstance.setOlcmMarginType(stringToChar(dtoobject.getValue("MARGIN_TYPE")));
			OlcmarInstance.setOlcmExOverLimit(Double.parseDouble(dtoobject.getValue("EXCESS_LIMIT")));
			OlcmarInstance.setIsNew(true);
			OlcmarManagerInstance.save(OlcmarInstance, TBAAUTH_MAIN_PK, TBAAUTH_ENTRY_DATE, TBAAUTH_DTL_SL);

		} catch (Exception e) {
			throw new PanaceaException(e.getLocalizedMessage());
		}
	}

	private void ModOlcMar(DTObject dtoobject) throws PanaceaException {
		try {
			Olcmar OlcmarInstance;
			OlcmarManager OlcmarManagerInstance = new OlcmarManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);
			maxSl = String.valueOf(OlcmarManagerInstance.GetMaxSl(Integer.parseInt(dtoobj.getValue("OLCA_BRN_CODE")), Integer.parseInt(dtoobj.getValue("OLCA_LC_SL")), dtoobj.getValue("OLCA_LC_TYPE"), Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")), stringToChar(olcotexttype)));
			OlcmarInstance = OlcmarManagerInstance.loadByKey(Integer.parseInt(dtoobj.getValue("OLCA_BRN_CODE")), Integer.parseInt(dtoobj.getValue("OLCA_LC_SL")), dtoobj.getValue("OLCA_LC_TYPE"), Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")), Integer.parseInt(maxSl) - 1, stringToChar(olcotexttype));
			if (OlcmarInstance != null) {
				OlcmarInstance.setOlcmMarginCurr(dtoobject.getValue("MARGIN_CURR"));
				OlcmarInstance.setOlcmMarginPerc(Double.parseDouble(dtoobject.getValue("MARGIN_PER")));
				OlcmarInstance.setOlcmExOverLimitMarginPerc(Double.parseDouble(dtoobject.getValue("EOL_MARGIN_PER")));
				OlcmarInstance.setOlcmMarginAmt(Double.parseDouble(dtoobject.getValue("MARGIN_AMT")));
				OlcmarInstance.setOlcmExOverLimitMarginAmt(Double.parseDouble(dtoobject.getValue("EOL_MARGIN_AMT")));
				OlcmarInstance.setOlcmCashMarginAmt(Double.parseDouble(dtoobject.getValue("CASH_MARGIN")));
				OlcmarInstance.setOlcmEolCashMarginAmt(Double.parseDouble(dtoobject.getValue("EOL_CASH_MARGIN")));
				OlcmarInstance.setOlcmMarginType(stringToChar(dtoobject.getValue("MARGIN_TYPE")));
				OlcmarInstance.setOlcmExOverLimit(Double.parseDouble(dtoobject.getValue("EXCESS_LIMIT")));
				OlcmarInstance.setIsNew(false);

				OlcmarManagerInstance.save(OlcmarInstance, TBAAUTH_MAIN_PK, TBAAUTH_ENTRY_DATE, TBAAUTH_DTL_SL);
			}
		} catch (Exception e) {
			throw new PanaceaException(e.getLocalizedMessage());
		}
	}

	// Chnages in EOLCAMD on 16-Oct-2018 start
	private void AddSwiftAmendLcDetails(DTObject dtoobject) throws PanaceaException {
		try {
			AmendDetails AmenddetailsInstance = new AmendDetails();
			AmendDetailsManager AmendManagerInstance = new AmendDetailsManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);
			AmenddetailsInstance.setAmendLcBrnCode(Integer.parseInt(dtoobj.getValue("OLCA_BRN_CODE")));
			AmenddetailsInstance.setAmendLcType(dtoobj.getValue("OLCA_LC_TYPE"));
			AmenddetailsInstance.setAmendLcYear(Integer.parseInt(dtoobj.getValue("OLCA_LC_YEAR")));
			AmenddetailsInstance.setAmendLcSerial(Integer.parseInt(dtoobj.getValue("OLCA_LC_SL")));
			AmenddetailsInstance.setAmendLcAmdSl(Integer.parseInt(dtoobj.getValue("OLCA_AMD_SL")));
			AmenddetailsInstance.setAmendSndrRef(dtoobj.getValue("AMEND_SNDR_REF"));
			AmenddetailsInstance.setAmendRcvrRef(dtoobj.getValue("AMEND_RCVR_REF"));
			AmenddetailsInstance.setAmendDocCrNum(dtoobj.getValue("AMEND_DOC_CR_NUM"));
			AmenddetailsInstance.setAmendIssueRef(dtoobj.getValue("AMEND_ISSUE_REF"));
			AmenddetailsInstance.setAmendIssuingBnkReq(stringToChar(dtoobj.getValue("AMEND_ISSUING_BNK_REQ")));
			AmenddetailsInstance.setAmendIssuingType(stringToChar(dtoobj.getValue("AMEND_ISSUING_TYPE")));
			AmenddetailsInstance.setAmendIssuingBicCode(dtoobj.getValue("AMEND_ISSUING_BIC_CODE"));
			AmenddetailsInstance.setAmendIssuingBrnCode(dtoobj.getValue("AMEND_ISSUING_BRN_CODE"));
			AmenddetailsInstance.setAmendIssuingBnkCode(dtoobj.getValue("AMEND_ISSUING_BNK_CODE"));
			AmenddetailsInstance.setAmendIssuingRoutid(dtoobj.getValue("AMEND_ISSUING_ROUTID"));
			AmenddetailsInstance.setAmendIssuingAddr1(dtoobj.getValue("AMEND_ISSUING_ADDR1"));
			AmenddetailsInstance.setAmendIssuingAddr2(dtoobj.getValue("AMEND_ISSUING_ADDR2"));
			AmenddetailsInstance.setAmendIssuingAddr3(dtoobj.getValue("AMEND_ISSUING_ADDR3"));
			AmenddetailsInstance.setAmendIssuingAddr4(dtoobj.getValue("AMEND_ISSUING_ADDR4"));
			AmenddetailsInstance.setAmendIssuingAddr5(dtoobj.getValue("AMEND_ISSUING_ADDR5"));
			AmenddetailsInstance.setAmendIssuingCntry(dtoobj.getValue("AMEND_ISSUING_CNTRY"));
			AmenddetailsInstance.setAmendNonBnkIssur(dtoobj.getValue("AMEND_NON_BNK_ISSUR"));
			AmenddetailsInstance.setAmendDateOfIssue(DateToYYYYMMDD(dtoobj.getValue("AMEND_DATE_OF_ISSUE")));
			AmenddetailsInstance.setAmendDateOfAmendment(DateToYYYYMMDD(dtoobj.getValue("AMEND_DATE_OF_AMENDMENT")));
			AmenddetailsInstance.setAmendPurposeOfMsg(stringToChar(dtoobj.getValue("AMEND_PURPOSE_OF_MSG")));
			AmenddetailsInstance.setAmendCancelRequest(dtoobj.getValue("AMEND_CANCEL_REQUEST"));
			AmenddetailsInstance.setAmendAdvisingBnkReq(stringToChar(dtoobj.getValue("AMEND_ADVISING_BNK_REQ")));
			AmenddetailsInstance.setAmendAdvisingBnkType(stringToChar(dtoobj.getValue("AMEND_ADVISING_BNK_TYPE")));
			AmenddetailsInstance.setAmendAdvisingBrnCode(dtoobj.getValue("AMEND_ADVISING_BRN_CODE"));
			AmenddetailsInstance.setAmendAdvisingBicCode(dtoobj.getValue("AMEND_ADVISING_BIC_CODE"));
			AmenddetailsInstance.setAmendAdvisingRoutid(dtoobj.getValue("AMEND_ADVISING_ROUTID"));
			AmenddetailsInstance.setAmendAdvisingBnkCode(dtoobj.getValue("AMEND_ADVISING_BNK_CODE"));
			AmenddetailsInstance.setAmendAdvisingAddr1(dtoobj.getValue("AMEND_ADVISING_ADDR1"));
			AmenddetailsInstance.setAmendAdvisingAddr2(dtoobj.getValue("AMEND_ADVISING_ADDR2"));
			AmenddetailsInstance.setAmendAdvisingAddr3(dtoobj.getValue("AMEND_ADVISING_ADDR3"));
			AmenddetailsInstance.setAmendAdvisingAddr4(dtoobj.getValue("AMEND_ADVISING_ADDR4"));
			AmenddetailsInstance.setAmendAdvisingAddr5(dtoobj.getValue("AMEND_ADVISING_ADDR5"));
			AmenddetailsInstance.setAmendSecondAdvReq(stringToChar(dtoobj.getValue("AMEND_SECOND_ADV_REQ")));
			AmenddetailsInstance.setAmendSecondAdvType(stringToChar(dtoobj.getValue("AMEND_SECOND_ADV_TYPE")));
			AmenddetailsInstance.setAmendSecondAdvBrnCode(dtoobj.getValue("AMEND_SECOND_ADV_BRN_CODE"));
			AmenddetailsInstance.setAmendSecondAdvBicCode(dtoobj.getValue("AMEND_SECOND_ADV_BIC_CODE"));
			AmenddetailsInstance.setAmendSecondAdvRoutid(dtoobj.getValue("AMEND_SECOND_ADV_ROUTID"));
			AmenddetailsInstance.setAmendSecondAdvBnkCode(dtoobj.getValue("AMEND_SECOND_ADV_BNK_CODE"));
			AmenddetailsInstance.setAmendSecondAdvAddr1(dtoobj.getValue("AMEND_SECOND_ADV_ADDR1"));
			AmenddetailsInstance.setAmendSecondAdvAddr2(dtoobj.getValue("AMEND_SECOND_ADV_ADDR2"));
			AmenddetailsInstance.setAmendSecondAdvAddr3(dtoobj.getValue("AMEND_SECOND_ADV_ADDR3"));
			AmenddetailsInstance.setAmendSecondAdvAddr4(dtoobj.getValue("AMEND_SECOND_ADV_ADDR4"));
			AmenddetailsInstance.setAmendSecondAdvAddr5(dtoobj.getValue("AMEND_SECOND_ADV_ADDR5"));
			AmenddetailsInstance.setAmendNewBeneficiary(dtoobj.getValue("AMEND_NEW_BENEFICIARY"));
			if (dtoobj.getValue("AMEND_NEW_DATE_OF_EXPIRY") != null && !dtoobj.getValue("AMEND_NEW_DATE_OF_EXPIRY").trim().equals(""))
				AmenddetailsInstance.setAmendNewDateOfExpiry(DateToYYYYMMDD(dtoobj.getValue("AMEND_NEW_DATE_OF_EXPIRY")));
			else
				AmenddetailsInstance.setAmendNewDateOfExpiry(null);
			AmenddetailsInstance.setAmendIncrDocCrAmt(Double.parseDouble(dtoobj.getValue("AMEND_INCR_DOC_CR_AMT")));
			AmenddetailsInstance.setAmendDecrDocCrAmt(Double.parseDouble(dtoobj.getValue("AMEND_DECR_DOC_CR_AMT")));
			AmenddetailsInstance.setAmendNewAddnlAmt(Double.parseDouble(dtoobj.getValue("AMEND_NEW_ADDNL_AMT")));
			AmenddetailsInstance.setAmendPlaceTakinInChrg(dtoobj.getValue("AMEND_PLACE_TAKIN_IN_CHRG"));
			AmenddetailsInstance.setAmendPortOfLoading(dtoobj.getValue("AMEND_PORT_OF_LOADING"));
			AmenddetailsInstance.setAmendPortOfDischarge(dtoobj.getValue("AMEND_PORT_OF_DISCHARGE"));
			AmenddetailsInstance.setAmendPlaceOfFinalDest(dtoobj.getValue("AMEND_PLACE_OF_FINAL_DEST"));
			if (dtoobj.getValue("AMEND_DATE_OF_SHIPMENT") != null)
				AmenddetailsInstance.setAmendDateOfShipment(DateToYYYYMMDD(dtoobj.getValue("AMEND_DATE_OF_SHIPMENT")));
			else
				AmenddetailsInstance.setAmendDateOfShipment(null);
			AmenddetailsInstance.setAmendDescGoddSer1(dtoobj.getValue("AMEND_DESC_GODD_SER1"));
			AmenddetailsInstance.setAmendDocReq1(dtoobj.getValue("AMEND_DOC_REQ1"));
			AmenddetailsInstance.setAmendAddCondition1(dtoobj.getValue("AMEND_ADD_CONDITION1"));

			// NEW FIELDS ADDED BY PRASHANTH ON 08 FEB 2019
			/*
			 * AmenddetailsInstance.setAmendDescGoddSer2(dtoobj.getValue("AMEND_DESC_GODD_SER2"));
			 * AmenddetailsInstance.setAmendDocReq2(dtoobj.getValue("AMEND_DOC_REQ2"));
			 * AmenddetailsInstance.setAmendAddCondition2(dtoobj.getValue("AMEND_ADD_CONDITION2"));
			 * 
			 * 
			 * AmenddetailsInstance.setAmendDescGoddSer3(dtoobj.getValue("AMEND_DESC_GODD_SER3"));
			 * AmenddetailsInstance.setAmendDocReq3(dtoobj.getValue("AMEND_DOC_REQ3"));
			 * AmenddetailsInstance.setAmendAddCondition3(dtoobj.getValue("AMEND_ADD_CONDITION3"));
			 * //NEW FIELDS ADDED BY PRASHANTH ON 08 FEB 2019
			 */

			AmenddetailsInstance.setAmendChrgPayable1(dtoobj.getValue("AMEND_CHRG_PAYABLE1"));
			AmenddetailsInstance.setAmendChrgPayable2(dtoobj.getValue("AMEND_CHRG_PAYABLE2"));
			AmenddetailsInstance.setAmendChrgPayable3(dtoobj.getValue("AMEND_CHRG_PAYABLE3"));
			AmenddetailsInstance.setAmendChrgPayable4(dtoobj.getValue("AMEND_CHRG_PAYABLE4"));
			AmenddetailsInstance.setAmendChrgPayable5(dtoobj.getValue("AMEND_CHRG_PAYABLE5"));
			AmenddetailsInstance.setAmendChrgPayable6(dtoobj.getValue("AMEND_CHRG_PAYABLE6"));
			/*AmenddetailsInstance.setAmendNewPrdPresntDay(dtoobj.getValue("AMEND_NEW_PRD_PRESNT_DAY"));
			AmenddetailsInstance.setAmendNewConfirmInstr(dtoobj.getValue("AMEND_NEW_CONFIRM_INSTR"));
			AmenddetailsInstance.setAmendSplPayBenficiary(dtoobj.getValue("AMEND_SPL_PAY_BENFICIARY"));
			AmenddetailsInstance.setAmendSplPayRecBnk(dtoobj.getValue("AMEND_SPL_PAY_REC_BNK"));
			AmenddetailsInstance.setAmendInstrTopaying1(dtoobj.getValue("AMEND_INSTR_TOPAYING1"));
			AmenddetailsInstance.setAmendInstrTopaying2(dtoobj.getValue("AMEND_INSTR_TOPAYING2"));
			AmenddetailsInstance.setAmendInstrTopaying3(dtoobj.getValue("AMEND_INSTR_TOPAYING3"));
			AmenddetailsInstance.setAmendInstrTopaying4(dtoobj.getValue("AMEND_INSTR_TOPAYING4"));
			AmenddetailsInstance.setAmendInstrTopaying5(dtoobj.getValue("AMEND_INSTR_TOPAYING5"));
			AmenddetailsInstance.setAmendInstrTopaying6(dtoobj.getValue("AMEND_INSTR_TOPAYING6"));
			AmenddetailsInstance.setAmendInstrTopaying7(dtoobj.getValue("AMEND_INSTR_TOPAYING7"));
			AmenddetailsInstance.setAmendInstrTopaying8(dtoobj.getValue("AMEND_INSTR_TOPAYING8"));
			AmenddetailsInstance.setAmendInstrTopaying9(dtoobj.getValue("AMEND_INSTR_TOPAYING9"));
			AmenddetailsInstance.setAmendInstrTopaying10(dtoobj.getValue("AMEND_INSTR_TOPAYING10"));
			AmenddetailsInstance.setAmendInstrTopaying11(dtoobj.getValue("AMEND_INSTR_TOPAYING11"));
			AmenddetailsInstance.setAmendInstrTopaying12(dtoobj.getValue("AMEND_INSTR_TOPAYING12"));
			*/
			AmenddetailsInstance.setAmendSndrRecInfo1(dtoobj.getValue("AMEND_SNDR_REC_INFO1"));
			AmenddetailsInstance.setAmendSndrRecInfo2(dtoobj.getValue("AMEND_SNDR_REC_INFO2"));
			AmenddetailsInstance.setAmendSndrRecInfo3(dtoobj.getValue("AMEND_SNDR_REC_INFO3"));
			AmenddetailsInstance.setAmendSndrRecInfo4(dtoobj.getValue("AMEND_SNDR_REC_INFO4"));
			AmenddetailsInstance.setAmendSndrRecInfo5(dtoobj.getValue("AMEND_SNDR_REC_INFO5"));
			AmenddetailsInstance.setAmendSndrRecInfo6(dtoobj.getValue("AMEND_SNDR_REC_INFO6"));
			//Changes Sanjay1 18-07-2019 Begin
			//AmenddetailsInstance.setAmendNarrative(dtoobj.getValue("AMEND_NARRATIVE"));
			//AmenddetailsInstance.setAmendLcApplicantRules(stringToChar(dtoobject.getValue("AMEND_LC_APPLICANT_RULES")));
			//Changes Sanjay1 18-07-2019 End
			AmenddetailsInstance.setAmendChkbox(dtoobj.getValue("AMEND_CHKBOX"));
			AmenddetailsInstance.setAmendAdvisingCntry(dtoobj.getValue("AMEND_ADVISING_CNTRY"));
			AmenddetailsInstance.setAmendSecondAdvCntry(dtoobj.getValue("AMEND_SECOND_ADV_CNTRY"));
			// AmenddetailsInstance.setAmendIssueRef(dtoobj.getValue("AMEND_SECOND_ADV_CNTRY"));

			// NEW FIELDS ADDED BY PRASHANTH ON 21 FEB 2019
			AmenddetailsInstance.setAmendFormOfDocCredit(Integer.parseInt(dtoobject.getValue("AMEND_FORM_OF_DOC_CREDIT")));
			AmenddetailsInstance.setAmendLcApplicableRules(Integer.parseInt(dtoobject.getValue("AMEND_LC_APPLICABLE_RULES")));
			AmenddetailsInstance.setAmendLcApplicantReq(stringToChar(dtoobject.getValue("AMEND_LC_APPLICANT_REQ")));
			AmenddetailsInstance.setAmendLcApplicantName(dtoobject.getValue("AMEND_LC_APPLICANT_NAME"));
			AmenddetailsInstance.setAmendLcApplicantAddr1(dtoobject.getValue("AMEND_LC_APPLICANT_ADDR1"));
			AmenddetailsInstance.setAmendLcApplicantAddr2(dtoobject.getValue("AMEND_LC_APPLICANT_ADDR2"));
			AmenddetailsInstance.setAmendLcApplicantAddr3(dtoobject.getValue("AMEND_LC_APPLICANT_ADDR3"));
			AmenddetailsInstance.setAmendLcApplicantAddr4(dtoobject.getValue("AMEND_LC_APPLICANT_ADDR4"));
			AmenddetailsInstance.setAmendLcApplicantAddr5(dtoobject.getValue("AMEND_LC_APPLICANT_ADDR5"));
			AmenddetailsInstance.setAmendLcAvlWithType(stringToChar(dtoobject.getValue("AMEND_LC_AVL_WITH_TYPE")));
			//Changes Sanjay1 18-07-2019 Begin
			AmenddetailsInstance.setAmendLcAvlWithBicCode(dtoobject.getValue("AMEND_LC_AVL_WITH_BIC_CODE"));
			//Changes Sanjay1 18-07-2019 End
			AmenddetailsInstance.setAmendLcAvlWithBrnCode(dtoobject.getValue("AMEND_LC_AVL_WITH_BRN_CODE"));
			AmenddetailsInstance.setAmendLcLcAvlWithRoutid(dtoobject.getValue("AMEND_LC_LC_AVL_WITH_ROUTID"));
			AmenddetailsInstance.setAmendLcAvlWithBnkCode(dtoobject.getValue("AMEND_LC_AVL_WITH_BNK_CODE"));
			AmenddetailsInstance.setAmendLcAvlWithAddr1(dtoobject.getValue("AMEND_LC_AVL_WITH_ADDR1"));
			AmenddetailsInstance.setAmendLcAvlWithAddr2(dtoobject.getValue("AMEND_LC_AVL_WITH_ADDR2"));
			AmenddetailsInstance.setAmendLcAvlWithAddr3(dtoobject.getValue("AMEND_LC_AVL_WITH_ADDR3"));
			AmenddetailsInstance.setAmendLcAvlWithAddr4(dtoobject.getValue("AMEND_LC_AVL_WITH_ADDR4"));
			AmenddetailsInstance.setAmendLcAvlWithAddr5(dtoobject.getValue("AMEND_LC_AVL_WITH_ADDR5"));

			//
			AmenddetailsInstance.setAmendLcAvlWithCntry(dtoobject.getValue("AMEND_LC_AVL_WITH_CNTRY"));
			//

			AmenddetailsInstance.setAmendLcDraftsAt1(dtoobject.getValue("AMEND_LC_DRAFTS_AT1"));
			AmenddetailsInstance.setAmendLcDraftsAt2(dtoobject.getValue("AMEND_LC_DRAFTS_AT2"));
			AmenddetailsInstance.setAmendLcDraftsAt3(dtoobject.getValue("AMEND_LC_DRAFTS_AT3"));
			AmenddetailsInstance.setAmendLcDraweeReq(stringToChar(dtoobject.getValue("AMEND_LC_DRAWEE_REQ")));
			AmenddetailsInstance.setAmendLcDraweeType(stringToChar(dtoobject.getValue("AMEND_LC_DRAWEE_TYPE")));
			AmenddetailsInstance.setAmendLcDraweeBrnCode(dtoobject.getValue("AMEND_LC_DRAWEE_BRN_CODE"));
			AmenddetailsInstance.setAmendLcDraweeBicCode(dtoobject.getValue("AMEND_LC_DRAWEE_BIC_CODE"));
			AmenddetailsInstance.setAmendLcDraweeRoutid(dtoobject.getValue("AMEND_LC_DRAWEE_ROUTID"));
			AmenddetailsInstance.setAmendLcDraweeBnkCode(dtoobject.getValue("AMEND_LC_DRAWEE_BNK_CODE"));
			AmenddetailsInstance.setAmendLcDraweeAddr1(dtoobject.getValue("AMEND_LC_DRAWEE_ADDR1"));
			AmenddetailsInstance.setAmendLcDraweeAddr2(dtoobject.getValue("AMEND_LC_DRAWEE_ADDR2"));
			AmenddetailsInstance.setAmendLcDraweeAddr3(dtoobject.getValue("AMEND_LC_DRAWEE_ADDR3"));
			AmenddetailsInstance.setAmendLcDraweeAddr4(dtoobject.getValue("AMEND_LC_DRAWEE_ADDR4"));
			AmenddetailsInstance.setAmendLcDraweeAddr5(dtoobject.getValue("AMEND_LC_DRAWEE_ADDR5"));
			//
			AmenddetailsInstance.setAmendDraweeCntryCode(dtoobject.getValue("AMEND_DRAWEE_CNTRY_CODE"));

			//

			AmenddetailsInstance.setAmendLcMixedPayDetails1(dtoobject.getValue("AMEND_LC_MIXED_PAY_DETAILS1"));
			AmenddetailsInstance.setAmendLcMixedPayDetails2(dtoobject.getValue("AMEND_LC_MIXED_PAY_DETAILS2"));
			AmenddetailsInstance.setAmendLcMixedPayDetails3(dtoobject.getValue("AMEND_LC_MIXED_PAY_DETAILS3"));
			AmenddetailsInstance.setAmendLcMixedPayDetails4(dtoobject.getValue("AMEND_LC_MIXED_PAY_DETAILS4"));
			AmenddetailsInstance.setAmendLcMixedPayDetails5(dtoobject.getValue("AMEND_LC_MIXED_PAY_DETAILS5"));
			AmenddetailsInstance.setAmendLcDeferredPayDetails1(dtoobject.getValue("AMEND_LC_DEFERRED_PAY_DETAILS1"));
			AmenddetailsInstance.setAmendLcDeferredPayDetails2(dtoobject.getValue("AMEND_LC_DEFERRED_PAY_DETAILS2"));
			AmenddetailsInstance.setAmendLcDeferredPayDetails3(dtoobject.getValue("AMEND_LC_DEFERRED_PAY_DETAILS3"));
			AmenddetailsInstance.setAmendLcDeferredPayDetails4(dtoobject.getValue("AMEND_LC_DEFERRED_PAY_DETAILS4"));
			AmenddetailsInstance.setAmendLcDeferredPayDetails5(dtoobject.getValue("AMEND_LC_DEFERRED_PAY_DETAILS5"));
			AmenddetailsInstance.setAmendLcPartialShipments(Integer.parseInt(dtoobject.getValue("AMEND_LC_PARTIAL_SHIPMENTS")));
			AmenddetailsInstance.setAmendLcTranshipment(Integer.parseInt(dtoobject.getValue("AMEND_LC_TRANSHIPMENT")));
			if(!dtoobject.getValue("AMEND_LC_CONFIRMATION_INST").equals("")){
			AmenddetailsInstance.setAmendLcConfirmationInst(Integer.parseInt(dtoobject.getValue("AMEND_LC_CONFIRMATION_INST")));
			}
			//Changes Sanjay1 18-07-2019 Begin
			//AmenddetailsInstance.setAmendLcCnfByBank(dtoobject.getValue("AMEND_LC_CNF_BY_BANK"));
			//AmenddetailsInstance.setAmendLcCnfByBrn(Integer.parseInt(dtoobject.getValue("AMEND_LC_CNF_BY_BRN")));
			//Changes Sanjay1 18-07-2019 End
			AmenddetailsInstance.setAmendLcReimbReq(stringToChar(dtoobject.getValue("AMEND_LC_REIMB_REQ")));
			AmenddetailsInstance.setAmendLcReimbType(stringToChar(dtoobject.getValue("AMEND_LC_REIMB_TYPE")));
			AmenddetailsInstance.setAmendLcReimbBrnCode(dtoobject.getValue("AMEND_LC_REIMB_BRN_CODE"));
			AmenddetailsInstance.setAmendLcReimbBicCode(dtoobject.getValue("AMEND_LC_REIMB_BIC_CODE"));
			AmenddetailsInstance.setAmendLcReimbRoutid(dtoobject.getValue("AMEND_LC_REIMB_ROUTID"));
			AmenddetailsInstance.setAmendLcReimbBnkCode(dtoobject.getValue("AMEND_LC_REIMB_BNK_CODE"));
			AmenddetailsInstance.setAmendLcReimbAddr1(dtoobject.getValue("AMEND_LC_REIMB_ADDR1"));
			AmenddetailsInstance.setAmendLcReimbAddr2(dtoobject.getValue("AMEND_LC_REIMB_ADDR2"));
			AmenddetailsInstance.setAmendLcReimbAddr3(dtoobject.getValue("AMEND_LC_REIMB_ADDR3"));
			AmenddetailsInstance.setAmendLcReimbAddr4(dtoobject.getValue("AMEND_LC_REIMB_ADDR4"));
			AmenddetailsInstance.setAmendLcReimbAddr5(dtoobject.getValue("AMEND_LC_REIMB_ADDR5"));
			AmenddetailsInstance.setAmendLcInstPaying1(dtoobject.getValue("AMEND_LC_INST_PAYING1"));
			AmenddetailsInstance.setAmendLcInstPaying2(dtoobject.getValue("AMEND_LC_INST_PAYING2"));
			AmenddetailsInstance.setAmendLcInstPaying3(dtoobject.getValue("AMEND_LC_INST_PAYING3"));
			AmenddetailsInstance.setAmendLcInstPaying4(dtoobject.getValue("AMEND_LC_INST_PAYING4"));
			AmenddetailsInstance.setAmendLcInstPaying5(dtoobject.getValue("AMEND_LC_INST_PAYING5"));
			AmenddetailsInstance.setAmendLcInstPaying6(dtoobject.getValue("AMEND_LC_INST_PAYING6"));
			AmenddetailsInstance.setAmendLcInstPaying7(dtoobject.getValue("AMEND_LC_INST_PAYING7"));
			AmenddetailsInstance.setAmendLcInstPaying8(dtoobject.getValue("AMEND_LC_INST_PAYING8"));
			AmenddetailsInstance.setAmendLcInstPaying9(dtoobject.getValue("AMEND_LC_INST_PAYING9"));
			AmenddetailsInstance.setAmendLcInstPaying10(dtoobject.getValue("AMEND_LC_INST_PAYING10"));
			AmenddetailsInstance.setAmendLcInstPaying11(dtoobject.getValue("AMEND_LC_INST_PAYING11"));
			AmenddetailsInstance.setAmendLcInstPaying12(dtoobject.getValue("AMEND_LC_INST_PAYING12"));
			AmenddetailsInstance.setAmendLcSecondAdvReq(stringToChar(dtoobject.getValue("AMEND_LC_SECOND_ADV_REQ")));
			AmenddetailsInstance.setAmendLcSecondAdvType(stringToChar(dtoobject.getValue("AMEND_LC_SECOND_ADV_TYPE")));
			AmenddetailsInstance.setAmendLcSecondAdvBrnCode(dtoobject.getValue("AMEND_LC_SECOND_ADV_BRN_CODE"));
			AmenddetailsInstance.setAmendLcSecondAdvBicCode(dtoobject.getValue("AMEND_LC_SECOND_ADV_BIC_CODE"));
			AmenddetailsInstance.setAmendLcSecondAdvRoutid(dtoobject.getValue("AMEND_LC_SECOND_ADV_ROUTID"));
			AmenddetailsInstance.setAmendLcSecondAdvBnkCode(dtoobject.getValue("AMEND_LC_SECOND_ADV_BNK_CODE"));
			AmenddetailsInstance.setAmendLcSecondAdvAddr1(dtoobject.getValue("AMEND_LC_SECOND_ADV_ADDR1"));
			AmenddetailsInstance.setAmendLcSecondAdvAddr2(dtoobject.getValue("AMEND_LC_SECOND_ADV_ADDR2"));
			AmenddetailsInstance.setAmendLcSecondAdvAddr3(dtoobject.getValue("AMEND_LC_SECOND_ADV_ADDR3"));
			AmenddetailsInstance.setAmendLcSecondAdvAddr4(dtoobject.getValue("AMEND_LC_SECOND_ADV_ADDR4"));
			AmenddetailsInstance.setAmendLcSecondAdvAddr5(dtoobject.getValue("AMEND_LC_SECOND_ADV_ADDR5"));
			//Changes Sanjay1 18-07-2019 Begin
			AmenddetailsInstance.setAmendLcCnfAdvType(stringToChar(dtoobject.getValue("AMEND_LC_CNF_ADV_TYPE")));
			AmenddetailsInstance.setAmendLcCnfAdvBrnCode(dtoobject.getValue("AMEND_LC_CNF_ADV_BRN_CODE"));
			AmenddetailsInstance.setAmendLcCnfAdvBicCode(dtoobject.getValue("AMEND_LC_CNF_ADV_BIC_CODE"));
			AmenddetailsInstance.setAmendLcCnfAdvRoutid(dtoobject.getValue("AMEND_LC_CNF_ADV_ROUTID"));
			AmenddetailsInstance.setAmendLcCnfAdvBnkCode(dtoobject.getValue("AMEND_LC_CNF_ADV_BNK_CODE"));
			AmenddetailsInstance.setAmendLcCnfAdvAddr1(dtoobject.getValue("AMEND_LC_CNF_ADV_ADDR1"));
			AmenddetailsInstance.setAmendLcCnfAdvAddr2(dtoobject.getValue("AMEND_LC_CNF_ADV_ADDR2"));
			AmenddetailsInstance.setAmendLcCnfAdvAddr3(dtoobject.getValue("AMEND_LC_CNF_ADV_ADDR3"));
			AmenddetailsInstance.setAmendLcCnfAdvAddr4(dtoobject.getValue("AMEND_LC_CNF_ADV_ADDR4"));
			AmenddetailsInstance.setAmendLcCnfAdvAddr5(dtoobject.getValue("AMEND_LC_CNF_ADV_ADDR5"));
			AmenddetailsInstance.setAmendLcCnfAdvCntrycode(dtoobject.getValue("AMEND_LC_CNF_ADV_CNTRYCODE"));
			//Changes Sanjay1 18-07-2019 End
			//
			AmenddetailsInstance.setAmendLcSecondAdvCntrycode(dtoobject.getValue("AMEND_LC_SECOND_ADV_CNTRYCODE"));
			//
			// NEW FIELDS ADDED BY PRASHANTH ON 21 FEB 2019
			
			AmenddetailsInstance.setAmendLcAvlWithCodetyp(stringToChar(dtoobject.getValue("AMEND_LC_AVL_WITH_CODETYP")));
			
			
			//21 june 2019
			AmenddetailsInstance.setAmendLcReimbCntryCode(dtoobject.getValue("AMEND_LC_REIMB_CNTRY_CODE"));
			//21 june 2019


			AmenddetailsInstance.setIsNew(true);
			AmendManagerInstance.save(AmenddetailsInstance, TBAAUTH_MAIN_PK, TBAAUTH_ENTRY_DATE, TBAAUTH_DTL_SL);

		} catch (Exception e) {
			throw new PanaceaException(e.getLocalizedMessage());
		}
	}

	private void ModifySwiftamendDetails(DTObject dtoobject) throws PanaceaException {
		try {
			AmendDetails AmenddetailsInstance = new AmendDetails();
			AmendDetailsManager AmendManagerInstance = new AmendDetailsManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);
			AmenddetailsInstance = AmendManagerInstance.loadByKey(Integer.parseInt(dtoobj.getValue("OLCA_AMD_SL")), Integer.parseInt(dtoobj.getValue("OLCA_BRN_CODE")), Integer.parseInt(dtoobj.getValue("OLCA_LC_SL")), dtoobj.getValue("OLCA_LC_TYPE"), Integer.parseInt(dtoobj.getValue("OLCA_LC_YEAR")));

			if (AmenddetailsInstance != null) {
				AmenddetailsInstance.setAmendLcBrnCode(Integer.parseInt(dtoobj.getValue("OLCA_BRN_CODE")));
				AmenddetailsInstance.setAmendLcType(dtoobj.getValue("OLCA_LC_TYPE"));
				AmenddetailsInstance.setAmendLcYear(Integer.parseInt(dtoobj.getValue("OLCA_LC_YEAR")));
				AmenddetailsInstance.setAmendLcSerial(Integer.parseInt(dtoobj.getValue("OLCA_LC_SL")));
				AmenddetailsInstance.setAmendLcAmdSl(Integer.parseInt(dtoobj.getValue("OLCA_AMD_SL")));
				AmenddetailsInstance.setAmendSndrRef(dtoobj.getValue("AMEND_SNDR_REF"));
				AmenddetailsInstance.setAmendRcvrRef(dtoobj.getValue("AMEND_RCVR_REF"));
				AmenddetailsInstance.setAmendDocCrNum(dtoobj.getValue("AMEND_DOC_CR_NUM"));
				AmenddetailsInstance.setAmendIssueRef(dtoobj.getValue("AMEND_ISSUE_REF"));
				AmenddetailsInstance.setAmendIssuingBnkReq(stringToChar(dtoobj.getValue("AMEND_ISSUING_BNK_REQ")));
				AmenddetailsInstance.setAmendIssuingType(stringToChar(dtoobj.getValue("AMEND_ISSUING_TYPE")));
				AmenddetailsInstance.setAmendIssuingBicCode(dtoobj.getValue("AMEND_ISSUING_BIC_CODE"));
				AmenddetailsInstance.setAmendIssuingBrnCode(dtoobj.getValue("AMEND_ISSUING_BRN_CODE"));
				AmenddetailsInstance.setAmendIssuingBnkCode(dtoobj.getValue("AMEND_ISSUING_BNK_CODE"));
				AmenddetailsInstance.setAmendIssuingRoutid(dtoobj.getValue("AMEND_ISSUING_ROUTID"));
				AmenddetailsInstance.setAmendIssuingAddr1(dtoobj.getValue("AMEND_ISSUING_ADDR1"));
				AmenddetailsInstance.setAmendIssuingAddr2(dtoobj.getValue("AMEND_ISSUING_ADDR2"));
				AmenddetailsInstance.setAmendIssuingAddr3(dtoobj.getValue("AMEND_ISSUING_ADDR3"));
				AmenddetailsInstance.setAmendIssuingAddr4(dtoobj.getValue("AMEND_ISSUING_ADDR4"));
				AmenddetailsInstance.setAmendIssuingAddr5(dtoobj.getValue("AMEND_ISSUING_ADDR5"));
				AmenddetailsInstance.setAmendIssuingCntry(dtoobj.getValue("AMEND_ISSUING_CNTRY"));
				AmenddetailsInstance.setAmendNonBnkIssur(dtoobj.getValue("AMEND_NON_BNK_ISSUR"));
				if (dtoobj.getValue("AMEND_DATE_OF_ISSUE") != null && !dtoobj.getValue("AMEND_DATE_OF_ISSUE").trim().equals(""))
					AmenddetailsInstance.setAmendDateOfIssue(DateToYYYYMMDD(dtoobj.getValue("AMEND_DATE_OF_ISSUE")));
				else
					AmenddetailsInstance.setAmendDateOfIssue(null);
				AmenddetailsInstance.setAmendDateOfAmendment(DateToYYYYMMDD(dtoobj.getValue("AMEND_DATE_OF_AMENDMENT")));
				AmenddetailsInstance.setAmendPurposeOfMsg(stringToChar(dtoobj.getValue("AMEND_PURPOSE_OF_MSG")));
				AmenddetailsInstance.setAmendCancelRequest(dtoobj.getValue("AMEND_CANCEL_REQUEST"));
				AmenddetailsInstance.setAmendAdvisingBnkReq(stringToChar(dtoobj.getValue("AMEND_ADVISING_BNK_REQ")));
				AmenddetailsInstance.setAmendAdvisingBnkType(stringToChar(dtoobj.getValue("AMEND_ADVISING_BNK_TYPE")));
				AmenddetailsInstance.setAmendAdvisingBrnCode(dtoobj.getValue("AMEND_ADVISING_BRN_CODE"));
				AmenddetailsInstance.setAmendAdvisingBicCode(dtoobj.getValue("AMEND_ADVISING_BIC_CODE"));
				AmenddetailsInstance.setAmendAdvisingRoutid(dtoobj.getValue("AMEND_ADVISING_ROUTID"));
				AmenddetailsInstance.setAmendAdvisingBnkCode(dtoobj.getValue("AMEND_ADVISING_BNK_CODE"));
				AmenddetailsInstance.setAmendAdvisingAddr1(dtoobj.getValue("AMEND_ADVISING_ADDR1"));
				AmenddetailsInstance.setAmendAdvisingAddr2(dtoobj.getValue("AMEND_ADVISING_ADDR2"));
				AmenddetailsInstance.setAmendAdvisingAddr3(dtoobj.getValue("AMEND_ADVISING_ADDR3"));
				AmenddetailsInstance.setAmendAdvisingAddr4(dtoobj.getValue("AMEND_ADVISING_ADDR4"));
				AmenddetailsInstance.setAmendAdvisingAddr5(dtoobj.getValue("AMEND_ADVISING_ADDR5"));
				AmenddetailsInstance.setAmendSecondAdvReq(stringToChar(dtoobj.getValue("AMEND_SECOND_ADV_REQ")));
				AmenddetailsInstance.setAmendSecondAdvType(stringToChar(dtoobj.getValue("AMEND_SECOND_ADV_TYPE")));
				AmenddetailsInstance.setAmendSecondAdvBrnCode(dtoobj.getValue("AMEND_SECOND_ADV_BRN_CODE"));
				AmenddetailsInstance.setAmendSecondAdvBicCode(dtoobj.getValue("AMEND_SECOND_ADV_BIC_CODE"));
				AmenddetailsInstance.setAmendSecondAdvRoutid(dtoobj.getValue("AMEND_SECOND_ADV_ROUTID"));
				AmenddetailsInstance.setAmendSecondAdvBnkCode(dtoobj.getValue("AMEND_SECOND_ADV_BNK_CODE"));
				AmenddetailsInstance.setAmendSecondAdvAddr1(dtoobj.getValue("AMEND_SECOND_ADV_ADDR1"));
				AmenddetailsInstance.setAmendSecondAdvAddr2(dtoobj.getValue("AMEND_SECOND_ADV_ADDR2"));
				AmenddetailsInstance.setAmendSecondAdvAddr3(dtoobj.getValue("AMEND_SECOND_ADV_ADDR3"));
				AmenddetailsInstance.setAmendSecondAdvAddr4(dtoobj.getValue("AMEND_SECOND_ADV_ADDR4"));
				AmenddetailsInstance.setAmendSecondAdvAddr5(dtoobj.getValue("AMEND_SECOND_ADV_ADDR5"));
				AmenddetailsInstance.setAmendNewBeneficiary(dtoobj.getValue("AMEND_NEW_BENEFICIARY"));
				if (dtoobj.getValue("AMEND_NEW_DATE_OF_EXPIRY") != null && !dtoobj.getValue("AMEND_NEW_DATE_OF_EXPIRY").trim().equals(""))
					AmenddetailsInstance.setAmendNewDateOfExpiry(DateToYYYYMMDD(dtoobj.getValue("AMEND_NEW_DATE_OF_EXPIRY")));
				else
					AmenddetailsInstance.setAmendNewDateOfExpiry(null);
				AmenddetailsInstance.setAmendIncrDocCrAmt(Double.parseDouble(dtoobj.getValue("AMEND_INCR_DOC_CR_AMT")));
				AmenddetailsInstance.setAmendDecrDocCrAmt(Double.parseDouble(dtoobj.getValue("AMEND_DECR_DOC_CR_AMT")));
				AmenddetailsInstance.setAmendNewAddnlAmt(Double.parseDouble(dtoobj.getValue("AMEND_NEW_ADDNL_AMT")));
				AmenddetailsInstance.setAmendPlaceTakinInChrg(dtoobj.getValue("AMEND_PLACE_TAKIN_IN_CHRG"));
				AmenddetailsInstance.setAmendPortOfLoading(dtoobj.getValue("AMEND_PORT_OF_LOADING"));
				AmenddetailsInstance.setAmendPortOfDischarge(dtoobj.getValue("AMEND_PORT_OF_DISCHARGE"));
				AmenddetailsInstance.setAmendPlaceOfFinalDest(dtoobj.getValue("AMEND_PLACE_OF_FINAL_DEST"));
				if (dtoobj.getValue("AMEND_DATE_OF_SHIPMENT") != null)
					AmenddetailsInstance.setAmendDateOfShipment(DateToYYYYMMDD(dtoobj.getValue("AMEND_DATE_OF_SHIPMENT")));
				else
					AmenddetailsInstance.setAmendDateOfShipment(null);
				AmenddetailsInstance.setAmendDescGoddSer1(dtoobj.getValue("AMEND_DESC_GODD_SER1"));
				AmenddetailsInstance.setAmendDocReq1(dtoobj.getValue("AMEND_DOC_REQ1"));
				AmenddetailsInstance.setAmendAddCondition1(dtoobj.getValue("AMEND_ADD_CONDITION1"));

				/*
				 * //NEW FIELDS ADDED BY PRASHANTH ON 08 FEB 2019
				 * AmenddetailsInstance.setAmendDescGoddSer2(dtoobj.getValue("AMEND_DESC_GODD_SER2"));
				 * AmenddetailsInstance.setAmendDocReq2(dtoobj.getValue("AMEND_DOC_REQ2"));
				 * AmenddetailsInstance.setAmendAddCondition2(dtoobj.getValue("AMEND_ADD_CONDITION2"));
				 * 
				 * 
				 * AmenddetailsInstance.setAmendDescGoddSer3(dtoobj.getValue("AMEND_DESC_GODD_SER3"));
				 * AmenddetailsInstance.setAmendDocReq3(dtoobj.getValue("AMEND_DOC_REQ3"));
				 * AmenddetailsInstance.setAmendAddCondition3(dtoobj.getValue("AMEND_ADD_CONDITION3"));
				 * //NEW FIELDS ADDED BY PRASHANTH ON 08 FEB 2019
				 */

				AmenddetailsInstance.setAmendChrgPayable1(dtoobj.getValue("AMEND_CHRG_PAYABLE1"));
				AmenddetailsInstance.setAmendChrgPayable2(dtoobj.getValue("AMEND_CHRG_PAYABLE2"));
				AmenddetailsInstance.setAmendChrgPayable3(dtoobj.getValue("AMEND_CHRG_PAYABLE3"));
				AmenddetailsInstance.setAmendChrgPayable4(dtoobj.getValue("AMEND_CHRG_PAYABLE4"));
				AmenddetailsInstance.setAmendChrgPayable5(dtoobj.getValue("AMEND_CHRG_PAYABLE5"));
				AmenddetailsInstance.setAmendChrgPayable6(dtoobj.getValue("AMEND_CHRG_PAYABLE6"));
				/*AmenddetailsInstance.setAmendNewPrdPresntDay(dtoobj.getValue("AMEND_NEW_PRD_PRESNT_DAY"));
				AmenddetailsInstance.setAmendNewConfirmInstr(dtoobj.getValue("AMEND_NEW_CONFIRM_INSTR"));
				AmenddetailsInstance.setAmendSplPayBenficiary(dtoobj.getValue("AMEND_SPL_PAY_BENFICIARY"));
				AmenddetailsInstance.setAmendSplPayRecBnk(dtoobj.getValue("AMEND_SPL_PAY_REC_BNK"));
				AmenddetailsInstance.setAmendInstrTopaying1(dtoobj.getValue("AMEND_INSTR_TOPAYING1"));
				AmenddetailsInstance.setAmendInstrTopaying2(dtoobj.getValue("AMEND_INSTR_TOPAYING2"));
				AmenddetailsInstance.setAmendInstrTopaying3(dtoobj.getValue("AMEND_INSTR_TOPAYING3"));
				AmenddetailsInstance.setAmendInstrTopaying4(dtoobj.getValue("AMEND_INSTR_TOPAYING4"));
				AmenddetailsInstance.setAmendInstrTopaying5(dtoobj.getValue("AMEND_INSTR_TOPAYING5"));
				AmenddetailsInstance.setAmendInstrTopaying6(dtoobj.getValue("AMEND_INSTR_TOPAYING6"));
				AmenddetailsInstance.setAmendInstrTopaying7(dtoobj.getValue("AMEND_INSTR_TOPAYING7"));
				AmenddetailsInstance.setAmendInstrTopaying8(dtoobj.getValue("AMEND_INSTR_TOPAYING8"));
				AmenddetailsInstance.setAmendInstrTopaying9(dtoobj.getValue("AMEND_INSTR_TOPAYING9"));
				AmenddetailsInstance.setAmendInstrTopaying10(dtoobj.getValue("AMEND_INSTR_TOPAYING10"));
				AmenddetailsInstance.setAmendInstrTopaying11(dtoobj.getValue("AMEND_INSTR_TOPAYING11"));
				AmenddetailsInstance.setAmendInstrTopaying12(dtoobj.getValue("AMEND_INSTR_TOPAYING12"));*/
				AmenddetailsInstance.setAmendSndrRecInfo1(dtoobj.getValue("AMEND_SNDR_REC_INFO1"));
				AmenddetailsInstance.setAmendSndrRecInfo2(dtoobj.getValue("AMEND_SNDR_REC_INFO2"));
				AmenddetailsInstance.setAmendSndrRecInfo3(dtoobj.getValue("AMEND_SNDR_REC_INFO3"));
				AmenddetailsInstance.setAmendSndrRecInfo4(dtoobj.getValue("AMEND_SNDR_REC_INFO4"));
				AmenddetailsInstance.setAmendSndrRecInfo5(dtoobj.getValue("AMEND_SNDR_REC_INFO5"));
				AmenddetailsInstance.setAmendSndrRecInfo6(dtoobj.getValue("AMEND_SNDR_REC_INFO6"));
				//Changes Sanjay1 18-07-2019 Begin
				//AmenddetailsInstance.setAmendNarrative(dtoobj.getValue("AMEND_NARRATIVE"));
				//AmenddetailsInstance.setAmendLcApplicantRules(stringToChar(dtoobject.getValue("AMEND_LC_APPLICANT_RULES")));
				//Changes Sanjay1 18-07-2019 End
				AmenddetailsInstance.setAmendChkbox(dtoobj.getValue("AMEND_CHKBOX"));
				AmenddetailsInstance.setAmendAdvisingCntry(dtoobj.getValue("AMEND_ADVISING_CNTRY"));
				AmenddetailsInstance.setAmendSecondAdvCntry(dtoobj.getValue("AMEND_SECOND_ADV_CNTRY"));
				// AmenddetailsInstance.setAmendIssueRef(dtoobj.getValue("AMEND_SECOND_ADV_CNTRY"));

				// NEW FIELDS ADDED BY PRASHANTH ON 21 FEB 2019
				AmenddetailsInstance.setAmendFormOfDocCredit(Integer.parseInt(dtoobject.getValue("AMEND_FORM_OF_DOC_CREDIT")));
				AmenddetailsInstance.setAmendLcApplicableRules(Integer.parseInt(dtoobject.getValue("AMEND_LC_APPLICABLE_RULES")));
				AmenddetailsInstance.setAmendLcApplicantReq(stringToChar(dtoobject.getValue("AMEND_LC_APPLICANT_REQ")));
				AmenddetailsInstance.setAmendLcApplicantName(dtoobject.getValue("AMEND_LC_APPLICANT_NAME"));
				AmenddetailsInstance.setAmendLcApplicantAddr1(dtoobject.getValue("AMEND_LC_APPLICANT_ADDR1"));
				AmenddetailsInstance.setAmendLcApplicantAddr2(dtoobject.getValue("AMEND_LC_APPLICANT_ADDR2"));
				AmenddetailsInstance.setAmendLcApplicantAddr3(dtoobject.getValue("AMEND_LC_APPLICANT_ADDR3"));
				AmenddetailsInstance.setAmendLcApplicantAddr4(dtoobject.getValue("AMEND_LC_APPLICANT_ADDR4"));
				AmenddetailsInstance.setAmendLcApplicantAddr5(dtoobject.getValue("AMEND_LC_APPLICANT_ADDR5"));
				AmenddetailsInstance.setAmendLcAvlWithType(stringToChar(dtoobject.getValue("AMEND_LC_AVL_WITH_TYPE")));
				//Changes Sanjay1 18-07-2019 Begin
				AmenddetailsInstance.setAmendLcAvlWithBicCode(dtoobject.getValue("AMEND_LC_AVL_WITH_BIC_CODE"));
				//Changes Sanjay1 18-07-2019 End
				AmenddetailsInstance.setAmendLcAvlWithBrnCode(dtoobject.getValue("AMEND_LC_AVL_WITH_BRN_CODE"));
				AmenddetailsInstance.setAmendLcLcAvlWithRoutid(dtoobject.getValue("AMEND_LC_LC_AVL_WITH_ROUTID"));
				AmenddetailsInstance.setAmendLcAvlWithBnkCode(dtoobject.getValue("AMEND_LC_AVL_WITH_BNK_CODE"));
				AmenddetailsInstance.setAmendLcAvlWithAddr1(dtoobject.getValue("AMEND_LC_AVL_WITH_ADDR1"));
				AmenddetailsInstance.setAmendLcAvlWithAddr2(dtoobject.getValue("AMEND_LC_AVL_WITH_ADDR2"));
				AmenddetailsInstance.setAmendLcAvlWithAddr3(dtoobject.getValue("AMEND_LC_AVL_WITH_ADDR3"));
				AmenddetailsInstance.setAmendLcAvlWithAddr4(dtoobject.getValue("AMEND_LC_AVL_WITH_ADDR4"));
				AmenddetailsInstance.setAmendLcAvlWithAddr5(dtoobject.getValue("AMEND_LC_AVL_WITH_ADDR5"));
				//
				AmenddetailsInstance.setAmendLcAvlWithCntry(dtoobject.getValue("AMEND_LC_AVL_WITH_CNTRY"));
				//
				AmenddetailsInstance.setAmendLcDraftsAt1(dtoobject.getValue("AMEND_LC_DRAFTS_AT1"));
				AmenddetailsInstance.setAmendLcDraftsAt2(dtoobject.getValue("AMEND_LC_DRAFTS_AT2"));
				AmenddetailsInstance.setAmendLcDraftsAt3(dtoobject.getValue("AMEND_LC_DRAFTS_AT3"));
				AmenddetailsInstance.setAmendLcDraweeReq(stringToChar(dtoobject.getValue("AMEND_LC_DRAWEE_REQ")));
				AmenddetailsInstance.setAmendLcDraweeType(stringToChar(dtoobject.getValue("AMEND_LC_DRAWEE_TYPE")));
				AmenddetailsInstance.setAmendLcDraweeBrnCode(dtoobject.getValue("AMEND_LC_DRAWEE_BRN_CODE"));
				AmenddetailsInstance.setAmendLcDraweeBicCode(dtoobject.getValue("AMEND_LC_DRAWEE_BIC_CODE"));
				AmenddetailsInstance.setAmendLcDraweeRoutid(dtoobject.getValue("AMEND_LC_DRAWEE_ROUTID"));
				AmenddetailsInstance.setAmendLcDraweeBnkCode(dtoobject.getValue("AMEND_LC_DRAWEE_BNK_CODE"));
				AmenddetailsInstance.setAmendLcDraweeAddr1(dtoobject.getValue("AMEND_LC_DRAWEE_ADDR1"));
				AmenddetailsInstance.setAmendLcDraweeAddr2(dtoobject.getValue("AMEND_LC_DRAWEE_ADDR2"));
				AmenddetailsInstance.setAmendLcDraweeAddr3(dtoobject.getValue("AMEND_LC_DRAWEE_ADDR3"));
				AmenddetailsInstance.setAmendLcDraweeAddr4(dtoobject.getValue("AMEND_LC_DRAWEE_ADDR4"));
				AmenddetailsInstance.setAmendLcDraweeAddr5(dtoobject.getValue("AMEND_LC_DRAWEE_ADDR5"));

				//
				AmenddetailsInstance.setAmendDraweeCntryCode(dtoobject.getValue("AMEND_DRAWEE_CNTRY_CODE"));

				//

				AmenddetailsInstance.setAmendLcMixedPayDetails1(dtoobject.getValue("AMEND_LC_MIXED_PAY_DETAILS1"));
				AmenddetailsInstance.setAmendLcMixedPayDetails2(dtoobject.getValue("AMEND_LC_MIXED_PAY_DETAILS2"));
				AmenddetailsInstance.setAmendLcMixedPayDetails3(dtoobject.getValue("AMEND_LC_MIXED_PAY_DETAILS3"));
				AmenddetailsInstance.setAmendLcMixedPayDetails4(dtoobject.getValue("AMEND_LC_MIXED_PAY_DETAILS4"));
				AmenddetailsInstance.setAmendLcMixedPayDetails5(dtoobject.getValue("AMEND_LC_MIXED_PAY_DETAILS5"));
				AmenddetailsInstance.setAmendLcDeferredPayDetails1(dtoobject.getValue("AMEND_LC_DEFERRED_PAY_DETAILS1"));
				AmenddetailsInstance.setAmendLcDeferredPayDetails2(dtoobject.getValue("AMEND_LC_DEFERRED_PAY_DETAILS2"));
				AmenddetailsInstance.setAmendLcDeferredPayDetails3(dtoobject.getValue("AMEND_LC_DEFERRED_PAY_DETAILS3"));
				AmenddetailsInstance.setAmendLcDeferredPayDetails4(dtoobject.getValue("AMEND_LC_DEFERRED_PAY_DETAILS4"));
				AmenddetailsInstance.setAmendLcDeferredPayDetails5(dtoobject.getValue("AMEND_LC_DEFERRED_PAY_DETAILS5"));
				AmenddetailsInstance.setAmendLcPartialShipments(Integer.parseInt(dtoobject.getValue("AMEND_LC_PARTIAL_SHIPMENTS")));
				AmenddetailsInstance.setAmendLcTranshipment(Integer.parseInt(dtoobject.getValue("AMEND_LC_TRANSHIPMENT")));
				if(!dtoobject.getValue("AMEND_LC_CONFIRMATION_INST").equals("")){
				AmenddetailsInstance.setAmendLcConfirmationInst(Integer.parseInt(dtoobject.getValue("AMEND_LC_CONFIRMATION_INST")));
				}
				//Changes Sanjay1 18-07-2019 Begin
				//AmenddetailsInstance.setAmendLcCnfByBank(dtoobject.getValue("AMEND_LC_CNF_BY_BANK"));
				//AmenddetailsInstance.setAmendLcCnfByBrn(Integer.parseInt(dtoobject.getValue("AMEND_LC_CNF_BY_BRN")));
				//Changes Sanjay1 18-07-2019 End
				AmenddetailsInstance.setAmendLcReimbReq(stringToChar(dtoobject.getValue("AMEND_LC_REIMB_REQ")));
				AmenddetailsInstance.setAmendLcReimbType(stringToChar(dtoobject.getValue("AMEND_LC_REIMB_TYPE")));
				AmenddetailsInstance.setAmendLcReimbBrnCode(dtoobject.getValue("AMEND_LC_REIMB_BRN_CODE"));
				AmenddetailsInstance.setAmendLcReimbBicCode(dtoobject.getValue("AMEND_LC_REIMB_BIC_CODE"));
				AmenddetailsInstance.setAmendLcReimbRoutid(dtoobject.getValue("AMEND_LC_REIMB_ROUTID"));
				AmenddetailsInstance.setAmendLcReimbBnkCode(dtoobject.getValue("AMEND_LC_REIMB_BNK_CODE"));
				AmenddetailsInstance.setAmendLcReimbAddr1(dtoobject.getValue("AMEND_LC_REIMB_ADDR1"));
				AmenddetailsInstance.setAmendLcReimbAddr2(dtoobject.getValue("AMEND_LC_REIMB_ADDR2"));
				AmenddetailsInstance.setAmendLcReimbAddr3(dtoobject.getValue("AMEND_LC_REIMB_ADDR3"));
				AmenddetailsInstance.setAmendLcReimbAddr4(dtoobject.getValue("AMEND_LC_REIMB_ADDR4"));
				AmenddetailsInstance.setAmendLcReimbAddr5(dtoobject.getValue("AMEND_LC_REIMB_ADDR5"));
				AmenddetailsInstance.setAmendLcInstPaying1(dtoobject.getValue("AMEND_LC_INST_PAYING1"));
				AmenddetailsInstance.setAmendLcInstPaying2(dtoobject.getValue("AMEND_LC_INST_PAYING2"));
				AmenddetailsInstance.setAmendLcInstPaying3(dtoobject.getValue("AMEND_LC_INST_PAYING3"));
				AmenddetailsInstance.setAmendLcInstPaying4(dtoobject.getValue("AMEND_LC_INST_PAYING4"));
				AmenddetailsInstance.setAmendLcInstPaying5(dtoobject.getValue("AMEND_LC_INST_PAYING5"));
				AmenddetailsInstance.setAmendLcInstPaying6(dtoobject.getValue("AMEND_LC_INST_PAYING6"));
				AmenddetailsInstance.setAmendLcInstPaying7(dtoobject.getValue("AMEND_LC_INST_PAYING7"));
				AmenddetailsInstance.setAmendLcInstPaying8(dtoobject.getValue("AMEND_LC_INST_PAYING8"));
				AmenddetailsInstance.setAmendLcInstPaying9(dtoobject.getValue("AMEND_LC_INST_PAYING9"));
				AmenddetailsInstance.setAmendLcInstPaying10(dtoobject.getValue("AMEND_LC_INST_PAYING10"));
				AmenddetailsInstance.setAmendLcInstPaying11(dtoobject.getValue("AMEND_LC_INST_PAYING11"));
				AmenddetailsInstance.setAmendLcInstPaying12(dtoobject.getValue("AMEND_LC_INST_PAYING12"));
				AmenddetailsInstance.setAmendLcSecondAdvReq(stringToChar(dtoobject.getValue("AMEND_LC_SECOND_ADV_REQ")));
				AmenddetailsInstance.setAmendLcSecondAdvType(stringToChar(dtoobject.getValue("AMEND_LC_SECOND_ADV_TYPE")));
				AmenddetailsInstance.setAmendLcSecondAdvBrnCode(dtoobject.getValue("AMEND_LC_SECOND_ADV_BRN_CODE"));
				AmenddetailsInstance.setAmendLcSecondAdvBicCode(dtoobject.getValue("AMEND_LC_SECOND_ADV_BIC_CODE"));
				AmenddetailsInstance.setAmendLcSecondAdvRoutid(dtoobject.getValue("AMEND_LC_SECOND_ADV_ROUTID"));
				AmenddetailsInstance.setAmendLcSecondAdvBnkCode(dtoobject.getValue("AMEND_LC_SECOND_ADV_BNK_CODE"));
				AmenddetailsInstance.setAmendLcSecondAdvAddr1(dtoobject.getValue("AMEND_LC_SECOND_ADV_ADDR1"));
				AmenddetailsInstance.setAmendLcSecondAdvAddr2(dtoobject.getValue("AMEND_LC_SECOND_ADV_ADDR2"));
				AmenddetailsInstance.setAmendLcSecondAdvAddr3(dtoobject.getValue("AMEND_LC_SECOND_ADV_ADDR3"));
				AmenddetailsInstance.setAmendLcSecondAdvAddr4(dtoobject.getValue("AMEND_LC_SECOND_ADV_ADDR4"));
				AmenddetailsInstance.setAmendLcSecondAdvAddr5(dtoobject.getValue("AMEND_LC_SECOND_ADV_ADDR5"));
				//Changes Sanjay1 18-07-2019 Begin
				AmenddetailsInstance.setAmendLcCnfAdvType(stringToChar(dtoobject.getValue("AMEND_LC_CNF_ADV_TYPE")));
				AmenddetailsInstance.setAmendLcCnfAdvBrnCode(dtoobject.getValue("AMEND_LC_CNF_ADV_BRN_CODE"));
				AmenddetailsInstance.setAmendLcCnfAdvBicCode(dtoobject.getValue("AMEND_LC_CNF_ADV_BIC_CODE"));
	            AmenddetailsInstance.setAmendLcCnfAdvRoutid(dtoobject.getValue("AMEND_LC_CNF_ADV_ROUTID"));
	            AmenddetailsInstance.setAmendLcCnfAdvBnkCode(dtoobject.getValue("AMEND_LC_CNF_ADV_BNK_CODE"));
	            AmenddetailsInstance.setAmendLcCnfAdvAddr1(dtoobject.getValue("AMEND_LC_CNF_ADV_ADDR1"));
	            AmenddetailsInstance.setAmendLcCnfAdvAddr2(dtoobject.getValue("AMEND_LC_CNF_ADV_ADDR2"));
	            AmenddetailsInstance.setAmendLcCnfAdvAddr3(dtoobject.getValue("AMEND_LC_CNF_ADV_ADDR3"));
	            AmenddetailsInstance.setAmendLcCnfAdvAddr4(dtoobject.getValue("AMEND_LC_CNF_ADV_ADDR4"));
	            AmenddetailsInstance.setAmendLcCnfAdvAddr5(dtoobject.getValue("AMEND_LC_CNF_ADV_ADDR5"));
	            AmenddetailsInstance.setAmendLcCnfAdvCntrycode(dtoobject.getValue("AMEND_LC_CNF_ADV_CNTRYCODE"));
	          //Changes Sanjay1 18-07-2019 End
				// NEW FIELDS ADDED BY PRASHANTH ON 21 FEB 2019
				//
				AmenddetailsInstance.setAmendLcSecondAdvCntrycode(dtoobject.getValue("AMEND_LC_SECOND_ADV_CNTRYCODE"));
				//
				
				AmenddetailsInstance.setAmendLcAvlWithCodetyp(stringToChar(dtoobject.getValue("AMEND_LC_AVL_WITH_CODETYP")));
				//21 june 2019
				AmenddetailsInstance.setAmendLcReimbCntryCode(dtoobject.getValue("AMEND_LC_REIMB_CNTRY_CODE"));
				//21 june 2019

				AmenddetailsInstance.setIsNew(false);
				AmendManagerInstance.save(AmenddetailsInstance, TBAAUTH_MAIN_PK, TBAAUTH_ENTRY_DATE, TBAAUTH_DTL_SL);

			}

		} catch (Exception e) {
			throw new PanaceaException(e.getLocalizedMessage());
		}
	}

	private void AddSwiftAmendDetailsHist(DTObject dtoobject) throws PanaceaException {
		try {
			AmendDetailsHist AmendDetailsHistInstance = new AmendDetailsHist();
			AmendDetailsHistManager AmendDetailsHistManagerInstance = new AmendDetailsHistManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);
			AmendDetailsHistInstance.setAmendhistLcBrnCode(Integer.parseInt(dtoobj.getValue("OLCA_BRN_CODE")));
			AmendDetailsHistInstance.setAmendhistLcType(dtoobj.getValue("OLCA_LC_TYPE"));
			AmendDetailsHistInstance.setAmendhistLcYear(Integer.parseInt(dtoobj.getValue("OLCA_LC_YEAR")));
			AmendDetailsHistInstance.setAmendhistLcSerial(Integer.parseInt(dtoobj.getValue("OLCA_LC_SL")));
			AmendDetailsHistInstance.setAmendhistLcAmdSl(Integer.parseInt(dtoobj.getValue("OLCA_AMD_SL")));
			AmendDetailsHistInstance.setAmendhistHistSl(max_sl);
			AmendDetailsHistInstance.setAmendhistHistDate(DateToYYYYMMDD(dtoobj.getValue("CBD")));
			AmendDetailsHistInstance.setAmendhistSndrRef(dtoobj.getValue("AMEND_SNDR_REF"));
			AmendDetailsHistInstance.setAmendhistRcvrRef(dtoobj.getValue("AMEND_RCVR_REF"));
			AmendDetailsHistInstance.setAmendhistDocCrNum(dtoobj.getValue("AMEND_DOC_CR_NUM"));
			AmendDetailsHistInstance.setAmendhistIssueRef(dtoobj.getValue("AMEND_ISSUE_REF"));
			AmendDetailsHistInstance.setAmendhistIssuingBnkReq(stringToChar(dtoobj.getValue("AMEND_ISSUING_BNK_REQ")));
			AmendDetailsHistInstance.setAmendhistIssuingType(stringToChar(dtoobj.getValue("AMEND_ISSUING_TYPE")));
			AmendDetailsHistInstance.setAmendhistIssuingBicCode(dtoobj.getValue("AMEND_ISSUING_BIC_CODE"));
			AmendDetailsHistInstance.setAmendhistIssuingBrnCode(dtoobj.getValue("AMEND_ISSUING_BRN_CODE"));
			AmendDetailsHistInstance.setAmendhistIssuingBnkCode(dtoobj.getValue("AMEND_ISSUING_BNK_CODE"));
			AmendDetailsHistInstance.setAmendhistIssuingRoutid(dtoobj.getValue("AMEND_ISSUING_ROUTID"));
			AmendDetailsHistInstance.setAmendhistIssuingAddr1(dtoobj.getValue("AMEND_ISSUING_ADDR1"));
			AmendDetailsHistInstance.setAmendhistIssuingAddr2(dtoobj.getValue("AMEND_ISSUING_ADDR2"));
			AmendDetailsHistInstance.setAmendhistIssuingAddr3(dtoobj.getValue("AMEND_ISSUING_ADDR3"));
			AmendDetailsHistInstance.setAmendhistIssuingAddr4(dtoobj.getValue("AMEND_ISSUING_ADDR4"));
			AmendDetailsHistInstance.setAmendhistIssuingAddr5(dtoobj.getValue("AMEND_ISSUING_ADDR5"));
			AmendDetailsHistInstance.setAmendhistIssuingCntry(dtoobj.getValue("AMEND_ISSUING_CNTRY"));
			AmendDetailsHistInstance.setAmendhistNonBnkIssur(dtoobj.getValue("AMEND_NON_BNK_ISSUR"));
			if (dtoobj.getValue("AMEND_DATE_OF_ISSUE") != null && !dtoobj.getValue("AMEND_DATE_OF_ISSUE").trim().equals(""))
				AmendDetailsHistInstance.setAmendhistDateOfIssue(DateToYYYYMMDD(dtoobj.getValue("AMEND_DATE_OF_ISSUE")));
			else
				AmendDetailsHistInstance.setAmendhistDateOfIssue(null);
			AmendDetailsHistInstance.setAmendhistDateOfAmendmnt(DateToYYYYMMDD(dtoobj.getValue("AMEND_DATE_OF_AMENDMENT")));
			AmendDetailsHistInstance.setAmendhistPurposeOfMsg(stringToChar(dtoobj.getValue("AMEND_PURPOSE_OF_MSG")));
			AmendDetailsHistInstance.setAmendhistCancelRequest(dtoobj.getValue("AMEND_CANCEL_REQUEST"));
			AmendDetailsHistInstance.setAmendhistAdvisingBnkReq(stringToChar(dtoobj.getValue("AMEND_ADVISING_BNK_REQ")));
			AmendDetailsHistInstance.setAmendhistAdvisingBnkType(stringToChar(dtoobj.getValue("AMEND_ADVISING_BNK_TYPE")));
			AmendDetailsHistInstance.setAmendhistAdvisingBrnCode(dtoobj.getValue("AMEND_ADVISING_BRN_CODE"));
			AmendDetailsHistInstance.setAmendhistAdvisingBicCode(dtoobj.getValue("AMEND_ADVISING_BIC_CODE"));
			AmendDetailsHistInstance.setAmendhistAdvisingRoutid(dtoobj.getValue("AMEND_ADVISING_ROUTID"));
			AmendDetailsHistInstance.setAmendhistAdvisingBnkCode(dtoobj.getValue("AMEND_ADVISING_BNK_CODE"));
			AmendDetailsHistInstance.setAmendhistAdvisingAddr1(dtoobj.getValue("AMEND_ADVISING_ADDR1"));
			AmendDetailsHistInstance.setAmendhistAdvisingAddr2(dtoobj.getValue("AMEND_ADVISING_ADDR2"));
			AmendDetailsHistInstance.setAmendhistAdvisingAddr3(dtoobj.getValue("AMEND_ADVISING_ADDR3"));
			AmendDetailsHistInstance.setAmendhistAdvisingAddr4(dtoobj.getValue("AMEND_ADVISING_ADDR4"));
			AmendDetailsHistInstance.setAmendhistAdvisingAddr5(dtoobj.getValue("AMEND_ADVISING_ADDR5"));
			AmendDetailsHistInstance.setAmendhistSecondAdvReq(stringToChar(dtoobj.getValue("AMEND_SECOND_ADV_REQ")));
			AmendDetailsHistInstance.setAmendhistSecondAdvType(stringToChar(dtoobj.getValue("AMEND_SECOND_ADV_TYPE")));
			AmendDetailsHistInstance.setAmendhistSecondAdvBrnCode(dtoobj.getValue("AMEND_SECOND_ADV_BRN_CODE"));
			AmendDetailsHistInstance.setAmendhistSecondAdvBicCode(dtoobj.getValue("AMEND_SECOND_ADV_BIC_CODE"));
			AmendDetailsHistInstance.setAmendhistSecondAdvRoutid(dtoobj.getValue("AMEND_SECOND_ADV_ROUTID"));
			AmendDetailsHistInstance.setAmendhistSecondAdvBnkCode(dtoobj.getValue("AMEND_SECOND_ADV_BNK_CODE"));
			AmendDetailsHistInstance.setAmendhistSecondAdvAddr1(dtoobj.getValue("AMEND_SECOND_ADV_ADDR1"));
			AmendDetailsHistInstance.setAmendhistSecondAdvAddr2(dtoobj.getValue("AMEND_SECOND_ADV_ADDR2"));
			AmendDetailsHistInstance.setAmendhistSecondAdvAddr3(dtoobj.getValue("AMEND_SECOND_ADV_ADDR3"));
			AmendDetailsHistInstance.setAmendhistSecondAdvAddr4(dtoobj.getValue("AMEND_SECOND_ADV_ADDR4"));
			AmendDetailsHistInstance.setAmendhistSecondAdvAddr5(dtoobj.getValue("AMEND_SECOND_ADV_ADDR5"));
			AmendDetailsHistInstance.setAmendhistNewBeneficiary(dtoobj.getValue("AMEND_NEW_BENEFICIARY"));
			if (dtoobj.getValue("AMEND_NEW_DATE_OF_EXPIRY") != null && !dtoobj.getValue("AMEND_NEW_DATE_OF_EXPIRY").trim().equals(""))
				AmendDetailsHistInstance.setAmendhistNewDateOfExpiry(DateToYYYYMMDD(dtoobj.getValue("AMEND_NEW_DATE_OF_EXPIRY")));
			else
				AmendDetailsHistInstance.setAmendhistNewDateOfExpiry(null);
			AmendDetailsHistInstance.setAmendhistIncrDocCrAmt(Double.parseDouble(dtoobj.getValue("AMEND_INCR_DOC_CR_AMT")));
			AmendDetailsHistInstance.setAmendhistDecrDocCrAmt(Double.parseDouble(dtoobj.getValue("AMEND_DECR_DOC_CR_AMT")));
			AmendDetailsHistInstance.setAmendhistNewAddnlAmt(Double.parseDouble(dtoobj.getValue("AMEND_NEW_ADDNL_AMT")));
			AmendDetailsHistInstance.setAmendhistPlaceTakinInChrg(dtoobj.getValue("AMEND_PLACE_TAKIN_IN_CHRG"));
			AmendDetailsHistInstance.setAmendhistPortOfLoading(dtoobj.getValue("AMEND_PORT_OF_LOADING"));
			AmendDetailsHistInstance.setAmendhistPortOfDischarge(dtoobj.getValue("AMEND_PORT_OF_DISCHARGE"));
			AmendDetailsHistInstance.setAmendhistPlaceOfFinalDest(dtoobj.getValue("AMEND_PLACE_OF_FINAL_DEST"));
			if (dtoobj.getValue("AMEND_DATE_OF_SHIPMENT") != null)
				AmendDetailsHistInstance.setAmendhistDateOfShipment(DateToYYYYMMDD(dtoobj.getValue("AMEND_DATE_OF_SHIPMENT")));
			else
				AmendDetailsHistInstance.setAmendhistDateOfShipment(null);
			AmendDetailsHistInstance.setAmendhistDescGoddSer1(dtoobj.getValue("AMEND_DESC_GODD_SER1"));
			AmendDetailsHistInstance.setAmendhistDocReq1(dtoobj.getValue("AMEND_DOC_REQ1"));
			AmendDetailsHistInstance.setAmendhistAddCondition1(dtoobj.getValue("AMEND_ADD_CONDITION1"));

			// NEW FIELDS ADDED BY PRASHANTH ON 08 FEB 2019
			/*
			 * AmendDetailsHistInstance.setAmendhistDescGoddSer2(dtoobj.getValue("AMEND_DESC_GODD_SER2"));
			 * AmendDetailsHistInstance.setAmendhistDocReq2(dtoobj.getValue("AMEND_DOC_REQ2"));
			 * AmendDetailsHistInstance.setAmendhistAddCondition2(dtoobj.getValue("AMEND_ADD_CONDITION2"));
			 * 
			 * 
			 * AmendDetailsHistInstance.setAmendhistDescGoddSer3(dtoobj.getValue("AMEND_DESC_GODD_SER3"));
			 * AmendDetailsHistInstance.setAmendhistDocReq3(dtoobj.getValue("AMEND_DOC_REQ3"));
			 * AmendDetailsHistInstance.setAmendhistAddCondition3(dtoobj.getValue("AMEND_ADD_CONDITION3"));
			 * //NEW FIELDS ADDED BY PRASHANTH ON 08 FEB 2019
			 * 
			 */

			AmendDetailsHistInstance.setAmendhistChrgPayable1(dtoobj.getValue("AMEND_CHRG_PAYABLE1"));
			AmendDetailsHistInstance.setAmendhistChrgPayable2(dtoobj.getValue("AMEND_CHRG_PAYABLE2"));
			AmendDetailsHistInstance.setAmendhistChrgPayable3(dtoobj.getValue("AMEND_CHRG_PAYABLE3"));
			AmendDetailsHistInstance.setAmendhistChrgPayable4(dtoobj.getValue("AMEND_CHRG_PAYABLE4"));
			AmendDetailsHistInstance.setAmendhistChrgPayable5(dtoobj.getValue("AMEND_CHRG_PAYABLE5"));
			AmendDetailsHistInstance.setAmendhistChrgPayable6(dtoobj.getValue("AMEND_CHRG_PAYABLE6"));
			/*AmendDetailsHistInstance.setAmendhistNewPrdPresntDay(dtoobj.getValue("AMEND_NEW_PRD_PRESNT_DAY"));
			AmendDetailsHistInstance.setAmendhistNewConfirmInstr(dtoobj.getValue("AMEND_NEW_CONFIRM_INSTR"));
			AmendDetailsHistInstance.setAmendhistSplPayBenficiary(dtoobj.getValue("AMEND_SPL_PAY_BENFICIARY"));
			AmendDetailsHistInstance.setAmendhistSplPayRecBnk(dtoobj.getValue("AMEND_SPL_PAY_REC_BNK"));
			AmendDetailsHistInstance.setAmendhistInstrTopaying1(dtoobj.getValue("AMEND_INSTR_TOPAYING1"));
			AmendDetailsHistInstance.setAmendhistInstrTopaying2(dtoobj.getValue("AMEND_INSTR_TOPAYING2"));
			AmendDetailsHistInstance.setAmendhistInstrTopaying3(dtoobj.getValue("AMEND_INSTR_TOPAYING3"));
			AmendDetailsHistInstance.setAmendhistInstrTopaying4(dtoobj.getValue("AMEND_INSTR_TOPAYING4"));
			AmendDetailsHistInstance.setAmendhistInstrTopaying5(dtoobj.getValue("AMEND_INSTR_TOPAYING5"));
			AmendDetailsHistInstance.setAmendhistInstrTopaying6(dtoobj.getValue("AMEND_INSTR_TOPAYING6"));
			AmendDetailsHistInstance.setAmendhistInstrTopaying7(dtoobj.getValue("AMEND_INSTR_TOPAYING7"));
			AmendDetailsHistInstance.setAmendhistInstrTopaying8(dtoobj.getValue("AMEND_INSTR_TOPAYING8"));
			AmendDetailsHistInstance.setAmendhistInstrTopaying9(dtoobj.getValue("AMEND_INSTR_TOPAYING9"));
			AmendDetailsHistInstance.setAmendhistInstrTopaying10(dtoobj.getValue("AMEND_INSTR_TOPAYING10"));
			AmendDetailsHistInstance.setAmendhistInstrTopaying11(dtoobj.getValue("AMEND_INSTR_TOPAYING11"));
			AmendDetailsHistInstance.setAmendhistInstrTopaying12(dtoobj.getValue("AMEND_INSTR_TOPAYING12"));
			*/
			AmendDetailsHistInstance.setAmendhistSndrRecInfo1(dtoobj.getValue("AMEND_SNDR_REC_INFO1"));
			AmendDetailsHistInstance.setAmendhistSndrRecInfo2(dtoobj.getValue("AMEND_SNDR_REC_INFO2"));
			AmendDetailsHistInstance.setAmendhistSndrRecInfo3(dtoobj.getValue("AMEND_SNDR_REC_INFO3"));
			AmendDetailsHistInstance.setAmendhistSndrRecInfo4(dtoobj.getValue("AMEND_SNDR_REC_INFO4"));
			AmendDetailsHistInstance.setAmendhistSndrRecInfo5(dtoobj.getValue("AMEND_SNDR_REC_INFO5"));
			AmendDetailsHistInstance.setAmendhistSndrRecInfo6(dtoobj.getValue("AMEND_SNDR_REC_INFO6"));
			//Changes Sanjay1 18-07-2019 Begin
			//AmendDetailsHistInstance.setAmendhistNarrative(dtoobj.getValue("AMEND_NARRATIVE"));
			//AmendDetailsHistInstance.setAmdhistLcApplRules(stringToChar(dtoobject.getValue("AMEND_LC_APPLICANT_RULES")));
			//Changes Sanjay1 18-07-2019 End
			AmendDetailsHistInstance.setAmendhistChkbox(dtoobj.getValue("AMEND_CHKBOX"));
			AmendDetailsHistInstance.setAmendhistAdvisingCntry(dtoobj.getValue("AMEND_ADVISING_CNTRY"));
			AmendDetailsHistInstance.setAmendhistSecondAdvCntry(dtoobj.getValue("AMEND_SECOND_ADV_CNTRY"));
			// AmendDetailsHistInstance.setAmendhistIssueRef(dtoobj.getValue("AMEND_SECOND_ADV_CNTRY"));

			// NEW FIELDS ADDED BY PRASHANTH ON 21 FEB 2019
			AmendDetailsHistInstance.setAmdhistFormOfDocCredit(Integer.parseInt(dtoobject.getValue("AMEND_FORM_OF_DOC_CREDIT")));
			AmendDetailsHistInstance.setAmdhistLcApplicableRules(Integer.parseInt(dtoobject.getValue("AMEND_LC_APPLICABLE_RULES")));
			AmendDetailsHistInstance.setAmdhistLcApplReq(stringToChar(dtoobject.getValue("AMEND_LC_APPLICANT_REQ")));
			AmendDetailsHistInstance.setAmdhistLcApplName(dtoobject.getValue("AMEND_LC_APPLICANT_NAME"));
			AmendDetailsHistInstance.setAmdhistLcApplAddr1(dtoobject.getValue("AMEND_LC_APPLICANT_ADDR1"));
			AmendDetailsHistInstance.setAmdhistLcApplAddr2(dtoobject.getValue("AMEND_LC_APPLICANT_ADDR2"));
			AmendDetailsHistInstance.setAmdhistLcApplAddr3(dtoobject.getValue("AMEND_LC_APPLICANT_ADDR3"));
			AmendDetailsHistInstance.setAmdhistLcApplAddr4(dtoobject.getValue("AMEND_LC_APPLICANT_ADDR4"));
			AmendDetailsHistInstance.setAmdhistLcApplAddr5(dtoobject.getValue("AMEND_LC_APPLICANT_ADDR5"));
			AmendDetailsHistInstance.setAmdhistLcAvlWithType(stringToChar(dtoobject.getValue("AMEND_LC_AVL_WITH_TYPE")));
			//Changes Sanjay1 18-07-2019 Begin
            AmendDetailsHistInstance.setAmdhistLcAvlWithBicCode(dtoobject.getValue("AMEND_LC_AVL_WITH_BIC_CODE"));
          //Changes Sanjay1 18-07-2019 End
			AmendDetailsHistInstance.setAmdhistLcAvlWithBrnCode(dtoobject.getValue("AMEND_LC_AVL_WITH_BRN_CODE"));
			AmendDetailsHistInstance.setAmdhistLcLcAvlWithRoutid(dtoobject.getValue("AMEND_LC_LC_AVL_WITH_ROUTID"));
			AmendDetailsHistInstance.setAmdhistLcAvlWithBnkCode(dtoobject.getValue("AMEND_LC_AVL_WITH_BNK_CODE"));
			AmendDetailsHistInstance.setAmdhistLcAvlWithAddr1(dtoobject.getValue("AMEND_LC_AVL_WITH_ADDR1"));
			AmendDetailsHistInstance.setAmdhistLcAvlWithAddr2(dtoobject.getValue("AMEND_LC_AVL_WITH_ADDR2"));
			AmendDetailsHistInstance.setAmdhistLcAvlWithAddr3(dtoobject.getValue("AMEND_LC_AVL_WITH_ADDR3"));
			AmendDetailsHistInstance.setAmdhistLcAvlWithAddr4(dtoobject.getValue("AMEND_LC_AVL_WITH_ADDR4"));
			AmendDetailsHistInstance.setAmdhistLcAvlWithAddr5(dtoobject.getValue("AMEND_LC_AVL_WITH_ADDR5"));

			//

			AmendDetailsHistInstance.setAmdhistLcAvlWithCntry(dtoobject.getValue("AMEND_LC_AVL_WITH_CNTRY"));

			//

			AmendDetailsHistInstance.setAmdhistLcDraftsAt1(dtoobject.getValue("AMEND_LC_DRAFTS_AT1"));
			AmendDetailsHistInstance.setAmdhistLcDraftsAt2(dtoobject.getValue("AMEND_LC_DRAFTS_AT2"));
			AmendDetailsHistInstance.setAmdhistLcDraftsAt3(dtoobject.getValue("AMEND_LC_DRAFTS_AT3"));
			AmendDetailsHistInstance.setAmdhistLcDraweeReq(stringToChar(dtoobject.getValue("AMEND_LC_DRAWEE_REQ")));
			AmendDetailsHistInstance.setAmdhistLcDraweeType(stringToChar(dtoobject.getValue("AMEND_LC_DRAWEE_TYPE")));
			AmendDetailsHistInstance.setAmdhistLcDraweeBrnCode(dtoobject.getValue("AMEND_LC_DRAWEE_BRN_CODE"));
			AmendDetailsHistInstance.setAmdhistLcDraweeBicCode(dtoobject.getValue("AMEND_LC_DRAWEE_BIC_CODE"));
			AmendDetailsHistInstance.setAmdhistLcDraweeRoutid(dtoobject.getValue("AMEND_LC_DRAWEE_ROUTID"));
			AmendDetailsHistInstance.setAmdhistLcDraweeBnkCode(dtoobject.getValue("AMEND_LC_DRAWEE_BNK_CODE"));
			AmendDetailsHistInstance.setAmdhistLcDraweeAddr1(dtoobject.getValue("AMEND_LC_DRAWEE_ADDR1"));
			AmendDetailsHistInstance.setAmdhistLcDraweeAddr2(dtoobject.getValue("AMEND_LC_DRAWEE_ADDR2"));
			AmendDetailsHistInstance.setAmdhistLcDraweeAddr3(dtoobject.getValue("AMEND_LC_DRAWEE_ADDR3"));
			AmendDetailsHistInstance.setAmdhistLcDraweeAddr4(dtoobject.getValue("AMEND_LC_DRAWEE_ADDR4"));
			AmendDetailsHistInstance.setAmdhistLcDraweeAddr5(dtoobject.getValue("AMEND_LC_DRAWEE_ADDR5"));
			//
			AmendDetailsHistInstance.setAmdhistDraweeCntryCode(dtoobject.getValue("AMEND_DRAWEE_CNTRY_CODE"));
			//
			AmendDetailsHistInstance.setAmdhistLcMixedPayDetails1(dtoobject.getValue("AMEND_LC_MIXED_PAY_DETAILS1"));
			AmendDetailsHistInstance.setAmdhistLcMixedPayDetails2(dtoobject.getValue("AMEND_LC_MIXED_PAY_DETAILS2"));
			AmendDetailsHistInstance.setAmdhistLcMixedPayDetails3(dtoobject.getValue("AMEND_LC_MIXED_PAY_DETAILS3"));
			AmendDetailsHistInstance.setAmdhistLcMixedPayDetails4(dtoobject.getValue("AMEND_LC_MIXED_PAY_DETAILS4"));
			AmendDetailsHistInstance.setAmdhistLcMixedPayDetails5(dtoobject.getValue("AMEND_LC_MIXED_PAY_DETAILS5"));
			AmendDetailsHistInstance.setAmdhistLcDefPayDetails1(dtoobject.getValue("AMEND_LC_DEFERRED_PAY_DETAILS1"));
			AmendDetailsHistInstance.setAmdhistLcDefPayDetails2(dtoobject.getValue("AMEND_LC_DEFERRED_PAY_DETAILS2"));
			AmendDetailsHistInstance.setAmdhistLcDefPayDetails3(dtoobject.getValue("AMEND_LC_DEFERRED_PAY_DETAILS3"));
			AmendDetailsHistInstance.setAmdhistLcDefPayDetails4(dtoobject.getValue("AMEND_LC_DEFERRED_PAY_DETAILS4"));
			AmendDetailsHistInstance.setAmdhistLcDefPayDetails5(dtoobject.getValue("AMEND_LC_DEFERRED_PAY_DETAILS5"));
			AmendDetailsHistInstance.setAmdhistLcPartialShipments(Integer.parseInt(dtoobject.getValue("AMEND_LC_PARTIAL_SHIPMENTS")));
			AmendDetailsHistInstance.setAmdhistLcTranshipment(Integer.parseInt(dtoobject.getValue("AMEND_LC_TRANSHIPMENT")));
			if(!dtoobject.getValue("AMEND_LC_CONFIRMATION_INST").equals("")){
			AmendDetailsHistInstance.setAmdhistLcConfirmationInst(Integer.parseInt(dtoobject.getValue("AMEND_LC_CONFIRMATION_INST")));
			}
			//Changes Sanjay1 18-07-2019 Begin
			//AmendDetailsHistInstance.setAmdhistLcCnfByBank(dtoobject.getValue("AMEND_LC_CNF_BY_BANK"));
			//AmendDetailsHistInstance.setAmdhistLcCnfByBrn(Integer.parseInt(dtoobject.getValue("AMEND_LC_CNF_BY_BRN")));
			//Changes Sanjay1 18-07-2019 End
			AmendDetailsHistInstance.setAmdhistLcReimbReq(stringToChar(dtoobject.getValue("AMEND_LC_REIMB_REQ")));
			AmendDetailsHistInstance.setAmdhistLcReimbType(stringToChar(dtoobject.getValue("AMEND_LC_REIMB_TYPE")));
			AmendDetailsHistInstance.setAmdhistLcReimbBrnCode(dtoobject.getValue("AMEND_LC_REIMB_BRN_CODE"));
			AmendDetailsHistInstance.setAmdhistLcReimbBicCode(dtoobject.getValue("AMEND_LC_REIMB_BIC_CODE"));
			AmendDetailsHistInstance.setAmdhistLcReimbRoutid(dtoobject.getValue("AMEND_LC_REIMB_ROUTID"));
			AmendDetailsHistInstance.setAmdhistLcReimbBnkCode(dtoobject.getValue("AMEND_LC_REIMB_BNK_CODE"));
			AmendDetailsHistInstance.setAmdhistLcReimbAddr1(dtoobject.getValue("AMEND_LC_REIMB_ADDR1"));
			AmendDetailsHistInstance.setAmdhistLcReimbAddr2(dtoobject.getValue("AMEND_LC_REIMB_ADDR2"));
			AmendDetailsHistInstance.setAmdhistLcReimbAddr3(dtoobject.getValue("AMEND_LC_REIMB_ADDR3"));
			AmendDetailsHistInstance.setAmdhistLcReimbAddr4(dtoobject.getValue("AMEND_LC_REIMB_ADDR4"));
			AmendDetailsHistInstance.setAmdhistLcReimbAddr5(dtoobject.getValue("AMEND_LC_REIMB_ADDR5"));
			AmendDetailsHistInstance.setAmdhistLcInstPaying1(dtoobject.getValue("AMEND_LC_INST_PAYING1"));
			/*
			 * FIELDS MISSING AMDHIST_LC_INST_PAYING2 TO
			 * AMDHIST_LC_INST_PAYING10
			 */

			AmendDetailsHistInstance.setAmdhistLcInstPaying2(dtoobject.getValue("AMEND_LC_INST_PAYING2"));
			AmendDetailsHistInstance.setAmdhistLcInstPaying3(dtoobject.getValue("AMEND_LC_INST_PAYING3"));
			AmendDetailsHistInstance.setAmdhistLcInstPaying4(dtoobject.getValue("AMEND_LC_INST_PAYING4"));
			AmendDetailsHistInstance.setAmdhistLcInstPaying5(dtoobject.getValue("AMEND_LC_INST_PAYING5"));
			AmendDetailsHistInstance.setAmdhistLcInstPaying6(dtoobject.getValue("AMEND_LC_INST_PAYING6"));
			AmendDetailsHistInstance.setAmdhistLcInstPaying7(dtoobject.getValue("AMEND_LC_INST_PAYING7"));
			AmendDetailsHistInstance.setAmdhistLcInstPaying8(dtoobject.getValue("AMEND_LC_INST_PAYING8"));
			AmendDetailsHistInstance.setAmdhistLcInstPaying9(dtoobject.getValue("AMEND_LC_INST_PAYING9"));
			AmendDetailsHistInstance.setAmdhistLcInstPaying10(dtoobject.getValue("AMEND_LC_INST_PAYING10"));
			AmendDetailsHistInstance.setAmdhistLcInstPaying11(dtoobject.getValue("AMEND_LC_INST_PAYING11"));
			AmendDetailsHistInstance.setAmdhistLcInstPaying12(dtoobject.getValue("AMEND_LC_INST_PAYING12"));

			/*
			 * FIELDS MISSING AMDHIST_LC_INST_PAYING2 TO
			 * AMDHIST_LC_INST_PAYING10
			 */

			AmendDetailsHistInstance.setAmdhistLcSecondAdvReq(stringToChar(dtoobject.getValue("AMEND_LC_SECOND_ADV_REQ")));
			AmendDetailsHistInstance.setAmdhistLcSecondAdvType(stringToChar(dtoobject.getValue("AMEND_LC_SECOND_ADV_TYPE")));
			AmendDetailsHistInstance.setAmdhistLcSecondAdvBrnCode(dtoobject.getValue("AMEND_LC_SECOND_ADV_BRN_CODE"));
			AmendDetailsHistInstance.setAmdhistLcSecondAdvBicCode(dtoobject.getValue("AMEND_LC_SECOND_ADV_BIC_CODE"));
			AmendDetailsHistInstance.setAmdhistLcSecondAdvRoutid(dtoobject.getValue("AMEND_LC_SECOND_ADV_ROUTID"));
			AmendDetailsHistInstance.setAmdhistLcSecondAdvBnkCode(dtoobject.getValue("AMEND_LC_SECOND_ADV_BNK_CODE"));
			AmendDetailsHistInstance.setAmdhistLcSecondAdvAddr1(dtoobject.getValue("AMEND_LC_SECOND_ADV_ADDR1"));
			AmendDetailsHistInstance.setAmdhistLcSecondAdvAddr2(dtoobject.getValue("AMEND_LC_SECOND_ADV_ADDR2"));
			AmendDetailsHistInstance.setAmdhistLcSecondAdvAddr3(dtoobject.getValue("AMEND_LC_SECOND_ADV_ADDR3"));
			AmendDetailsHistInstance.setAmdhistLcSecondAdvAddr4(dtoobject.getValue("AMEND_LC_SECOND_ADV_ADDR4"));
			AmendDetailsHistInstance.setAmdhistLcSecondAdvAddr5(dtoobject.getValue("AMEND_LC_SECOND_ADV_ADDR5"));
			//Changes Sanjay1 18-07-2019 Begin
			AmendDetailsHistInstance.setAmendhistLcCnfAdvType(stringToChar(dtoobject.getValue("AMENDHIST_LC_CNF_ADV_TYPE")));
            AmendDetailsHistInstance.setAmendhistLcCnfAdvBrnCode(dtoobject.getValue("AMENDHIST_LC_CNF_ADV_BRN_CODE"));
            AmendDetailsHistInstance.setAmendhistLcCnfAdvBicCode(dtoobject.getValue("AMENDHIST_LC_CNF_ADV_BIC_CODE"));
            AmendDetailsHistInstance.setAmendhistLcCnfAdvRoutid(dtoobject.getValue("AMENDHIST_LC_CNF_ADV_ROUTID"));
            AmendDetailsHistInstance.setAmendhistLcCnfAdvBnkCode(dtoobject.getValue("AMENDHIST_LC_CNF_ADV_BNK_CODE"));
            AmendDetailsHistInstance.setAmendhistLcCnfAdvAddr1(dtoobject.getValue("AMENDHIST_LC_CNF_ADV_ADDR1"));
            AmendDetailsHistInstance.setAmendhistLcCnfAdvAddr2(dtoobject.getValue("AMENDHIST_LC_CNF_ADV_ADDR2"));
            AmendDetailsHistInstance.setAmendhistLcCnfAdvAddr3(dtoobject.getValue("AMENDHIST_LC_CNF_ADV_ADDR3"));
            AmendDetailsHistInstance.setAmendhistLcCnfAdvAddr4(dtoobject.getValue("AMENDHIST_LC_CNF_ADV_ADDR4"));
            AmendDetailsHistInstance.setAmendhistLcCnfAdvAddr5(dtoobject.getValue("AMENDHIST_LC_CNF_ADV_ADDR5"));
            AmendDetailsHistInstance.setAmendhistLcCnfAdvCntrycode(dtoobject.getValue("AMENDHIST_LC_CNF_ADV_CNTRYCODE"));
          //Changes Sanjay1 18-07-2019 End
			// NEW FIELDS

			//
			AmendDetailsHistInstance.setAmdhistLcSecAdvCntrycode(dtoobject.getValue("AMEND_LC_SECOND_ADV_CNTRYCODE"));
			//

            AmendDetailsHistInstance.setAmendHistLcAvlWithCodetyp(stringToChar(dtoobject.getValue("AMEND_LC_AVL_WITH_CODETYP")));
            
            AmendDetailsHistInstance.setAmendhistLcReimbCntryCode(dtoobject.getValue("AMEND_LC_REIMB_CNTRY_CODE"));

            
            
            
            
			AmendDetailsHistInstance.setIsNew(true);
			AmendDetailsHistManagerInstance.save(AmendDetailsHistInstance, TBAAUTH_MAIN_PK, TBAAUTH_ENTRY_DATE, TBAAUTH_DTL_SL);
		} catch (Exception e) {
			throw new PanaceaException(e.getLocalizedMessage());
		}
	}

	private void setSerialNumber(DTObject dtoobject) throws PanaceaException {

		try {
			AmendDetailsHist amendhist = null;
			AmendDetailsHistManager amendmangrhist = new AmendDetailsHistManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);
			amendhist = amendmangrhist.loadByKey(DateToYYYYMMDD(dtoobj.getValue("CBD")), Integer.parseInt(dtoobj.getValue("OLCA_AMD_SL")), Integer.parseInt(dtoobj.getValue("OLCA_BRN_CODE")), Integer.parseInt(dtoobj.getValue("OLCA_LC_SL")), dtoobj.getValue("OLCA_LC_TYPE"), Integer.parseInt(dtoobj.getValue("OLCA_LC_YEAR")));
			if (amendhist != null) {
				max_sl = amendmangrhist.GetMaxSl(DateToYYYYMMDD(dtoobj.getValue("CBD")), Integer.parseInt(dtoobj.getValue("OLCA_AMD_SL")), Integer.parseInt(dtoobj.getValue("OLCA_BRN_CODE")), Integer.parseInt(dtoobj.getValue("OLCA_LC_SL")), dtoobj.getValue("OLCA_LC_TYPE"), Integer.parseInt(dtoobj.getValue("OLCA_LC_YEAR")));
			} else {
				max_sl = 1;

			}
			ReturnResult.setValue("REQ_DAY_SL", String.valueOf(max_sl));
			dtoobj.setValue("REQ_DAY_SL", max_sl + "");

		} catch (Exception e) {
			throw new PanaceaException(e.getLocalizedMessage());
		}
	}

	// Chnages in EOLCAMD on 16-Oct-2018 end

	// ADDED BY PRASHANTH ON 22 FEB 2019

	private void DeleteRecordAmdChoice(DTObject dtoobject) throws PanaceaException {
		Olcamdchoice OlcamdchoiceInstance = new Olcamdchoice();
		OlcamdchoiceManager OlcamdchoiceManagerInstance = new OlcamdchoiceManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);
		try {
			OlcamdchoiceManagerInstance.deleteByKey(Integer.parseInt(dtoobject.getValue("OLCA_AMD_SL")),Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")),0,"45B",Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")),dtoobject.getValue("OLCA_LC_TYPE"),Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")));
			OlcamdchoiceManagerInstance.deleteByKey(Integer.parseInt(dtoobject.getValue("OLCA_AMD_SL")),Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")),0,"46B",Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")),dtoobject.getValue("OLCA_LC_TYPE"),Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")));
			OlcamdchoiceManagerInstance.deleteByKey(Integer.parseInt(dtoobject.getValue("OLCA_AMD_SL")),Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")),0,"47B",Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")),dtoobject.getValue("OLCA_LC_TYPE"),Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")));
			OlcamdchoiceManagerInstance.deleteByKey(Integer.parseInt(dtoobject.getValue("OLCA_AMD_SL")),Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")),0,"49M",Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")),dtoobject.getValue("OLCA_LC_TYPE"),Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")));
			OlcamdchoiceManagerInstance.deleteByKey(Integer.parseInt(dtoobject.getValue("OLCA_AMD_SL")),Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")),0,"49N",Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")),dtoobject.getValue("OLCA_LC_TYPE"),Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")));
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	private void DeleteaddRecordOlcTxtLogInstance(DTObject dtoobject) throws PanaceaException {
		Olcamdtextlog OlcamdtextlogInstance = new Olcamdtextlog();
		OlcamdtextlogManager OlcamdtextlogManagerInstance = new OlcamdtextlogManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);
		try {
			OlcamdtextlogManagerInstance.deleteByKey(Integer.parseInt(dtoobject.getValue("OLCA_AMD_SL")),Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")),0,"45B",Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")),dtoobject.getValue("OLCA_LC_TYPE"),Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")),0);
			OlcamdtextlogManagerInstance.deleteByKey(Integer.parseInt(dtoobject.getValue("OLCA_AMD_SL")),Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")),0,"46B",Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")),dtoobject.getValue("OLCA_LC_TYPE"),Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")),0);
			OlcamdtextlogManagerInstance.deleteByKey(Integer.parseInt(dtoobject.getValue("OLCA_AMD_SL")),Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")),0,"47B",Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")),dtoobject.getValue("OLCA_LC_TYPE"),Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")),0);
			OlcamdtextlogManagerInstance.deleteByKey(Integer.parseInt(dtoobject.getValue("OLCA_AMD_SL")),Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")),0,"49M",Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")),dtoobject.getValue("OLCA_LC_TYPE"),Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")),0);
			OlcamdtextlogManagerInstance.deleteByKey(Integer.parseInt(dtoobject.getValue("OLCA_AMD_SL")),Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")),0,"49N",Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")),dtoobject.getValue("OLCA_LC_TYPE"),Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")),0);
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	private void DeleteaddRecordOlcAmdtext(DTObject dtoobject) throws PanaceaException {
		Olcamdtext OlcamdtextInstance = new Olcamdtext();
		OlcamdtextManager OlcamdtextManagerInstance = new OlcamdtextManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);
		try {
			OlcamdtextManagerInstance.deleteByKey(Integer.parseInt(dtoobject.getValue("OLCA_AMD_SL")),Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")),"45B",Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")),dtoobject.getValue("OLCA_LC_TYPE"),Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")),0);
			OlcamdtextManagerInstance.deleteByKey(Integer.parseInt(dtoobject.getValue("OLCA_AMD_SL")),Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")),"46B",Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")),dtoobject.getValue("OLCA_LC_TYPE"),Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")),0);
			OlcamdtextManagerInstance.deleteByKey(Integer.parseInt(dtoobject.getValue("OLCA_AMD_SL")),Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")),"47B",Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")),dtoobject.getValue("OLCA_LC_TYPE"),Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")),0);
			OlcamdtextManagerInstance.deleteByKey(Integer.parseInt(dtoobject.getValue("OLCA_AMD_SL")),Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")),"49M",Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")),dtoobject.getValue("OLCA_LC_TYPE"),Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")),0);
			OlcamdtextManagerInstance.deleteByKey(Integer.parseInt(dtoobject.getValue("OLCA_AMD_SL")),Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")),"49N",Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")),dtoobject.getValue("OLCA_LC_TYPE"),Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")),0);
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	
	
	
	
	
	
	private void addRecordAmdChoice(DTObject dtoobject) throws PanaceaException {
		try {
			String choiceGoods[];
			String choiceDoc[];
			String choiceAddl[];
			String choiceSplCond1[];
			String choiceSplCond2[];

			int choiceGoodsLength = dtoobject.getValue("OLCAMDGOODSCHOICE").split("\\|").length;
			int choiceDocLength = dtoobject.getValue("OLCAMDDOCSCHOICE").split("\\|").length;
			int choiceAddlLength = dtoobject.getValue("OLCAMDADDLCHOICE").split("\\|").length;
			int choiceSplCond1Length = dtoobject.getValue("OLCAMDSPLCOND1CHOICE").split("\\|").length;
			int choiceSplCond2Length = dtoobject.getValue("OLCAMDSPLCOND2CHOICE").split("\\|").length;

			choiceGoods = dtoobject.getValue("OLCAMDGOODSCHOICE").split("\\|");
			choiceDoc = dtoobject.getValue("OLCAMDDOCSCHOICE").split("\\|");
			choiceAddl = dtoobject.getValue("OLCAMDADDLCHOICE").split("\\|");
			choiceSplCond1 = dtoobject.getValue("OLCAMDSPLCOND1CHOICE").split("\\|");
			choiceSplCond2 = dtoobject.getValue("OLCAMDSPLCOND2CHOICE").split("\\|");
			String amdChoice = "";
			String fromRange = "";
			String uptoRange = "";

			if (!dtoobject.getValue("OLCAMDGOODSCHOICE").trim().equals("")) {// for goods
				Olcamdchoice OlcamdchoiceInstance = new Olcamdchoice();
				OlcamdchoiceManager OlcamdchoiceManagerInstance = new OlcamdchoiceManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);
				for (int i = 0; i < choiceGoodsLength; i++) {
					OlcamdchoiceInstance.setOlcacBrnCode(Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")));
					OlcamdchoiceInstance.setOlcacLcType(dtoobject.getValue("OLCA_LC_TYPE"));
					OlcamdchoiceInstance.setOlcacLcYear(Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")));
					OlcamdchoiceInstance.setOlcacLcSl(Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")));
					OlcamdchoiceInstance.setOlcacAmdSl(Integer.parseInt(dtoobject.getValue("OLCA_AMD_SL")));
					amdChoice = String.valueOf(choiceGoods[i].split("\\,")[3]);
					fromRange = String.valueOf(choiceGoods[i].split("\\,")[1]);
					uptoRange = String.valueOf(choiceGoods[i].split("\\,")[2]);

					OlcamdchoiceInstance.setOlcacFieldType("45B");
					OlcamdchoiceInstance.setOlcacChoiceSl(i+1);
					OlcamdchoiceInstance.setOlcacAmdChoice(stringToChar(amdChoice));
					if (!fromRange.equals("")) {
						OlcamdchoiceInstance.setOlcacAmdRangeFrom(Integer.parseInt(fromRange));
					}
					else{
						OlcamdchoiceInstance.setOlcacAmdRangeFrom(Integer.parseInt("0"));
					}
					if (!uptoRange.equals("")) {
						OlcamdchoiceInstance.setOlcacAmdRangeUpto(Integer.parseInt(uptoRange));
					}
					else{
						OlcamdchoiceInstance.setOlcacAmdRangeUpto(Integer.parseInt("0"));
					}
					OlcamdchoiceInstance.setIsNew(true);
					OlcamdchoiceManagerInstance.save(OlcamdchoiceInstance, TBAAUTH_MAIN_PK, TBAAUTH_ENTRY_DATE, TBAAUTH_DTL_SL);
				}

				
			}
			if (!dtoobject.getValue("OLCAMDDOCSCHOICE").trim().equals("")) {// for doc
				Olcamdchoice OlcamdchoiceInstance = new Olcamdchoice();
				OlcamdchoiceManager OlcamdchoiceManagerInstance = new OlcamdchoiceManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);
				for (int i = 0; i < choiceDocLength; i++) {
					OlcamdchoiceInstance.setOlcacBrnCode(Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")));
					OlcamdchoiceInstance.setOlcacLcType(dtoobject.getValue("OLCA_LC_TYPE"));
					OlcamdchoiceInstance.setOlcacLcYear(Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")));
					OlcamdchoiceInstance.setOlcacLcSl(Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")));
					OlcamdchoiceInstance.setOlcacAmdSl(Integer.parseInt(dtoobject.getValue("OLCA_AMD_SL")));
					amdChoice = String.valueOf(choiceDoc[i].split("\\,")[3]);
					fromRange = String.valueOf(choiceDoc[i].split("\\,")[1]);
					uptoRange = String.valueOf(choiceDoc[i].split("\\,")[2]);


					OlcamdchoiceInstance.setOlcacFieldType("46B");
					OlcamdchoiceInstance.setOlcacChoiceSl(i+1);
					OlcamdchoiceInstance.setOlcacAmdChoice(stringToChar(amdChoice));
					if (!fromRange.equals("")) {
						OlcamdchoiceInstance.setOlcacAmdRangeFrom(Integer.parseInt(fromRange));
					}
					else{
						OlcamdchoiceInstance.setOlcacAmdRangeFrom(Integer.parseInt("0"));
					}
					if (!uptoRange.equals("")) {
						OlcamdchoiceInstance.setOlcacAmdRangeUpto(Integer.parseInt(uptoRange));
					}
					else{
						OlcamdchoiceInstance.setOlcacAmdRangeUpto(Integer.parseInt("0"));
					}
					OlcamdchoiceInstance.setIsNew(true);
					OlcamdchoiceManagerInstance.save(OlcamdchoiceInstance, TBAAUTH_MAIN_PK, TBAAUTH_ENTRY_DATE, TBAAUTH_DTL_SL);
				}

				
			}

			if (!dtoobject.getValue("OLCAMDADDLCHOICE").trim().equals("")) {// for addl
				Olcamdchoice OlcamdchoiceInstance = new Olcamdchoice();
				OlcamdchoiceManager OlcamdchoiceManagerInstance = new OlcamdchoiceManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);

				for (int i = 0; i < choiceAddlLength; i++) {
					OlcamdchoiceInstance.setOlcacBrnCode(Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")));
					OlcamdchoiceInstance.setOlcacLcType(dtoobject.getValue("OLCA_LC_TYPE"));
					OlcamdchoiceInstance.setOlcacLcYear(Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")));
					OlcamdchoiceInstance.setOlcacLcSl(Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")));
					OlcamdchoiceInstance.setOlcacAmdSl(Integer.parseInt(dtoobject.getValue("OLCA_AMD_SL")));
					
					amdChoice = String.valueOf(choiceAddl[i].split("\\,")[3]);
					fromRange = String.valueOf(choiceAddl[i].split("\\,")[1]);
					uptoRange = String.valueOf(choiceAddl[i].split("\\,")[2]);


					OlcamdchoiceInstance.setOlcacFieldType("47B");
					OlcamdchoiceInstance.setOlcacChoiceSl(i+1);
					OlcamdchoiceInstance.setOlcacAmdChoice(stringToChar(amdChoice));
					if (!fromRange.equals("")) {
						OlcamdchoiceInstance.setOlcacAmdRangeFrom(Integer.parseInt(fromRange));
					}
					else{
						OlcamdchoiceInstance.setOlcacAmdRangeFrom(Integer.parseInt("0"));
					}
					if (!uptoRange.equals("")) {
						OlcamdchoiceInstance.setOlcacAmdRangeUpto(Integer.parseInt(uptoRange));
					}
					else{
						OlcamdchoiceInstance.setOlcacAmdRangeUpto(Integer.parseInt("0"));
					}

					OlcamdchoiceInstance.setIsNew(true);
					OlcamdchoiceManagerInstance.save(OlcamdchoiceInstance, TBAAUTH_MAIN_PK, TBAAUTH_ENTRY_DATE, TBAAUTH_DTL_SL);
				}

			}

			if (!dtoobject.getValue("OLCAMDSPLCOND1CHOICE").trim().equals("")) {// for spl cond 1
				Olcamdchoice OlcamdchoiceInstance = new Olcamdchoice();
				OlcamdchoiceManager OlcamdchoiceManagerInstance = new OlcamdchoiceManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);
				for (int i = 0; i < choiceSplCond1Length; i++) {
					OlcamdchoiceInstance.setOlcacBrnCode(Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")));
					OlcamdchoiceInstance.setOlcacLcType(dtoobject.getValue("OLCA_LC_TYPE"));
					OlcamdchoiceInstance.setOlcacLcYear(Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")));
					OlcamdchoiceInstance.setOlcacLcSl(Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")));
					OlcamdchoiceInstance.setOlcacAmdSl(Integer.parseInt(dtoobject.getValue("OLCA_AMD_SL")));
					amdChoice = String.valueOf(choiceSplCond1[i].split("\\,")[2]);
					fromRange = String.valueOf(choiceSplCond1[i].split("\\,")[1]);
					uptoRange = String.valueOf(choiceSplCond1[i].split("\\,")[0]);

					OlcamdchoiceInstance.setOlcacFieldType("49M");
					OlcamdchoiceInstance.setOlcacChoiceSl(i+1);
					OlcamdchoiceInstance.setOlcacAmdChoice(stringToChar(amdChoice));
					if (!fromRange.equals("")) {
						OlcamdchoiceInstance.setOlcacAmdRangeFrom(Integer.parseInt(fromRange));
					}
					else{
						OlcamdchoiceInstance.setOlcacAmdRangeFrom(Integer.parseInt("0"));
					}
					if (!uptoRange.equals("")) {
						OlcamdchoiceInstance.setOlcacAmdRangeUpto(Integer.parseInt(uptoRange));
					}
					else{
						OlcamdchoiceInstance.setOlcacAmdRangeUpto(Integer.parseInt("0"));
					}
					OlcamdchoiceInstance.setIsNew(true);
					OlcamdchoiceManagerInstance.save(OlcamdchoiceInstance, TBAAUTH_MAIN_PK, TBAAUTH_ENTRY_DATE, TBAAUTH_DTL_SL);
				}
			}

			if (!dtoobject.getValue("OLCAMDSPLCOND2CHOICE").trim().equals("")) {// for spl cond 2
				Olcamdchoice OlcamdchoiceInstance = new Olcamdchoice();
				OlcamdchoiceManager OlcamdchoiceManagerInstance = new OlcamdchoiceManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);
				for (int i = 0; i < choiceSplCond2Length; i++) {
					OlcamdchoiceInstance.setOlcacBrnCode(Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")));
					OlcamdchoiceInstance.setOlcacLcType(dtoobject.getValue("OLCA_LC_TYPE"));
					OlcamdchoiceInstance.setOlcacLcYear(Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")));
					OlcamdchoiceInstance.setOlcacLcSl(Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")));
					OlcamdchoiceInstance.setOlcacAmdSl(Integer.parseInt(dtoobject.getValue("OLCA_AMD_SL")));
					amdChoice = String.valueOf(choiceSplCond2[i].split("\\,")[2]);
					fromRange = String.valueOf(choiceSplCond2[i].split("\\,")[1]);
					uptoRange = String.valueOf(choiceSplCond2[i].split("\\,")[0]);
					OlcamdchoiceInstance.setOlcacFieldType("49N");
					OlcamdchoiceInstance.setOlcacChoiceSl(i+1);
					OlcamdchoiceInstance.setOlcacAmdChoice(stringToChar(amdChoice));
					if (!fromRange.equals("")) {
						OlcamdchoiceInstance.setOlcacAmdRangeFrom(Integer.parseInt(fromRange));
					}
					else{
						OlcamdchoiceInstance.setOlcacAmdRangeFrom(Integer.parseInt("0"));
					}
					if (!uptoRange.equals("")) {
						OlcamdchoiceInstance.setOlcacAmdRangeUpto(Integer.parseInt(uptoRange));
					}
					else{
						OlcamdchoiceInstance.setOlcacAmdRangeUpto(Integer.parseInt("0"));
					}
					OlcamdchoiceInstance.setIsNew(true);
					OlcamdchoiceManagerInstance.save(OlcamdchoiceInstance, TBAAUTH_MAIN_PK, TBAAUTH_ENTRY_DATE, TBAAUTH_DTL_SL);
				}
			}

		} catch (Exception e) {
			throw new PanaceaException(e.getLocalizedMessage());
		}
	}

	private void addRecordOlcTxtLogInstance(DTObject dtoobject) throws PanaceaException {
		try {

			String AmendLogGoods[];
			String AmendLogDocs[];
			String AmendLogAddl[];
			String AmendLogSpl1[];
			String AmendLogSpl2[];

			int AmendGoodsLength = dtoobject.getValue("AMENDLOGGOODS").split("\n").length;
			AmendLogGoods = dtoobject.getValue("AMENDLOGGOODS").split("\n\r");
			// AmendLogGoods = String.valueOf(AmendLogGoods).split("\\|");//new add

			int AmendDocsLength = dtoobject.getValue("AMENDLOGDOCS").split("\n").length;
			AmendLogDocs = dtoobject.getValue("AMENDLOGDOCS").split("\n\r");
		//	AmendLogDocs = String.valueOf(AmendLogDocs).split("\\|");//new add


			int AmendAddlLength = dtoobject.getValue("AMENDLOGADDL").split("\n").length;
			AmendLogAddl = dtoobject.getValue("AMENDLOGADDL").split("\n\r");
		//	AmendLogAddl = String.valueOf(AmendLogAddl).split("\\|");//new add

			int AmendSpl1Length = dtoobject.getValue("AMENDLOGSPL1").split("\n").length;
			AmendLogSpl1 = dtoobject.getValue("AMENDLOGSPL1").split("\n\r");
		//	AmendLogSpl1 = String.valueOf(AmendLogSpl1).split("\\|");//new add

			int AmendSpl2Length = dtoobject.getValue("AMENDLOGSPL2").split("\n").length;
			AmendLogSpl2 = dtoobject.getValue("AMENDLOGSPL2").split("\n\r");
		// 	AmendLogSpl2 = String.valueOf(AmendLogSpl2).split("\\|");//new add
			
			
			

			if (!dtoobject.getValue("AMENDLOGGOODS").trim().equals("")) {
				Olcamdtextlog OlcamdtextlogInstance = new Olcamdtextlog();
				OlcamdtextlogManager OlcamdtextlogManagerInstance = new OlcamdtextlogManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);
				for (int i = 0; i < AmendGoodsLength; i++) {
					OlcamdtextlogInstance.setOlcatlBrnCode(Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")));
					OlcamdtextlogInstance.setOlcatlLcType(dtoobject.getValue("OLCA_LC_TYPE"));
					OlcamdtextlogInstance.setOlcatlLcYear(Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")));
					OlcamdtextlogInstance.setOlcatlLcSl(Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")));
					OlcamdtextlogInstance.setOlcatlAmdSl(Integer.parseInt(dtoobject.getValue("OLCA_AMD_SL")));
					
					OlcamdtextlogInstance.setOlcatlFieldType("45B");
				//	OlcamdtextlogInstance.setOlcatlChoiceSl(i+1);
					OlcamdtextlogInstance.setOlcatlLogSl(i+1);
					OlcamdtextlogInstance.setOlcatlText(String.valueOf(AmendLogGoods[0].split("\\r\\n")[i].split("\\|")[0]));
					OlcamdtextlogInstance.setOlcatlChoiceSl(Integer.parseInt(AmendLogGoods[0].split("\\r\\n")[i].split("\\|")[1]));
					OlcamdtextlogInstance.setIsNew(true);
					OlcamdtextlogManagerInstance.save(OlcamdtextlogInstance, TBAAUTH_MAIN_PK, TBAAUTH_ENTRY_DATE, TBAAUTH_DTL_SL);

				}
			}

			if (!dtoobject.getValue("AMENDLOGDOCS").trim().equals("")) {
				Olcamdtextlog OlcamdtextlogInstance = new Olcamdtextlog();
				OlcamdtextlogManager OlcamdtextlogManagerInstance = new OlcamdtextlogManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);
				for (int i = 0; i < AmendDocsLength; i++) {
					OlcamdtextlogInstance.setOlcatlBrnCode(Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")));
					OlcamdtextlogInstance.setOlcatlLcType(dtoobject.getValue("OLCA_LC_TYPE"));
					OlcamdtextlogInstance.setOlcatlLcYear(Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")));
					OlcamdtextlogInstance.setOlcatlLcSl(Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")));
					OlcamdtextlogInstance.setOlcatlAmdSl(Integer.parseInt(dtoobject.getValue("OLCA_AMD_SL")));
					
					OlcamdtextlogInstance.setOlcatlFieldType("46B");
				//	OlcamdtextlogInstance.setOlcatlChoiceSl(i+1);
					OlcamdtextlogInstance.setOlcatlLogSl(i+1);
					OlcamdtextlogInstance.setOlcatlText(String.valueOf(AmendLogDocs[0].split("\\r\\n")[i].split("\\|")[0]));
					OlcamdtextlogInstance.setOlcatlChoiceSl(Integer.parseInt(AmendLogDocs[0].split("\\r\\n")[i].split("\\|")[1]));
					
					
					OlcamdtextlogInstance.setIsNew(true);
					OlcamdtextlogManagerInstance.save(OlcamdtextlogInstance, TBAAUTH_MAIN_PK, TBAAUTH_ENTRY_DATE, TBAAUTH_DTL_SL);

				}
			}

			if (!dtoobject.getValue("AMENDLOGADDL").trim().equals("")) {
				Olcamdtextlog OlcamdtextlogInstance = new Olcamdtextlog();
				OlcamdtextlogManager OlcamdtextlogManagerInstance = new OlcamdtextlogManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);
				for (int i = 0; i < AmendAddlLength; i++) {
					OlcamdtextlogInstance.setOlcatlBrnCode(Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")));
					OlcamdtextlogInstance.setOlcatlLcType(dtoobject.getValue("OLCA_LC_TYPE"));
					OlcamdtextlogInstance.setOlcatlLcYear(Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")));
					OlcamdtextlogInstance.setOlcatlLcSl(Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")));
					OlcamdtextlogInstance.setOlcatlAmdSl(Integer.parseInt(dtoobject.getValue("OLCA_AMD_SL")));

					
					OlcamdtextlogInstance.setOlcatlFieldType("47B");
				//	OlcamdtextlogInstance.setOlcatlChoiceSl(i+1);
					OlcamdtextlogInstance.setOlcatlLogSl(i+1);
					
					OlcamdtextlogInstance.setOlcatlText(String.valueOf(AmendLogAddl[0].split("\\r\\n")[i].split("\\|")[0]));
					OlcamdtextlogInstance.setOlcatlChoiceSl(Integer.parseInt(AmendLogAddl[0].split("\\r\\n")[i].split("\\|")[1]));
					
					OlcamdtextlogInstance.setIsNew(true);
					OlcamdtextlogManagerInstance.save(OlcamdtextlogInstance, TBAAUTH_MAIN_PK, TBAAUTH_ENTRY_DATE, TBAAUTH_DTL_SL);

				}
			}

			if (!dtoobject.getValue("AMENDLOGSPL1").trim().equals("")) {
				Olcamdtextlog OlcamdtextlogInstance = new Olcamdtextlog();
				OlcamdtextlogManager OlcamdtextlogManagerInstance = new OlcamdtextlogManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);

				for (int i = 0; i < AmendSpl1Length; i++) {
					OlcamdtextlogInstance.setOlcatlBrnCode(Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")));
					OlcamdtextlogInstance.setOlcatlLcType(dtoobject.getValue("OLCA_LC_TYPE"));
					OlcamdtextlogInstance.setOlcatlLcYear(Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")));
					OlcamdtextlogInstance.setOlcatlLcSl(Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")));
					OlcamdtextlogInstance.setOlcatlAmdSl(Integer.parseInt(dtoobject.getValue("OLCA_AMD_SL")));
					
					OlcamdtextlogInstance.setOlcatlFieldType("49M");
					OlcamdtextlogInstance.setOlcatlLogSl(i+1);
					
					OlcamdtextlogInstance.setOlcatlText(String.valueOf(AmendLogSpl1[0].split("\\r\\n")[i].split("\\|")[0]));
					OlcamdtextlogInstance.setOlcatlChoiceSl(Integer.parseInt(AmendLogSpl1[0].split("\\r\\n")[i].split("\\|")[1]));
					
					OlcamdtextlogInstance.setIsNew(true);
					OlcamdtextlogManagerInstance.save(OlcamdtextlogInstance, TBAAUTH_MAIN_PK, TBAAUTH_ENTRY_DATE, TBAAUTH_DTL_SL);

				}
			}

			if (!dtoobject.getValue("AMENDLOGSPL2").trim().equals("")) {
				Olcamdtextlog OlcamdtextlogInstance = new Olcamdtextlog();
				OlcamdtextlogManager OlcamdtextlogManagerInstance = new OlcamdtextlogManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);
				for (int i = 0; i < AmendSpl2Length; i++) {
					OlcamdtextlogInstance.setOlcatlBrnCode(Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")));
					OlcamdtextlogInstance.setOlcatlLcType(dtoobject.getValue("OLCA_LC_TYPE"));
					OlcamdtextlogInstance.setOlcatlLcYear(Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")));
					OlcamdtextlogInstance.setOlcatlLcSl(Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")));
					OlcamdtextlogInstance.setOlcatlAmdSl(Integer.parseInt(dtoobject.getValue("OLCA_AMD_SL")));
					
					OlcamdtextlogInstance.setOlcatlFieldType("49N");
					OlcamdtextlogInstance.setOlcatlLogSl(i+1);
					
					OlcamdtextlogInstance.setOlcatlText(String.valueOf(AmendLogSpl2[0].split("\\r\\n")[i].split("\\|")[0]));
					OlcamdtextlogInstance.setOlcatlChoiceSl(Integer.parseInt(AmendLogSpl2[0].split("\\r\\n")[i].split("\\|")[1]));
					
					
					OlcamdtextlogInstance.setIsNew(true);
					OlcamdtextlogManagerInstance.save(OlcamdtextlogInstance, TBAAUTH_MAIN_PK, TBAAUTH_ENTRY_DATE, TBAAUTH_DTL_SL);

				}
			}

		} catch (Exception e) {
			throw new PanaceaException(e.getLocalizedMessage());
		}
	}

	private void addRecordOlcAmdtext(DTObject dtoobject) throws PanaceaException {
		try {
			String ComplAmendLogGoods[];
			String ComplAmendLogDocs[];
			String ComplAmendLogAddl[];
			String ComplAmendLogSpl1[];
			String ComplAmendLogSpl2[];

			int ComplAmendGoodsLength = dtoobject.getValue("COMPLAMENDGOODS").split("\n").length;
			ComplAmendLogGoods = dtoobject.getValue("COMPLAMENDGOODS").split("\n");

			int ComplAmendDocsLength = dtoobject.getValue("COMPLAMENDDOCS").split("\n").length;
			ComplAmendLogDocs = dtoobject.getValue("COMPLAMENDDOCS").split("\n");

			int ComplAmendAddlLength = dtoobject.getValue("COMPLAMENDADDL").split("\n").length;
			ComplAmendLogAddl = dtoobject.getValue("COMPLAMENDADDL").split("\n");

			int ComplAmendSpl1Length = dtoobject.getValue("COMPLAMENDSPL1").split("\n").length;
			ComplAmendLogSpl1 = dtoobject.getValue("COMPLAMENDSPL1").split("\n");

			int AmendSpl2Length = dtoobject.getValue("COMPLAMENDSPL2").split("\n").length;
			ComplAmendLogSpl2 = dtoobject.getValue("COMPLAMENDSPL2").split("\n");

			if (!dtoobject.getValue("COMPLAMENDGOODS").trim().equals("")) {
				Olcamdtext OlcamdtextInstance = new Olcamdtext();
				OlcamdtextManager OlcamdtextManagerInstance = new OlcamdtextManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);
				for (int i = 0; i < ComplAmendGoodsLength; i++) {
					OlcamdtextInstance.setOlcatBrnCode(Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")));
					OlcamdtextInstance.setOlcatLcType(dtoobject.getValue("OLCA_LC_TYPE"));
					OlcamdtextInstance.setOlcatLcYea(Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")));
					OlcamdtextInstance.setOlcatLcSl(Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")));
					OlcamdtextInstance.setOlcatAmdSl(Integer.parseInt(dtoobject.getValue("OLCA_AMD_SL")));
					
					OlcamdtextInstance.setOlcatFieldType("45B");
					OlcamdtextInstance.setOlcatTextSl(i+1);
					OlcamdtextInstance.setOlcatText(ComplAmendLogGoods[i]);
					OlcamdtextInstance.setIsNew(true);
					OlcamdtextManagerInstance.save(OlcamdtextInstance, TBAAUTH_MAIN_PK, TBAAUTH_ENTRY_DATE, TBAAUTH_DTL_SL);
				}

			}
			if (!dtoobject.getValue("COMPLAMENDDOCS").trim().equals("")) {
				Olcamdtext OlcamdtextInstance = new Olcamdtext();
				OlcamdtextManager OlcamdtextManagerInstance = new OlcamdtextManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);
				for (int i = 0; i < ComplAmendDocsLength; i++) {
					OlcamdtextInstance.setOlcatBrnCode(Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")));
					OlcamdtextInstance.setOlcatLcType(dtoobject.getValue("OLCA_LC_TYPE"));
					OlcamdtextInstance.setOlcatLcYea(Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")));
					OlcamdtextInstance.setOlcatLcSl(Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")));
					OlcamdtextInstance.setOlcatAmdSl(Integer.parseInt(dtoobject.getValue("OLCA_AMD_SL")));
					
					OlcamdtextInstance.setOlcatFieldType("46B");
					OlcamdtextInstance.setOlcatTextSl(i+1);
					OlcamdtextInstance.setOlcatText(ComplAmendLogDocs[i]);
					OlcamdtextInstance.setIsNew(true);
					OlcamdtextManagerInstance.save(OlcamdtextInstance, TBAAUTH_MAIN_PK, TBAAUTH_ENTRY_DATE, TBAAUTH_DTL_SL);
				}

			}
			
			if (!dtoobject.getValue("COMPLAMENDADDL").trim().equals("")) {
				Olcamdtext OlcamdtextInstance = new Olcamdtext();
				OlcamdtextManager OlcamdtextManagerInstance = new OlcamdtextManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);
				for (int i = 0; i < ComplAmendAddlLength; i++) {
					OlcamdtextInstance.setOlcatBrnCode(Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")));
					OlcamdtextInstance.setOlcatLcType(dtoobject.getValue("OLCA_LC_TYPE"));
					OlcamdtextInstance.setOlcatLcYea(Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")));
					OlcamdtextInstance.setOlcatLcSl(Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")));
					OlcamdtextInstance.setOlcatAmdSl(Integer.parseInt(dtoobject.getValue("OLCA_AMD_SL")));
					
					OlcamdtextInstance.setOlcatFieldType("47B");
					OlcamdtextInstance.setOlcatTextSl(i+1);
					OlcamdtextInstance.setOlcatText(ComplAmendLogAddl[i]);
					OlcamdtextInstance.setIsNew(true);
					OlcamdtextManagerInstance.save(OlcamdtextInstance, TBAAUTH_MAIN_PK, TBAAUTH_ENTRY_DATE, TBAAUTH_DTL_SL);
				}

			}
			
			if (!dtoobject.getValue("COMPLAMENDSPL1").trim().equals("")) {
				Olcamdtext OlcamdtextInstance = new Olcamdtext();
				OlcamdtextManager OlcamdtextManagerInstance = new OlcamdtextManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);
				
				for (int i = 0; i < ComplAmendSpl1Length; i++) {
					
					OlcamdtextInstance.setOlcatBrnCode(Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")));
					OlcamdtextInstance.setOlcatLcType(dtoobject.getValue("OLCA_LC_TYPE"));
					OlcamdtextInstance.setOlcatLcYea(Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")));
					OlcamdtextInstance.setOlcatLcSl(Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")));
					OlcamdtextInstance.setOlcatAmdSl(Integer.parseInt(dtoobject.getValue("OLCA_AMD_SL")));
					
					
					OlcamdtextInstance.setOlcatFieldType("49M");
					OlcamdtextInstance.setOlcatTextSl(i+1);
					OlcamdtextInstance.setOlcatText(ComplAmendLogSpl1[i]);
					OlcamdtextInstance.setIsNew(true);
					OlcamdtextManagerInstance.save(OlcamdtextInstance, TBAAUTH_MAIN_PK, TBAAUTH_ENTRY_DATE, TBAAUTH_DTL_SL);
				}

			}
			
			if (!dtoobject.getValue("COMPLAMENDSPL2").trim().equals("")) {
				Olcamdtext OlcamdtextInstance = new Olcamdtext();
				OlcamdtextManager OlcamdtextManagerInstance = new OlcamdtextManager(_COLLECTIONObj, V_LOG_REQ, V_ADD_LOG_REQ);
				
				for (int i = 0; i < AmendSpl2Length; i++) {
					OlcamdtextInstance.setOlcatBrnCode(Integer.parseInt(dtoobject.getValue("OLCA_BRN_CODE")));
					OlcamdtextInstance.setOlcatLcType(dtoobject.getValue("OLCA_LC_TYPE"));
					OlcamdtextInstance.setOlcatLcYea(Integer.parseInt(dtoobject.getValue("OLCA_LC_YEAR")));
					OlcamdtextInstance.setOlcatLcSl(Integer.parseInt(dtoobject.getValue("OLCA_LC_SL")));
					OlcamdtextInstance.setOlcatAmdSl(Integer.parseInt(dtoobject.getValue("OLCA_AMD_SL")));
					
					
					OlcamdtextInstance.setOlcatFieldType("49N");
					OlcamdtextInstance.setOlcatTextSl(i+1);
					OlcamdtextInstance.setOlcatText(ComplAmendLogSpl2[i]);
					OlcamdtextInstance.setIsNew(true);
					OlcamdtextManagerInstance.save(OlcamdtextInstance, TBAAUTH_MAIN_PK, TBAAUTH_ENTRY_DATE, TBAAUTH_DTL_SL);
				}

			}
		} catch (Exception e) {
			throw new PanaceaException(e.getLocalizedMessage());
		}
	}
	// ADDED BY PRASHANTH ON 22 FEB 2019
}
